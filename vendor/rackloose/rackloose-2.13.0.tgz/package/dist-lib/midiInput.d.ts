import type { WheelKind } from './wheels';
/**
 * Hardware MIDI keyboards through the Web MIDI API, in browsers that have it (Chrome, Edge and Firefox; not Safari).
 * Notes arrive with the time they were received on the `performance.now()` clock, so they record as precisely as keys.
 */
export type MidiNote = {
    on: boolean;
    note: number;
    velocity: number;
    timeStamp: number;
    input: string;
};
/** A pitch wheel or mod wheel move, at MIDI's value: pitch bend from −8192 to 8191, the mod wheel (CC1) from 0 to 127. */
export type MidiWheel = {
    kind: WheelKind;
    value: number;
    timeStamp: number;
};
export declare const midiSupported: () => boolean;
/** A note-on or note-off from a channel message, or null for anything else. A note-on at velocity 0 is a note-off. */
export declare function parseMidiMessage(data: ArrayLike<number>): {
    on: boolean;
    note: number;
    velocity: number;
} | null;
/** A pitch bend or a mod wheel (CC1) move from a channel message, or null for anything else. */
export declare function parseWheelMessage(data: ArrayLike<number>): {
    kind: WheelKind;
    value: number;
} | null;
/**
 * Asks for MIDI access and listens to every input, including ones plugged in later, calling `onNote` for each note,
 * `onWheel` for each pitch bend and mod wheel move, and `onInputs` with the inputs' names whenever they change. Resolves
 * with a function that stops listening.
 */
export declare function listenToMidi(onNote: (note: MidiNote) => void, onInputs?: (names: string[]) => void, onWheel?: (wheel: MidiWheel) => void): Promise<() => void>;
