import { type Ref } from 'react';
import { type Note } from '../dictator';
import { type WheelKind, type WheelPoint } from '../wheels';
type RollProps = {
    name: string;
    notes: Note[];
    take: Note[] | null;
    loop: number;
    grid: number;
    clock: number;
    disabled: boolean;
    /** The clip's PITCH and MOD lanes. */
    bends: WheelPoint[];
    mods: WheelPoint[];
    /** Commits an edit as one undo step; edits sharing `key` within a second share a step, like a typed velocity. */
    onChange: (notes: Note[], key?: string) => void;
    /** Commits a PITCH or MOD lane as one undo step. */
    onWheels: (kind: WheelKind, points: WheelPoint[]) => void;
    /** Plays a note to hear it; `touch` when a finger asked, which never starts audio on its own. */
    onAudition: (note: number, velocity: number, touch: boolean) => void;
    onAuditionEnd: () => void;
    onClose: () => void;
    /** Moves the playhead to 16th `step`, from the bar numbers. */
    onSeek: (step: number) => void;
    handle?: Ref<RollHandle>;
};
/** What DICTATOR's panel asks of the open roll. */
export type RollHandle = {
    /** Moves the selected notes' starts onto `grid` as one undo step, keeping them selected, and says how many it moved: none when none are selected. */
    quantize: (grid: number) => number;
};
/**
 * DICTATOR's piano roll: its clip as notes on a grid of pitches and 16ths, with a lane under it for the notes' velocity or
 * the PITCH and MOD wheels' moves, edited with a pointer, a finger or the keys. Every gesture is one change to the patch
 * when it ends, so Undo takes it back whole.
 */
export declare function PianoRoll({ name, notes, bends, mods, take, loop, grid, clock, disabled, onChange, onWheels, onAudition, onAuditionEnd, onClose, onSeek, handle }: RollProps): import("react").JSX.Element;
export {};
