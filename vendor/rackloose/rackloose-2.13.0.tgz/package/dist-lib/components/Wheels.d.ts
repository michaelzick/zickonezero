import type { WheelLevels } from '../audio/engine';
import type { WheelKind } from '../wheels';
type WheelsProps = {
    /** Where the wheels sit as heard, a hand's or a DICTATOR lane's, which they follow while no one holds them. */
    levels: WheelLevels;
    disabled: boolean;
    /** A move: the pitch wheel from −1 to 1, the mod wheel from 0 to 1. `held` while a hand is on the wheel. */
    onMove: (kind: WheelKind, level: number, held: boolean, timeStamp?: number) => void;
};
/**
 * The pitch and mod wheels at the left of the keys, played by dragging up and down. The pitch wheel springs back to the
 * centre when let go, as the originals' do; the mod wheel stays where it is left, and a double-click takes it back down.
 */
export declare function Wheels({ levels, disabled, onMove }: WheelsProps): import("react").JSX.Element;
export {};
