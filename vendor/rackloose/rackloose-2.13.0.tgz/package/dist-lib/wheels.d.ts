export type WheelKind = 'bend' | 'mod';
/** From `tick` on, the wheel sits at `value`. */
export type WheelPoint = [tick: number, value: number];
export declare const WHEEL_KINDS: readonly WheelKind[];
/** Each wheel's MIDI range and where it rests: the pitch wheel springs back to the centre, the mod wheel stays down. */
export declare const WHEEL_RANGE: Record<WheelKind, {
    min: number;
    max: number;
    rest: number;
}>;
/** Where a DICTATOR keeps each lane. */
export declare const LANE_KEY: {
    readonly bend: "bends";
    readonly mod: "mods";
};
/** The most points one lane keeps, and the most a whole patch keeps, so patches stay well inside storage limits. */
export declare const WHEEL_POINT_LIMIT = 4096;
export declare const PATCH_WHEEL_LIMIT = 16384;
/** The finest a lane is painted, in ticks: a 1/128 note. */
export declare const PAINT_TICKS = 30;
/** The finest a lane is recorded, in ticks, so a 16-bar lane fits WHEEL_POINT_LIMIT. */
export declare const RECORD_TICKS = 15;
/** `value` rounded into wheel `kind`'s range. */
export declare function clampWheel(kind: WheelKind, value: number): number;
/** A wheel value as the synths read it: the pitch wheel from −1 to 1, the mod wheel from 0 to 1. */
export declare function wheelLevel(kind: WheelKind, value: number): number;
/** The wheel value at `level`, −1 to 1 for the pitch wheel and 0 to 1 for the mod wheel. */
export declare const wheelValue: (kind: WheelKind, level: number) => number;
/** Points in tick order, the last of any on the same tick winning. */
export declare function sortPoints(points: readonly WheelPoint[]): WheelPoint[];
/** Sorted `points` without those that repeat the value before them, which change nothing. */
export declare function thinPoints(points: readonly WheelPoint[]): WheelPoint[];
/** The points of sorted `points` in clip ticks [from, to). */
export declare const pointsIn: (points: readonly WheelPoint[], from: number, to: number) => WheelPoint[];
/**
 * Where sorted lane `points` holds the wheel at clip tick `tick` of a `loop`-tick clip: the last point at or before it,
 * or before the first point, the clip's last, coming round the loop. Null for a lane with nothing in the clip.
 */
export declare function valueAt(points: readonly WheelPoint[], tick: number, loop: number): number | null;
/**
 * Lane `points` with clip ticks [from, to) of a `loop`-tick clip painted with `cells`: the points there give way to them,
 * and the lane goes back to the value it had at `to` from there on, so a stroke changes only the ticks it covers. A lane
 * that was empty goes to `empty` after the stroke, or keeps the stroke's last value when `empty` is null.
 */
export declare function paintSpan(points: readonly WheelPoint[], from: number, to: number, cells: readonly WheelPoint[], loop: number, empty: number | null): WheelPoint[];
/** Lane `points` without those in clip ticks [from, to): each point before them then holds on through. */
export declare const erasePoints: (points: readonly WheelPoint[], from: number, to: number) => WheelPoint[];
/**
 * The cells of a `grid`-tick grid a drag crosses from point `a` to point `b`, each at its start, holding the value the
 * straight line between them has there.
 */
export declare function lineCells(kind: WheelKind, a: WheelPoint, b: WheelPoint, grid: number): WheelPoint[];
/**
 * A lane with recorded `strokes` laid into it, oldest first, so a later pass round the loop wins. Each stroke holds a
 * wheel's moves in absolute ticks, from taking hold of it to letting go, and replaces the lane where it ran (its last
 * loop at most), as automation recording does in Reason; after it, the lane goes on as it was.
 */
export declare function mergeWheelTake(existing: readonly WheelPoint[], strokes: readonly (readonly WheelPoint[])[], loop: number): WheelPoint[];
/** Recorded `strokes` cut to absolute ticks [from, to), for Capture: a stroke that began earlier starts at `from` with the value it held there. */
export declare function strokesWithin(strokes: readonly (readonly WheelPoint[])[], from: number, to: number): WheelPoint[][];
/**
 * A recorded stroke with point `point` added: one within RECORD_TICKS of the last point takes its value instead, so a
 * fast hand doesn't fill the lane, and one that repeats the value changes nothing.
 */
export declare function strokeWith(stroke: readonly WheelPoint[], point: WheelPoint): WheelPoint[];
/** Lane `points` within `room` points: as they are when they fit, or else on a coarser grid, then cut. */
export declare function fitPoints(points: readonly WheelPoint[], room: number): WheelPoint[];
/**
 * Lane `points` of a `loop`-tick clip as a MIDI file holds them, for export: the points in the clip, starting at its first
 * tick with the value it comes round the loop with, since a file's wheel sits at rest until its first move.
 */
export declare function laneForFile(points: readonly WheelPoint[], loop: number): WheelPoint[];
/**
 * A file's wheel `kind` moves as a lane of a `loop`-tick clip: those in the clip, held at rest from its start to the first
 * of them as in the file, or nothing for a wheel that never leaves rest.
 */
export declare function laneFromFile(kind: WheelKind, points: readonly WheelPoint[], loop: number): WheelPoint[];
