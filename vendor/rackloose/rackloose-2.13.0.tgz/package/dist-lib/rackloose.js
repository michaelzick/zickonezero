"use client";
import { Fragment as e, createContext as t, useCallback as n, useContext as r, useEffect as i, useId as a, useImperativeHandle as o, useLayoutEffect as s, useMemo as c, useReducer as l, useRef as u, useState as d, useSyncExternalStore as f } from "react";
import { Fragment as p, jsx as m, jsxs as h } from "react/jsx-runtime";
var g = 3840, _ = [
	1,
	2,
	4,
	8,
	16
], v = _.at(-1) * g, y = 2048, b = 8192, x = [
	["1/4", 960],
	["1/8", 480],
	["1/8T", 320],
	["1/16", 240],
	["1/16T", 160],
	["1/32", 120]
], S = {
	1: 1,
	2: 14,
	3: 28,
	4: 42,
	5: 56,
	6: 70,
	7: 84,
	8: 98,
	9: 112,
	0: 127
}, C = (e) => (_[e] ?? _[0]) * g, w = (e) => C(e) / 240, T = (e) => [...e].sort((e, t) => e[0] - t[0] || e[2] - t[2]);
function E(e, t) {
	let n = 0, r = e.length;
	for (; n < r;) {
		let i = n + r >> 1;
		e[i][0] < t ? n = i + 1 : r = i;
	}
	return n;
}
var D = (e, t, n) => e.slice(E(e, t), E(e, n));
function O(e, t, n = 1, r = v) {
	return (Math.round(e + (Math.round(e / t) * t - e) * n) % r + r) % r;
}
function ee(e, t, n, r) {
	return T(e.map(([e, i, a, o]) => {
		let s = O(e, t, n, r);
		return [
			s,
			Math.max(1, Math.min(i, r - s)),
			a,
			o
		];
	}));
}
function k(e, t, n, r, i) {
	let a = (Math.round(e) % i + i) % i;
	return [
		a,
		Math.max(1, Math.min(Math.round(t), i - a)),
		n,
		Math.max(1, Math.min(127, Math.round(r)))
	];
}
function te(e, t, n) {
	if (t <= e) return [];
	if (t - e >= n) return [[0, n]];
	let r = (e % n + n) % n, i = r + (t - e);
	return i <= n ? [[r, i]] : [[r, n], [0, i - n]];
}
var A = (e) => (Math.floor(e / g) + 1) * g;
function j(e, t, n = e.length ? A(Math.max(...e.map((e) => e[0]))) : 0) {
	return T(e.filter(([e]) => e >= n - t && e < n).map(([e, n, r, i]) => k(e, n, r, i, t)));
}
var M = (e, t) => t.some(([t, n]) => e >= t && e < n);
function N(e, t, n, r) {
	let i = e.filter(([e, , i]) => !(n && M(e, r)) && !t.some((t) => t[0] === e && t[2] === i));
	return T([...i, ...t.slice(0, Math.max(0, y - i.length))]);
}
var P = class {
	held = [];
	on(e, t, n) {
		return this.held = [...this.held.filter((t) => t.id !== e), {
			id: e,
			note: t,
			velocity: n
		}], {
			note: t,
			velocity: n
		};
	}
	off(e) {
		let t = this.held.at(-1);
		if (this.held = this.held.filter((t) => t.id !== e), t?.id !== e) return;
		let n = this.held.at(-1);
		return n && n.note !== t.note ? {
			note: n.note,
			velocity: n.velocity
		} : n ? void 0 : null;
	}
	clear() {
		this.held = [];
	}
	get size() {
		return this.held.length;
	}
};
function ne(e, t) {
	for (let n = e.length - 1; n >= 0; n--) {
		let r = e[n];
		if (!(r.time > t)) return t >= r.time + r.duration && n === e.length - 1 ? null : r.count * 240 + Math.min(1, (t - r.time) / r.duration) * 240;
	}
	let n = e[0];
	return n && n.time - t <= n.duration ? n.count * 240 - (n.time - t) / n.duration * 240 : null;
}
function re(e, t, n) {
	return t && t.performanceTime > 0 ? t.contextTime + (e - t.performanceTime) / 1e3 : n.currentTime - n.latency - Math.max(0, n.now - e) / 1e3;
}
function ie(e, t = 16) {
	let n = (e % t + t) % t;
	return `${Math.floor(n / 16) + 1}.${Math.floor(n % 16 / 4) + 1}.${n % 4 + 1}`;
}
var ae = (e) => `−${Math.ceil(-e / 16)}.${Math.floor((e % 16 + 16) % 16 / 4) + 1}`, oe = {
	kick: 36,
	rim: 37,
	snare: 38,
	clap: 39,
	lowTom: 45,
	hat: 42,
	pedal: 44,
	open: 46,
	midTom: 47,
	crash: 49,
	highTom: 50,
	ride: 51,
	china: 52,
	tambourine: 54,
	bell: 56,
	anvil: 56,
	highConga: 63,
	lowConga: 64,
	cabasa: 69,
	skin: 36,
	wood: 37,
	sand: 38,
	shaker: 42,
	metal: 46,
	tom: 45
}, se = {
	35: 36,
	40: 38,
	39: 38,
	41: 45,
	43: 45,
	44: 42,
	47: 45,
	48: 50,
	52: 49,
	55: 49,
	57: 49,
	53: 51,
	59: 51,
	62: 63,
	70: 69
};
function F(e, t) {
	for (let n = t, r = 0; n !== void 0 && r < 4; n = se[n], r++) {
		let t = e.find((e) => oe[e.id] === n);
		if (t) return t.id;
	}
	return null;
}
// src/presetKit.ts
var ce = (e) => [...e].reduce((e, t, n) => t === "x" ? e | 1 << n : e, 0), I = (e, t, n) => [...e].map((e, r) => ({
	note: t[r],
	enabled: e !== ".",
	velocity: e === "X" ? 1 : e === "o" ? .5 : .74,
	gate: typeof n == "number" ? n : n[r]
})), L = (...e) => e.flatMap(([e, t]) => Array(t).fill(e)), le = (...e) => T(e.map(([e, t, n, r]) => [
	Math.round(e * 240),
	Math.round((t - .1) * 240),
	n,
	r
])), R = (e) => Number((45 / e).toFixed(3)), ue = (...e) => Object.fromEntries(Array.from({ length: 6 }, (t, n) => {
	let [r, i, a, o, s, c, l] = e[n] ?? [
		1,
		0,
		0,
		.005,
		.3,
		0,
		.2
	];
	return Object.entries({
		Ratio: r,
		Detune: i,
		Level: a,
		Attack: o,
		Decay: s,
		Sustain: c,
		Release: l
	}).map(([e, t]) => [`op${n + 1}${e}`, t]);
}).flat()), de = {
	epiano: ue([
		1,
		0,
		.85,
		.002,
		1.8,
		.12,
		.7
	], [
		1,
		0,
		.45,
		.002,
		1,
		.05,
		.5
	], [
		1,
		4,
		.45,
		.002,
		1.4,
		.1,
		.6
	], [
		14,
		0,
		.2,
		.002,
		.12,
		0,
		.1
	], [
		1,
		-4,
		.35,
		.002,
		1.6,
		.1,
		.6
	], [
		1,
		0,
		.12,
		.002,
		.6,
		0,
		.3
	]),
	bell: ue([
		1,
		0,
		.8,
		.002,
		2.2,
		0,
		1.4
	], [
		3.5,
		0,
		.5,
		.002,
		1.4,
		0,
		1
	], [
		2,
		3,
		.35,
		.002,
		1.5,
		0,
		1
	], [
		7,
		0,
		.3,
		.002,
		.6,
		0,
		.5
	], [
		4,
		0,
		.12,
		.002,
		.9,
		0,
		.6
	], [
		10.5,
		0,
		.15,
		.002,
		.3,
		0,
		.3
	]),
	reed: ue([
		1,
		0,
		.8,
		.03,
		.4,
		.8,
		.25
	], [
		2,
		0,
		.5,
		.03,
		.5,
		.6,
		.3
	], [
		1,
		6,
		.3,
		.03,
		.4,
		.8,
		.25
	], [
		2,
		0,
		.3,
		.03,
		.5,
		.5,
		.3
	]),
	kalimba: ue([
		1,
		0,
		.85,
		.002,
		.7,
		0,
		.4
	], [
		3,
		0,
		.35,
		.002,
		.08,
		0,
		.08
	], [
		1,
		5,
		.4,
		.002,
		.5,
		0,
		.3
	], [
		7,
		0,
		.18,
		.002,
		.04,
		0,
		.04
	]),
	slap: ue([
		1,
		0,
		.9,
		.002,
		.35,
		.25,
		.08
	], [
		1,
		0,
		.65,
		.002,
		.15,
		.05,
		.06
	], [
		1,
		3,
		.5,
		.002,
		.3,
		.2,
		.08
	], [
		3,
		0,
		.35,
		.002,
		.05,
		0,
		.04
	], [
		.5,
		0,
		.35,
		.002,
		.4,
		.3,
		.08
	], [
		.5,
		0,
		.1,
		.002,
		.2,
		0,
		.06
	]),
	bass: ue([
		1,
		0,
		.9,
		.002,
		.4,
		.3,
		.1
	], [
		1,
		0,
		.55,
		.002,
		.25,
		.1,
		.08
	], [
		.5,
		0,
		.5,
		.002,
		.5,
		.4,
		.1
	], [
		1,
		0,
		.2,
		.002,
		.15,
		0,
		.08
	]),
	pluck: ue([
		1,
		0,
		.8,
		.002,
		.45,
		0,
		.3
	], [
		2,
		0,
		.4,
		.002,
		.15,
		0,
		.1
	], [
		2,
		3,
		.35,
		.002,
		.35,
		0,
		.25
	], [
		5,
		0,
		.2,
		.002,
		.06,
		0,
		.05
	])
};
function z(e, t, n, r, i) {
	let a = {
		version: 1,
		name: e,
		modules: Object.entries(r).map(([e, { type: t, params: n, lanes: r, euclid: i, steps: a, notes: o }], s) => {
			let c = Pt(t, e), l = Z[t].drum?.voices ?? [];
			if (r) for (let e of l) c.params[`${e.id}Pattern`] = ce(r[e.id] ?? "");
			if (i) for (let e of l) {
				let [t, n, r = 0] = i[e.id] ?? [0, c.params[`${e.id}Steps`]];
				Object.assign(c.params, {
					[`${e.id}Hits`]: t,
					[`${e.id}Steps`]: n,
					[`${e.id}Shift`]: r
				});
			}
			return Object.assign(c.params, n), a && s > 0 ? {
				...c,
				steps: a
			} : o ? {
				...c,
				notes: o
			} : c;
		}),
		cables: [],
		sequencer: {
			bpm: t,
			swing: n,
			steps: Object.values(r)[0].steps ?? It("performance").steps
		}
	};
	for (let [e, t, n, r, o] of i) a = ln(a, {
		moduleId: e,
		portId: t
	}, {
		moduleId: n,
		portId: r
	}, o);
	return a;
}
var B = (e, t, n = "") => [[
	e,
	`pitch${n}`,
	t,
	"pitch"
], [
	e,
	`gate${n}`,
	t,
	"gate"
]], fe = (...e) => e.slice(1).map((t, n) => [
	e[n],
	"out",
	t,
	"in"
]), pe = (e, t, ...n) => [...e.flatMap((e, n) => [...fe(...e), [
	e.at(-1),
	"out",
	t,
	"abcdefgh"[n]
]]), ...fe(t, ...n)], V = (e, ...t) => pe(e, "mixer", ...t, "output");
function me(e) {
	if (e === "Vintage Bass") return z(e, 94, .1, {
		performance: {
			type: "performance",
			steps: I("X..o.xx.X..x.xx.", [
				43,
				43,
				43,
				43,
				43,
				46,
				48,
				48,
				36,
				36,
				36,
				48,
				48,
				46,
				41,
				41
			], [
				.9,
				.5,
				.5,
				.5,
				.5,
				.6,
				.9,
				.5,
				.9,
				.5,
				.5,
				.45,
				.5,
				.6,
				.9,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Wave: 3,
				osc2Detune: 4,
				osc2Level: .4,
				osc3Wave: 1,
				osc3Level: .45,
				cutoff: 560,
				resonance: .3,
				drive: .3,
				envAmount: .45,
				filterAttack: .004,
				filterDecay: .25,
				filterSustain: .3,
				filterRelease: .15,
				ampAttack: .004,
				ampDecay: .4,
				ampSustain: .8,
				ampRelease: .08,
				glide: .01,
				level: .75
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 2,
				midFreq: 1,
				midGain: 3,
				drive: 6
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 35,
				lfGain: 1,
				lfFreq: 80,
				lfBell: 1,
				lmfGain: -5,
				lmfFreq: 250,
				lmfQ: .8,
				hmfGain: 4,
				hmfFreq: 1200,
				hmfQ: 1.1,
				lpf: 7e3
			}
		},
		melody: {
			type: "performance",
			steps: I("x".repeat(16), L([86, 6], [84, 1], [82, 1], [79, 6], [77, 1], [79, 1]), .95)
		},
		whistle: {
			type: "monarch",
			params: {
				osc1Wave: 0,
				osc1Level: .9,
				osc2Level: 0,
				osc3Level: 0,
				cutoff: 6e3,
				resonance: 0,
				drive: 0,
				envAmount: 0,
				tracking: 0,
				ampAttack: .03,
				ampDecay: .3,
				ampSustain: 1,
				ampRelease: .3,
				glide: .12,
				level: .5
			}
		},
		whistleEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lpf: 9e3
			}
		},
		echo: {
			type: "delay",
			params: {
				time: R(94),
				feedback: .35,
				mix: .25
			}
		},
		echoR: {
			type: "delay",
			params: {
				time: Number((60 / 94).toFixed(3)),
				feedback: .3,
				mix: 1
			}
		},
		chords: {
			type: "performance",
			steps: I("x.......x.......", L([67, 8], [60, 8]), .95)
		},
		keys: {
			type: "aurora",
			params: {
				osc1Wave: 2,
				osc2Wave: 1,
				osc2Detune: 8,
				blend: .45,
				cutoff: 2e3,
				resonance: .1,
				envAmount: .2,
				filterAttack: .05,
				filterDecay: .8,
				filterSustain: .4,
				ampAttack: .04,
				ampDecay: .9,
				ampSustain: .7,
				ampRelease: 1.6,
				lfoWidth: .3,
				chord: 4,
				vintage: .4,
				level: .65
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 300,
				lmfGain: -3,
				lmfFreq: 450,
				lmfQ: 1.2,
				hmfGain: 2,
				hmfFreq: 2500,
				hmfQ: .8,
				hfGain: 2,
				hfFreq: 1e4,
				output: 3
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 1.8,
				mix: .25
			}
		},
		drums: {
			type: "strike",
			params: {
				level: 1,
				kickDecay: .4,
				snareTune: -2,
				snareDecay: .3,
				snareLag: 10,
				clapLevel: .55,
				clapLag: 14,
				hatDecay: .06,
				hatLevel: .45,
				hatPan: .25,
				hatLag: -5,
				openLevel: .4,
				openPan: .25,
				openLag: -5,
				tambourineLevel: .3,
				tambourinePan: -.35
			},
			lanes: {
				kick: "x......xx.x.....",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "x.xxx.x.x.xxx.x.",
				open: ".....x.......x..",
				tambourine: "....x.......x..."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 3,
				ratio: 3,
				attack: .01,
				release: .15,
				color: 1,
				detectorHp: 1,
				output: 8
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 3,
				lfFreq: 65,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 400,
				lmfQ: 1.4,
				hmfGain: 4,
				hmfFreq: 3800,
				hmfQ: .9,
				lpf: 14e3
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: .7,
				c: .7,
				d: .45,
				e: .35,
				aPan: 0,
				bPan: 0,
				cPan: .3,
				dPan: -.3,
				ePan: .7
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 0,
				attack: 4,
				release: 4,
				scHpf: 2,
				output: 4.5
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...B("performance", "monarch"),
		...B("melody", "whistle"),
		...B("chords", "keys"),
		[
			"whistleEq",
			"out2",
			"echoR",
			"in"
		],
		...V([
			[
				"drums",
				"talon",
				"drumEq"
			],
			[
				"monarch",
				"brit",
				"bassEq"
			],
			[
				"keys",
				"console",
				"space"
			],
			[
				"whistle",
				"whistleEq",
				"echo"
			],
			["echoR"]
		], "cohere")
	]);
	if (e === "Vintage Lead") return z(e, 120, 0, {
		performance: {
			type: "performance",
			steps: I("X.xx.xx.X.xxX.xx", [
				76,
				76,
				76,
				74,
				74,
				72,
				74,
				74,
				72,
				72,
				69,
				72,
				71,
				71,
				67,
				71
			], .7)
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 3,
				osc1Level: .7,
				osc2Detune: 9,
				osc2Level: .5,
				osc3Wave: 3,
				osc3Octave: 1,
				osc3Level: .2,
				cutoff: 2600,
				resonance: .25,
				drive: .2,
				envAmount: .35,
				tracking: .6,
				filterDecay: .2,
				filterSustain: .4,
				ampAttack: .004,
				ampDecay: .25,
				ampSustain: .7,
				ampRelease: .15,
				glide: .025,
				level: .6
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 300,
				lmfGain: -2,
				lmfFreq: 500,
				hmfGain: 3,
				hmfFreq: 3e3,
				hfGain: 2,
				hfFreq: 12e3
			}
		},
		echo: {
			type: "delay",
			params: {
				time: R(120),
				feedback: .3,
				mix: .22
			}
		},
		octaves: {
			type: "performance",
			steps: I("XxXxXxXxXxXxXxXx", [
				33,
				45,
				33,
				45,
				33,
				45,
				33,
				45,
				29,
				41,
				29,
				41,
				31,
				43,
				31,
				43
			], .5)
		},
		bass: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Detune: 6,
				osc2Level: .4,
				osc3Octave: 0,
				osc3Level: .3,
				cutoff: 600,
				resonance: .3,
				envAmount: .5,
				filterDecay: .12,
				filterSustain: .3,
				ampAttack: .002,
				ampDecay: .15,
				ampSustain: .5,
				ampRelease: .05,
				level: .7
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 1,
				lfGain: 2,
				midFreq: 3,
				midGain: 2,
				drive: 6
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 1,
				lfFreq: 70,
				lfBell: 1,
				lmfGain: -4.5,
				lmfFreq: 250,
				lmfQ: .9,
				hmfGain: 3,
				hmfFreq: 1200,
				hmfQ: 1.1,
				lpf: 7e3
			}
		},
		chords: {
			type: "performance",
			steps: I("x.......x...x...", L([57, 8], [50, 4], [52, 4]), .95)
		},
		strings: {
			type: "aurora",
			params: {
				osc2Wave: 0,
				osc2Detune: 12,
				hpf: 200,
				cutoff: 3e3,
				envAmount: .15,
				filterAttack: .1,
				filterDecay: .8,
				filterSustain: .6,
				ampAttack: .08,
				ampDecay: .6,
				ampSustain: .8,
				ampRelease: 1.2,
				lfoRate: .5,
				lfoWidth: .2,
				chord: 2,
				vintage: .4,
				level: .7
			}
		},
		stringsEq: {
			type: "equalizer",
			params: {
				lmfGain: -6,
				lmfFreq: 300,
				lmfQ: .7,
				hmfGain: 2,
				hmfFreq: 3e3,
				hmfQ: .8,
				hfGain: 2.5,
				hfFreq: 1e4,
				output: 2
			}
		},
		spaceEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lpf: 1e4
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2,
				mix: 1
			}
		},
		drums: {
			type: "boom",
			params: {
				kickTune: 54.2,
				kickDecay: .5,
				snareTone: .55,
				snappy: .7,
				hatDecay: .04,
				hatPan: .25,
				openDecay: .25,
				openPan: .25,
				level: .85
			},
			lanes: {
				kick: "x...x...x...x...",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "xx.xxx.xxx.xxx.x",
				open: "..x...x...x...x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .003,
				release: .1,
				color: 1,
				detectorHp: 1,
				output: 5
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2.5,
				lfFreq: 60,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 400,
				lmfQ: 1.4,
				hmfGain: 3.5,
				hmfFreq: 3800,
				hmfQ: .9,
				lpf: 14e3
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: .75,
				c: .7,
				d: .45,
				e: .4,
				aPan: 0,
				bPan: 0,
				cPan: -.35,
				dPan: .15,
				ePan: .4
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 1,
				attack: 4,
				release: 1,
				scHpf: 2,
				output: 3
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...B("performance", "monarch"),
		...B("octaves", "bass"),
		...B("chords", "strings"),
		[
			"stringsEq",
			"out2",
			"spaceEq",
			"in"
		],
		...V([
			[
				"drums",
				"talon",
				"drumEq"
			],
			[
				"bass",
				"brit",
				"bassEq"
			],
			["strings", "stringsEq"],
			[
				"monarch",
				"console",
				"echo"
			],
			["spaceEq", "space"]
		], "cohere")
	]);
	if (e === "Boom Bap") return z(e, 84, .18, {
		performance: {
			type: "performance",
			steps: I("X.....x.X..x..x.", L([50, 8], [55, 6], [50, 2]), [
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.4,
				.5,
				.95,
				.5,
				.5,
				.4,
				.5,
				.5,
				.6,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 1,
				osc1Octave: -1,
				osc1Level: .8,
				osc2Wave: 2,
				osc2Octave: -1,
				osc2Detune: 0,
				osc2Level: .2,
				osc3Wave: 0,
				osc3Octave: -2,
				osc3Level: .35,
				cutoff: 600,
				resonance: .1,
				drive: .3,
				envAmount: .25,
				tracking: .4,
				filterDecay: .3,
				filterSustain: .3,
				ampAttack: .006,
				ampDecay: .5,
				ampSustain: .75,
				ampRelease: .12,
				glide: .01,
				level: .8
			}
		},
		delay: {
			type: "delay",
			params: {
				time: R(84),
				feedback: .3,
				mix: .18
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 50,
				kickDecay: .55,
				snareTone: .4,
				snappy: .45,
				snareLag: 10,
				hatDecay: .05,
				hatPan: .2,
				hatLag: -5,
				level: .85
			},
			lanes: {
				kick: "x.....x...x..x..",
				snare: "....x.......x...",
				hat: "x.x.x.x.x.x.x.xx"
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .8,
				woodTune: 3,
				woodLevel: .4,
				shakerDecay: .08,
				shakerLevel: .5
			},
			euclid: {
				wood: [
					3,
					16,
					3
				],
				shaker: [
					8,
					16,
					1
				]
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 35,
				lfGain: 3,
				lfFreq: 70,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 420,
				lmfQ: 1.4,
				hmfGain: 4,
				hmfFreq: 3400,
				hmfQ: 1,
				lpf: 12e3
			}
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .1,
				brightness: .8,
				velocity: .75,
				lfoRate: 4.5,
				lfoDepth: .03,
				chord: 4,
				level: .7,
				...de.epiano,
				op1Ratio: 2,
				op2Ratio: 2,
				op3Ratio: 2,
				op4Ratio: 16,
				op5Ratio: 2,
				op6Ratio: 2
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 4,
				midFreq: 1,
				midGain: 2,
				hfGain: -6,
				drive: 10,
				output: 4
			}
		},
		keysEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lmfGain: -2,
				lmfFreq: 500,
				lmfQ: 1,
				hmfGain: 2,
				hmfFreq: 2500,
				hmfQ: 1,
				lpf: 1e4,
				output: 2
			}
		},
		echoR: {
			type: "delay",
			params: {
				time: Number((60 / 84).toFixed(3)),
				feedback: .3,
				mix: 1
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .006,
				release: .15,
				color: 2,
				detectorHp: 1,
				output: 6
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 35,
				lfGain: 1.5,
				lfFreq: 80,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 250,
				lmfQ: .8,
				hmfGain: 4,
				hmfFreq: 1100,
				hmfQ: 1.1,
				lpf: 6e3
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .85,
				b: .6,
				c: .6,
				d: .8,
				e: .35,
				aPan: 0,
				bPan: -.3,
				cPan: 0,
				dPan: .35,
				ePan: .7
			}
		},
		valve: {
			type: "compressor",
			params: {
				input: 1,
				threshold: -16,
				time: 1,
				output: 0
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...B("performance", "monarch"),
		...B("performance", "prism", 3),
		[
			"keysEq",
			"out2",
			"echoR",
			"in"
		],
		...V([
			[
				"boom",
				"console",
				"talon"
			],
			[
				"prism",
				"brit",
				"keysEq",
				"delay"
			],
			["monarch", "bassEq"],
			["orbit"],
			["echoR"]
		], "valve")
	]);
	if (e === "Late Night Hip-Hop") return z(e, 72, .24, {
		performance: {
			type: "performance",
			steps: I("X.....o.X....x..", L([41, 8], [39, 5], [46, 3]), [
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.95,
				.5,
				.5,
				.5,
				.5,
				.7,
				.5,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 1,
				osc1Level: .8,
				osc2Wave: 2,
				osc2Detune: 0,
				osc2Level: .22,
				osc3Wave: 0,
				osc3Level: .4,
				cutoff: 650,
				resonance: .1,
				drive: .15,
				envAmount: .3,
				filterDecay: .4,
				ampAttack: .008,
				ampDecay: .6,
				ampSustain: .8,
				ampRelease: .25,
				glide: .02,
				level: .8
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 35,
				lfGain: 1.5,
				lfFreq: 80,
				lfBell: 1,
				lmfGain: -5,
				lmfFreq: 250,
				lmfQ: .8,
				hmfGain: 4,
				hmfFreq: 1200,
				hmfQ: 1.1,
				lpf: 7e3
			}
		},
		chords: {
			type: "performance",
			steps: I("x.......x.....o.", L([57, 8], [55, 8]), .95)
		},
		keys: {
			type: "aurora",
			params: {
				osc1Wave: 1,
				osc1Width: .3,
				osc2Wave: 2,
				osc2Octave: 1,
				blend: .4,
				cutoff: 1400,
				envAmount: .25,
				filterAttack: .01,
				filterDecay: 1.2,
				ampAttack: .06,
				ampDecay: 1.5,
				ampSustain: .6,
				ampRelease: 2,
				lfoWidth: .35,
				lfoFilter: .05,
				chord: 2,
				vintage: .5,
				level: .6
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 3,
				midFreq: 0,
				midGain: -3,
				hfGain: -5,
				drive: 8,
				output: 3
			}
		},
		keysEq: {
			type: "equalizer",
			params: {
				lmfGain: -3.5,
				lmfFreq: 320,
				lmfQ: 1.1,
				hmfGain: 1.5,
				hmfFreq: 2800,
				hmfQ: 1,
				lpf: 9e3
			}
		},
		roomEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lpf: 8e3
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2.4,
				mix: 1
			}
		},
		glint: {
			type: "performance",
			steps: I("...x..x....x....", [
				88,
				88,
				88,
				88,
				88,
				88,
				84,
				84,
				84,
				84,
				84,
				86,
				86,
				86,
				86,
				86
			], .9)
		},
		bell: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: 0,
				brightness: .55,
				velocity: .5,
				level: 1,
				...de.bell
			}
		},
		bellEq: {
			type: "equalizer",
			params: {
				hpf: 350,
				hmfGain: -2,
				hmfFreq: 4e3,
				hmfQ: 1,
				lpf: 9e3,
				output: 1.5
			}
		},
		bellEcho: {
			type: "delay",
			params: {
				time: R(72),
				feedback: .4,
				mix: .35
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 47,
				kickDecay: .7,
				snareTone: .3,
				snappy: .35,
				snareLag: 12,
				rimLag: 10,
				rimPan: -.4,
				hatDecay: .04,
				hatPan: .25,
				hatLag: -6,
				openDecay: .3,
				level: .85
			},
			lanes: {
				kick: "x......x..x.....",
				snare: "....x.......x...",
				rim: "..............x.",
				hat: "..x...x...x...x."
			}
		},
		orbit: {
			type: "orbit",
			params: {
				pitch: -4,
				level: .8,
				shakerLevel: .5
			},
			euclid: { shaker: [
				6,
				16,
				2
			] }
		},
		talon: {
			type: "talon",
			params: {
				input: 4,
				ratio: 5,
				attack: .01,
				release: .4,
				color: 1,
				output: 9
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 3,
				lfFreq: 65,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 400,
				lmfQ: 1.4,
				hmfGain: 3.5,
				hmfFreq: 3400,
				hmfQ: .9,
				lpf: 11e3
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .9,
				b: .65,
				c: .6,
				d: 1,
				e: .45,
				f: .5,
				aPan: 0,
				bPan: 0,
				cPan: -.3,
				dPan: .4,
				ePan: .35,
				fPan: .5
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 25,
				lpf: 9e3,
				lfGain: 1.5,
				lfFreq: 120,
				lfBell: 1,
				hfGain: -2,
				hfFreq: 6e3
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -18,
				ratio: 0,
				attack: 4,
				release: 4,
				scHpf: 2,
				output: 4
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...B("performance", "monarch"),
		...B("chords", "keys"),
		...B("glint", "bell"),
		[
			"keysEq",
			"out2",
			"roomEq",
			"in"
		],
		...V([
			[
				"boom",
				"talon",
				"drumEq"
			],
			["monarch", "bassEq"],
			[
				"keys",
				"brit",
				"keysEq"
			],
			["orbit"],
			["roomEq", "space"],
			[
				"bell",
				"bellEq",
				"bellEcho"
			]
		], "console", "cohere")
	]);
	if (e === "Roots Reggae") return z(e, 76, .2, {
		performance: {
			type: "performance",
			steps: I("..X...x.X..x.xx.", [
				33,
				33,
				33,
				33,
				33,
				33,
				36,
				36,
				38,
				38,
				38,
				38,
				38,
				41,
				40,
				40
			], [
				.65,
				.65,
				.85,
				.65,
				.65,
				.65,
				.5,
				.65,
				.85,
				.65,
				.65,
				.45,
				.65,
				.5,
				.85,
				.65
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 1,
				osc1Level: .7,
				osc2Wave: 1,
				osc2Octave: 1,
				osc2Detune: 0,
				osc2Level: .3,
				osc3Wave: 0,
				osc3Octave: 0,
				osc3Level: .5,
				cutoff: 600,
				resonance: .05,
				drive: .35,
				envAmount: .15,
				filterDecay: .3,
				ampAttack: .006,
				ampDecay: .35,
				ampSustain: .7,
				ampRelease: .12,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 2,
				midFreq: 0,
				midGain: -3,
				hfGain: -4,
				drive: 7
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lmfGain: -4,
				lmfFreq: 230,
				lmfQ: .9,
				hmfGain: 3,
				hmfFreq: 900,
				hmfQ: 1,
				lpf: 4500
			}
		},
		bubble: {
			type: "performance",
			steps: I("..xx..xx..xx..xx", L([57, 8], [50, 8]), .6)
		},
		organ: {
			type: "aurora",
			params: {
				osc1Wave: 1,
				osc2Wave: 3,
				osc2Octave: 1,
				osc2Detune: 0,
				blend: .5,
				cutoff: 2600,
				resonance: 0,
				slope: 0,
				envAmount: 0,
				ampAttack: .003,
				ampDecay: .2,
				ampSustain: .85,
				ampRelease: .04,
				lfoRate: 6,
				lfoPitch: .01,
				lfoWidth: 0,
				chord: 2,
				vintage: .2,
				level: .45
			}
		},
		organEq: {
			type: "equalizer",
			params: {
				hpf: 130,
				lmfGain: -4,
				lmfFreq: 280,
				lmfQ: .9,
				hmfGain: 2,
				hmfFreq: 2200,
				hmfQ: 1,
				lpf: 9e3
			}
		},
		skank: {
			type: "performance",
			steps: I("....X.......X...", L([69, 8], [62, 8]), .35)
		},
		guitar: {
			type: "oracle",
			params: {
				bShape: 2,
				bFine: 5,
				cutoff: 2800,
				resonance: .2,
				envAmount: .3,
				filterDecay: .12,
				filterSustain: 0,
				ampAttack: .002,
				ampDecay: .14,
				ampSustain: 0,
				ampRelease: .08,
				chord: 2,
				level: 1
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 300,
				lmfGain: -3,
				lmfFreq: 500,
				lmfQ: 1.2,
				hmfGain: 3.5,
				hmfFreq: 2200,
				hmfQ: 1.4,
				lpf: 9e3,
				output: 3
			}
		},
		echo: {
			type: "delay",
			params: {
				time: R(76),
				feedback: .4,
				mix: .3
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 1.6,
				mix: .22
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 46,
				kickDecay: .5,
				kickLevel: 1.3,
				snareTone: .5,
				rimLevel: .9,
				hatDecay: .05,
				hatPan: .25,
				hatLag: -4,
				openDecay: .35,
				openPan: .25,
				openLag: -4,
				level: .85
			},
			lanes: {
				kick: "........x.......",
				rim: "........x.......",
				hat: "x.x.x...x.x.x..x",
				open: "......x.......x."
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .8,
				metalDecay: .09,
				metalTone: .7,
				metalLevel: .5,
				sandDecay: .06,
				sandLevel: .55
			},
			euclid: {
				metal: [
					2,
					16,
					4
				],
				sand: [
					2,
					16,
					4
				]
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 1,
				ratio: 2,
				attack: .004,
				release: .25,
				color: 1,
				detectorHp: 1,
				output: 6
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2,
				lfFreq: 60,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 400,
				lmfQ: 1.4,
				hmfGain: 3,
				hmfFreq: 3500,
				hmfQ: .9,
				lpf: 13e3,
				output: 4.5
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: 1,
				c: .5,
				d: .9,
				e: 1,
				bPan: -.3,
				dPan: -.35,
				ePan: .35
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 0,
				attack: 4,
				release: 4,
				scHpf: 2,
				output: 4.5
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...B("performance", "monarch"),
		...B("bubble", "organ"),
		...B("skank", "guitar"),
		...V([
			[
				"boom",
				"talon",
				"drumEq"
			],
			["orbit"],
			[
				"monarch",
				"brit",
				"bassEq"
			],
			["organ", "organEq"],
			[
				"guitar",
				"console",
				"echo",
				"space"
			]
		], "cohere")
	]);
	if (e === "Dub Session") return z(e, 70, .18, {
		performance: {
			type: "performance",
			steps: I("X..x..x.X.x...x.", L([40, 6], [43, 2], [47, 2], [50, 4], [47, 2]), .95)
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 0,
				osc1Level: .7,
				osc2Wave: 1,
				osc2Octave: 1,
				osc2Detune: 0,
				osc2Level: .3,
				osc3Wave: 0,
				osc3Octave: 2,
				osc3Level: .1,
				cutoff: 600,
				resonance: .1,
				drive: .25,
				envAmount: .1,
				ampAttack: .01,
				ampDecay: .5,
				ampSustain: .8,
				ampRelease: .35,
				glide: .006,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 2,
				lfGain: 2,
				midFreq: 0,
				midGain: -3,
				hfGain: -8,
				drive: 6
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 50,
				output: 3
			}
		},
		skank: {
			type: "performance",
			steps: I("....x.......x...", L([64, 16]), .3)
		},
		guitar: {
			type: "oracle",
			params: {
				bShape: 2,
				bFine: 5,
				cutoff: 2400,
				resonance: .2,
				envAmount: .3,
				filterDecay: .12,
				filterSustain: 0,
				ampAttack: .002,
				ampDecay: .15,
				ampSustain: 0,
				ampRelease: .1,
				chord: 2,
				level: 1
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 300,
				lmfGain: -3,
				lmfFreq: 450,
				hmfGain: 3,
				hmfFreq: 1800,
				lpf: 6e3,
				output: 2
			}
		},
		repeats: {
			type: "delay",
			params: {
				time: Number((60 / 70).toFixed(3)),
				feedback: .6,
				mix: .4
			}
		},
		melody: {
			type: "performance",
			steps: I("X.....X.X.X...X.", [
				71,
				71,
				71,
				71,
				71,
				71,
				74,
				74,
				71,
				71,
				69,
				69,
				69,
				69,
				67,
				67
			], .95)
		},
		melodica: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: 0,
				brightness: .9,
				velocity: .5,
				lfoRate: 5,
				lfoDepth: .12,
				level: 1,
				...de.reed
			}
		},
		melodicaEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				hmfGain: 1.5,
				hmfFreq: 2500,
				hmfQ: 1,
				lpf: 1e4,
				output: 1.5
			}
		},
		hall: {
			type: "reverb",
			params: {
				decay: 2.2,
				mix: .3
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 40.6,
				kickDecay: .75,
				kickLevel: 1.3,
				snareTone: .35,
				snappy: .5,
				snareLag: 10,
				rimLag: 8,
				hatDecay: .06,
				hatPan: .25,
				hatLag: -5,
				openDecay: .5,
				openPan: .25,
				openLag: -5,
				level: .8
			},
			lanes: {
				kick: "x..x......x.....",
				snare: "....x.......x...",
				rim: ".......x........",
				hat: "x.x.x.x.x.x.x...",
				open: "..............x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 3,
				ratio: 2,
				attack: .003,
				release: .2,
				color: 2,
				output: 8
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 28,
				lfGain: 2,
				lfFreq: 45,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 380,
				lmfQ: 1.4,
				hmfGain: 3,
				hmfFreq: 3500,
				hmfQ: .9,
				lpf: 12e3,
				output: 2
			}
		},
		roomEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lpf: 8e3
			}
		},
		reverb: {
			type: "reverb",
			params: {
				decay: 1.4,
				mix: 1
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .9,
				skinTune: 5,
				skinDecay: .25,
				skinLevel: 1,
				woodLevel: .5
			},
			euclid: {
				skin: [
					1,
					16,
					12
				],
				wood: [
					2,
					16,
					6
				]
			}
		},
		percEq: {
			type: "equalizer",
			params: {
				hpf: 250,
				output: 2
			}
		},
		delay: {
			type: "delay",
			params: {
				time: R(70),
				feedback: .55,
				mix: .45
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: 1,
				c: .7,
				d: 1,
				e: 1,
				f: .35,
				bPan: -.35,
				dPan: .35,
				ePan: -.2
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 0,
				attack: 4,
				release: 4,
				scHpf: 2,
				output: 3
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...B("performance", "monarch"),
		...B("skank", "guitar"),
		...B("melody", "melodica"),
		[
			"drumEq",
			"out2",
			"roomEq",
			"in"
		],
		...V([
			[
				"boom",
				"talon",
				"drumEq"
			],
			[
				"orbit",
				"percEq",
				"delay"
			],
			[
				"monarch",
				"brit",
				"bassEq"
			],
			[
				"guitar",
				"console",
				"repeats"
			],
			[
				"melodica",
				"melodicaEq",
				"hall"
			],
			["roomEq", "reverb"]
		], "cohere")
	]);
	if (e === "Recuerdos") {
		let t = (e) => (t, ...n) => e.map(([e, r, i], a) => [
			t * 16 + e,
			r,
			n[a],
			i
		]), n = t([
			[
				0,
				2,
				116
			],
			[
				3,
				2,
				100
			],
			[
				6,
				3,
				110
			],
			[
				10,
				2,
				96
			],
			[
				12,
				2,
				112
			],
			[
				14,
				2,
				104
			]
		]), r = [
			71,
			71,
			74,
			73,
			71,
			66
		], i = t([
			[
				0,
				3,
				120
			],
			[
				4,
				2,
				100
			],
			[
				6,
				2,
				112
			],
			[
				8,
				3,
				116
			],
			[
				12,
				2,
				100
			],
			[
				14,
				2,
				108
			]
		]), a = (e, ...t) => [
			0,
			4,
			8,
			12
		].flatMap((n) => t.map((t) => [
			e * 16 + n,
			4,
			t,
			n ? 92 : 104
		])), o = (e, ...t) => Array.from({ length: 8 }, (n, r) => [
			e * 16 + r * 2,
			2,
			t[r % 4],
			r % 2 ? 80 : 96
		]);
		return z(e, 94, 0, {
			hook: {
				type: "dictator",
				params: { length: 2 },
				notes: le(...n(0, ...r), ...n(1, 73, 73, 76, 74, 73, 69), ...n(2, ...r), ...n(3, 70, 70, 73, 76, 74, 73))
			},
			lead: {
				type: "monarch",
				params: {
					osc1Wave: 3,
					osc1Level: .7,
					osc2Wave: 2,
					osc2Detune: 11,
					osc2Level: .5,
					osc3Wave: 2,
					osc3Octave: 0,
					osc3Detune: -9,
					osc3Level: .35,
					cutoff: 1500,
					resonance: .4,
					drive: .5,
					envAmount: .5,
					tracking: .6,
					filterAttack: .002,
					filterDecay: .18,
					filterSustain: .35,
					filterRelease: .1,
					ampAttack: .002,
					ampDecay: .3,
					ampSustain: .6,
					ampRelease: .07,
					glide: 0,
					level: .7
				}
			},
			grit: {
				type: "rust",
				params: {
					mode: 0,
					drive: .45,
					bias: .2,
					body: 1e3,
					tone: .5,
					mix: .45,
					level: .6
				}
			},
			leadEq: {
				type: "equalizer",
				params: {
					hpf: 300,
					lmfGain: -3,
					lmfFreq: 520,
					lmfQ: 1,
					hmfGain: 2,
					hmfFreq: 2200,
					hmfQ: 1,
					lpf: 7500,
					output: 2
				}
			},
			echo: {
				type: "delay",
				params: {
					time: R(94),
					feedback: .25,
					mix: .18
				}
			},
			room: {
				type: "reverb",
				params: {
					decay: 1.1,
					mix: .18
				}
			},
			leadR: {
				type: "delay",
				params: {
					time: .02,
					feedback: 0,
					mix: 1
				}
			},
			bassline: {
				type: "dictator",
				params: { length: 2 },
				notes: le(...i(0, 47, 47, 50, 47, 47, 45), ...i(1, 45, 45, 49, 45, 45, 43), ...i(2, 43, 43, 47, 43, 43, 42), ...i(3, 42, 42, 46, 42, 42, 46))
			},
			bass: {
				type: "monarch",
				params: {
					osc1Wave: 2,
					osc1Level: .7,
					osc2Wave: 3,
					osc2Detune: 5,
					osc2Level: .3,
					osc3Wave: 0,
					osc3Octave: 0,
					osc3Detune: 0,
					osc3Level: .45,
					cutoff: 700,
					resonance: .25,
					drive: .35,
					envAmount: .45,
					tracking: .55,
					filterAttack: .002,
					filterDecay: .25,
					filterSustain: .3,
					filterRelease: .1,
					ampAttack: .003,
					ampDecay: .45,
					ampSustain: .75,
					ampRelease: .07,
					glide: .006,
					level: .75
				}
			},
			fuzz: {
				type: "rust",
				params: {
					mode: 0,
					drive: .35,
					bias: .15,
					body: 650,
					tone: .5,
					mix: .25,
					level: .6
				}
			},
			bassEq: {
				type: "equalizer",
				params: {
					hpf: 35,
					lfGain: 1.5,
					lfFreq: 80,
					lfBell: 1,
					lmfGain: -7,
					lmfFreq: 280,
					lmfQ: .8,
					hmfGain: 4.5,
					hmfFreq: 1200,
					hmfQ: 1.1,
					lpf: 6500
				}
			},
			chords: {
				type: "dictator",
				params: {
					length: 2,
					lag: 15
				},
				notes: le(...a(0, 62, 66, 71), ...a(1, 64, 69, 73), ...a(2, 62, 67, 71), ...a(3, 64, 70, 73))
			},
			pad: {
				type: "aurora",
				params: {
					osc1Wave: 0,
					osc2Wave: 0,
					osc2Detune: 10,
					blend: .5,
					hpf: 220,
					cutoff: 1400,
					resonance: .12,
					slope: 1,
					envAmount: .15,
					tracking: .4,
					filterAttack: .08,
					filterDecay: .5,
					filterSustain: .6,
					filterRelease: .3,
					ampAttack: .07,
					ampDecay: .35,
					ampSustain: .55,
					ampRelease: .15,
					lfoRate: .3,
					lfoWidth: .2,
					vintage: .4,
					level: .75
				}
			},
			padEq: {
				type: "equalizer",
				params: {
					hpf: 300,
					lmfGain: -4.5,
					lmfFreq: 400,
					lmfQ: 1.1,
					lpf: 7e3,
					output: 4
				}
			},
			hall: {
				type: "reverb",
				params: {
					decay: 2.2,
					mix: .3
				}
			},
			hallL: {
				type: "delay",
				params: {
					time: .02,
					feedback: 0,
					mix: 1
				}
			},
			perc: {
				type: "strike",
				lanes: {
					cabasa: "xxxxxxxxxxxxxxxx",
					tambourine: "..x...x...x...x.",
					highConga: ".......x.......x",
					lowConga: "..........x....."
				},
				params: {
					level: .54,
					cabasaDecay: .05,
					cabasaLevel: .85,
					cabasaPan: -.6,
					cabasaLag: -3,
					tambourineDecay: .12,
					tambourineLevel: .9,
					tambourinePan: .6,
					highCongaLevel: .7,
					highCongaPan: .55,
					lowCongaLevel: .55,
					lowCongaPan: -.55
				}
			},
			boom: {
				type: "boom",
				lanes: {
					kick: "x...x...x...x...",
					snare: "...x..x....x..x.",
					rim: "...x..x....x..x."
				},
				params: {
					kickTune: 60.8,
					kickDecay: .38,
					kickLevel: 1.45,
					snareTune: 3,
					snareDecay: .14,
					snareTone: .75,
					snappy: .95,
					snareLevel: 1.35,
					snareLag: 3,
					rimLevel: .95,
					rimPan: -.3,
					rimLag: 3,
					level: 1
				}
			},
			strike: {
				type: "strike",
				lanes: {
					snare: "...x..x....x..x.",
					clap: "......x.......x.",
					hat: "x.xxx.x.x.xxx.x."
				},
				params: {
					level: .85,
					snareDecay: .13,
					snareTone: .85,
					snareLevel: .75,
					snareLag: 3,
					clapDecay: .18,
					clapLevel: .75,
					clapPan: .12,
					clapLag: 6,
					hatDecay: .04,
					hatTone: .75,
					hatLevel: .4,
					hatPan: .45,
					hatLag: -3
				}
			},
			drumComp: {
				type: "talon",
				params: {
					input: 5,
					ratio: 3,
					attack: .006,
					release: .1,
					color: 2,
					fierce: 1,
					detectorHp: 1,
					output: 6.5
				}
			},
			drumEq: {
				type: "equalizer",
				params: {
					hpf: 30,
					lfGain: 2.5,
					lfFreq: 62,
					lfBell: 1,
					lmfGain: -4.5,
					lmfFreq: 400,
					lmfQ: 1.4,
					hmfGain: 5,
					hmfFreq: 3800,
					hmfQ: .9,
					lpf: 13e3
				}
			},
			arpeggio: {
				type: "dictator",
				params: { length: 2 },
				notes: le(...o(0, 78, 83, 86, 83), ...o(1, 76, 81, 85, 81), ...o(2, 79, 83, 86, 83), ...o(3, 78, 82, 85, 82))
			},
			kalimba: {
				type: "prism",
				params: {
					algorithm: 0,
					feedback: 0,
					brightness: .8,
					velocity: .6,
					level: 1,
					...de.kalimba
				}
			},
			kalimbaEq: {
				type: "equalizer",
				params: {
					hpf: 300,
					lmfGain: -2,
					lmfFreq: 600,
					hfGain: 2,
					hfFreq: 9e3,
					lpf: 12e3,
					output: 6
				}
			},
			kalimbaEcho: {
				type: "delay",
				params: {
					time: R(94),
					feedback: .35,
					mix: .3
				}
			},
			kalimbaEchoR: {
				type: "delay",
				params: {
					time: Number((60 / 94).toFixed(3)),
					feedback: .3,
					mix: 1
				}
			},
			mixer: {
				type: "mixer",
				params: {
					a: 1,
					b: .85,
					c: .9,
					d: .335,
					e: .3,
					f: .4,
					g: .33,
					h: .75,
					aPan: 0,
					bPan: 0,
					cPan: .6,
					dPan: -.2,
					ePan: .8,
					fPan: -.7,
					gPan: .7,
					hPan: -.6
				}
			},
			cohere: {
				type: "cohere",
				params: {
					threshold: -16,
					ratio: 0,
					attack: 4,
					release: 4,
					scHpf: 2,
					output: 3
				}
			},
			output: {
				type: "output",
				params: { volume: .7 }
			}
		}, [
			...B("hook", "lead"),
			...B("bassline", "bass"),
			...B("chords", "pad"),
			...B("arpeggio", "kalimba"),
			[
				"perc",
				"out",
				"boom",
				"chain"
			],
			[
				"boom",
				"out",
				"strike",
				"chain"
			],
			[
				"room",
				"out2",
				"leadR",
				"in"
			],
			[
				"kalimbaEq",
				"out2",
				"kalimbaEchoR",
				"in"
			],
			[
				"hall",
				"out2",
				"hallL",
				"in"
			],
			...V([
				[
					"strike",
					"drumComp",
					"drumEq"
				],
				[
					"bass",
					"fuzz",
					"bassEq"
				],
				[
					"pad",
					"padEq",
					"hall"
				],
				[
					"lead",
					"grit",
					"leadEq",
					"echo",
					"room"
				],
				["leadR"],
				[
					"kalimba",
					"kalimbaEq",
					"kalimbaEcho"
				],
				["kalimbaEchoR"],
				["hallL"]
			], "cohere")
		]);
	}
	return e === "Trap Soul" ? z(e, 68, .06, {
		performance: {
			type: "performance",
			steps: I("X.......X.....x.", L([65, 8], [58, 8]), [
				.95,
				.65,
				.65,
				.65,
				.65,
				.65,
				.65,
				.65,
				.95,
				.65,
				.65,
				.65,
				.65,
				.65,
				.6,
				.65
			])
		},
		oracle: {
			type: "oracle",
			params: {
				aLevel: .7,
				bLevel: .6,
				bFine: 6,
				noise: .03,
				cutoff: 1600,
				resonance: .12,
				envAmount: .3,
				tracking: .4,
				filterAttack: .005,
				filterDecay: .9,
				filterSustain: .25,
				filterRelease: 1.6,
				ampAttack: .01,
				ampDecay: 1.2,
				ampSustain: .6,
				ampRelease: 2.4,
				lfoRate: .35,
				lfoAmount: .12,
				lfoDest: 2,
				vintage: .45,
				chord: 4,
				level: 1
			}
		},
		equalizer: {
			type: "equalizer",
			params: {
				hpf: 280,
				lmfGain: -3,
				lmfFreq: 420,
				lmfQ: 1.2,
				hmfGain: 2,
				hmfFreq: 2800,
				hmfQ: .8,
				hfGain: 3,
				hfFreq: 9e3,
				lpf: 16e3,
				output: 5
			}
		},
		reverb: {
			type: "reverb",
			params: {
				decay: 2.6,
				mix: .3
			}
		},
		performance2: {
			type: "performance",
			steps: I("X.....x.X..x..x.", [
				53,
				53,
				53,
				53,
				53,
				53,
				53,
				53,
				58,
				58,
				58,
				56,
				56,
				56,
				60,
				60
			], [
				.95,
				.65,
				.65,
				.65,
				.65,
				.65,
				.6,
				.65,
				.95,
				.65,
				.65,
				.5,
				.65,
				.65,
				.5,
				.65
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 0,
				osc1Octave: -2,
				osc1Level: .8,
				osc2Wave: 1,
				osc2Octave: -1,
				osc2Detune: 0,
				osc2Level: .2,
				osc3Level: 0,
				cutoff: 1400,
				resonance: 0,
				drive: .55,
				envAmount: .1,
				tracking: .3,
				ampAttack: .003,
				ampDecay: .8,
				ampSustain: .75,
				ampRelease: 1.1,
				glide: .035,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 2,
				midFreq: 1,
				midGain: 4,
				drive: 12,
				output: -2
			}
		},
		subEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lmfGain: -3,
				lmfFreq: 250,
				lmfQ: .8,
				hmfGain: 4,
				hmfFreq: 1200,
				hmfQ: 1,
				lpf: 6e3
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 52,
				kickDecay: .32,
				snareTone: .65,
				snappy: .8,
				hatDecay: .035,
				hatPan: .2,
				openDecay: .3,
				level: .8
			},
			lanes: {
				kick: "x.....x.x.....x.",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "x.x.x.xxx.x.x.xx",
				open: "...........x...."
			}
		},
		compressor: {
			type: "compressor",
			params: {
				input: 3,
				threshold: -26,
				time: 1,
				output: 10
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2.5,
				lfFreq: 60,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 400,
				lmfQ: 1.4,
				hmfGain: 4,
				hmfFreq: 3800,
				hmfQ: .9,
				lpf: 15e3
			}
		},
		bells: {
			type: "performance",
			steps: I("..X...X...X..X..", [
				84,
				84,
				84,
				84,
				84,
				84,
				80,
				80,
				80,
				80,
				82,
				82,
				82,
				77,
				77,
				77
			], .5)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .05,
				brightness: 1,
				velocity: .6,
				level: 1,
				...de.bell
			}
		},
		bellEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lpf: 12e3
			}
		},
		delay: {
			type: "delay",
			params: {
				time: R(68),
				feedback: .4,
				mix: .3
			}
		},
		echoR: {
			type: "delay",
			params: {
				time: Number((60 / 68).toFixed(3)),
				feedback: .35,
				mix: 1
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: .3,
				c: 1,
				d: .9,
				e: .4,
				aPan: .2,
				bPan: 0,
				cPan: 0,
				dPan: -.35,
				ePan: .7
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -18,
				ratio: 0,
				attack: 4,
				release: 4,
				scHpf: 2,
				output: 4.5
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...B("performance", "oracle"),
		...B("performance2", "monarch"),
		...B("bells", "prism"),
		[
			"bellEq",
			"out2",
			"echoR",
			"in"
		],
		...V([
			[
				"oracle",
				"equalizer",
				"reverb"
			],
			[
				"monarch",
				"brit",
				"subEq"
			],
			[
				"boom",
				"compressor",
				"drumEq"
			],
			[
				"prism",
				"bellEq",
				"delay"
			],
			["echoR"]
		], "cohere")
	]) : e === "Broken Beat" ? z(e, 108, .1, {
		performance: {
			type: "performance",
			steps: I("X..x..x...x..x.x", [
				36,
				36,
				36,
				48,
				48,
				48,
				46,
				46,
				46,
				46,
				41,
				41,
				41,
				44,
				44,
				43
			], .7)
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Wave: 3,
				osc2Detune: 5,
				osc2Level: .35,
				osc3Wave: 0,
				osc3Level: .45,
				cutoff: 700,
				resonance: .3,
				drive: .3,
				envAmount: .5,
				filterDecay: .16,
				filterSustain: .2,
				ampAttack: .003,
				ampDecay: .25,
				ampSustain: .55,
				ampRelease: .06,
				glide: .006,
				level: .7
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 2,
				lfGain: 2,
				midFreq: 2,
				midGain: 3,
				drive: 8
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 35,
				lfGain: 1,
				lfFreq: 80,
				lfBell: 1,
				lmfGain: -5,
				lmfFreq: 250,
				lmfQ: .8,
				hmfGain: 3.5,
				hmfFreq: 1300,
				hmfQ: 1.1,
				lpf: 7e3
			}
		},
		stabs: {
			type: "performance",
			steps: I("X..x...x..x..x..", L([48, 7], [53, 9]), .4)
		},
		keys: {
			type: "oracle",
			params: {
				aShape: 2,
				bFine: 8,
				cutoff: 1800,
				resonance: .15,
				envAmount: .45,
				filterDecay: .25,
				filterSustain: .2,
				ampAttack: .003,
				ampDecay: .35,
				ampSustain: .3,
				ampRelease: .25,
				chord: 4,
				vintage: .4,
				level: .9
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 200,
				lmfGain: -4.5,
				lmfFreq: 330,
				lmfQ: 1,
				hmfGain: 3,
				hmfFreq: 2800,
				hfGain: 2,
				hfFreq: 9e3,
				output: 3
			}
		},
		echoEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lpf: 9e3
			}
		},
		echo: {
			type: "delay",
			params: {
				time: R(108),
				feedback: .3,
				mix: 1
			}
		},
		punch: {
			type: "punch",
			params: {
				kickTune: 54,
				kickClick: .55,
				kickDecay: .4,
				snareTone: .55,
				snappy: .65,
				snareLag: 6,
				clapLag: 10,
				hatDecay: .04,
				hatPan: .25,
				hatLag: -4,
				openDecay: .2,
				openPan: .25,
				openLag: -4,
				level: .85
			},
			lanes: {
				kick: "x.....x..x...x..",
				snare: "....x.......x...",
				clap: "....x..........x",
				hat: "x.xxx.x.x.xxx.x.",
				open: ".....x.......x.."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .004,
				release: .12,
				color: 2,
				detectorHp: 1,
				output: 6
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2.5,
				lfFreq: 65,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 400,
				lmfQ: 1.4,
				hmfGain: 3.5,
				hmfFreq: 3800,
				hmfQ: .9,
				lpf: 14e3
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .5,
				skinTune: 5,
				tomTune: 7,
				sandLevel: .6
			},
			euclid: {
				skin: [3, 8],
				tom: [
					2,
					16,
					3
				],
				sand: [5, 12]
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .85,
				b: .5,
				c: .8,
				d: .75,
				e: .4,
				aPan: 0,
				bPan: .35,
				cPan: 0,
				dPan: -.3,
				ePan: .65
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 1,
				attack: 4,
				release: 1,
				scHpf: 2,
				output: 3.5
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...B("performance", "monarch"),
		...B("stabs", "keys"),
		[
			"console",
			"out2",
			"echoEq",
			"in"
		],
		...V([
			[
				"punch",
				"talon",
				"drumEq"
			],
			["orbit"],
			[
				"monarch",
				"brit",
				"bassEq"
			],
			["keys", "console"],
			["echoEq", "echo"]
		], "cohere")
	]) : z(e, 96, .08, {
		performance: {
			type: "performance",
			steps: I("X..X..X.X..X..X.", [
				62,
				62,
				62,
				65,
				65,
				65,
				69,
				69,
				67,
				67,
				67,
				72,
				72,
				72,
				69,
				69
			], .5)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: 0,
				brightness: .9,
				velocity: .6,
				level: 1,
				...de.kalimba
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 300,
				lmfGain: -2,
				lmfFreq: 450,
				hmfGain: 2.5,
				hmfFreq: 3500,
				hfGain: 3,
				hfFreq: 1e4,
				output: 3
			}
		},
		echo: {
			type: "delay",
			params: {
				time: R(96),
				feedback: .35,
				mix: .25
			}
		},
		echoR: {
			type: "delay",
			params: {
				time: Number((60 / 96).toFixed(3)),
				feedback: .3,
				mix: 1
			}
		},
		bass: {
			type: "performance",
			steps: I("X......o..x.....", L([38, 10], [36, 6]), [
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.6,
				.5,
				.5,
				.95,
				.5,
				.5,
				.5,
				.5,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 0,
				osc1Level: .8,
				osc2Wave: 1,
				osc2Detune: 0,
				osc2Level: .3,
				osc3Level: 0,
				cutoff: 900,
				resonance: 0,
				drive: .3,
				envAmount: .1,
				ampAttack: .006,
				ampDecay: .6,
				ampSustain: .8,
				ampRelease: .2,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 2,
				midFreq: 1,
				midGain: 4,
				drive: 10
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lmfGain: -3,
				lmfFreq: 250,
				lmfQ: .8,
				hmfGain: 4,
				hmfFreq: 1200,
				hmfQ: 1,
				lpf: 6e3
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 44,
				kickDecay: .9,
				level: .85
			},
			lanes: { kick: "x.......x......." }
		},
		talon: {
			type: "talon",
			params: {
				input: 3,
				ratio: 4,
				attack: .002,
				release: .2,
				color: 2,
				output: 4
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2.5,
				lfFreq: 60,
				lfBell: 1,
				lmfGain: -3,
				lmfFreq: 350,
				lmfQ: 1.2,
				hmfGain: 3,
				hmfFreq: 3e3,
				hmfQ: 1,
				lpf: 12e3
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .75,
				woodLevel: .5,
				metalLevel: .35,
				shakerLevel: .45
			},
			euclid: {
				skin: [
					5,
					16,
					2
				],
				wood: [
					3,
					8,
					2
				],
				sand: [7, 12],
				metal: [2, 15],
				shaker: [
					9,
					16,
					2
				],
				tom: [
					3,
					14,
					1
				]
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .95,
				b: .9,
				c: 1,
				d: .6,
				e: .4,
				aPan: 0,
				bPan: 0,
				cPan: -.3,
				dPan: 0,
				ePan: .7
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -18,
				ratio: 0,
				attack: 4,
				release: 4,
				scHpf: 2,
				output: 4
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...B("performance", "prism"),
		...B("bass", "monarch"),
		[
			"console",
			"out2",
			"echoR",
			"in"
		],
		...V([
			[
				"boom",
				"talon",
				"drumEq"
			],
			["orbit"],
			[
				"prism",
				"console",
				"echo"
			],
			[
				"monarch",
				"brit",
				"bassEq"
			],
			["echoR"]
		], "cohere")
	]);
}
// src/retroPresets.ts
var he = (...e) => pe(e, "mixer", "cohere", "main"), ge = {
	cohere: {
		type: "cohere",
		params: {
			threshold: -16,
			ratio: 0,
			attack: 4,
			release: 4,
			scHpf: 2,
			output: 2
		}
	},
	main: {
		type: "output",
		params: { volume: .7 }
	}
};
function _e(e) {
	return e === "Neon Skyline" ? z(e, 112, 0, {
		pads: {
			type: "performance",
			steps: I("X.......X.......", L([57, 8], [52, 8]), .95)
		},
		aurora: {
			type: "aurora",
			params: {
				osc2Wave: 0,
				osc2Detune: 12,
				hpf: 150,
				cutoff: 2400,
				envAmount: .2,
				filterAttack: .1,
				filterDecay: 1.5,
				filterSustain: .5,
				ampAttack: .08,
				ampDecay: 1,
				ampSustain: .8,
				ampRelease: 2.2,
				lfoRate: .4,
				lfoWidth: .3,
				chord: 2,
				vintage: .5,
				level: .8
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 150,
				lmfGain: -6,
				lmfFreq: 300,
				lmfQ: .7,
				hmfGain: 2,
				hmfFreq: 3e3,
				hmfQ: .8,
				hfGain: 3,
				hfFreq: 12e3,
				output: -1
			}
		},
		spaceEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lpf: 1e4
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2.6,
				mix: 1
			}
		},
		bass: {
			type: "performance",
			steps: I("X.x.X.x.X.x.X.x.", L([41, 8], [36, 8]), .55)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .2,
				brightness: 1,
				velocity: .6,
				level: 1,
				...de.bass
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 2,
				midFreq: 2,
				midGain: 2,
				hfGain: 1,
				drive: 8,
				output: 8
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 35,
				lfGain: 1,
				lfFreq: 80,
				lfBell: 1,
				lmfGain: -4.5,
				lmfFreq: 250,
				lmfQ: .9,
				hmfGain: 3,
				hmfFreq: 1200,
				hmfQ: 1.1,
				lpf: 7e3
			}
		},
		arp: {
			type: "performance",
			steps: I("XxxxXxxxXxxxXxxx", [
				69,
				72,
				76,
				79,
				81,
				79,
				76,
				72,
				67,
				72,
				76,
				79,
				84,
				79,
				76,
				72
			], .5)
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 3,
				osc1Level: .7,
				osc2Detune: 5,
				osc2Level: .4,
				osc3Level: 0,
				cutoff: 2200,
				resonance: .3,
				envAmount: .4,
				filterDecay: .12,
				filterSustain: .1,
				ampAttack: .002,
				ampDecay: .18,
				ampSustain: .2,
				ampRelease: .12,
				level: .55
			}
		},
		arpEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				hmfGain: 1.5,
				hmfFreq: 2500,
				hmfQ: 1,
				lpf: 1e4
			}
		},
		echo: {
			type: "delay",
			params: {
				time: R(112),
				feedback: .35,
				mix: .3
			}
		},
		echoR: {
			type: "delay",
			params: {
				time: Number((60 / 112).toFixed(3)),
				feedback: .3,
				mix: 1
			}
		},
		strike: {
			type: "strike",
			params: {
				level: 1,
				kickTune: .35,
				kickDecay: .4,
				snareTune: -2,
				snareDecay: .3,
				clapLevel: .5,
				hatLevel: .4,
				hatPan: .2,
				tambourineLevel: .3,
				tambourinePan: -.3
			},
			lanes: {
				kick: "x...x...x...x...",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "x.x.x.x.x.x.x.x.",
				tambourine: "....x.......x..."
			}
		},
		drumComp: {
			type: "talon",
			params: {
				input: 3,
				ratio: 3,
				attack: 5e-4,
				release: .1,
				color: 1,
				detectorHp: 1,
				output: 8
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2.5,
				lfFreq: 60,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 400,
				lmfQ: 1.4,
				hmfGain: 3.5,
				hmfFreq: 3800,
				hmfQ: .9,
				lpf: 14e3,
				output: 3
			}
		},
		roomEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lpf: 8e3
			}
		},
		room: {
			type: "reverb",
			params: {
				decay: 1.2,
				mix: 1
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 0,
				ratio: 7,
				attack: 2e-4,
				release: .08,
				color: 2,
				output: 12
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .9,
				b: .8,
				c: .6,
				d: .5,
				e: .4,
				f: .3,
				g: .35,
				aPan: 0,
				bPan: 0,
				cPan: -.3,
				dPan: .3,
				ePan: .4,
				fPan: -.6,
				gPan: 0
			}
		},
		...ge,
		cohere: {
			type: "cohere",
			params: {
				...ge.cohere.params,
				output: 5.5
			}
		}
	}, [
		...B("pads", "aurora"),
		...B("bass", "prism"),
		...B("arp", "monarch"),
		[
			"console",
			"out2",
			"spaceEq",
			"in"
		],
		[
			"arpEq",
			"out2",
			"echoR",
			"in"
		],
		[
			"drumEq",
			"out2",
			"roomEq",
			"in"
		],
		...he([
			"strike",
			"drumComp",
			"drumEq"
		], [
			"prism",
			"brit",
			"bassEq"
		], ["aurora", "console"], [
			"monarch",
			"arpEq",
			"echo"
		], ["spaceEq", "space"], ["echoR"], [
			"roomEq",
			"room",
			"talon"
		])
	]) : e === "Digital Boogie" ? z(e, 116, .12, {
		bass: {
			type: "performance",
			steps: I("X..x..x.X.xx..x.", [
				40,
				40,
				40,
				52,
				52,
				52,
				40,
				40,
				45,
				45,
				45,
				57,
				57,
				57,
				43,
				43
			], [
				.6,
				.5,
				.5,
				.3,
				.5,
				.5,
				.6,
				.5,
				.6,
				.5,
				.5,
				.3,
				.5,
				.5,
				.6,
				.5
			])
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .3,
				brightness: 1.1,
				velocity: .8,
				level: 1,
				...de.slap
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 2,
				lfGain: 2,
				midFreq: 3,
				midGain: 3,
				drive: 6,
				output: 8
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 35,
				lfGain: 1,
				lfFreq: 80,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 280,
				lmfQ: .9,
				hmfGain: 2.5,
				hmfFreq: 1300,
				hmfQ: 1.1,
				lpf: 8e3,
				output: 3.5
			}
		},
		stabs: {
			type: "performance",
			steps: I("..X..x....X..x..", L([52, 8], [57, 8]), .6)
		},
		aurora: {
			type: "aurora",
			params: {
				osc2Detune: 8,
				cutoff: 2600,
				envAmount: .4,
				filterDecay: .2,
				filterSustain: .2,
				ampAttack: .003,
				ampDecay: .3,
				ampSustain: .2,
				ampRelease: .2,
				lfoWidth: .2,
				chord: 4,
				vintage: .35,
				level: .6
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 200,
				lmfGain: -4.5,
				lmfFreq: 330,
				lmfQ: 1,
				hmfGain: 3,
				hmfFreq: 2500,
				hmfQ: 1,
				hfGain: 2,
				hfFreq: 1e4,
				output: 3
			}
		},
		roomEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lpf: 9e3
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 1.2,
				mix: 1
			}
		},
		strike: {
			type: "strike",
			params: {
				level: 1,
				kickDecay: .35,
				snareDecay: .25,
				snareLag: 6,
				clapLevel: .6,
				clapLag: 10,
				hatDecay: .05,
				hatLevel: .35,
				hatPan: .25,
				hatLag: -4,
				bellLevel: .35,
				bellPan: -.3
			},
			lanes: {
				kick: "x.....x.x.....x.",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "x".repeat(16),
				bell: "......x.......x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .003,
				release: .1,
				color: 1,
				detectorHp: 1,
				output: 9
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2.5,
				lfFreq: 65,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 400,
				lmfQ: 1.4,
				hmfGain: 3.5,
				hmfFreq: 3800,
				hmfQ: .9,
				lpf: 14e3,
				output: 3
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .9,
				b: .75,
				c: .7,
				d: .4,
				aPan: 0,
				bPan: 0,
				cPan: -.3,
				dPan: .45
			}
		},
		...ge,
		cohere: {
			type: "cohere",
			params: {
				...ge.cohere.params,
				output: 4.5
			}
		}
	}, [
		...B("bass", "prism"),
		...B("stabs", "aurora"),
		[
			"console",
			"out2",
			"roomEq",
			"in"
		],
		...he([
			"strike",
			"talon",
			"drumEq"
		], [
			"prism",
			"brit",
			"bassEq"
		], ["aurora", "console"], ["roomEq", "space"])
	]) : e === "Midnight Ballad" ? z(e, 76, .04, {
		keys: {
			type: "performance",
			steps: I("X.....x.X.....x.", L([58, 8], [51, 8]), .9)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .08,
				brightness: .75,
				velocity: .75,
				lfoRate: 4.5,
				lfoDepth: .04,
				chord: 3,
				level: .7,
				...de.epiano
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 150,
				lmfGain: -6,
				lmfFreq: 300,
				lmfQ: .8,
				hmfGain: 2,
				hmfFreq: 2200,
				hmfQ: 1,
				hfGain: 3,
				hfFreq: 11e3,
				output: 6
			}
		},
		echoEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lpf: 9e3
			}
		},
		echo: {
			type: "delay",
			params: {
				time: R(76),
				feedback: .3,
				mix: 1
			}
		},
		strings: {
			type: "performance",
			steps: I("X.......X.......", L([58, 8], [63, 8]), .95)
		},
		aurora: {
			type: "aurora",
			params: {
				osc1Wave: 0,
				osc2Wave: 0,
				osc2Detune: 10,
				hpf: 250,
				cutoff: 2200,
				envAmount: .15,
				filterAttack: .15,
				filterDecay: 1.5,
				filterSustain: .6,
				ampAttack: .12,
				ampDecay: 1.2,
				ampSustain: .8,
				ampRelease: 2.8,
				lfoRate: .3,
				lfoWidth: .3,
				chord: 1,
				vintage: .45,
				level: .8
			}
		},
		stringsEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lmfGain: -4,
				lmfFreq: 500,
				lmfQ: 1,
				hmfGain: 2,
				hmfFreq: 3200,
				hmfQ: 1,
				hfGain: 2.5,
				hfFreq: 1e4,
				lpf: 14e3,
				output: 5
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2.8,
				mix: .4
			}
		},
		bass: {
			type: "performance",
			steps: I("X.....x.X.....x.", L([34, 6], [41, 2], [39, 6], [46, 2]), [
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.8,
				.5,
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.8,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 1,
				osc1Level: .8,
				osc2Wave: 2,
				osc2Detune: 0,
				osc2Level: .15,
				osc3Wave: 0,
				osc3Octave: 0,
				osc3Level: .25,
				cutoff: 850,
				resonance: .15,
				drive: .15,
				envAmount: .25,
				filterDecay: .5,
				filterSustain: .4,
				ampAttack: .015,
				ampDecay: .8,
				ampSustain: .7,
				ampRelease: .3,
				glide: .03,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				midFreq: 1,
				midGain: 2,
				hfGain: -3,
				drive: 4
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 38,
				lfGain: 1,
				lfFreq: 70,
				lfBell: 1,
				lmfGain: -4.5,
				lmfFreq: 220,
				lmfQ: .9,
				hmfGain: 3,
				hmfFreq: 800,
				hmfQ: 1,
				lpf: 4500,
				output: -1
			}
		},
		strike: {
			type: "strike",
			params: {
				level: .9,
				kickDecay: .25,
				kickTone: .55,
				kickLevel: 1.6,
				snareTune: -3,
				snareDecay: .5,
				snareLag: 10,
				hatLevel: .22,
				hatPan: .25,
				hatLag: -4,
				rideLevel: .09,
				rideDecay: .9,
				rideTone: .5,
				ridePan: -.25,
				rideLag: -4
			},
			lanes: {
				kick: "x.......x..x....",
				snare: "....x.......x...",
				hat: "x...x...x...x...",
				ride: "..x...x...x...x."
			}
		},
		drumComp: {
			type: "talon",
			params: {
				input: 0,
				ratio: 1,
				attack: .012,
				release: .15,
				color: 1,
				detectorHp: 1,
				output: 7
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 40,
				lfGain: -3.5,
				lfFreq: 110,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 220,
				lmfQ: .9,
				hmfGain: 1.5,
				hmfFreq: 3500,
				hmfQ: .9,
				lpf: 11e3,
				output: 4.5
			}
		},
		roomEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lpf: 8e3
			}
		},
		room: {
			type: "reverb",
			params: {
				decay: 1.6,
				mix: 1
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 0,
				ratio: 6,
				attack: 5e-4,
				release: .12,
				color: 1,
				output: 8
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .9,
				b: .9,
				c: .6,
				d: .55,
				e: .4,
				f: .28,
				aPan: 0,
				bPan: -.35,
				cPan: .4,
				dPan: 0,
				ePan: .65,
				fPan: 0
			}
		},
		...ge,
		cohere: {
			type: "cohere",
			params: {
				...ge.cohere.params,
				output: 5
			}
		}
	}, [
		...B("keys", "prism"),
		...B("strings", "aurora"),
		...B("bass", "monarch"),
		[
			"console",
			"out2",
			"echoEq",
			"in"
		],
		[
			"drumEq",
			"out2",
			"roomEq",
			"in"
		],
		...he([
			"strike",
			"drumComp",
			"drumEq"
		], ["prism", "console"], [
			"aurora",
			"stringsEq",
			"space"
		], [
			"monarch",
			"brit",
			"bassEq"
		], ["echoEq", "echo"], [
			"roomEq",
			"room",
			"talon"
		])
	]) : e === "New Wave Motion" ? z(e, 132, 0, {
		bass: {
			type: "performance",
			steps: I("X.x.x.x.X.x.x.x.", [
				38,
				38,
				38,
				38,
				38,
				38,
				50,
				50,
				34,
				34,
				34,
				34,
				34,
				34,
				46,
				46
			], .6)
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Detune: 7,
				osc2Level: .5,
				osc3Wave: 3,
				osc3Octave: 0,
				osc3Level: .35,
				cutoff: 900,
				resonance: .3,
				drive: .35,
				envAmount: .45,
				filterDecay: .15,
				filterSustain: .3,
				ampAttack: .002,
				ampDecay: .15,
				ampSustain: .6,
				ampRelease: .05,
				level: .7
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 2,
				lfGain: 2,
				midFreq: 2,
				midGain: 4,
				hfGain: 2,
				drive: 10
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 35,
				lfGain: 1,
				lfFreq: 80,
				lfBell: 1,
				lmfGain: -4.5,
				lmfFreq: 250,
				lmfQ: .9,
				hmfGain: 3,
				hmfFreq: 1200,
				hmfQ: 1.1,
				lpf: 7e3
			}
		},
		pad: {
			type: "performance",
			steps: I("x.......x.......", L([50, 16]), .95)
		},
		aurora: {
			type: "aurora",
			params: {
				osc1Wave: 1,
				osc1Width: .35,
				osc2Wave: 0,
				osc2Detune: 9,
				hpf: 180,
				cutoff: 2600,
				envAmount: .2,
				filterAttack: .15,
				filterDecay: 1,
				filterSustain: .5,
				ampAttack: .06,
				ampDecay: .8,
				ampSustain: .75,
				ampRelease: 1.6,
				lfoRate: .7,
				lfoWidth: .45,
				chord: 2,
				vintage: .35,
				level: .7
			}
		},
		padEq: {
			type: "equalizer",
			params: {
				hpf: 150,
				lmfGain: -6,
				lmfFreq: 280,
				lmfQ: .7,
				hmfGain: 2.5,
				hmfFreq: 2800,
				hmfQ: .8,
				hfGain: 3,
				hfFreq: 11e3,
				output: 2
			}
		},
		spaceEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lpf: 1e4
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 1.8,
				mix: 1
			}
		},
		hook: {
			type: "performance",
			steps: I("X..X..X...X..X..", [
				81,
				81,
				81,
				77,
				77,
				77,
				74,
				74,
				74,
				74,
				76,
				76,
				76,
				77,
				77,
				77
			], .6)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .05,
				brightness: 1.1,
				velocity: .6,
				level: 1,
				...de.bell
			}
		},
		hookEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				hmfGain: 1.5,
				hmfFreq: 3e3,
				hmfQ: 1,
				lpf: 12e3
			}
		},
		echo: {
			type: "delay",
			params: {
				time: R(132),
				feedback: .35,
				mix: .25
			}
		},
		echoR: {
			type: "delay",
			params: {
				time: Number((60 / 132).toFixed(3)),
				feedback: .3,
				mix: 1
			}
		},
		strike: {
			type: "strike",
			params: {
				level: 1,
				kickTune: -3.64,
				kickDecay: .35,
				snareDecay: .3,
				hatDecay: .05,
				hatLevel: .4,
				hatPan: .2,
				midTomPan: .3,
				lowTomPan: -.3
			},
			lanes: {
				kick: "x.......x.x.....",
				snare: "....x.......x...",
				hat: "x.x.x.x.x.x.x...",
				midTom: "..............x.",
				lowTom: "...............x"
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 4,
				attack: .002,
				release: .1,
				color: 2,
				detectorHp: 1,
				output: 10
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 3,
				lfFreq: 60,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 380,
				lmfQ: 1.2,
				hmfGain: 3,
				hmfFreq: 4e3,
				hmfQ: 1,
				lpf: 14e3
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: .65,
				c: .55,
				d: .7,
				e: .4,
				f: .3,
				aPan: 0,
				bPan: 0,
				cPan: -.4,
				dPan: .35,
				ePan: .5,
				fPan: -.65
			}
		},
		...ge,
		cohere: {
			type: "cohere",
			params: {
				...ge.cohere.params,
				output: 4
			}
		}
	}, [
		...B("bass", "monarch"),
		...B("pad", "aurora"),
		...B("hook", "prism"),
		[
			"padEq",
			"out2",
			"spaceEq",
			"in"
		],
		[
			"hookEq",
			"out2",
			"echoR",
			"in"
		],
		...he([
			"strike",
			"talon",
			"console"
		], [
			"monarch",
			"brit",
			"bassEq"
		], ["aurora", "padEq"], [
			"prism",
			"hookEq",
			"echo"
		], ["spaceEq", "space"], ["echoR"])
	]) : e === "Glass Arcade" ? z(e, 108, 0, {
		arp: {
			type: "performance",
			steps: I("XxxxXxxxXxxxXxxx", [
				72,
				76,
				79,
				83,
				84,
				83,
				79,
				76,
				69,
				72,
				76,
				79,
				81,
				79,
				76,
				72
			], .5)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: 0,
				brightness: 1.2,
				velocity: .6,
				level: 1,
				...de.bell,
				op1Decay: .6,
				op1Release: .4,
				op3Decay: .5,
				op3Release: .3
			}
		},
		arpEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lpf: 12e3
			}
		},
		echo: {
			type: "delay",
			params: {
				time: R(108),
				feedback: .4,
				mix: .3
			}
		},
		echoR: {
			type: "delay",
			params: {
				time: Number((60 / 108).toFixed(3)),
				feedback: .3,
				mix: 1
			}
		},
		melody: {
			type: "performance",
			steps: I("X.x.x...X.x.xx..", [
				76,
				76,
				79,
				79,
				81,
				81,
				79,
				79,
				76,
				76,
				74,
				74,
				72,
				74,
				74,
				74
			], .75)
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 3,
				osc1Level: .8,
				osc2Wave: 3,
				osc2Detune: 6,
				osc2Level: .35,
				osc3Level: 0,
				cutoff: 3200,
				resonance: .15,
				envAmount: .2,
				filterDecay: .2,
				filterSustain: .6,
				ampAttack: .003,
				ampDecay: .2,
				ampSustain: .75,
				ampRelease: .1,
				glide: .006,
				level: .55
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 2,
				midFreq: 3,
				midGain: 3,
				hfGain: 2,
				drive: 4,
				output: 4
			}
		},
		bass: {
			type: "performance",
			steps: I("X.x.X.x.X.x.X.x.", [
				36,
				36,
				48,
				48,
				36,
				36,
				48,
				48,
				33,
				33,
				45,
				45,
				33,
				33,
				45,
				45
			], .55)
		},
		aurora: {
			type: "aurora",
			params: {
				osc1Wave: 1,
				osc1Width: .25,
				osc2Wave: 1,
				osc2Octave: 0,
				osc2Detune: 0,
				osc2Width: .5,
				blend: .4,
				cutoff: 1400,
				resonance: .2,
				envAmount: .4,
				filterDecay: .15,
				filterSustain: .2,
				ampAttack: .002,
				ampDecay: .2,
				ampSustain: .5,
				ampRelease: .06,
				lfoWidth: 0,
				level: 1
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 35,
				lfGain: 1.5,
				lfFreq: 80,
				lfBell: 1,
				lmfGain: -4.5,
				lmfFreq: 250,
				lmfQ: .9,
				hmfGain: 3,
				hmfFreq: 1200,
				hmfQ: 1.1,
				lpf: 7e3
			}
		},
		strike: {
			type: "strike",
			params: {
				level: 1,
				kickTune: .35,
				kickDecay: .3,
				snareDecay: .22,
				hatDecay: .04,
				hatLevel: .3,
				hatPan: .2,
				openLevel: .35,
				openPan: .2
			},
			lanes: {
				kick: "x.....x.x.......",
				snare: "....x.......x...",
				hat: "x.x.x.x.x.x.x...",
				open: "..............x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 3,
				ratio: 3,
				attack: 3e-4,
				release: .1,
				color: 0,
				detectorHp: 1,
				output: 10
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2.5,
				lfFreq: 60,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 400,
				lmfQ: 1.4,
				hmfGain: 3.5,
				hmfFreq: 3800,
				hmfQ: .9,
				lpf: 14e3,
				output: 1
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .9,
				b: 1,
				c: .3,
				d: .85,
				e: .35,
				aPan: 0,
				bPan: .45,
				cPan: -.3,
				dPan: 0,
				ePan: -.65
			}
		},
		...ge,
		cohere: {
			type: "cohere",
			params: {
				...ge.cohere.params,
				output: 6
			}
		}
	}, [
		...B("arp", "prism"),
		...B("melody", "monarch"),
		...B("bass", "aurora"),
		[
			"arpEq",
			"out2",
			"echoR",
			"in"
		],
		...he([
			"strike",
			"talon",
			"drumEq"
		], [
			"prism",
			"arpEq",
			"echo"
		], ["monarch", "brit"], ["aurora", "console"], ["echoR"])
	]) : z(e, 96, .06, {
		pads: {
			type: "performance",
			steps: I("X.......X.......", L([50, 8], [55, 8]), .95)
		},
		aurora: {
			type: "aurora",
			params: {
				osc1Wave: 0,
				osc2Wave: 2,
				osc2Octave: 1,
				osc2Detune: 6,
				blend: .4,
				hpf: 120,
				cutoff: 2e3,
				envAmount: .15,
				filterAttack: .12,
				filterDecay: 1.5,
				filterSustain: .6,
				ampAttack: .1,
				ampDecay: 1.2,
				ampSustain: .8,
				ampRelease: 2.4,
				lfoRate: .25,
				lfoWidth: .3,
				lfoFilter: .05,
				chord: 3,
				vintage: .4,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 2,
				midFreq: 0,
				midGain: -2,
				hfGain: 5,
				drive: 3
			}
		},
		padEq: {
			type: "equalizer",
			params: {
				lmfGain: -5,
				lmfFreq: 300,
				lmfQ: .7,
				hmfGain: 1.5,
				hmfFreq: 3e3,
				hmfQ: .8,
				output: -1
			}
		},
		spaceEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lpf: 1e4
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2.8,
				mix: 1
			}
		},
		pluck: {
			type: "performance",
			steps: I("X.XX.X.XX.X.XX.X", [
				74,
				74,
				78,
				81,
				81,
				85,
				85,
				81,
				79,
				79,
				83,
				86,
				86,
				83,
				83,
				79
			], .5)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: 0,
				brightness: .9,
				velocity: .6,
				level: 1,
				...de.pluck,
				op1Level: 1
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 300,
				lmfGain: -2,
				lmfFreq: 450,
				lmfQ: 1,
				hmfGain: 2,
				hmfFreq: 3e3,
				hmfQ: .8,
				hfGain: 3,
				hfFreq: 12e3
			}
		},
		echo: {
			type: "delay",
			params: {
				time: R(96),
				feedback: .45,
				mix: .3
			}
		},
		echoR: {
			type: "delay",
			params: {
				time: Number((60 / 96).toFixed(3)),
				feedback: .3,
				mix: 1
			}
		},
		bass: {
			type: "performance",
			steps: I("X.....x.X.....x.", L([38, 8], [43, 8]), [
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 0,
				osc1Level: .8,
				osc2Wave: 1,
				osc2Octave: 1,
				osc2Detune: 0,
				osc2Level: .25,
				osc3Level: 0,
				cutoff: 400,
				resonance: 0,
				drive: .1,
				envAmount: .1,
				ampAttack: .01,
				ampDecay: .6,
				ampSustain: .8,
				ampRelease: .3,
				glide: .006,
				level: .8
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .9,
				woodTune: 5,
				woodLevel: .45,
				sandLevel: .5,
				sandPan: -.35,
				shakerDecay: .08,
				shakerLevel: .55,
				shakerPan: .35
			},
			euclid: {
				wood: [3, 8],
				sand: [
					5,
					16,
					2
				],
				shaker: [
					8,
					16,
					1
				]
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .7,
				b: 1,
				c: .6,
				d: 1,
				e: .4,
				f: .3,
				aPan: -.3,
				bPan: .3,
				cPan: 0,
				dPan: 0,
				ePan: .4,
				fPan: -.6
			}
		},
		...ge,
		cohere: {
			type: "cohere",
			params: {
				threshold: -14,
				ratio: 0,
				attack: 5,
				release: 4,
				scHpf: 2,
				output: 5
			}
		}
	}, [
		...B("pads", "aurora"),
		...B("pluck", "prism"),
		...B("bass", "monarch"),
		[
			"padEq",
			"out2",
			"spaceEq",
			"in"
		],
		[
			"console",
			"out2",
			"echoR",
			"in"
		],
		...he([
			"aurora",
			"brit",
			"padEq"
		], [
			"prism",
			"console",
			"echo"
		], ["monarch"], ["orbit"], ["spaceEq", "space"], ["echoR"])
	]);
}
// src/studioPresets.ts
var ve = (...e) => pe(e, "sum", "cohere", "main");
function ye(e) {
	return e === "French Touch" ? z(e, 123, .08, {
		seq: {
			type: "performance",
			steps: I("X.xx.x.xX.x.X.xx", [
				33,
				33,
				45,
				33,
				33,
				43,
				43,
				45,
				38,
				38,
				50,
				38,
				48,
				48,
				45,
				43
			], .8)
		},
		stabs: {
			type: "performance",
			steps: I("..X..x.x..X..x..", L([57, 8], [62, 8]), .55)
		},
		bass: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Wave: 3,
				osc2Detune: 5,
				osc2Level: .45,
				osc3Wave: 3,
				osc3Octave: 0,
				osc3Level: .5,
				cutoff: 520,
				resonance: .35,
				drive: .35,
				envAmount: .55,
				tracking: .6,
				filterAttack: .003,
				filterDecay: .16,
				filterSustain: .12,
				filterRelease: .08,
				ampAttack: .003,
				ampDecay: .3,
				ampSustain: .7,
				ampRelease: .06,
				glide: .006,
				level: .75
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 2,
				lfGain: 2.5,
				midFreq: 1,
				midGain: 3,
				drive: 8,
				output: -2
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 1,
				lfFreq: 70,
				lfBell: 1,
				lmfGain: -4.5,
				lmfFreq: 250,
				lmfQ: .9,
				hmfGain: 3,
				hmfFreq: 1200,
				hmfQ: 1.1,
				lpf: 7e3
			}
		},
		keys: {
			type: "aurora",
			params: {
				osc2Wave: 0,
				osc2Detune: 9,
				hpf: 180,
				cutoff: 2200,
				envAmount: .35,
				filterAttack: .002,
				filterDecay: .22,
				filterSustain: .2,
				ampAttack: .004,
				ampDecay: .35,
				ampSustain: .5,
				ampRelease: .22,
				lfoWidth: 0,
				chord: 4,
				vintage: .35,
				level: .75
			}
		},
		sieve: {
			type: "filter",
			params: {
				cutoff: 1100,
				resonance: 4.5
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 150,
				lmfGain: -5,
				lmfFreq: 320,
				lmfQ: .7,
				hmfGain: 3,
				hmfFreq: 2e3,
				hmfQ: 1,
				hfGain: 2,
				hfFreq: 1e4
			}
		},
		sweep: {
			type: "lfo",
			params: {
				wave: 1,
				rate: .12
			}
		},
		echoEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lpf: 1e4
			}
		},
		echo: {
			type: "delay",
			params: {
				time: R(123),
				feedback: .3,
				mix: 1
			}
		},
		drums: {
			type: "punch",
			params: {
				kickTune: 54.3,
				kickClick: .45,
				kickDecay: .5,
				snappy: .6,
				hatDecay: .04,
				hatPan: .25,
				openDecay: .28,
				openPan: .25,
				level: .85
			},
			lanes: {
				kick: "x...x...x...x...",
				clap: "....x.......x...",
				hat: "...x...x...x...x",
				open: "..x...x...x...x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .008,
				release: .12,
				color: 1,
				detectorHp: 1,
				output: 5
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2.5,
				lfFreq: 60,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 400,
				lmfQ: 1.4,
				hmfGain: 3.5,
				hmfFreq: 3800,
				hmfQ: .9,
				lpf: 14e3
			}
		},
		sum: {
			type: "mixer",
			params: {
				a: .8,
				b: .8,
				c: .5,
				d: .22,
				aPan: 0,
				bPan: -.3,
				cPan: 0,
				dPan: .45
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 1,
				attack: 4,
				release: 1,
				scHpf: 2,
				output: 3
			}
		},
		main: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...B("seq", "bass"),
		...B("stabs", "keys"),
		[
			"sweep",
			"out",
			"sieve",
			"cv",
			.8
		],
		[
			"console",
			"out2",
			"echoEq",
			"in"
		],
		...ve([
			"drums",
			"talon",
			"drumEq"
		], [
			"keys",
			"sieve",
			"console"
		], [
			"bass",
			"brit",
			"bassEq"
		], ["echoEq", "echo"])
	]) : e === "Distortion Disco" ? z(e, 116, 0, {
		seq: {
			type: "performance",
			steps: I("Xx.xX.x.Xx.xX.xx", [
				28,
				40,
				40,
				28,
				38,
				38,
				40,
				40,
				31,
				43,
				43,
				31,
				33,
				33,
				35,
				38
			], .8)
		},
		stabs: {
			type: "performance",
			steps: I("..X....x..X..x..", L([64, 8], [57, 8]), .7)
		},
		bass: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Detune: 14,
				osc2Level: .6,
				osc3Wave: 3,
				osc3Octave: 1,
				osc3Level: .3,
				cutoff: 650,
				resonance: .25,
				drive: .6,
				envAmount: .5,
				tracking: .7,
				filterDecay: .2,
				filterSustain: .3,
				ampAttack: .002,
				ampDecay: .2,
				ampSustain: .8,
				ampRelease: .05,
				level: .7
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 2,
				lfGain: 2,
				midFreq: 1,
				midGain: 6,
				hfGain: -4,
				drive: 12,
				output: 1
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 1,
				lfFreq: 70,
				lfBell: 1,
				lmfGain: -5,
				lmfFreq: 250,
				lmfQ: .9,
				hmfGain: 3,
				hmfFreq: 1200,
				hmfQ: 1.1,
				lpf: 6500
			}
		},
		prophet: {
			type: "oracle",
			params: {
				bFine: 10,
				aLevel: .8,
				bLevel: .7,
				cutoff: 1400,
				resonance: .2,
				envAmount: .5,
				filterAttack: .005,
				filterDecay: .3,
				filterSustain: .3,
				filterRelease: .2,
				ampAttack: .004,
				ampDecay: .5,
				ampSustain: .55,
				ampRelease: .25,
				chord: 2,
				vintage: .45,
				level: .9
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 150,
				lmfGain: -5,
				lmfFreq: 350,
				lmfQ: .7,
				hmfGain: 3,
				hmfFreq: 2500,
				hmfQ: 1,
				hfGain: 1.5,
				hfFreq: 9e3,
				lpf: 14e3
			}
		},
		spaceEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lpf: 1e4
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 1.4,
				mix: 1
			}
		},
		drums: {
			type: "strike",
			params: {
				level: .85,
				kickTune: -4.64,
				kickDecay: .35,
				kickLevel: 1,
				snareDecay: .25,
				snareLevel: .85,
				clapLevel: .6,
				hatDecay: .06,
				hatLevel: .5,
				hatPan: -.15,
				openLevel: .45,
				tambourineLevel: .4,
				tambourinePan: .25
			},
			lanes: {
				kick: "x...x...x...x...",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "x.x.x.x.x.x.x...",
				open: "..............x.",
				tambourine: "..x...x...x...x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 8,
				ratio: 6,
				attack: .001,
				release: .1,
				color: 2,
				fierce: 1,
				detectorHp: 1,
				output: 5
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2.5,
				lfFreq: 60,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 400,
				lmfQ: 1.4,
				hmfGain: 3.5,
				hmfFreq: 3800,
				hmfQ: .9,
				lpf: 14e3
			}
		},
		sum: {
			type: "mixer",
			params: {
				a: 1,
				b: .9,
				c: .6,
				d: .2,
				aPan: 0,
				bPan: .3,
				cPan: 0,
				dPan: -.4
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -18,
				ratio: 2,
				attack: 3,
				release: 1,
				scHpf: 2,
				output: 5
			}
		},
		main: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...B("seq", "bass"),
		...B("stabs", "prophet"),
		[
			"console",
			"out2",
			"spaceEq",
			"in"
		],
		...ve([
			"drums",
			"talon",
			"drumEq"
		], ["prophet", "console"], [
			"bass",
			"brit",
			"bassEq"
		], ["spaceEq", "space"])
	]) : e === "Electro Pogo" ? z(e, 128, 0, {
		seq: {
			type: "performance",
			steps: I(".xXx.xXx.xXx.xXx", [
				38,
				38,
				50,
				38,
				38,
				38,
				50,
				38,
				34,
				34,
				46,
				34,
				36,
				36,
				48,
				36
			], .6)
		},
		hook: {
			type: "performance",
			steps: I("X.x.xx.x.X.xX.x.", [
				69,
				69,
				74,
				74,
				77,
				76,
				76,
				74,
				74,
				77,
				77,
				74,
				76,
				76,
				79,
				79
			], .7)
		},
		bass: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Detune: 8,
				osc2Level: .5,
				osc3Wave: 3,
				osc3Level: .45,
				cutoff: 500,
				resonance: .4,
				drive: .55,
				envAmount: .6,
				filterDecay: .12,
				filterSustain: .15,
				ampDecay: .18,
				ampSustain: .6,
				ampRelease: .04,
				level: .7
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2,
				lfFreq: 70,
				lfBell: 1,
				lmfGain: -3,
				lmfFreq: 280,
				lmfQ: 1.2,
				hmfGain: 3,
				hmfFreq: 1200,
				hmfQ: 1.2,
				lpf: 9e3
			}
		},
		lead: {
			type: "oracle",
			params: {
				bOctave: 1,
				bFine: 6,
				bLevel: .5,
				cutoff: 2600,
				resonance: .3,
				envAmount: .35,
				filterDecay: .25,
				filterSustain: .4,
				ampAttack: .003,
				ampDecay: .3,
				ampSustain: .65,
				ampRelease: .15,
				glide: .035,
				level: 1
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 2,
				midFreq: 3,
				midGain: 4,
				hfGain: 4,
				drive: 6,
				output: 6
			}
		},
		echo: {
			type: "delay",
			params: {
				time: R(128),
				feedback: .32,
				mix: .22
			}
		},
		drums: {
			type: "punch",
			params: {
				kickTune: 50,
				kickClick: .7,
				kickDecay: .45,
				snareTone: .6,
				snappy: .8,
				hatDecay: .035,
				openDecay: .2,
				level: .85
			},
			lanes: {
				kick: "x...x...x...x...",
				snare: "....x.......x..x",
				clap: "....x.......x...",
				hat: "xx.xxx.xxx.xxx.x",
				open: "..x...x...x...x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .006,
				release: .09,
				color: 1,
				detectorHp: 1,
				output: 5
			}
		},
		sum: {
			type: "mixer",
			params: {
				a: .8,
				b: .8,
				c: .5
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -14,
				ratio: 1,
				attack: 5,
				release: 4,
				scHpf: 2,
				output: 2
			}
		},
		main: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...B("seq", "bass"),
		...B("hook", "lead"),
		...ve(["drums", "talon"], [
			"lead",
			"brit",
			"echo"
		], ["bass", "console"])
	]) : z(e, 126, 0, {
		seq: {
			type: "performance",
			steps: I("XxxxXxxxXxxxXxxx", [
				36,
				48,
				36,
				48,
				36,
				48,
				36,
				48,
				32,
				44,
				32,
				44,
				34,
				46,
				34,
				46
			], .65)
		},
		hook: {
			type: "performance",
			steps: I("..X..x.x..X..x..", [
				75,
				75,
				75,
				75,
				75,
				74,
				74,
				72,
				72,
				72,
				75,
				75,
				75,
				74,
				74,
				74
			], .8)
		},
		bass: {
			type: "monarch",
			params: {
				osc1Wave: 3,
				osc1Level: .8,
				osc2Detune: -7,
				osc2Level: .5,
				osc3Wave: 3,
				osc3Octave: 0,
				osc3Level: .35,
				cutoff: 420,
				resonance: .75,
				drive: .6,
				envAmount: .7,
				tracking: .6,
				filterAttack: .002,
				filterDecay: .11,
				filterSustain: 0,
				filterRelease: .05,
				ampAttack: .002,
				ampDecay: .15,
				ampSustain: .5,
				ampRelease: .04,
				level: .7
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 35,
				lfGain: 1,
				lfFreq: 70,
				lfBell: 1,
				lmfGain: -4.5,
				lmfFreq: 250,
				lmfQ: .9,
				hmfGain: 3.5,
				hmfFreq: 1500,
				hmfQ: 1.5,
				lpf: 9e3
			}
		},
		fm: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .35,
				brightness: 1,
				velocity: .7,
				lfoRate: 5.5,
				lfoDepth: .12,
				level: .55,
				...ue([
					1,
					0,
					.9,
					.005,
					.8,
					.6,
					.25
				], [
					1,
					0,
					.55,
					.02,
					.4,
					.35,
					.2
				], [
					1,
					9,
					.8,
					.005,
					.8,
					.6,
					.25
				], [
					3,
					0,
					.25,
					.003,
					.25,
					.1,
					.15
				], [
					2,
					-6,
					.35,
					.005,
					.6,
					.4,
					.25
				], [
					1,
					0,
					.35,
					.003,
					.3,
					.15,
					.15
				])
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 2,
				midFreq: 1,
				midGain: 3,
				hfGain: 2,
				drive: 10,
				output: 12
			}
		},
		hookEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lpf: 12e3
			}
		},
		echo: {
			type: "delay",
			params: {
				time: R(126),
				feedback: .38,
				mix: .28
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2.2,
				mix: .22
			}
		},
		drums: {
			type: "boom",
			params: {
				kickTune: 48.6,
				kickDecay: .4,
				snareTone: .6,
				snappy: .75,
				hatDecay: .05,
				hatPan: .25,
				bellPan: -.3,
				level: .85
			},
			lanes: {
				kick: "x...x...x...x...",
				snare: "....x.......x...",
				clap: "....x.......x...",
				rim: "...x.....x...x..",
				hat: "x.x.x.x.x.x.x.x.",
				bell: "..x..x....x..x.."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 4,
				attack: .003,
				release: .15,
				color: 2,
				fierce: 1,
				detectorHp: 1,
				output: 8
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2.5,
				lfFreq: 60,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 400,
				lmfQ: 1.4,
				hmfGain: 3.5,
				hmfFreq: 3800,
				hmfQ: .9,
				lpf: 14e3
			}
		},
		sum: {
			type: "mixer",
			params: {
				a: .8,
				b: .8,
				c: .34,
				aPan: 0,
				bPan: .2,
				cPan: 0
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 1,
				attack: 4,
				release: 1,
				scHpf: 2,
				output: 3
			}
		},
		main: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...B("seq", "bass"),
		...B("hook", "fm"),
		...ve([
			"drums",
			"talon",
			"drumEq"
		], [
			"fm",
			"brit",
			"hookEq",
			"echo",
			"space"
		], ["bass", "console"])
	]);
}
// src/trapPresets.ts
var be = (e, t, n) => ({
	performance: {
		type: "performance",
		steps: e
	},
	oscillator: {
		type: "oscillator",
		params: {
			wave: n.wave,
			octave: n.octave,
			level: 1
		}
	},
	filter: {
		type: "filter",
		params: {
			cutoff: n.cutoff,
			resonance: n.resonance
		}
	},
	amplifier: {
		type: "amplifier",
		params: { level: .8 }
	},
	envelope: {
		type: "envelope",
		params: {
			attack: n.attack,
			decay: n.decay,
			sustain: n.sustain,
			release: n.release
		}
	},
	leadEq: {
		type: "equalizer",
		params: {
			hpf: 300,
			lmfGain: -2,
			lmfFreq: 500,
			lmfQ: 1,
			hmfGain: 2.5,
			hmfFreq: 3e3,
			hmfQ: .9,
			lpf: 12e3
		}
	},
	delay: {
		type: "delay",
		params: {
			time: R(t),
			feedback: .38,
			mix: n.echo
		}
	},
	space: {
		type: "reverb",
		params: {
			decay: 2.6,
			mix: n.space
		}
	},
	echoR: {
		type: "delay",
		params: {
			time: Number((60 / t).toFixed(3)),
			feedback: .35,
			mix: 1
		}
	}
}), xe = [
	[
		"oscillator",
		"out",
		"filter",
		"in"
	],
	[
		"filter",
		"out",
		"amplifier",
		"in"
	],
	[
		"amplifier",
		"out",
		"leadEq",
		"in"
	],
	[
		"leadEq",
		"out",
		"delay",
		"in"
	],
	[
		"delay",
		"out",
		"space",
		"in"
	],
	[
		"leadEq",
		"out2",
		"echoR",
		"in"
	],
	[
		"performance",
		"pitch",
		"oscillator",
		"pitch"
	],
	[
		"performance",
		"gate",
		"envelope",
		"gate"
	],
	[
		"envelope",
		"out",
		"amplifier",
		"cv",
		1
	]
], Se = (e) => ({
	type: "monarch",
	params: {
		osc1Wave: 0,
		osc1Octave: 0,
		osc1Level: .9,
		osc2Wave: 1,
		osc2Octave: 1,
		osc2Detune: 0,
		osc2Level: .15,
		osc3Level: 0,
		cutoff: 1400,
		resonance: 0,
		drive: .5,
		envAmount: .1,
		tracking: .3,
		ampAttack: .003,
		ampDecay: 1.2,
		ampSustain: .7,
		ampRelease: .9,
		glide: .03,
		level: .4,
		...e
	}
}), Ce = {
	grit: {
		type: "rust",
		params: {
			mode: 0,
			drive: .45,
			bias: .1,
			body: 500,
			tone: .45,
			mix: .3,
			level: .4
		}
	},
	subEq: {
		type: "equalizer",
		params: {
			hpf: 30,
			lmfGain: -3,
			lmfFreq: 250,
			lmfQ: .8,
			hmfGain: 4,
			hmfFreq: 1200,
			hmfQ: 1,
			lpf: 6e3
		}
	}
}, we = (e, t, n = {}) => ({
	type: "skitter",
	lanes: e,
	params: {
		...n,
		...Object.fromEntries(Object.entries(t).flatMap(([e, t]) => Object.entries(t).map(([t, n]) => [`${e}Roll${t}`, ce(n)])))
	}
}), Te = (e, t) => ({
	type: "boom",
	lanes: e,
	params: {
		kickTune: 49,
		kickDecay: .55,
		snareTone: .35,
		snappy: .55,
		hatDecay: .045,
		openDecay: .35,
		level: .85,
		...t
	}
}), H = {
	type: "talon",
	params: {
		input: 4,
		ratio: 3,
		attack: .008,
		release: .12,
		color: 1,
		detectorHp: 1,
		output: 7
	}
}, Ee = {
	cohere: {
		type: "cohere",
		params: {
			threshold: -18,
			ratio: 1,
			attack: 4,
			release: 4,
			scHpf: 2,
			output: 5.5
		}
	},
	output: {
		type: "output",
		params: { volume: .7 }
	}
};
function De(e) {
	return e === "High Dive" ? z(e, 76, 0, {
		...be(I("X.x.x..x..x.x...", [
			76,
			76,
			74,
			74,
			72,
			72,
			72,
			69,
			69,
			69,
			72,
			72,
			76,
			76,
			76,
			76
		], [
			.6,
			.6,
			.6,
			.6,
			.8,
			.8,
			.8,
			.9,
			.9,
			.9,
			.6,
			.6,
			.9,
			.9,
			.9,
			.9
		]), 76, {
			wave: 1,
			octave: 0,
			cutoff: 2600,
			resonance: 2,
			attack: .002,
			decay: .5,
			sustain: .15,
			release: .45,
			echo: .3,
			space: .35
		}),
		chords: {
			type: "performance",
			steps: I("X.......X.......", L([60, 8], [65, 8]), .95)
		},
		aurora: {
			type: "aurora",
			params: {
				osc1Wave: 0,
				osc2Wave: 2,
				osc2Detune: 4,
				blend: .45,
				hpf: 250,
				cutoff: 2200,
				resonance: .1,
				envAmount: .15,
				filterAttack: .2,
				filterDecay: 1.4,
				filterSustain: .5,
				ampAttack: .25,
				ampDecay: 1.2,
				ampSustain: .75,
				ampRelease: 1.8,
				lfoRate: .3,
				lfoPitch: 0,
				lfoWidth: .25,
				chord: 1,
				vintage: .3,
				level: .55
			}
		},
		bass: {
			type: "performance",
			steps: I("X.....x...X.....", L([33, 8], [29, 8]), [
				.95,
				.6,
				.6,
				.6,
				.6,
				.6,
				.7,
				.6,
				.6,
				.6,
				.95,
				.6,
				.6,
				.6,
				.6,
				.6
			])
		},
		monarch: Se({ level: .3 }),
		...Ce,
		skitter: we({
			hat: "x.x.x.x.x.x.xx.x",
			open: "..............x."
		}, { hat: { 2: "............xx.x" } }),
		boom: Te({
			kick: "x.....x...x.....",
			snare: "....x.......x...",
			clap: "....x.......x..."
		}, {
			kickDecay: .45,
			snareTone: .5,
			snappy: .7
		}),
		console: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2.5,
				lfFreq: 60,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 400,
				lmfQ: 1.4,
				hmfGain: 4,
				hmfFreq: 3800,
				hmfQ: .9,
				hfGain: 1.5,
				hfFreq: 1e4,
				lpf: 15e3,
				output: 3.5
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: .75,
				c: .95,
				d: .8,
				e: .5,
				aPan: 0,
				bPan: 0,
				cPan: -.25,
				dPan: .2,
				ePan: .7
			}
		},
		valve: {
			type: "compressor",
			params: {
				input: 0,
				threshold: -20,
				time: 2,
				output: 2.5
			}
		},
		output: Ee.output
	}, [
		...xe,
		...B("chords", "aurora"),
		...B("bass", "monarch"),
		[
			"skitter",
			"trig",
			"boom",
			"trig"
		],
		...pe([
			["boom", "console"],
			[
				"monarch",
				"grit",
				"subEq"
			],
			["space"],
			["aurora"],
			["echoR"]
		], "mixer", "valve", "output")
	]) : e === "Deep End" ? z(e, 64, .04, {
		performance: {
			type: "performance",
			steps: I("..X.......x.x...", L([74, 10], [75, 2], [74, 4]), [
				.9,
				.9,
				.95,
				.9,
				.9,
				.9,
				.9,
				.9,
				.9,
				.9,
				.9,
				.9,
				.95,
				.9,
				.9,
				.9
			])
		},
		lead: {
			type: "monarch",
			params: {
				osc1Wave: 0,
				osc1Octave: 0,
				osc1Level: .8,
				osc2Wave: 1,
				osc2Octave: 0,
				osc2Detune: 7,
				osc2Level: .25,
				osc3Level: 0,
				cutoff: 2800,
				resonance: 0,
				drive: 0,
				envAmount: 0,
				tracking: .5,
				ampAttack: .012,
				ampDecay: 1.2,
				ampSustain: .4,
				ampRelease: 1.4,
				glide: .18,
				level: .75
			}
		},
		leadEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lmfGain: -2,
				lmfFreq: 500,
				lmfQ: 1,
				hmfGain: 2.5,
				hmfFreq: 2800,
				hmfQ: .9,
				lpf: 1e4,
				output: 2
			}
		},
		delay: {
			type: "delay",
			params: {
				time: R(64),
				feedback: .45,
				mix: .32
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 3,
				mix: .42
			}
		},
		echoR: {
			type: "delay",
			params: {
				time: Number((60 / 64).toFixed(3)),
				feedback: .4,
				mix: 1
			}
		},
		bass: {
			type: "performance",
			steps: I("X.........x...x.", L([31, 10], [27, 4], [30, 2]), [
				.95,
				.6,
				.6,
				.6,
				.6,
				.6,
				.6,
				.6,
				.6,
				.6,
				.95,
				.6,
				.6,
				.6,
				.7,
				.6
			])
		},
		monarch: Se({
			drive: .6,
			glide: .04,
			ampDecay: 1.6,
			ampRelease: 1.4,
			level: .28
		}),
		...Ce,
		skitter: we({
			hat: "x.x.x.x.x.x.x.xx",
			perc: "...........x...."
		}, { hat: {
			2: "...............x",
			3: "......x.........",
			4: "..........x.....",
			6: "..............x."
		} }, { rollFade: .4 }),
		boom: Te({
			kick: "x.........x.....",
			snare: "....x.......x...",
			clap: "....x.......x..."
		}, {
			kickDecay: .6,
			snareTone: .25,
			snappy: .45
		}),
		drumComp: H,
		console: {
			type: "equalizer",
			params: {
				hpf: 35,
				lfGain: 2.5,
				lfFreq: 55,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 350,
				lmfQ: 1.2,
				hmfGain: 3.5,
				hmfFreq: 3500,
				hmfQ: .9,
				lpf: 12e3
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: .75,
				c: 1,
				d: .5,
				aPan: 0,
				bPan: 0,
				cPan: -.2,
				dPan: .7
			}
		},
		valve: {
			type: "compressor",
			params: {
				input: 0,
				threshold: -20,
				time: 2,
				output: 1.8
			}
		},
		output: Ee.output
	}, [
		...B("performance", "lead"),
		...B("bass", "monarch"),
		[
			"skitter",
			"trig",
			"boom",
			"trig"
		],
		[
			"leadEq",
			"out2",
			"echoR",
			"in"
		],
		...pe([
			[
				"boom",
				"drumComp",
				"console"
			],
			[
				"monarch",
				"grit",
				"subEq"
			],
			[
				"lead",
				"leadEq",
				"delay",
				"space"
			],
			["echoR"]
		], "mixer", "valve", "output")
	]) : z(e, 72, .05, {
		...be(I("X...x.x.X...x...", L([71, 4], [67, 2], [69, 2], [71, 4], [74, 4]), .9), 72, {
			wave: 0,
			octave: 0,
			cutoff: 3200,
			resonance: 1,
			attack: .02,
			decay: .8,
			sustain: .5,
			release: .6,
			echo: .25,
			space: .4
		}),
		chords: {
			type: "performance",
			steps: I("X.....x.X.....x.", L([55, 8], [48, 8]), [
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.7,
				.5,
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.7,
				.5
			])
		},
		oracle: {
			type: "oracle",
			params: {
				aShape: 0,
				aLevel: .6,
				bShape: 1,
				bFine: 4,
				bLevel: .7,
				cutoff: 2600,
				resonance: .1,
				envAmount: .35,
				tracking: .5,
				filterAttack: .002,
				filterDecay: .35,
				filterSustain: .1,
				ampAttack: .003,
				ampDecay: .9,
				ampSustain: .15,
				ampRelease: .8,
				vintage: .35,
				chord: 3,
				level: .75
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 140,
				lmfGain: -4,
				lmfFreq: 320,
				lmfQ: 1.1,
				hmfGain: 2.5,
				hmfFreq: 2500,
				hmfQ: .8,
				hfGain: 2.5,
				hfFreq: 1e4,
				output: 1
			}
		},
		glint: {
			type: "performance",
			steps: I("..x.......x...x.", [
				86,
				86,
				86,
				86,
				86,
				86,
				86,
				86,
				88,
				88,
				88,
				88,
				83,
				83,
				83,
				83
			], .9)
		},
		pluck: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: 0,
				brightness: .7,
				velocity: .5,
				level: 1,
				...de.pluck
			}
		},
		pluckEq: {
			type: "equalizer",
			params: {
				hpf: 350,
				hmfGain: -2,
				hmfFreq: 4e3,
				hmfQ: 1,
				lpf: 1e4,
				output: 10
			}
		},
		pluckEcho: {
			type: "delay",
			params: {
				time: R(72),
				feedback: .35,
				mix: .35
			}
		},
		bass: {
			type: "performance",
			steps: I("X.......X.......", L([31, 8], [36, 8]), .5)
		},
		monarch: Se({
			ampRelease: .6,
			level: .3
		}),
		...Ce,
		skitter: we({
			hat: "x.xxx.x.x.xxx.x.",
			open: ".......x........",
			synth: "x......x..x...x."
		}, {
			hat: { 3: "...x.......x...." },
			synth: { 2: "..............x." }
		}, { gate: .7 }),
		boom: Te({
			kick: "x......x..x.....",
			snare: "....x.......x..."
		}, {
			kickDecay: .5,
			snareTone: .3,
			snappy: .5
		}),
		drumComp: H,
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2.5,
				lfFreq: 60,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 400,
				lmfQ: 1.4,
				hmfGain: 3.5,
				hmfFreq: 3500,
				hmfQ: .9,
				lpf: 13e3
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: .62,
				c: .8,
				d: .9,
				e: .45,
				f: .5,
				aPan: 0,
				bPan: 0,
				cPan: -.2,
				dPan: .25,
				ePan: .7,
				fPan: -.5
			}
		},
		...Ee
	}, [
		...xe,
		...B("chords", "oracle"),
		...B("glint", "pluck"),
		[
			"bass",
			"pitch",
			"monarch",
			"pitch"
		],
		[
			"skitter",
			"trig",
			"boom",
			"trig"
		],
		[
			"skitter",
			"gate",
			"monarch",
			"gate"
		],
		...pe([
			[
				"boom",
				"drumComp",
				"drumEq"
			],
			[
				"monarch",
				"grit",
				"subEq"
			],
			["space"],
			["oracle", "console"],
			["echoR"],
			[
				"pluck",
				"pluckEq",
				"pluckEcho"
			]
		], "mixer", "cohere", "output")
	]);
}
// src/industrialPresets.ts
var Oe = (e, t, n, r, i, a) => ({
	[`riff${e}`]: {
		type: "performance",
		steps: t,
		params: { lag: n }
	},
	[`gtr${e}`]: {
		type: "monarch",
		params: r
	},
	[`fuzz${e}`]: {
		type: "rust",
		params: i
	},
	[`eq${e}`]: {
		type: "equalizer",
		params: a
	}
});
function ke(e) {
	if (e === "Rust Machine") return z(e, 93, .08, {
		seq: {
			type: "performance",
			steps: I("X.xX.xx.X.xX.xxo", [
				41,
				41,
				41,
				53,
				53,
				41,
				44,
				44,
				46,
				46,
				46,
				48,
				48,
				51,
				48,
				44
			], [
				.85,
				.7,
				.7,
				.6,
				.7,
				.7,
				.7,
				.7,
				.85,
				.7,
				.7,
				.6,
				.7,
				.7,
				.7,
				.6
			])
		},
		bass: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Wave: 3,
				osc2Detune: 6,
				osc2Level: .4,
				osc3Wave: 0,
				osc3Octave: -1,
				osc3Level: .45,
				cutoff: 480,
				resonance: .6,
				drive: .4,
				envAmount: .7,
				tracking: .5,
				filterAttack: .002,
				filterDecay: .14,
				filterSustain: .12,
				filterRelease: .06,
				ampAttack: .002,
				ampDecay: .25,
				ampSustain: .7,
				ampRelease: .05,
				glide: .006,
				level: .75
			}
		},
		fuzz: {
			type: "rust",
			params: {
				mode: 0,
				drive: .35,
				bias: .15,
				body: 600,
				tone: .5,
				mix: .35,
				level: .6
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 35,
				lfGain: 1.5,
				lfFreq: 80,
				lfBell: 1,
				lmfGain: -6,
				lmfFreq: 250,
				lmfQ: .8,
				hmfGain: 5,
				hmfFreq: 1300,
				hmfQ: 1.1,
				lpf: 7e3
			}
		},
		chops: {
			type: "performance",
			steps: I("..x..X..x..x.X..", L([65, 8], [70, 8]), .25)
		},
		guitar: {
			type: "oracle",
			params: {
				aShape: 1,
				aWidth: .3,
				bShape: 2,
				bFine: 4,
				bLevel: .5,
				cutoff: 3400,
				resonance: .1,
				envAmount: .3,
				filterDecay: .1,
				filterSustain: 0,
				ampAttack: .002,
				ampDecay: .12,
				ampSustain: 0,
				ampRelease: .06,
				chord: 2,
				vintage: .25,
				level: .9
			}
		},
		guitarEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lmfGain: -3,
				lmfFreq: 600,
				lmfQ: 1.2,
				hmfGain: 3,
				hmfFreq: 2500,
				hmfQ: 1,
				hfGain: 2,
				hfFreq: 9e3,
				output: 2
			}
		},
		echo: {
			type: "delay",
			params: {
				time: R(93),
				feedback: .25,
				mix: .18
			}
		},
		echoR: {
			type: "delay",
			params: {
				time: Number((60 / 93).toFixed(3)),
				feedback: .3,
				mix: 1
			}
		},
		pad: {
			type: "performance",
			steps: I("X.......X.......", L([65, 8], [58, 8]), .95)
		},
		aurora: {
			type: "aurora",
			params: {
				osc1Wave: 0,
				osc2Wave: 1,
				osc2Detune: 9,
				blend: .45,
				hpf: 150,
				cutoff: 1400,
				resonance: .15,
				envAmount: .1,
				filterAttack: .4,
				filterDecay: 1.6,
				filterSustain: .6,
				ampAttack: .6,
				ampDecay: 1.5,
				ampSustain: .8,
				ampRelease: 2.4,
				lfoRate: .2,
				lfoWidth: .35,
				lfoFilter: .05,
				chord: 4,
				vintage: .5,
				level: .7
			}
		},
		padEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lmfGain: -3,
				lmfFreq: 450,
				lmfQ: 1,
				hmfGain: 2,
				hmfFreq: 2800,
				hmfQ: 1,
				lpf: 8e3,
				output: 5
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2.6,
				mix: .4
			}
		},
		lead: {
			type: "performance",
			steps: I("X.......x...x...", L([65, 8], [63, 4], [60, 4]), .9)
		},
		power: {
			type: "monarch",
			params: {
				osc1Level: .7,
				osc2Detune: 12,
				osc2Level: .6,
				osc3Wave: 3,
				osc3Octave: -1,
				osc3Level: .25,
				cutoff: 2200,
				resonance: .2,
				drive: .6,
				envAmount: .2,
				filterDecay: .4,
				filterSustain: .6,
				ampAttack: .01,
				ampDecay: .4,
				ampSustain: .8,
				ampRelease: .2,
				glide: .02,
				level: .45
			}
		},
		grind: {
			type: "rust",
			params: {
				mode: 1,
				drive: .6,
				bias: .2,
				starve: .2,
				body: 900,
				tone: .5,
				mix: .85,
				level: .4
			}
		},
		forge: {
			type: "forge",
			params: {
				level: .9,
				drive: .3,
				room: .08,
				kickLevel: 1.2,
				kickDecay: .45,
				kickTone: .7,
				snareLevel: 1.1,
				snareDecay: .3,
				snareTone: .65,
				snareLag: 8,
				hatLevel: .45,
				hatDecay: .05,
				hatPan: .25,
				hatLag: -3,
				openLevel: .4,
				openPan: .25,
				openLag: -3,
				anvilLevel: .3,
				anvilPan: -.4
			},
			lanes: {
				kick: "x.....x...x..x..",
				snare: "....x.......x...",
				hat: "xxxxxxxxxxx.xxxx",
				open: "...........x....",
				anvil: "..............x."
			}
		},
		drumComp: {
			type: "talon",
			params: {
				input: 4,
				ratio: 3,
				attack: .008,
				release: .12,
				color: 1,
				detectorHp: 1,
				output: 5
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 3,
				lfFreq: 65,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 400,
				lmfQ: 1.4,
				hmfGain: 4.5,
				hmfFreq: 3800,
				hmfQ: .9,
				lpf: 14e3
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: .8,
				c: .9,
				d: .9,
				e: .6,
				f: .55,
				aPan: 0,
				bPan: 0,
				cPan: -.5,
				dPan: .4,
				ePan: 0,
				fPan: .75
			}
		},
		valve: {
			type: "compressor",
			params: {
				input: 1,
				threshold: -18,
				time: 1,
				output: 0
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...B("seq", "bass"),
		...B("chops", "guitar"),
		...B("pad", "aurora"),
		...B("lead", "power"),
		[
			"guitarEq",
			"out2",
			"echoR",
			"in"
		],
		...pe([
			[
				"forge",
				"drumComp",
				"drumEq"
			],
			[
				"bass",
				"fuzz",
				"bassEq"
			],
			[
				"guitar",
				"guitarEq",
				"echo"
			],
			[
				"aurora",
				"padEq",
				"space"
			],
			["power", "grind"],
			["echoR"]
		], "mixer", "valve", "output")
	]);
	if (e === "Black Mass") {
		let t = I("X.....oxX..xX.x.", [
			37,
			37,
			37,
			37,
			37,
			37,
			37,
			40,
			43,
			43,
			43,
			42,
			38,
			38,
			36,
			36
		], [
			.95,
			.5,
			.5,
			.5,
			.5,
			.5,
			.4,
			.6,
			.95,
			.5,
			.5,
			.6,
			.95,
			.5,
			.8,
			.5
		]), n = {
			osc1Wave: 2,
			osc1Level: .8,
			osc2Wave: 2,
			osc2Level: .6,
			osc3Octave: -1,
			osc3Level: .45,
			cutoff: 1500,
			resonance: .08,
			drive: .7,
			envAmount: .2,
			filterAttack: .003,
			filterDecay: .5,
			filterSustain: .5,
			filterRelease: .6,
			ampAttack: .004,
			ampDecay: .8,
			ampSustain: .7,
			ampRelease: 1.1,
			glide: .04,
			level: .6
		};
		return z(e, 76, .04, {
			...Oe("L", t, 6, {
				...n,
				osc2Detune: -8,
				osc3Wave: 3
			}, {
				mode: 0,
				drive: .8,
				bias: .25,
				starve: .15,
				body: 200,
				tone: .36,
				mix: 1,
				level: .55
			}, {
				hpf: 105,
				lfGain: 1.5,
				lfFreq: 170,
				lfBell: 1,
				lmfGain: -5.5,
				lmfFreq: 380,
				lmfQ: 1.1,
				hmfGain: 4,
				hmfFreq: 1600,
				hmfQ: 1.1,
				lpf: 6500
			}),
			...Oe("R", t, 14, {
				...n,
				osc1Detune: -4,
				osc2Wave: 3,
				osc2Detune: 11,
				osc3Wave: 2,
				cutoff: 1350,
				drive: .75,
				glide: .05
			}, {
				mode: 0,
				drive: .78,
				bias: .4,
				starve: .12,
				body: 320,
				tone: .33,
				mix: 1,
				level: .55
			}, {
				hpf: 110,
				lfGain: 1.5,
				lfFreq: 150,
				lfBell: 1,
				lmfGain: -5.5,
				lmfFreq: 330,
				lmfQ: 1.1,
				hmfGain: 4,
				hmfFreq: 2200,
				hmfQ: 1.1,
				lpf: 6e3
			}),
			sub: {
				type: "monarch",
				params: {
					osc1Wave: 0,
					osc1Level: .9,
					osc2Wave: 1,
					osc2Octave: 1,
					osc2Detune: 0,
					osc2Level: .1,
					osc3Level: 0,
					cutoff: 600,
					resonance: 0,
					drive: .5,
					envAmount: .1,
					tracking: .3,
					ampAttack: .004,
					ampDecay: 1.4,
					ampSustain: .75,
					ampRelease: 1,
					glide: .05,
					level: .45
				}
			},
			lead: {
				type: "performance",
				steps: I("....X.......x.x.", L([68, 12], [69, 2], [67, 2]), .95)
			},
			voice: {
				type: "monarch",
				params: {
					osc1Wave: 0,
					osc1Level: .8,
					osc2Wave: 2,
					osc2Detune: 7,
					osc2Level: .15,
					osc3Level: 0,
					cutoff: 1800,
					resonance: 0,
					drive: 0,
					envAmount: 0,
					tracking: .5,
					ampAttack: .03,
					ampDecay: 1.4,
					ampSustain: .45,
					ampRelease: 1.8,
					glide: .22,
					level: 1
				}
			},
			voiceEq: {
				type: "equalizer",
				params: {
					hpf: 300,
					lmfGain: -2,
					lmfFreq: 500,
					lmfQ: 1,
					hmfGain: 2,
					hmfFreq: 2500,
					hmfQ: 1,
					lpf: 9e3,
					output: 4
				}
			},
			echo: {
				type: "delay",
				params: {
					time: R(76),
					feedback: .5,
					mix: .32
				}
			},
			space: {
				type: "reverb",
				params: {
					decay: 3,
					mix: .45
				}
			},
			echoR: {
				type: "delay",
				params: {
					time: Number((60 / 76).toFixed(3)),
					feedback: .42,
					mix: 1
				}
			},
			boom: {
				type: "boom",
				lanes: {
					kick: "x.......x.x....x",
					snare: "....x.......x...",
					clap: "....x.......x..."
				},
				params: {
					kickTune: 44,
					kickDecay: .7,
					kickLevel: 1.6,
					snareTune: -5,
					snareDecay: .45,
					snareTone: .6,
					snappy: .9,
					snareLevel: 1.6,
					snarePan: .1,
					snareLag: 12,
					clapTone: .55,
					clapDecay: .45,
					clapLevel: 1.4,
					clapPan: -.1,
					clapLag: 17,
					level: 1
				}
			},
			forge: {
				type: "forge",
				params: {
					level: 1,
					drive: .55,
					room: .5,
					kickTune: -1,
					kickDecay: .6,
					kickTone: .7,
					kickLevel: 1.6,
					snareTune: -4,
					snareDecay: .9,
					snareTone: .85,
					snareLevel: 1.6,
					snareLag: 12,
					hatLevel: .35,
					hatDecay: .06,
					hatTone: .4,
					hatPan: .3,
					hatLag: -6,
					lowTomTune: -5,
					lowTomDecay: 1.2,
					lowTomLevel: 1.3,
					lowTomPan: .4,
					lowTomLag: 8,
					anvilTune: -10,
					anvilDecay: 2.5,
					anvilTone: .35,
					anvilLevel: .35,
					anvilPan: -.55,
					anvilLag: 20
				},
				lanes: {
					kick: "x.......x.x....x",
					snare: "....x.......x...",
					hat: "x.xxx.xxx.xxx.xx",
					lowTom: "......x.......x.",
					anvil: "...........x...."
				}
			},
			drumComp: {
				type: "talon",
				params: {
					input: 4,
					ratio: 4,
					attack: .01,
					release: .15,
					color: 2,
					detectorHp: 1,
					output: 7.5
				}
			},
			drumEq: {
				type: "equalizer",
				params: {
					hpf: 30,
					lfGain: 3.5,
					lfFreq: 68,
					lfBell: 1,
					lmfGain: -4.5,
					lmfFreq: 380,
					lmfQ: 1.4,
					hmfGain: 5.5,
					hmfFreq: 3400,
					hmfQ: .9,
					lpf: 13e3
				}
			},
			mixer: {
				type: "mixer",
				params: {
					a: 1,
					b: .72,
					c: .72,
					d: .6,
					e: 1,
					f: .75,
					aPan: 0,
					bPan: -.9,
					cPan: .9,
					dPan: 0,
					ePan: -.15,
					fPan: .75
				}
			},
			valve: {
				type: "compressor",
				params: {
					input: 0,
					threshold: -18,
					time: 2,
					output: -3.2
				}
			},
			output: {
				type: "output",
				params: { volume: .7 }
			}
		}, [
			...B("riffL", "gtrL"),
			...B("riffR", "gtrR"),
			...B("riffL", "sub", 2),
			...B("lead", "voice"),
			[
				"voiceEq",
				"out2",
				"echoR",
				"in"
			],
			[
				"boom",
				"out",
				"forge",
				"chain"
			],
			...pe([
				[
					"forge",
					"drumComp",
					"drumEq"
				],
				[
					"gtrL",
					"fuzzL",
					"eqL"
				],
				[
					"gtrR",
					"fuzzR",
					"eqR"
				],
				["sub"],
				[
					"voice",
					"voiceEq",
					"echo",
					"space"
				],
				["echoR"]
			], "mixer", "valve", "output")
		]);
	}
	let t = (e, ...t) => [
		[
			0,
			3,
			120
		],
		[
			3,
			1,
			96
		],
		[
			6,
			1,
			100
		],
		[
			7,
			3,
			116
		],
		[
			10,
			2,
			104
		],
		[
			12,
			2,
			100
		],
		[
			14,
			2,
			108
		]
	].map(([n, r, i], a) => [
		e * 16 + n,
		r,
		t[a],
		i
	]), n = [
		41,
		44,
		48,
		46,
		44,
		43,
		44
	], r = (e, t, ...n) => n.map((n) => [
		e,
		t,
		n,
		100
	]);
	return z(e, 92, .12, {
		tune: {
			type: "dictator",
			params: { length: 2 },
			notes: le(...t(0, ...n), ...t(1, 37, 49, 48, 44, 41, 39, 41), ...t(2, ...n), ...t(3, 39, 46, 49, 48, 46, 43, 40))
		},
		bass: {
			type: "monarch",
			params: {
				osc1Wave: 2,
				osc1Level: .75,
				osc2Wave: 3,
				osc2Detune: 5,
				osc2Level: .35,
				osc3Wave: 0,
				osc3Octave: -1,
				osc3Level: .35,
				cutoff: 750,
				resonance: .3,
				drive: .35,
				envAmount: .45,
				tracking: .6,
				filterAttack: .002,
				filterDecay: .3,
				filterSustain: .3,
				filterRelease: .12,
				ampAttack: .003,
				ampDecay: .5,
				ampSustain: .8,
				ampRelease: .07,
				glide: .006,
				level: .75
			}
		},
		fuzz: {
			type: "rust",
			params: {
				mode: 0,
				drive: .4,
				bias: .2,
				body: 700,
				tone: .5,
				mix: .35,
				level: .6
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 35,
				lfGain: 1.5,
				lfFreq: 80,
				lfBell: 1,
				lmfGain: -6,
				lmfFreq: 250,
				lmfQ: .8,
				hmfGain: 5,
				hmfFreq: 1300,
				hmfQ: 1.1,
				lpf: 7e3
			}
		},
		chords: {
			type: "dictator",
			params: { length: 2 },
			notes: le(...r(0, 16, 65, 68, 72), ...r(16, 16, 65, 68, 73), ...r(32, 16, 65, 68, 72), ...r(48, 12, 63, 67, 70), ...r(60, 4, 64, 67, 72))
		},
		pad: {
			type: "aurora",
			params: {
				osc1Wave: 0,
				osc2Wave: 1,
				osc2Width: .35,
				osc2Detune: 9,
				blend: .5,
				hpf: 220,
				cutoff: 2e3,
				resonance: .1,
				slope: 1,
				envAmount: .2,
				filterAttack: .05,
				filterDecay: 1.2,
				filterSustain: .5,
				filterRelease: 1.2,
				ampAttack: .06,
				ampDecay: 1.5,
				ampSustain: .7,
				ampRelease: 1.4,
				lfoRate: .4,
				lfoWidth: .25,
				vintage: .3,
				level: .8
			}
		},
		padEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lmfGain: -3,
				lmfFreq: 450,
				lmfQ: 1,
				hmfGain: 3,
				hmfFreq: 2800,
				hmfQ: 1,
				lpf: 8e3
			}
		},
		hall: {
			type: "reverb",
			params: {
				decay: 2.6,
				mix: .4
			}
		},
		answer: {
			type: "dictator",
			params: {
				length: 2,
				lag: 6
			},
			notes: le([
				8,
				2,
				72,
				96
			], [
				11,
				4,
				75,
				104
			], [
				24,
				2,
				72,
				96
			], [
				27,
				4,
				77,
				104
			], [
				40,
				2,
				72,
				96
			], [
				43,
				4,
				79,
				108
			], [
				56,
				2,
				70,
				96
			], [
				59,
				4,
				67,
				100
			])
		},
		keys: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .05,
				brightness: 1.1,
				velocity: .5,
				lfoRate: 4.5,
				lfoDepth: .02,
				level: 1,
				...de.epiano
			}
		},
		keysEq: {
			type: "equalizer",
			params: {
				output: 8,
				hpf: 300,
				lmfGain: -2,
				lmfFreq: 500,
				lmfQ: 1,
				hmfGain: 3,
				hmfFreq: 3e3,
				hmfQ: .9,
				lpf: 12e3
			}
		},
		echo: {
			type: "delay",
			params: {
				time: R(92),
				feedback: .42,
				mix: .35
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 3,
				mix: .4
			}
		},
		echoR: {
			type: "delay",
			params: {
				time: Number((60 / 92).toFixed(3)),
				feedback: .38,
				mix: 1
			}
		},
		boom: {
			type: "boom",
			lanes: {
				kick: "x......x..x...x.",
				snare: "....x.......x...",
				clap: "....x.......x...",
				rim: "......x........x"
			},
			params: {
				kickTune: 44,
				kickDecay: .5,
				kickLevel: 1.4,
				snareTune: -2,
				snareDecay: .35,
				snareTone: .65,
				snappy: .9,
				snareLevel: 1.5,
				snarePan: .1,
				snareLag: 14,
				clapTone: .6,
				clapDecay: .35,
				clapLevel: 1.4,
				clapPan: -.12,
				clapLag: 19,
				rimLevel: .5,
				rimPan: -.5,
				rimLag: 10,
				level: 1
			}
		},
		forge: {
			type: "forge",
			params: {
				level: 1,
				drive: .4,
				room: .3,
				kickTune: 0,
				kickDecay: .5,
				kickTone: .7,
				kickLevel: 1.6,
				snareTune: -1,
				snareDecay: .6,
				snareTone: .8,
				snareLevel: 1.6,
				snareLag: 14,
				hatLevel: .45,
				hatDecay: .05,
				hatTone: .5,
				hatPan: .4,
				hatLag: -6
			},
			lanes: {
				kick: "x......x..x...x.",
				snare: "....x.......x...",
				hat: "x.x.x.xxx.x.x.xx"
			}
		},
		drumComp: {
			type: "talon",
			params: {
				input: 4,
				ratio: 3,
				attack: .008,
				release: .12,
				color: 1,
				fierce: 1,
				detectorHp: 1,
				output: 7.5
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2.5,
				lfFreq: 70,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 400,
				lmfQ: 1.4,
				hmfGain: 5,
				hmfFreq: 3800,
				hmfQ: .9,
				lpf: 14e3
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: .85,
				c: .85,
				d: 1,
				e: .8,
				aPan: 0,
				bPan: 0,
				cPan: 0,
				dPan: -.35,
				ePan: .7
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 0,
				attack: 4,
				release: 4,
				scHpf: 2,
				output: 1.5
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...B("tune", "bass"),
		...B("chords", "pad"),
		...B("answer", "keys"),
		[
			"keysEq",
			"out2",
			"echoR",
			"in"
		],
		[
			"boom",
			"out",
			"forge",
			"chain"
		],
		...pe([
			[
				"forge",
				"drumComp",
				"drumEq"
			],
			[
				"bass",
				"fuzz",
				"bassEq"
			],
			[
				"pad",
				"padEq",
				"hall"
			],
			[
				"keys",
				"keysEq",
				"echo",
				"space"
			],
			["echoR"]
		], "mixer", "cohere", "output")
	]);
}
// src/wheels.ts
var U = ["bend", "mod"], Ae = {
	bend: {
		min: -8192,
		max: 8191,
		rest: 0
	},
	mod: {
		min: 0,
		max: 127,
		rest: 0
	}
}, je = {
	bend: "bends",
	mod: "mods"
}, Me = 4096, Ne = 16384;
function Pe(e, t) {
	let { min: n, max: r } = Ae[e];
	return Math.max(n, Math.min(r, Math.round(t)));
}
function Fe(e, t) {
	let n = Pe(e, t);
	return e === "mod" ? n / 127 : n < 0 ? n / 8192 : n / 8191;
}
var Ie = (e, t) => Pe(e, e === "mod" ? t * 127 : t < 0 ? t * 8192 : t * 8191);
function Le(e) {
	let t = /* @__PURE__ */ new Map();
	for (let [n, r] of e) t.delete(n), t.set(n, r);
	return [...t].sort((e, t) => e[0] - t[0]);
}
function Re(e) {
	return e.filter((t, n) => n === 0 || t[1] !== e[n - 1][1]);
}
function ze(e, t) {
	let n = 0, r = e.length;
	for (; n < r;) {
		let i = n + r >> 1;
		e[i][0] < t ? n = i + 1 : r = i;
	}
	return n;
}
var Be = (e, t, n) => e.slice(ze(e, t), ze(e, n));
function Ve(e, t, n) {
	let r = ze(e, n);
	if (!r) return null;
	let i = ze(e, Math.floor(t) + 1);
	return e[(i ? Math.min(i, r) : r) - 1][1];
}
function He(e, t, n, r, i, a) {
	let o = Math.min(n, i), s = Ve(e, o >= i ? 0 : o, i) ?? a, c = e.filter(([e]) => e < t || e >= o), l = r.filter(([e]) => e >= t && e < o), u = o >= i ? 0 : o, d = s === null || [...c, ...l].some(([e]) => e === u) ? [] : [[u, s]];
	return Re(Le([
		...c,
		...l,
		...d
	]));
}
var Ue = (e, t, n) => Re(e.filter(([e]) => e < t || e >= n));
function We(e, t, n, r) {
	let [i, a] = t[0] <= n[0] ? [t, n] : [n, t], o = [];
	for (let t = Math.floor(i[0] / r) * r; t <= a[0]; t += r) {
		let n = a[0] === i[0] ? 1 : Math.max(0, Math.min(1, (t - i[0]) / (a[0] - i[0])));
		o.push([t, Pe(e, i[1] + (a[1] - i[1]) * n)]);
	}
	return o;
}
function Ge(e, t) {
	let n = ze(e, Math.floor(t) + 1);
	return e[Math.max(0, n - 1)][1];
}
function Ke(e, t, n) {
	let r = [...e];
	for (let e of t) {
		if (!e.length) continue;
		let t = e.at(-1)[0] + 1;
		for (let i = Math.max(e[0][0], t - n); i < t;) {
			let a = (i % n + n) % n, o = Math.min(t, i + n - a), s = a + o - i, c = [[a, Ge(e, i)], ...Be(e, i + 1, o).map(([e, t]) => [a + e - i, t])];
			r = He(r, a, s, c, n, null), i = o;
		}
	}
	return r;
}
function qe(e, t, n) {
	return e.flatMap((e) => {
		if (!e.length || e.at(-1)[0] < t || e[0][0] >= n) return [];
		let r = Be(e, t, n);
		return [e[0][0] < t ? [[t, Ge(e, t)], ...r] : r];
	});
}
function Je(e, t) {
	let n = e.at(-1);
	return n ? t[0] - n[0] < 15 && e.length > 1 ? e[e.length - 2][1] === t[1] ? e.slice(0, -1) : [...e.slice(0, -1), [n[0], t[1]]] : n[1] === t[1] ? [...e] : [...e, [Math.max(t[0], n[0]), t[1]]] : [t];
}
function Ye(e, t) {
	let n = Re(Le(e));
	for (let e = 30; n.length > t && e <= v; e *= 2) n = Re(Le(n.map(([t, n]) => [Math.floor(t / e) * e, n])));
	return n.slice(0, t);
}
function Xe(e, t) {
	let n = Ve(e, 0, t), r = Be(e, 0, t);
	return n === null ? [] : Re(Le([[0, n], ...r]));
}
function Ze(e, t, n) {
	let r = Ae[e].rest, i = Be(Le(t), 0, n).map(([t, n]) => [t, Pe(e, n)]);
	return i.some(([, e]) => e !== r) ? Re(Le([[0, r], ...i])) : [];
}
// src/model.ts
var W = (e, t, n, r, i, a = .01, o, s = !1) => ({
	id: e,
	label: t,
	min: n,
	max: r,
	initial: i,
	step: a,
	unit: o,
	logarithmic: s
}), G = (e, t, n, r) => ({
	id: e,
	label: t,
	choices: n,
	initial: r,
	min: 0,
	max: n.length - 1,
	step: 1
}), K = (e, t, n = "audio", r) => ({
	id: e,
	label: t,
	kind: n,
	direction: "in",
	scale: r
}), q = (e, t, n = "audio") => ({
	id: e,
	label: t,
	kind: n,
	direction: "out"
}), J = (e, t = 2) => Array.from({ length: t }, (t, n) => n ? {
	...e,
	id: `${e.id}${n + 1}`,
	copyOf: e.id
} : e), Y = (e) => ({
	...e,
	legacyDefault: e.initial
}), Qe = (e) => ({
	...Y(W(e, "Lag", -50, 50, 0, 1, "ms")),
	hint: "Plays these notes up to 50 ms late, or early when negative, to push or pull the part against the beat. You hear it against the click or the other parts, not on its own. Double-click puts it back on the beat."
}), $e = (e, t) => ({
	...e,
	hint: t
}), et = (e, t) => Y(W("bendRange", "Bend", e, 12, t, 1, "st")), tt = ["filterModel", "engine"], nt = (e) => Y(G(e, "Engine", ["Digital", "Analog"], 1)), rt = (e, t) => ({
	id: `${e}Pattern`,
	label: "Pattern",
	min: 0,
	max: 65535,
	step: 1,
	initial: [...t].reduce((e, t, n) => t === "x" ? e | 1 << n : e, 0),
	pattern: !0,
	voice: e
}), it = (e, t, n, r, i) => [
	{
		...W(`${e}Steps`, `${t} steps`, 1, 16, n, 1),
		voice: e
	},
	{
		...W(`${e}Hits`, `${t} hits`, 0, 16, r, 1),
		voice: e
	},
	{
		...W(`${e}Shift`, `${t} shift`, 0, 15, i, 1),
		voice: e
	}
], at = [
	"Skin",
	"Wood",
	"Sand",
	"Metal",
	"Shaker",
	"Tom"
].map((e) => ({
	id: e.toLowerCase(),
	label: e
})), ot = ({ id: e, label: t }, n) => {
	let [r, i, a] = [
		[
			16,
			5,
			2
		],
		[
			8,
			3,
			0
		],
		[
			12,
			8,
			0
		],
		[
			16,
			0,
			0
		],
		[
			16,
			0,
			0
		],
		[
			16,
			0,
			0
		]
	][n], o = (t) => ({
		...Y(t),
		voice: e
	});
	return [
		...it(e, t, r, i, a).map((e) => n > 2 ? o(e) : e),
		o(W(`${e}Tune`, `${t} tune`, -24, 24, 0, 1, "st")),
		o(W(`${e}Decay`, `${t} decay`, .02, 2, [
			.32,
			.07,
			.07,
			.5,
			.12,
			.4
		][n], .01, "s", !0)),
		o(W(`${e}Tone`, `${t} tone`, 0, 1, .5)),
		o(W(`${e}Level`, `${t} level`, 0, 2, 1)),
		o(W(`${e}Pan`, `${t} pan`, -1, 1, 0)),
		o({
			...Qe(`${e}Lag`),
			label: `${t} lag`
		}),
		o(G(`${e}Custom`, `${t} rhythm`, ["Euclidean", "Custom"], 0)),
		o(rt(e, "................"))
	];
}, st = (e, t) => [
	W(`${e}Attack`, "Attack", .002, 2, .008, .001, "s", !0),
	W(`${e}Decay`, "Decay", .01, 3, .25, .01, "s", !0),
	W(`${e}Sustain`, "Sustain", 0, 1, e === "amp" ? .65 : .2),
	W(`${e}Release`, "Release", .01, 4, .2, .01, "s", !0)
].map((e) => ({
	...e,
	group: t
})), ct = [
	K("chain", "Chain in"),
	K("trig", "Trig in", "gate"),
	...J(q("out", "Drums out"))
], X = (e, t) => t.map((t) => ({
	...t,
	group: e
})), lt = [
	["Off", [0]],
	["Maj 7", [
		0,
		4,
		7,
		11
	]],
	["Min 7", [
		0,
		3,
		7,
		10
	]],
	["Maj 9", [
		0,
		4,
		7,
		11,
		14
	]],
	["Min 9", [
		0,
		3,
		7,
		10,
		14
	]],
	["Min 11", [
		0,
		3,
		10,
		14,
		17
	]],
	["Dom 9", [
		0,
		4,
		7,
		10,
		14
	]]
], ut = [
	["kick", "Kick"],
	["snare", "Snare"],
	["rim", "Sidestick"],
	["clap", "Clap"],
	["hat", "Closed hat"],
	["open", "Open hat"],
	["lowTom", "Low tom"],
	["midTom", "Mid tom"],
	["highTom", "High tom"],
	["lowConga", "Low conga"],
	["highConga", "High conga"],
	["cabasa", "Cabasa"],
	["tambourine", "Tambourine"],
	["bell", "Cowbell"],
	["crash", "Crash"],
	["ride", "Ride"]
].map(([e, t]) => ({
	id: e,
	label: t
})), dt = [
	"Three pairs",
	"Twin stacks",
	"Serial stack",
	"Shared modulation",
	"Branched",
	"Additive"
], ft = [
	"a",
	"b",
	"c",
	"d",
	"e",
	"f",
	"g",
	"h"
], pt = (e) => `${e}Pan`, mt = [
	["kick", "Kick"],
	["snare", "Snare"],
	["clap", "Clap"],
	["hat", "Hat"],
	["open", "Open hat"],
	["perc", "Perc"],
	["synth", "Synth"]
].map(([e, t]) => ({
	id: e,
	label: t
})), ht = {
	boom: {
		kick: "kick",
		snare: "snare",
		clap: "clap",
		hat: "hat",
		open: "open",
		perc: "rim"
	},
	punch: {
		kick: "kick",
		snare: "snare",
		clap: "clap",
		hat: "hat",
		open: "open"
	},
	strike: {
		kick: "kick",
		snare: "snare",
		clap: "clap",
		hat: "hat",
		open: "open",
		perc: "rim"
	},
	forge: {
		kick: "kick",
		snare: "snare",
		hat: "hat",
		open: "open",
		perc: "anvil"
	},
	orbit: {
		kick: "skin",
		snare: "sand",
		clap: "sand",
		hat: "shaker",
		open: "metal",
		perc: "wood"
	}
}, gt = [
	["kick", "Kick"],
	["snare", "Snare"],
	["hat", "Closed hat"],
	["pedal", "Pedal hat"],
	["open", "Open hat"],
	["lowTom", "Floor tom"],
	["highTom", "Rack tom"],
	["crash", "Crash"],
	["china", "China"],
	["ride", "Ride"],
	["anvil", "Anvil"]
].map(([e, t]) => ({
	id: e,
	label: t
})), _t = [
	2,
	3,
	4,
	6
], vt = (e, t) => `${e}Roll${t}`, yt = [
	"Fuzz",
	"Rectify",
	"Fold",
	"Crush",
	"Broken"
], bt = (e, t) => e.flatMap(({ id: e, label: n }) => [
	W(`${e}Tune`, "Tune", -24, 24, 0, 1, "st"),
	W(`${e}Decay`, "Decay", .03, 4, t(e), .01, "s", !0),
	W(`${e}Tone`, "Tone", 0, 1, .7),
	W(`${e}Level`, "Level", 0, 1.6, .8),
	W(`${e}Pan`, "Pan", -1, 1, 0),
	Qe(`${e}Lag`)
].map((t) => ({
	...t,
	voice: e,
	label: `${n} ${t.label}`
}))), xt = [
	["kick", "Kick"],
	["snare", "Snare"],
	["rim", "Rim"],
	["clap", "Clap"],
	["hat", "Hat"],
	["open", "Open"],
	["lowTom", "Lo tom"],
	["highTom", "Hi tom"],
	["crash", "Crash"],
	["ride", "Ride"],
	["bell", "Bell"]
].map(([e, t]) => ({
	id: e,
	label: t
})), St = [
	["kick", "Kick"],
	["snare", "Snare"],
	["clap", "Clap"],
	["hat", "Hat"],
	["open", "Open"]
].map(([e, t]) => ({
	id: e,
	label: t
})), Ct = (e) => e.map(({ id: e, label: t }) => Y({
	...W(`${e}Level`, `${t} level`, 0, 2, 1),
	voice: e
})), wt = (e, t) => e.flatMap(({ id: e, label: n }) => [
	...t[e],
	Y(W(`${e}Pan`, "Pan", -1, 1, 0)),
	Qe(`${e}Lag`)
].map((t) => ({
	...t,
	voice: e,
	label: `${n} ${t.label}`
}))), Tt = (e) => Y(W(e, "Tune", -12, 12, 0, 1, "st")), Et = (e, t, n, r, i = .01) => W(e, "Decay", t, n, r, i, "s", !0), Dt = (e) => Y(W(e, "Tone", 0, 1, .5)), Ot = (e, t) => 2 ** ((e - .5) * t), kt = {
	kick: [W("kickTune", "Tune", 30, 90, 49, 1, "Hz"), W("kickDecay", "Decay", .1, 2.5, .8, .01, "s", !0)],
	snare: [
		Tt("snareTune"),
		Y(Et("snareDecay", .05, 1, .2)),
		W("snareTone", "Tone", 0, 1, .5),
		W("snappy", "Snappy", 0, 1, .6)
	],
	rim: [Tt("rimTune"), Y(Et("rimDecay", .01, .3, .03, .001))],
	clap: [Dt("clapTone"), Y(Et("clapDecay", .05, 1.5, .2))],
	hat: [Et("hatDecay", .02, .6, .06), Dt("hatTone")],
	open: [Y(Et("openDecay", .1, 1.2, .4)), Dt("openTone")],
	lowTom: [Tt("tomTune"), Y(Et("tomDecay", .1, 1.5, .45))],
	highTom: [{
		...Tt("highTomTune"),
		legacyFrom: "tomTune"
	}, {
		...Y(Et("highTomDecay", .1, 1.5, .45)),
		legacyFrom: "tomDecay"
	}],
	crash: [Y(Et("crashDecay", .3, 3, 1.6)), Dt("crashTone")],
	ride: [Y(Et("rideDecay", .2, 2.5, 1)), Dt("rideTone")],
	bell: [W("bellTune", "Tune", -12, 12, 0, 1, "st"), Y(Et("bellDecay", .05, 1.5, .32))]
}, At = {
	kick: [
		W("kickTune", "Tune", 40, 90, 55, 1, "Hz"),
		Et("kickDecay", .1, 1.2, .45),
		W("kickClick", "Click", 0, 1, .5)
	],
	snare: [
		Tt("snareTune"),
		Y(Et("snareDecay", .05, 1, .18)),
		W("snareTone", "Tone", 0, 1, .5),
		W("snappy", "Snappy", 0, 1, .7)
	],
	clap: [Dt("clapTone"), Y(Et("clapDecay", .05, 1.5, .24))],
	hat: [Et("hatDecay", .02, .3, .05), Dt("hatTone")],
	open: [Et("openDecay", .1, 1, .35), Dt("openTone")]
}, Z = {
	performance: {
		name: "STEP–16",
		subtitle: "PATTERN & NOTE CONTROLLER",
		color: "performance",
		params: [Qe("lag")],
		ports: [...J(q("pitch", "Pitch · 1V/oct", "cv"), 3), ...J(q("gate", "Note gate", "gate"), 3)]
	},
	dictator: {
		name: "DICTATOR",
		subtitle: "NOTE RECORDER · LOOPING MIDI CLIP",
		color: "dictator",
		params: [
			$e(G("length", "Length", _.map((e) => `${e} ${e === 1 ? "bar" : "bars"}`), 2), "How many bars the clip loops. Notes past the end stay in the clip, unheard, until it is long enough to play them again."),
			$e(G("quantize", "Quantize", x.map(([e]) => e), 3), "The grid, from quarter notes to 1/32s, that the Quantize button beside it, and AUTO while recording, move note starts onto."),
			$e(G("qrec", "Q-Rec", ["Off", "On"], 0), "AUTO quantizes while recording, as Reason’s Q Record does: on, each note you record starts on the Quantize grid; off, it keeps the timing you played, and the Quantize button can tidy it later."),
			$e(G("mode", "Record", ["Overdub", "Replace"], 0), "Overdub adds what you play to the clip on every pass round the loop. Replace erases the notes the playhead passes while recording, so a new pass takes the place of the old one."),
			Qe("lag")
		],
		ports: [...J(q("pitch", "Pitch · 1V/oct", "cv"), 3), ...J(q("gate", "Note gate", "gate"), 3)]
	},
	oscillator: {
		name: "SOLID",
		subtitle: "ANALOG OSCILLATOR",
		color: "oscillator",
		params: [
			G("wave", "Waveform", [
				"Sine",
				"Triangle",
				"Saw",
				"Square"
			], 2),
			W("octave", "Octave", -3, 3, 0, 1),
			W("tune", "Tune", -12, 12, 0, 1, "st"),
			W("fine", "Fine", -50, 50, 0, 1, "ct"),
			W("level", "Level", 0, 1, .7)
		],
		ports: [
			K("pitch", "Pitch · 1V/oct", "cv", 1200),
			K("fm", "FM", "cv", 1200),
			...J(q("out", "Audio out"))
		]
	},
	noise: {
		name: "STATIC",
		subtitle: "NOISE GENERATOR",
		color: "noise",
		params: [G("color", "Color", [
			"White",
			"Pink",
			"Brown"
		], 0), W("level", "Level", 0, 1, .4)],
		ports: [...J(q("out", "Audio out"))]
	},
	mixer: {
		name: "SUM",
		subtitle: "EIGHT CHANNEL MIXER",
		color: "mixer",
		params: [
			...ft.map((e, t) => {
				let n = W(e, `Channel ${e.toUpperCase()}`, 0, 1, .7);
				return t > 2 ? Y(n) : n;
			}),
			...ft.map((e) => Y(W(pt(e), `Channel ${e.toUpperCase()} pan`, -1, 1, 0))),
			Y(W("master", "Mix bus", 0, 1, 1))
		],
		ports: [...ft.map((e) => K(e, `Channel ${e.toUpperCase()}`)), ...J(q("out", "Mix out"))]
	},
	filter: {
		name: "SIEVE",
		subtitle: "MULTIMODE FILTER",
		color: "filter",
		params: [
			G("mode", "Mode", [
				"Low-pass",
				"High-pass",
				"Band-pass"
			], 0),
			W("cutoff", "Cutoff", 40, 18e3, 1400, 1, "Hz", !0),
			W("resonance", "Resonance", .1, 12, 2.5, .1),
			nt("filterModel")
		],
		ports: [
			K("in", "Audio in"),
			K("cv", "Cutoff CV", "cv", 2400),
			...J(q("out", "Audio out"))
		]
	},
	amplifier: {
		name: "LEVEL",
		subtitle: "VOLTAGE CONTROLLED AMPLIFIER",
		color: "amplifier",
		params: [W("level", "Level", 0, 1, .8)],
		ports: [
			K("in", "Audio in"),
			K("cv", "Amplitude CV", "cv", 1),
			...J(q("out", "Audio out"))
		]
	},
	envelope: {
		name: "CONTOUR",
		subtitle: "ADSR ENVELOPE",
		color: "envelope",
		params: [
			W("attack", "Attack", .002, 2, .01, .001, "s", !0),
			W("decay", "Decay", .01, 3, .2, .01, "s", !0),
			W("sustain", "Sustain", 0, 1, .5),
			W("release", "Release", .01, 4, .18, .01, "s", !0)
		],
		ports: [K("gate", "Note gate", "gate"), ...J(q("out", "Envelope CV", "cv"))]
	},
	lfo: {
		name: "PULSE",
		subtitle: "LOW FREQUENCY OSCILLATOR",
		color: "lfo",
		params: [G("wave", "Waveform", [
			"Sine",
			"Triangle",
			"Saw",
			"Square"
		], 0), W("rate", "Rate", .05, 20, 2, .05, "Hz", !0)],
		ports: [K("cv", "Rate CV", "cv", 5), ...J(q("out", "Modulation CV", "cv"))]
	},
	delay: {
		name: "ECHO",
		subtitle: "FEEDBACK DELAY",
		color: "delay",
		params: [
			W("time", "Time", .02, 1, .28, .01, "s"),
			W("feedback", "Feedback", 0, .85, .32),
			W("mix", "Mix", 0, 1, .22)
		],
		ports: [K("in", "Audio in"), ...J(q("out", "Audio out"))]
	},
	reverb: {
		name: "SPACE",
		subtitle: "STEREO REVERBERATOR",
		color: "reverb",
		params: [W("decay", "Decay", .2, 3, 1.5, .1, "s"), W("mix", "Mix", 0, 1, .25)],
		ports: [K("in", "Audio in"), ...J(q("out", "Audio out"))]
	},
	boom: {
		name: "BOOM",
		subtitle: "ANALOG DRUM MACHINE",
		color: "boom",
		ports: ct,
		drum: {
			mode: "steps",
			voices: xt
		},
		params: [
			...wt(xt, kt),
			W("level", "Level", 0, 1, .8),
			nt("engine"),
			rt("kick", "x......x..x....."),
			rt("snare", "....x.......x..."),
			rt("hat", "x.x.x.x.x.x.x.x."),
			rt("bell", "...........x..x."),
			...[
				"rim",
				"clap",
				"open",
				"lowTom",
				"highTom",
				"crash",
				"ride"
			].map((e) => Y(rt(e, "................"))),
			...Ct(xt)
		]
	},
	punch: {
		name: "PUNCH",
		subtitle: "DANCE FLOOR DRUM MACHINE",
		color: "punch",
		ports: ct,
		drum: {
			mode: "steps",
			voices: St
		},
		params: [
			...wt(St, At),
			W("level", "Level", 0, 1, .8),
			nt("engine"),
			rt("kick", "x...x...x...x..."),
			rt("snare", "............x..x"),
			rt("clap", "....x.......x..."),
			rt("hat", "xx..xx..xx..xx.."),
			rt("open", "..x...x...x...x."),
			...Ct(St)
		]
	},
	orbit: {
		name: "ORBIT",
		subtitle: "EUCLIDEAN PERCUSSION",
		color: "orbit",
		ports: ct,
		drum: {
			mode: "euclid",
			voices: at
		},
		params: [
			W("pitch", "Pitch", -12, 12, 0, 1, "st"),
			W("level", "Level", 0, 1, .7),
			nt("engine"),
			...at.flatMap(ot)
		]
	},
	monarch: {
		name: "MONARCH",
		subtitle: "VINTAGE MONOSYNTH",
		color: "monarch",
		ports: [
			K("pitch", "Pitch · 1V/oct", "cv", 1200),
			K("gate", "Note gate", "gate"),
			K("cv", "Cutoff CV", "cv", 2400),
			...J(q("out", "Audio out"))
		],
		params: [
			...[
				1,
				2,
				3
			].flatMap((e) => [
				G(`osc${e}Wave`, "Waveform", [
					"Sine",
					"Triangle",
					"Saw",
					"Square"
				], 2),
				W(`osc${e}Octave`, "Octave", -3, 3, e === 3 ? -1 : 0, 1),
				W(`osc${e}Detune`, "Detune", -50, 50, e === 2 ? 7 : 0, 1, "ct"),
				W(`osc${e}Level`, "Level", 0, 1, e === 1 ? .7 : .35)
			].map((t) => ({
				...t,
				group: `Oscillator ${e}`
			}))),
			...[
				nt("filterModel"),
				W("cutoff", "Cutoff", 40, 18e3, 1100, 1, "Hz", !0),
				W("resonance", "Resonance", 0, 1, .2),
				W("drive", "Drive", 0, 1, .25),
				W("envAmount", "Env amount", -1, 1, .5),
				W("tracking", "Key track", 0, 1, .5)
			].map((e) => ({
				...e,
				group: "Filter"
			})),
			...st("filter", "Filter envelope"),
			...st("amp", "Amplifier envelope"),
			...[
				W("noise", "Noise", 0, 1, 0),
				W("glide", "Glide", 0, 1, 0, .01, "s"),
				W("level", "Level", 0, 1, .7)
			].map((e) => ({
				...e,
				group: "Performance"
			})),
			...X("Controllers", [
				$e(et(1, 5), "How far the pitch wheel bends the oscillators, up or down. As on a Minimoog, the wheel bends them after Glide, and the filter stays put."),
				$e(Y(W("modMix", "Mod mix", 0, 1, 0)), "What the mod wheel sends, as a Minimoog’s Modulation Mix: Oscillator 3 at the left, noise at the right, a blend of the two between."),
				$e(Y(G("modDest", "Mod to", [
					"Osc",
					"Filter",
					"Both"
				], 0)), "Where the mod wheel sends the Mod mix, as a Minimoog’s Oscillator and Filter Modulation switches do: oscillators 1 and 2’s pitch, the filter’s cutoff, or both."),
				$e(Y(G("osc3Mode", "Osc 3", ["Audio", "LFO"], 0)), "LFO takes Oscillator 3 off the keys and down to a crawl, as a Minimoog’s Osc 3 Control switch and Lo range do, so the mod wheel brings in vibrato or a trill. Its Octave then sets the rate, from about 0.6 Hz to 40 Hz, and its Level still sends it to the mixer, so turn that down to keep it out of the sound. Audio keeps it playing with the keys, and the mod wheel growls.")
			])
		]
	},
	oracle: {
		name: "ORACLE",
		subtitle: "FIVE-VOICE POLYSYNTH",
		color: "oracle",
		ports: [
			K("pitch", "Pitch · 1V/oct", "cv", 1200),
			K("gate", "Note gate", "gate"),
			K("cv", "Cutoff CV", "cv", 2400),
			...J(q("out", "Audio out"))
		],
		params: [
			...X("Poly-Mod", [
				W("polyEnv", "Filt env", 0, 1, 0),
				W("polyOscB", "Osc B", 0, 1, 0),
				G("polyDest", "Dest", [
					"Freq A",
					"Filter",
					"Both"
				], 0)
			]),
			...X("Oscillator A", [
				W("aOctave", "Octave", -2, 2, 0, 1),
				G("aShape", "Shape", [
					"Saw",
					"Pulse",
					"Saw + Pulse"
				], 0),
				W("aWidth", "Width", .05, .95, .5)
			]),
			...X("Oscillator B", [
				W("bOctave", "Octave", -2, 2, 0, 1),
				W("bFine", "Fine", -50, 50, 7, 1, "ct"),
				G("bShape", "Shape", [
					"Saw",
					"Triangle",
					"Pulse"
				], 0),
				W("bWidth", "Width", .05, .95, .5)
			]),
			...X("LFO", [
				W("lfoRate", "Rate", .05, 20, 4, .05, "Hz", !0),
				G("lfoShape", "Shape", [
					"Triangle",
					"Saw",
					"Square"
				], 0),
				$e(W("lfoAmount", "Amount", 0, 1, 0), "How much modulation reaches Dest with the mod wheel down, as a Prophet-5 Rev 4’s LFO initial amount. The mod wheel brings in the rest, up to full."),
				G("lfoDest", "Dest", [
					"Pitch",
					"PW",
					"Filter"
				], 0),
				$e(Y(W("lfoMix", "Source mix", 0, 1, 0)), "What the LFO section sends, as a Prophet-5’s Wheel-Mod Source Mix: the LFO at the left, noise at the right, a blend of the two between.")
			]),
			...X("Mixer", [
				W("aLevel", "Osc A", 0, 1, .8),
				W("bLevel", "Osc B", 0, 1, .6),
				W("noise", "Noise", 0, 1, 0)
			]),
			...X("Filter", [
				nt("filterModel"),
				W("cutoff", "Cutoff", 40, 18e3, 1600, 1, "Hz", !0),
				W("resonance", "Resonance", 0, 1, .15),
				W("envAmount", "Env amount", 0, 1, .4),
				W("tracking", "Key track", 0, 1, .5)
			]),
			...st("filter", "Filter envelope"),
			...st("amp", "Amplifier envelope"),
			...X("Voices", [
				W("glide", "Glide", 0, 1, 0, .01, "s"),
				W("vintage", "Vintage", 0, 1, .3),
				G("chord", "Chord", lt.map(([e]) => e), 0),
				W("level", "Level", 0, 1, .7),
				$e(et(1, 2), "How far the spring-loaded pitch wheel bends oscillators A and B, up or down: from a semitone to an octave, as a Prophet-5 sets it.")
			])
		]
	},
	aurora: {
		name: "AURORA",
		subtitle: "EIGHT-VOICE ANALOG POLYSYNTH",
		color: "aurora",
		ports: [
			K("pitch", "Pitch · 1V/oct", "cv", 1200),
			K("gate", "Note gate", "gate"),
			K("cv", "Cutoff CV", "cv", 2400),
			...J(q("out", "Audio out"))
		],
		params: [
			...[1, 2].flatMap((e) => X(`Oscillator ${e}`, [
				G(`osc${e}Wave`, "Waveform", [
					"Saw",
					"Pulse",
					"Triangle",
					"Sine"
				], e === 1 ? 0 : 1),
				W(`osc${e}Octave`, "Octave", -2, 2, 0, 1),
				W(`osc${e}Detune`, "Detune", -50, 50, e === 2 ? 6 : 0, 1, "ct"),
				W(`osc${e}Width`, "Width", .05, .95, .5)
			])),
			...X("Source mix", [
				W("blend", "Osc 1 / 2", 0, 1, .5),
				W("crossMod", "Cross mod", 0, 1, 0),
				W("hpf", "High-pass", 20, 3e3, 20, 1, "Hz", !0)
			]),
			...X("Filter", [
				nt("filterModel"),
				W("cutoff", "Cutoff", 40, 18e3, 2200, 1, "Hz", !0),
				W("resonance", "Resonance", 0, 1, .15),
				G("slope", "Slope", ["12 dB", "24 dB"], 1),
				W("envAmount", "Env amount", -1, 1, .35),
				W("tracking", "Key track", 0, 1, .5)
			]),
			...st("filter", "Filter envelope"),
			...st("amp", "Amplifier envelope"),
			...X("LFO", [
				W("lfoRate", "Rate", .05, 20, .6, .05, "Hz", !0),
				G("lfoShape", "Waveform", [
					"Triangle",
					"Sine",
					"Square"
				], 0),
				W("lfoPitch", "Pitch", 0, 1, 0),
				W("lfoWidth", "PWM", 0, 1, .15),
				W("lfoFilter", "Filter", 0, 1, 0)
			]),
			...X("Voices", [
				W("glide", "Glide", 0, 1, 0, .01, "s"),
				W("vintage", "Vintage", 0, 1, .25),
				G("chord", "Chord", lt.map(([e]) => e), 0),
				W("level", "Level", 0, 1, .65)
			]),
			...X("Bender", [
				$e({
					...et(0, 2),
					label: "VCO bend"
				}, "How far the pitch wheel bends both oscillators, up or down, as a Jupiter-8’s VCO bend sensitivity."),
				$e(Y(W("bendFilter", "VCF bend", 0, 1, 0)), "How far the pitch wheel moves the cutoff with it, up to two octaves either way, as a Jupiter-8’s VCF bend sensitivity."),
				$e(Y(W("leverLfo", "LFO mod", 0, 1, .5)), "How much LFO vibrato the mod wheel brings in at full, as pushing a Jupiter-8’s bender lever away does at the depth its LFO Mod knob sets. The LFO section sets its rate and shape.")
			])
		]
	},
	strike: {
		name: "STRIKE",
		subtitle: "VINTAGE DIGITAL DRUM MACHINE",
		color: "strike",
		ports: ct,
		drum: {
			mode: "steps",
			voices: ut
		},
		params: [
			W("level", "Level", 0, 1, .8),
			nt("engine"),
			...ut.flatMap(({ id: e, label: t }) => [rt(e, e === "kick" ? "x.......x.x....." : e === "snare" ? "....x.......x..." : e === "hat" ? "x.x.x.x.x.x.x.x." : "................"), ...[
				W(`${e}Tune`, "Tune", -24, 24, 0, 1, "st"),
				W(`${e}Decay`, "Decay", .03, 3, ["crash", "ride"].includes(e) ? 1.8 : e === "open" ? .45 : e === "hat" ? .08 : .35, .01, "s", !0),
				W(`${e}Tone`, "Tone", 0, 1, .7),
				W(`${e}Level`, "Level", 0, 1.6, .8),
				W(`${e}Pan`, "Pan", -1, 1, 0),
				Qe(`${e}Lag`)
			].map((n) => ({
				...n,
				voice: e,
				label: `${t} ${n.label}`
			}))])
		]
	},
	prism: {
		name: "PRISM",
		subtitle: "SIX-OPERATOR FM SYNTH",
		color: "prism",
		ports: [
			K("pitch", "Pitch · 1V/oct", "cv", 1200),
			K("gate", "Note gate", "gate"),
			K("cv", "Brightness CV", "cv", 1),
			...J(q("out", "Audio out"))
		],
		params: [
			...X("Sound", [
				G("algorithm", "Algorithm", dt, 0),
				W("feedback", "Feedback", 0, 1, .08),
				W("brightness", "Brightness", 0, 2, .8),
				W("velocity", "Velocity", 0, 1, .7)
			]),
			...X("Performance", [
				W("lfoRate", "LFO rate", .05, 20, 5, .05, "Hz", !0),
				W("lfoDepth", "Vibrato", 0, 1, 0),
				G("chord", "Chord", lt.map(([e]) => e), 0),
				W("level", "Level", 0, 1, .65),
				$e(et(0, 2), "How far the spring-loaded pitch wheel bends, up or down: up to an octave, as a DX7’s Pitch bend range."),
				$e(Y(W("wheelRange", "Mod range", 0, 1, .5)), "How far the mod wheel reaches at full, as a DX7’s wheel Range, 0 to 99, which leaves the factory at 50."),
				$e(Y(G("wheelAssign", "Mod to", [
					"Pitch",
					"Amp",
					"EG bias"
				], 0)), "What the mod wheel does, as a DX7’s wheel assign: Pitch deepens the LFO’s vibrato, Amp brings in tremolo from it, and EG bias brightens the sound.")
			]),
			...X("Filter", [nt("filterModel"), ...[
				W("filterCutoff", "Cutoff", 40, 18e3, 9e3, 1, "Hz", !0),
				W("filterResonance", "Resonance", 0, 1, .15),
				W("filterDrive", "Drive", 0, 1, .2),
				W("filterEnv", "Env amount", -1, 1, .25),
				W("filterTrack", "Key track", 0, 1, .5)
			].map(Y)]),
			...Array.from({ length: 6 }, (e, t) => {
				let n = `op${t + 1}`;
				return [
					W(`${n}Ratio`, "Ratio", .5, 16, t % 2 ? 2 : 1, .5),
					W(`${n}Detune`, "Detune", -50, 50, 0, 1, "ct"),
					W(`${n}Level`, "Level", 0, 1, t < 2 ? .8 : .4),
					W(`${n}Attack`, "Attack", .002, 2, .005, .001, "s", !0),
					W(`${n}Decay`, "Decay", .01, 3, t % 2 ? .35 : 1.2, .01, "s", !0),
					W(`${n}Sustain`, "Sustain", 0, 1, t % 2 ? .05 : .25),
					W(`${n}Release`, "Release", .01, 4, .25, .01, "s", !0)
				].map((e) => ({
					...e,
					voice: n
				}));
			}).flat()
		]
	},
	compressor: {
		name: "VALVE",
		subtitle: "VARIABLE-MU LIMITER",
		color: "compressor",
		ports: [K("in", "Audio in"), ...J(q("out", "Audio out"))],
		params: [
			W("input", "Input", -12, 18, 0, .5, "dB"),
			W("threshold", "Threshold", -40, 0, -18, .5, "dB"),
			G("time", "Time constant", [
				"1",
				"2",
				"3",
				"4",
				"5",
				"6"
			], 1),
			W("output", "Output", -12, 12, 0, .5, "dB")
		]
	},
	equalizer: {
		name: "CONSOLE",
		subtitle: "FOUR-BAND CHANNEL EQ",
		color: "equalizer",
		ports: [K("in", "Audio in"), ...J(q("out", "Audio out"))],
		params: [
			G("active", "EQ", ["In", "Out"], 0),
			W("output", "Output", -12, 12, 0, .5, "dB"),
			...X("Filters", [W("hpf", "High-pass", 16, 350, 16, 1, "Hz", !0), W("lpf", "Low-pass", 3e3, 22e3, 22e3, 10, "Hz", !0)]),
			...X("LF", [
				W("lfGain", "Gain", -15, 15, 0, .5, "dB"),
				W("lfFreq", "Freq", 30, 450, 100, 1, "Hz", !0),
				G("lfBell", "Shape", ["Shelf", "Bell"], 0)
			]),
			...X("LMF", [
				W("lmfGain", "Gain", -15, 15, 0, .5, "dB"),
				W("lmfFreq", "Freq", 200, 2500, 600, 1, "Hz", !0),
				W("lmfQ", "Q", .5, 4, 1, .1)
			]),
			...X("HMF", [
				W("hmfGain", "Gain", -15, 15, 0, .5, "dB"),
				W("hmfFreq", "Freq", 600, 7e3, 2500, 10, "Hz", !0),
				W("hmfQ", "Q", .5, 4, 1, .1)
			]),
			...X("HF", [
				W("hfGain", "Gain", -15, 15, 0, .5, "dB"),
				W("hfFreq", "Freq", 1500, 16e3, 8e3, 10, "Hz", !0),
				G("hfBell", "Shape", ["Shelf", "Bell"], 0)
			])
		]
	},
	cohere: {
		name: "COHERE",
		subtitle: "STEREO BUS COMPRESSOR",
		color: "cohere",
		ports: [K("in", "Audio in"), ...J(q("out", "Audio out"))],
		params: [...X("Dynamics", [
			W("threshold", "Threshold", -40, 10, -18, .5, "dB"),
			G("ratio", "Ratio", [
				"2:1",
				"4:1",
				"10:1"
			], 1),
			G("attack", "Attack", [
				"0.1 ms",
				"0.3 ms",
				"1 ms",
				"3 ms",
				"10 ms",
				"30 ms"
			], 4),
			G("release", "Release", [
				"0.1 s",
				"0.3 s",
				"0.6 s",
				"1.2 s",
				"Auto"
			], 4)
		]), ...X("Bus", [
			G("scHpf", "Detector HP", [
				"Off",
				"30 Hz",
				"60 Hz",
				"106 Hz",
				"125 Hz",
				"185 Hz"
			], 0),
			W("output", "Makeup", -12, 20, 0, .5, "dB"),
			G("active", "Process", ["In", "Bypass"], 0)
		])]
	},
	talon: {
		name: "TALON",
		subtitle: "HARMONIC DYNAMICS PROCESSOR",
		color: "talon",
		ports: [K("in", "Audio in"), ...J(q("out", "Audio out"))],
		params: [
			...X("Dynamics", [
				W("input", "Input", -12, 30, 0, .5, "dB"),
				G("ratio", "Ratio", [
					"1:1",
					"2:1",
					"3:1",
					"4:1",
					"6:1",
					"10:1 Opto",
					"20:1",
					"Crush"
				], 4),
				W("attack", "Attack", 5e-5, .03, .003, 5e-5, "s", !0),
				W("release", "Release", .05, 3.5, .3, .01, "s", !0)
			]),
			...X("Character", [
				G("color", "Harmonics", [
					"Clean",
					"Even",
					"Odd"
				], 0),
				G("audioHp", "Audio HP", ["Off", "65 Hz"], 0),
				G("fierce", "Fierce", ["Off", "On"], 0)
			]),
			...X("Detector", [
				G("detectorHp", "High-pass", ["Off", "80 Hz"], 0),
				G("detectorBand", "Emphasis", ["Off", "6 kHz"], 0),
				G("link", "Stereo link", ["Off", "On"], 1)
			]),
			...X("Output", [W("output", "Output", -30, 12, 0, .5, "dB"), G("active", "Process", ["In", "Bypass"], 0)])
		]
	},
	brit: {
		name: "BRIT",
		subtitle: "THREE-BAND CLASS A EQUALIZER",
		color: "brit",
		ports: [K("in", "Audio in"), ...J(q("out", "Audio out"))],
		params: [
			...X("Low shelf", [G("lfFreq", "Freq", [
				"35 Hz",
				"60 Hz",
				"110 Hz",
				"220 Hz"
			], 2), W("lfGain", "Gain", -16, 16, 0, .5, "dB")]),
			...X("Mid bell", [G("midFreq", "Freq", [
				"360 Hz",
				"700 Hz",
				"1.6 kHz",
				"3.2 kHz",
				"4.8 kHz",
				"7.2 kHz"
			], 2), W("midGain", "Gain", -18, 18, 0, .5, "dB")]),
			...X("High shelf · 12 kHz", [W("hfGain", "Gain", -16, 16, 0, .5, "dB")]),
			...X("Signal", [
				G("hpf", "High-pass", [
					"Off",
					"50 Hz",
					"80 Hz",
					"160 Hz",
					"300 Hz"
				], 0),
				W("drive", "Drive", 0, 24, 0, .5, "dB"),
				W("output", "Output", -18, 18, 0, .5, "dB"),
				G("active", "Process", ["In", "Bypass"], 0)
			])
		]
	},
	skitter: {
		name: "SKITTER",
		subtitle: "TRAP STEP SEQUENCER · 1/16 · 1/32 · ROLLS",
		color: "skitter",
		ports: [...J(q("trig", "Trig out · drums", "gate")), ...J(q("gate", "Synth gate", "gate"))],
		drum: {
			mode: "steps",
			voices: mt
		},
		params: [
			W("rollFade", "Roll fade", 0, 1, .35),
			W("gate", "Gate", .1, 1, .5),
			...mt.flatMap(({ id: e }) => [rt(e, {
				snare: "....x.......x...",
				hat: "x.x.x.x.x.x.x.x."
			}[e] ?? "................"), ..._t.map((t) => ({
				...rt(e, "................"),
				id: vt(e, t),
				label: `Roll ×${t}`
			}))])
		]
	},
	forge: {
		name: "FORGE",
		subtitle: "INDUSTRIAL DRUM KIT",
		color: "forge",
		ports: ct,
		drum: {
			mode: "steps",
			voices: gt
		},
		params: [
			W("level", "Level", 0, 1, .8),
			nt("engine"),
			W("drive", "Drive", 0, 1, .35),
			W("room", "Room", 0, 1, .2),
			...gt.map(({ id: e }) => rt(e, {
				kick: "x.......x.x.....",
				snare: "....x.......x...",
				hat: "x.x.x.x.x.x.x.x."
			}[e] ?? "................")),
			...bt(gt, (e) => ({
				crash: 2.4,
				china: 1.6,
				ride: 2.6,
				open: .7,
				hat: .09,
				pedal: .12,
				lowTom: .7,
				highTom: .55,
				anvil: 1,
				kick: .5,
				snare: .45
			})[e] ?? .4)
		]
	},
	rust: {
		name: "RUST",
		subtitle: "INDUSTRIAL DISTORTION",
		color: "rust",
		ports: [
			K("in", "Audio in"),
			K("cv", "Drive CV", "cv", 4),
			...J(q("out", "Audio out"))
		],
		params: [
			G("mode", "Mode", yt, 0),
			W("drive", "Drive", 0, 1, .6),
			W("bias", "Bias", 0, 1, .15),
			W("crush", "Bits", 2, 12, 6, 1),
			W("starve", "Starve", 0, 1, 0),
			W("body", "Body", 60, 2e3, 220, 1, "Hz", !0),
			W("tone", "Tone", 0, 1, .55),
			W("mix", "Mix", 0, 1, 1),
			W("level", "Level", 0, 1, .6)
		]
	},
	output: {
		name: "MAIN",
		subtitle: "STEREO MASTER OUTPUT",
		color: "output",
		params: [W("volume", "Master", 0, 1, .65)],
		ports: [K("in", "Audio in")]
	}
}, jt = Object.keys(Z).filter((e) => e !== "output"), Mt = 0, Nt = (e = "module") => `${e}-${Date.now().toString(36)}-${++Mt}`, Pt = (e, t = Nt()) => ({
	id: t,
	type: e,
	params: Object.fromEntries(Z[e].params.map((e) => [e.id, e.initial]))
}), Ft = (e) => Z[e].params.find((e) => tt.includes(e.id)), It = (e) => e === "performance" ? {
	...Pt(e),
	steps: Array.from({ length: 16 }, (e, t) => ({
		enabled: t % 4 == 0,
		note: 48,
		velocity: .8,
		gate: .5
	}))
} : e === "dictator" ? {
	...Pt(e),
	notes: []
} : Pt(e), Lt = (e, t) => e.modules.find((e) => e.id === t)?.type === "output", Rt = (e, t) => e.modules[0].id === t ? e.sequencer.steps : e.modules.find((e) => e.id === t)?.steps ?? e.sequencer.steps;
function zt(e, t, n) {
	return e.modules[0].id === t ? {
		...e,
		sequencer: {
			...e.sequencer,
			steps: n
		}
	} : {
		...e,
		modules: e.modules.map((e) => e.id === t ? {
			...e,
			steps: n
		} : e)
	};
}
function Bt(e, t, n = e.cables) {
	let r = (t) => e.modules.some((e) => e.id === t.id) ? Rt(e, t.id) : t.steps ?? e.sequencer.steps, i = t[0]?.type === "performance" ? r(t[0]) : e.sequencer.steps;
	return {
		...e,
		cables: n,
		sequencer: i === e.sequencer.steps ? e.sequencer : {
			...e.sequencer,
			steps: i
		},
		modules: t.map((e, t) => e.type === "performance" ? t === 0 ? e.steps ? {
			id: e.id,
			type: e.type,
			params: e.params
		} : e : e.steps ? e : {
			...e,
			steps: r(e)
		} : e)
	};
}
var Vt = (e) => e.modules.find((e) => En(e.type)) ?? e.modules[0], Ht = (e, t) => e.modules.find((e) => e.id === t)?.notes ?? [], Ut = (e, t) => Math.max(0, Math.min(y, b - e.modules.reduce((e, n) => e + (n.id === t ? 0 : n.notes?.length ?? 0), 0))), Wt = (e, t, n) => {
	let r = Ut(e, t);
	return {
		...e,
		modules: e.modules.map((e) => e.id === t ? {
			...e,
			notes: n.length > r ? n.slice(0, r) : n
		} : e)
	};
}, Gt = (e, t) => e?.[je[t]] ?? [], Kt = (e, t, n) => Math.max(0, Math.min(Me, Ne - e.modules.reduce((e, r) => e + U.reduce((e, i) => e + (r.id === t && i === n ? 0 : Gt(r, i).length), 0), 0)));
function qt(e, t, n, r) {
	let i = Ye(r, Kt(e, t, n)), a = je[n];
	return {
		...e,
		modules: e.modules.map((e) => {
			if (e.id !== t) return e;
			let n = { ...e };
			return i.length ? n[a] = i : delete n[a], n;
		})
	};
}
function Jt(e, t, n) {
	let r = e.modules.find((e) => e.id === t);
	return r ? U.reduce((e, i) => n[i]?.length ? qt(e, t, i, Ke(Gt(r, i), n[i], C(r.params.length))) : e, e) : e;
}
var Yt = [
	"monarch",
	"oracle",
	"aurora",
	"prism"
], Xt = (e) => Yt.includes(e);
function Zt(e, t) {
	let n = e.modules.find((e) => e.id === t);
	if (!n) return [];
	if (Xt(n.type)) return [n.id];
	if (!kn(n.type)) return [];
	let r = new Set(e.cables.filter((t) => t.from.moduleId === n.id && rn(e, t.from)?.kind === "gate").map((e) => e.to.moduleId));
	return e.modules.filter((e) => r.has(e.id) && Xt(e.type)).map((e) => e.id);
}
var Qt = (e) => Z[e].ports.some((e) => e.id === "trig" && e.direction === "in");
function $t(e, t, n) {
	let r = Qt(e.modules.find((e) => e.id === n).type), i = [
		{
			moduleId: t,
			portId: "pitch"
		},
		{
			moduleId: t,
			portId: "gate"
		},
		{
			moduleId: n,
			portId: r ? "trig" : "pitch"
		},
		...r ? [] : [{
			moduleId: n,
			portId: "gate"
		}]
	], a = {
		...e,
		cables: e.cables.filter((e) => !i.some((t) => an(e.from, t) || an(e.to, t)))
	};
	return r ? ln(a, i[1], i[2]) : ln(ln(a, i[0], i[2]), i[1], i[3]);
}
function en(e, t) {
	let n = sn(e, {
		moduleId: t,
		portId: "pitch"
	}), r = sn(e, {
		moduleId: t,
		portId: "gate"
	});
	return !n && !r ? null : !n && r?.to.portId === "trig" || n && r && n.to.moduleId === r.to.moduleId && n.to.portId === "pitch" && r.to.portId === "gate" ? r.to.moduleId : "";
}
function tn(e, t) {
	let n = e.cables.filter((n) => n.from.moduleId === t && rn(e, n.from)?.kind === "gate").map((t) => e.modules.find((e) => e.id === t.to.moduleId));
	return n.length && n.every((e) => e && Qt(e.type)) ? n[0] : null;
}
var nn = (e) => Math.max(16, ...e.modules.filter((e) => e.type === "dictator").map((e) => w(e.params.length))), rn = (e, t) => {
	let n = e.modules.find((e) => e.id === t.moduleId);
	return n && Z[n.type].ports.find((e) => e.id === t.portId);
}, an = (e, t) => e.moduleId === t.moduleId && e.portId === t.portId;
function on(e, t) {
	let n = e.filter((e) => (e.copyOf ?? e.id) === (t.copyOf ?? t.id));
	return n.length > 1 ? n.indexOf(t) + 1 : null;
}
var sn = (e, t) => e.cables.find((e) => an(e.from, t) || an(e.to, t));
function cn(e, t, n) {
	let r = rn(e, t), i = rn(e, n);
	if (!r || !i) return "That socket no longer exists.";
	if (r.direction !== "out" || i.direction !== "in") return "Connect an output to an input.";
	if (r.kind !== i.kind) return `A ${r.kind.toUpperCase()} output needs a ${r.kind.toUpperCase()} input.`;
	if (e.cables.some((e) => an(e.to, n))) return "That input already has a cable. Pull its plug out first.";
	if (e.cables.some((e) => an(e.from, t))) return "That output jack already has a cable. Use its spare jack, or pull the plug out first.";
	let a = /* @__PURE__ */ new Set(), o = (n) => n === t.moduleId || !a.has(n) && (a.add(n), e.cables.filter((e) => e.from.moduleId === n).some((e) => o(e.to.moduleId)));
	return o(n.moduleId) ? "External feedback loops are not supported. Use ECHO’s feedback control." : null;
}
function ln(e, t, n, r = 1) {
	let i = cn(e, t, n);
	if (i) throw Error(i);
	return {
		...e,
		cables: [...e.cables, {
			id: Nt("cable"),
			from: t,
			to: n,
			amount: r
		}]
	};
}
function un(e, t, n) {
	let r = rn(e, t), i = rn(e, n);
	return !r || !i || r.direction === i.direction ? null : r.direction === "out" ? {
		from: t,
		to: n
	} : {
		from: n,
		to: t
	};
}
function dn(e, t, n, r = null) {
	if (!rn(e, t) || !rn(e, n)) return "That socket no longer exists.";
	let i = un(e, t, n);
	return i ? cn(r ? {
		...e,
		cables: e.cables.filter((e) => e.id !== r)
	} : e, i.from, i.to) : "Connect an output to an input.";
}
function fn(e, t, n, r) {
	if (!e.cables.find((e) => e.id === t)) throw Error("That cable no longer exists.");
	let i = dn(e, n, r, t);
	if (i) throw Error(i);
	let a = un(e, n, r);
	return {
		...e,
		cables: e.cables.map((e) => e.id === t ? {
			...e,
			...a
		} : e)
	};
}
function pn(e, t) {
	return Lt(e, t) || !e.modules.some((e) => e.id === t) ? e : Bt(e, e.modules.filter((e) => e.id !== t), e.cables.filter((e) => e.from.moduleId !== t && e.to.moduleId !== t));
}
function mn(e, t, n) {
	let r = [...e.modules], i = r.findIndex((e) => e.id === t), a = i + n;
	return i < 0 || a < 0 || a >= r.length - 1 || Lt(e, t) ? e : ([r[i], r[a]] = [r[a], r[i]], Bt(e, r));
}
var hn = (e, t) => (e >> t & 1) == 1;
function gn(e, t, n = 0) {
	let r = Math.max(1, Math.min(16, Math.round(e))), i = Math.max(0, Math.min(r, Math.round(t))), a = Math.round(n);
	return Array.from({ length: r }, (e, t) => ((t - a) % r + r) % r * i % r < i);
}
function _n(e, t, n) {
	let r = e.params;
	return [..._t].reverse().find((e) => hn(r[vt(t, e)] ?? 0, n)) ?? 1;
}
var vn = (e, t) => yn(e, t).map((n) => [n, _n(e, n, t % 16)]);
function yn(e, t) {
	let n = Z[e.type].drum, r = e.params;
	return n ? n.voices.filter(({ id: i }) => {
		if (n.mode === "steps") return hn(r[`${i}Pattern`], t % 16);
		let a = bn(e, i);
		return a[t % a.length];
	}).map((e) => e.id) : [];
}
function bn(e, t) {
	let n = e.params, r = n[`${t}Steps`];
	return n[`${t}Custom`] ? Array.from({ length: r }, (e, r) => hn(n[`${t}Pattern`], r)) : gn(r, n[`${t}Hits`], n[`${t}Shift`]);
}
function xn(e, t, n) {
	let r = e.params[`${t}Custom`] ? e.params[`${t}Pattern`] : bn(e, t).reduce((e, t, n) => e | (t ? 1 << n : 0), 0);
	return {
		...e.params,
		[`${t}Custom`]: 1,
		[`${t}Pattern`]: r ^ 1 << n
	};
}
function Sn(e, t) {
	let n = e.params;
	if (n[`${t}Hits`]) return { [`${t}Custom`]: 0 };
	let r = n[`${t}Custom`] ? bn(e, t).filter(Boolean).length : 0;
	return {
		[`${t}Custom`]: 0,
		[`${t}Hits`]: r || Math.max(1, Math.round(n[`${t}Steps`] * 3 / 8))
	};
}
var Cn = (e, t) => !!e.params[`${t}Custom`] || !e.params[`${t}Hits`];
function wn(e, t) {
	let n = Z[t.type].drum;
	return t.type === "performance" ? Rt(e, t.id).some((e) => e.enabled) : t.type === "dictator" ? !!t.notes?.length || U.some((e) => Gt(t, e).length) : n?.mode === "euclid" ? n.voices.some(({ id: e }) => bn(t, e).some(Boolean)) : Z[t.type].params.some((e) => e.pattern && t.params[e.id]);
}
function Tn(e, t) {
	let n = e.modules.find((e) => e.id === t);
	if (!n) return e;
	if (n.type === "performance") return zt(e, t, Rt(e, t).map((e) => ({
		...e,
		enabled: !1
	})));
	if (n.type === "dictator") return U.reduce((e, n) => qt(e, t, n, []), Wt(e, t, []));
	let r = Z[n.type].drum;
	if (!r) return e;
	let i = Object.fromEntries(Z[n.type].params.filter((e) => e.pattern).map((e) => [e.id, 0]));
	if (r.mode === "euclid") for (let { id: e } of r.voices) Object.assign(i, {
		[`${e}Hits`]: 0,
		[`${e}Custom`]: 0
	});
	return {
		...e,
		modules: e.modules.map((e) => e.id === t ? {
			...e,
			params: {
				...e.params,
				...i
			}
		} : e)
	};
}
var En = (e) => [
	"performance",
	"dictator",
	"oscillator",
	"monarch",
	"oracle",
	"aurora",
	"prism",
	"strike",
	"noise",
	"boom",
	"punch",
	"orbit",
	"forge"
].includes(e), Dn = (e) => [
	"oracle",
	"aurora",
	"prism"
].includes(e), On = (e) => kn(e) || !!Z[e].drum, kn = (e) => e === "performance" || e === "dictator";
function An(e, t) {
	let n = /* @__PURE__ */ new Set([t]);
	for (let t of n) for (let r of e.cables) r.from.moduleId === t && rn(e, r.from)?.kind === "audio" && n.add(r.to.moduleId);
	return n;
}
function jn(e, t) {
	let n = e.modules.find((e) => e.id === t);
	if (n && (kn(n.type) || n.type === "skitter")) {
		let n = /* @__PURE__ */ new Set([t]);
		for (let t of n) for (let r of e.cables) r.from.moduleId === t && rn(e, r.from)?.kind !== "audio" && n.add(r.to.moduleId);
		return [...n].some((n) => n !== t && jn(e, n));
	}
	let r = An(e, t);
	return e.modules.some((e) => e.type === "output" && r.has(e.id));
}
function Mn(e, t, n, r = null) {
	let i = un(e, t, n);
	if (!i) throw Error("Connect an output to an input.");
	if (!r) return ln(e, i.from, i.to);
	let a = e.cables.find((e) => e.id === r);
	return a && an(a.from, i.from) && an(a.to, i.to) ? e : fn(e, r, i.from, i.to);
}
var Nn = {
	muted: /* @__PURE__ */ new Set(),
	soloed: /* @__PURE__ */ new Set()
}, Pn = (e, t) => `${e}:${t}`, Fn = (e, t) => `${e}:step:${t}`, In = /* @__PURE__ */ new Set([
	"oscillator",
	"noise",
	"boom",
	"punch",
	"orbit",
	"monarch",
	"oracle",
	"aurora",
	"prism",
	"strike",
	"forge"
]), Ln = (e) => In.has(e);
function Rn(e, t) {
	let n = /* @__PURE__ */ new Set([t]);
	for (let t of n) for (let r of e.cables) r.from.moduleId === t && rn(e, r.from)?.kind !== "audio" && n.add(r.to.moduleId);
	return n.delete(t), e.modules.filter((t) => In.has(t.type) && [...An(e, t.id)].some((e) => n.has(e))).map((e) => e.id);
}
function zn(e, t) {
	let n = new Set(e.modules.map((e) => e.id)), r = new Set([...t.soloed].filter((e) => n.has(e)));
	for (let t of r) for (let n of e.cables) n.from.moduleId === t && rn(e, n.from)?.kind !== "audio" && r.add(n.to.moduleId);
	let i = (t, n = /* @__PURE__ */ new Set()) => r.has(t) ? !0 : !n.has(t) && (n.add(t), e.cables.some((e) => e.from.moduleId === t && e.to.portId !== "chain" && i(e.to.moduleId, n)));
	return Object.fromEntries(e.modules.filter((e) => e.type !== "output").map((e) => [e.id, !t.muted.has(e.id) && (!r.size || !In.has(e.type) || i(e.id))]));
}
var Bn = (e) => Z[e].drum?.voices.map((e) => e.id) ?? (e === "mixer" ? ft : []);
function Vn(e, t, n) {
	let r = Bn(e.type).some((t) => n.soloed.has(Pn(e.id, t)));
	return !n.muted.has(Pn(e.id, t)) && (!r || n.soloed.has(Pn(e.id, t)));
}
function Hn(e, t, n) {
	return !n.muted.has(Fn(e, t)) && (!Array.from({ length: 16 }, (t, n) => Fn(e, n)).some((e) => n.soloed.has(e)) || n.soloed.has(Fn(e, t)));
}
function Un(e, t, n) {
	let r = [], i = sn(e, {
		moduleId: t,
		portId: n
	});
	for (; i;) {
		let t = e.modules.find((e) => e.id === i.from.moduleId);
		if (!t || r.includes(t) || (r.unshift(t), In.has(t.type) || t.type === "mixer")) break;
		let n = Z[t.type].ports.filter((e) => e.direction === "in" && e.kind === "audio");
		i = n.length === 1 ? sn(e, {
			moduleId: t.id,
			portId: n[0].id
		}) : void 0;
	}
	return r;
}
function Wn(e, t) {
	let n = Z[t.type].name;
	return e.modules.filter((e) => e.type === t.type).length > 1 ? `${n} #${e.modules.findIndex((e) => e.id === t.id) + 1}` : n;
}
function Gn(e, t) {
	return t.label ?? Wn(e, t);
}
var Kn = (e) => e.replace(/\s+/g, " ").trim();
function qn(e, t, n) {
	let r = Kn(n).slice(0, 40).trimEnd() || void 0, i = e.modules.find((e) => e.id === t);
	return !i || i.label === r ? e : {
		...e,
		modules: e.modules.map((e) => {
			if (e.id !== t) return e;
			let n = { ...e };
			return r ? n.label = r : delete n.label, n;
		})
	};
}
function Jn(e, t) {
	let n = [t], r = sn(e, {
		moduleId: t.id,
		portId: "chain"
	});
	for (; r;) {
		let t = e.modules.find((e) => e.id === r.from.moduleId);
		if (!t || n.includes(t)) break;
		n.unshift(t), r = sn(e, {
			moduleId: t.id,
			portId: "chain"
		});
	}
	return [...e.modules.filter((t) => (kn(t.type) || t.type === "skitter") && Rn(e, t.id).some((e) => n.some((t) => t.id === e))), ...n.slice(0, -1)].filter((e) => e.label);
}
function Yn(e, t, n) {
	let r = Un(e, t, n), i = n.toUpperCase(), a = r.length ? [...Jn(e, r[0]), ...r] : r, o = a.filter((e) => e.label).at(-1);
	return {
		source: o?.label ?? (r.length ? Wn(e, r[0]) : `Channel ${i}`),
		tooltip: a.map((t) => Gn(e, t)).join(" → "),
		connected: r.length > 0,
		named: !!o,
		deviceId: (o ?? r[0])?.id
	};
}
function Xn(e, t, n) {
	let r = new Set(e.muted), i = new Set(e.soloed), [a, o] = n === "muted" ? [r, i] : [i, r];
	return a.delete(t) || (a.add(t), o.delete(t)), {
		muted: r,
		soloed: i
	};
}
function Zn(e, t) {
	return e.muted.has(t) ? Xn(e, t, "soloed") : e.soloed.has(t) ? Xn(e, t, "muted") : e;
}
var Qn = (e, t) => t === e.id || t.startsWith(`${e.id}:`), $n = (e, t) => [...t.muted, ...t.soloed].some((t) => Qn(e, t));
function er(e, t) {
	return $n(t, e) ? {
		muted: new Set([...e.muted].filter((e) => !Qn(t, e))),
		soloed: new Set([...e.soloed].filter((e) => !Qn(t, e)))
	} : e;
}
var tr = [
	"Vintage Bass",
	"Vintage Lead",
	"Boom Bap",
	"Late Night Hip-Hop",
	"Roots Reggae",
	"Dub Session",
	"Recuerdos",
	"Trap Soul",
	"Broken Beat",
	"Orbit Percussion"
], nr = [
	"Neon Skyline",
	"Digital Boogie",
	"Midnight Ballad",
	"New Wave Motion",
	"Glass Arcade",
	"Analog Sunrise"
], rr = [
	"French Touch",
	"Distortion Disco",
	"Electro Pogo",
	"Electroclash"
], ir = [
	"High Dive",
	"Undertow",
	"Deep End"
], ar = [
	"Rust Machine",
	"Black Mass",
	"Bone Orchard"
], or = [
	["EDM / House", [
		"House",
		"French Touch",
		"Distortion Disco",
		"Electro Pogo",
		"Electroclash"
	]],
	["Funk / Soul", [
		"Groove",
		"Digital Boogie",
		"Midnight Ballad",
		"Broken Beat"
	]],
	["Industrial / Rock", ar],
	["Reggae", [
		"Roots Reggae",
		"Dub Session",
		"Recuerdos"
	]],
	["Synthwave / 80s", [
		"Neon Skyline",
		"Vintage Lead",
		"New Wave Motion",
		"Glass Arcade",
		"Analog Sunrise"
	]],
	["Trap / Hip-Hop", [
		...ir,
		"Trap Soul",
		"Late Night Hip-Hop",
		"Boom Bap",
		"Vintage Bass"
	]],
	["Miscellaneous", ["Orbit Percussion"]]
];
or.flatMap(([, e]) => e);
var sr = "Bone Orchard", cr = (e, t) => e.includes(t);
function lr(e = sr) {
	if (cr(ir, e)) return De(e);
	if (cr(ar, e)) return ke(e);
	if (cr(rr, e)) return ye(e);
	if (cr(nr, e)) return _e(e);
	if (cr(tr, e)) return me(e);
	let t = e === "Groove" ? ["boom", "orbit"] : ["punch"], n = [
		"performance",
		"oscillator",
		"filter",
		"amplifier",
		"equalizer",
		"envelope",
		"lfo",
		"delay",
		...t,
		"output"
	].map((e) => Pt(e, e)), r = (e) => n.find((t) => t.type === e);
	e === "Groove" ? (r("oscillator").params.level = .85, Object.assign(r("envelope").params, {
		decay: .16,
		sustain: .3
	}), Object.assign(r("equalizer").params, {
		hpf: 35,
		lfGain: 1.5,
		lfFreq: 80,
		lfBell: 1,
		lmfGain: -5,
		lmfFreq: 250,
		lmfQ: .8,
		hmfGain: 4,
		hmfFreq: 1200,
		hmfQ: 1.1,
		lpf: 7e3,
		output: 3
	}), Object.assign(r("delay").params, {
		time: .319,
		feedback: .2,
		mix: .08
	}), Object.assign(r("boom").params, {
		kickTune: 46,
		kickDecay: .5,
		kickLevel: 1.3,
		snareTone: .6,
		snappy: .8,
		snareLevel: 1.3,
		snareLag: 12,
		hatPan: .3,
		hatLag: -5,
		bellPan: -.3,
		level: 1
	}), Object.assign(r("orbit").params, {
		level: .55,
		skinTone: .6,
		skinPan: -.35,
		woodPan: .4,
		sandPan: .25
	}), r("output").params.volume = .75) : (r("oscillator").params.wave = 3, Object.assign(r("filter").params, {
		cutoff: 900,
		resonance: 5
	}), Object.assign(r("envelope").params, {
		attack: .002,
		decay: .14,
		sustain: 0,
		release: .08
	}), Object.assign(r("equalizer").params, {
		hpf: 40,
		lfGain: 2,
		lfFreq: 70,
		lfBell: 1,
		lmfGain: -3,
		lmfFreq: 300,
		hmfGain: 2,
		hmfFreq: 2e3,
		lpf: 12e3
	}), r("delay").params.mix = .12);
	let i = [
		36,
		36,
		43,
		36,
		48,
		36,
		46,
		43,
		36,
		36,
		43,
		48,
		46,
		43,
		38,
		43
	], a = (t) => e === "House" ? t % 4 != 0 : t !== 1 && t !== 9, o = {
		version: 1,
		name: e,
		modules: n,
		cables: [],
		sequencer: {
			bpm: e === "Groove" ? 94 : 124,
			swing: e === "Groove" ? .12 : 0,
			steps: i.map((e, t) => ({
				enabled: a(t),
				note: e,
				velocity: t % 4 == 0 ? 1 : .75,
				gate: .65
			}))
		}
	}, s = ["delay", ...t];
	for (let [e, n, r, i, a] of [
		[
			"oscillator",
			"out",
			"filter",
			"in",
			1
		],
		[
			"filter",
			"out",
			"amplifier",
			"in",
			1
		],
		[
			"amplifier",
			"out",
			"equalizer",
			"in",
			1
		],
		[
			"equalizer",
			"out",
			"delay",
			"in",
			1
		],
		...t.map((e, t) => [
			s[t],
			"out",
			e,
			"chain",
			1
		]),
		[
			s.at(-1),
			"out",
			"output",
			"in",
			1
		],
		[
			"performance",
			"pitch",
			"oscillator",
			"pitch",
			1
		],
		[
			"performance",
			"gate",
			"envelope",
			"gate",
			1
		],
		[
			"envelope",
			"out",
			"amplifier",
			"cv",
			1
		],
		[
			"lfo",
			"out",
			"filter",
			"cv",
			.12
		]
	]) o = ln(o, {
		moduleId: e,
		portId: n
	}, {
		moduleId: r,
		portId: i
	}, a);
	return o;
}
function ur(e) {
	let t = `@@note-${Math.random().toString(36).slice(2)}@@`, n = /* @__PURE__ */ new Set(["notes", ...Object.values(je)]);
	return JSON.stringify(e, (e, r) => n.has(e) && Array.isArray(r) ? r.map((e) => `${t}${e.join(",")}`) : r, 2).replaceAll(RegExp(`"${t}([-\\d,]+)"`, "g"), "[$1]");
}
function dr(e) {
	let t = e.cables.map((e) => JSON.stringify([
		e.from.moduleId,
		e.from.portId,
		e.to.moduleId,
		e.to.portId,
		e.amount
	])).sort();
	return JSON.stringify({
		name: e.name,
		modules: e.modules,
		sequencer: e.sequencer,
		cables: t
	});
}
function fr(e) {
	if (e.length > 1e6) throw Error("Patch files must be smaller than 1 MB.");
	let t = JSON.parse(e), n = (e) => typeof e == "object" && !!e && !Array.isArray(e), r = () => {
		throw Error("This is not a valid Rackloose v1 patch.");
	}, i = (e) => !Array.isArray(e) || e.length !== 16 ? r() : e.map((e) => !n(e) || typeof e.enabled != "boolean" || typeof e.note != "number" || !Number.isInteger(e.note) || e.note < 24 || e.note > 96 || typeof e.velocity != "number" || !Number.isFinite(e.velocity) || e.velocity < 0 || e.velocity > 1 || typeof e.gate != "number" || !Number.isFinite(e.gate) || e.gate < .1 || e.gate > .95 ? r() : {
		enabled: e.enabled,
		note: e.note,
		velocity: e.velocity,
		gate: e.gate
	}), a = (e) => e === void 0 ? [] : !Array.isArray(e) || e.length > 2048 ? r() : T(e.map((e) => {
		if (!Array.isArray(e) || e.length !== 4 || !e.every((e) => Number.isInteger(e))) return r();
		let [t, n, i, a] = e;
		return t < 0 || t >= v || n < 1 || n > v || i < 0 || i > 127 || a < 1 || a > 127 ? r() : [
			t,
			n,
			i,
			a
		];
	})), o = (e, t) => {
		if (e === void 0) return {};
		if (!Array.isArray(e) || e.length > 4096) return r();
		let { min: n, max: i } = Ae[t], a = Le(e.map((e) => {
			if (!Array.isArray(e) || e.length !== 2 || !e.every((e) => Number.isInteger(e))) return r();
			let [t, a] = e;
			return t < 0 || t >= v || a < n || a > i ? r() : [t, a];
		}));
		return a.length ? { [je[t]]: a } : {};
	};
	if (!n(t) || t.version !== 1 || typeof t.name != "string" || t.name.length > 100 || !Array.isArray(t.modules) || !Array.isArray(t.cables) || !n(t.sequencer) || t.modules.length < 1 || t.modules.length > 32 || t.cables.length > 128) return r();
	let s = /* @__PURE__ */ new Set(), c = (e) => {
		if (e === void 0) return {};
		if (typeof e != "string") return r();
		let t = Kn(e);
		return t.length > 40 ? r() : t ? { label: t } : {};
	}, l = t.modules.map((e, t) => {
		if (!n(e) || typeof e.id != "string" || !/^[\w-]{1,80}$/.test(e.id) || s.has(e.id) || typeof e.type != "string" || !Object.hasOwn(Z, e.type) || !n(e.params)) return r();
		s.add(e.id);
		let l = e.type, u = e.params, d = Object.fromEntries(Z[l].params.map((e) => {
			let t = u[e.id] === void 0 ? e.legacyFrom !== void 0 && u[e.legacyFrom] !== void 0 ? u[e.legacyFrom] : e.legacyDefault : u[e.id];
			return typeof t != "number" || !Number.isFinite(t) || t < e.min || t > e.max || (e.choices || e.pattern) && !Number.isInteger(t) ? r() : [e.id, t];
		})), f = c(e.label);
		return l === "dictator" ? {
			id: e.id,
			type: l,
			params: d,
			notes: a(e.notes),
			...o(e.bends, "bend"),
			...o(e.mods, "mod"),
			...f
		} : l === "performance" && t > 0 ? {
			id: e.id,
			type: l,
			params: d,
			steps: i(e.steps),
			...f
		} : {
			id: e.id,
			type: l,
			params: d,
			...f
		};
	});
	if (l.reduce((e, t) => e + (t.notes?.length ?? 0), 0) > 8192 || l.reduce((e, t) => e + U.reduce((e, n) => e + Gt(t, n).length, 0), 0) > 16384 || l.filter((e) => e.type === "output").length !== 1 || l.at(-1)?.type !== "output") return r();
	let u = t.sequencer;
	if (typeof u.bpm != "number" || !Number.isFinite(u.bpm) || u.bpm < 40 || u.bpm > 240 || typeof u.swing != "number" || !Number.isFinite(u.swing) || u.swing < 0 || u.swing > .6) return r();
	let d = i(u.steps), f = {
		version: 1,
		name: t.name,
		modules: l,
		cables: [],
		sequencer: {
			bpm: u.bpm,
			swing: u.swing,
			steps: d
		}
	}, p = /* @__PURE__ */ new Set();
	for (let e of t.cables) {
		if (!n(e) || typeof e.id != "string" || !/^[\w-]{1,80}$/.test(e.id) || p.has(e.id) || !n(e.from) || !n(e.to) || typeof e.from.moduleId != "string" || typeof e.from.portId != "string" || typeof e.to.moduleId != "string" || typeof e.to.portId != "string" || typeof e.amount != "number" || !Number.isFinite(e.amount) || e.amount < -1 || e.amount > 1) return r();
		p.add(e.id);
		let t = {
			moduleId: e.from.moduleId,
			portId: e.from.portId
		}, i = {
			moduleId: e.to.moduleId,
			portId: e.to.portId
		}, a = rn(f, t);
		if (a && f.cables.some((e) => an(e.from, t))) {
			let e = Z[f.modules.find((e) => e.id === t.moduleId).type].ports.find((e) => (e.copyOf ?? e.id) === (a.copyOf ?? a.id) && !f.cables.some((n) => an(n.from, {
				moduleId: t.moduleId,
				portId: e.id
			})));
			if (!e) continue;
			t.portId = e.id;
		}
		if (cn(f, t, i) || rn(f, t)?.kind !== "cv" && e.amount !== 1) return r();
		f = {
			...f,
			cables: [...f.cables, {
				id: e.id,
				from: t,
				to: i,
				amount: e.amount
			}]
		};
	}
	return f;
}
function pr(e, t) {
	try {
		let n = e.getItem(t);
		return {
			patch: n ? fr(n) : null,
			error: null
		};
	} catch {
		return {
			patch: null,
			error: "Saved patch unavailable. You can still play and export patch files."
		};
	}
}
function mr(e, t, n) {
	try {
		return e.setItem(t, ur(n)), null;
	} catch {
		return "Local save unavailable. Export a patch file to keep your work.";
	}
}
var hr = (e, t) => e.logarithmic ? Math.log(t / e.min) / Math.log(e.max / e.min) : (t - e.min) / (e.max - e.min), gr = [
	"C",
	"C♯",
	"D",
	"D♯",
	"E",
	"F",
	"F♯",
	"G",
	"G♯",
	"A",
	"A♯",
	"B"
], _r = (e) => `${gr[e % 12]}${Math.floor(e / 12) - 1}`, vr = class {
	notes = /* @__PURE__ */ new Map();
	press(e, t) {
		return this.notes.delete(e), this.notes.set(e, t), this.current;
	}
	release(e) {
		return this.notes.delete(e), this.current;
	}
	clear() {
		this.notes.clear();
	}
	has(e) {
		return this.notes.has(e);
	}
	get current() {
		return [...this.notes.values()].at(-1) ?? null;
	}
	get entries() {
		return [...this.notes];
	}
}, yr = (e, t, n) => 60 / e / 4 * (n % 2 == 0 ? 1 + t : 1 - t);
function br(e, t, n = 0) {
	let r = [], i = n;
	for (let n = 0; n < t * nn(e); n++) {
		let t = n % 16, a = yr(e.sequencer.bpm, e.sequencer.swing, t);
		r.push({
			step: e.sequencer.steps[t],
			index: t,
			time: i,
			duration: a
		}), i += a;
	}
	return {
		events: r,
		duration: i - n
	};
}
var xr = (e) => [...e].map((e) => e.charCodeAt(0) & 127), Sr = (e) => [
	e >>> 24 & 255,
	e >>> 16 & 255,
	e >>> 8 & 255,
	e & 255
];
function Cr(e) {
	let t = [e & 127];
	for (let n = e >>> 7; n > 0; n >>>= 7) t.unshift(n & 127 | 128);
	return t;
}
var Q = (e, t) => [
	...xr(e),
	...Sr(t.length),
	...t
], wr = (e, t) => [
	255,
	e,
	...Cr(t.length),
	...t
];
function Tr(e, t) {
	let n = Math.round(6e7 / t), r = [
		0,
		...wr(81, [
			n >> 16 & 255,
			n >> 8 & 255,
			n & 255
		]),
		0,
		...wr(88, [
			4,
			2,
			24,
			8
		]),
		0,
		...wr(47, [])
	], i = e.map(({ name: e, notes: t, channel: n = 0, bends: r = [], mods: i = [] }) => {
		let a = [
			...t.flatMap(([e, t, r, i]) => [{
				tick: e,
				data: [
					144 | n,
					r,
					i
				],
				order: 2
			}, {
				tick: e + t,
				data: [
					128 | n,
					r,
					64
				],
				order: 0
			}]),
			...r.map(([e, t]) => {
				let r = t - Ae.bend.min;
				return {
					tick: e,
					data: [
						224 | n,
						r & 127,
						r >> 7 & 127
					],
					order: 1
				};
			}),
			...i.map(([e, t]) => ({
				tick: e,
				data: [
					176 | n,
					1,
					t & 127
				],
				order: 1
			}))
		].sort((e, t) => e.tick - t.tick || e.order - t.order), o = 0, s = [0, ...wr(3, xr(e.replace(/[^\x20-\x7e]/g, "-").slice(0, 100)))];
		for (let e of a) s.push(...Cr(e.tick - o), ...e.data), o = e.tick;
		return Q("MTrk", [
			...s,
			0,
			...wr(47, [])
		]);
	});
	return new Uint8Array([
		...Q("MThd", [
			0,
			1,
			...[e.length + 1].flatMap((e) => [e >> 8, e & 255]),
			3,
			192
		]),
		...Q("MTrk", r),
		...i.flat()
	]);
}
var Er = () => {
	throw Error("This MIDI file is damaged or not a MIDI file.");
};
function Dr(e) {
	if (e.length > 1e6) throw Error("MIDI files must be smaller than 1 MB.");
	let t = new DataView(e.buffer, e.byteOffset, e.byteLength), n = (t) => String.fromCharCode(...e.subarray(t, t + 4));
	if (e.length < 14 || n(0) !== "MThd") return Er();
	let r = t.getUint32(4), i = t.getUint16(8), a = t.getUint16(10), o = t.getUint16(12);
	if (r < 6 || i > 1 || 8 + r > e.length) return Er();
	if (o & 32768) throw Error("MIDI files timed in SMPTE frames are not supported.");
	if (!o || a > 256) return Er();
	let s = (e) => Math.round(e * 960 / o), c = null, l = 8 + r, u = 0, d = [];
	for (; l + 8 <= e.length && u < a;) {
		let r = n(l), i = t.getUint32(l + 4), a = l + 8 + i;
		if (a > e.length) return Er();
		if (r === "MTrk") {
			u++;
			let t = l + 8, n = 0, r = 0, i = "", o = /* @__PURE__ */ new Map(), f = /* @__PURE__ */ new Map(), p = /* @__PURE__ */ new Map(), m = /* @__PURE__ */ new Map(), h = (e, t, r) => {
				let i = e.get(t) ?? [];
				i.push([s(n), r]), e.set(t, i);
			}, g = () => t < a ? e[t++] : Er(), _ = () => {
				let e = 0;
				for (let t = 0; t < 4; t++) {
					let t = g();
					if (e = e * 128 + (t & 127), !(t & 128)) return e;
				}
				return Er();
			}, v = (e, t, n) => {
				let r = o.get(e * 128 + t)?.shift();
				if (r) {
					let i = f.get(e) ?? [];
					i.push([
						r.tick,
						Math.max(1, n - r.tick),
						t,
						r.velocity
					]), f.set(e, i);
				}
			};
			for (; t < a;) {
				n += _();
				let l = g();
				if (l === 255) {
					let n = g(), r = _();
					if (t + r > a) return Er();
					let o = e.subarray(t, t + r);
					t += r, n === 3 && !i && (i = String.fromCharCode(...o).replace(/[^\x20-\x7e]/g, "").trim().slice(0, 100));
					let s = o[0] << 16 | o[1] << 8 | o[2];
					if (n === 81 && r === 3 && s > 0 && c === null && (c = Math.round(6e7 / s * 100) / 100), n === 47) break;
					continue;
				}
				if (l === 240 || l === 247) {
					let e = _();
					if (t += e, t > a) return Er();
					continue;
				}
				if (l < 128) {
					if (!r) return Er();
					t--, l = r;
				} else r = l;
				let u = l & 240, d = l & 15, f = g(), y = u === 192 || u === 208 ? 0 : g();
				if (f > 127 || y > 127) return Er();
				if (u === 144 && y > 0) {
					let e = d * 128 + f;
					o.set(e, [...o.get(e) ?? [], {
						tick: s(n),
						velocity: y
					}]);
				} else u === 128 || u === 144 ? v(d, f, s(n)) : u === 224 ? h(p, d, (y << 7 | f) + Ae.bend.min) : u === 176 && f === 1 && h(m, d, y);
			}
			for (let e of o.keys()) for (; o.get(e)?.length;) v(Math.floor(e / 128), e % 128, s(n));
			for (let [e, t] of [...f].sort(([e], [t]) => e - t)) {
				let n = {
					name: i || `Track ${u}`,
					channel: e,
					notes: t.sort((e, t) => e[0] - t[0] || e[2] - t[2])
				}, r = p.get(e), a = m.get(e);
				r && (n.bends = Re(Le(r))), a && (n.mods = Re(Le(a))), d.push(n);
			}
		}
		l = a;
	}
	return u < Math.min(a, 1) ? Er() : {
		bpm: c,
		tracks: d
	};
}
function Or(e, t, n = {}) {
	let r = [...(n.bends ?? []).filter(([, e]) => e !== Ae.bend.rest), ...(n.mods ?? []).filter(([, e]) => e !== Ae.mod.rest)], i = [...e, ...r].reduce((e, [t]) => Math.max(e, t), 0), a = _.findIndex((e) => i < e * g), o = a < 0 ? _.length - 1 : a, s = C(o), c = /* @__PURE__ */ new Set(), l = [];
	for (let [t, n, r, i] of T(e)) t < 0 || t >= s || c.has(t * 128 + r) || (c.add(t * 128 + r), l.push([
		t,
		Math.max(1, Math.min(n, s - t)),
		r,
		Math.max(1, Math.min(127, i))
	]));
	let u = l.slice(0, Math.max(0, Math.min(y, t)));
	return {
		notes: u,
		length: o,
		dropped: e.length - u.length,
		bends: Ze("bend", n.bends ?? [], s),
		mods: Ze("mod", n.mods ?? [], s)
	};
}
// src/midiInput.ts
var kr = () => typeof navigator < "u" && typeof navigator.requestMIDIAccess == "function";
function Ar(e) {
	if (e.length < 3) return null;
	let t = e[0] & 240, n = e[1], r = e[2];
	return n > 127 || r > 127 ? null : t === 144 ? r ? {
		on: !0,
		note: n,
		velocity: r
	} : {
		on: !1,
		note: n,
		velocity: 0
	} : t === 128 ? {
		on: !1,
		note: n,
		velocity: 0
	} : null;
}
function jr(e) {
	if (e.length < 3 || e[1] > 127 || e[2] > 127) return null;
	let t = e[0] & 240;
	return t === 224 ? {
		kind: "bend",
		value: (e[2] << 7 | e[1]) - 8192
	} : t === 176 && e[1] === 1 ? {
		kind: "mod",
		value: e[2]
	} : null;
}
async function Mr(e, t = () => {}, n = () => {}) {
	let r = await navigator.requestMIDIAccess({ sysex: !1 }), i = !1, a = () => {
		for (let t of r.inputs.values()) t.onmidimessage = (r) => {
			if (!r.data || i) return;
			let a = Ar(r.data), o = a ? null : jr(r.data);
			a ? e({
				...a,
				timeStamp: r.timeStamp,
				input: t.name ?? t.id
			}) : o && n({
				...o,
				timeStamp: r.timeStamp
			});
		};
		t([...r.inputs.values()].filter((e) => e.state !== "disconnected").map((e) => e.name || e.id));
	};
	return r.onstatechange = () => {
		i || a();
	}, a(), () => {
		i = !0, r.onstatechange = null;
		for (let e of r.inputs.values()) e.onmidimessage = null;
	};
}
var Nr = () => ({
	past: [],
	future: [],
	key: null,
	at: 0
});
function Pr(e, t, n, r) {
	return n !== null && n === e.key && r - e.at < 1e3 && !e.future.length ? {
		...e,
		at: r
	} : {
		past: [...e.past, t].slice(-50),
		future: [],
		key: n,
		at: r
	};
}
function Fr(e, t) {
	let n = e.past.at(-1);
	return n === void 0 ? null : {
		state: n,
		history: {
			past: e.past.slice(0, -1),
			future: [t, ...e.future],
			key: null,
			at: 0
		}
	};
}
function Ir(e, t) {
	let [n, ...r] = e.future;
	return n === void 0 ? null : {
		state: n,
		history: {
			past: [...e.past, t].slice(-50),
			future: r,
			key: null,
			at: 0
		}
	};
}
var Lr = "This browser could not save to My Presets. Export a file to keep your work.", Rr = 100, zr = (e, t) => e.trim().toLocaleLowerCase() === t.trim().toLocaleLowerCase(), Br = (e, t) => e.patch.name.localeCompare(t.patch.name, void 0, {
	sensitivity: "base",
	numeric: !0
}) || e.savedAt - t.savedAt;
function Vr(e, t) {
	try {
		let n = e.getItem(t);
		if (!n) return {
			presets: [],
			error: null
		};
		let r = JSON.parse(n);
		if (typeof r != "object" || !r || !("presets" in r) || !Array.isArray(r.presets)) throw Error("Not a preset list");
		let i = [], a = /* @__PURE__ */ new Set();
		for (let e of r.presets.slice(0, 200)) try {
			if (typeof e != "object" || !e) continue;
			let { id: t, savedAt: n, patch: r } = e;
			if (typeof t != "string" || !/^[\w-]{1,80}$/.test(t) || a.has(t) || typeof n != "number" || !Number.isFinite(n)) continue;
			let o = fr(JSON.stringify(r));
			if (i.some((e) => zr(e.patch.name, o.name))) continue;
			a.add(t), i.push({
				id: t,
				savedAt: n,
				patch: o
			});
		} catch {}
		return {
			presets: i.sort(Br),
			error: null
		};
	} catch {
		return {
			presets: [],
			error: "My Presets could not be read. Export files to keep your presets."
		};
	}
}
function Hr(e, t, n) {
	try {
		return e.setItem(t, JSON.stringify({
			version: 1,
			presets: n
		})), null;
	} catch {
		return Lr;
	}
}
function Ur(e, t) {
	return [...e.filter((e) => e.id !== t.id && !zr(e.patch.name, t.patch.name)), t].sort(Br);
}
var Wr = (e, t, n) => e.find((e) => e.id !== n && zr(e.patch.name, t));
function Gr(e, t) {
	for (let n = 1;; n++) {
		let r = n === 1 ? "" : ` (${n})`, i = `${t.slice(0, Rr - r.length).trimEnd()}${r}`;
		if (!Wr(e, i)) return i;
	}
}
function Kr(e) {
	return e.trim().toLowerCase().replace(/[^a-z0-9_-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80).replace(/-+$/, "") || "rackloose-patch";
}
function qr(e, t) {
	return e ? t ? t.error ? {
		state: "failed",
		text: "Edited · not saved",
		detail: t.error
	} : {
		state: "saved",
		text: "Edited · saved locally",
		detail: "Your edits are kept in this browser and come back after a reload. Save adds them to My Presets."
	} : {
		state: "edited",
		text: "Edited",
		detail: ""
	} : {
		state: "clean",
		text: "",
		detail: ""
	};
}
// src/audio/hold.ts
var Jr = /* @__PURE__ */ new WeakMap(), Yr = 64;
function Xr(e, t, n) {
	let r = () => t, i = 0;
	for (let t of e) if (t.type === "ramp") {
		if (t.time > n) {
			let e = r(i);
			return e + (t.value - e) * (n - i) / (t.time - i);
		}
		r = () => t.value, i = t.time;
	} else {
		if (t.time > n) break;
		let e = r(t.time), a = t.time;
		r = t.type === "set" ? () => t.value : (n) => t.value + (e - t.value) * Math.exp(-(n - a) / t.constant), i = t.time;
	}
	return r(n);
}
function Zr(e, t) {
	if (typeof e.cancelAndHoldAtTime == "function" || Jr.has(e)) return e;
	let n = [], { setValueAtTime: r, linearRampToValueAtTime: i, setTargetAtTime: a, cancelScheduledValues: o } = e, s, c = (r) => {
		s ??= e.value;
		let i = n.length;
		for (; i && n[i - 1].time > r.time;) i--;
		if (n.splice(i, 0, r), t && n.length > Yr) {
			let e = -1;
			for (let r = 0; r < n.length && n[r].time <= t.currentTime - 1; r++) n[r].type !== "ramp" && (e = r);
			e > 0 && (s = Xr(n.slice(0, e), s, n[e].time), n.splice(0, e));
		}
	};
	return Object.assign(e, {
		setValueAtTime(t, n) {
			return c({
				type: "set",
				time: n,
				value: t,
				constant: 0
			}), r.call(e, t, n);
		},
		linearRampToValueAtTime(t, n) {
			return c({
				type: "ramp",
				time: n,
				value: t,
				constant: 0
			}), i.call(e, t, n);
		},
		setTargetAtTime(t, n, r) {
			return c({
				type: "target",
				time: n,
				value: t,
				constant: r
			}), a.call(e, t, n, r);
		},
		cancelScheduledValues(t) {
			return n.splice(0, n.length, ...n.filter((e) => e.time < t)), o.call(e, t);
		}
	}), Jr.set(e, {
		events: n,
		hold: (t) => {
			let r = Xr(n, s ?? e.value, t), i = n.find((e) => e.time >= t);
			e.cancelScheduledValues(t), i?.type === "ramp" ? e.linearRampToValueAtTime(r, t) : e.setValueAtTime(r, t);
		}
	}), e;
}
function Qr(e, t) {
	if (typeof e.cancelAndHoldAtTime == "function") {
		e.cancelAndHoldAtTime(t);
		return;
	}
	let n = Jr.get(e)?.hold;
	if (n) n(t);
	else {
		let n = e.value;
		e.cancelScheduledValues(t), e.setValueAtTime(n, t);
	}
}
// src/audio/drums.ts
var $r = [
	205.3,
	304.4,
	369.6,
	522.7,
	540,
	800
], ei = (e) => 2 ** (e / 12);
function ti(e, t, n, { keep: r, start: i, noise: a }) {
	let o = /* @__PURE__ */ new Set(), s = /* @__PURE__ */ new Map(), c = (t = 0, i = n) => {
		let a = r(e.createGain());
		return a.gain.value = t, a.connect(i), a;
	}, l = /* @__PURE__ */ new Set(), u = (e, t, n) => {
		l.add(e), e.setValueAtTime(t, n);
	}, d = /* @__PURE__ */ new Map(), f = (t) => {
		let n = d.get(t);
		return n || (n = r(e.createStereoPanner()), n.channelCount = 1, n.channelCountMode = "explicit", n.connect(c(Math.SQRT2)), d.set(t, n)), n;
	}, p = (t, n, i = .7) => {
		let a = r(e.createBiquadFilter());
		return a.type = t, a.frequency.value = n, a.Q.value = i, a;
	}, m = (...e) => (e.reduce((e, t) => e.connect(t)), e.at(-1)), h = null, g = () => (h || (h = i(e.createBufferSource()), h.buffer = a, h.loop = !0), h), _ = (t, n) => {
		let a = r(e.createGain());
		return a.gain.value = n, {
			sum: a,
			oscillators: t.map((t) => {
				let n = i(e.createOscillator());
				return n.type = "square", n.frequency.value = t, n.connect(a), n;
			})
		};
	}, v = (e, t, ...n) => {
		let r = c(0, f(e)), i = n.map((e) => e.frequency.value);
		return m(t, ...n, r), {
			gain: r.gain,
			tune: (e, t) => n.forEach((n, r) => u(n.frequency, i[r] * e, t))
		};
	}, y = /* @__PURE__ */ new Map(), b = (t, n, r, i, a = 5e-4) => {
		Zr(t, e);
		let o = y.get(t) ?? [], s = o.filter((t) => t.time < e.currentTime).at(-1);
		y.set(t, [
			...s ? [s] : [],
			...o.filter((t) => t.time >= e.currentTime),
			{
				time: n,
				peak: r,
				decay: i,
				rise: a
			}
		].sort((e, t) => e.time - t.time)), t.setTargetAtTime(r, n, a), t.setTargetAtTime(0, n + a * 5, i / 4.6);
	}, x = (e, t) => e.setTargetAtTime(0, t, .003);
	function S(e) {
		if (o.delete(e)) {
			for (let t of [
				...e.sources,
				...e.nodes,
				e.vca
			]) t.disconnect();
			s.get(e.voice) === e && s.delete(e.voice);
		}
	}
	function C(t, n, r, i, a, c = f(t)) {
		let l = e.createGain(), u = [];
		l.gain.value = 0, Zr(l.gain, e), l.connect(c);
		let d = {
			voice: t,
			vca: l,
			nodes: u,
			sources: a(l, u),
			start: n,
			end: n + i * 1.25 + .05,
			naturalEnd: n + i * 1.25 + .05,
			decay: i
		};
		l.gain.setValueAtTime(0, n), l.gain.linearRampToValueAtTime(r, n + .0015), l.gain.setTargetAtTime(0, n + .0015, i / 4.6);
		for (let e of d.sources) e.start(n), e.stop(d.end);
		d.sources[0].onended = () => S(d), o.add(d);
		let p = s.get(t), [m, h] = p && p.start > n ? [d, p] : [p, d];
		if (s.set(t, h), m && o.has(m) && m.end > h.start) {
			m.vca.gain.setTargetAtTime(0, h.start, .002), m.end = h.start + .03, m.chokeAt = h.start;
			for (let e of m.sources) e.stop(m.end);
		}
	}
	let w = (t, n, r, i, a = 1) => {
		let o = e.createOscillator();
		if (o.type = r, o.frequency.value = i, a === 1) o.connect(t);
		else {
			let r = e.createGain();
			r.gain.value = a, o.connect(r).connect(t), n.push(r);
		}
		return o;
	}, T = (e, t, n, r, i) => {
		e.frequency.setValueAtTime(n * r, t), e.frequency.exponentialRampToValueAtTime(n, t + i);
	}, E = () => {};
	if (t === "boom") {
		let e = v("snare", g(), p("highpass", 1800)), t = v("rim", g(), p("highpass", 5e3)), n = v("clap", g(), p("bandpass", 1e3, 1.4)), r = _($r, .5).sum, i = p("highpass", 5e3), a = v("hat", r, p("bandpass", 1e4, 1), p("highpass", 7e3)), o = v("open", r, p("bandpass", 1e4, 1), p("highpass", 7e3)), s = v("crash", r, p("bandpass", 7e3, .5), i);
		m(g(), c(.35, i));
		let l = v("ride", _($r.map((e) => e * 1.13), .5).sum, p("bandpass", 4800, 2.5), p("highpass", 3e3)), u = _([540, 800], .5), d = v("bell", u.sum, p("bandpass", 2640, 1.4)), f = (e, t, n, r, i) => C(e, t, .9 * i, r, (e, r) => {
			let i = w(e, r, "sine", n), a = w(e, r, "triangle", n * 1.5, .15);
			return T(i, t, n, 1.6, .06), T(a, t, n * 1.5, 1.6, .06), [i, a];
		});
		E = (r, i, c) => {
			let p = c[`${r}Level`] ?? 1;
			if (r === "kick") C("kick", i, p, c.kickDecay, (e) => {
				let t = w(e, [], "sine", c.kickTune);
				return T(t, i, c.kickTune, 2, .025), [t];
			});
			else if (r === "snare") {
				let t = c.snareTone, n = ei(c.snareTune);
				C("snare", i, .55 * p, .65 * c.snareDecay, (e, r) => [w(e, r, "sine", 185 * n, 1 - .6 * t), w(e, r, "sine", 330 * n, .35 + .65 * t)]), b(e.gain, i, .6 * c.snappy * p, c.snareDecay);
			} else if (r === "rim") {
				let e = ei(c.rimTune);
				C("rim", i, .7 * p, c.rimDecay, (t, n) => [w(t, n, "triangle", 455 * e, .6), w(t, n, "triangle", 1667 * e)]), b(t.gain, i, .5 * p, .008 / .03 * c.rimDecay);
			} else if (r === "clap") {
				n.tune(Ot(c.clapTone, 3), i);
				for (let e of [
					0,
					.01,
					.021
				]) b(n.gain, i + e, 1.4 * p, .016, 4e-4);
				b(n.gain, i + .032, 1.4 * p, c.clapDecay);
			} else if (r === "hat") x(o.gain, i), a.tune(Ot(c.hatTone, 2), i), b(a.gain, i, 1.25 * p, c.hatDecay);
			else if (r === "open") o.tune(Ot(c.openTone, 2), i), b(o.gain, i, p, c.openDecay);
			else if (r === "lowTom") f("lowTom", i, 95 * ei(c.tomTune), c.tomDecay, p);
			else if (r === "highTom") f("highTom", i, 145 * ei(c.highTomTune), c.highTomDecay * .85, p);
			else if (r === "crash") s.tune(Ot(c.crashTone, 2), i), b(s.gain, i, .75 * p, c.crashDecay, .002);
			else if (r === "ride") l.tune(Ot(c.rideTone, 2), i), b(l.gain, i, .8 * p, c.rideDecay, .001);
			else if (r === "bell") {
				let e = ei(c.bellTune);
				u.oscillators.forEach((t, n) => t.frequency.setValueAtTime([540, 800][n] * e, i)), b(d.gain, i, .9 * p, c.bellDecay);
			}
		};
	} else if (t === "punch") {
		let t = c(1, f("kick")), n = r(e.createWaveShaper()), i = c(1, n), a = c(0, i);
		n.curve = Float32Array.from({ length: 1025 }, (e, t) => Math.tanh(2.2 * (t / 512 - 1)) / Math.tanh(2.2)), n.oversample = "2x", n.connect(t), m(g(), p("lowpass", 4e3), a);
		let o = p("lowpass", 6e3), s = v("snare", g(), p("highpass", 1200), o), l = v("clap", g(), p("bandpass", 1100, 1.6)), d = r(e.createGain());
		m(_($r.map((e) => e * 1.5), .5).sum, d), m(g(), c(.35, d));
		let h = v("hat", d, p("highpass", 7500)), y = v("open", d, p("highpass", 7500));
		E = (e, n, r) => {
			let c = r[`${e}Level`] ?? 1;
			if (e === "kick") u(t.gain, c, n), C("kick", n, 1, r.kickDecay, (e) => {
				let t = w(e, [], "sine", r.kickTune), i = t.frequency;
				return i.setValueAtTime(r.kickTune * 5, n), i.exponentialRampToValueAtTime(r.kickTune * 1.3, n + .03), i.exponentialRampToValueAtTime(r.kickTune, n + .16), [t];
			}, i), b(a.gain, n, .7 * r.kickClick, .012);
			else if (e === "snare") {
				let e = ei(r.snareTune);
				C("snare", n, .5 * c, .11 / .18 * r.snareDecay, (t, r) => [180, 330].map((i, a) => {
					let o = w(t, r, "triangle", i * e, a ? .6 : 1);
					return T(o, n, i * e, 1.15, .02), o;
				})), u(o.frequency, 3e3 + 7e3 * r.snareTone, n), b(s.gain, n, .75 * r.snappy * c, r.snareDecay);
			} else if (e === "clap") {
				l.tune(Ot(r.clapTone, 3), n);
				for (let e of [
					0,
					.011,
					.022
				]) b(l.gain, n + e, 1.5 * c, .018, 4e-4);
				b(l.gain, n + .033, 1.5 * c, r.clapDecay);
			} else e === "hat" ? (x(y.gain, n), h.tune(Ot(r.hatTone, 2), n), b(h.gain, n, .9 * c, r.hatDecay)) : e === "open" && (y.tune(Ot(r.openTone, 2), n), b(y.gain, n, .75 * c, r.openDecay));
		};
	} else if (t === "orbit") {
		let e = p("bandpass", 6500, 1.2), t = c(0, f("sand")), n = p("highpass", 4500), r = c(0, f("shaker"));
		m(g(), e, p("highpass", 3e3), t), m(g(), n, r), E = (i, a, o) => {
			let s = ei(o.pitch + o[`${i}Tune`]), c = o[`${i}Decay`], l = o[`${i}Level`], d = o[`${i}Tone`];
			i === "skin" || i === "tom" ? C(i, a, (i === "skin" ? .8 : .95) * l, c, (e, t) => {
				let n = (i === "skin" ? 196 : 98) * s, r = w(e, t, "sine", n), o = w(e, t, "sine", n * (i === "skin" ? 311 / 196 : 1.5), d * .5);
				return T(r, a, n, i === "skin" ? 1.4 : 2.2, .035), T(o, a, n * (i === "skin" ? 311 / 196 : 1.5), 1.4, .035), [r, o];
			}) : i === "wood" ? C("wood", a, .6 * l, c, (e, t) => {
				let n = w(e, t, "sine", 1450 * s), r = w(e, t, "sine", 3915 * s, d * .6);
				return T(n, a, 1450 * s, 1.05, .005), [n, r];
			}) : i === "sand" ? (u(e.frequency, Math.min(18e3, 6500 * s * (.5 + d)), a), b(t.gain, a, .9 * l, c, .004)) : i === "shaker" ? (u(n.frequency, Math.min(16e3, (1500 + d * 6e3) * s), a), b(r.gain, a, .65 * l, c, .008)) : i === "metal" && C("metal", a, .3 * l, c, (e, t) => [
				440,
				623,
				1067,
				1573
			].map((n, r) => w(e, t, r ? "sine" : "triangle", n * s, r ? .15 + d * .7 : 1)));
		};
	}
	return {
		trigger(e, t, n, r = 1) {
			u(f(e).pan, n[`${e}Pan`] ?? 0, t), E(e, t, r === 1 ? n : {
				...n,
				[`${e}Level`]: (n[`${e}Level`] ?? 1) * r
			});
		},
		cancelScheduled(e) {
			for (let t of [...o]) if (t.start >= e) {
				for (let n of t.sources) n.stop(e);
				S(t);
			}
			s.clear();
			for (let t of o) {
				if (t.chokeAt !== void 0 && t.chokeAt >= e) {
					Qr(t.vca.gain, e), t.vca.gain.setTargetAtTime(0, e, t.decay / 4.6), t.end = t.naturalEnd, t.chokeAt = void 0;
					for (let e of t.sources) e.stop(t.end);
				}
				(!s.has(t.voice) || s.get(t.voice).start < t.start) && s.set(t.voice, t);
			}
			for (let t of l) t.cancelScheduledValues(e);
			for (let [t, n] of y) {
				let r = n.filter((t) => t.time < e).at(-1);
				Qr(t, e), r ? t.setTargetAtTime(0, Math.max(e, r.time + r.rise * 5), r.decay / 4.6) : t.setValueAtTime(0, e), y.set(t, r ? [r] : []);
			}
		},
		dispose() {
			for (let e of o) for (let t of e.sources) t.stop();
			for (let e of [...o]) S(e);
			s.clear();
		}
	};
}
// src/audio/strike.ts
var ni = 28e3, ri = /* @__PURE__ */ new Map();
function ii(e) {
	let t = ri.get(e);
	if (t) return t;
	let n = ut.findIndex((t) => t.id === e);
	if (n < 0) throw Error(`Unknown STRIKE voice: ${e}`);
	let r = [
		"crash",
		"ride",
		"open"
	].includes(e), i = Math.ceil(ni * (r ? 3 : 1.5)), a = new Float32Array(i), o = 7103 + n * 197, s = 0, c = 0, l = 0, u = (e, t) => Math.sin(2 * Math.PI * e * t), d = {
		lowTom: 100,
		midTom: 142,
		highTom: 195,
		lowConga: 210,
		highConga: 310
	};
	for (let t = 0; t < i; t++) {
		o ^= o << 13, o ^= o >>> 17, o ^= o << 5;
		let n = (o >>> 0) / 2 ** 31 - 1, r = t / ni;
		s = .65 * s + .35 * n;
		let f = n - c;
		c = n;
		let p = 0;
		if (e === "kick") l += 2 * Math.PI * (54 + 120 * Math.exp(-r * 80)) / ni, p = Math.sin(l) * Math.exp(-r * 9) + .28 * s * Math.exp(-r * 170) + .1 * u(105, r) * Math.exp(-r * 25);
		else if (e === "snare") p = (.55 * u(185, r) + .28 * u(331, r)) * Math.exp(-r * 25) + .75 * (n - s) * Math.exp(-r * 15);
		else if (e === "rim") p = (u(420, r) + .65 * u(1750, r) + .35 * u(3100, r)) * Math.exp(-r * 85) + n * .25 * Math.exp(-r * 300);
		else if (e === "clap") {
			let e = [
				0,
				.011,
				.024
			].reduce((e, t) => e + (r >= t ? Math.exp(-(r - t) * 230) : 0), 0);
			p = (n - s) * (e + (r > .035 ? .65 * Math.exp(-(r - .035) * 16) : 0));
		} else if (e in d) {
			let t = d[e], n = e.includes("Conga");
			l += 2 * Math.PI * t * (1 + .55 * Math.exp(-r * 55)) / ni, p = (Math.sin(l) + .3 * u(t * (n ? 2.14 : 1.59), r)) * Math.exp(-r * (n ? 14 : 8)) + .22 * s * Math.exp(-r * 95);
		} else if (e === "bell") p = (u(540, r) + .65 * u(800, r) + .22 * u(1620, r)) * Math.exp(-r * 11);
		else {
			let t = [
				3421,
				4517,
				5683,
				7129,
				9181
			].reduce((t, n, i) => t + u(n * (e === "ride" ? .68 : 1), r) / (i + 2), 0), n = e === "hat" ? 34 : e === "open" ? 5 : e === "crash" ? 1.8 : e === "ride" ? 2.3 : e === "cabasa" ? 32 : 16;
			p = ((e === "cabasa" ? 0 : .4) * t + (e === "ride" ? .2 : .65) * f) * Math.exp(-r * n), e === "tambourine" && (p *= .65 + .35 * u(85, r)), e === "crash" && (p *= Math.min(1, r * 180));
		}
		let m = Math.tanh(p), h = Math.sign(m) * Math.log1p(255 * Math.abs(m)) / Math.log(256), g = Math.round(h * 127) / 127;
		a[t] = Math.sign(g) * Math.expm1(Math.abs(g) * Math.log(256)) / 255 * Math.min(1, t / 12) * Math.min(1, (i - 1 - t) / 128);
	}
	return ri.set(e, a), a;
}
var ai = {
	rate: ni,
	sample: ii,
	chokedBy: { open: ["hat"] }
}, oi = (e, t) => si(e, t, ai);
function si(e, t, { rate: n, sample: r, chokedBy: i = {}, peak: a = 1.6, tone: o = (e) => 700 * 20 ** e }) {
	let s = /* @__PURE__ */ new Map(), c = /* @__PURE__ */ new Set(), l = (e) => [e, ...i[e] ?? []], u = (e) => {
		if (c.delete(e)) for (let t of [
			e.source,
			e.gain,
			e.filter,
			e.pan
		]) t.disconnect();
	};
	function d(t) {
		let n = e.currentTime, r = /* @__PURE__ */ new Map();
		for (let e of c) {
			let t = r.get(e.voice) ?? [];
			t.push(e), r.set(e.voice, t);
		}
		for (let e of r.values()) e.sort((e, t) => e.start - t.start);
		for (let [e, i] of r) if (!t || l(e).includes(t)) for (let t of i) {
			let i = l(e).flatMap((e) => r.get(e) ?? []).filter((n) => n.start > t.start || n.voice !== e && n.start === t.start).reduce((e, t) => !e || t.start < e.start ? t : e, void 0)?.start ?? Infinity, a = t.gain.gain, o = (e) => t.peak * Math.min(1, Math.max(0, e - t.start) / .001) * Math.exp(-Math.max(0, e - t.start - .001) * 4.6 / t.decay);
			a.cancelScheduledValues(n), n < t.start + .001 ? (a.setValueAtTime(o(n), n), a.setValueAtTime(0, Math.max(n, t.start)), a.linearRampToValueAtTime(t.peak, t.start + .001)) : a.setValueAtTime(i < n ? o(i) * Math.max(0, 1 - (n - i) / .004) : o(n), n), a.setTargetAtTime(0, Math.max(n, t.start + .001), t.decay / 4.6), i >= n && i < t.end && (a.cancelScheduledValues(i), a.setValueAtTime(o(i), i), a.linearRampToValueAtTime(0, i + .004)), t.source.stop(Math.max(n, Math.min(t.end, i + .005)));
		}
	}
	return {
		trigger(i, l, f, p = 1) {
			let m = s.get(i);
			if (!m) {
				let t = r(i);
				m = e.createBuffer(1, t.length, n), m.copyToChannel(new Float32Array(t), 0), s.set(i, m);
			}
			let h = e.createBufferSource(), g = e.createGain(), _ = e.createBiquadFilter(), v = e.createStereoPanner();
			h.buffer = m, h.playbackRate.value = 2 ** (f[`${i}Tune`] / 12), _.type = "lowpass", _.frequency.value = Math.min(2e4, o(f[`${i}Tone`])), _.Q.value = -3.01, v.pan.value = f[`${i}Pan`], g.gain.value = 0, h.connect(_).connect(g).connect(v).connect(t);
			let y = {
				voice: i,
				start: l,
				end: l + Math.min(m.duration / h.playbackRate.value, f[`${i}Decay`] * 2) + .01,
				peak: f[`${i}Level`] * a * p,
				decay: f[`${i}Decay`],
				source: h,
				gain: g,
				filter: _,
				pan: v
			};
			h.onended = () => u(y), c.add(y), h.start(l), d(i);
		},
		cancelScheduled(e) {
			for (let t of [...c]) t.start >= e && (t.source.stop(e), u(t));
			d();
		},
		dispose() {
			for (let e of [...c]) e.source.stop(), u(e);
			s.clear();
		}
	};
}
// src/audio/poly.ts
var ci = .005;
function li(e, t, n = (e) => e) {
	let r = () => {
		let n = t(e.createConstantSource());
		return n.offset.value = 0, Zr(n.offset, e), n;
	}, i = r(), a = r();
	return {
		bend: i,
		mod: a,
		move: (t, r, o, s = !1) => {
			let c = (t === "bend" ? i : a).offset, l = Math.max(o, e.currentTime);
			s && Qr(c, l), c.setTargetAtTime(t === "bend" ? Math.max(-1, Math.min(1, r)) : n(Math.max(0, Math.min(1, r))), l, ci);
		}
	};
}
function ui(e, t) {
	let n = !1, r;
	return (i, a) => {
		if (clearTimeout(r), r = void 0, i && !n) e.connect(t), n = !0;
		else if (!i && n) {
			let i = () => {
				r = void 0, n = !1;
				try {
					e.disconnect(t);
				} catch {}
			};
			a ? i() : r = setTimeout(i, 100);
		}
	};
}
var di = class {
	voices;
	constructor(e = 5) {
		this.voices = Array.from({ length: e }, () => ({
			key: null,
			start: -Infinity,
			releaseAt: -Infinity,
			freeAt: -Infinity
		}));
	}
	allocate(e, t = /* @__PURE__ */ new Set()) {
		let n = this.voices.map((e, t) => ({
			voice: e,
			index: t
		})).filter(({ index: e }) => !t.has(e)), r = (e, t) => e.reduce((e, n) => t(n.voice) < t(e.voice) ? n : e).index, i = n.filter(({ voice: t }) => t.freeAt <= e), a = n.filter(({ voice: t }) => t.releaseAt <= e);
		return i.length ? r(i, (e) => e.freeAt) : a.length ? r(a, (e) => e.releaseAt) : r(n, (e) => e.start);
	}
	start(e, t, n) {
		Object.assign(this.voices[e], {
			key: t,
			start: n,
			releaseAt: Infinity,
			freeAt: Infinity
		});
	}
	release(e, t, n) {
		return this.voices.flatMap((r, i) => {
			if (n !== void 0 && r.key !== n || r.releaseAt <= e) return [];
			let a = r.start > e;
			return Object.assign(r, {
				start: Math.min(r.start, e),
				releaseAt: e,
				freeAt: e + t
			}), [{
				index: i,
				pending: a
			}];
		});
	}
}, fi = (e, t) => Math.sin(2 * Math.PI * e * t);
function pi(e, t, n) {
	let r = new Float32Array(Math.ceil(e * t));
	return {
		data: r,
		each(t) {
			let i = n, a = 0;
			for (let n = 0; n < r.length; n++) {
				i ^= i << 13, i ^= i >>> 17, i ^= i << 5;
				let o = (i >>> 0) / 2 ** 31 - 1;
				a = .7 * a + .3 * o, r[n] = t(n / e, {
					noise: o,
					low: a,
					high: o - a,
					sin: fi
				}) * Math.min(1, n / 8) * Math.min(1, (r.length - 1 - n) / 256);
			}
		}
	};
}
function mi(e, t) {
	let n = 0;
	for (let t of e) n = Math.max(n, Math.abs(t));
	if (n > 0) for (let r = 0; r < e.length; r++) e[r] *= t / n;
}
// src/audio/forge.ts
var hi = 44100, gi = /* @__PURE__ */ new Map();
function _i(e, t, n, r) {
	let i = r, a = () => (i = i * 16807 % 2147483647, i / 2147483647);
	return Array.from({ length: e }, () => ({
		frequency: t * (n / t) ** a(),
		level: .4 + a(),
		decay: .6 + a(),
		phase: a() * 2 * Math.PI
	}));
}
function vi(e) {
	let t = gi.get(e);
	if (t) return t;
	let n = gt.findIndex((t) => t.id === e);
	if (n < 0) throw Error(`Unknown FORGE voice: ${e}`);
	let { data: r, each: i } = pi(hi, {
		crash: 4,
		china: 3,
		ride: 4,
		open: 2,
		anvil: 2,
		lowTom: 1.6,
		highTom: 1.3,
		kick: 1.2,
		snare: 1
	}[e] ?? .5, 9241 + n * 173), a = {
		hat: [
			26,
			3e3,
			14e3
		],
		pedal: [
			26,
			3e3,
			14e3
		],
		open: [
			30,
			2600,
			13e3
		],
		crash: [
			44,
			1800,
			12500
		],
		china: [
			40,
			1100,
			9e3
		],
		ride: [
			28,
			2400,
			11e3
		]
	}[e], o = a ? _i(a[0], a[1], a[2], 77 + n * 31) : [], s = o.map((e) => Math.sin(e.phase)), c = o.map((e) => Math.cos(e.phase)), l, u = (e, t) => {
		l ??= o.map((e) => ({
			cos: Math.cos(2 * Math.PI * e.frequency / hi),
			sin: Math.sin(2 * Math.PI * e.frequency / hi),
			fall: Math.exp(-t * e.decay / hi)
		}));
		let n = 0;
		for (let e = 0; e < o.length; e++) {
			let { cos: t, sin: r, fall: i } = l[e], a = s[e], u = c[e];
			n += o[e].level * a, s[e] = (a * t + u * r) * i, c[e] = (u * t - a * r) * i;
		}
		return n / o.length;
	}, d = 0, f = 0;
	return i((t, { noise: n, high: r, sin: i }) => {
		if (f = .55 * f + .45 * r, e === "kick") {
			d += 2 * Math.PI * (52 + 88 * Math.exp(-t * 35)) / hi;
			let e = Math.sin(d) * Math.exp(-t * 6.5), n = r * Math.exp(-t * 600) + .5 * i(3200, t) * Math.exp(-t * 300);
			return Math.tanh(2.6 * (e + .55 * n));
		}
		if (e === "snare") {
			let e = i(190, t) * Math.exp(-t * 22) + .6 * i(287, t) * Math.exp(-t * 28) + .35 * i(412, t) * Math.exp(-t * 35), r = f * Math.exp(-t * 10), a = n * Math.exp(-t * 220);
			return Math.tanh(1.9 * (.7 * e + 1.1 * r + .6 * a));
		}
		return e === "lowTom" || e === "highTom" ? (d += 2 * Math.PI * (e === "lowTom" ? 82 : 132) * (1 + .3 * Math.exp(-t * 30)) / hi, Math.tanh(1.5 * ((Math.sin(d) + .25 * Math.sin(1.52 * d)) * Math.exp(-t * (e === "lowTom" ? 4.5 : 5.5)) + .4 * r * Math.exp(-t * 300)))) : e === "anvil" ? [
			[1, 4],
			[2.76, 6],
			[5.4, 9],
			[8.93, 13]
		].reduce((e, [n, r], a) => e + i(520 * n, t) * Math.exp(-t * r) / (a + 1), 0) + .6 * r * Math.exp(-t * 500) : e === "hat" ? .7 * u(t, 40) + .55 * f * Math.exp(-t * 55) + .5 * r * Math.exp(-t * 900) : e === "pedal" ? (.6 * u(t, 30) + .4 * f * Math.exp(-t * 35)) * Math.min(1, t * 400) : e === "open" ? .7 * u(t, 3.2) + .45 * f * Math.exp(-t * 4.5) + .4 * r * Math.exp(-t * 700) : e === "crash" ? (.8 * u(t, 1.3) + .6 * f * Math.exp(-t * 2.2)) * Math.min(1, t * 250) : e === "china" ? (.8 * u(t, 2.2) * (1 + .6 * i(370, t)) + .6 * f * Math.exp(-t * 3)) * Math.min(1, t * 300) : .55 * u(t, 1.1) + (.5 * i(3150, t) + .35 * i(4270, t)) * Math.exp(-t * 4) + .15 * f * Math.exp(-t * 2) + .4 * r * Math.exp(-t * 800);
	}), mi(r, .9), gi.set(e, r), r;
}
function yi(e) {
	let t = e.createBuffer(2, Math.ceil(e.sampleRate * .34), e.sampleRate), n = 31337;
	for (let r = 0; r < 2; r++) {
		let i = t.getChannelData(r);
		for (let t = 0; t < i.length; t++) {
			n ^= n << 13, n ^= n >>> 17, n ^= n << 5;
			let r = t / e.sampleRate;
			i[t] = ((n >>> 0) / 2 ** 31 - 1) * Math.exp(-r * 3) * Math.min(1, (i.length - 1 - t) / 64) * .35;
		}
	}
	return t;
}
var bi = {
	rate: hi,
	sample: vi,
	chokedBy: { open: ["hat", "pedal"] },
	peak: 1.4,
	tone: (e) => 1200 * 16 ** e
};
function xi(e, t, n) {
	let r = n(e.createGain()), i = n(e.createGain()), a = n(e.createWaveShaper()), o = n(e.createGain()), s = n(e.createConvolver()), c = n(e.createGain());
	a.curve = Float32Array.from({ length: 2049 }, (e, t) => {
		let n = (t / 1024 - 1) * 6;
		return Math.max(-1, Math.min(1, n > 0 ? Math.tanh(n) : Math.tanh(1.4 * n) * .9));
	}), a.oversample = "2x", r.connect(i).connect(t), a.connect(o).connect(t), s.buffer = yi(e), s.connect(c).connect(t);
	let l = ui(r, a), u = ui(i, s), d = 0, f, p = () => {
		d < gt.length && (vi(gt[d++].id), f = setTimeout(p, 0));
	};
	f = setTimeout(p, 0);
	let m = !1;
	return {
		input: r,
		classic: () => si(e, r, bi),
		dispose() {
			clearTimeout(f);
		},
		apply(t) {
			let n = (t, n) => {
				m ? t.setTargetAtTime(n, e.currentTime, .01) : t.value = n;
			};
			l(t.drive > 0, !m), u(t.room > 0, !m), n(i.gain, 1 - .45 * t.drive), n(o.gain, .75 * t.drive), n(c.gain, t.room * .9), m = !0;
		}
	};
}
// src/audio/prism-processor.js?raw
var Si = "/** Self-contained phase-modulation DSP, imported directly by tests and as inline source by the worklet loader. */\nexport const ALGORITHMS = [\n  {inputs: [[1], [], [3], [], [5], []], carriers: [0, 2, 4]},\n  {inputs: [[1], [2], [], [4], [5], []], carriers: [0, 3]},\n  {inputs: [[1], [2], [3], [4], [5], []], carriers: [0]},\n  {inputs: [[3], [3], [3], [4, 5], [], []], carriers: [0, 1, 2]},\n  {inputs: [[1, 2], [3], [4], [], [5], []], carriers: [0]},\n  {inputs: [[], [], [], [], [], []], carriers: [0, 1, 2, 3, 4, 5]},\n];\nconst TAU = 2 * Math.PI, QUANTUM = 128;\n/** Blocks a voice's ladder keeps running after the voice ends, so its tail rings out (about 23 ms). */\nconst FILTER_TAIL = 8;\n/** The gain that matches the Ladder filter's level to Off at PRISM's default settings. */\nexport const FILTER_LEVEL = 1.02;\n/** How far the mod wheel lifts Brightness at full Mod range on EG bias, and how deep its tremolo goes on Amp. */\nexport const EG_BIAS = 1.5, TREMOLO = 0.5;\n/**\n * `makeFilter`, when given, makes one Rust ladder (a LadderDSP) per voice for the Filter section; without it PRISM plays\n * unfiltered, as it did before the section existed.\n */\nexport class PrismDSP {\n  constructor(rate, makeFilter) {\n    this.rate = rate; this.events = []; this.params = {}; this.level = 0; this.disposed = false;\n    this.makeFilter = makeFilter; this.filters = []; this.wet = 0; this.fade = 1 - Math.exp(-1 / (0.008 * rate));\n    if (makeFilter) {\n      this.voiceOut = Array.from({length: 16}, () => new Float32Array(QUANTUM));\n      this.voiceDetune = Array.from({length: 16}, () => new Float32Array(QUANTUM));\n      this.used = new Uint8Array(16); this.tails = new Uint8Array(16);\n      this.dry = new Float32Array(QUANTUM); this.wets = new Float32Array(QUANTUM); this.levels = new Float32Array(QUANTUM);\n    }\n    this.voices = Array.from({length: 16}, () => ({key: null, start: -Infinity, released: -Infinity, free: -Infinity,\n      phase: new Float64Array(6), env: new Float64Array(6), stage: new Uint8Array(6), attackStep: new Float64Array(6), releaseStep: new Float64Array(6), values: new Float64Array(6), frequency: 0, velocity: 1, feedback: 0, lastFeedback: 0}));\n  }\n  enqueue(event) {\n    if (event.type === 'off') this.events = this.events.filter(e => !(e.time >= event.time && (event.key === undefined || e.key === event.key) && (e.type === 'on' || e.type === 'off')));\n    this.events.push(event); this.events.sort((a, b) => a.time - b.time);\n  }\n  release(time, key) {\n    for (const v of this.voices) if (v.key !== null && (key === undefined || v.key === key) && v.released === Infinity) {\n      v.released = time; v.free = time + Math.max(...this.ops.map(o => o.release));\n      for (let i = 0; i < 6; i++) {v.stage[i] = 3; v.releaseStep[i] = v.env[i] / (this.ops[i].release * this.rate);}\n    }\n  }\n  apply(event) {\n    if (event.type === 'params') {\n      this.params = event.params;\n      this.ops = Array.from({length: 6}, (_, i) => {const id = `op${i + 1}`, p = this.params; return {\n        ratio: p[`${id}Ratio`] * 2 ** (p[`${id}Detune`] / 1200), level: p[`${id}Level`], attack: p[`${id}Attack`],\n        decay: Math.exp(-1 / (p[`${id}Decay`] * this.rate / 4)), sustain: p[`${id}Sustain`], release: p[`${id}Release`],\n      };});\n    } else if (event.type === 'off') this.release(event.time, event.key);\n    else if (event.type === 'on' && this.ops) {\n      this.release(event.time, event.key);\n      const taken = new Set();\n      for (const note of event.notes) {\n        const available = this.voices.filter(v => !taken.has(v));\n        const silent = available.filter(v => v.free <= event.time), released = available.filter(v => v.released <= event.time);\n        const candidates = silent.length ? silent : released.length ? released : available;\n        const field = silent.length ? 'free' : released.length ? 'released' : 'start';\n        const v = candidates.reduce((a, b) => b[field] < a[field] ? b : a);\n        taken.add(v);\n        if (v.free <= event.time) {v.phase.fill(0); v.env.fill(0); v.feedback = 0; v.lastFeedback = 0;}\n        v.key = event.key; v.start = event.time; v.free = Infinity; v.released = Infinity;\n        v.frequency = 440 * 2 ** ((note - 69) / 12); v.cents = (note - 60) * 100; v.velocity = event.velocity;\n        for (let i = 0; i < 6; i++) {v.stage[i] = 0; v.attackStep[i] = (1 - v.env[i]) / (this.ops[i].attack * this.rate);}\n      }\n    }\n  }\n  /**\n   * `pitch` is the bend in cents, `brightness` the Brightness CV, and `wheel` the mod wheel from 0 to 1, which goes\n   * where wheelAssign says, as a DX7's wheel does: deeper vibrato, tremolo, or EG bias, which brightens the sound.\n   */\n  render(output, startFrame, pitch, brightness, wheel) {\n    if (this.disposed) {output.fill(0); return;}\n    // The per-voice filter buffers hold one render quantum, so longer renders (tests) go a quantum at a time.\n    if (this.makeFilter && output.length > QUANTUM) {\n      for (let i = 0; i < output.length; i += QUANTUM) this.render(output.subarray(i, i + QUANTUM), startFrame + i, pitch?.subarray(i, i + QUANTUM), brightness?.subarray(i, i + QUANTUM), wheel?.subarray(i, i + QUANTUM));\n      return;\n    }\n    // The Filter section crossfades in and out over 8 ms. While it is fully off, the original unfiltered path runs.\n    const filtering = !!this.makeFilter && (this.params.filterModel === 1 || this.wet > 0);\n    if (filtering) for (let i = 0; i < 16; i++) {this.voiceOut[i].fill(0); this.voiceDetune[i].fill(this.voiceDetune[i][QUANTUM - 1]);}\n    for (let n = 0; n < output.length; n++) {\n      const time = (startFrame + n) / this.rate;\n      while (this.events.length && this.events[0].time <= time) this.apply(this.events.shift());\n      if (!this.ops) {output[n] = 0; continue;}\n      const p = this.params, algorithm = ALGORITHMS[p.algorithm];\n      const mod = (wheel?.[n] ?? 0) * (p.wheelRange ?? 0), assign = p.wheelAssign ?? 0, lfo = Math.sin(TAU * p.lfoRate * time);\n      const bend = Math.max(-9600, Math.min(9600, (pitch?.[n] ?? 0) + lfo * (p.lfoDepth + (assign === 0 ? mod : 0)) * 100));\n      const tune = 2 ** (bend / 1200);\n      const color = Math.max(0, Math.min(4, p.brightness + (brightness?.[n] ?? 0) + (assign === 2 ? mod * EG_BIAS : 0)));\n      const tremolo = assign === 1 ? 1 - mod * TREMOLO * (1 + lfo) : 1;\n      let sum = 0;\n      for (let index = 0; index < this.voices.length; index++) {\n        const v = this.voices[index];\n        if (v.free <= time) continue;\n        const touch = 1 - p.velocity + p.velocity * v.velocity;\n        for (let i = 5; i >= 0; i--) {\n          const op = this.ops[i];\n          if (v.stage[i] === 0) {v.env[i] = Math.min(1, v.env[i] + v.attackStep[i]); if (v.env[i] >= 1) v.stage[i] = 1;}\n          else if (v.stage[i] === 1) v.env[i] = op.sustain + (v.env[i] - op.sustain) * op.decay;\n          else v.env[i] = Math.max(0, v.env[i] - v.releaseStep[i]);\n          const frequency = Math.min(this.rate * 0.45, v.frequency * tune * op.ratio);\n          // The step is under half a turn, so subtracting a turn wraps exactly as the remainder would.\n          v.phase[i] += TAU * frequency / this.rate; if (v.phase[i] >= TAU) v.phase[i] -= TAU;\n          // A released operator at zero contributes nothing, so its sine is skipped.\n          if (v.env[i] === 0) {v.values[i] = 0; continue;}\n          let modulation = i === 5 ? (v.feedback + v.lastFeedback) * 0.5 * p.feedback * 3.5 : 0;\n          const inputs = algorithm.inputs[i];\n          for (let k = 0; k < inputs.length; k++) modulation += v.values[inputs[k]] * 5 * color * touch;\n          v.values[i] = Math.sin(v.phase[i] + modulation) * v.env[i] * op.level;\n        }\n        v.lastFeedback = v.feedback; v.feedback = v.values[5];\n        let voice = 0;\n        for (let k = 0; k < algorithm.carriers.length; k++) voice += v.values[algorithm.carriers[k]];\n        voice = voice / Math.sqrt(algorithm.carriers.length) * v.velocity;\n        sum += voice;\n        if (filtering) {\n          // Each voice's ladder follows its first carrier's envelope and its note, including bends.\n          this.voiceOut[index][n] = voice; this.used[index] = 1;\n          this.voiceDetune[index][n] = p.filterEnv * 4800 * v.env[0] + p.filterTrack * (v.cents + bend);\n        }\n      }\n      this.level += (p.level - this.level) * 0.003;\n      if (!filtering) {output[n] = sum * this.level * tremolo * 0.18; continue;}\n      this.wet += ((p.filterModel === 1 ? 1 : 0) - this.wet) * this.fade;\n      if (this.wet < 1e-5 && p.filterModel !== 1) this.wet = 0;\n      this.dry[n] = sum; this.wets[n] = this.wet; this.levels[n] = this.level * tremolo;\n    }\n    if (filtering) this.mixFiltered(output);\n  }\n\n  /** Runs each sounding voice (and each ringing tail) through its ladder and crossfades the result with the dry mix. */\n  mixFiltered(output) {\n    const p = this.params, n = output.length;\n    output.fill(0);\n    for (let i = 0; i < 16; i++) {\n      if (this.used[i]) this.tails[i] = FILTER_TAIL;\n      if (!this.tails[i]) continue;\n      const filter = (this.filters[i] ??= this.makeFilter()), buffer = this.voiceOut[i];\n      filter.render(buffer, buffer, p.filterCutoff, p.filterResonance, p.filterDrive, this.voiceDetune[i], 0);\n      for (let k = 0; k < n; k++) output[k] += buffer[k];\n      if (!this.used[i]) this.tails[i]--;\n      this.used[i] = 0;\n    }\n    for (let k = 0; k < n; k++) output[k] = (this.dry[k] * (1 - this.wets[k]) + output[k] * FILTER_LEVEL * this.wets[k]) * this.levels[k] * 0.18;\n  }\n\n  dispose() {\n    this.disposed = true; this.events = [];\n    for (const filter of this.filters) filter?.dispose();\n    this.filters = [];\n  }\n}\n// The guard lets unit tests import the exact processor DSP without an audio environment.\nif (typeof registerProcessor !== 'undefined') {\n  class PrismProcessor extends AudioWorkletProcessor {\n    constructor(options) {\n      // dsp-processor.js shares its ladder through the global scope; without the Rust DSP, PRISM plays unfiltered.\n      const module = options?.processorOptions?.module, Ladder = globalThis.RacklooseDSP?.LadderDSP;\n      super(); this.dsp = new PrismDSP(sampleRate, module && Ladder ? () => new Ladder(module, sampleRate) : undefined);\n      this.port.onmessage = ({data}) => {\n        if (data.type === 'flush') this.port.postMessage({id: data.id});\n        else if (data.type === 'dispose') this.dsp.dispose();\n        else this.dsp.enqueue(data);\n      };\n    }\n    process(inputs, outputs) {\n      this.dsp.render(outputs[0][0], currentFrame, inputs[0]?.[0], inputs[1]?.[0], inputs[2]?.[0]);\n      return !this.dsp.disposed;\n    }\n  }\n  registerProcessor('rackloose-prism-v1', PrismProcessor);\n}\n", Ci = "/** Original behavioral models, not measured circuit replicas. See docs/studio-processors.md for calibration and sources. */\nexport const COHERE_ATTACKS = [0.0001, 0.0003, 0.001, 0.003, 0.01, 0.03];\nexport const COHERE_RELEASES = [0.1, 0.3, 0.6, 1.2];\nexport const TALON_RATIOS = [1, 2, 3, 4, 6, 10, 20, 100];\nexport const BRIT_LOW = [35, 60, 110, 220];\nexport const BRIT_MID = [360, 700, 1600, 3200, 4800, 7200];\nexport const BRIT_HP = [0, 50, 80, 160, 300];\nconst db = x => 10 ** (x / 20);\nconst unity = [1, 0, 0, 0, 0];\n\n/** Normalized biquads and one pole filters. A third-order Butterworth HP is a first order plus a Q=1 biquad. */\nexport function coefficients(type, frequency, gain, Q, rate) {\n  if (!frequency) return unity.slice();\n  const w = 2 * Math.PI * Math.min(frequency, rate * 0.45) / rate, c = Math.cos(w), s = Math.sin(w);\n  const A = 10 ** (gain / 40), alpha = s / (2 * Q), shelf = s * Math.sqrt(2 * A);\n  let b0, b1, b2, a0, a1, a2;\n  if (type === 'pole') {\n    const k = Math.tan(w / 2); return [1 / (1 + k), -1 / (1 + k), 0, (k - 1) / (k + 1), 0];\n  } else if (type === 'highpass') {\n    [b0, b1, b2, a0, a1, a2] = [(1 + c) / 2, -(1 + c), (1 + c) / 2, 1 + alpha, -2 * c, 1 - alpha];\n  } else if (type === 'bell') {\n    [b0, b1, b2, a0, a1, a2] = [1 + alpha * A, -2 * c, 1 - alpha * A, 1 + alpha / A, -2 * c, 1 - alpha / A];\n  } else if (type === 'low') {\n    [b0, b1, b2, a0, a1, a2] = [A * (A + 1 - (A - 1) * c + shelf), 2 * A * (A - 1 - (A + 1) * c), A * (A + 1 - (A - 1) * c - shelf), A + 1 + (A - 1) * c + shelf, -2 * (A - 1 + (A + 1) * c), A + 1 + (A - 1) * c - shelf];\n  } else {\n    [b0, b1, b2, a0, a1, a2] = [A * (A + 1 + (A - 1) * c + shelf), -2 * A * (A - 1 + (A + 1) * c), A * (A + 1 + (A - 1) * c - shelf), A + 1 - (A - 1) * c + shelf, 2 * (A - 1 - (A + 1) * c), A + 1 - (A - 1) * c - shelf];\n  }\n  return [b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0];\n}\nexport function britFilters(p, rate) {\n  const hp = BRIT_HP[p.hpf] ?? 0;\n  return [coefficients('pole', hp, 0, 1, rate), coefficients('highpass', hp, 0, 1, rate),\n    coefficients('low', BRIT_LOW[p.lfFreq] ?? 110, p.lfGain, 0.7, rate),\n    coefficients('bell', BRIT_MID[p.midFreq] ?? 1600, p.midGain, 0.75, rate), coefficients('high', 12000, p.hfGain, 0.7, rate)];\n}\nexport function britResponse(p, frequency, rate = 48000) {\n  if (p.active) return 0;\n  const w = 2 * Math.PI * frequency / rate;\n  const magnitude = (a, b, c) => Math.hypot(a + b * Math.cos(w) + c * Math.cos(2 * w), b * Math.sin(w) + c * Math.sin(2 * w));\n  return britFilters(p, rate).reduce((sum, [b0, b1, b2, a1, a2]) => sum + 20 * Math.log10(magnitude(b0, b1, b2) / magnitude(1, a1, a2)), 0);\n}\n\n/** Each TALON mode has its own threshold and knee; Input drives a fixed characteristic instead of moving a threshold. */\nfunction curveSettings(type, p) {\n  let ratio, threshold, knee;\n  if (type === 'cohere') {\n    ratio = [2, 4, 10][p.ratio] ?? 4;\n    threshold = p.threshold + [-3, 0, 2][p.ratio]; knee = [9, 6, 3][p.ratio];\n  } else {\n    ratio = TALON_RATIOS[p.ratio] ?? 6;\n    threshold = [-18, -26, -24, -22, -20, -18, -16, -18][p.ratio];\n    knee = [0, 15, 12, 9, 6, 4, 2, 3][p.ratio];\n    if (p.fierce) {ratio = Math.max(12, ratio * 2); threshold -= 3; knee = 2;}\n  }\n  return [1 - 1 / ratio, threshold, knee];\n}\nfunction curveGain(level, slope, threshold, knee) {\n  if (!slope) return 0;\n  const over = level - threshold;\n  return over <= -knee / 2 ? 0 : over >= knee / 2 ? -over * slope : -slope * (over + knee / 2) ** 2 / (2 * knee);\n}\nexport function compressionCurve(type, level, p) {return curveGain(level, ...curveSettings(type, p));}\n\nclass Filter {\n  constructor(rate) {this.c = unity.slice(); this.target = unity.slice(); this.z1 = 0; this.z2 = 0; this.smooth = 1 - Math.exp(-1 / (rate * 0.008));}\n  set(c, initial) {this.target = c; if (initial) this.c = c.slice();}\n  run(x) {\n    const c = this.c;\n    for (let i = 0; i < 5; i++) c[i] += (this.target[i] - c[i]) * this.smooth;\n    const y = c[0] * x + this.z1;\n    this.z1 = c[1] * x - c[3] * y + this.z2; this.z2 = c[2] * x - c[4] * y;\n    return y;\n  }\n}\n\n// 4x interpolation/decimation of the nonlinear residual only: linear audio keeps its full bandwidth.\n// Two symmetric 49-tap Blackman-windowed sinc FIRs give exactly 12 base-rate samples of delay.\nexport const FIR = Float64Array.from({length: 49}, (_, i) => {\n  const n = i - 24, cutoff = 0.1125;\n  return (n ? Math.sin(2 * Math.PI * cutoff * n) / (Math.PI * n) : 2 * cutoff) * (0.42 - 0.5 * Math.cos(2 * Math.PI * i / 48) + 0.08 * Math.cos(4 * Math.PI * i / 48));\n});\nconst total = FIR.reduce((sum, x) => sum + x, 0); for (let i = 0; i < FIR.length; i++) FIR[i] /= total;\nclass Fir {\n  constructor() {this.buffer = new Float64Array(49); this.index = 0;}\n  /** Stores `x` without computing an output, for decimation steps whose output is discarded. */\n  push(x) {this.buffer[this.index] = x; this.index = (this.index + 1) % 49;}\n  run(x) {\n    this.buffer[this.index] = x; let sum = 0, at = this.index;\n    for (let i = 0; i < 49; i++) {sum += FIR[i] * this.buffer[at]; if (--at < 0) at = 48;}\n    this.index = (this.index + 1) % 49; return sum;\n  }\n}\n/**\n * The FIR over a 4x zero-stuffed signal, computed polyphase: phase `i` reads only the taps that meet a real sample,\n * in the same order, so it matches the full filter exactly at a quarter of the work.\n */\nclass Interpolator {\n  constructor() {this.buffer = new Float64Array(13); this.index = 0;}\n  push(x) {this.index = this.index ? this.index - 1 : 12; this.buffer[this.index] = x;}\n  run(phase) {\n    let sum = 0, at = this.index;\n    for (let k = phase; k < 49; k += 4) {sum += FIR[k] * this.buffer[at]; if (++at > 12) at = 0;}\n    return sum;\n  }\n}\nexport const STUDIO_LATENCY = 12;\nclass Delay {\n  constructor() {this.buffer = new Float64Array(STUDIO_LATENCY); this.index = 0;}\n  run(x) {const y = this.buffer[this.index]; this.buffer[this.index] = x; this.index = (this.index + 1) % this.buffer.length; return y;}\n}\nexport class Color {\n  constructor(rate) {this.up = new Interpolator(); this.down = new Fir(); this.clean = new Delay(); this.previous = 0; this.blocked = 0; this.dc = Math.exp(-2 * Math.PI * 5 / rate);}\n  run(x, amount, bias) {\n    let residual = 0;\n    const offset = Math.tanh(bias), slope = amount * (1 - offset * offset);\n    this.up.push(x * 4);\n    for (let i = 0; i < 4; i++) {\n      const up = this.up.run(i);\n      const shaped = (Math.tanh(amount * up + bias) - offset) / slope;\n      // Only every fourth decimated sample is kept, so the others are stored without being filtered.\n      if (i === 0) residual = this.down.run(shaped - up); else this.down.push(shaped - up);\n    }\n    // AC coupling of the nonlinear residual removes the DC generated by asymmetric coloration.\n    this.blocked = residual - this.previous + this.dc * this.blocked; this.previous = residual;\n    return this.clean.run(x) + this.blocked;\n  }\n}\n\nexport class StudioDSP {\n  constructor(type, rate) {\n    this.type = type; this.rate = rate; this.params = null; this.events = []; this.disposed = false; this.reduction = 0;\n    this.gain = [0, 0]; this.memory = [0, 0]; this.input = 1; this.output = 1; this.wet = 1; this.drive = 0;\n    this.smooth = 1 - Math.exp(-1 / (rate * 0.008));\n    this.channels = Array.from({length: 2}, () => ({filters: Array.from({length: 5}, () => new Filter(rate)),\n      hp: new Filter(rate), emphasis: new Filter(rate), audioPole: new Filter(rate), audioHp: new Filter(rate), color: new Color(rate), dry: new Delay(), clean: new Delay(), amount: 0.15, bias: 0}));\n  }\n  enqueue(event) {this.events.push(event); this.events.sort((a, b) => a.time - b.time);}\n  configure(p) {\n    const initial = !this.params; this.params = {...p};\n    this.inputTarget = db(this.type === 'talon' ? p.input : 0); this.outputTarget = db(p.output);\n    this.wetTarget = p.active ? 0 : 1; this.driveTarget = p.drive ?? 0;\n    if (initial) {this.input = this.inputTarget; this.output = this.outputTarget; this.wet = this.wetTarget; this.drive = this.driveTarget;}\n    if (this.type !== 'brit') {\n      this.curveTarget = curveSettings(this.type, p); this.linkTarget = this.type === 'cohere' ? 1 : p.link;\n      this.attackTarget = this.type === 'cohere' ? COHERE_ATTACKS[p.attack] : p.attack;\n      this.releaseTarget = this.type === 'cohere' ? COHERE_RELEASES[p.release] ?? 0.3 : p.release;\n      if (initial) {this.curve = this.curveTarget.slice(); this.link = this.linkTarget; this.attack = this.attackTarget; this.release = this.releaseTarget;}\n    }\n    for (const channel of this.channels) {\n      if (this.type === 'brit') britFilters(p, this.rate).forEach((c, i) => channel.filters[i].set(c, initial));\n      const hp = this.type === 'cohere' ? [0, 30, 60, 106, 125, 185][p.scHpf] : p.detectorHp ? 80 : 0;\n      channel.hp.set(coefficients('highpass', hp, 0, Math.SQRT1_2, this.rate), initial);\n      channel.emphasis.set(coefficients('bell', 6000, p.detectorBand ? 10 : 0, 1, this.rate), initial);\n      // Third-order Bessel HP, normalized to -3 dB at 65 Hz. Distinct from the detector filter.\n      channel.audioPole.set(coefficients('pole', p.audioHp ? 65 * 0.754 : 0, 0, 1, this.rate), initial);\n      channel.audioHp.set(coefficients('highpass', p.audioHp ? 65 * 0.691 : 0, 0, 0.691, this.rate), initial);\n      if (initial && this.type === 'talon') {channel.amount = [0.15, 0.8, 1.5][p.color]; channel.bias = p.color === 1 ? 0.3 : 0;}\n    }\n  }\n  envelope(level, channel) {\n    const p = this.params, target = curveGain(level, this.curve[0], this.curve[1], this.curve[2]), current = this.gain[channel];\n    // A slow reservoir makes Auto and Opto depend on both the depth and duration of preceding compression.\n    this.memory[channel] += (Math.max(0, -current) - this.memory[channel]) * (1 - Math.exp(-1 / (this.rate * 0.6)));\n    let release = this.release;\n    if (this.type === 'cohere' && p.release === 4) release = 0.1 + Math.min(1.1, this.memory[channel] * 0.09);\n    if (this.type === 'talon') {\n      if (p.ratio === 5) release = Math.min(20, this.release * (1 + this.memory[channel] * 0.9));\n      else if (p.ratio === 7) release *= 0.45 + Math.min(1.5, Math.max(0, -current) / 15);\n      else release *= [1, 1.15, 1.05, 1, 0.9, 1, 0.8, 1][p.ratio];\n      if (p.ratio !== 5) release = Math.min(3.5, release);\n      if (p.fierce) release *= 0.65;\n    }\n    const seconds = target < current ? this.attack : release;\n    this.gain[channel] += (target - current) * (1 - Math.exp(-1 / (seconds * this.rate)));\n    return db(this.gain[channel]);\n  }\n  render(inputs, outputs, startFrame = 0) {\n    if (this.disposed) {outputs.forEach(out => out.fill(0)); return;}\n    const frames = outputs[0].length;\n    for (let n = 0; n < frames; n++) {\n      const time = (startFrame + n) / this.rate;\n      while (this.events.length && this.events[0].time <= time) this.configure(this.events.shift().params);\n      if (!this.params) {outputs.forEach(out => {out[n] = 0;}); continue;}\n      const p = this.params;\n      this.input += (this.inputTarget - this.input) * this.smooth; this.output += (this.outputTarget - this.output) * this.smooth;\n      this.wet += (this.wetTarget - this.wet) * this.smooth; this.drive += (this.driveTarget - this.drive) * this.smooth;\n      const left = inputs[0]?.[n] ?? 0, right = inputs[1]?.[n] ?? left;\n      const l = left * this.input, r = right * this.input;\n      let gainL = 1, gainR = 1;\n      if (this.type !== 'brit') {\n        for (let i = 0; i < 3; i++) this.curve[i] += (this.curveTarget[i] - this.curve[i]) * this.smooth;\n        this.link += (this.linkTarget - this.link) * this.smooth;\n        this.attack += (this.attackTarget - this.attack) * this.smooth; this.release += (this.releaseTarget - this.release) * this.smooth;\n        const a = this.channels[0], b = this.channels[1];\n        const levelL = 20 * Math.log10(Math.max(1e-12, Math.abs(a.emphasis.run(a.hp.run(l)))));\n        const levelR = 20 * Math.log10(Math.max(1e-12, Math.abs(b.emphasis.run(b.hp.run(r)))));\n        const dominant = Math.max(levelL, levelR);\n        this.envelope(levelL + this.link * (dominant - levelL), 0); this.envelope(levelR + this.link * (dominant - levelR), 1);\n        // Converge existing independent histories continuously when linking, never copy one channel's gain instantly.\n        const commonGain = Math.min(this.gain[0], this.gain[1]), commonMemory = Math.max(this.memory[0], this.memory[1]), coupling = this.link * this.smooth;\n        for (let i = 0; i < 2; i++) {this.gain[i] += (commonGain - this.gain[i]) * coupling; this.memory[i] += (commonMemory - this.memory[i]) * coupling;}\n        gainL = db(this.gain[0]); gainR = db(this.gain[1]);\n        this.reduction = Math.min(this.gain[0], this.gain[1]) * this.wet;\n      }\n      for (let i = 0; i < outputs.length; i++) {\n        const channel = this.channels[i], raw = i === 0 ? left : right;\n        let wet = i === 0 ? l : r;\n        if (this.type === 'brit') {\n          for (const filter of channel.filters) wet = filter.run(wet);\n          wet = channel.color.run(wet, 0.22 * db(this.drive), 0.12);\n        } else if (this.type === 'talon') {\n          wet = channel.audioHp.run(channel.audioPole.run(wet * (i === 0 ? gainL : gainR)));\n          const amount = [0.15, 0.8, 1.5][p.color] * (1 + Math.min(2, -this.gain[i] / 20));\n          channel.amount += (amount - channel.amount) * this.smooth; channel.bias += ((p.color === 1 ? 0.3 : 0) - channel.bias) * this.smooth;\n          wet = channel.color.run(wet, channel.amount, channel.bias);\n        } else wet = channel.clean.run(wet * (i === 0 ? gainL : gainR));\n        const dry = channel.dry.run(raw);\n        outputs[i][n] = dry + this.wet * (wet * this.output - dry);\n      }\n    }\n  }\n}\n\nif (typeof registerProcessor !== 'undefined') {\n  class StudioProcessor extends AudioWorkletProcessor {\n    constructor(options) {\n      super(); this.dsp = new StudioDSP(options.processorOptions.type, sampleRate); this.meterFrames = 0;\n      this.port.onmessage = ({data}) => {\n        if (data.type === 'flush') this.port.postMessage({id: data.id});\n        else if (data.type === 'dispose') {this.dsp.disposed = true; this.dsp.events = [];}\n        else this.dsp.enqueue(data);\n      };\n    }\n    process(inputs, outputs) {\n      this.dsp.render(inputs[0] ?? [], outputs[0], currentFrame);\n      this.meterFrames += outputs[0][0].length;\n      if (this.meterFrames >= sampleRate / 25) {this.meterFrames = 0; this.port.postMessage({reduction: this.dsp.reduction});}\n      return !this.dsp.disposed;\n    }\n  }\n  registerProcessor('rackloose-studio-v1', StudioProcessor);\n}\n", wi = "/**\n * Hosts Rackloose's Rust DSP (crates/rackloose-dsp, compiled to WebAssembly): the zero-delay-feedback ladder filter\n * for MONARCH, ORACLE, AURORA and SIEVE, and the modeled drum engine for BOOM, PUNCH, ORBIT, STRIKE and FORGE. PRISM\n * reaches the ladder through `globalThis.RacklooseDSP`. Imported directly by tests and as inline source by the worklet\n * loader.\n *\n * Audio moves through fixed buffers in Wasm linear memory, so nothing allocates per block. Every processor in a context\n * shares one instance of the module, and every view is rebuilt when an allocation grows that memory.\n */\nconst RENDER_QUANTUM = 128, DRUM_PARAMS = 8;\nlet shared = null;\n\n/**\n * The context's one instance of the module. Every AudioWorkletNode receives its own structured clone of `module`, so the\n * instance belongs to the worklet scope (one per audio context) rather than to a module object: an instance per\n * processor would reserve a Wasm memory each, and enough of them exhaust the browser's Wasm address space. It needs no\n * imports, so instantiating is synchronous.\n */\nexport function wasmFor(module) {\n  shared ??= new WebAssembly.Instance(module, {}).exports;\n  return shared;\n}\n\n/** One ladder: cutoff, resonance and drive are smoothed in Rust; detune (cents) applies sample-exact. */\nexport class LadderDSP {\n  constructor(module, sampleRate) {\n    this.wasm = wasmFor(module);\n    this.ptr = this.wasm.ladder_new(sampleRate);\n    this.last = {cutoff: NaN, resonance: NaN, drive: NaN, mode: NaN};\n    this.fresh = true;\n    this.buffer = null;\n  }\n\n  views() {\n    const {memory, ladder_input_ptr, ladder_detune_ptr, ladder_output_ptr} = this.wasm;\n    this.buffer = memory.buffer;\n    this.input = new Float32Array(this.buffer, ladder_input_ptr(this.ptr), RENDER_QUANTUM);\n    this.detune = new Float32Array(this.buffer, ladder_detune_ptr(this.ptr), RENDER_QUANTUM);\n    this.output = new Float32Array(this.buffer, ladder_output_ptr(this.ptr), RENDER_QUANTUM);\n  }\n\n  /**\n   * Filters `input` (missing means silence) into `output`. `detune` holds one value for the block or one per sample;\n   * `mode` is 0 24 dB low-pass, 1 12 dB low-pass, 2 band-pass, 3 high-pass.\n   */\n  render(input, output, cutoff, resonance, drive, detune, mode = 0) {\n    if (!this.ptr) {output.fill(0); return;}\n    if (this.wasm.memory.buffer !== this.buffer) this.views();\n    const n = Math.min(output.length, RENDER_QUANTUM);\n    if (input) this.input.set(input.length > n ? input.subarray(0, n) : input); else this.input.fill(0, 0, n);\n    if (detune.length === 1) this.detune.fill(detune[0], 0, n); else this.detune.set(detune.length > n ? detune.subarray(0, n) : detune);\n    const {last, wasm, ptr} = this;\n    if (cutoff !== last.cutoff) wasm.ladder_set_cutoff(ptr, (last.cutoff = cutoff));\n    if (resonance !== last.resonance) wasm.ladder_set_resonance(ptr, (last.resonance = resonance));\n    if (drive !== last.drive) wasm.ladder_set_drive(ptr, (last.drive = drive));\n    if (mode !== last.mode) wasm.ladder_set_mode(ptr, (last.mode = mode));\n    // The first block starts on its settings instead of gliding from Rust's defaults.\n    if (this.fresh) {wasm.ladder_reset(ptr); this.fresh = false;}\n    wasm.ladder_process(ptr, n);\n    output.set(n === RENDER_QUANTUM ? this.output : this.output.subarray(0, n));\n  }\n\n  dispose() {\n    if (!this.ptr) return;\n    this.wasm.ladder_free(this.ptr);\n    this.ptr = 0;\n    this.input = this.detune = this.output = null;\n  }\n}\n\n/**\n * One drum machine. Hits arrive ahead of time as {time, voice, velocity, params} and start sample-accurately inside\n * the block that contains them; a late hit starts at the next block. `chokes` lists [voice, by] pairs.\n */\nexport class DrumsDSP {\n  constructor(module, sampleRate, kit, chokes = []) {\n    this.wasm = wasmFor(module);\n    this.rate = sampleRate;\n    this.ptr = this.wasm.drums_new(sampleRate, kit);\n    for (const [voice, by] of chokes) this.wasm.drums_choke(this.ptr, voice, by);\n    this.events = [];\n    this.buffer = null;\n  }\n\n  views() {\n    const {memory, drums_params_ptr, drums_output_ptr} = this.wasm;\n    this.buffer = memory.buffer;\n    this.params = new Float32Array(this.buffer, drums_params_ptr(this.ptr), DRUM_PARAMS);\n    this.left = new Float32Array(this.buffer, drums_output_ptr(this.ptr, 0), RENDER_QUANTUM);\n    this.right = new Float32Array(this.buffer, drums_output_ptr(this.ptr, 1), RENDER_QUANTUM);\n  }\n\n  /** Copies a sampled kit's one-shot for `voice` into Wasm memory. */\n  load(voice, pcm) {\n    if (!this.ptr) return;\n    const at = this.wasm.drums_load_sample(this.ptr, voice, pcm.length);\n    if (at) new Float32Array(this.wasm.memory.buffer, at, pcm.length).set(pcm);\n  }\n\n  enqueue(event) {\n    let i = this.events.length;\n    while (i > 0 && this.events[i - 1].time > event.time) i--;\n    this.events.splice(i, 0, event);\n  }\n\n  /** Drops hits scheduled at or after `time`. Hits already sounding keep their natural tails. */\n  cancel(time) {this.events = this.events.filter(event => event.time < time);}\n\n  render(left, right, startFrame) {\n    if (!this.ptr) {left.fill(0); right?.fill(0); return;}\n    if (this.wasm.memory.buffer !== this.buffer) this.views();\n    const n = Math.min(left.length, RENDER_QUANTUM), end = startFrame + n;\n    while (this.events.length && this.events[0].time * this.rate < end) {\n      const event = this.events.shift(), offset = Math.max(0, Math.floor(event.time * this.rate) - startFrame);\n      this.params.fill(0); this.params.set(event.params.slice(0, DRUM_PARAMS));\n      this.wasm.drums_trigger(this.ptr, event.voice, Math.min(offset, n - 1), event.velocity);\n    }\n    this.wasm.drums_process(this.ptr, n);\n    if (this.wasm.memory.buffer !== this.buffer) this.views();\n    left.set(n === RENDER_QUANTUM ? this.left : this.left.subarray(0, n));\n    right?.set(n === RENDER_QUANTUM ? this.right : this.right.subarray(0, n));\n  }\n\n  dispose() {\n    if (!this.ptr) return;\n    this.wasm.drums_free(this.ptr);\n    this.ptr = 0;\n    this.events = [];\n  }\n}\n\n// The guard lets unit tests import the exact processor DSP without an audio environment.\nif (typeof registerProcessor !== 'undefined') {\n  globalThis.RacklooseDSP = {LadderDSP, wasmFor};\n\n  class LadderProcessor extends AudioWorkletProcessor {\n    static get parameterDescriptors() {\n      return [\n        {name: 'cutoff', defaultValue: 1000, minValue: 20, maxValue: 20000, automationRate: 'k-rate'},\n        {name: 'resonance', defaultValue: 0, minValue: 0, maxValue: 1, automationRate: 'k-rate'},\n        {name: 'drive', defaultValue: 0, minValue: 0, maxValue: 1, automationRate: 'k-rate'},\n        {name: 'mode', defaultValue: 0, minValue: 0, maxValue: 3, automationRate: 'k-rate'},\n        // Cents, like BiquadFilterNode.detune, with its unbounded range. Rust clamps the resulting cutoff.\n        {name: 'detune', defaultValue: 0, automationRate: 'a-rate'},\n      ];\n    }\n    constructor({processorOptions}) {\n      super(); this.dsp = new LadderDSP(processorOptions.module, sampleRate);\n      this.port.onmessage = ({data}) => {\n        if (data.type === 'flush') this.port.postMessage({id: data.id});\n        else if (data.type === 'dispose') this.dsp.dispose();\n      };\n    }\n    process(inputs, outputs, parameters) {\n      if (!this.dsp.ptr) return false;\n      const {cutoff, resonance, drive, mode, detune} = parameters;\n      this.dsp.render(inputs[0]?.[0], outputs[0][0], cutoff[0], resonance[0], drive[0], detune, Math.round(mode[0]));\n      return true;\n    }\n  }\n  registerProcessor('rackloose-ladder-v1', LadderProcessor);\n\n  class DrumsProcessor extends AudioWorkletProcessor {\n    constructor({processorOptions: {module, kit, chokes}}) {\n      super(); this.dsp = new DrumsDSP(module, sampleRate, kit, chokes);\n      this.port.onmessage = ({data}) => {\n        if (data.type === 'hit') this.dsp.enqueue(data);\n        else if (data.type === 'sample') this.dsp.load(data.voice, data.pcm);\n        else if (data.type === 'cancel') this.dsp.cancel(data.time);\n        else if (data.type === 'flush') this.port.postMessage({id: data.id});\n        else if (data.type === 'dispose') this.dsp.dispose();\n      };\n    }\n    process(inputs, outputs) {\n      if (!this.dsp.ptr) return false;\n      const [left, right] = outputs[0];\n      this.dsp.render(left, right, currentFrame);\n      return true;\n    }\n  }\n  registerProcessor('rackloose-drums-v1', DrumsProcessor);\n}\n", Ti = "data:application/wasm;base64,AGFzbQEAAAABmwEXYAJ/fwF/YAN/f38Bf2ACf38AYAF/AGADf39/AGABfwF/YAR/f39/AGAEf39/fwF/YAAAYAJ9fwF/YAR/f399AGABfQF/YAJ/fQBgBX9/f39/AX9gBn9/f39/fwBgCX9/f39/f35+fgBgA399fwF/YAR/fX9/AX9gAX0BfWAGf39/f39/AX9gBX9+fn5+AGACfX8BfWACfX0BfQNoZwMABAUDBgIHBQMCBAYDBAQDAQgJAgAFAgMKBQMFCwUCAwwMAgwCAgICAAADBw0NAAIAAQAIAw4ADwQEAAEQEBEGCAICAgMDAwACAgQGAwIBAAEAAgICAgISEhMSEhQSEhISEhIVFhYEBQFwARUVBQMBABEGCQF/AUGAgMAACwffAhUGbWVtb3J5AgALZHJ1bXNfY2hva2UADwpkcnVtc19mcmVlABARZHJ1bXNfbG9hZF9zYW1wbGUAEQlkcnVtc19uZXcAExBkcnVtc19vdXRwdXRfcHRyABUQZHJ1bXNfcGFyYW1zX3B0cgAWDWRydW1zX3Byb2Nlc3MAFwtkcnVtc19yZXNldAAYDWRydW1zX3RyaWdnZXIAGRFsYWRkZXJfZGV0dW5lX3B0cgAaC2xhZGRlcl9mcmVlABsQbGFkZGVyX2lucHV0X3B0cgAcCmxhZGRlcl9uZXcAHRFsYWRkZXJfb3V0cHV0X3B0cgAeDmxhZGRlcl9wcm9jZXNzAB8MbGFkZGVyX3Jlc2V0ACARbGFkZGVyX3NldF9jdXRvZmYAIRBsYWRkZXJfc2V0X2RyaXZlACIPbGFkZGVyX3NldF9tb2RlACMUbGFkZGVyX3NldF9yZXNvbmFuY2UAJAkaAQBBAQsUAS8pKjFNT1BRUlNUVUdISUpCQ04K6voFZ9cDBAF/AX0BfgJ9I4CAgIAAQSBrIgEkgICAgAACQCAAKgLcDiICQwAAoEFgDQAgAUGAgICNBDYCCCABIAI4AgwgAUGBgICAAK1CIIYiAyABQQxqrYQ3AxggASADIAFBCGqthDcDEEHPgcCAACABQRBqQcSIwIAAEIKAgIAAAAsgAEMAAIA/IAJDAACgQSAAKgKwDSAAKgKoDUOaaxc6lJIQ2YCAgAAiBCAEQwAAoEFdGyIEIAQgAl4bQ9sPSUCUIAAqAtgOlRDjgICAACICQwAAgD+SlSIEOAKADyAAIAIgBJQiAjgC8A4gACACIAKUIgQ4AvQOIAAgBCAElCIFOAL8DiAAIAIgBJQ4AvgOIABDAACAP0MAAAAAIAAqArwNIgIgAkMAAAAAXRsiAiACQwAAgD9eG0MAAIBAlCICOAKEDyAAQwAAgD9DAAAAACAAKgLIDSIEIARDAAAAAF0bIgQgBEMAAIA/XhtDAABAQJQQ4YCAgAAiBDgCkA8gAEMAAIA/IASVOAKUDyAAQwAAgD8gBSAClEMAAIA/kpU4AowPIAAgAkMAAAA/lEMAAIA/kkMAAIA/IAAtAJwPQQJJGzgCiA8gACAEkYs4ApgPIAFBIGokgICAgAALgQECAn8CfSABKAIIIgJBgICAAXEhAyAAKgIAIQQCQCACQYCAgIABcQ0AAkAgBIsiBUPKGw5aYA0AIARDAAAAAFwgBUMXt9E4XXENACABIAQgA0EARxC9gICAAA8LIAEgBCADQQBHEL6AgIAADwsgASAEIANBAEcgAS8BDhC/gICAAAtHAQF/I4CAgIAAQSBrIgMkgICAgAAgAyABNgIQIAMgADYCDCADQQE7ARwgAyACNgIYIAMgA0EMajYCFCADQRRqEKuAgIAAAAuRBAEBf0EAIQECQCAAKAIAQQF0Qf///3dLDQAgACgCBEEBdEH///93Sw0AIAAoAghBAXRB////d0sNACAAKAIMQQF0Qf///3dLDQAgACgCEEEBdEH///93Sw0AIAAoAhRBAXRB////d0sNACAAKAIYQQF0Qf///3dLDQAgACgCHEEBdEH///93Sw0AIAAoAiBBAXRB////d0sNACAAKAIkQQF0Qf///3dLDQAgACgCKEEBdEH///93Sw0AIAAoAixBAXRB////d0sNACAAKAIwQQF0Qf///3dLDQAgACgCNEEBdEH///93Sw0AIAAoAjhBAXRB////d0sNACAAKAI8QQF0Qf///3dLDQAgACgCQEEBdEH///93Sw0AIAAoAkRBAXRB////d0sNACAAKAJIQQF0Qf///3dLDQAgACgCTEEBdEH///93Sw0AIAAoAlBBAXRB////d0sNACAAKAJUQQF0Qf///3dLDQAgACgCWEEBdEH///93Sw0AIAAoAlxBAXRB////d0sNACAAKAJgQQF0Qf///3dLDQAgACgCZEEBdEH///93Sw0AIAAoAmhBAXRB////d0sNACAAKAJsQQF0Qf///3dLDQAgACgCcEEBdEH///93Sw0AIAAoAnRBAXRB////d0sNACAAKAJ4QQF0Qf///3dLDQAgACgCfEEBdEH///93Sw0AQQEhAQsgAQt7AQN/I4CAgIAAQRBrIgEkgICAgAAgAUEEaiAAKAIAIgIgACgCBCACQQF0IgJBBCACQQRLGyICEIWAgIAAAkAgASgCBEEBRw0AIAEoAgggASgCDBCGgICAAAALIAEoAgghAyAAIAI2AgAgACADNgIEIAFBEGokgICAgAALkwEBAX9BASEEAkACQCADQa70ohdNDQBBACEDQQQhAQwBCyADQSxsIQMCQAJAAkACQCABRQ0AIAIgAUEsbEEEIAMQh4CAgAAhAQwBCwJAIAMNAEEEIQEMAgsgAxCIgICAACEBCyABDQAgAEEENgIEDAELIAAgATYCBEEAIQQLQQghAQsgACABaiADNgIAIAAgBDYCAAscAAJAIABFDQAgACABEJSAgIAAAAsQkoCAgAAAC68GAQd/AkACQAJAAkACQAJAIABBfGoiBCgCACIFQXhxIgZBBEEIIAVBA3EiBxsgAWpJDQACQCAHRQ0AIAYgAUEnaksNAgtBACEBQVBBACgCnKzAgAAiCGtBd3FBfWogA00NBUEQIANBC2pBeHEgA0ELSRshCSAAQXhqIQoCQAJAAkACQAJAIAdFDQAgCiAGaiEHIAYgCU8NAyAHQQAoAoSswIAARg0EIAdBACgCgKzAgABGDQIgBygCBCIFQQJxDQkgBUF4cSIFIAZqIgYgCUkNCSAHIAUQpYCAgAAgBiAJayIHQRBJDQEgBCAJIAQoAgBBAXFyQQJyNgIAIAogCWoiBSAHQQNyNgIEIAogBmoiBiAGKAIEQQFyNgIEIAUgBxCmgICAAAwICyAJQYACSQ0IIAYgCU0NCCAKRQ0IIAYgCWsgCEEBdEsNCCAADwsgBCAGIAQoAgBBAXFyQQJyNgIAIAogBmoiBiAGKAIEQQFyNgIEDAYLQQAoAvirwIAAIAZqIgYgCUkNBgJAAkAgBiAJayIHQQ9LDQAgBCAFQQFxIAZyQQJyNgIAIAogBmoiBiAGKAIEQQFyNgIEQQAhB0EAIQUMAQsgBCAJIAVBAXFyQQJyNgIAIAogCWoiBSAHQQFyNgIEIAogBmoiBiAHNgIAIAYgBigCBEF+cTYCBAtBACAFNgKArMCAAEEAIAc2AvirwIAADAULIAYgCWsiBkEPTQ0EIAQgCSAFQQFxckECcjYCACAKIAlqIgUgBkEDcjYCBCAHIAcoAgRBAXI2AgQgBSAGEKaAgIAADAQLQQAoAvyrwIAAIAZqIgYgCUsNAgwEC0HgosCAAEEuQZCjwIAAEI6AgIAAAAtBoKPAgABBLkHQo8CAABCOgICAAAALIAQgCSAFQQFxckECcjYCACAKIAlqIgcgBiAJayIGQQFyNgIEQQAgBjYC/KvAgABBACAHNgKErMCAAAsgCkUNACAADwsgAxCIgICAACIGRQ0AAkAgA0F8QXggBCgCACIBQQNxGyABQXhxaiIBIAMgAUkbIgNFDQAgBiAAIAP8CgAACyAAEI2AgIAAIAYhAQsgAQvKKAIIfwF+AkACQAJAAkAgAEH1AUkNAEEAIQFBUEEAKAKcrMCAAGtBd3FBfWogAE0NAyAAQQtqIgFBeHEhAkEAKAL0q8CAACIDRQ0CQR8hBCAAQfX//wdPDQEgAkEmIAFBCHZnIgBrdkEBcSAAQQF0ckE+cyEEDAELAkACQAJAAkACQAJAQQAoAvCrwIAAIgVBECAAQQtqQfgDcSAAQQtJGyICQQN2IgF2IgBBA3FFDQAgAEF/c0EBcSABaiIGQQN0IgBB6KnAgABqIgIgAEHwqcCAAGooAgAiASgCCCIHRg0BIAcgAjYCDCACIAc2AggMAgsgAkEAKAL4q8CAAE0NBgJAIAANAEEAKAL0q8CAACIARQ0HIABoQQJ0QdiowIAAaigCACIHKAIEQXhxIAJrIQEgByEFAkADQAJAIAcoAhAiAA0AIAcoAhQiAEUNAgsgACgCBEF4cSACayIHIAEgByABSSIHGyEBIAAgBSAHGyEFIAAhBwwACwsgBSgCGCEEAkACQAJAIAUoAgwiACAFRw0AIAVBFEEQIAUoAhQiABtqKAIAIgcNAUEAIQAMAgsgBSgCCCIHIAA2AgwgACAHNgIIDAELIAVBFGogBUEQaiAAGyEGA0AgBiEIIAciAEEUaiAAQRBqIAAoAhQiBxshBiAAQRRBECAHG2ooAgAiBw0ACyAIQQA2AgALIARFDQUCQAJAIAUgBSgCHEECdEHYqMCAAGoiBygCAEYNAAJAIAQoAhAgBUYNACAEIAA2AhQgAA0CDAgLIAQgADYCECAADQEMBwsgByAANgIAIABFDQULIAAgBDYCGAJAIAUoAhAiB0UNACAAIAc2AhAgByAANgIYCyAFKAIUIgdFDQUgACAHNgIUIAcgADYCGAwFCwJAAkAgACABdEECIAF0IgBBACAAa3JxaCIIQQN0IgFB6KnAgABqIgcgAUHwqcCAAGooAgAiACgCCCIGRg0AIAYgBzYCDCAHIAY2AggMAQtBACAFQX4gCHdxNgLwq8CAAAsgACACQQNyNgIEIAAgAWogASACayIHNgIAIAAgAmoiBSAHQQFyNgIEQQAoAvirwIAAIgJFDQJBACgCgKzAgAAhAQJAAkBBACgC8KvAgAAiBkEBIAJBA3Z0IghxDQBBACAGIAhyNgLwq8CAACACQXhxQeipwIAAaiICIQYMAQsgAkF4cSICQeipwIAAaiEGIAJB8KnAgABqKAIAIQILIAYgATYCCCACIAE2AgwgASAGNgIMIAEgAjYCCAwCC0EAIAVBfiAGd3E2AvCrwIAACyABIABBA3I2AgQgASAAaiIAIAAoAgRBAXI2AgQgAUEIag8LQQAgBTYCgKzAgABBACAHNgL4q8CAACAAQQhqDwtBAEEAKAL0q8CAAEF+IAUoAhx3cTYC9KvAgAALAkACQAJAIAFBEEkNACAFIAJBA3I2AgQgBSACaiIHIAFBAXI2AgQgByABaiABNgIAQQAoAvirwIAAIgZFDQFBACgCgKzAgAAhAAJAAkBBACgC8KvAgAAiCEEBIAZBA3Z0IgRxDQBBACAIIARyNgLwq8CAACAGQXhxQeipwIAAaiIGIQgMAQsgBkF4cSIGQeipwIAAaiEIIAZB8KnAgABqKAIAIQYLIAggADYCCCAGIAA2AgwgACAINgIMIAAgBjYCCAwBCyAFIAEgAmoiAEEDcjYCBCAFIABqIgAgACgCBEEBcjYCBAwBC0EAIAc2AoCswIAAQQAgATYC+KvAgAALIAVBCGoiAUUNAQwCC0EAIAJrIQECQAJAAkACQCAEQQJ0QdiowIAAaigCACIFDQBBACEHQQAhAAwBC0EAIQcgAkEAQRkgBEEBdmsgBEEfRht0IQZBACEAA0ACQCAFIgUoAgRBeHEiCCACSQ0AIAggAmsiCCABTw0AIAUhByAIIQEgCA0AQQAhASAFIQAgBSEHDAMLIAUoAhQiCCAAIAggBSAGQR12QQRxaigCECIFRxsgACAIGyEAIAZBAXQhBiAFDQALCwJAIAAgB3INAEEAIQdBAiAEdCIAQQAgAGtyIANxIgBFDQMgAGhBAnRB2KjAgABqKAIAIQALIABFDQELA0AgACgCBEF4cSIGIAJrIgUgASAFIAFJGyEIIAYgAkkhBiAHIAAgBSABTxshBAJAIAAoAhAiBQ0AIAAoAhQhBQsgASAIIAYbIQEgByAEIAYbIQcgBSEAIAUNAAsLIAdFDQACQEEAKAL4q8CAACIAIAJJDQAgASAAIAJrTw0BCyAHKAIYIQQCQAJAAkAgBygCDCIAIAdHDQAgB0EUQRAgBygCFCIAG2ooAgAiBQ0BQQAhAAwCCyAHKAIIIgUgADYCDCAAIAU2AggMAQsgB0EUaiAHQRBqIAAbIQYDQCAGIQggBSIAQRRqIABBEGogACgCFCIFGyEGIABBFEEQIAUbaigCACIFDQALIAhBADYCAAsCQCAERQ0AAkACQAJAIAcgBygCHEECdEHYqMCAAGoiBSgCAEYNAAJAIAQoAhAgB0YNACAEIAA2AhQgAA0CDAQLIAQgADYCECAADQEMAwsgBSAANgIAIABFDQELIAAgBDYCGAJAIAcoAhAiBUUNACAAIAU2AhAgBSAANgIYCyAHKAIUIgVFDQEgACAFNgIUIAUgADYCGAwBC0EAQQAoAvSrwIAAQX4gBygCHHdxNgL0q8CAAAsCQAJAIAFBEEkNACAHIAJBA3I2AgQgByACaiIAIAFBAXI2AgQgACABaiABNgIAAkAgAUGAAkkNACAAIAEQ1oCAgAAMAgsCQAJAQQAoAvCrwIAAIgVBASABQQN2dCIGcQ0AQQAgBSAGcjYC8KvAgAAgAUH4AXFB6KnAgABqIgEhBQwBCyABQfgBcSIBQeipwIAAaiEFIAFB8KnAgABqKAIAIQELIAUgADYCCCABIAA2AgwgACAFNgIMIAAgATYCCAwBCyAHIAEgAmoiAEEDcjYCBCAHIABqIgAgACgCBEEBcjYCBAsgB0EIaiIBDQELAkACQAJAQQAoAvirwIAAIgAgAk8NAAJAQQAoAvyrwIAAIgAgAksNAEEAIQEgAkEAKAKcrMCAACIAakEvakEAIABrcSIARQ0CQQAtAKSswIAAIQdBAEEBOgCkrMCAAEHArMCAACEFQYCAxIAAQcCswIAATQ0CIABBgIDEgABBwKzAgABrSw0CIAdB/wFxDQJBgIDEgABBwKzAgABrIQgMAwtBACAAIAJrIgE2AvyrwIAAQQBBACgChKzAgAAiACACaiIHNgKErMCAACAHIAFBAXI2AgQgACACQQNyNgIEIABBCGohAQwDC0EAKAKArMCAACEBAkACQCAAIAJrIgdBD0sNAEEAQQA2AoCswIAAQQBBADYC+KvAgAAgASAAQQNyNgIEIAEgAGoiACAAKAIEQQFyNgIEDAELQQAgBzYC+KvAgABBACABIAJqIgU2AoCswIAAIAUgB0EBcjYCBCABIABqIAc2AgAgASACQQNyNgIECyABQQhqDwsgAEEQdiAAQf//A3FBAEdqIgdAACIAQX9GDQFBACEBIABBEHQiBUUNASAHQRB0IgBBcGogACAFQQAgAGtGGyEIC0EAQQAoAoiswIAAIAhqIgA2AoiswIAAQQAgAEEAKAKMrMCAACIBIAAgAUsbNgKMrMCAAAJAAkACQAJAAkACQAJAAkACQAJAQQAoAoSswIAAIgFFDQBB2KnAgAAhAANAIAUgACgCACIHIAAoAgQiBmpGDQIgACgCCCIADQAMAwsLQQAoApSswIAAIgBFDQUgBSAASQ0FDAcLIAEgBU8NACAHIAFLDQAgACgCDEUNAQtBAEEAKAKUrMCAACIAIAUgACAFSRs2ApSswIAAIAUgCGohB0HYqcCAACEAAkACQAJAAkADQCAAKAIAIgYgB0YNASAAKAIIIgANAAwCCwsgACgCDEUNAQtB2KnAgAAhAANAAkAgACgCACIHIAFLDQAgASAHIAAoAgRqIgdJDQMLIAAoAgghAAwACwsgACAFNgIAIAAgACgCBCAIajYCBCAFQQ9qQXhxQXhqIgUgAkEDcjYCBCAGQQ9qQXhxQXhqIgcgBSACaiIAayEBIAdBACgChKzAgABGDQIgB0EAKAKArMCAAEYNAwJAIAcoAgQiAkEDcUEBRw0AIAcgAkF4cSICEKWAgIAAIAIgAWohASAHIAJqIgcoAgQhAgsgByACQX5xNgIEIAAgAUEBcjYCBCAAIAFqIAE2AgACQCABQYACSQ0AIAAgARDWgICAAAwGCwJAAkBBACgC8KvAgAAiAkEBIAFBA3Z0IgdxDQBBACACIAdyNgLwq8CAACABQfgBcUHoqcCAAGoiASECDAELIAFB+AFxIgFB6KnAgABqIQIgAUHwqcCAAGooAgAhAQsgAiAANgIIIAEgADYCDCAAIAI2AgwgACABNgIIDAULQQAgBUEPakF4cSIAQXhqIgY2AoSswIAAQQAgBSAAayAIQVhqIgBqQQhqIgQ2AvyrwIAAIAYgBEEBcjYCBCAFIABqQSg2AgRBAEGAgIABNgKQrMCAACABIAdBYGpBeHFBeGoiACAAIAFBEGpJGyIGQRs2AgRBACkC2KnAgAAhCSAGQRBqQQApAuCpwIAANwIAIAZBCGoiACAJNwIAQQAgCDYC3KnAgABBACAFNgLYqcCAAEEAIAA2AuCpwIAAQQBBADYC5KnAgAAgBkEcaiEAA0AgAEEHNgIAIABBBGoiACAHSQ0ACyAGIAFGDQYgBiAGKAIEQX5xNgIEIAEgBiABayIAQQFyNgIEIAYgADYCAAJAIABBgAJJDQAgASAAENaAgIAADAcLAkACQEEAKALwq8CAACIHQQEgAEEDdnQiBXENAEEAIAcgBXI2AvCrwIAAIABB+AFxQeipwIAAaiIAIQcMAQsgAEH4AXEiAEHoqcCAAGohByAAQfCpwIAAaigCACEACyAHIAE2AgggACABNgIMIAEgBzYCDCABIAA2AggMBgsgACAGIAhqNgIEQQBBACgChKzAgAAiAEEPakF4cSIBQXhqIgc2AoSswIAAQQAgACABa0EAKAL8q8CAACAIaiIBakEIaiIFNgL8q8CAACAHIAVBAXI2AgQgACABakEoNgIEQQBBgICAATYCkKzAgAAMBQtBACAANgKErMCAAEEAQQAoAvyrwIAAIAFqIgE2AvyrwIAAIAAgAUEBcjYCBAwCC0EAIAA2AoCswIAAQQBBACgC+KvAgAAgAWoiATYC+KvAgAAgACABQQFyNgIEIAAgAWogATYCAAwBC0EAIAU2ApSswIAADAELIAVBCGoPC0EAIAg2AtypwIAAQQAgBTYC2KnAgABBAEHoqcCAADYC9KnAgABBAEHwqcCAADYC/KnAgABBAEHoqcCAADYC8KnAgABBAEH4qcCAADYChKrAgABBAEHwqcCAADYC+KnAgABBAEGAqsCAADYCjKrAgABBAEH4qcCAADYCgKrAgABBAEGIqsCAADYClKrAgABBAEGAqsCAADYCiKrAgABBAEGQqsCAADYCnKrAgABBAEGIqsCAADYCkKrAgABBAEGYqsCAADYCpKrAgABBAEGQqsCAADYCmKrAgABBAEGgqsCAADYCrKrAgABBAEGYqsCAADYCoKrAgABBAEEAKAKgrMCAACIAQX8gABs2ApiswIAAQQBBADYC5KnAgABBAEGoqsCAADYCtKrAgABBAEGgqsCAADYCqKrAgABBAEGoqsCAADYCsKrAgABBAEGwqsCAADYCvKrAgABBAEGwqsCAADYCuKrAgABBAEG4qsCAADYCxKrAgABBAEG4qsCAADYCwKrAgABBAEHAqsCAADYCzKrAgABBAEHAqsCAADYCyKrAgABBAEHIqsCAADYC1KrAgABBAEHIqsCAADYC0KrAgABBAEHQqsCAADYC3KrAgABBAEHQqsCAADYC2KrAgABBAEHYqsCAADYC5KrAgABBAEHgqsCAADYC7KrAgABBAEHYqsCAADYC4KrAgABBAEHgqsCAADYC6KrAgABBAEHoqsCAADYC9KrAgABBAEHwqsCAADYC/KrAgABBAEHoqsCAADYC8KrAgABBAEHwqsCAADYC+KrAgABBAEH4qsCAADYChKvAgABBAEH4qsCAADYCgKvAgABBAEGAq8CAADYCjKvAgABBAEGAq8CAADYCiKvAgABBAEGIq8CAADYClKvAgABBAEGIq8CAADYCkKvAgABBAEGQq8CAADYCnKvAgABBAEGQq8CAADYCmKvAgABBAEGYq8CAADYCpKvAgABBAEGYq8CAADYCoKvAgABBAEGgq8CAADYCrKvAgABBAEGgq8CAADYCqKvAgABBAEGoq8CAADYCtKvAgABBAEGoq8CAADYCsKvAgABBAEGwq8CAADYCvKvAgABBAEG4q8CAADYCxKvAgABBAEGwq8CAADYCuKvAgABBAEHAq8CAADYCzKvAgABBAEG4q8CAADYCwKvAgABBAEHIq8CAADYC1KvAgABBAEHAq8CAADYCyKvAgABBAEHQq8CAADYC3KvAgABBAEHIq8CAADYC0KvAgABBAEHYq8CAADYC5KvAgABBAEHQq8CAADYC2KvAgABBAEHgq8CAADYC7KvAgABBAEHYq8CAADYC4KvAgABBACAFQQ9qQXhxIgBBeGoiATYChKzAgABBAEHgq8CAADYC6KvAgABBACAFIABrIAhBWGoiAGpBCGoiBzYC/KvAgAAgASAHQQFyNgIEIAUgAGpBKDYCBEEAQYCAgAE2ApCswIAAC0EAIQFBACgC/KvAgAAiACACTQ0AQQAgACACayIBNgL8q8CAAEEAQQAoAoSswIAAIgAgAmoiBzYChKzAgAAgByABQQFyNgIEIAAgAkEDcjYCBCAAQQhqDwsgAQvKGQEdfyOAgICAAEHwDGsiASSAgICAAAJAIAAoAggiAkUNACAAKAIEIgMgAkHQEmxqIQQgAUGgDGpBPGohAiABQaAMakEoaiEFIAFBoAxqQRRqIQYgAUHQC2pBPGohByABQdALakEoaiEIIAFB0AtqQRRqIQkgAUGAC2pBPGohCiABQYALakEoaiELIAFBgAtqQRRqIQwgAUGwCmpBPGohDSABQbAKakEoaiEOIAFBsApqQRRqIQ8gAUHgCWpBPGohECABQeAJakEoaiERIAFB4AlqQRRqIRIgAUHQCGpB7ABqIRMgAUHQCGpByABqIRQgAUHQCGpBJGohFSABQdAIakE8aiEWIAFB0AhqQShqIRcgAUHQCGpBFGohGCABQcgFakHsAGohGSABQcgFakHIAGohGiABQcgFakEkaiEbIAFByAVqQQNqIRwgAUGlAWpBA2ohHQNAIBtCADcCACAbQgA3AgggG0IANwIQIBtCADcCGCAbQQA7ASAgGkIANwIAIBpCADcCCCAaQgA3AhAgGkIANwIYIBpBADsBICAZQgA3AgAgGUIANwIIIBlCADcCECAZQgA3AhggGUEAOwEgIAFBADsB6AUgAUIANwPgBSABQgA3A9gFIAFCADcD0AUgAUIANwPIBSAPQgA3AgAgD0IANwIIIA9BADoAECAOQgA3AgAgDkIANwIIIA5BADoAECANQgA3AgAgDUIANwIIIA1BADoAECAMQgA3AgAgDEIANwIIIAxBADoAECABQQA6AMAKIAFCADcDuAogAUIANwOwCiABQgA3A4ALIAFCADcDiAsgAUEAOgCQCyALQQA6ABAgC0IANwIIIAtCADcCACAKQQA6ABAgCkIANwIIIApCADcCACAJQQA6ABAgCUIANwIIIAlCADcCACAIQQA6ABAgCEIANwIIIAhCADcCACAHQgA3AgAgB0IANwIIIAdBADoAECABQQA6AOALIAFCADcD2AsgAUIANwPQCyABQQA6ALAMIAFCADcDqAwgAUIANwOgDCAGQQA6ABAgBkIANwIIIAZCADcCACAFQQA6ABAgBUIANwIIIAVCADcCACACQQA6ABAgAkIANwIIIAJCADcCACABQQA6AOAIIAFCADcD2AggAUIANwPQCCAYQQA6ABAgGEIANwIIIBhCADcCACAXQQA6ABAgF0IANwIIIBdCADcCACAWQQA6ABAgFkIANwIIIBZCADcCACAdIAFByAVqQZAB/AoAACABIAFBsApqQdAA/AoAACABQYgDaiABQYALakHQAPwKAAAgAUG4AmogAUHQC2pB0AD8CgAAIAFB0ABqIAFBoAxqQdAA/AoAACABQdgDaiABQdAIakHQAPwKAAAgFUIANwIAIBVCADcCCCAVQgA3AhAgFUIANwIYIBVBADsBICAUQgA3AgAgFEIANwIIIBRCADcCECAUQgA3AhggFEEAOwEgIBNCADcCACATQgA3AgggE0IANwIQIBNCADcCGCATQQA7ASAgAUEAOwHwCCABQgA3A+gIIAFCADcD4AggAUIANwPYCCABQgA3A9AIIBJCADcCACASQgA3AgggEkEAOgAQIBFCADcCACARQgA3AgggEUEAOgAQIBBCADcCACAQQgA3AgggEEEAOgAQIA9CADcCACAPQgA3AgggD0EAOgAQIAFBADoA8AkgAUIANwPoCSABQgA3A+AJIAFCADcDsAogAUIANwO4CiABQQA6AMAKIA5BADoAECAOQgA3AgggDkIANwIAIA1BADoAECANQgA3AgggDUIANwIAIAxBADoAECAMQgA3AgggDEIANwIAIAtBADoAECALQgA3AgggC0IANwIAIApCADcCACAKQgA3AgggCkEAOgAQIAFBADoAkAsgAUIANwOICyABQgA3A4ALIAFBADoA4AsgAUIANwPYCyABQgA3A9ALIAlBADoAECAJQgA3AgggCUIANwIAIAhBADoAECAIQgA3AgggCEIANwIAIAdBADoAECAHQgA3AgggB0IANwIAIAFBADoAsAwgAUIANwOoDCABQgA3A6AMIAZBADoAECAGQgA3AgggBkIANwIAIAVBADoAECAFQgA3AgggBUIANwIAIAJBADoAECACQgA3AgggAkIANwIAIBwgAUHQCGpBkAH8CgAAIAFBqARqIAFB4AlqQdAA/AoAACABQbAHaiABQbAKakHQAPwKAAAgAUHgBmogAUGAC2pB0AD8CgAAIAFB+ARqIAFB0AtqQdAA/AoAACABQYAIaiABQaAMakHQAPwKAAAgA0IANwMYIANCADcDECADQgA3AwggA0IANwMAIANB6ABqQgA3AAAgA0HkAGpB/wE6AAAgA0HwAGpCADcAACADQfgAakIANwAAIANBgAFqQgA3AAAgA0GIAWogAUHYA2pB0AD8CgAAIANB3AFqQQA6AAAgA0HYAWpBADsBACADQeABakEAQc0A/AsAIANB1AJqQgA3AAAgA0HQAmpB/wE6AAAgA0HcAmpCADcAACADQeQCakIANwAAIANB7AJqQgA3AAAgA0H0AmpBADoAACADQfgCakIANwAAIANBgANqQgA3AAAgA0GIA2pCADcAACADQZADakEANgAAIANBlANqIAFBiANqQdAA/AoAACADQZAEakIANwAAIANBjARqQf8BOgAAIANB6ANqQQA6AAAgA0HkA2pBADsBACADQZgEakIANwAAIANBoARqQgA3AAAgA0GoBGpCADcAACADQbAEakEAOgAAIANBtARqQgA3AAAgA0G8BGpCADcAACADQcQEakIANwAAIANBzARqQQA2AAAgA0HQBGogAUG4AmpB0AD8CgAAIANBpAVqQQA6AAAgA0GgBWpBADsBACADQaUFaiABQaUBakGTAfwKAAAgA0HwBmpBADYCACADQegGakIANwMAIANB4AZqQgA3AwAgA0HYBmpCADcDACADQdAGakIANwMAIANByAZqQgA3AwAgA0HABmpCADcDACADQbgGakIANwMAIANBvAdqQgA3AAAgA0G4B2pB/wE6AAAgA0GUB2pB/wE6AAAgA0HEB2pCADcAACADQcwHakIANwAAIANB1AdqQQA2AAAgA0HYB2ogAUHQAGpB0AD8CgAAIANBsAhqQgA3AAAgA0GsCGpBADoAACADQagIakEAOwEAIANBuAhqQgA3AAAgA0HACGpCADcAACADQcgIakEANgAAIANBzAhqIAFB0AD8CgAAIANBqAlqQgA3AwAgA0GgCWpBADoAACADQZwJakEAOwEAIANBsAlqQgA3AwAgA0G4CWpCADcDACADQcAJakIANwMAIANBkApqQgA3AAAgA0GMCmpB/wE6AAAgA0GYCmpCADcAACADQaAKakIANwAAIANBqApqQgA3AAAgA0GwCmogAUGACGpB0AD8CgAAIANBhAtqQQA6AAAgA0GAC2pBADsBACADQYgLakEAQc0A/AsAIANB/AtqQgA3AAAgA0H4C2pB/wE6AAAgA0GEDGpCADcAACADQYwMakIANwAAIANBlAxqQgA3AAAgA0GcDGpBADoAACADQaAMakIANwAAIANBqAxqQgA3AAAgA0GwDGpCADcAACADQbgMakEANgAAIANBvAxqIAFBsAdqQdAA/AoAACADQbgNakIANwAAIANBtA1qQf8BOgAAIANBkA1qQQA6AAAgA0GMDWpBADsBACADQcANakIANwAAIANByA1qQgA3AAAgA0HQDWpCADcAACADQdgNakEAOgAAIANB3A1qQgA3AAAgA0HkDWpCADcAACADQewNakIANwAAIANB9A1qQQA2AAAgA0H4DWogAUHgBmpB0AD8CgAAIANBzA5qQQA6AAAgA0HIDmpBADsBACADQc0OaiABQcgFakGTAfwKAAAgA0GYEGpBADYCACADQZAQakIANwMAIANBiBBqQgA3AwAgA0GAEGpCADcDACADQfgPakIANwMAIANB8A9qQgA3AwAgA0HoD2pCADcDACADQeAPakIANwMAIANB5BBqQgA3AAAgA0HgEGpB/wE6AAAgA0G8EGpB/wE6AAAgA0HsEGpCADcAACADQfQQakIANwAAIANB/BBqQQA2AAAgA0GAEWogAUH4BGpB0AD8CgAAIANB2BFqQgA3AAAgA0HUEWpBADoAACADQdARakEAOwEAIANB4BFqQgA3AAAgA0HoEWpCADcAACADQfARakEANgAAIANB9BFqIAFBqARqQdAA/AoAACADQcgSakEAOgAAIANBxBJqQQA7AQAgA0HQEmoiAyAERw0ACwsgAEEANgI4IABB4AhqQQBB0AL8CwAgAEF/NgKwIyABQfAMaiSAgICAAAupggIqCX8BfgF/BH4mfwl9AX8CfQV/En0CfAF/BX0BfwF9AX8GfQF/A30BfwJ9An8CfQF/An0CfwR9An8EfQF/BH0DfwN9AX8CfQF/AX0Cfwp9AX8CfQF8I4CAgIAAQeAKayICJICAgIAAIAAoAjghA0EAIQQgAEEANgI4IAAoAjQhBSAAKAIwIQYgAEKAgICAwAA3AjAgAUGAAUkhBwJAIANBAkkNAEEBIQgDQCAIQQFqIQggBCEJAkADQCAFIAlqIgpBJGooAgAgCkHQAGooAgBNDQEgCikCACELIAogCkEsaiIMKQIANwIAIAopAgghDSAKIAwpAgg3AgggCikCECEOIAogDCkCEDcCECAKKQIYIQ8gCiAMKQIYNwIYIAopAiAhECAKIAwpAiA3AiAgCigCKCERIAogDCgCKDYCKCACIBE2AugDIAIgEDcD4AMgAiAPNwPYAyACIA43A9ADIAIgDTcDyAMgAiALNwPAAyAMIAIpA8ADNwIAIAwgAigC6AM2AiggDCACKQPgAzcCICAMIAIpA9gDNwIYIAwgAikD0AM3AhAgDCACKQPIAzcCCCAJQVRqIglBVEcNAAsLIARBLGohBCAIIANHDQALCyABQYABIAcbIRICQAJAAkACQAJAAkACQAJAAkACQCABRQ0AIABBsBtqIRMgAEGwE2ohFCAAQbALaiEVIAJBowlqQStqIRYgAkGjCWpBF2ohFyACQaMJakEDaiEYIAJBwANqQStqIRkgAkHAA2pBF2ohGiACQcADakEDaiEbIAJBoQpqQStqIRwgAkGhCmpBF2ohHSACQaEKakEDaiEeIAJB4glqQStqIR8gAkHiCWpBF2ohICACQeIJakEDaiEhIAJBK2ohIiACQRdqISMgAkEDaiEkIAJB8ABqQStqISUgAkHwAGpBF2ohJiACQfAAakEDaiEnIAJB5AhqQStqISggAkHkCGpBF2ohKSACQeQIakEDaiEqIAJBjQdqQQNqISsgAkGsB2pBA2ohLCACQfwDaiEtIAJB6ANqIS4gAkHAA2pBFGohLyACQeAEaiEwIAJB5AJqITEgAkEcaiEyQQAhM0EAITRBACE1A0AgEiE2AkAgNCADTw0AAkADQAJAIAUgNEEsbGoiCigCJCIMIDNNDQAgDCASIAwgEkkbITYMAwsCQCAKKgIAIje8QQF0Qf///3dLDQAgCioCBCI4vEEBdEH///93Sw0AIAoqAggiObxBAXRB////d0sNACAKKgIMIjq8QQF0Qf///3dLDQAgCioCECI7vEEBdEH///93Sw0AIAooAhRBAXRB////d0sNACAKKAIYQQF0Qf///3dLDQAgCioCHCI8vEEBdEH///93Sw0AIAoqAighPSAKKAIgIQQgACoCPCI+ID6SIT8CQCAAKAIgIgpFDQAgCkECdCERIAAoAhwhCUEBIAR0IQggACgCBEHIEmohDCAAKAIIIQdBACEKQwAAgL8gP0Omm0Q7lJUQ2YCAgAAhPgNAAkAgBCAKRg0AIAkoAgAgCHFFDQACQAJAIAogB08NACAMQdh2ai0AAEUNASAMQbhvaiJAID4gQCoCACJBIEEgQVwbIkEgQSA+ID4gPlwbIkIgQSBCXRs4AgAMAQsgCiAHQcSJwIAAEIuAgIAAAAsgDC0AAEEBRw0AIAxB4HhqIkAgPiBAKgIAIkEgQSBBXBsiQSBBID4gPiA+XBsiQiBBIEJdGzgCAAsgCUEEaiEJIApBAWohCiAMQdASaiEMIBFBfGoiEQ0ACwsCQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkAgBCAAKAIUIgpPDQAgBCAAKAIIIgpPDQEgACgCECAEQQJ0aiIMKAIAIgpBAk8NAgJAIAAoAgQgBEHQEmwiQ2ogCkGoCWxqIgktAKAJRQ0AIAkqAoACIT4gCUMAAIC/ID9DbxIDO5SVENmAgIAAIkEgPiA+ID5cGyI+ID4gQSBBIEFcGyJBID4gQV0bOAKAAgsgDCAKQQFzIkQ2AgAgACAAKAK0IyIKQQ10IApzIgpBEXYgCnMiCkEFdCAKcyIKQQ10IApzIgxBEXYgDHMiDEEFdCAMcyIMQQ10IAxzIglBEXYgCXMiCUEFdCAJcyIJQQ10IAlzIhFBEXYgEXMiEUEFdCARcyIRQQ10IBFzIghBEXYgCHMiCEEFdCAIcyIIQQ10IAhzIgdBEXYgB3MiB0EFdCAHcyIHQQ10IAdzIkBBEXYgQHMiQEEFdCBAcyJFNgK0IyAALQC4IyJALQC8pMCAACJGQX9qIkcgBCBHIARJGyJHIEZPDSAgRbNDAACAL5QiPiA+kkMAAIC/kkMAAAA/lEMAAAA/kiFIIAezQwAAgC+UIj4gPpJDAACAv5JDAAAAP5RDAAAAP5IhSSAIs0MAAIAvlCI+ID6SQwAAgL+SQwAAAD+UQwAAAD+SIUogEbNDAACAL5QiPiA+kkMAAIC/kkMAAAA/lEMAAAA/kiFLIAmzQwAAgC+UIj4gPpJDAACAv5JDAAAAP5RDAAAAP5IhTCAMs0MAAIAvlCI+ID6SQwAAgL+SQwAAAD+UQwAAAD+SIU0gCrNDAACAL5QiPiA+kkMAAIC/kkOmm0Q7lEMAAIA/kiE+IEBBAnQoAsSkwIAAIEdBAnRqKgIAIUEgHkEAOgAQIB5CADcACCAeQgA3AAAgHUIANwAAIB1CADcACCAdQQA6ABAgHEIANwAAIBxCADcACCAcQQA6ABAgL0IANwIAIC9CADcCCCAvQQA6ABAgLkIANwIAIC5CADcCCCAuQQA6ABAgAkIANwPAAyACQgA3A8gDIAJBADoA0AMgLUEAOgAQIC1CADcCCCAtQgA3AgAgJEIANwAAICRCADcACCAkQQA6ABAgI0IANwAAICNCADcACCAjQQA6ABAgIkIANwAAICJCADcACCAiQQA6ABAgJ0IANwAAICdCADcACCAnQQA6ABAgJkIANwAAICZCADcACCAmQQA6ABAgJUEAOgAQICVCADcACCAlQgA3AAAgAkIANwOIBiACQgA3A4AGIAJCADcD+AUgAiACKQDYCjcA7wUgAiACKQDRCjcD6AUgAiACKQDJCjcD4AUgAiACKQDBCjcD2AUgAiACKQC5CjcD0AUgAiACKQCxCjcDyAUgAiACKQCpCjcDwAUgAiACKQChCjcDuAUgAkGAAmogAkHAA2pB0AD8CgAAIAIgAikANzcAxwYgAiACKQAwNwPABiACIAIpACg3A7gGIAIgAikAIDcDsAYgAiACKQAYNwOoBiACIAIpABA3A6AGIAIgAikACDcDmAYgAiACKQAANwOQBiACIAIpAHA3A4gIIAIgAikAeDcDkAggAiACKQCAATcDmAggAiACKQCIATcDoAggAiACKQCQATcDqAggAiACKQCYATcDsAggAiACKQCgATcDuAggAiACKQCnATcAvwggLEIANwAAICxCADcACCAsQgA3ABAgLEIANwAYICxBADoAICArQgA3AAAgK0IANwAIICtCADcAECArQQA2ABggAkIANwPQByACQgA3A9gHIAJCADcD4AcgAkIANwPQBiACQgA3A9gGIAJCADcD4AYgAkIANwPYCCACQgA3A9AIIAJCADcDyAggAkIANwOACCACQgA3A/gHQwAAIEEgQUMAAKDBlRDmgICAACFOIEAOBQMEBQYGAwsgBCAKQdSJwIAAEIuAgIAAAAsgBCAKQeSJwIAAEIuAgIAAAAsgCkECQfSJwIAAEIuAgIAAAAtDAACgPyFPIAQOCgQFBgcMCwgICQoDC0NmZmY/IU8gBA4EDg8QEhELIDcgPpQhPiAEDgYTFhcSGBQSCyA/QwAAAD+UIkFDZmbmPpQiUEMAAKBBYEUNGiBQQwAAekQgUEMAAHpEXRtD2w9JQJQgQSBBkiJRlRDjgICAABpBACFGIFBDAACgQSA5IDlDAACgQV0bIkEgQSBQXhtD2w9JQJQgUZUQ44CAgAAhQSAqQQA6ABBCACELICpCADcACCAqQgA3AAAgKUIANwAAIClCADcACCApQQA6ABAgKEIANwAAIChCADcACCAoQQA6ABAgAkIANwPAAyACQgA3A8gDIAJCADcDyAggAkIANwPQCCACQgA3A9gIIAIgAikA5Ag3A4gIIAIgAikA7Ag3A5AIIAIgAikA9Ag3A5gIIAIgAikA/Ag3A6AIIAIgAikAhAk3A6gIIAIgAikAjAk3A7AIIAIgAikAlAk3A7gIIAIgAikAmwk3AL8IIEFDAACAPyBBQwAAgD+SlSJSlCJTIFMgU5QiVJQhVUMAAIA/ID9DbxKDOpQiQSBBIEFcGyJBQwAAgD8gQUMAAIA/XhshVkMAAIA/IFQgVJQiV0PNzEw+lEMAAIA/kpUhWEMAAAAAIVkgO0MAAAAAlyA3ID6UIj6UuyFaID67ID+7oyFbID9DAAAAAJT8ASFcQQEhCEH/ASFHQzMzk8BDbxKDOiA4IDggOFwbIj5DbxKDOiA+Q28SgzpeGyA/lJUQ2YCAgAAhXUMAAAAAIV5DAAAAACFfQwAAAAAhYEMAAAAAIWFBACFiQwAAAAAhY0EAIWRDAAAAACFNQwAAAAAhTEMAAAAAIUtDAAAAACFKQwAAAAAhSUMAAAAAIUhDAAAAACFlQwAAAAAhZkMAAAAAIWdDAAAAACFoQwAAAAAhaUMAAAAAIWpBACFrQwAAAAAhbEMAAAAAIW1DAAAAACFuQwAAAAAhO0EAIUBBACFvQQAhCUMAAAAAIXBDAAAAACFxQwAAAAAhT0EAIXJB/wEhc0MAAAAAIXRDAAAAACF1QQAhdkEAIRFDAAAAACE5QwAAAAAhd0MAAAAAIXhBACF5QQAhekMAAAAAIXtDAAAAACF8QwAAAAAhfUIAIQ1DAAAAACF+QQAhf0EAIYABQwAAAAAhgQFDAAAAACGCAUMAAAAAIYMBQwAAAAAhhAFBACE2Qf8BIYUBQwAAAAAhhgFDAAAAACGHAUEAIQdBACEMQwAAAAAhiAFDAAAAACGJAUMAAAAAIUFBACGKAUMAAAAAIUJDAAAAACE3QQAhiwFBACGMAUMAAAAAIY0BQwAAAAAhjgFDAAAAACGPAUEAIZABQwAAAAAhkQFDAAAAACGSAUMAAAAAIT5BACGTAUMAAAAAIZQBQQEhlQEgBCGWAQw0CyAYQQA6ABAgGEIANwAIIBhCADcAACAXQgA3AAAgF0IANwAIIBdBADoAECAWQgA3AAAgFkIANwAIIBZBADoAECACQgA3A9AGIAJCADcD2AYgAkIANwPgBiACIAIpAKMJNwOQBiACIAIpAKsJNwOYBiACIAIpALMJNwOgBiACIAIpALsJNwOoBiACIAIpAMMJNwOwBiACIAIpAMsJNwO4BiACIAIpANMJNwPABiACIAIpANoJNwDHBiA/Q0jh+j6UIkFDAAAgQWBFDRpCACELIEFDAAAlRSBBQwAAJUVdG0PbD0lAlCA/lRDjgICAACFBIAJCADcDgAcgAkIANwP4BkMAAIA/ID9DbxIDOpQiQiBCIEJcGyJCQwAAgD8gQkMAAIA/XhshcUNu2zY/IZcBIEEgQUMAAIA/IEEgQUNu2zY/kpRDAACAP5KVIpgBlCKZAZQhmgEgNyA+lCI+QwAAB0SUID+VIWUgPkMAAEhElCA/lSFmQwAAAAAhWSA/QwAAAACU/AEhckQAAAAAAAAAACFaQ2Zmpj8hPkECIXZDAAAAPyF1Qf8BIUdDZmZmPyFPQQEha0EAIUZDMzOTwENvEoM6IDggOCA4XBsiQUNvEoM6IEFDbxKDOl4bID+UlRDZgICAACFwQwAAAAAhXkMAAAAAIV9DAAAAACFgQwAAAAAhYUEAIWJDAAAAACFjQQAhZEMAAAAAIWdDAAAAACFoQwAAAAAhaUMAAAAAIWpDAAAAACFsQwAAAAAhbUMAAAAAIW5DAAAAACE7QQAhQEEAIW9BASEJQQEhc0MAAAAAIXQMLQsgG0EAOgAQIBtCADcACCAbQgA3AAAgGkIANwAAIBpCADcACCAaQQA6ABAgGUIANwAAIBlCADcACCAZQQA6ABAgAkIANwP4BSACQgA3A4AGIAJCADcDiAYgAiACKQDAAzcDuAUgAiACKQDIAzcDwAUgAiACKQDQAzcDyAUgAiACKQDYAzcD0AUgAiACKQDgAzcD2AUgAiACKQDoAzcD4AUgAiACKQDwAzcD6AUgAiACKQD3AzcA7wUgP0NI4fo+lCJBQwAAIEFgRQ0aQgAhCyBBQwDAWkUgQUMAwFpFXRtD2w9JQJQgP5UQ44CAgAAhQSACQgA3A4AIIAJCADcD+AdDAACAPyE7QwAAgD8gP0Omm8Q6lCJCIEIgQlwbIkJDAACAPyBCQwAAgD9eGyFuQ27btj8hkgEgQSBBQwAAgD8gQSBBQ27btj+SlEMAAIA/kpUikQGUIocBlCGGASA3ID6UID+VIYMBID9DF7fROZT8ASGTAUMAAAAAIVkgP0MAAAAAlPwBIUBDAABAwCA/Q83MzDyUlRDZgICAALwhZEQAAAAAAAAAACFaQwAAgD4hlAFDzczMPyE+QYCAgPwDITZDj8J1PSGBAUEBIW9B/wEhR0EAIUZDMzOTwENvEoM6IDggOCA4XBsiQUNvEoM6IEFDbxKDOl4bID+UlRDZgICAACFtQwAAAAAhXkMAAAAAIV9DAAAAACFgQwAAAAAhYUEAIWJDAAAAACFjQwAAAAAhTUMAAAAAIUxDAAAAACFLQwAAAAAhSkMAAAAAIUlDAAAAACFIQwAAAAAhZUMAAAAAIWZDAAAAACFnQwAAAAAhaEMAAAAAIWlDAAAAACFqQQAha0MAAAAAIWxBACEJQwAAAAAhcEMAAAAAIXFDAAAAACFPQQAhckH/ASFzQwAAAAAhdEMAAAAAIXVBACF2QQAhEUMAAAAAITlDAAAAACF3QwAAAAAheEEAIXlBACF6QwAAAAAhe0MAAAAAIXxDAAAAACF9QgAhDUMAAAAAIX5BACF/QQEhgAFDAACAPyGCAUMAAAAAIYQBQf8BIYUBQQAhB0EAIQxDAAAAACGIAUMAAAAAIYkBQwAAAAAhQUEAIYoBQwAAAAAhQkMAAAAAITdBACGLAUEAIYwBQwAAAAAhjQFDAAAAACGOAUMAAAAAIY8BQQAhkAEMMQsgG0EAOgAQIBtCADcACCAbQgA3AAAgGkIANwAAIBpCADcACCAaQQA6ABAgGUIANwAAIBlCADcACCAZQQA6ABAgAkIANwP4BSACQgA3A4AGIAJCADcDiAYgAiACKQDAAzcDuAUgAiACKQDIAzcDwAUgAiACKQDQAzcDyAUgAiACKQDYAzcD0AUgAiACKQDgAzcD2AUgAiACKQDoAzcD4AUgAiACKQDwAzcD6AUgAiACKQD3AzcA7wUgP0NI4fo+lCJBQwAAIEFgRQ0aQgAhCyBBQwAA4UQgQUMAAOFEXRtD2w9JQJQgP5UQ44CAgAAhQSACQgA3A+AHIAJCADcD2AcgAkIANwPQB0MAAIA/ID9DbxIDOpQiQiBCIEJcGyJCQwAAgD8gQkMAAIA/XhshjgFDAACAPyA/Q6abxDqUIkIgQiBCXBsiQkMAAIA/IEJDAACAP14bIW5Dq6qqPyFsIEEgQUMAAIA/IEEgQUOrqqo/kpRDAACAP5KVIlmUIl6UIV8gOEOamRk/lCGPAUMAAIA/IDdDmpkZP5STIYIBIDdDZmYmP5RDMzOzPpIhfCA5ID6UIj5DAAA5Q5QgP5UhgwEgPkMAAKVDlCA/lSF9QwAAAAAhYCA/QwAAAACU/AEhQEMAAEDAID9DCtcjPJSVENmAgIAAvCJkrSENRAAAAAAAAAAAIVpDZmamPyE+QZCuj+0DITZDENejPSF+QwrXozwhe0EBIWJB/wEhR0EAIWtDzcwMPyE7QQIhRkMzM5PAIDpDbxKDOpcgP5SVENmAgIAAIY0BQzMzk8AgOkNmZiY/lENvEoM6lyA/lJUQ2YCAgAAhbUMAAAAAIWFDAAAAACFjQwAAAAAhTUMAAAAAIUxDAAAAACFLQwAAAAAhSkMAAAAAIUlDAAAAACFIQwAAAAAhZUMAAAAAIWZDAAAAACFnQwAAAAAhaEMAAAAAIWlDAAAAACFqQQEhb0EAIQlDAAAAACFwQwAAAAAhcUMAAAAAIU9BACFyQf8BIXNDAAAAACF0QwAAAAAhdUEAIXZBACERQwAAAAAhOUMAAAAAIXdDAAAAACF4QQAheUEBIXpBACF/QQEhgAFDCtejPCGBAQwoCyAbQQA6ABAgG0IANwAIIBtCADcAACAaQgA3AAAgGkIANwAIIBpBADoAECAZQgA3AAAgGUIANwAIIBlBADoAECACQgA3A/gFIAJCADcDgAYgAkIANwOIBiACIAIpAMADNwO4BSACIAIpAMgDNwPABSACIAIpANADNwPIBSACIAIpANgDNwPQBSACIAIpAOADNwPYBSACIAIpAOgDNwPgBSACIAIpAPADNwPoBSACIAIpAPcDNwDvBSA/Q0jh+j6UIkFDAAAgQWBFDRpCACELIEFDAECcRSBBQwBAnEVdG0PbD0lAlCA/lRDjgICAACFBIAJCADcD4AcgAkIANwPYByACQgA3A9AHQwAAgD8hfEMAAIA/ID9DbxIDOpQiQiBCIEJcGyJCQwAAgD8gQkMAAIA/XhshjgFDAACAPyA/Q6abxDqUIkIgQiBCXBsiQkMAAIA/IEJDAACAP14bIW5Dq6qqPyFsIEEgQUMAAIA/IEEgQUOrqqo/kpRDAACAP5KVIlmUIl6UIV8gNyA+lCI+QwCA40OUID+VIYMBID5DAGDQRJQgP5UhfUMAAAAAIWAgP0MAAAAAlPwBIUBDAABAwCA/Q28SgzqUlRDZgICAALwiZK0hDUQAAAAAAAAAACFaQwAAAEAhPkMAAAA/IY8BQ5qZGT8hggFBASFiQf8BIUdBACFrQzMzMz8hO0ECIUZDMzOTwENvEoM6IDggOCA4XBsiQUNvEoM6IEFDbxKDOl4bID+UlRDZgICAACFtQzMzk8BDbxKDOiA4Q4mIiD6UIkEgQSBBXBsiQUNvEoM6IEFDbxKDOl4bID+UlRDZgICAACGNAUMAAAAAIWFDAAAAACFjQwAAAAAhTUMAAAAAIUxDAAAAACFLQwAAAAAhSkMAAAAAIUlDAAAAACFIQwAAAAAhZUMAAAAAIWZDAAAAACFnQwAAAAAhaEMAAAAAIWlDAAAAACFqQQEhb0EAIQlDAAAAACFwQwAAAAAhcUMAAAAAIU9BACFyQf8BIXNDAAAAACF0QwAAAAAhdUEAIXZBACERQwAAAAAhOUMAAAAAIXdDAAAAACF4QQEheUEBIXpDAAAAACF7QwAAAAAhfkEBIX9BASGAAUMAAAAAIYEBQwAAAAAhhAFBACE2DCgLID9DSOH6PpQiPkMAACBBYEUNGkIAIQsgPkMAACBBIDdDAAB6RJQiQSBBQwAAIEFdGyJBIEEgPl4bQ9sPSUCUID+VEOOAgIAAIT4gAkIANwPgByACQgA3A9gHIAJCADcD0AdDbts2PyFsID4gPkMAAIA/ID4gPkNu2zY/kpRDAACAP5KVIlmUIl6UIV9DAACAPyA/Q28SAzqUIj4gPiA+XBsiPkMAAIA/ID5DAACAP14bIYkBID9DbxIDPZT8ASGKASA/QzEIrDyU/AEhiwEgP0MK1yM8lPwBIYwBQwAAAAAhYyA/QwAAAACU/AEhkAFEAAAAAAAAAAAhWkOamZk/IT5DMzOzPyFBQf8BIUdBACFkQQQhYkEBIUZDq6oqPyFhQwAAwD8hYEMzM5PAID9DbxKDPJSVENmAgIAAIUJDMzOTwENvEoM6IDggOCA4XBsiOENvEoM6IDhDbxKDOl4bID+UlRDZgICAACGIAUMAAAAAIU1DAAAAACFMQwAAAAAhS0MAAAAAIUpDAAAAACFJQwAAAAAhSEMAAAAAIWVDAAAAACFmQwAAAAAhZ0MAAAAAIWhDAAAAACFpQwAAAAAhakEAIWtDAAAAACFtQwAAAAAhbkMAAAAAITtBACFAQQAhb0EAIQlDAAAAACFwQwAAAAAhcUMAAAAAIU9BACFyQf8BIXNDAAAAACF0QwAAAAAhdUEAIXZBACERQwAAAAAhOUMAAAAAIXdDAAAAACF4QQAheUEAIXpDAAAAACF7QwAAAAAhfEMAAAAAIX1CACENQwAAAAAhfkEAIX9BACGAAUMAAAAAIYEBQwAAAAAhggFDAAAAACGDAUMAAAAAIYQBQQAhNkH/ASGFAUMAAAAAIYYBQwAAAAAhhwFBASEHQQEhDCBCIY0BQwAAgD8gP0MXt9E5lCI4IDggOFwbIjhDAACAPyA4QwAAgD9eGyI3IY4BQzMzsz8hjwEMLQsgG0EAOgAQIBtCADcACCAbQgA3AAAgGkIANwAAIBpCADcACCAaQQA6ABAgGUIANwAAIBlCADcACCAZQQA6ABAgAkIANwP4BSACQgA3A4AGIAJCADcDiAYgAiACKQDAAzcDuAUgAiACKQDIAzcDwAUgAiACKQDQAzcDyAUgAiACKQDYAzcD0AUgAiACKQDgAzcD2AUgAiACKQDoAzcD4AUgAiACKQDwAzcD6AUgAiACKQD3AzcA7wUgP0NI4fo+lCJBQwAAIEFgRQ0aQgAhCyBBQwCAO0UgQUMAgDtFXRtD2w9JQJQgP5UQ44CAgAAhQSACQgA3A+AHIAJCADcD2AcgAkIANwPQB0MAAIA/IYIBQwAAgD8gP0NSSZ05lCJCIEIgQlwbIkJDAACAPyBCQwAAgD9eGyGOAUMAAIA/ID9DppvEOpQiQiBCIEJcGyJCQwAAgD8gQkMAAIA/XhshbkOrqqo/IWwgQSBBQwAAgD8gQSBBQ6uqqj+SlEMAAIA/kpUiWZQiXpQhXyA3ID6UIj4gP5UhgwEgPkMAAMA/lCA/lSF9QwAAAAAhYEMAAEDAID9Dj8J1PZSVENmAgIAAvCJkrSENRAAAAAAAAAAAIVpDZmamPyE+QZqz5vgDITZDzcxMPSGBAUOamRk/IX5DmpkZPiF8QQEhYkH/ASFHQQAha0NmZmY/ITtBAiFGQzMzk8AgP0MK1yM8lJUQ2YCAgAAhjQFDMzOTwENvEoM6IDggOCA4XBsiQUNvEoM6IEFDbxKDOl4bID+UlRDZgICAACFtQwAAAAAhYUMAAAAAIWNDAAAAACFNQwAAAAAhTEMAAAAAIUtDAAAAACFKQwAAAAAhSUMAAAAAIUhDAAAAACFlQwAAAAAhZkMAAAAAIWdDAAAAACFoQwAAAAAhaUMAAAAAIWpBASFvQQAhCUMAAAAAIXBDAAAAACFxQwAAAAAhT0EAIXJB/wEhc0MAAAAAIXRDAAAAACF1QQAhdkEAIRFDAAAAACE5QwAAAAAhd0MAAAAAIXhBASF5QQEhekMAAAAAIXtBACF/QQEhgAFDAAAAACGEAUH/ASGFAUMAAAAAIYYBQwAAAAAhhwFBASEHQQAhDEMAAAAAIYgBQwAAAAAhiQFDAAAAACFBQQAhigFDAAAAACFCQwAAAAAhN0EAIYsBQQAhjAFDmpkZPiGPASA/QwAAAACU/AEiQCGQAQwsCyAhQQA6ABAgIUIANwAIICFCADcAACAgQgA3AAAgIEIANwAIICBBADoAECAfQgA3AAAgH0IANwAIIB9BADoAECACQgA3A9AGIAJCADcD2AYgAkIANwPgBiACIAIpAOIJNwOQBiACIAIpAOoJNwOYBiACIAIpAPIJNwOgBiACIAIpAPoJNwOoBiACIAIpAIIKNwOwBiACIAIpAIoKNwO4BiACIAIpAJIKNwPABiACIAIpAJkKNwDHBiA/Q0jh+j6UIkFDAAAgQWBFDRpCACELIEFDAAAgQSA4QwDA2kWUIkIgQkMAACBBXRsiQiBCIEFeG0PbD0lAlCA/lRDjgICAACFCIAJCADcDgAcgAkIANwP4BiBBQwAAIEEgOEMAQJxFlCI4IDhDAAAgQV0bIjggOCBBXhtD2w9JQJQgP5UQ44CAgAAhQSACQgA3A/AGIAJCADcD6AZDAAAAQCGXASBCIEJDAACAPyBCIEJDAAAAQJKUQwAAgD+SlSKYAZQimQGUIZoBIEEgQUMAAIA/IEEgQUOrqqo/kpRDAACAP5KVIpsBlCKcAZQhnQFDAACAPyA/Q28SAzuUIkEgQSBBXBsiQUMAAIA/IEFDAACAP14bIXEgPkPNTE1DlCA/lSFlID5DMzOYQ5QgP5UhZiA+Q83MuEOUID+VIWcgPkPNrAJElCA/lSFoID5DAAAHRJQgP5UhaSA+QwAASESUID+VIWpDAAAAACFZID9DAAAAAJT8ASFyRAAAAAAAAAAAIVpDmpmZPyE+Qf8BIYUBQQYhdkMAAAA/IXVDMzOzPiF0QQIhR0MAAEA/IU9BASFrQQAhRkMzM5PAQ28SgzogNyA3IDdcGyJBQ28SgzogQUNvEoM6XhsgP5SVENmAgIAAIXBDAAAAACFeQwAAAAAhX0MAAAAAIWBDAAAAACFhQQAhYkMAAAAAIWNBACFkQwAAAAAhbEMAAAAAIW1DAAAAACFuQwAAAAAhO0EAIUBBACFvQQEhCUEBIXMMBAsgHkEAOgAQIB5CADcACCAeQgA3AAAgHUIANwAAIB1CADcACCAdQQA6ABAgHEIANwAAIBxCADcACCAcQQA6ABAgAkIANwPQBiACQgA3A9gGIAJCADcD4AYgAiACKQChCjcDkAYgAiACKQCpCjcDmAYgAiACKQCxCjcDoAYgAiACKQC5CjcDqAYgAiACKQDBCjcDsAYgAiACKQDJCjcDuAYgAiACKQDRCjcDwAYgAiACKQDYCjcAxwYgP0NI4fo+lCJBQwAAIEFgRQ0aQgAhCyBBQwAAIEEgOEMAAJZFlCJCIEJDAAAgQV0bIkIgQiBBXhtD2w9JQJQgP5UQ44CAgAAhQiACQgA3A4AHIAJCADcD+AYgQUMAACBBIDhDAIA7RZQiOCA4QwAAIEFdGyI4IDggQV4bQ9sPSUCUID+VEOOAgIAAIUEgAkIANwPwBiACQgA3A+gGQ83MzD4hlwEgQiBCQwAAgD8gQiBCQ83MzD6SlEMAAIA/kpUimAGUIpkBlCGaASBBIEFDAACAPyBBIEFDq6qqP5KUQwAAgD+SlSKbAZQinAGUIZ0BQwAAgD8gP0NvEoM6lCJBIEEgQVwbIkFDAACAPyBBQwAAgD9eGyFxID5D16OQP5QiPkPNTE1DlCA/lSFlID5DMzOYQ5QgP5UhZiA+Q83MuEOUID+VIWcgPkPNrAJElCA/lSFoID5DAAAHRJQgP5UhaSA+QwAASESUID+VIWpDAAAAACFZID9DAAAAAJT8ASFyRAAAAAAAAAAAIVpDmpmZPyE+Qf8BIYUBQQYhdkMAAAA/IXVBAiFHQ83MTD8hT0EBIWtBACFGQzMzk8BDbxKDOiA3IDcgN1wbIkFDbxKDOiBBQ28SgzpeGyA/lJUQ2YCAgAAhcAwCC0MAAIA/IU8LICRBADoAECAkQgA3AAggJEIANwAAICNCADcAACAjQgA3AAggI0EAOgAQICJCADcAACAiQgA3AAggIkEAOgAQIAJCADcD0AYgAkIANwPYBiACQgA3A+AGIAIgAikAADcDkAYgAiACKQAINwOYBiACIAIpABA3A6AGIAIgAikAGDcDqAYgAiACKQAgNwOwBiACIAIpACg3A7gGIAIgAikAMDcDwAYgAiACKQA3NwDHBiA/Q0jh+j6UIkFDAAAgQWBFDRlCACELIEFDAAAgQSA4QwBAHEaUIkIgQkMAACBBXRsiQiBCIEFeG0PbD0lAlCA/lRDjgICAACFCIAJCADcDgAcgAkIANwP4BiBBQwAAIEEgOEMAwNpFlCI4IDhDAAAgQV0bIjggOCBBXhtD2w9JQJQgP5UQ44CAgAAhQSACQgA3A/AGIAJCADcD6AZDAACAPyGXASBCIEJDAACAPyBCIEJDAACAP5KUQwAAgD+SlSKYAZQimQGUIZoBIEEgQUMAAIA/IEEgQUOrqqo/kpRDAACAP5KVIpsBlCKcAZQhnQFDAACAPyA/Q28SAzqUIkEgQSBBXBsiQUMAAIA/IEFDAACAP14bIXEgPkPNTE1DlCA/lSFlID5DMzOYQ5QgP5UhZiA+Q83MuEOUID+VIWcgPkPNrAJElCA/lSFoID5DAAAHRJQgP5UhaSA+QwAASESUID+VIWpDAAAAACFZID9DAAAAAJT8ASFyRAAAAAAAAAAAIVpDmpmZPyE+Qf8BIYUBQQYhdkMAAAA/IXVBAiFHQQEha0EAIUZDMzOTwENvEoM6IDcgNyA3XBsiQUNvEoM6IEFDbxKDOl4bID+UlRDZgICAACFwC0MAAAAAIV5DAAAAACFfQwAAAAAhYEMAAAAAIWFBACFiQwAAAAAhY0EAIWRDAAAAACFsQwAAAAAhbUMAAAAAIW5DAAAAACE7QQAhQEEAIW9BASEJQQEhc0MAAAAAIXQLQQAhEUMAAAAAITlDAAAAACF3QwAAAAAheEEAIXlBACF6QwAAAAAhe0MAAAAAIXxDAAAAACF9QgAhDUMAAAAAIX5BACF/QQAhgAFDAAAAACGBAUMAAAAAIYIBQwAAAAAhgwFDAAAAACGEAUEAITYMJQsgG0EAOgAQIBtCADcACCAbQgA3AAAgGkIANwAAIBpCADcACCAaQQA6ABAgGUIANwAAIBlCADcACCAZQQA6ABAgAkIANwP4BSACQgA3A4AGIAJCADcDiAYgAiACKQDAAzcDuAUgAiACKQDIAzcDwAUgAiACKQDQAzcDyAUgAiACKQDYAzcD0AUgAiACKQDgAzcD2AUgAiACKQDoAzcD4AUgAiACKQDwAzcD6AUgAiACKQD3AzcA7wUgP0NI4fo+lCJBQwAAIEFgRQ0XQgAhCyBBQwAAekUgQUMAAHpFXRtD2w9JQJQgP5UQ44CAgAAhQSACQgA3A+AHIAJCADcD2AcgAkIANwPQB0MAAIA/ITtDAACAPyA/Q28SAzqUIkIgQiBCXBsiQkMAAIA/IEJDAACAP14bIY4BQwAAgD8gP0Omm8Q6lCJCIEIgQlwbIkJDAACAPyBCQwAAgD9eGyFuQ6uqqj8hbCBBIEFDAACAPyBBIEFDq6qqP5KUQwAAgD+SlSJZlCJelCFfIDlDMzMzP5QhjwEgNyA+lCA/lSGDAUMAAAAAIWAgP0MAAAAAlPwBIUBDAABAwCA/QzEIrDyUlRDZgICAALwhZEQAAAAAAAAAACFaQ83MDEAhPkGAgICEBCE2Q5qZmT4hhAFDj8L1PCGBAUEBIWJB/wEhR0EAIUZDMzOTwCA/Q6abRDyUlRDZgICAACGNAUMAAIC/ID9DzcxMPZSVENmAgIAAIWNDMzOTwENvEoM6IDggOCA4XBsiQUNvEoM6IEFDbxKDOl4bID+UlRDZgICAACFtQwAAAAAhYUMAAAAAIU1DAAAAACFMQwAAAAAhS0MAAAAAIUpDAAAAACFJQwAAAAAhSEMAAAAAIWVDAAAAACFmQwAAAAAhZ0MAAAAAIWhDAAAAACFpQwAAAAAhakEAIWtBASFvQQAhCUMAAAAAIXBDAAAAACFxQwAAAAAhT0EAIXJB/wEhc0MAAAAAIXRDAAAAACF1QQAhdkEAIRFDAAAAACE5QwAAAAAhd0MAAAAAIXhBACF5QQAhekMAAAAAIXtDAAAAACF8QwAAAAAhfUIAIQ1DAAAAACF+QQAhf0EBIYABQwAAgD8hggEMHwsgG0EAOgAQIBtCADcACCAbQgA3AAAgGkIANwAAIBpCADcACCAaQQA6ABAgGUIANwAAIBlCADcACCAZQQA6ABAgAkIANwP4BSACQgA3A4AGIAJCADcDiAYgAiACKQDAAzcDuAUgAiACKQDIAzcDwAUgAiACKQDQAzcDyAUgAiACKQDYAzcD0AUgAiACKQDgAzcD2AUgAiACKQDoAzcD4AUgAiACKQDwAzcD6AUgAiACKQD3AzcA7wUgP0NI4fo+lCJBQwAAIEFgRQ0XQgAhCyBBQwAAlkQgQUMAAJZEXRtD2w9JQJQgP5UQ44CAgAAhQiBBQwAAIEEgN0MAwNpFlEMAgDtFkiI3IDdDAAAgQV0bIjcgNyBBXhtD2w9JQJQgP5UQ44CAgAAhQSACQgA3A/AHIAJCADcD6AcgAkIANwPQByACQgA3A9gHIAJCADcD4AdDq6qqPyFsQwAAgD8hggEgQSBBQwAAgD8gQSBBQ6uqqj+SlEMAAIA/kpUingGUIp8BlCGgAUMAAIA/ID9DbxIDOpQiQSBBIEFcGyJBQwAAgD8gQUMAAIA/XhshjgFDAACAPyA/Q6abxDqUIkEgQSBBXBsiQUMAAIA/IEFDAACAP14bIW4gQiBCQwAAgD8gQiBCQ6uqqj+SlEMAAIA/kpUiWZQiXpQhXyA4QwAAQD+UIY8BIDkgPpQiPkMAADRDlCA/lSGDASA+QwAApUOUID+VIX1DAAAAACFgID9DAAAAAJT8ASFAQwrXozwhe0MAAEDAID9DCtejPJSVENmAgIAAvCJkrSENRAAAAAAAAAAAIVpDZmamPyE+QZiz5vADITZDmJkZPiF+Q5qZGT8hfEEBIWJB/wEhR0EAIWtDAAAAPyE7QQIhRkMzM5PAIDpDbxKDOpcgP5SVENmAgIAAIY0BQzMzk8AgOkPHcRw/lENvEoM6lyA/lJUQ2YCAgAAhbUMAAAAAIWFDAAAAACFjQwAAAAAhTUMAAAAAIUxDAAAAACFLQwAAAAAhSkMAAAAAIUlDAAAAACFIQwAAAAAhZUMAAAAAIWZDAAAAACFnQwAAAAAhaEMAAAAAIWlDAAAAACFqQQEhb0EAIQlDAAAAACFwQwAAAAAhcUMAAAAAIU9BACFyQf8BIXNDAAAAACF0QwAAAAAhdUEAIXZBACERQwAAAAAhOUMAAAAAIXdDAAAAACF4QQEheUEBIXpBASF/QQEhgAFDCtejPCGBAUMAAAAAIYQBQQAhhQEMHwsgP0NI4fo+lCI+QwAAIEFgRQ0XQgAhCyA+QwAAIEEgN0MAgIlElCJBIEFDAAAgQV0bIkEgQSA+XhtD2w9JQJQgP5UQ44CAgAAhPiACQgA3A+AHIAJCADcD2AcgAkIANwPQB0MAACA/IWwgPiA+QwAAgD8gPiA+QwAAID+SlEMAAIA/kpUiWZQiXpQhX0MAAIA/ID9DbxIDOpQiPiA+ID5cGyI+QwAAgD8gPkMAAIA/XhshiQEgP0MCKwc9lPwBIYoBID9DWDm0PJT8ASGLASA/Q1g5NDyU/AEhjAFDAAAAACFjID9DAAAAAJT8ASGQAUQAAAAAAAAAACFaQ5qZmT8hPkH/ASFHQQAhZEEEIWJBASFGQ6uqKj8hYUMAAMA/IWBDMzOTwCA/Q7x0kzyUlRDZgICAACFCQzMzk8BDbxKDOiA4IDggOFwbIkFDbxKDOiBBQ28SgzpeGyA/lJUQ2YCAgAAhiAFDAAAAACFNQwAAAAAhTEMAAAAAIUtDAAAAACFKQwAAAAAhSUMAAAAAIUhDAAAAACFlQwAAAAAhZkMAAAAAIWdDAAAAACFoQwAAAAAhaUMAAAAAIWpBACFrQwAAAAAhbUMAAAAAIW5DAAAAACE7QQAhQEEAIW9BACEJQwAAAAAhcEMAAAAAIXFDAAAAACFPQQAhckH/ASFzQwAAAAAhdEMAAAAAIXVBACF2QQAhEUMAAAAAITlDAAAAACF3QwAAAAAheEEAIXlBACF6QwAAAAAhe0MAAAAAIXxDAAAAACF9QgAhDUMAAAAAIX5BACF/QQAhgAFDAAAAACGBAUMAAAAAIYIBQwAAAAAhgwFDAAAAACGEAUEAITZB/wEhhQFDAAAAACGGAUMAAAAAIYcBQQEhB0EBIQxDAADAPyFBIEIhjQFDAACAPyA/Qxe30TmUIjggOCA4XBsiOEMAAIA/IDhDAACAP14bIjchjgFDAADAPyGPAQwjC0MAAEA/IU8LICdBADoAECAnQgA3AAggJ0IANwAAICZCADcAACAmQgA3AAggJkEAOgAQICVCADcAACAlQgA3AAggJUEAOgAQIAJCADcD0AYgAkIANwPYBiACQgA3A+AGIAIgAikAcDcDkAYgAiACKQB4NwOYBiACIAIpAIABNwOgBiACIAIpAIgBNwOoBiACIAIpAJABNwOwBiACIAIpAJgBNwO4BiACIAIpAKABNwPABiACIAIpAKcBNwDHBiA/Q0jh+j6UIkFDAAAgQWBFDRZCACELIEFDAAAgQSA4QwBg6kWUIkIgQkMAACBBXRsiQiBCIEFeG0PbD0lAlCA/lRDjgICAACFBIAJCADcD8AYgAkIANwPoBiBBIEFDAACAPyBBIEFDq6qqP5KUQwAAgD+SlSKbAZQinAGUIZ0BQwAAgD8gP0NvEgM6lCJBIEEgQVwbIkFDAACAPyBBQwAAgD9eGyFxID5DmvmZQ5QgP5UhZSA+Q8xM5EOUID+VIWYgPkOamQpElCA/lSFnID5DNANERJQgP5UhaCA+QwCASkSUID+VIWkgPkMAAJZElCA/lSFqQwAAAAAhWSA/QwAAAACU/AEhckQAAAAAAAAAACFaQ5qZmT8hPkEGIXZDAAAAPyF1QzMzsz4hdEH/ASFzQQIhR0EBIWtBACFGQzMzk8BDbxKDOiA3IDcgN1wbIkFDbxKDOiBBQ28SgzpeGyA/lJUQ2YCAgAAhcEMAAAAAIV5DAAAAACFfQwAAAAAhYEMAAAAAIWFBACFiQwAAAAAhY0EAIWRDAAAAACFsQwAAAAAhbUMAAAAAIW5DAAAAACE7QQAhQEEAIW9BASEJDB0LQQAhRiAbQQA6ABAgG0IANwAIIBtCADcAACAaQgA3AAAgGkIANwAIIBpBADoAECAZQgA3AAAgGUIANwAIIBlBADoAECACQgA3A/gFIAJCADcDgAYgAkIANwOIBiACIAIpAMADNwO4BSACIAIpAMgDNwPABSACIAIpANADNwPIBSACIAIpANgDNwPQBSACIAIpAOADNwPYBSACIAIpAOgDNwPgBSACIAIpAPADNwPoBSACIAIpAPcDNwDvBUMAAIA/IYIBQwAAgD8gP0Omm8Q6lCJBIEEgQVwbIkFDAACAPyBBQwAAgD9eGyFuIDlDmpmZPpQhOyA+QwCgxESUID+VIXcgPkMAYIVElCA/lSF4ID5DAMAbRJQgP5UhfSA+QwAA3EOUID+VIYMBQwAAAAAhWSA/QwAAAACU/AEhQEMAAEDAID9DbxKDOpSVENmAgIAAIUFEAAAAAAAAAAAhWkPNzIw/IT5BASFvQf8BIUdDMzOTwENvEoM6IDggOCA4XBsiQkNvEoM6IEJDbxKDOl4bID+UlRDZgICAACFtQwAAAAAhXkMAAAAAIV9DAAAAACFgQwAAAAAhYUEAIWJDAAAAACFjQwAAAAAhTUMAAAAAIUxDAAAAACFLQwAAAAAhSkMAAAAAIUlDAAAAACFIQwAAAAAhZUMAAAAAIWZDAAAAACFnQwAAAAAhaEMAAAAAIWlDAAAAACFqQQAha0MAAAAAIWxBACEJQwAAAAAhcEMAAAAAIXFDAAAAACFPQQAhckH/ASFzQwAAAAAhdEMAAAAAIXVBACF2QQEhEUEAIXlBASF6QwAAAAAheyA6QzMzMz+UQ5qZGT6SIjkhfCBBvCJkrSILIQ1DAAAAACF+QQEhf0EBIYABQwAAAAAhgQEMHQtBACFGIBtBADoAEEIAIQsgG0IANwAIIBtCADcAACAaQgA3AAAgGkIANwAIIBpBADoAECAZQgA3AAAgGUIANwAIIBlBADoAECACQgA3A/gFIAJCADcDgAYgAkIANwOIBiACIAIpAMADNwO4BSACIAIpAMgDNwPABSACIAIpANADNwPIBSACIAIpANgDNwPQBSACIAIpAOADNwPYBSACIAIpAOgDNwPgBSACIAIpAPADNwPoBSACIAIpAPcDNwDvBUMAAIA/IYIBQwAAgD8gP0Omm8Q6lCJBIEEgQVwbIkFDAACAPyBBQwAAgD9eGyFuIDlDzcxMP5QhOyA6QwAAAD+UIXwgPkMAAERDlCI+ID+VIYMBID5DAICbQ5RDAABEQ5UgP5UhfUMAAAAAIVkgP0MAAAAAlPwBIUBDAABAwCA/QylcDz2UlRDZgICAALwiZK0hDUQAAAAAAAAAACFaQ5qZmT8hPkHMmbP2AyE2QwrXIz0hgQFDzMzMPiF+QQEhb0H/ASFHQzMzk8BDbxKDOiA4IDggOFwbIkFDbxKDOiBBQ28SgzpeGyA/lJUQ2YCAgAAhbQwBC0EAIUYgG0EAOgAQQgAhCyAbQgA3AAggG0IANwAAIBpCADcAACAaQgA3AAggGkEAOgAQIBlCADcAACAZQgA3AAggGUEAOgAQIAJCADcD+AUgAkIANwOABiACQgA3A4gGIAIgAikAwAM3A7gFIAIgAikAyAM3A8AFIAIgAikA0AM3A8gFIAIgAikA2AM3A9AFIAIgAikA4AM3A9gFIAIgAikA6AM3A+AFIAIgAikA8AM3A+gFIAIgAikA9wM3AO8FQwAAgD8hggFDAACAPyA/Q6abxDqUIkEgQSBBXBsiQUMAAIA/IEFDAACAP14bIW4gOUMzM3M/lCE7IDpDAAAAP5QhfCA+QwAAxEKUIj4gP5UhgwEgPkMAAMA/lCA/lSF9QwAAAAAhWSA/QwAAAACU/AEhQEMAAEDAID9DKVwPPZSVENmAgIAAvCJkrSENRAAAAAAAAAAAIVpDZmamPyE+QZqz5vwDITZDzcxMPSGBAUPMzMw+IX5BASFvQf8BIUdDMzOTwENvEoM6IDggOCA4XBsiQUNvEoM6IEFDbxKDOl4bID+UlRDZgICAACFtC0MAAAAAIV5DAAAAACFfQwAAAAAhYEMAAAAAIWFBACFiQwAAAAAhY0MAAAAAIU1DAAAAACFMQwAAAAAhS0MAAAAAIUpDAAAAACFJQwAAAAAhSEMAAAAAIWVDAAAAACFmQwAAAAAhZ0MAAAAAIWhDAAAAACFpQwAAAAAhakEAIWtDAAAAACFsQQAhCUMAAAAAIXBDAAAAACFxQwAAAAAhT0EAIXJB/wEhc0MAAAAAIXRDAAAAACF1QQAhdkEAIRFDAAAAACE5QwAAAAAhd0MAAAAAIXhBACF5QQEhekMAAAAAIXtBACF/QQEhgAFDAAAAACGEAQwbCyAbQQA6ABAgG0IANwAIIBtCADcAACAaQgA3AAAgGkIANwAIIBpBADoAECAZQgA3AAAgGUIANwAIIBlBADoAECACQgA3A/gFIAJCADcDgAYgAkIANwOIBiACIAIpAMADNwO4BSACIAIpAMgDNwPABSACIAIpANADNwPIBSACIAIpANgDNwPQBSACIAIpAOADNwPYBSACIAIpAOgDNwPgBSACIAIpAPADNwPoBSACIAIpAPcDNwDvBSA/Q0jh+j6UIkFDAAAgQWBFDRJCACELIEFDAAB6RSBBQwAAekVdG0PbD0lAlCA/lRDjgICAACFBIAJCADcD4AcgAkIANwPYByACQgA3A9AHQwAAgD8hggFDAACAPyA/Qxe3UTmUIkIgQiBCXBsiQkMAAIA/IEJDAACAP14bIY4BQwAAgD8gP0Omm8Q6lCJCIEIgQlwbIkJDAACAPyBCQwAAgD9eGyFuQ6uqqj8hbCBBIEFDAACAPyBBIEFDq6qqP5KUQwAAgD+SlSJZlCJelCFfIDlDzczMPZQhjwEgOkOamRk/lCF8IDlDmpkZP5QhOyA+QwBAtUSUID+VIYMBID5DALB0RZQgP5UhfUMAAAAAIWAgP0MAAAAAlPwBIUBDAABAwCA/QwrXozuUlRDZgICAALwhZEMAAEDAID9DbxKDOpSVENmAgIAAvK0hDUQAAAAAAAAAACFaQzMzsz8hPkHAmbPqAyE2QQEhYkH/ASFHQQAha0ECIUZDMzOTwCA/Q28SgzuUlRDZgICAACGNAUMzM5PAQ28SgzogOCA4IDhcGyJBQ28SgzogQUNvEoM6XhsgP5SVENmAgIAAIW1DAAAAACFhQwAAAAAhY0MAAAAAIU1DAAAAACFMQwAAAAAhS0MAAAAAIUpDAAAAACFJQwAAAAAhSEMAAAAAIWVDAAAAACFmQwAAAAAhZ0MAAAAAIWhDAAAAACFpQwAAAAAhakEBIW9BACEJQwAAAAAhcEMAAAAAIXFDAAAAACFPQQAhckH/ASFzQwAAAAAhdEMAAAAAIXVBACF2QQAhEUMAAAAAITlDAAAAACF3QwAAAAAheEEAIXlBASF6QwAAAAAhe0MAAAAAIX5BACF/QQEhgAFDAAAAACGBAQwVCyA/Q0jh+j6UIkFDAAAgQWBFDRJCACELIEFDAAAgQUMAoIxGIDpDAAAAP5IgPkMAIMtFlJQiPiA+ID5cGyI+QwCgjEYgPkMAoIxGXRsiPiA+QwAAIEFdGyI+ID4gQV4bQ9sPSUCUID+VEOOAgIAAIT4gQUMAgDtFIEFDAIA7RV0bQ9sPSUCUID+VEOOAgIAAIUEgAkIANwPwByACQgA3A+gHIAJCADcD0AcgAkIANwPYByACQgA3A+AHQ1VVVT8hbCA+ID5DAACAPyA+ID5DVVVVP5KUQwAAgD+SlSJZlCJelCFfQwAAgD8gP0NvEoM7lCI+ID4gPlwbIj5DAACAPyA+QwAAgD9eGyGOASBBIEFDAACAPyBBIEFDq6qqP5KUQwAAgD+SlSKeAZQinwGUIaABIDlDZmZmP5QhjwFDAAAAACFgID9DAAAAAJT8ASGQAUQAAAAAAAAAACFaQ5qZmT8hPkECIYUBQf8BIUdBACFkQQEhRkMzM5PAQ28SgzogOCA4IDhcGyJBQ28SgzogQUNvEoM6XhsgP5SVENmAgIAAIY0BQwAAAAAhYUEBIWJDAAAAACFjQwAAAAAhTUMAAAAAIUxDAAAAACFLQwAAAAAhSkMAAAAAIUlDAAAAACFIQwAAAAAhZUMAAAAAIWZDAAAAACFnQwAAAAAhaEMAAAAAIWlDAAAAACFqQQAha0MAAAAAIW1DAAAAACFuQwAAAAAhO0EAIUBBACFvQQAhCUMAAAAAIXBDAAAAACFxQwAAAAAhT0EAIXJB/wEhc0MAAAAAIXRDAAAAACF1QQAhdkEAIRFDAAAAACE5QwAAAAAhd0MAAAAAIXhBACF5QQAhekMAAAAAIXtDAAAAACF8QwAAAAAhfUIAIQ1DAAAAACF+QQAhf0EAIYABQwAAAAAhgQFDAAAAACGCAUMAAAAAIYMBQwAAAAAhhAFBACE2QwAAAAAhhgFDAAAAACGHAUEBIQcMAQsgP0NI4fo+lCJBQwAAIEFgRQ0SQgAhCyBBQwAAIEFDAAB6RiA6QwCAu0WUQwCAu0SSID6UIj4gPiA+XBsiPkMAAHpGID5DAAB6Rl0bIj4gPkMAACBBXRsiPiA+IEFeG0PbD0lAlCA/lRDjgICAACE+IAJCADcD4AcgAkIANwPYByACQgA3A9AHQ6uqqj8hbCA+ID5DAACAPyA+ID5Dq6qqP5KUQwAAgD+SlSJZlCJelCFfQwAAgD8gP0NvEgM8lCI+ID4gPlwbIj5DAACAPyA+QwAAgD9eGyGOASA5Q2ZmJj+UIY8BQwAAAAAhOSA/QwAAAACU/AEhkAFEAAAAAAAAAAAhWkOamZk/IT5BASEHQf8BIUdBACFAQQIhRkMzM5PAQ28SgzogOCA4IDhcGyJBQ28SgzogQUNvEoM6XhsgP5SVENmAgIAAIY0BQwAAAAAhYEMAAAAAIWFBASFiQwAAAAAhY0EAIWRDAAAAACFNQwAAAAAhTEMAAAAAIUtDAAAAACFKQwAAAAAhSUMAAAAAIUhDAAAAACFlQwAAAAAhZkMAAAAAIWdDAAAAACFoQwAAAAAhaUMAAAAAIWpBACFrQwAAAAAhbUMAAAAAIW5DAAAAACE7QQAhb0EAIQlDAAAAACFwQwAAAAAhcUMAAAAAIU9BACFyQf8BIXNDAAAAACF0QwAAAAAhdUEAIXZBACERQwAAAAAhd0MAAAAAIXhBACF5QQAhekMAAAAAIXtDAAAAACF8QwAAAAAhfUIAIQ1DAAAAACF+QQAhf0EAIYABQwAAAAAhgQFDAAAAACGCAUMAAAAAIYMBQwAAAAAhhAFBACE2Qf8BIYUBQwAAAAAhhgFDAAAAACGHAQtBACEMQwAAAAAhiAFDAAAAACGJAUMAAAAAIUFBACGKAUMAAAAAIUJDAAAAACE3QQAhiwFBACGMAQwZCyBHIEZBlIvAgAAQi4CAgAAACyACQYCAgI0ENgL4BiACIFA4AugHIAJBgYCAgACtQiCGIgsgAkHoB2qthDcDyAMgAiALIAJB+AZqrYQ3A8ADQc+BwIAAIAJBwANqQcSIwIAAEIKAgIAAAAsgAkGAgICJBDYC+AYgAiBBOALoByACQYGAgIAArUIghiILIAJB6AdqrYQ3A8gDIAIgCyACQfgGaq2ENwPAA0HPgcCAACACQcADakHEiMCAABCCgICAAAALIAJBgICAiQQ2AvgGIAIgQTgC6AcgAkGBgICAAK1CIIYiCyACQegHaq2ENwPIAyACIAsgAkH4BmqthDcDwANBz4HAgAAgAkHAA2pBxIjAgAAQgoCAgAAACyACQYCAgIkENgL4BiACIEE4AugHIAJBgYCAgACtQiCGIgsgAkHoB2qthDcDyAMgAiALIAJB+AZqrYQ3A8ADQc+BwIAAIAJBwANqQcSIwIAAEIKAgIAAAAsgAkGAgICJBDYC+AYgAiBBOALoByACQYGAgIAArUIghiILIAJB6AdqrYQ3A8gDIAIgCyACQfgGaq2ENwPAA0HPgcCAACACQcADakHEiMCAABCCgICAAAALIAJBgICAiQQ2AvgGIAIgPjgC6AcgAkGBgICAAK1CIIYiCyACQegHaq2ENwPIAyACIAsgAkH4BmqthDcDwANBz4HAgAAgAkHAA2pBxIjAgAAQgoCAgAAACyACQYCAgIkENgL4BiACIEE4AugHIAJBgYCAgACtQiCGIgsgAkHoB2qthDcDyAMgAiALIAJB+AZqrYQ3A8ADQc+BwIAAIAJBwANqQcSIwIAAEIKAgIAAAAsgAkGAgICJBDYC+AYgAiBBOALoByACQYGAgIAArUIghiILIAJB6AdqrYQ3A8gDIAIgCyACQfgGaq2ENwPAA0HPgcCAACACQcADakHEiMCAABCCgICAAAALIAJBgICAiQQ2AvgGIAIgQTgC6AcgAkGBgICAAK1CIIYiCyACQegHaq2ENwPIAyACIAsgAkH4BmqthDcDwANBz4HAgAAgAkHAA2pBxIjAgAAQgoCAgAAACyACQYCAgIkENgL4BiACIEE4AugHIAJBgYCAgACtQiCGIgsgAkHoB2qthDcDyAMgAiALIAJB+AZqrYQ3A8ADQc+BwIAAIAJBwANqQcSIwIAAEIKAgIAAAAsgAkGAgICJBDYC+AYgAiBBOALoByACQYGAgIAArUIghiILIAJB6AdqrYQ3A8gDIAIgCyACQfgGaq2ENwPAA0HPgcCAACACQcADakHEiMCAABCCgICAAAALIAJBgICAiQQ2AvgGIAIgQTgC6AcgAkGBgICAAK1CIIYiCyACQegHaq2ENwPIAyACIAsgAkH4BmqthDcDwANBz4HAgAAgAkHAA2pBxIjAgAAQgoCAgAAACyACQYCAgIkENgL4BiACID44AugHIAJBgYCAgACtQiCGIgsgAkHoB2qthDcDyAMgAiALIAJB+AZqrYQ3A8ADQc+BwIAAIAJBwANqQcSIwIAAEIKAgIAAAAsgAkGAgICJBDYC+AYgAiBBOALoByACQYGAgIAArUIghiILIAJB6AdqrYQ3A8gDIAIgCyACQfgGaq2ENwPAA0HPgcCAACACQcADakHEiMCAABCCgICAAAALIAJBgICAiQQ2AvgGIAIgQTgC6AcgAkGBgICAAK1CIIYiCyACQegHaq2ENwPIAyACIAsgAkH4BmqthDcDwANBz4HAgAAgAkHAA2pBxIjAgAAQgoCAgAAACyACQYCAgIkENgL4BiACIEE4AugHIAJBgYCAgACtQiCGIgsgAkHoB2qthDcDyAMgAiALIAJB+AZqrYQ3A8ADQc+BwIAAIAJBwANqQcSIwIAAEIKAgIAAAAsgAkGAgICJBDYC+AYgAiBBOALoByACQYGAgIAArUIghiILIAJB6AdqrYQ3A8gDIAIgCyACQfgGaq2ENwPAA0HPgcCAACACQcADakHEiMCAABCCgICAAAALQwAAAAAhhAELQf8BIYUBC0MAAAAAIYYBQwAAAAAhhwFBASEHQQAhDEMAAAAAIYgBQwAAAAAhiQFDAAAAACFBQQAhigFDAAAAACFCQwAAAAAhN0EAIYsBQQAhjAEgQCGQAQwEC0EAIRFDAAAAACE5QwAAAAAhd0MAAAAAIXhBACF5QQAhekMAAAAAIXtDAAAAACF8QwAAAAAhfUIAIQ1DAAAAACF+QQAhf0EAIYABQwAAAAAhgQFDAAAAACGCAUMAAAAAIYMBC0MAAAAAIYQBQQAhNgtB/wEhhQELQwAAAAAhhgFDAAAAACGHAUEAIQdBACEMQwAAAAAhiAFDAAAAACGJAUMAAAAAIUFBACGKAUMAAAAAIUJDAAAAACE3QQAhiwFBACGMAUMAAAAAIY0BQwAAAAAhjgFDAAAAACGPAUEAIZABC0MAAAAAIZEBQwAAAAAhkgFBACGTAUMAAAAAIZQBC0EAIQhDAAAAACFdQwAAAAAhVkMAAAAAITpBACFcQf8BIZUBQQAhlgFEAAAAAAAAAAAhWwsgAC0AuCMhoQFDAACAP0MAAIC/IDwgPEMAAIC/XRsiOCA4QwAAgD9eG0MAAIA/kkPbD0lAlEMAAIA+lCI4EOCAgIAAITwgOBDcgICAACGiAUMAAIA/ITgCQCA+QwAAAABeRQ0AQwAAgD9DAACAP0MAAIC/ID4gPiA+lCI4IDggOEMAAL1DkpRDAFqHRpKUQ8D3A0iSlCA4IDggOEMAAOBBlEMA4ERFkpRDAKJzR5KUQ8D3A0iSlSI4IDhDAACAv10bIjggOEMAAIA/XhuVITgLIAQgACgCCCIKTw0CIAAoAgQgQ2ogREGoCWxqIgogUDgCJCAKIFE4AiAgCiBaOQMYIAogWzkDECAKQgA3AwggCiA8QwAAgD9D8wS1PyChAUECSxsiowGUOAIEIAogogEgowGUOAIAIAogAikDwAM3AyggCiACKQPIAzcDMCAKIAg2AmwgCiCWATYCaCAKIJUBOgBkIApB/rTW/AM2AmAgCkLotLv9k+XZnT83A1ggCiBYOAJUIApCzZmz8tOZs8Y/NwJMIAogUjgCSCAKIFc4AkQgCiBVOAJAIAogVDgCPCAKIFM4AjggCiBcNgKIASAKIDo4AowBIAogVjgCkAEgCiBdOAKUASAKQQA6AJgBIAogAikD2Ag3A4ABIAogAikD0Ag3A3ggCiACKQPICDcDcCAKIAIpA4gINwCZASAKIAIpA5AINwChASAKIAIpA5gINwCpASAKIAIpA6AINwCxASAKIAIpA6gINwC5ASAKIAIpA7AINwDBASAKIAIpA7gINwDJASAKIAIpAL8INwDQASAKIIYBOAKYAiAKIIcBOAKUAiAKIJEBOAKQAiAKIJIBOAKMAiAKID84AogCIAogRUEBckG178nkAmw2AoQCIApCgICA/IOAgMA/NwL8ASAKQwAAgEBDAAAAACA9ID1DAAAAAF0bIj8gP0MAAIBAXhsgTpQ4AvgBIAogODgC9AEgCiA+OALwASAKIJMBNgLsASAKIJQBOALoASAKIDs4AuQBIApBADYC4AEgCiAIOgDcASAKQQA7AdgBIAogAikD+Ac3ApwCIAogAikDgAg3AqQCIAogoAE4ArwCIAognwE4ArgCIAogngE4ArQCIApBq9Wq/QM2ArACIApBADoArAIgCiACKQPwBzcDyAIgCiACKQPoBzcDwAIgCiBiNgL4AiAKIEY6APQCIApCADcC7AIgCiBhOALoAiAKIGA4AuQCIAogXzgC4AIgCiBeOALcAiAKIFk4AtgCIAogbDgC1AIgCiCFAToA0AIgCiACKQPgBzcCjAMgCiACKQPYBzcChAMgCiACKQPQBzcC/AIgCkH/AToAjAQgCiAHOgDoAyAKQQA7AeQDIAogDDoA4AMgCiCIATgC3AMgCiCJATgC2AMgCiBBOALUAyAKIIoBNgLQAyAKIAw6AMwDIAogQjgCyAMgCiA3OALEAyAKIEE4AsADIAogiwE2ArwDIAogDDoAuAMgCiBCOAK0AyAKIDc4ArADIAogQTgCrAMgCiCMATYCqAMgCiAHOgCkAyAKII0BOAKgAyAKII4BOAKcAyAKII8BOAKYAyAKIJABNgKUAyAKIAIoAMwHNgCtBCAKIAIpAMQHNwClBCAKIAIpALwHNwCdBCAKIAIpALQHNwCVBCAKIAIpAKwHNwCNBCAKIAIpAI0HNwCxBCAKIAIpAJUHNwC5BCAKIAIpAJ0HNwDBBCAKIAIpAKQHNwDIBCAKQdAEaiACQYACakHQAPwKAAAgCiCaATgCgAcgCiCZATgC/AYgCiCYATgC+AYgCiCXATgC9AYgCiB0OALwBiAKIHU4AuwGIAogdjYC6AYgCiBqOALkBiAKIGk4AuAGIAogaDgC3AYgCiBnOALYBiAKIGY4AtQGIAogZTgC0AYgCiBIOALMBiAKIEk4AsgGIAogSjgCxAYgCiBLOALABiAKIEw4ArwGIAogTTgCuAYgCkEAOgC1BiAKIBE6ALQGIApBADYCsAYgCiA5OAKsBiAKIHc4AqgGIApBADYCpAYgCiALNwKcBiAKQgA3ApQGIApBADoAkQYgCiAROgCQBiAKQQA2AowGIAogOTgCiAYgCiB4OAKEBiAKQQA2AoAGIAogCzcD+AUgCkIANwPwBSAKIHk6AO0FIAogejoA7AUgCiB7OALoBSAKIHw4AuQFIAogfTgC4AUgCkEANgLcBSAKIA03AtQFIApBADYC0AUgCiB+OALMBSAKIH86AMkFIAoggAE6AMgFIAoggQE4AsQFIAogggE4AsAFIAoggwE4ArwFIApBADYCuAUgCiBjOAK0BSAKIGQ2ArAFIAoghAE4AqwFIAogNjYCqAUgCkEAOgCkBSAKQQA7AaAFIAogmwE4ApwHIAognAE4AqAHIAognQE4AqQHIApBq9Wq/QM2ApgHIAogczoAlAcgCiBrNgK8ByAKIEc6ALgHIAogAikDgAc3AowHIAogAikD+AY3AoQHIAogAikD6AY3A6gHIAogAikD8AY3A7AHIAogAikD0AY3A8AHIAogAikD2AY3A8gHIAogAikD4AY3A9AHIAogCToA6AcgCiBwOALkByAKIHE4AuAHIAogTzgC3AcgCiByNgLYByAKIAIpA5AGNwDpByAKIAIpA5gGNwDxByAKIAIpA6AGNwD5ByAKIAIpA6gGNwCBCCAKIAIpA7AGNwCJCCAKIAIpA7gGNwCRCCAKIAIpA8AGNwCZCCAKIAIpAMcGNwCgCCAKIG82ArAIIAogCToArAggCkEAOwGoCCAKIAIpA4gGNwLECCAKIAIpA4AGNwK8CCAKIAIpA/gFNwK0CCAKQQA6ANwIIAogbTgC2AggCiBuOALUCCAKIDs4AtAIIAogQDYCzAggCiACKQDvBTcAlAkgCiACKQPoBTcAjQkgCiACKQPgBTcAhQkgCiACKQPYBTcA/QggCiACKQPQBTcA9QggCiACKQPIBTcA7QggCiACKQPABTcA5QggCiACKQO4BTcA3QggCkEBOgCgCSAKQQA7AZwJCyA0QQFqIjQgA0cNAAsgAyE0IBIhNgwBCyAEIApBhIrAgAAQi4CAgAAACwJAAkACQAJAIDZBAXQiCiAzQQF0IgxJDQAgCiAMayKAAUECdCF5IDNBA3QhcgJAIAogDEYibw0AIAAgcmohCgJAIHlFIgwNACAKQbALakEAIHn8CwALIAwNACAKQbATakEAIHn8CwALIBMgeWoheiAAKAIEImQgACgCCEHQEmxqIXNBACF/QQANAgwBCyAMIApBgAJBlIrAgAAQjICAgAAAC0EBIQoMAQtBACEKCwJAA0ACQAJAAkACQAJAAkAgCg4CAAEBCyB/IGRGDQQgf0GgCWohCiB/QagJaiIMIX8gCi0AAA0BDAMLIGQhQwJAA0AgQyBzRg0HIENB0BJqIWQgQ0GgCWotAAANASBDQcgSaiEKIGQhQyAKLQAAQQFHDQALIGRBsG1qQagJaiFDIGQhfwwCCyBDQagJaiF/DAELIAxB2HZqIUMgDCF/CyAAKAIsIYUBIAAoAighkAECQCBvDQAgeUUNACATQQAgefwLAAsgQygC4AEhdgJAIEMtAMgFRQ0AIENBqAVqIUYgAiBDQbAIaiJHQfAA/AoAAAJAAkAgQy0A7AVBAUYNAEEkIQoMAQsCQCBDLQCQBkEBRg0AQcgAIQoMAQtBkAFB7AAgQy0AtAYbIQoLIEMqAuQBIT4gAkHwAGogRkGQAfwKAAACQCBvDQBDAACAPyA+lUMAAAAAID5DAAAAAF4bITkgAkHwAGogCmohCUEAIQggAi0AbCEHIAItAG0hQCACKAIUITMgAioCDCE8IAIqAgghOiACKgIYIT0gAioCECE3IAIoAgQhBCACKAIAIUUgEyERA0ACQAJAAkACQAJAAkACQAJAIAQgRU8NACAEQQRPDQEgCCB2aiAyIARBFGxqIgooAgBPDQILIAcgQHFBAXFFDQIgMyEKDAQLIARBBEGkisCAABCLgICAAAALIAIgCi0AECIMOgBtIAJBAToAbCAEQQFqIQQgCioCDCE9IAoqAgghPiAKKgIEITcgDA0BIDcgOpMgPpUhPEEAIUAMAwsgB0EBcQ0CQwAAAAAgOiA9lCI+ID6LQwjlPB5dGyE6QQAhBwwDC0MAAIA/QwAAgL8gPpUQ2YCAgACTITwgPkMAAKBAlPwBIQoLIAogCkEAR2shMyA6IDcgOpMgPJSSITpBASFAAkAgCkECSQ0AQQEhBwwCC0EAIQcgAkEAOgBsDAELIDogPJIhOgJAAkAgPEMAAAAAYEUNACA6IDdgDQELQQEhByA8QwAAAABdRQ0BIDogN19FDQELQQAhByACQQA6AGwgNyE6CyA5IDqUITggAkHwAGohCkMAAAAAIT8DQCAKQwAAAAAgCioCACI+IApBCGoqAgCUIkEgQYtDCOU8Hl0bOAIAIApBBGoiDEMAAAAAIAwqAgAiQSAKQQxqKgIAlCJCIEKLQwjlPB5dGzgCACAKQRBqIgwgDCoCAENmZuY+IEEgPkMAAIA/kpIgOCAKQRxqKgIAlEMAAIA/kpQgCkEUaioCAJQiPiA+ID5cGyI+Q2Zm5j4gPkNmZuY+XRuSIj5DAACAv5IgPiA+QwAAgD9gGyI+OAIAIApBGGoqAgAhQQJAAkAgCkEhai0AAA0AAkACQCA+Q9sPyUCUIj5D2w/JwJIgPiA+Q9sPSUBeGyI+Q9sPyT9eDQAgPkPbD8m/XUUNAUPbD0nAID6TIT4MAQtD2w9JQCA+kyE+CyA+QwAAgD8gPiA+lCJCQ6uqKj4gQiBCQwCAncWVQ4mICDySlJOUk5QhPgwBCyA+QwAAAL+Si0MAAIDAlEMAAIA/kiE+CyA/IEEgPpSSIT8gCkEkaiIKIAlHDQALIBEgOiA/lCARKgIAkjgCACAIQQFqIQggEUEEaiIRIHpHDQALIAIgPTgCGCACIDc4AhAgAiAzNgIUIAIgPDgCDCACIDo4AgggAiAENgIECyBHIAJB8AD8CgAAIEYgAkHwAGpBkAH8CgAACyBDQbACaiFrIEMoAoQCIQxBACEKQQEhRANAAkAgayAKQbwBbGoiYi0AuAFFDQAgAkGAAmogYkG8AfwKAAACQCBvDQAgAi0AtAMhBCACLQC1AyFFIAIoAtwCIUcgAioC1AIhSCACKgLQAiE/IAIqAuACIWUgAioC2AIhSiACKALMAiEJIAIqApgCITkgAioCnAIhPSACKgK8AiFBIAIqAsACIUIgAigCyAIhMyACKgKAAiFmIAIqAowCIWAgAioClAIhZyACKgKQAiFOIAIqAogCIUsgAioChAIhYSACLQCgAiFAIAIqAqQCIV8gAi0AxAIhRiACKgKwAiFNIAIqArgCIWMgAioCtAIhSSACKgKsAiE7IAIqAqgCIU8gdiERIHkhByATIQgDQCAIIQogTyBBlCA7IAxBDXQgDHMiDEERdiAMcyIMQQV0IAxzIgyzQwAAgC+UIj4gPpJDAACAv5IiOiBCkyI4lJIhPgJAIElDAAAAAF5FDQAgY0MAAIA/QwAAgL9DAACgQEMAAKDAIEkgPpQiPiA+QwAAoMBdGyI+ID5DAACgQF4bIj4gPiA+lCI+ID4gPkMAAL1DkpRDAFqHRpKUQ8D3A0iSlCA+ID4gPkMAAOBBlEMA4ERFkpRDAKJzR5KUQ8D3A0iSlSI+ID5DAACAv10bIj4gPkMAAIA/XhuUIT4LIEIgOyBBlJIgTSA4lJIiOCE3AkACQAJAIEYOAwIAAQILIF8gPpQhNwwBCyA6IF8gPpSTIDiTITcLAkACQCBAQf8BRw0AIDchOgwBCyBhIDmUIEsgNyA9kyJMlJIhPAJAIE5DAAAAAF5FDQAgZ0MAAIA/QwAAgL9DAACgQEMAAKDAIE4gPJQiOiA6QwAAoMBdGyI6IDpDAACgQF4bIjogOiA6lCI6IDogOkMAAL1DkpRDAFqHRpKUQ8D3A0iSlCA6IDogOkMAAOBBlEMA4ERFkpRDAKJzR5KUQ8D3A0iSlSI6IDpDAACAv10bIjogOkMAAIA/XhuUITwLQwAAAAAgPSBLIDmUkiBgIEyUkiI6IDqSID2TIj0gPYtDCOU8Hl0bIT1DAAAAACA8IDySIDmTIjkgOYtDCOU8Hl0bITkCQAJAIEAOAwIAAQILIGYgPJQhOgwBCyA3IGYgPJSTIDqTIToLAkACQAJAAkACQAJAAkACQCAJIDNPDQAgCUEETw0BIBEgMSAJQRRsaiIIKAIATw0CCyAEIEVxQQFxRQ0CIEchBAwECyAJQQRBpIrAgAAQi4CAgAAACyACIAgtABAiBDoAtQMgAkEBOgC0AyAJQQFqIQkgCCoCDCFlIAgqAgghPCAIKgIEIUogBA0BIEogP5MgPJUhSEEAIUUMAwsgBEEBcQ0CQwAAAAAgPyBllCI/ID+LQwjlPB5dGyE/QQAhBAwDC0MAAIA/QwAAgL8gPJUQ2YCAgACTIUggPEMAAKBAlPwBIQQLIAQgBEEAR2shRyA/IEogP5MgSJSSIT9BASFFAkAgBEECSQ0AQQEhBAwCC0EAIQQgAkEAOgC0AwwBCyA/IEiSIT8CQAJAIEhDAAAAAGBFDQAgPyBKYA0BC0EBIQQgSEMAAAAAXUUNASA/IEpfRQ0BC0EAIQQgAkEAOgC0AyBKIT8LIApBBGohCEMAAAAAIDggOJIgQpMiQiBCi0MI5TweXRshQkMAAAAAID4gPpIgQZMiPiA+i0MI5TweXRshQSAKIAoqAgAgOiA/lJI4AgAgEUEBaiERIAdBfGoiBw0ACyACIEE4ArwCIAIgQjgCwAIgAiA9OAKcAiACIGU4AuACIAIgSjgC2AIgAiAJNgLMAiACIDk4ApgCIAIgRzYC3AIgAiBIOALUAiACID84AtACCyBiIAJBgAJqQbwB/AoAAAtBASEKIERBAXEhCUEAIUQgCQ0ACwJAIEMtAKwIRQ0AIAJBwANqIENBuAZqImJB+AH8CgAAAkAgbw0AQwAAgD8gAioC7AMigQGTIY8BQwAAgD8gAioC6AMie5MhgwFDAACAPyACKgLkAyJxkyGCAUMAAIA/IAIqAuADImWTIX1DAACAPyACKgLcAyJLkyF0QwAAgD8gAioC2AMiOJMhZiACLQCwBSEIIAItALEFIUYgAigC2AQhRCACKgLQBCFJIAIqAswEIT4gAioC3AQhbSACKgLUBCFKIAIoAsgEIQkgAigCxAQhRyACKgKgBCFuIAIqAqwEIWcgAioCtAQhdSACKgKwBCFhIAIqAqgEIUwgAioCpAQhaCACLQDABCFFIAIqAvgDIV8gAioC/AMhcCACKgKIBCFpIAIqApAEIXcgAioCjAQhYyACKgKEBCFNIAIqAoAEIWogAi0AnAQhMyACKgL0AyFgIAIqArgEITogAioCvAQhPCACKgKUBCE3IAIqApgEITkgAioC1AMhfiACKgLQAyF4IAIqAswDIWwgAioCyAMhTiACKgLEAyE7IAIqAsADIT8gAigC8AMiBEEGRiFrIHkhQCB2IREgEyEHA0AgByEKAkACQCAEDQBDAAAAACFBDAELID9DAAAAP0MAAAC/ID9DAAAAP10iBxuSIUECQAJAID8gOF0NAEMAAAAAIUIgPyBmXkUNASA/QwAAgL+SIDiVIkIgQiBCIEKUkpJDAACAP5IhQgwBCyA/IDiVIkIgQpIgQiBClJNDAACAv5IhQgsCQAJAIEEgOF0NAEMAAAAAIT0gQSBmXkUNASBBQwAAgL+SIDiVIkEgQSBBIEGUkpJDAACAP5IhPQwBCyBBIDiVIkEgQZIgQSBBlJNDAACAv5IhPQsgOCA/kiI/QwAAgL+SID8gP0MAAIA/YBshP0MAAIA/QwAAgL8gBxsgQpIgPZMhQSAEQQFGDQAgO0MAAAA/QwAAAL8gO0MAAAA/XSIHG5IhQgJAAkAgOyBLXQ0AQwAAAAAhPSA7IHReRQ0BIDtDAACAv5IgS5UiPSA9ID0gPZSSkkMAAIA/kiE9DAELIDsgS5UiPSA9kiA9ID2Uk0MAAIC/kiE9CwJAAkAgQiBLXQ0AQwAAAAAhSCBCIHReRQ0BIEJDAACAv5IgS5UiQiBCIEIgQpSSkkMAAIA/kiFIDAELIEIgS5UiQiBCkiBCIEKUk0MAAIC/kiFICyBLIDuSIkJDAACAv5IgQiBCQwAAgD9gGyE7IEFDAACAP0MAAIC/IAcbID2SIEiTkiFBIARBAkYNACBOQwAAAD9DAAAAvyBOQwAAAD9dIgcbkiFCAkACQCBOIGVdDQBDAAAAACE9IE4gfV5FDQEgTkMAAIC/kiBllSI9ID0gPSA9lJKSQwAAgD+SIT0MAQsgTiBllSI9ID2SID0gPZSTQwAAgL+SIT0LAkACQCBCIGVdDQBDAAAAACFIIEIgfV5FDQEgQkMAAIC/kiBllSJCIEIgQiBClJKSQwAAgD+SIUgMAQsgQiBllSJCIEKSIEIgQpSTQwAAgL+SIUgLIGUgTpIiQkMAAIC/kiBCIEJDAACAP2AbIU4gQUMAAIA/QwAAgL8gBxsgPZIgSJOSIUEgBEEDRg0AIGxDAAAAP0MAAAC/IGxDAAAAP10iBxuSIUICQAJAIGwgcV0NAEMAAAAAIT0gbCCCAV5FDQEgbEMAAIC/kiBxlSI9ID0gPSA9lJKSQwAAgD+SIT0MAQsgbCBxlSI9ID2SID0gPZSTQwAAgL+SIT0LAkACQCBCIHFdDQBDAAAAACFIIEIgggFeRQ0BIEJDAACAv5IgcZUiQiBCIEIgQpSSkkMAAIA/kiFIDAELIEIgcZUiQiBCkiBCIEKUk0MAAIC/kiFICyBxIGySIkJDAACAv5IgQiBCQwAAgD9gGyFsIEFDAACAP0MAAIC/IAcbID2SIEiTkiFBIARBBEYNACB4QwAAAD9DAAAAvyB4QwAAAD9dIgcbkiFCAkACQCB4IHtdDQBDAAAAACE9IHgggwFeRQ0BIHhDAACAv5Ige5UiPSA9ID0gPZSSkkMAAIA/kiE9DAELIHgge5UiPSA9kiA9ID2Uk0MAAIC/kiE9CwJAAkAgQiB7XQ0AQwAAAAAhSCBCIIMBXkUNASBCQwAAgL+SIHuVIkIgQiBCIEKUkpJDAACAP5IhSAwBCyBCIHuVIkIgQpIgQiBClJNDAACAv5IhSAsgeyB4kiJCQwAAgL+SIEIgQkMAAIA/YBsheCBBQwAAgD9DAACAvyAHGyA9kiBIk5IhQSAEQQVGDQAgfkMAAAA/QwAAAL8gfkMAAAA/XSIHG5IhQgJAAkAgfiCBAV0NAEMAAAAAIT0gfiCPAV5FDQEgfkMAAIC/kiCBAZUiPSA9ID0gPZSSkkMAAIA/kiE9DAELIH4ggQGVIj0gPZIgPSA9lJNDAACAv5IhPQsCQAJAIEIggQFdDQBDAAAAACFIIEIgjwFeRQ0BIEJDAACAv5IggQGVIkIgQiBCIEKUkpJDAACAP5IhSAwBCyBCIIEBlSJCIEKSIEIgQpSTQwAAgL+SIUgLIIEBIH6SIkJDAACAv5IgQiBCQwAAgD9gGyF+AkAga0UNACBBQwAAgD9DAACAvyAHGyA9kiBIk5IhQQwBCyACIG04AtwEIAIgSjgC1AQgAiAJNgLIBCACIEQ2AtgEIAIgSTgC0AQgAiA+OALMBCACIDk4ApgEIAIgfjgC1AMgAiB4OALQAyACIGw4AswDIAIgTjgCyAMgAiA7OALEAyACID84AsADIAIgPDgCvAQgAiA3OAKUBCACIDo4ArgEQQZBBkGUicCAABCLgICAAAALIAxBDXQgDHMiDEERdiAMcyIMQQV0IAxzIgyzQwAAgC+UIkIgQpJDAACAv5IhSCBgIEGUIT0CQAJAIDNB/wFHDQAgPSFBDAELIGogN5QgTSA9IDmTIk+UkiFCAkAgY0MAAAAAXkUNACB3QwAAgD9DAACAv0MAAKBAQwAAoMAgYyBClCJBIEFDAACgwF0bIkEgQUMAAKBAXhsiQSBBIEGUIkEgQSBBQwAAvUOSlEMAWodGkpRDwPcDSJKUIEEgQSBBQwAA4EGUQwDgREWSlEMAonNHkpRDwPcDSJKVIkEgQUMAAIC/XRsiQSBBQwAAgD9eG5QhQgtDAAAAACA5IE0gN5SSIGkgT5SSIkEgQZIgOZMiOSA5i0MI5TweXRshOUMAAAAAIEIgQpIgN5MiNyA3i0MI5TweXRshNwJAAkAgMw4DAgABAgsgcCBClCFBDAELID0gcCBClJMgQZMhQQsgXyBIlCBBkiE9AkACQCBFQf8BRw0AID0hQQwBCyBoIDqUIEwgPSA8kyJIlJIhQgJAIGFDAAAAAF5FDQAgdUMAAIA/QwAAgL9DAACgQEMAAKDAIGEgQpQiQSBBQwAAoMBdGyJBIEFDAACgQF4bIkEgQSBBlCJBIEEgQUMAAL1DkpRDAFqHRpKUQ8D3A0iSlCBBIEEgQUMAAOBBlEMA4ERFkpRDAKJzR5KUQ8D3A0iSlSJBIEFDAACAv10bIkEgQUMAAIA/XhuUIUILQwAAAAAgPCBMIDqUkiBnIEiUkiJBIEGSIDyTIjwgPItDCOU8Hl0bITxDAAAAACBCIEKSIDqTIjogOotDCOU8Hl0bIToCQAJAIEUOAwIBAAILID0gbiBClJMgQZMhQQwBCyBuIEKUIUELAkACQAJAAkACQAJAAkACQCAJIEdPDQAgCUEETw0BIBEgMCAJQRRsaiIHKAIATw0CCyAIIEZxQQFxRQ0CIEQhCAwECyACIG04AtwEIAIgSjgC1AQgAiAJNgLIBCACIEQ2AtgEIAIgSTgC0AQgAiA+OALMBCACIDk4ApgEIAIgfjgC1AMgAiB4OALQAyACIGw4AswDIAIgTjgCyAMgAiA7OALEAyACID84AsADIAIgPDgCvAQgAiA3OAKUBCACIDo4ArgEIAlBBEGkisCAABCLgICAAAALIAIgBy0AECIIOgCxBSACQQE6ALAFIAlBAWohCSAHKgIMIW0gByoCCCFCIAcqAgQhSiAIDQEgSiA+kyBClSFJQQAhRgwDCyAIQQFxDQJDAAAAACA+IG2UIj4gPotDCOU8Hl0bIT5BACEIDAMLQwAAgD9DAACAvyBClRDZgICAAJMhSSBCQwAAoECU/AEhCAsgCCAIQQBHayFEID4gSiA+kyBJlJIhPkEBIUYCQCAIQQJJDQBBASEIDAILQQAhCCACQQA6ALAFDAELID4gSZIhPgJAAkAgSUMAAAAAYEUNACA+IEpgDQELQQEhCCBJQwAAAABdRQ0BID4gSl9FDQELQQAhCCACQQA6ALAFIEohPgsgCkEEaiEHIAogCioCACBBID6UkjgCACARQQFqIREgQEF8aiJADQALIAIgbTgC3AQgAiBKOALUBCACIAk2AsgEIAIgRDYC2AQgAiBJOALQBCACID44AswEIAIgOTgCmAQgAiB+OALUAyACIHg4AtADIAIgbDgCzAMgAiBOOALIAyACIDs4AsQDIAIgPzgCwAMgAiA8OAK8BCACIDc4ApQEIAIgOjgCuAQLIGIgAkHAA2pB+AH8CgAACyBDIAw2AoQCAkAgQyoC6AEiN0MAAAAAWw0AIEMoAuwBIQcgQyoCqAIhPyBDKgKkAiFBAkAgbw0AIEMtAKwCIUAgQyoCoAIhSCBDKgKcAiE6IEMqApgCITkgQyoClAIhOCBDKgKQAiE9IEMqAowCITsgeSEJIHYhDCATIREDQCARIQogPSBBlCA4IDdDAAAAACAMIAdJGyI8ID+TIkKUkiE+AkAgOkMAAAAAXkUNACBIQwAAgD9DAACAv0MAAKBAQwAAoMAgOiA+lCI+ID5DAACgwF0bIj4gPkMAAKBAXhsiPiA+ID6UIj4gPiA+QwAAvUOSlEMAWodGkpRDwPcDSJKUID4gPiA+QwAA4EGUQwDgREWSlEMAonNHkpRDwPcDSJKVIj4gPkMAAIC/XRsiPiA+QwAAgD9eG5QhPgsgPyA4IEGUkiA5IEKUkiJCIEKSID+TIj+LQwjlPB5dIQQgPiA+kiBBkyJBi0MI5TweXSEIAkACQAJAIEAOAwIAAQILIDsgPpQhQgwBCyA8IDsgPpSTIEKTIUILIApBBGohEUMAAAAAID8gBBshP0MAAAAAIEEgCBshQSAKIEIgCioCAJI4AgAgDEEBaiEMIAlBfGoiCQ0ACwsgQyA/OAKoAiBDIEE4AqQCIHYggAFqIEMqAogCQ28SAzuU/AEgB2pNDQAgQ0EANgLoAQsCQCBDLQDcAUUNAAJAIEMoAmgiCiCFAU8NACBvDQEgQ0GIAWohRyCQASAKQQxsaiIMKAIIIhFBf2ohCiAMKAIEIQcgQysDGCGkASBDKwMIIVogeSEIIHYhBCATIQwDQAJAAkACQAJAAkACQAJAIBFBBEkNACBaIKQBZg0AQQAgWvwDIglBf2oiQCAKIEAgCkkbIEBBAEgbIkUgEU8NAUEAIAkgCiAJIApJGyAJQQBIGyIzIBFPDQJBACAJQQFqIkAgCiBAIApJGyBAQQBIGyJGIBFPDQNBACAJQQJqIkAgCiBAIApJGyBAQQBIGyJAIBFPDQQgWiAJuKEhWyAHIEVBAnRqKgIAIT4gByAzQQJ0aioCACE/IEMgWiBDKwMQoCJaOQMIID8gW7YiQUMAAAA/lCAHIEZBAnRqKgIAIkIgPpMgPiA+kiA/QwAAoMCUkiBCQwAAgECUkiAHIEBBAnRqKgIAIjiTIDggPyBCk0MAAEBAlJIgPpMgQZSSIEGUkpSSIT4CQCBDLQBkIglB/wFGDQAgQ0MAAAAAIEMqAjgiPyBDKgJcQwAAgD9DAACAv0MAAKBAQwAAoMAgQyoCWCBDKgJUID4gQyoCUJQgQyoCTCBDKgJIIEMqAjQiQSBDKgIoIkIgQyoCQJQgQyoCLCI4IEMqAjyUkiA/IEMqAjAiOpSSkpSUk5SUIj4gPkMAAKDAXRsiPiA+QwAAoEBeGyI+ID4gPpQiPiA+ID5DAAC9Q5KUQwBah0aSlEPA9wNIkpQgPiA+ID5DAADgQZRDAOBERZKUQwCic0eSlEPA9wNIkpUiPiA+QwAAgL9dGyI+ID5DAACAP14blCI3IEKTlCI+IEIgPpIiPJIiPiA+i0MI5TweXRs4AiggQ0MAAAAAID8gPCA4k5QiPiA4ID6SIkKSIj4gPotDCOU8Hl0bOAIsIENDAAAAACA/IEIgOpOUIj4gOiA+kiI4kiI+ID6LQwjlPB5dGzgCMCBDQwAAAAAgPyA4IEGTlCI+IEEgPpIiPpIiPyA/i0MI5TweXRs4AjQCQAJAAkACQCAJDgQDAAECAwsgQiE+DAILIEIgOCA4kpMgPpJDAACAQJQhPgwBCyA3IDxDAACAQJSTIEJDAADAQJSSIDhDAACAQJSTID6SIT4LID4gQyoCYJQhPgsgQygCcCIJIEMoAmxPDQUCQAJAIAlBBE8NACAEIEcgCUEUbGoiQCgCAE8NAQwHCyAJQQRBpIrAgAAQi4CAgAAACyBDQQE6ANgBIEMgQC0AECJFOgDZASBDIEAqAgw4AoQBIEMgQCoCBCJBOAJ8IEMgCUEBajYCcCBAKgIIIT8CQCBFDQAgQyBBIEMqAnSTID+VOAJ4DAYLIEMgP0MAAKBAlPwBNgKAASBDQwAAgD9DAACAvyA/lRDZgICAAJM4AngMBQsgQ0EAOgDcAUMAAAAAIT4MBQsgRSARQaSJwIAAEIuAgIAAAAsgMyARQaSJwIAAEIuAgIAAAAsgRiARQaSJwIAAEIuAgIAAAAsgQCARQaSJwIAAEIuAgIAAAAsCQAJAAkACQCBDLQDYASIJQQFHDQAgQy0A2QFBAXENAQsgCQ0BIENDAAAAACBDKgJ0IEMqAoQBlCI/ID+LQwjlPB5dGyI/OAJ0DAILIEMgQyoCdCI/IEMqAnwgP5MgQyoCeJSSIj84AnQgQyBDKAKAASIJIAlBAEdrNgKAASAJQQJPDQEgQ0EAOgDYAQwBCyBDIEMqAngiQiBDKgJ0kiI/OAJ0IEMqAnwhQQJAAkAgQkMAAAAAYEUNACA/IEFgDQELIEJDAAAAAF1FDQEgPyBBX0UNAQsgQ0EAOgDYASBDIEE4AnQgQSE/CyA+ID+UIT4LIAwgPiAMKgIAkjgCACAEQQFqIQQgDEEEaiEMIAhBfGoiCEUNAgwACwsgCiCFAUG0icCAABCLgICAAAALIEMqAvwBIT4CQCBvDQAgQyoCgAIhQiBDKgIEITggQyoCACE6IEMqAvgBITwgQyoC9AEhNyBDKgLwASFBIIABIREgEyEKA0AgCiByaiIJQYB4aiEMIAlBgHBqIQkgCioCACE/AkAgQUMAAAAAXkUNACA3QwAAgD9DAACAv0MAAKBAQwAAoMAgQSA/lCI/ID9DAACgwF0bIj8gP0MAAKBAXhsiPyA/ID+UIj8gPyA/QwAAvUOSlEMAWodGkpRDwPcDSJKUID8gPyA/QwAA4EGUQwDgREWSlEMAonNHkpRDwPcDSJKVIj8gP0MAAIC/XRsiPyA/QwAAgD9eG5QhPwsgCSAJKgIAIDogPCA+lCA/lCI/lJI4AgAgDCA4ID+UIAwqAgCSOAIAIApBBGohCiBCID6UIT4gEUF/aiIRDQALCyBDID44AvwBIEMgdiCAAWo2AuABAkACQCA+Q6zFJzddDQBBASEKAkAgQy0AyAVBAUcNAEEAIQogQygCtAggQygCsAhJDQAgQy0AnAlBAXENACBDKgK4CItDrMUnN10hCgsCQAJAIEMtAOgDQQFHDQBBACEJIEMoAvwCIEMoAvgCSQ0BIEMtAOQDQQFxDQEgQyoCgAOLQ6zFJzddRQ0BCwJAIEMtAKQFQQFHDQBBACEJIEMoArgEIEMoArQESQ0BIEMtAKAFQQFxDQEgQyoCvASLQ6zFJzddRQ0BC0EBIQkLQQEhDAJAIEMtAKwIRQ0AQQAhDCBDKALAByBDKAK8B0kNACBDLQCoCEEBcQ0AIEMqAsQHi0OsxSc3XSEMCwJAAkAgQy0A3AENACAKIAlxIAxxDQEMAwsgQygCcCBDKAJsSQ0CIEMtANgBQQFxDQIgDCAJIAogQyoCdItDrMUnN11xcXFBAUcNAgsgQyoC6AFDAAAAAFwNAQsgQ0EAOgCgCQtBASE1IH9FDQELQQAhCgwBC0EBIQoMAAsLIDYhMyA2IBJJDQALAkACQCA1QQFxRQ0AIABBADYCsCMMAQsgAEF/IAAoArAjIgogEmoiDCAMIApJGyIKNgKwIyAKQT9JDQACQCASQQJ0IgpFIgwNACAAQeAAakEAIAr8CwALIAwNASAAQeAEakEAIAr8CwAMAQsgAEGACWohDCAAQeAIaiEHIABB4ABqIQkgEkECdCIIIREDQCAVQQRqKgIAIT8gFSoCACE+IAAgACgCgAoiCkF/aiIEQQ8gChsiCjYCgAogCkEfSw0HIAwgCkECdGogPjgCACAAKAKACkEQaiIKQSBPDQogDCAKQQJ0aiA+OAIAIAAoAoQKIgpBB0sNAiAHIApBAnRqIgoqAgAhPiAKID84AgAgACAAKAKECkEBakEHcTYChAogACgCgAoiCkERTw0DIAkgPkMAAAA/lCAMIApBAnRqIgoqAgAgCioCPJJD2fCluJRDAAAAAJIgCioCBCAKKgI4kkMDtFg6lJIgCioCCCAKKgI0kkNXdlK7lJIgCioCDCAKKgIwkkPGRRE8lJIgCioCECAKKgIskkPO56a8lJIgCioCFCAKKgIokkM9Ey89lJIgCioCGCAKKgIkkkNYuLy9lJIgCioCHCAKKgIgkkPvcqA+lJKSOAIAIBVBCGohFSAJQQRqIQkgEUF8aiIRDQALIABBqApqIQwgAEGICmohESAAQeAEaiEJA0AgFEEEaioCACE/IBQqAgAhPiAAIAAoAqgLIgpBf2oiBEEPIAobIgo2AqgLIApBH0sNByAMIApBAnRqID44AgAgACgCqAtBEGoiCkEfSw0KIAwgCkECdGogPjgCACAAKAKsCyIKQQdLDQIgESAKQQJ0aiIKKgIAIT4gCiA/OAIAIAAgACgCrAtBAWpBB3E2AqwLIAAoAqgLIgpBEEsNAyAJID5DAAAAP5QgDCAKQQJ0aiIKKgIAIAoqAjySQ9nwpbiUQwAAAACSIAoqAgQgCioCOJJDA7RYOpSSIAoqAgggCioCNJJDV3ZSu5SSIAoqAgwgCioCMJJDxkURPJSSIAoqAhAgCioCLJJDzuemvJSSIAoqAhQgCioCKJJDPRMvPZSSIAoqAhggCioCJJJDWLi8vZSSIAoqAhwgCioCIJJD73KgPpSSkjgCACAUQQhqIRQgCUEEaiEJIAhBfGoiCA0ACwsCQCAAKAIwIgpFDQAgACgCNCIJQXxqKAIAIgxBeHEiEUEEQQggDEEDcSIMGyAKQSxsIgpqSQ0DAkAgDEUNACARIApBJ2pLDQULIAkQjYCAgAALQQAhDCAAQQA2AjggACAFNgI0IAAgBjYCMCAAQeAEaiEJIABB4ABqIREDQCAAIAxqIgpB4ABqKAIAQQF0QYCAgHhPDQcgCkHkAGooAgBBAXRB////d0sNByAKQegAaigCAEEBdEH///93Sw0HIApB7ABqKAIAQQF0Qf///3dLDQcgDEEQaiIMQYAERw0AC0EAIQwMBAsgCkEIQYSJwIAAEIuAgIAAAAsgCiAKQRBqQSBB9IjAgAAQjICAgAAAC0HgosCAAEEuQZCjwIAAEI6AgIAAAAtBoKPAgABBLkHQo8CAABCOgICAAAALA0AgACAMaiIKQeAEaigCAEEBdEH///93Sw0CIApB5ARqKAIAQQF0Qf///3dLDQIgCkHoBGooAgBBAXRB////d0sNAiAKQewEaigCAEEBdEH///93Sw0CIAxBEGoiDEGABEcNAAwDCwsgBEEgQdSIwIAAEIuAgIAAAAsgABCJgICAACABRQ0AAkAgEkECdCIKRSIMDQAgEUEAIAr8CwALIAwNACAJQQAgCvwLAAsgAkHgCmokgICAgAAPCyAKQSBB5IjAgAAQi4CAgAAAC18CAX8BfiOAgICAAEEgayIDJICAgIAAIAMgATYCDCADIAA2AgggA0GCgICAAK1CIIYiBCADQQhqrYQ3AxggAyAEIANBDGqthDcDEEGogMCAACADQRBqIAIQgoCAgAAAC80CAgF/AX4jgICAgABBIGsiBCSAgICAAAJAAkACQCAAIAJLDQAgASACSw0BQYKAgIAArUIghiEFIAAgAU0NAiAEIAA2AgggBCABNgIMIAQgBSAEQQxqrYQ3AxggBCAFIARBCGqthDcDEEGAgMCAACAEQRBqIAMQgoCAgAAACyAEIAA2AgggBCACNgIMIARBgoCAgACtQiCGIgUgBEEMaq2ENwMYIAQgBSAEQQhqrYQ3AxBB34DAgAAgBEEQaiADEIKAgIAAAAsgBCABNgIIIAQgAjYCDCAEQYKAgIAArUIghiIFIARBDGqthDcDGCAEIAUgBEEIaq2ENwMQQZiBwIAAIARBEGogAxCCgICAAAALIAQgATYCCCAEIAI2AgwgBCAFIARBDGqthDcDGCAEIAUgBEEIaq2ENwMQQZiBwIAAIARBEGogAxCCgICAAAAL3QkBBX8gAEF4aiIBIABBfGooAgAiAkF4cSIAaiEDAkACQAJAIAJBAXENACACQQJxRQ0BIAEoAgAiAiAAaiEAAkAgASACayIBQQAoAoCswIAARw0AIAMoAgRBA3FBA0cNAUEAIAA2AvirwIAAIAMgAygCBEF+cTYCBCABIABBAXI2AgQgAyAANgIADwsgASACEKWAgIAACwJAAkACQAJAAkACQAJAAkACQCADKAIEIgJBAnENACADQQAoAoSswIAARg0CIANBACgCgKzAgABGDQUgAyACQXhxIgIQpYCAgAAgASACIABqIgBBAXI2AgQgASAAaiAANgIAIAFBACgCgKzAgABHDQFBACAANgL4q8CAAA8LIAMgAkF+cTYCBCABIABBAXI2AgQgASAAaiAANgIACyAAQYACSQ0CQR8hAyAAQYCAgAhJDQEMBgtBACABNgKErMCAAEEAQQAoAvyrwIAAIABqIgA2AvyrwIAAIAEgAEEBcjYCBAJAIAFBACgCgKzAgABHDQBBAEEANgL4q8CAAEEAQQA2AoCswIAACyAAQQAoApCswIAAIgJNDQZBUEEAKAKcrMCAACIBa0F3cUEDRg0GQQAoAoSswIAAIgBFDQZBACgC/KvAgAAiBEEpSQ0EIAFFDQNB2KnAgAAhAQNAAkAgASgCACIDIABLDQAgACADIAEoAgRqSQ0GCyABKAIIIQEMAAsLIABBJiAAQQh2ZyIDa3ZBAXEgA0EBdHJBPnMhAwwECwJAAkBBACgC8KvAgAAiA0EBIABBA3Z0IgJxDQBBACADIAJyNgLwq8CAACAAQfgBcUHoqcCAAGoiACEDDAELIABB+AFxIgBB6KnAgABqIQMgAEHwqcCAAGooAgAhAAsgAyABNgIIIAAgATYCDCABIAM2AgwgASAANgIIDwtBACABNgKArMCAAEEAQQAoAvirwIAAIABqIgA2AvirwIAAIAEgAEEBcjYCBCABIABqIAA2AgAPC0Hgo8CAABC1gICAAAALQQAhAQJAQQAoAuCpwIAAIgBFDQBBACEBA0AgAUEBaiEBIAAoAggiAA0ACwtBAEEAKAKgrMCAACIAIAEgACABSxtBfyAAGzYCmKzAgAAgBCACTQ0BQQBBfzYCkKzAgAAPCyABQgA3AhAgASADNgIcIANBAnRB2KjAgABqIQICQAJAQQAoAvSrwIAAQQEgA3QiBHENACACIAE2AgAgASACNgIYIAEgATYCDCABIAE2AghBAEEAKAL0q8CAACAEcjYC9KvAgAAMAQsCQAJAAkAgAigCACIEKAIEQXhxIABHDQAgBCEDDAELIABBAEEZIANBAXZrIANBH0YbdCECA0AgBCACQR12QQRxaiIFKAIQIgNFDQIgAkEBdCECIAMhBCADKAIEQXhxIABHDQALCyADKAIIIgAgATYCDCADIAE2AgggAUEANgIYIAEgAzYCDCABIAA2AggMAQsgBUEQaiABNgIAIAEgBDYCGCABIAE2AgwgASABNgIIC0EAIQFBAEEAKAKYrMCAAEF/aiIANgKYrMCAACAARQ0BCw8LAkBBACgC4KnAgAAiAEUNAEEAIQEDQCABQQFqIQEgACgCCCIADQALC0EAQQAoAqCswIAAIgAgASAAIAFLG0F/IAAbNgKYrMCAAAsVACAAIAFBAXRBAXIgAhCCgICAAAALOgEBfwJAIABFDQAgASAAKAIgIgNPDQAgAiADTw0AIAAoAhwgAUECdGoiACAAKAIAQQEgAnRyNgIACwurBwEHfwJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQCAARQ0AAkAgACgCACIBRQ0AIAAoAgQiAkF8aigCACIDQXhxIgRBBEEIIANBA3EiAxsgAUHQEmwiAXJJDQICQCADRQ0AIAQgAUEnaksNBAsgAhCNgICAAAsCQCAAKAIMIgFFDQAgACgCECICQXxqKAIAIgNBeHEiBEEEQQggA0EDcSIDGyABQQJ0IgFqSQ0EAkAgA0UNACAEIAFBJ2pLDQYLIAIQjYCAgAALAkAgACgCGCIBRQ0AIAAoAhwiAkF8aigCACIDQXhxIgRBBEEIIANBA3EiAxsgAUECdCIBakkNBgJAIANFDQAgBCABQSdqSw0ICyACEI2AgIAACyAAKAIoIQUCQCAAKAIsIgNFDQAgBSEBA0ACQCABKAIAIgJFDQAgAUEEaigCACIGQXxqKAIAIgRBeHEiB0EEQQggBEEDcSIEGyACQQJ0IgJqSQ0KAkAgBEUNACAHIAJBJ2pLDQwLIAYQjYCAgAALIAFBDGohASADQX9qIgMNAAsLAkAgACgCJCIBRQ0AIAVBfGooAgAiA0F4cSICQQRBCCADQQNxIgMbIAFBDGwiAWpJDQoCQCADRQ0AIAIgAUEnaksNDAsgBRCNgICAAAsCQCAAKAIwIgFFDQAgACgCNCICQXxqKAIAIgNBeHEiBEEEQQggA0EDcSIDGyABQSxsIgFqSQ0MAkAgA0UNACAEIAFBJ2pLDQ4LIAIQjYCAgAALIABBfGooAgAiAUF4cSIDQcAjQcQjIAFBA3EiARtJDQ0CQCABRQ0AIANB5CNPDQ8LIAAQjYCAgAALDwtB4KLAgABBLkGQo8CAABCOgICAAAALQaCjwIAAQS5B0KPAgAAQjoCAgAAAC0HgosCAAEEuQZCjwIAAEI6AgIAAAAtBoKPAgABBLkHQo8CAABCOgICAAAALQeCiwIAAQS5BkKPAgAAQjoCAgAAAC0Ggo8CAAEEuQdCjwIAAEI6AgIAAAAtB4KLAgABBLkGQo8CAABCOgICAAAALQaCjwIAAQS5B0KPAgAAQjoCAgAAAC0HgosCAAEEuQZCjwIAAEI6AgIAAAAtBoKPAgABBLkHQo8CAABCOgICAAAALQeCiwIAAQS5BkKPAgAAQjoCAgAAAC0Ggo8CAAEEuQdCjwIAAEI6AgIAAAAtB4KLAgABBLkGQo8CAABCOgICAAAALQaCjwIAAQS5B0KPAgAAQjoCAgAAAC8ECAQV/QQAhAwJAAkACQAJAAkAgAEUNACAALQC4I0EDSQ0AIAEgACgCLE8NACACQf////8DSw0BIAJBAnQiBEH9////B08NAQJAAkAgBA0AQQQhA0EAIQQMAQsgBBCIgICAACIDRQ0DAkAgA0F8ai0AAEEDcUUNACAERQ0AIANBACAE/AsACyACIQQLAkAgACgCKCABQQxsaiIAKAIAIgFFDQAgACgCBCIFQXxqKAIAIgZBeHEiB0EEQQggBkEDcSIGGyABQQJ0IgFqSQ0EAkAgBkUNACAHIAFBJ2pLDQYLIAUQjYCAgAALIAAgAjYCCCAAIAM2AgQgACAENgIACyADDwsQkoCAgAAAC0EEIAQQhoCAgAAAC0HgosCAAEEuQZCjwIAAEI6AgIAAAAtBoKPAgABBLkHQo8CAABCOgICAAAALFwBBqYvAgABBI0G8i8CAABCCgICAAAALnDICCn8EfiOAgICAAEGgIGsiAiSAgICAAEEAIQMCQAJAAkACQAJAAkACQCABQQRLDQAgAkIANwO4CCACQgA3A7AIIAJCADcDqAggAkIANwOgCCACQcAIakEAQYAI/AsAIAJBADsBICACQgA3AxggAkIANwMQIAJCADcDCCACQgA3AwAgAkIANwIkIAJCADcCLCACQgA3AjQgAkIANwI8IAJBADsBRCACQgA3A0ggAkIANwNQIAJCADcDWCACQgA3A2AgAkEAOwFoIAJCADcCbCACQgA3AnQgAkIANwJ8IAJCADcChAEgAkEAOwGMASACQQA6AIAZIAJCADcD+BggAkIANwPwGCACQgA3AoQZIAJCADcCjBkgAkEAOgCUGSACQgA3A5gZIAJCADcDoBkgAkEAOgCoGSACQgA3AqwZIAJCADcCtBkgAkEAOgC8GSACQgA3A7AdIAJCADcDuB0gAkEAOgDAHSACQgA3AsQdIAJCADcCzB0gAkEAOgDUHSACQQA6AOgdIAJCADcD4B0gAkIANwPYHSACQQA6APwdIAJCADcC9B0gAkIANwLsHSACQQA6AKgcIAJCADcDoBwgAkIANwOYHCACQQA6ALwcIAJCADcCtBwgAkIANwKsHCACQQA6ANAcIAJCADcDyBwgAkIANwPAHCACQgA3AtQcIAJCADcC3BwgAkEAOgDkHCACQQA6APAZIAJCADcD6BkgAkIANwPgGSACQQA6AIQaIAJCADcC/BkgAkIANwL0GSACQQA6AJgaIAJCADcDkBogAkIANwOIGiACQQA6AKwaIAJCADcCpBogAkIANwKcGiACQQA6AKAfIAJCADcDmB8gAkIANwOQHyACQQA6ALQfIAJCADcCrB8gAkIANwKkHyACQQA6AMgfIAJCADcDwB8gAkIANwO4HyACQQA6ANwfIAJCADcC1B8gAkIANwLMHyACQYUbakEDaiACQZAB/AoAACACQgA3A/gaIAJCADcD8BogAkIANwPoGiACQgA3A+AaIAJCADcD2BogAkIANwPQGiACQgA3A4ggIAJCADcDkCAgAkIANwOYICACQcgeakEAQcUA/AsAIAJBADsBICACQgA3AxggAkIANwMQIAJCADcDCCACQgA3AwAgAkIANwIkIAJCADcCLCACQgA3AjQgAkIANwI8IAJBADsBRCACQgA3A0ggAkIANwNQIAJCADcDWCACQgA3A2AgAkEAOwFoIAJCADcCbCACQgA3AnQgAkIANwJ8IAJCADcChAEgAkEAOwGMASACQQA6APARIAJCADcD6BEgAkIANwPgESACQgA3AvQRIAJCADcC/BEgAkEAOgCEEiACQgA3A4gSIAJCADcDkBIgAkEAOgCYEiACQgA3ApwSIAJCADcCpBIgAkEAOgCsEiACQgA3A4AWIAJCADcDiBYgAkEAOgCQFiACQgA3ApQWIAJCADcCnBYgAkEAOgCkFiACQQA6ALgWIAJCADcDsBYgAkIANwOoFiACQQA6AMwWIAJCADcCxBYgAkIANwK8FiACQQA6APgUIAJCADcD8BQgAkIANwPoFCACQQA6AIwVIAJCADcChBUgAkIANwL8FCACQQA6AKAVIAJCADcDmBUgAkIANwOQFSACQgA3AqQVIAJCADcCrBUgAkEAOgC0FSACQQA6AMASIAJCADcDuBIgAkIANwOwEiACQQA6ANQSIAJCADcCzBIgAkIANwLEEiACQQA6AOgSIAJCADcD4BIgAkIANwPYEiACQQA6APwSIAJCADcC9BIgAkIANwLsEiACQQA6APAXIAJCADcD6BcgAkIANwPgFyACQQA6AIQYIAJCADcC/BcgAkIANwL0FyACQQA6AJgYIAJCADcDkBggAkIANwOIGCACQQA6AKwYIAJCADcCpBggAkIANwKcGCACQdUTakEDaiACQZAB/AoAACACQgA3A8gTIAJCADcDwBMgAkIANwO4EyACQgA3A7ATIAJCADcDqBMgAkIANwOgEyACQgA3A9gYIAJCADcD4BggAkIANwPoGCACQZgXakEAQcUA/AsAIAJCADcA6B8gAkIANwDwHyACQgA3APgfIAJCADcAgCAgAkIANwCnHiACQgA3AK8eIAJCADcAtx4gAkIANwC/HiACQQA6AMceIAJCADcAiB4gAkIANwCQHiACQgA3AJgeIAJBADYAoB4gAkIANwCPHSACQgA3AJcdIAJCADcAnx0gAkIANwCnHSACQQA6AK8dIAJBADYAiB0gAkIANwCAHSACQgA3APgcIAJCADcA8BwgAkIANwC0GiACQgA3ALwaIAJCADcAxBogAkEANgDMGiACQgA3AMQZIAJCADcAzBkgAkIANwDUGSACQQA2ANwZIAJCADcAuBggAkIANwDAGCACQgA3AMgYIAJCADcA0BggAkEAOgCXFyACQgA3AI8XIAJCADcAhxcgAkIANwD/FiACQgA3APcWIAJBADYA8BYgAkIANwDoFiACQgA3AOAWIAJCADcA2BYgAkEAOgD/FSACQgA3APcVIAJCADcA7xUgAkIANwDnFSACQgA3AN8VIAJBADYA2BUgAkIANwDQFSACQgA3AMgVIAJCADcAwBUgAkEANgCcEyACQgA3AJQTIAJCADcAjBMgAkIANwCEEyACQQA2ABsgAkIANwATIAJCADcACyACQgA3AAMgAS0ApIvAgAAiBC0A2KTAgAAiBUHQEmwiAxCIgICAACIGRQ0BIAVBf2ohB0EAIQEDQCAGIAFqIgNCADcDACADQQhqIAIpA4ggNwMAIANBEGogAikDkCA3AwAgA0EYaiACKQOYIDcDACADQeQAakH/AToAACADQeUAaiACKQDlHzcAACADQe0AaiACKQDtHzcAACADQfUAaiACKQD1HzcAACADQf0AaiACKQD9HzcAACADQYQBaiACKACEIDYAACADQYgBaiACQZAfakHQAPwKAAAgA0HgAWpCADcDACADQdwBakEAOgAAIANB2AFqQQA7AQAgA0HoAWogAkHIHmpBxQD8CgAAIANB0AJqQf8BOgAAIANB0QJqIAIpAKQeNwAAIANB2QJqIAIpAKweNwAAIANB4QJqIAIpALQeNwAAIANB6QJqIAIpALweNwAAIANB8QJqIAIoAMQeNgAAIANB9QJqIAIpAIUeNwAAIANB/QJqIAIpAI0eNwAAIANBhQNqIAIpAJUeNwAAIANBjANqIAIpAJweNwAAIANBlANqIAJBsB1qQdAA/AoAACADQYwEakH/AToAACADQegDakEAOgAAIANB5ANqQQA7AQAgA0GNBGogAikAjB03AAAgA0GVBGogAikAlB03AAAgA0GdBGogAikAnB03AAAgA0GlBGogAikApB03AAAgA0GtBGogAigArB02AAAgA0GxBGogAikA7Rw3AAAgA0G5BGogAikA9Rw3AAAgA0HBBGogAikA/Rw3AAAgA0HIBGogAikAhB03AAAgA0HQBGogAkGYHGpB0AD8CgAAIANBpAVqQQA6AAAgA0GgBWpBADsBACADQaUFaiACQYUbakGTAfwKAAAgA0G4B2pB/wE6AAAgA0GUB2pB/wE6AAAgA0HsBmpCADcCACADQegGakEANgIAIANB4AZqIAIpA/gaNwMAIANB2AZqIAIpA/AaNwMAIANB0AZqIAIpA+gaNwMAIANByAZqIAIpA+AaNwMAIANBwAZqIAIpA9gaNwMAIANBuAZqIAIpA9AaNwMAIANBuQdqIAIpALEaNwAAIANBwQdqIAIpALkaNwAAIANByQdqIAIpAMEaNwAAIANB0AdqIAIpAMgaNwAAIANB2AdqIAJB4BlqQdAA/AoAACADQawIakEAOgAAIANBqAhqQQA7AQAgA0GtCGogAikAwRk3AAAgA0G1CGogAikAyRk3AAAgA0G9CGogAikA0Rk3AAAgA0HECGogAikA2Bk3AAAgA0HMCGogAkHwGGpB0AD8CgAAIANBqAlqQgA3AwAgA0GgCWpBADoAACADQZwJakEAOwEAIANBjApqQf8BOgAAIANBsAlqIAIpA9gYNwMAIANBuAlqIAIpA+AYNwMAIANBwAlqIAIpA+gYNwMAIANBjQpqIAIpALUYNwAAIANBlQpqIAIpAL0YNwAAIANBnQpqIAIpAMUYNwAAIANBpQpqIAIpAM0YNwAAIANBrApqIAIoANQYNgAAIANBsApqIAJB4BdqQdAA/AoAACADQYgLakIANwMAIANBhAtqQQA6AAAgA0GAC2pBADsBACADQZALaiACQZgXakHFAPwKAAAgA0H4C2pB/wE6AAAgA0H5C2ogAikA9BY3AAAgA0GBDGogAikA/BY3AAAgA0GJDGogAikAhBc3AAAgA0GRDGogAikAjBc3AAAgA0GZDGogAigAlBc2AAAgA0GdDGogAikA1RY3AAAgA0GlDGogAikA3RY3AAAgA0GtDGogAikA5RY3AAAgA0G0DGogAikA7BY3AAAgA0G8DGogAkGAFmpB0AD8CgAAIANBtA1qQf8BOgAAIANBkA1qQQA6AAAgA0GMDWpBADsBACADQbUNaiACKQDcFTcAACADQb0NaiACKQDkFTcAACADQcUNaiACKQDsFTcAACADQc0NaiACKQD0FTcAACADQdUNaiACKAD8FTYAACADQdkNaiACKQC9FTcAACADQeENaiACKQDFFTcAACADQekNaiACKQDNFTcAACADQfANaiACKQDUFTcAACADQfgNaiACQegUakHQAPwKAAAgA0HMDmpBADoAACADQcgOakEAOwEAIANBzQ5qIAJB1RNqQZMB/AoAACADQeAQakH/AToAACADQbwQakH/AToAACADQZQQakIANwIAIANBkBBqQQA2AgAgA0GIEGogAikDyBM3AwAgA0GAEGogAikDwBM3AwAgA0H4D2ogAikDuBM3AwAgA0HwD2ogAikDsBM3AwAgA0HoD2ogAikDqBM3AwAgA0HgD2ogAikDoBM3AwAgA0HhEGogAikAgRM3AAAgA0HpEGogAikAiRM3AAAgA0HxEGogAikAkRM3AAAgA0H4EGogAikAmBM3AAAgA0GAEWogAkGwEmpB0AD8CgAAIANB1BFqQQA6AAAgA0HQEWpBADsBACADQdURaiACKQAANwAAIANB3RFqIAIpAAg3AAAgA0HlEWogAikAEDcAACADQewRaiACKQAXNwAAIANB9BFqIAJB4BFqQdAA/AoAACADQcgSakEAOgAAIANBxBJqQQA7AQAgAUHQEmohASAHQX9qIgcNAAsgBiABaiIBQbBtaiIDQQA2AtQSIAFBADYCACADIAIpA4ggNwPYEiADIAIpA5AgNwPgEiADIAIpA5ggNwPoEiADQf8BOgC0EyADIAIpAOUfNwC1EyADIAIpAO0fNwC9EyADIAIpAPUfNwDFEyADIAIpAP0fNwDNEyADIAIoAIQgNgDUEyADQdgTaiACQZAfakHQAPwKAAAgA0IANwOwFCADQQA6AKwUIANBADsBqBQgA0G4FGogAkHIHmpBxQD8CgAAIANB/wE6AKAVIAMgAikApB43AKEVIAMgAikArB43AKkVIAMgAikAtB43ALEVIAMgAikAvB43ALkVIAMgAigAxB42AMEVIAMgAikAhR43AMUVIAMgAikAjR43AM0VIAMgAikAlR43ANUVIAMgAikAnB43ANwVIANB5BVqIAJBsB1qQdAA/AoAACADQf8BOgDcFiADQQA6ALgWIANBADsBtBYgAyACKQCMHTcA3RYgAyACKQCUHTcA5RYgAyACKQCcHTcA7RYgAyACKQCkHTcA9RYgAyACKACsHTYA/RYgAyACKQDtHDcAgRcgAyACKQD1HDcAiRcgAyACKQD9HDcAkRcgAyACKQCEHTcAmBcgA0GgF2ogAkGYHGpB0AD8CgAAIANBADoA9BcgA0EAOwHwFyADQfUXaiACQYUbakGTAfwKAAAgA0H/AToAiBogA0H/AToA5BkgA0IANwK8GSADQQA2ArgZIAMgAikD+Bo3A7AZIAMgAikD8Bo3A6gZIAMgAikD6Bo3A6AZIAMgAikD4Bo3A5gZIAMgAikD2Bo3A5AZIAMgAikD0Bo3A4gZIAMgAikAsRo3AIkaIAMgAikAuRo3AJEaIAMgAikAwRo3AJkaIAMgAikAyBo3AKAaIANBqBpqIAJB4BlqQdAA/AoAACADQQA6APwaIANBADsB+BogAyACKQDBGTcA/RogAyACKQDJGTcAhRsgAyACKQDRGTcAjRsgAyACKQDYGTcAlBsgA0GcG2ogAkHwGGpB0AD8CgAAIANCADcD+BsgA0EAOgDwGyADQQA7AewbIANB/wE6ANwcIAMgAikD2Bg3A4AcIAMgAikD4Bg3A4gcIAMgAikD6Bg3A5AcIAMgAikAtRg3AN0cIAMgAikAvRg3AOUcIAMgAikAxRg3AO0cIAMgAikAzRg3APUcIAMgAigA1Bg2APwcIANBgB1qIAJB4BdqQdAA/AoAACADQgA3A9gdIANBADoA1B0gA0EAOwHQHSADQeAdaiACQZgXakHFAPwKAAAgA0H/AToAyB4gAyACKQD0FjcAyR4gAyACKQD8FjcA0R4gAyACKQCEFzcA2R4gAyACKQCMFzcA4R4gAyACKACUFzYA6R4gAyACKQDVFjcA7R4gAyACKQDdFjcA9R4gAyACKQDlFjcA/R4gAyACKQDsFjcAhB8gA0GMH2ogAkGAFmpB0AD8CgAAIANB/wE6AIQgIANBADoA4B8gA0EAOwHcHyADIAIpANwVNwCFICADIAIpAOQVNwCNICADIAIpAOwVNwCVICADIAIpAPQVNwCdICADIAIoAPwVNgClICADIAIpAL0VNwCpICADIAIpAMUVNwCxICADIAIpAM0VNwC5ICADIAIpANQVNwDAICADQcggaiACQegUakHQAPwKAAAgA0EAOgCcISADQQA7AZghIANBnSFqIAJB1RNqQZMB/AoAACADQf8BOgCwIyADQf8BOgCMIyADQgA3AuQiIANBADYC4CIgAyACKQPIEzcD2CIgAyACKQPAEzcD0CIgAyACKQO4EzcDyCIgAyACKQOwEzcDwCIgAyACKQOoEzcDuCIgAyACKQOgEzcDsCIgAyACKQCBEzcAsSMgAyACKQCJEzcAuSMgAyACKQCREzcAwSMgAyACKQCYEzcAyCMgA0HQI2ogAkGwEmpB0AD8CgAAIANBADoApCQgA0EAOwGgJCADIAIpAAA3AKUkIAMgAikACDcArSQgAyACKQAQNwC1JCADIAIpABc3ALwkIANBxCRqIAJB4BFqQdAA/AoAACADQQA6AJglIANBADsBlCUgBUECdCIDEIiAgIAAIghFDQICQCAIQXxqLQAAQQNxRQ0AIANFDQAgCEEAIAP8CwALIAMQiICAgAAiCUUNAwJAIAlBfGotAABBA3FFDQAgA0UNACAJQQAgA/wLAAsgBUEMbCIDEIiAgIAAIgpFDQQgBUF/aiILQQNxIQEgCiEDAkACQCAFQX5qQf8BcUEDSQ0AIApBUGohByALQXxxIQsDQCAHIgNB2ABqQgQ3AgAgA0HQAGpCADcCACADQcgAakKAgICAwAA3AgAgA0HAAGpCBDcCACADQThqQgA3AgAgA0EwaiIHQoCAgIDAADcCACALQXxqIgsNAAsgA0HgAGohAyABDQAgB0EkaiEBDAELA0AgA0KAgICAwAA3AgAgA0EIakEANgIAIANBDGohAyABQX9qIgENAAsgA0F0aiEBCyADQQA2AgAgAUIENwIQQYAWEIiAgIAAIgFFDQUgAkHgEGpBAEGAAfwLACACIAIpA7gIIgw3A9gQIAIgAikDsAgiDTcD0BAgAiACKQOoCCIONwPIECACIAIpA6AIIg83A8AQIAIgDzcDgAggAiAONwOICCACIA03A5AIIAIgDDcDmAggAiACQcAIakGACPwKAABBvCMQiICAgAAiA0UNBiADQQA2AjggAyABNgI0IANBwAA2AjAgAyAFNgIsIAMgCjYCKCADIAU2AiQgAyAFNgIgIAMgCTYCHCADIAU2AhggAyAFNgIUIAMgCDYCECADIAU2AgwgAyAFNgIIIAMgBjYCBCADIAU2AgAgAyACKQOACDcCQCADIAIpA4gINwJIIAMgAikDkAg3AlAgAyACKQOYCDcCWCADIABDAIA7RyAAIAC8IgFBAEgbQwCAO0cgAUH/////B3FBgICAfGpBgICA+AdJGyABQX9qQf///wNJGzgCPCADQeAAaiACQYAI/AoAACADQeAIaiACQcAQakGgAfwKAAAgA0IANwKACiADQYgKaiACQcAQakGgAfwKAAAgA0GoC2pBAEGIGPwLACADIAQ6ALgjIAMgBEG5893xeWxBkemXqgJzNgK0IyADQX82ArAjCyACQaAgaiSAgICAACADDwtBCCADEIaAgIAAAAtBBCADEIaAgIAAAAtBBCADEIaAgIAAAAtBBCADEIaAgIAAAAtBBEGAFhCGgICAAAALQQRBvCMQlICAgAAACw0AIAEgABCngICAAAALFgAgACABQQBHQQl0akHgAGpBACAAGwsNACAAQcAAakEAIAAbCxQAAkAgAEUNACAAIAEQioCAgAALCxIAAkAgAEUNACAAEImAgIAACwvsAQECfyOAgICAAEEgayIEJICAgIAAAkAgAEUNACABIAAoAghPDQAgA7xBAXRB////d0sNACAAKAI4IgVBP0sNACAEIAApAlg3AxggBCAAKQJQNwMQIAQgACkCSDcDCCAEIAApAkA3AwAgAkH/ACACQf8ASRshAgJAIAUgACgCMEcNACAAQTBqEISAgIAACyAAIAVBAWo2AjggACgCNCAFQSxsaiIAIAQpAwA3AgAgACAEKQMINwIIIAAgBCkDEDcCECAAIAQpAxg3AhggACADOAIoIAAgAjYCJCAAIAE2AiALIARBIGokgICAgAALDQAgAEGABGpBACAAGwtzAQJ/AkACQAJAIABFDQAgAEF8aigCACIBQXhxQaQPQagPIAFBA3EiAhtJDQECQCACRQ0AIAFByA9PDQMLIAAQjYCAgAALDwtB4KLAgABBLkGQo8CAABCOgICAAAALQaCjwIAAQS5B0KPAgAAQjoCAgAAACwQAIAAL+QQDAn8DfQF+I4CAgIAAQcAPayIBJICAgIAAAkACQCAAQwCAO0cgACAAvCICQQBIG0MAgDtHIAJB/////wdxQYCAgHxqQYCAgPgHSRsgAkF/akH///8DSRsiA0NmZuY+lCIAQwAAoEFgRQ0AIABDAAB6RCAAQwAAekRdG0PbD0lAlCADIAOSIgSVEOOAgIAAIQUgAUIANwLwDiABQgA3AugOIAFBADYCsA0gAUEIakEAQYAM/AsAIAFDAACAP0MAAIC/IANDCtcjPJSVENmAgIAAkyIDOALYDSABQs2Zs/LTmbOmPjcC0A0gASADOALMDSABQgA3AsQNIAEgAzgCwA0gAULVmPSG1IrD7sAANwK4DSABIAA4ArQNIAFB3A1qQQBBhAH8CwAgAUEIakGADGpBAEGoAfwLACABQQA6AKQPIAFBgICA/AM2AqAPIAFCgICA/IOAgMA/NwKYDyABQoCAgICAgIDAPzcCjA8gASAAOALkDiABIAQ4AuAOIAFDAACAPyAFQwAAgD+SlSIAOAKIDyABIAUgAJQiADgC+A4gASAAIACUIgM4AvwOIAEgACADlDgCgA8gASADIAOUIgA4AoQPIAFDAACAPyAAQwAAAACUQwAAgD+SlTgClA8gAUEIahCAgICAAEGgDxCIgICAACICRQ0BIAIgAUEIakGgD/wKAAAgAUHAD2okgICAgAAgAg8LIAFBgICAjQQ2AqgPIAEgADgCrA8gAUGBgICAAK1CIIYiBiABQawPaq2ENwO4DyABIAYgAUGoD2qthDcDsA9Bz4HAgAAgAUGwD2pBxIjAgAAQgoCAgAAAC0EEQaAPEJSAgIAAAAsNACAAQYAIakEAIAAbC/oWBQd/BH0BfgF/D30jgICAgABBsAFrIgIkgICAgAACQCAARQ0AIAFBgAEgAUGAAUkbIQMCQCABRQ0AIABBoAxqIQQgAEGADGohBSAAQdQNaiEGIAMhByAAIQgCQAJAAkACQAJAAkADQCAIQYAEaioCACIJQwAAAAAgCbxBAXRBgICAeEkbIQoCQAJAAkAgACoCsA0iCSAAKgK0DSILXA0AIAogACoCqA1cDQEMAgsCQCAJIAsgCZMgACoCuA2UkiIMIAlcDQAgACALIgk4ArANDAELIAwhCQJAIAsgDJOLQ703hjVdDQAgACAJOAKwDQwBCyAAIAsiCTgCsA0LIAAgCjgCqA0CQCAAKgLcDiILQwAAoEFgRQ0AIABDAACAPyALQwAAoEEgCkOaaxc6lCAJkhDZgICAACIJIAlDAACgQV0bIgkgCSALXhtD2w9JQJQgACoC2A6VEOOAgIAAIglDAACAP5KVIgo4AoAPIAAgCSAKlCIJOALwDiAAIAkgCZQiCjgC9A4gACAKIAqUIgs4AvwOIAAgCSAKlDgC+A4gAEMAAIA/IAsgACoChA+UQwAAgD+SlTgCjA8MAQsgAkGAgICNBDYCqAEgAiALOAKsASACQYGAgIAArUIghiINIAJBrAFqrYQ3AxAgAiANIAJBqAFqrYQ3AwhBz4HAgAAgAkEIakHEiMCAABCCgICAAAALAkAgACoCvA0iCiAAKgLADSILWw0AAkACQCAKIAsgCpMgACoCxA2UkiIJIApcDQAgCyEJDAELIAsgCZOLQ703hjVdRQ0AIAshCQsgACAJOAK8DSAAQwAAgD9DAAAAACAJIAlDAAAAAF0bIgkgCUMAAIA/XhtDAACAQJQiCTgChA8gACAJQwAAAD+UQwAAgD+SQwAAgD8gAC0AnA9BAkkbOAKIDyAAQwAAgD8gCSAAKgL8DpRDAACAP5KVOAKMDwsCQCAAKgLIDSIKIAAqAswNIgtbDQACQAJAIAogCyAKkyAAKgLQDZSSIgkgClwNACALIQkMAQsgCyAJk4tDvTeGNV1FDQAgCyEJCyAAIAk4AsgNIABDAACAP0MAAAAAIAkgCUMAAAAAXRsiCSAJQwAAgD9eG0MAAEBAlBDhgICAACIJOAKQDyAAQwAAgD8gCZU4ApQPIAAgCZGLOAKYDwsgCCoCACEJIAAgACgC1A4iDkF/akEPIA4bIg42AtQOAkAgDkEfSw0AIAYgDkECdGpDAAAAACAJIAmLQwjlPB5dGyIJOAIAIAAoAtQOQRBqIg5BIE8NAiAGIA5BAnRqIAk4AgAgACgC1A4iDkERTw0DQwAAAAAgACoC8A4iCSAAKgKUDyIPQwAAgD9DAACAv0MAAKBAQwAAoMAgACoCkA8iECAAKgKMDyIRIAAqAogPIhIgBiAOQQJ0aiIOKgIAIA4qAjySQ9nwpbiUQwAAAACSIA4qAgQgDioCOJJDA7RYOpSSIA4qAgggDioCNJJDV3ZSu5SSIA4qAgwgDioCMJJDxkURPJSSIA4qAhAgDioCLJJDzuemvJSSIA4qAhQgDioCKJJDPRMvPZSSIA4qAhggDioCJJJDWLi8vZSSIA4qAhwiEyAOKgIgkkPvcqA+lJIiCiAKkpQgACoChA8iFCAAKgKADyIVIAAqAuwOIhYgACoC+A4iFyAAKgLgDiILlCAAKgL0DiIYIAAqAuQOIgyUkiAJIAAqAugOIhmUkpKUlJOUlCIKIApDAACgwF0bIgogCkMAAKBAXhsiCiAKIAqUIgogCiAKQwAAvUOSlEMAWodGkpRDwPcDSJKUIAogCiAKQwAA4EGUQwDgREWSlEMAonNHkpRDwPcDSJKVIgogCkMAAIC/XRsiCiAKQwAAgD9eG5QiGiALk5QiCiALIAqSIhuSIgogCotDCOU8Hl0bIQtDAAAAACAJIBsgDJOUIgogDCAKkiIKkiIMIAyLQwjlPB5dGyEMQwAAAAAgCSAKIBmTlCIcIBkgHJIiHZIiGSAZi0MI5TweXRshGUMAAAAAIAkgHSAWk5QiHCAWIBySIhySIhYgFotDCOU8Hl0bIRYCQAJAAkACQCAALQCcDyIODgQDAAECAwsgCiEcDAILIAogHSAdkpMgHJJDAACAQJQhHAwBCyAaIBtDAACAQJSTIApDAADAQJSSIB1DAACAQJSTIBySIRwLQwAAAAAgCSAPQwAAgD9DAACAv0MAAKBAQwAAoMAgECARIBMgEpQgFCAVIBcgC5QgGCAMlJIgCSAZlJIgFpKUlJOUlCIKIApDAACgwF0bIgogCkMAAKBAXhsiCiAKIAqUIgogCiAKQwAAvUOSlEMAWodGkpRDwPcDSJKUIAogCiAKQwAA4EGUQwDgREWSlEMAonNHkpRDwPcDSJKVIgogCkMAAIC/XRsiCiAKQwAAgD9eG5QiDyALk5QiCiALIAqSIh2SIgogCotDCOU8Hl0bIRtDAAAAACAJIB0gDJOUIgogDCAKkiIKkiILIAuLQwjlPB5dGyEMQwAAAAAgCSAKIBmTlCILIBkgC5IiC5IiGSAZi0MI5TweXRshGUMAAAAAIAkgCyAWk5QiCSAWIAmSIgmSIhYgFotDCOU8Hl0bIRYCQAJAAkACQCAODgQDAgEAAwsgDyAdQwAAgECUkyAKQwAAwECUkiALQwAAgECUkyAJkiEJDAILIAogCyALkpMgCZJDAACAQJQhCQwBCyAKIQkLIAAqApgPIQogACAWOALsDiAAIBk4AugOIAAgDDgC5A4gACAbOALgDiAAIAAoAqANIg5Bf2pBDyAOGyIONgKgDSAOQR9LDQQgBCAOQQJ0aiAKIByUIgs4AgAgACgCoA1BEGoiDkEgTw0FIAQgDkECdGogCzgCACAAKAKkDSIOQQdLDQYgBSAOQQJ0aiIOKgIAIQsgDiAKIAmUOAIAIAAgACgCpA1BAWpBB3E2AqQNIAAoAqANIg5BEU8NByAIQYAIaiALQwAAAD+UIAQgDkECdGoiDioCACAOKgI8kkPZ8KW4lEMAAAAAkiAOKgIEIA4qAjiSQwO0WDqUkiAOKgIIIA4qAjSSQ1d2UruUkiAOKgIMIA4qAjCSQ8ZFETyUkiAOKgIQIA4qAiySQ87npryUkiAOKgIUIA4qAiiSQz0TLz2UkiAOKgIYIA4qAiSSQ1i4vL2UkiAOKgIcIA4qAiCSQ+9yoD6UkpI4AgAgCEEEaiEIIAdBf2oiBw0BDAgLCyAOQSBB1IjAgAAQi4CAgAAACyAOQSBB5IjAgAAQi4CAgAAACyAOIA5BEGpBIEH0iMCAABCMgICAAAALIA5BIEHUiMCAABCLgICAAAALIA5BIEHkiMCAABCLgICAAAALIA5BCEGEicCAABCLgICAAAALIA4gDkEQakEgQfSIwIAAEIyAgIAAAAsCQCAAKALgDkEBdEH///93Sw0AIAAoAuQOQQF0Qf///3dLDQAgACgC6A5BAXRB////d0sNACAAKALsDkEBdEH///93Sw0AIABB1A1qEIOAgIAARQ0AIABBoAxqEIOAgIAARQ0AIAAoAoAMQQF0Qf///3dLDQAgACgChAxBAXRB////d0sNACAAKAKIDEEBdEH///93Sw0AIAAoAowMQQF0Qf///3dLDQAgACgCkAxBAXRB////d0sNACAAKAKUDEEBdEH///93Sw0AIAAoApgMQQF0Qf///3dLDQAgACgCnAxBAXRB////d00NAQsgAEHgDmoiDkIANwIIIA5CADcCACACQShqQQBBgAH8CwAgAEHUDWpBAEGEAfwLACACQgA3AyAgAkIANwMYIAJCADcDECACQgA3AwggAEGADGogAkEIakGgAfwKAAAgAEIANwKgDSABRQ0AIANBAnQiDkUNACAAQYAIakEAIA78CwALIAJBsAFqJICAgIAAC7QBAQF/I4CAgIAAQaABayIBJICAgIAAAkAgAEUNACAAIAAqArQNOAKwDSAAIAAqAsANOAK8DSAAIAAqAswNOALIDSAAEICAgIAAIABCADcC6A4gAEIANwLgDiABQSBqQQBBgAH8CwAgAEHUDWpBAEGEAfwLACABQgA3AxggAUIANwMQIAFCADcDCCABQgA3AwAgAEGADGogAUGgAfwKAAAgAEIANwKgDQsgAUGgAWokgICAgAALxQEDAX8BfQF+I4CAgIAAQSBrIgIkgICAgAACQAJAIABFDQAgAbxBAXRB////d0sNACAAKgKsDSIDQwAAoEFgRQ0BIAAgA0MAAKBBIAEgAUMAAKBBXRsiASABIANeGxDegICAADgCtA0LIAJBIGokgICAgAAPCyACQYCAgI0ENgIIIAIgAzgCDCACQYGAgIAArUIghiIEIAJBDGqthDcDGCACIAQgAkEIaq2ENwMQQc+BwIAAIAJBEGpBxIjAgAAQgoCAgAAACz4AAkAgAEUNACABvEEBdEH///93Sw0AIABDAACAP0MAAAAAIAEgAUMAAAAAXRsiASABQwAAgD9eGzgCzA0LC20CAn8BfQJAIABFDQBBAiECQQAhAwJAAkACQAJAAkAgAUF/ag4DAgEAAwtBAyECCyAAIAI6AJwPQwAAgD8hBAwCC0EBIQMLIAAgAzoAnA8gACoChA9DAAAAP5RDAACAP5IhBAsgACAEOAKIDwsLPgACQCAARQ0AIAG8QQF0Qf///3dLDQAgAEMAAIA/QwAAAAAgASABQwAAAABdGyIBIAFDAACAP14bOALADQsLkgMBBH8gACgCDCECAkACQAJAAkAgAUGAAkkNACAAKAIYIQMCQAJAAkAgAiAARw0AIABBFEEQIAAoAhQiAhtqKAIAIgENAUEAIQIMAgsgACgCCCIBIAI2AgwgAiABNgIIDAELIABBFGogAEEQaiACGyEEA0AgBCEFIAEiAkEUaiACQRBqIAIoAhQiARshBCACQRRBECABG2ooAgAiAQ0ACyAFQQA2AgALIANFDQICQAJAIAAgACgCHEECdEHYqMCAAGoiASgCAEYNACADKAIQIABGDQEgAyACNgIUIAINAwwECyABIAI2AgAgAkUNBAwCCyADIAI2AhAgAg0BDAILAkAgAiAAKAIIIgRGDQAgBCACNgIMIAIgBDYCCA8LQQBBACgC8KvAgABBfiABQQN2d3E2AvCrwIAADwsgAiADNgIYAkAgACgCECIBRQ0AIAIgATYCECABIAI2AhgLIAAoAhQiAUUNACACIAE2AhQgASACNgIYDwsPC0EAQQAoAvSrwIAAQX4gACgCHHdxNgL0q8CAAAvuBgEEfyAAIAFqIQICQAJAAkACQAJAIAAoAgQiA0EBcQ0AIANBAnFFDQEgACgCACIDIAFqIQECQCAAIANrIgBBACgCgKzAgABHDQAgAigCBEEDcUEDRw0BQQAgATYC+KvAgAAgAiACKAIEQX5xNgIEIAAgAUEBcjYCBCACIAE2AgAPCyAAIAMQpYCAgAALAkACQAJAIAIoAgQiA0ECcQ0AIAJBACgChKzAgABGDQIgAkEAKAKArMCAAEYNBCACIANBeHEiAxClgICAACAAIAMgAWoiAUEBcjYCBCAAIAFqIAE2AgAgAEEAKAKArMCAAEcNAUEAIAE2AvirwIAADwsgAiADQX5xNgIEIAAgAUEBcjYCBCAAIAFqIAE2AgALAkAgAUGAAkkNAEEfIQIgAUGAgIAISQ0EDAULAkACQEEAKALwq8CAACICQQEgAUEDdnQiA3ENAEEAIAIgA3I2AvCrwIAAIAFB+AFxQeipwIAAaiIBIQIMAQsgAUH4AXEiAUHoqcCAAGohAiABQfCpwIAAaigCACEBCyACIAA2AgggASAANgIMIAAgAjYCDCAAIAE2AggPC0EAIAA2AoSswIAAQQBBACgC/KvAgAAgAWoiATYC/KvAgAAgACABQQFyNgIEIABBACgCgKzAgABHDQBBAEEANgL4q8CAAEEAQQA2AoCswIAACw8LQQAgADYCgKzAgABBAEEAKAL4q8CAACABaiIBNgL4q8CAACAAIAFBAXI2AgQgACABaiABNgIADwsgAUEmIAFBCHZnIgJrdkEBcSACQQF0ckE+cyECCyAAQgA3AhAgACACNgIcIAJBAnRB2KjAgABqIQMCQEEAKAL0q8CAAEEBIAJ0IgRxDQAgAyAANgIAIAAgAzYCGCAAIAA2AgwgACAANgIIQQBBACgC9KvAgAAgBHI2AvSrwIAADwsCQAJAAkAgAygCACIEKAIEQXhxIAFHDQAgBCECDAELIAFBAEEZIAJBAXZrIAJBH0YbdCEDA0AgBCADQR12QQRxaiIFKAIQIgJFDQIgA0EBdCEDIAIhBCACKAIEQXhxIAFHDQALCyACKAIIIgEgADYCDCACIAA2AgggAEEANgIYIAAgAjYCDCAAIAE2AggPCyAFQRBqIAA2AgAgACAENgIYIAAgADYCDCAAIAA2AggLDQAgASAAENeAgIAAAAueAQIBfwF+I4CAgIAAQTBrIgIkgICAgAAgAkHci8CAADYCBCACIAA2AgAgAkHci8CAADYCDCACIAE2AgggAkECNgIUIAJB5Y3AgAA2AhAgAkGDgICAAK1CIIYiAyACQQhqrYQ3AyggAiADIAKthDcDICACQYSAgIAArUIghiACQRBqrYQ3AxhBgILAgAAgAkEYakGwjMCAABCCgICAAAALHAAgACgCACABIAAoAgQoAgwRgICAgACAgICAAAvBCgEMfyAAKAIEIQIgACgCACEDAkACQCABKAIIIgRBgICAwAFxRQ0AAkACQCAEQYCAgIABcQ0AAkAgAkEQSQ0AIAIgAyADQQNqQXxxIgVrIgZqIgdBA3EhCEEAIQlBACEAAkAgAyAFRg0AQQAhCkEAIQACQCAGQXxLDQBBACEKQQAhAANAIAAgAyAKaiILLAAAQb9/SmogC0EBaiwAAEG/f0pqIAtBAmosAABBv39KaiALQQNqLAAAQb9/SmohACAKQQRqIgoNAAsLIAMgCmohCwNAIAAgCywAAEG/f0pqIQAgC0EBaiELIAZBAWoiBg0ACwsCQCAIRQ0AIAUgB0H8////B3FqIgssAABBv39KIQkgCEEBRg0AIAkgCywAAUG/f0pqIQkgCEECRg0AIAkgCywAAkG/f0pqIQkLIAdBAnYhCCAJIABqIQoDQCAFIQkgCEUNAyAIQcABIAhBwAFJGyIHQQNxIQwCQAJAIAdBAnQiDUHwB3EiAA0AQQAhCwwBCyAJIABqIQZBACELIAkhAANAIABBDGooAgAiBUF/c0EHdiAFQQZ2ckGBgoQIcSAAQQhqKAIAIgVBf3NBB3YgBUEGdnJBgYKECHEgAEEEaigCACIFQX9zQQd2IAVBBnZyQYGChAhxIAAoAgAiBUF/c0EHdiAFQQZ2ckGBgoQIcSALampqaiELIABBEGoiACAGRw0ACwsgCCAHayEIIAkgDWohBSALQQh2Qf+B/AdxIAtB/4H8B3FqQYGABGxBEHYgCmohCiAMRQ0ACyAJIAdB/AFxQQJ0aiILKAIAIgBBf3NBB3YgAEEGdnJBgYKECHEhAAJAIAxBAUYNACALKAIEIgVBf3NBB3YgBUEGdnJBgYKECHEgAGohACAMQQJGDQAgCygCCCILQX9zQQd2IAtBBnZyQYGChAhxIABqIQALIABBCHZB/4EccSAAQf+B/AdxakGBgARsQRB2IApqIQoMAgsCQCACDQBBACEKDAILIAJBA3EhC0EAIQVBACEKAkAgAkEESQ0AIAJBDHEhBkEAIQpBACEFA0AgCiADIAVqIgAsAABBv39KaiAAQQFqLAAAQb9/SmogAEECaiwAAEG/f0pqIABBA2osAABBv39KaiEKIAYgBUEEaiIFRw0ACyALRQ0CCyADIAVqIQADQCAKIAAsAABBv39KaiEKIABBAWohACALQX9qIgsNAAwCCwsCQAJAAkAgAS8BDiIKDQBBACECDAELIAMgAmohBkEAIQIgAyELIAohBQNAIAsiACAGRg0CAkACQCAALAAAIgtBf0wNACAAQQFqIQsMAQsCQCALQWBPDQAgAEECaiELDAELIABBBEEDIAtBb0sbaiELCyALIABrIAJqIQIgBUF/aiIFDQALC0EAIQULIAogBWshCgsgCiABLwEMIgBJDQELIAEoAgAgAyACIAEoAgQoAgwRgYCAgACAgICAAA8LIAAgCmshCUEAIQBBACEIAkACQAJAIARBHXZBA3EOBAIAAQICCyAJIQgMAQsgCUH+/wNxQQF2IQgLIARB////AHEhCiABKAIEIQsgASgCACEFAkACQANAIABB//8DcSAIQf//A3FPDQFBASEGIABBAWohACAFIAogCygCEBGAgICAAICAgIAARQ0ADAILC0EBIQYgBSADIAIgCygCDBGBgICAAICAgIAADQAgCSAIa0H//wNxIQhBACEAA0ACQCAAQf//A3EgCEkNAEEADwtBASEGIABBAWohACAFIAogCygCEBGAgICAAICAgIAARQ0ACwsgBgs4AgF/AX4jgICAgABBEGsiASSAgICAACAAKQIAIQIgASAANgIMIAEgAjcCBCABQQRqEMWAgIAAAAv0BAEIfyOAgICAAEEQayIEJICAgIAAAkACQAJAIANBAXENACACLQAAIgUNAUEAIQUMAgsgACACIANBAXYgASgCDBGBgICAAICAgIAAIQUMAQsgASgCDCEGQQAhBwNAIAJBAWohCAJAAkACQAJAAkAgBcBBf0oNACAFQf8BcSIJQYABRg0BIAlBwAFHDQMgBCABNgIEIAQgADYCACAEQqCAgIAGNwIIIAMgB0EDdGoiBSgCACAEIAUoAgQRgICAgACAgICAAEUNAkEBIQUMBgsCQCAAIAggBUH/AXEiBSAGEYGAgIAAgICAgAANACAIIAVqIQIMBAtBASEFDAULAkAgACACQQNqIgUgAi8AASICIAYRgYCAgACAgICAAA0AIAUgAmohAgwDC0EBIQUMBAsgB0EBaiEHIAghAgwBC0GggICABiEKAkAgBUEBcUUNACACQQVqIQggAigAASEKC0EAIQkCQAJAIAVBAnENAEEAIQsgCCECDAELIAhBAmohAiAILwAAIQsLAkACQCAFQQRxDQAgAiEIDAELIAJBAmohCCACLwAAIQkLAkACQCAFQQhxDQAgCCECDAELIAhBAmohAiAILwAAIQcLAkAgBUEQcUUNACADIAtB//8DcUEDdGovAQQhCwsCQCAFQSBxRQ0AIAMgCUH//wNxQQN0ai8BBCEJCyAEIAk7AQ4gBCALOwEMIAQgCjYCCCAEIAE2AgQgBCAANgIAAkAgAyAHQQN0aiIFKAIAIAQgBSgCBBGAgICAAICAgIAARQ0AQQEhBQwDCyAHQQFqIQcLIAItAAAiBQ0AC0EAIQULIARBEGokgICAgAAgBQv2BAIHfwF+IAAoAggiBUGAgIABcSIGQRV2IARqIQcCQAJAIAVBgICABHENAEEAIQEMAQsCQAJAIAINAEEAIQgMAQsgASwAAEG/f0ohCCACQQFGDQAgCCABLAABQb9/SmohCAsgCCAHaiEHC0ErQX8gBhshCQJAAkAgByAALwEMIgpPDQACQAJAAkAgBUGAgIAIcQ0AIAogB2shCkEAIQZBACELAkACQAJAIAVBHXZBA3EOBAIAAQACCyAKIQsMAQsgCkH+/wNxQQF2IQsLIAVB////AHEhCCAAKAIEIQcgACgCACEAA0AgBkH//wNxIAtB//8DcU8NAkEBIQUgBkEBaiEGIAAgCCAHKAIQEYCAgIAAgICAgABFDQAMBQsLIAAgACkCCCIMp0GAgID/eXFBsICAgAJyNgIIQQEhBSAAKAIAIgggACgCBCILIAkgASACEK6AgIAADQNBACEGIAogB2tB//8DcSEHA0AgBkH//wNxIAdPDQJBASEFIAZBAWohBiAIQTAgCygCEBGAgICAAICAgIAARQ0ADAQLC0EBIQUgACAHIAkgASACEK6AgIAADQIgACADIAQgBygCDBGBgICAAICAgIAADQIgCiALa0H//wNxIQtBACEGA0ACQCAGQf//A3EgC0kNAEEADwtBASEFIAZBAWohBiAAIAggBygCEBGAgICAAICAgIAARQ0ADAMLC0EBIQUgCCADIAQgCygCDBGBgICAAICAgIAADQEgACAMNwIIQQAPC0EBIQUgACgCACIGIAAoAgQiACAJIAEgAhCugICAAA0AIAYgAyAEIAAoAgwRgYCAgACAgICAACEFCyAFC0YAAkAgAkF/Rg0AIAAgAiABKAIQEYCAgIAAgICAgABFDQBBAQ8LAkAgAw0AQQAPCyAAIAMgBCABKAIMEYGAgIAAgICAgAALvQIBB38jgICAgABBEGsiAiSAgICAAEEKIQMgACgCACIEIQUCQCAEQegHSQ0AQQohAyAEIQUDQCACQQZqIANqIgZBfGogBSIAIABBkM4AbiIFQZDOAGxrIgdB//8DcUHkAG4iCEEBdC8A543AgAA7AAAgBkF+aiAHIAhB5ABsa0H//wNxQQF0LwDnjcCAADsAACADQXxqIQMgAEH/rOIESw0ACwsCQAJAIAVBCUsNACAFIQAMAQsgAkEGaiADQX5qIgNqIAUgBUH//wNxQeQAbiIAQeQAbGtB//8DcUEBdC8A543AgAA7AAALAkACQCAERQ0AIABFDQELIAJBBmogA0F/aiIDaiAAQQF0LQDojcCAADoAAAsgAUEBQQAgAkEGaiADakEKIANrEK2AgIAAIQMgAkEQaiSAgICAACADCzQBAX8jgICAgABBEGsiAiSAgICAACACIAE2AgwgAiAANgIIIAJBCGogAkEMahCogICAAAALqwQDAn8DfgJ/I4CAgIAAQSBrIgIkgICAgAAgACgCACEDAkACQAJAIAEoAggiAEGAgIAQcQ0AIABBgICAIHENAUEUIQAgAykDACIEIQUCQCAEQugHVA0AQRQhACAEIQUDQCACQQxqIABqIgNBfGogBSIGIAZCkM4AgCIFQpDOAH59pyIHQf//A3FB5ABuIghBAXQvAOeNwIAAOwAAIANBfmogByAIQeQAbGtB//8DcUEBdC8A543AgAA7AAAgAEF8aiEAIAZC/6ziBFYNAAsLAkAgBUIJWA0AIAJBDGogAEF+aiIAaiAFpyIDIANB//8DcUHkAG4iA0HkAGxrQf//A3FBAXQvAOeNwIAAOwAAIAOtIQULAkACQCAEUA0AIAVQDQELIAJBDGogAEF/aiIAaiAFp0EBdC0A6I3AgAA6AAALIAFBAUEAIAJBDGogAGpBFCAAaxCtgICAACEADAILIAMpAwAhBkERIQADQCACQQxqIABqQX5qIAanQQ9xLQDMi8CAADoAACAAQX9qIQAgBkIEiCIGQgBSDQALIAFB3KHAgABBAiACQQxqIABqQX9qQREgAGsQrYCAgAAhAAwBCyADKQMAIQZBESEAA0AgAkEMaiAAakF+aiAGp0EPcS0A3qHAgAA6AAAgAEF/aiEAIAZCBIgiBkIAUg0ACyABQdyhwIAAQQIgAkEMaiAAakF/akERIABrEK2AgIAAIQALIAJBIGokgICAgAAgAAvGBQIMfwJ+I4CAgIAAQaABayIDJICAgIAAQQAhBCADQQBBoAH8CwACQAJAAkAgACgCoAEiBSACSQ0AIAVBKU8NAiAFQQFqIQYgBUECdCEHIAEgAkECdGohCEEAIQlBACEKAkADQCADIAlBAnRqIQsDQCAJIQQgCyEMIAEgCEYNBCAMQQRqIQsgBEEBaiEJIAEoAgAhDSABQQRqIg4hASANRQ0ACyANrSEPQgAhECAHIQ0gBCEBIAAhCwNAIAFBKE8NAiAMIBAgDDUCAHwgCzUCACAPfnwiED4CACAQQiCIIRAgDEEEaiEMIAFBAWohASALQQRqIQsgDUF8aiINDQALIAUhDAJAAkAgEFANACAEIAVqIgxBKE8NASADIAxBAnRqIBCnNgIAIAYhDAsgCiAMIARqIgwgCiAMSxshCiAOIQEMAQsLIAxBKEH4jMCAABCLgICAAAALIAFBKEH4jMCAABCLgICAAAALIAJBAWohBiACQQJ0IQcgACAFQQJ0aiEOIAAhC0EAIQoCQANAIAMgBEECdGohCQNAIAQhDSAJIQwgCyAORg0DIAxBBGohCSANQQFqIQQgCygCACEIIAtBBGoiBSELIAhFDQALIAitIQ9CACEQIAchCCANIQsgASEJA0AgC0EoTw0CIAwgECAMNQIAfCAJNQIAIA9+fCIQPgIAIBBCIIghECAMQQRqIQwgC0EBaiELIAlBBGohCSAIQXxqIggNAAsgAiEMAkACQCAQUA0AIA0gAmoiDEEoTw0BIAMgDEECdGogEKc2AgAgBiEMCyAKIAwgDWoiDCAKIAxLGyEKIAUhCwwBCwsgDEEoQfiMwIAAEIuAgIAAAAsgC0EoQfiMwIAAEIuAgIAAAAsgACADQaAB/AoAACAAIAo2AqABIANBoAFqJICAgIAAIAAPC0EAIAVBKEH4jMCAABCMgICAAAALwgQBCX8CQAJAAkAgAUGACk8NACABQQV2IQICQAJAAkAgACgCoAEiA0UNACADQX9qIQQgA0ECdCAAakF8aiEFIAMgAmpBAnQgAGpBfGohBiADQSlJIQMDQCADRQ0CIAIgBGoiB0EoTw0DIAYgBSgCADYCACAGQXxqIQYgBUF8aiEFIARBf2oiBEF/Rw0ACwsgAUEfcSEFAkAgAkUNACACQQJ0IgRFDQAgAEEAIAT8CwALIAAoAqABIgcgAmohBAJAIAUNACAAIAQ2AqABIAAPCyAEQX9qIgZBJ0sNAyAEIQggACAGQQJ0aigCAEEgIAVrIgZ2IgNFDQQCQCAEQSdLDQAgACAEQQJ0aiADNgIAIARBAWohCAwFCyAEQShB+IzAgAAQi4CAgAAACyAEQShB+IzAgAAQi4CAgAAACyAHQShB+IzAgAAQi4CAgAAAC0GIjcCAAEEdQfiMwIAAEI6AgIAAAAsgBkEoQfiMwIAAEIuAgIAAAAsCQCACQQFqIgkgBE8NAAJAAkAgB0EBcUUNACAEIQMMAQsgACAEQX9qIgNBAnRqIgEgACAEQQJ0akF4aigCACAGdiABKAIAIAV0cjYCAAsgB0ECRg0AIANBAnQgAGpBdGohBANAIARBCGoiByAEQQRqIgEoAgAiCiAGdiAHKAIAIAV0cjYCACABIAQoAgAgBnYgCiAFdHI2AgAgBEF4aiEEIAkgA0F+aiIDSQ0ACwsgACACQQJ0aiIEIAQoAgAgBXQ2AgAgACAINgKgASAAC1IBAX8jgICAgABBEGsiACSAgICAACAAQRw2AgQgAEHwo8CAADYCACAAQYSAgIAArUIghiAArYQ3AwhBtYLAgAAgAEEIakGMpMCAABCCgICAAAALEwBBsI/AgABBMyAAEIKAgIAAAAuEAwEBfwJAAkAgAkUNACABLQAAQTBNDQEgBUECOwEAAkACQAJAAkACQCADwSIGQQFIDQAgBSABNgIEIAIgA0H//wNxIgNLDQIgBUEAOwEMIAUgAjYCCCAFIAMgAms2AhAgBA0BQQIhAQwECyAFIAI2AiAgBSABNgIcIAVBAjsBGCAFQQA7AQwgBUECNgIIIAVB9YvAgAA2AgQgBUEAIAZrIgM2AhBBAyEBIAQgAk0NAyAEIAJrIgIgA00NAyACIAZqIQQMAgsgBUEBNgIgIAVBr4/AgAA2AhwgBUECOwEYDAELIAVBAjsBGCAFQQE2AhQgBUGvj8CAADYCECAFQQI7AQwgBSADNgIIIAUgAiADayICNgIgIAUgASADajYCHAJAIAQgAksNAEEDIQEMAgsgBCACayEECyAFIAQ2AiggBUEAOwEkQQQhAQsgACABNgIEIAAgBTYCAA8LQcmPwIAAQSFB7I/AgAAQjoCAgAAAC0H8j8CAAEEfQZyQwIAAEI6AgIAAAAudCgIGfwJ+AkACQAJAAkACQAJAIAFBCEkNACABQQdxIgJFDQUgACgCoAEiA0EoSw0BAkAgAw0AIABBADYCoAEMBgsgA0ECdCIEQXxqIgVBAnZBAWoiBkEDcSEHIAJBAnQoAuifwIAAIAJ2rSEIQgAhCSAAIQICQAJAIAVBDEkNACAGQfz///8HcSEFQgAhCSAAIQIDQCACIAI1AgAgCH4gCXwiCT4CACACQQRqIgYgBjUCACAIfiAJQiCIfCIJPgIAIAJBCGoiBiAGNQIAIAh+IAlCIIh8Igk+AgAgAkEMaiIGIAY1AgAgCH4gCUIgiHwiCT4CACAJQiCIIQkgAkEQaiECIAVBfGoiBQ0ACyAHRQ0BCyAHQQJ0IQUDQCACIAI1AgAgCH4gCXwiCT4CACACQQRqIQIgCUIgiCEJIAVBfGoiBQ0ACwsCQCAJUA0AIANBKEYNAyAAIARqIAmnNgIAIANBAWohAwsgACADNgKgAQwFCyAAKAKgASIGQShLDQICQCAGDQAgAEEANgKgASAADwsgAUECdDUC6J/AgAAhCCAGQQJ0IgdBfGoiBUECdkEBaiIBQQNxIQNCACEJIAAhAgJAAkAgBUEMSQ0AIAFB/P///wdxIQVCACEJIAAhAgNAIAIgAjUCACAIfiAJfCIJPgIAIAJBBGoiASABNQIAIAh+IAlCIIh8Igk+AgAgAkEIaiIBIAE1AgAgCH4gCUIgiHwiCT4CACACQQxqIgEgATUCACAIfiAJQiCIfCIJPgIAIAlCIIghCSACQRBqIQIgBUF8aiIFDQALIANFDQELIANBAnQhBQNAIAIgAjUCACAIfiAJfCIJPgIAIAJBBGohAiAJQiCIIQkgBUF8aiIFDQALCwJAIAlQDQAgBkEoRg0EIAAgB2ogCac2AgAgBkEBaiEGCyAAIAY2AqABIAAPC0EAIANBKEH4jMCAABCMgICAAAALQShBKEH4jMCAABCLgICAAAALQQAgBkEoQfiMwIAAEIyAgIAAAAtBKEEoQfiMwIAAEIuAgIAAAAsCQAJAAkAgAUEIcUUNACAAKAKgASIDQShLDQECQAJAIAMNAEEAIQMMAQsgA0ECdCIEQXxqIgVBAnZBAWoiBkEDcSEHQgAhCCAAIQICQAJAIAVBDEkNACAGQfz///8HcSEFQgAhCCAAIQIDQCACIAI1AgBC4esXfiAIfCIIPgIAIAJBBGoiBiAGNQIAQuHrF34gCEIgiHwiCD4CACACQQhqIgYgBjUCAELh6xd+IAhCIIh8Igg+AgAgAkEMaiIGIAY1AgBC4esXfiAIQiCIfCIIPgIAIAhCIIghCCACQRBqIQIgBUF8aiIFDQALIAdFDQELIAdBAnQhBQNAIAIgAjUCAELh6xd+IAh8Igg+AgAgAkEEaiECIAhCIIghCCAFQXxqIgUNAAsLIAhQDQAgA0EoRg0DIAAgBGogCKc2AgAgA0EBaiEDCyAAIAM2AqABCwJAIAFBEHFFDQAgAEGQoMCAAEECELKAgIAAGgsCQCABQSBxRQ0AIABBmKDAgABBAxCygICAABoLAkAgAUHAAHFFDQAgAEGkoMCAAEEFELKAgIAAGgsCQCABQYABcUUNACAAQbigwIAAQQoQsoCAgAAaCwJAIAFBgAJxRQ0AIABB4KDAgABBExCygICAABoLIAAgARCzgICAABogAA8LQQAgA0EoQfiMwIAAEIyAgIAAAAtBKEEoQfiMwIAAEIuAgIAAAAv9AgEEfwJAAkACQAJAAkACQAJAAkAgByAIWA0AIAcgCH0gCFgNBAJAIAcgBn0gBlgNACAHIAZCAYZ9IAhCAYZaDQQLIAYgCFgNByAHIAYgCH0iCH0gCFYNByADIAJLDQUgASADaiEJIAMhCgNAIAoiC0UNAiALQX9qIgogAWoiDC0AAEE5Rg0ACyAMIAwtAABBAWo6AAAgAyALayIKRQ0CIAEgC2pBMCAK/AsADAILIABBADYCAA8LAkACQCADDQBBMSEKDAELIAFBMToAAEEwIQogA0F/aiILRQ0AIAFBAWpBMCAL/AsACyAEQQFqwSIEIAXBTA0AIAMgAk8NACAJIAo6AAAgA0EBaiEDCyADIAJNDQNBACADIAJBrKHAgAAQjICAgAAACyADIAJNDQJBACADIAJBzKHAgAAQjICAgAAACyAAQQA2AgAPC0EAIAMgAkG8ocCAABCMgICAAAALIAAgBDsBCCAAIAM2AgQgACABNgIADwsgAEEANgIAC5gNCgF/Bn4BfwR+AX8FfgJ/AX4EfwJ+I4CAgIAAQdAAayIDJICAgIAAAkACQAJAAkACQAJAAkACQAJAAkACQCABKQMAIgRCAFENACABKQMIIgVCAFENASABKQMQIgZCAFENAiAGIAR8IgcgBlQNAyAEIAVUDQQgB0KAgICAgICAgCBaDQUgAyABLwEYIgE7AUAgAyAEIAV9IgU3AzggAyAFIAd5IgaGIgggBogiCTcDSCAJIAVSDQYgAyABOwFAIAMgBDcDOCADIAQgBoYiCSAGiCIFNwNIIAUgBFINB0GgfyABIAanayIKa8FB0ABsQbCnBWpBzhBtIgFB0ABLDQkgA0EgaiABQQR0IgEpA9CQwIAAIgRCACAHIAaGQgAQ3YCAgAAgA0EQaiAEQgAgCEIAEN2AgIAAIAMgBEIAIAlCABDdgICAAEIBQQAgCiABLwHYkMCAAGprIgqtIgSGIghCf3whCyADKQMQQj+HIQwgAykDAEI/iCENIAMpAwghDiABLwHakMCAACEBIApBP3EhDyADKQMYIRACQCADKQMoIhEgAykDIEI/iCISfCITQgF8IhQgBIinIhVBkM4ASQ0AIBVBwIQ9SQ0JAkAgFUGAwtcvSQ0AQQhBCSAVQYCU69wDSSIKGyEWQYDC1y9BgJTr3AMgChshCgwMC0EGQQcgFUGAreIESSIKGyEWQcCEPUGAreIEIAobIQoMCwsCQCAVQeQASQ0AQQJBAyAVQegHSSIKGyEWQeQAQegHIAobIQoMCwtBCkEBIBVBCUsiFhshCgwKC0HgmsCAAEEcQbybwIAAEI6AgIAAAAtBzJvAgABBHUHsm8CAABCOgICAAAALQfybwIAAQRxBmJzAgAAQjoCAgAAAC0HQncCAAEE2QYiewIAAEI6AgIAAAAtBiJ3AgABBN0HAncCAABCOgICAAAALQaicwIAAQS1B2JzAgAAQjoCAgAAACyADQcgAaiADQThqELCAgIAAAAsgA0HIAGogA0E4ahCwgICAAAALQQRBBSAVQaCNBkkiChshFkGQzgBBoI0GIAobIQoMAQsgAUHRAEGMm8CAABCLgICAAAALIBQgC4MhBCANIA58IRcgD60hBiAWIAFrQQFqIRggDCAQfSAUfEIBfCIJIAuDIQVBACEBAkACQAJAAkACQAJAAkACQAJAA0AgAiABaiIZIBUgCm4iD0EwaiIaOgAAIAFBAWohGyAJIBUgDyAKbGsiFa0gBoYiHCAEfCIHVg0CAkAgFiABRw0AQgEhBwNAIAchCSABIgpBEEYNBSACIApqQQFqIARCCn4iBCAGiKdBMGoiFToAACAJQgp+IQcgCkEBaiEBIAVCCn4iBSAEIAuDIgRYDQALIAUgBH0iHCAIVCEPIAcgFCAXfX4iBiAHfCENIAQgBiAHfSILWg0HIBwgCFoNAgwHCyAKQQpJIQ8gCkEKbiEKIBshASAPRQ0AC0HonMCAABC1gICAAAALIAIgAWohASAFIAh9IRQgCCALfSEMQgAgBH0hBgNAAkAgBCAIfCIHIAtUDQAgCyAGfCAMIAR8Wg0AQQAhDwwGCyABIBVBf2oiFToAACAUIAZ8IhwgCFQhDyAHIAtaDQYgBiAIfSEGIAchBCAcIAhUDQYMAAsLIAkgB30iCCAKrSAGhiIGVCEBIBQgF30iBUIBfCEdIAcgBUJ/fCILWg0BIAggBlQNASATIAx8IBB9IAQgBnwiBCAcfH1CAnwhFCATIBd9IAd9IQwgBCANfCAOfCASfSARfSAcfCEIQgAhBANAAkAgByAGfCIFIAtUDQAgDCAEfCAIWg0AQQAhAQwDCyAZIBpBf2oiGjoAACAUIAR8IhwgBlQhASAFIAtaDQMgCCAGfCEIIAQgBn0hBCAFIQcgHCAGVA0DDAALC0ERQRFB+JzAgAAQi4CAgAAACyAHIQULAkAgHSAFWA0AIAENAAJAIAUgBnwiBCAdVA0AIB0gBX0gBCAdfVQNAQsgAEEANgIADAQLAkACQCAFQgJUDQAgBSAJQnx8WA0BCyAAQQA2AgAMBAsgACAYOwEIIAAgGzYCBAwCCyAEIQcLAkAgDSAHWA0AIA8NAAJAIAcgCHwiBCANVA0AIA0gB30gBCANfVQNAQsgAEEANgIADAILAkACQCAJQhR+IAdWDQAgByAFIAlCWH58WA0BCyAAQQA2AgAMAgsgACAYOwEIIAAgCkECajYCBAsgACACNgIACyADQdAAaiSAgICAAAvYLwMBfwR+Hn8jgICAgABBsAprIgMkgICAgAACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkAgASkDACIEQgBRDQAgASkDCCIFQgBRDQEgASkDECIGQgBRDQIgBiAEfCIHIAZUDQMgBCAFVA0EIAEsABohCCABLgEYIQEgAyAENwMIIANBAUECIARCgICAgBBUGzYCqAEgA0EIakEIakEAQZgB/AsAIAMgBTcDsAEgA0EBQQIgBUKAgICAEFQbNgLQAiADQbABakEIakEAQZgB/AsAIAMgBjcD2AIgA0EBQQIgBkKAgICAEFQbNgL4AyADQdgCakEIakEAQZgB/AsAIANBgARqQQBBnAH8CwAgA0EBNgL8AyADQQE2ApwFIAGsIAdCf3x5fULCmsHoBH5CgKHNoLQCfEIgiKciCcEhCgJAAkAgAUEASA0AIANBCGogARCzgICAABogA0GwAWogARCzgICAABogA0HYAmogARCzgICAABoMAQsgA0H8A2pBACABa8EQs4CAgAAaCwJAAkAgCkF/Sg0AIANBCGpBACAKa0H//wNxIgEQt4CAgAAaIANBsAFqIAEQt4CAgAAaIANB2AJqIAEQt4CAgAAaDAELIANB/ANqIAlB//8BcRC3gICAABoLIANBjAlqIANBCGpBpAH8CgAAIAMoAvgDIgsgAygCrAoiASALIAFLGyIMQShLDQUCQAJAIAwNAEEAIQwMAQtBACENQQAhDgJAAkACQCAMQQFGDQAgDEEBcSEPIAxBPnEhEEEAIQ0gA0GMCWohASADQdgCaiEJQQAhDgNAIAEgCSgCACIRIAEoAgBqIhIgDUEBcWoiEzYCACABQQRqIg0gCUEEaigCACIUIA0oAgBqIg0gEiARSSATIBJJcmoiEjYCACANIBRJIBIgDUlyIQ0gCUEIaiEJIAFBCGohASAQIA5BAmoiDkcNAAsgD0UNAQsgA0GMCWogDkECdCIBaiIJIANB2AJqIAFqKAIAIhIgCSgCAGoiASANaiIJNgIAIAEgEkkNASAJIAFJDQEMAgsgDUUNAQsgDEEoRg0HIANBjAlqIAxBAnRqQQE2AgAgDEEBaiEMCyADIAw2AqwKIAwgAygCnAUiFSAMIBVLGyIBQSlPDQcgAUECdCEBIANBjAlqQXxqIRICQANAAkAgAQ0AQQAhAQwCCyASIAFqIQkgAUF8aiIBIANB/ANqaigCACINIAkoAgAiCUYNAAsgDSAJSyANIAlJayEBCwJAAkAgASAISA0AAkACQAJAAkACQCADKAKoASINQShLDQACQCANDQBBACENDAULIA1BAnQiEUF8aiIBQQJ2QQFqIglBA3EhDiABQQxPDQFCACEEIANBCGohAQwCC0EAIA1BKEH4jMCAABCMgICAAAALIAlB/P///wdxIQlCACEEIANBCGohAQNAIAEgATUCAEIKfiAEfCIEPgIAIAFBBGoiEiASNQIAQgp+IARCIIh8IgQ+AgAgAUEIaiISIBI1AgBCCn4gBEIgiHwiBD4CACABQQxqIhIgEjUCAEIKfiAEQiCIfCIEPgIAIARCIIghBCABQRBqIQEgCUF8aiIJDQALIA5FDQELIA5BAnQhCQNAIAEgATUCAEIKfiAEfCIEPgIAIAFBBGohASAEQiCIIQQgCUF8aiIJDQALCyAEUA0AIA1BKEYNCyADQQhqIBFqIASnNgIAIA1BAWohDQsgAyANNgKoAQJAAkACQAJAAkAgAygC0AIiDkEoSw0AQQAhFkEAIQEgDkUNBCAOQQJ0IhNBfGoiAUECdkEBaiIJQQNxIREgAUEMTw0BQgAhBCADQbABaiEBDAILQQAgDkEoQfiMwIAAEIyAgIAAAAsgCUH8////B3EhCUIAIQQgA0GwAWohAQNAIAEgATUCAEIKfiAEfCIEPgIAIAFBBGoiEiASNQIAQgp+IARCIIh8IgQ+AgAgAUEIaiISIBI1AgBCCn4gBEIgiHwiBD4CACABQQxqIhIgEjUCAEIKfiAEQiCIfCIEPgIAIARCIIghBCABQRBqIQEgCUF8aiIJDQALIBFFDQELIBFBAnQhCQNAIAEgATUCAEIKfiAEfCIEPgIAIAFBBGohASAEQiCIIQQgCUF8aiIJDQALCwJAIARQRQ0AIA4hAQwBCyAOQShGDQwgA0GwAWogE2ogBKc2AgAgDkEBaiEBCyADIAE2AtACAkAgC0UNACALQQJ0IhFBfGoiAUECdkEBaiIJQQNxIQ4CQAJAAkAgAUEMTw0AQgAhBCADQdgCaiEBDAELIAlB/P///wdxIQlCACEEIANB2AJqIQEDQCABIAE1AgBCCn4gBHwiBD4CACABQQRqIhIgEjUCAEIKfiAEQiCIfCIEPgIAIAFBCGoiEiASNQIAQgp+IARCIIh8IgQ+AgAgAUEMaiISIBI1AgBCCn4gBEIgiHwiBD4CACAEQiCIIQQgAUEQaiEBIAlBfGoiCQ0ACyAORQ0BCyAOQQJ0IQkDQCABIAE1AgBCCn4gBHwiBD4CACABQQRqIQEgBEIgiCEEIAlBfGoiCQ0ACwsCQCAEUEUNACADIAsiFjYC+AMMAwsgC0EoRg0NIANB2AJqIBFqIASnNgIAIAtBAWohFgsgAyAWNgL4AwwBCyAKQQFqIQogAygCqAEhDSALIRYLIANBoAVqIANB/ANqQaQB/AoAACADQaAFakEBELOAgIAAIRcgA0HEBmogA0H8A2pBpAH8CgAAIANBxAZqQQIQs4CAgAAhGCADQegHaiADQfwDakGkAfwKAAACQAJAAkAgA0HoB2pBAxCzgICAACIZKAKgASIaIA0gGiANSxsiG0EoSw0AIANB/ANqQXxqIQ8gA0GMCWpBfGohHCADQaAFakF8aiELIANBxAZqQXxqIQwgA0HoB2pBfGohECAXKAKgASEdIBgoAqABIR5BACEfA0AgHyEgIBtBAnQhAQJAAkADQCABRQ0BIBAgAWohCSABQXxqIgEgA0EIamooAgAiEiAJKAIAIglGDQALQQAhISASIAlJDQELAkAgG0UNAEEBIQ1BACEOAkACQCAbQQFGDQAgG0EBcSEiIBtBPnEhI0EAIQ5BASENIANBCGohASADQegHaiEJA0AgASABKAIAIhEgCSgCAEF/c2oiEiANQQFxaiITNgIAIAFBBGoiDSANKAIAIhQgCUEEaigCAEF/c2oiDSASIBFJIBMgEklyaiISNgIAIA0gFEkgEiANSXIhDSAJQQhqIQkgAUEIaiEBICMgDkECaiIORw0ACyAiRQ0BCyADQQhqIA5BAnQiAWoiCSAJKAIAIgkgGSABaigCAEF/c2oiASANaiISNgIAIAEgCUkNASASIAFJDQEMJAsgDUUNIwsgAyAbNgKoAUEIISEgGyENCyAeIA0gHiANSxsiG0EpTw0PIBtBAnQhAQJAAkADQCABRQ0BIAwgAWohCSABQXxqIgEgA0EIamooAgAiEiAJKAIAIglGDQALIBIgCU8NACANIRsMAQsCQCAbRQ0AQQEhDUEAIQ4CQAJAIBtBAUYNACAbQQFxISIgG0E+cSEjQQAhDkEBIQ0gA0EIaiEBIANBxAZqIQkDQCABIAEoAgAiESAJKAIAQX9zaiISIA1BAXFqIhM2AgAgAUEEaiINIA0oAgAiFCAJQQRqKAIAQX9zaiINIBIgEUkgEyASSXJqIhI2AgAgDSAUSSASIA1JciENIAlBCGohCSABQQhqIQEgIyAOQQJqIg5HDQALICJFDQELIANBCGogDkECdCIBaiIJIAkoAgAiCSAYIAFqKAIAQX9zaiIBIA1qIhI2AgAgASAJSQ0BIBIgAUkNAQwjCyANRQ0iCyADIBs2AqgBICFBBHIhIQsgHSAbIB0gG0sbIiJBKU8NECAiQQJ0IQECQAJAA0AgAUUNASALIAFqIQkgAUF8aiIBIANBCGpqKAIAIhIgCSgCACIJRg0ACyASIAlPDQAgGyEiDAELAkAgIkUNAEEBIQ1BACEOAkACQCAiQQFGDQAgIkEBcSEbICJBPnEhI0EAIQ5BASENIANBCGohASADQaAFaiEJA0AgASABKAIAIhEgCSgCAEF/c2oiEiANQQFxaiITNgIAIAFBBGoiDSANKAIAIhQgCUEEaigCAEF/c2oiDSASIBFJIBMgEklyaiISNgIAIA0gFEkgEiANSXIhDSAJQQhqIQkgAUEIaiEBICMgDkECaiIORw0ACyAbRQ0BCyADQQhqIA5BAnQiAWoiCSAJKAIAIgkgFyABaigCAEF/c2oiASANaiISNgIAIAEgCUkNASASIAFJDQEMIgsgDUUNIQsgAyAiNgKoASAhQQJqISELIBUgIiAVICJLGyIbQSlPDREgG0ECdCEBAkACQANAIAFFDQEgAUF8aiIBIANBCGpqKAIAIgkgASADQfwDamooAgAiEkYNAAsgCSASTw0AICIhGwwBCwJAIBtFDQBBASENQQAhDgJAAkAgG0EBRg0AIBtBAXEhIiAbQT5xISNBACEOQQEhDSADQQhqIQEgA0H8A2ohCQNAIAEgASgCACIRIAkoAgBBf3NqIhIgDUEBcWoiEzYCACABQQRqIg0gDSgCACIUIAlBBGooAgBBf3NqIg0gEiARSSATIBJJcmoiEjYCACANIBRJIBIgDUlyIQ0gCUEIaiEJIAFBCGohASAjIA5BAmoiDkcNAAsgIkUNAQsgA0EIaiAOQQJ0IgFqIgkgCSgCACIJIANB/ANqIAFqKAIAQX9zaiIBIA1qIhI2AgAgASAJSQ0BIBIgAUkNAQwhCyANRQ0gCyADIBs2AqgBICFBAWohIQsgIEERRg0WIAIgIGogIUEwajoAACADKALQAiIhIBsgISAbSxsiAUEpTw0SICBBAWohHyABQQJ0IQECQANAAkAgAQ0AQQAhJAwCCyABQXxqIgEgA0EIamooAgAiCSABIANBsAFqaigCACISRg0ACyAJIBJLIAkgEklrISQLIANBjAlqIANBCGpBpAH8CgAAIBYgAygCrAoiASAWIAFLGyIiQShLDRMCQAJAICINAEEAISIMAQtBACENQQAhDgJAAkACQCAiQQFGDQAgIkEBcSElICJBPnEhI0EAIQ0gA0GMCWohASADQdgCaiEJQQAhDgNAIAEgCSgCACIRIAEoAgBqIhIgDUEBcWoiEzYCACABQQRqIg0gCUEEaigCACIUIA0oAgBqIg0gEiARSSATIBJJcmoiEjYCACANIBRJIBIgDUlyIQ0gCUEIaiEJIAFBCGohASAjIA5BAmoiDkcNAAsgJUUNAQsgA0GMCWogDkECdCIBaiIJIANB2AJqIAFqKAIAIhIgCSgCAGoiASANaiIJNgIAIAEgEkkNASAJIAFJDQEMAgsgDUUNAQsgIkEoRg0VIANBjAlqICJBAnRqQQE2AgAgIkEBaiEiCyADICI2AqwKICIgFSAiIBVLGyIBQSlPDRUgAUECdCEBAkADQAJAIAENAEEAIQEMAgsgHCABaiEJIA8gAWohEiABQXxqIQEgEigCACISIAkoAgAiCUYNAAsgEiAJSyASIAlJayEBCyAkIAhIDQIgASAISA0DQQAhDkEAIQ0CQCAbRQ0AIBtBAnQiEUF8aiIBQQJ2QQFqIglBA3EhDQJAAkACQCABQQxPDQBCACEEIANBCGohAQwBCyAJQfz///8HcSEJQgAhBCADQQhqIQEDQCABIAE1AgBCCn4gBHwiBD4CACABQQRqIhIgEjUCAEIKfiAEQiCIfCIEPgIAIAFBCGoiEiASNQIAQgp+IARCIIh8IgQ+AgAgAUEMaiISIBI1AgBCCn4gBEIgiHwiBD4CACAEQiCIIQQgAUEQaiEBIAlBfGoiCQ0ACyANRQ0BCyANQQJ0IQkDQCABIAE1AgBCCn4gBHwiBD4CACABQQRqIQEgBEIgiCEEIAlBfGoiCQ0ACwsCQCAEUEUNACAbIQ0MAQsgG0EoRg0YIANBCGogEWogBKc2AgAgG0EBaiENCyADIA02AqgBAkAgIUUNACAhQQJ0IhFBfGoiAUECdkEBaiIJQQNxIQ4CQAJAAkAgAUEMTw0AQgAhBCADQbABaiEBDAELIAlB/P///wdxIQlCACEEIANBsAFqIQEDQCABIAE1AgBCCn4gBHwiBD4CACABQQRqIhIgEjUCAEIKfiAEQiCIfCIEPgIAIAFBCGoiEiASNQIAQgp+IARCIIh8IgQ+AgAgAUEMaiISIBI1AgBCCn4gBEIgiHwiBD4CACAEQiCIIQQgAUEQaiEBIAlBfGoiCQ0ACyAORQ0BCyAOQQJ0IQkDQCABIAE1AgBCCn4gBHwiBD4CACABQQRqIQEgBEIgiCEEIAlBfGoiCQ0ACwsCQCAEUEUNACAhIQ4MAQsgIUEoRg0ZIANBsAFqIBFqIASnNgIAICFBAWohDgsgAyAONgLQAgJAAkAgFg0AQQAhFgwBCyAWQQJ0IhFBfGoiAUECdkEBaiIJQQNxIQ4CQAJAAkAgAUEMTw0AQgAhBCADQdgCaiEBDAELIAlB/P///wdxIQlCACEEIANB2AJqIQEDQCABIAE1AgBCCn4gBHwiBD4CACABQQRqIhIgEjUCAEIKfiAEQiCIfCIEPgIAIAFBCGoiEiASNQIAQgp+IARCIIh8IgQ+AgAgAUEMaiISIBI1AgBCCn4gBEIgiHwiBD4CACAEQiCIIQQgAUEQaiEBIAlBfGoiCQ0ACyAORQ0BCyAOQQJ0IQkDQCABIAE1AgBCCn4gBHwiBD4CACABQQRqIQEgBEIgiCEEIAlBfGoiCQ0ACwsgBFANACAWQShGDRogA0HYAmogEWogBKc2AgAgFkEBaiEWCyADIBY2AvgDIBogDSAaIA1LGyIbQSlJDQALC0EAIBtBKEH4jMCAABCMgICAAAALIAEgCE4NGSADQQhqQQEQs4CAgAAaIBUgAygCqAEiASAVIAFLGyIBQSlPDRcgAUECdCEBIANBCGpBfGohDSADQfwDakF8aiEOA0AgAUUNASAOIAFqIQkgDSABaiESIAFBfGohASASKAIAIhIgCSgCACIJRg0ACyASIAlJDRkLIAIgH2ohDSAfIQECQANAIAEiCUUNASAJQX9qIgEgAmoiEi0AAEE5Rg0ACyASIBItAABBAWo6AAAgHyAJayIBRQ0ZIAIgCWpBMCAB/AsADBkLIAJBMToAAAJAICBFDQAgAkEBakEwICD8CwALICBBD0sNFyANQTA6AAAgCkEBaiEKICBBAmohHwwZC0HgmsCAAEEcQeiewIAAEI6AgIAAAAtBzJvAgABBHUH4nsCAABCOgICAAAALQfybwIAAQRxBiJ/AgAAQjoCAgAAAC0HQncCAAEE2QdifwIAAEI6AgIAAAAtBiJ3AgABBN0HIn8CAABCOgICAAAALQQAgDEEoQfiMwIAAEIyAgIAAAAtBKEEoQfiMwIAAEIuAgIAAAAtBACABQShB+IzAgAAQjICAgAAAC0EoQShB+IzAgAAQi4CAgAAAC0EoQShB+IzAgAAQi4CAgAAAC0EoQShB+IzAgAAQi4CAgAAAC0EAIBtBKEH4jMCAABCMgICAAAALQQAgIkEoQfiMwIAAEIyAgIAAAAtBACAbQShB+IzAgAAQjICAgAAAC0EAIAFBKEH4jMCAABCMgICAAAALQQAgIkEoQfiMwIAAEIyAgIAAAAtBKEEoQfiMwIAAEIuAgIAAAAtBACABQShB+IzAgAAQjICAgAAAC0ERQRFBmJ/AgAAQi4CAgAAAC0EoQShB+IzAgAAQi4CAgAAAC0EoQShB+IzAgAAQi4CAgAAAC0EoQShB+IzAgAAQi4CAgAAAC0EAIAFBKEH4jMCAABCMgICAAAALIB9BEUGon8CAABCLgICAAAALICBBEE0NAEEAIB9BEUG4n8CAABCMgICAAAALIAAgCjsBCCAAIB82AgQgACACNgIAIANBsApqJICAgIAADwtB24zAgABBGkH4jMCAABCOgICAAAALQduMwIAAQRpB+IzAgAAQjoCAgAAAC0HbjMCAAEEaQfiMwIAAEI6AgIAAAAtB24zAgABBGkH4jMCAABCOgICAAAALmgUDBX8BfgJ/I4CAgIAAQRBrIgIkgICAgAACQAJAIAAvAQwiAw0AIAAoAgAgACgCBCABELyAgIAAIQQMAQsgAiABKAIMIgU2AgwgAiABKAIIIgQ2AgggAiABKAIEIgY2AgQgAiABKAIAIgE2AgACQAJAIAApAggiB6ciCEGAgIAIcUUNACAAKAIAIAEgBiAAKAIEKAIMEYGAgIAAgICAgAANASAAIAhBgICA/3lxQbCAgIACciIINgIIIAJCATcCACAGQf//A3EhAUEAIQZBACADIAFrIgEgASADSxshAwsCQCAFRQ0AA0ACQAJAAkACQAJAIAQvAQAOAwABAgALIARBBGooAgAhAQwDCyAEQQJqLwEAIgENAUEBIQEMAgsgBEEIaigCACEBDAELIAFB9v8XaiABQZz/H2pxIAFBmPg3aiABQfCxH2pxc0ERdkEBaiEBC0F/IAYgAWoiASABIAZJGyEGIARBDGohBCAFQX9qIgUNAAsLAkACQCAGIANB//8DcUkNACAAKAIAIAAoAgQgAhC8gICAACEEDAELIAMgBmshCUEAIQRBACEDAkACQAJAIAhBHXZBA3EOBAIAAQACCyAJIQMMAQsgCUH+/wNxQQF2IQMLIAhB////AHEhASAAKAIEIQYgACgCACEFAkADQCAEQf//A3EgA0H//wNxTw0BIARBAWohBCAFIAEgBigCEBGAgICAAICAgIAARQ0ADAMLCyAFIAYgAhC8gICAAA0BIAkgA2tB//8DcSEIQQAhAwNAAkAgA0H//wNxIAhJDQBBACEEDAILQQEhBCADQQFqIQMgBSABIAYoAhARgICAgACAgICAAEUNAAsLIAAgBzcCCAwBC0EBIQQLIAJBEGokgICAgAAgBAvCBAEHfyOAgICAAEEQayIDJICAgIAAAkACQCACKAIEIgRFDQAgACACKAIAIAQgASgCDBGBgICAAICAgIAARQ0AQQEhAgwBCwJAIAIoAgwiBUUNACACKAIIIgQgBUEMbGohBgNAAkACQAJAAkAgBC8BAA4DAAIBAAsCQAJAIAQoAgQiAkHBAEkNACABQQxqKAIAIQUDQAJAIABBpY3AgABBwAAgBRGBgICAAICAgIAARQ0AQQEhAgwJCyACQUBqIgJBwABLDQAMAgsLIAJFDQMgAUEMaigCACEFCyAAQaWNwIAAIAIgBRGBgICAAICAgIAARQ0CQQEhAgwFCyAAIAQoAgQgBCgCCCABQQxqKAIAEYGAgIAAgICAgABFDQFBASECDAQLIAQvAQIhAiADQQA6AAwgA0EANgIIAkACQCACDQAgAyACQTByOgAIQQEhBQwBCyADQQhqIAJB9v8XaiACQZz/H2pxIAJBmPg3aiACQfCxH2pxc0ERdiIHaiIIIAIgAkEKbiIJQQpsa0EwcjoAACAHQQFqIQUgB0UNACAIQX9qIAlBCnBBMHI6AAAgBUECRg0AIAhBfmogAkHkAG5BCnBBMHI6AAAgBUEDRg0AIAhBfWogAkHoB25BCnBBMHI6AAAgBUEERg0AIAhBfGogAkGQzgBuQTByOgAACyAAIANBCGogBSABQQxqKAIAEYGAgIAAgICAgABFDQBBASECDAMLIARBDGoiBCAGRw0ACwtBACECCyADQRBqJICAgIAAIAIL2AUEBX8CfgJ/AX4jgICAgABBgAFrIgMkgICAgAAgAbwiBEH///8DcSIFQYCAgARyIARBAXRB/v//B3EgBEEXdkH/AXEiBhsiB60iCEIBgyEJQQIhCgJAAkACQAJAAkAgBUVBBEEDQQIgBRsgBEGAgID8B3EiBRsgBUGAgID8B0YbDgUEAAECAwQLQQMhCgwDC0EEIQoMAgsgBkHqfmohCyAJp0EBcyEKQgEhDAwBC0KAgIAQIAhCAYYgB0GAgIAERiIFGyEIQgJCASAFGyEMIAmnQQFzIQpB6H5B6X4gBRsgBmohCwsgAyALOwF4IAMgDDcDcCADQgE3A2ggAyAINwNgIAMgCjoAegJAAkACQAJAAkACQCAKQf8BcUEBSw0AQeyLwIAAQQEgBEEASCIKGyEFQeyLwIAAQe2LwIAAIAobIQogBEEfdiEEIANBIGogA0HgAGogA0EPahC5gICAACADKAIgRQ0BIAMgAygCKDYCWCADIAMpAiA3A1AMAgsgCkF+akH/AXEiC0UNAkEBIQpB7IvAgABB7YvAgAAgBEEASCIFG0Hsi8CAAEEBIAUbIAIbIQVBASAEQR92IAIbIQQgA0ECOwEgIAtBAkYNAyADQQM2AiggA0Hxi8CAADYCJCADQSBqIQsMBAsgA0HQAGogA0HgAGogA0EPahC6gICAAAsgCiAFIAIbIQVBASAEIAIbIQQgAyADKAJQIAMoAlQgAy8BWEEBIANBIGoQtoCAgAAgAygCBCEKIAMoAgAhCwwCCyADQQM2AiggA0Hui8CAADYCJCADQQI7ASBBASEFIANBIGohC0EAIQRBASEKDAELIANBATYCMCADQQA7ASwgA0ECNgIoIANB9YvAgAA2AiQgA0EgaiELQQIhCgsgAyAKNgJcIAMgCzYCWCADIAQ2AlQgAyAFNgJQIAAgA0HQAGoQu4CAgAAhBCADQYABaiSAgICAACAEC5wHBQV/An4CfwF+AX8jgICAgABBoAFrIgMkgICAgAAgAbwiBEH///8DcSIFQYCAgARyIARBAXRB/v//B3EgBEEXdkH/AXEiBhsiB60iCEIBgyEJQQIhCgJAAkACQAJAAkAgBUVBBEEDQQIgBRsgBEGAgID8B3EiBRsgBUGAgID8B0YbDgUEAAECAwQLQQMhCgwDC0EEIQoMAgsgBkHqfmohCyAJp0EBcyEKQgEhDAwBC0KAgIAQIAhCAYYgB0GAgIAERiIFGyEIQgJCASAFGyEMIAmnQQFzIQpB6H5B6X4gBRsgBmohCwsgAyALOwGIASADIAw3A4ABIANCATcDeCADIAg3A3AgAyAKOgCKAQJAAkACQAJAAkACQAJAAkACQCAKQf8BcUEBSw0AIANB4ABqIANB8ABqIANBB2oQuYCAgAAgAygCYEUNASADIAMoAmg2ApgBIAMgAykCYDcDkAEMAgsgCkF+akH/AXEiBkUNAkEBIQpB7IvAgABB7YvAgAAgBEEASCIFG0Hsi8CAAEEBIAUbIAIbIQVBASAEQR92IAIbIQsgA0ECOwEYIAZBAkYNAyADQQM2AiAgA0Hxi8CAADYCHAwHCyADQZABaiADQfAAaiADQQdqELqAgIAACyADKAKUASIFRQ0CIAMoApABIgotAABBME0NA0Hsi8CAAEEBIARBAEgiCxshB0Hsi8CAAEHti8CAACALGyELIARBH3YhDSADLgGYASEGIANBATYCICADIAo2AhwgA0ECOwEYAkAgBUF/aiIFDQAgA0EkaiEEQQMhCgwFCyADQTxqIQQgAyAFNgI4IANBAjsBMCADQa+PwIAANgIoIANBAjsBJCADQQE2AiwgAyAKQQFqNgI0QQUhCgwECyADQQM2AiAgA0Hui8CAADYCHCADQQI7ARhBASEFQQAhC0EBIQoMBAsgA0EDNgIgIANB94vAgAA2AhwMAwtByY/AgABBIUGskMCAABCOgICAAAALQfyPwIAAQR9BvJDAgAAQjoCAgAAACyALIAcgAhshBUEBIA0gAhshCyAEQQE7AQwgBEECOwEAIARBAkEBIAZBAUgiAhs2AgggBEHNkMCAAEHMkMCAACACGzYCBCAEIAZBf2oiAiACQR91IgJzIAJrOwEOCyADIAo2AmwgAyALNgJkIAMgBTYCYCADIANBGGo2AmggACADQeAAahC7gICAACEEIANBoAFqJICAgIAAIAQLgTMHBX8CfgZ/BH4FfwF+En8jgICAgABB8A5rIgQkgICAgAAgAbwiBUH///8DcSIGQYCAgARyIAVBAXRB/v//B3EgBUEXdkH/AXEiBxsiCK0iCUIBgyEKQQIhCyADQf//A3EhDAJAAkACQAJAAkACQAJAAkACQCAGRUEEQQNBAiAGGyAFQYCAgPwHcSIGGyAGQYCAgPwHRhsOBQMCAAQBAwtBBCELDAILQoCAgBAgCUIBhiAIQYCAgARGIgsbIQkgCqdBAXMhBkHofkHpfiALGyAHaiENDAMLQQMhCwsgC0F+aiEGIAVBH3YhCwwCCyAHQep+aiENIAqnQQFzIQYLIAZB/wFxQQFNDQEgBUEfdiELIAZBfmohBgsCQAJAAkAgBkH/AXEiCEUNAEEBIQZB7IvAgABB7YvAgAAgCxtB7IvAgABBASALGyACGyELQQEgBUEfdiACGyEHIAhBAkcNASAEQQI7AcwNIANB//8DcQ0CQQEhBiAEQQE2AtQNIARB9IvAgAA2AtANIARBzA1qIQgMBAsgBEEDNgLUDSAEQe6LwIAANgLQDSAEQQI7AcwNQQEhCyAEQcwNaiEIQQAhB0EBIQYMAwsgBEEDNgLUDSAEQfGLwIAANgLQDSAEQQI7AcwNIARBzA1qIQgMAgsgBCAMNgLcDSAEQQA7AdgNQQIhBiAEQQI2AtQNIARB9YvAgAA2AtANIARBzA1qIQgMAQsCQAJAAkACQAJAAkACQAJAAkACQAJAAkBBdEEFIA1BAEgbIA1sIgZBwP0ATw0AIAlCAFENAUGgfyANIAl5IgqnayIHa0HQAGxBsKcFakHOEG0iC0HQAEsNAiAGQQR2Ig5BFWohD0EAIANrQYCAfiADwUF/ShvBIRAgBEEQaiALQQR0IgYpA9CQwIAAQgAgCSAKhkIAEN2AgIAAQgFBQCAHIAYvAdiQwIAAamsiC60iEYYiEkJ/fCITIAQpAxBCP4ggBCkDGHwiCoMiFFANBSAGLwHakMCAACEIIAtBP3EhFQJAIAogEYinIgdBkM4ASQ0AIAdBwIQ9SQ0EAkAgB0GAwtcvSQ0AQQhBCSAHQYCU69wDSSIGGyEWQYDC1y9BgJTr3AMgBhshBgwGC0EGQQcgB0GAreIESSIGGyEWQcCEPUGAreIEIAYbIQYMBQsCQCAHQeQASQ0AQQJBAyAHQegHSSIGGyEWQeQAQegHIAYbIQYMBQtBCkEBIAdBCUsiFhshBgwEC0H6i8CAAEElQaCMwIAAEI6AgIAAAAtB4JrAgABBHEH8msCAABCOgICAAAALIAtB0QBBjJvAgAAQi4CAgAAAC0EEQQUgB0GgjQZJIgYbIRZBkM4AQaCNBiAGGyEGCyAVrSERIBYgCGtBAWrBIhcgEEwNAyALQf//A3EhGCAXIBBrIgvBIA8gCyAPSRsiGUF/aiEVQQAhCwJAA0AgBEEsaiALaiAHIAZuIghBMGo6AAAgByAIIAZsayEHIBUgC0YNAyAWIAtGDQEgC0EBaiELIAZBCkkhCCAGQQpuIQYgCEUNAAtBnJvAgAAQtYCAgAAACyALQQFqIQZBbCAOayELIBhBf2pBP3GtIRpCASEKA0AgCiAaiEIAUg0BIAsgBmpBAUYNAyAEQSxqIAZqIBRCCn4iFCARiKdBMGo6AAAgCkIKfiEKIBQgE4MhFCAZIAZBAWoiBkcNAAsgBEGsCGogBEEsaiAPIBkgFyAQIBQgEiAKELiAgIAADAQLIARBADYCrAgMBAsgBEGsCGogBEEsaiAPIBkgFyAQIAetIBGGIBR8IAatIBGGIBIQuICAgAAMAgsgBiAPQaybwIAAEIuAgIAAAAsgBEGsCGogBEEsaiAPQQAgFyAQIApCCoAgBq0gEYYgEhC4gICAAAsgBCgCrAgiCEUNACAELwG0CCEYIAQoArAIIRcMAQsgBEEBNgLYCSAEIAk3A7gIIARBwAhqQQBBmAH8CwAgBEHkCWpBAEGcAfwLACAEQQE2AuAJIARBATYCgAsgDawgCUJ/fHl9QsKawegEfkKAoc2gtAJ8QiCIpyIGwSEYAkACQCANQQBIDQAgBEG4CGogDRCzgICAABoMAQsgBEHgCWpBACANa0H//wNxELOAgIAAGgsCQAJAIBhBf0oNACAEQbgIakEAIBhrQf//A3EQt4CAgAAaDAELIARB4AlqIAZB//8BcRC3gICAABoLIARBzA1qIARB4AlqQaQB/AoAACAEQcwNakF4aiEWIA8hCANAAkACQAJAAkAgBCgC7A4iBkEoSw0AIAZFDQMgBkECdCIGQXxqIg0NASAEQcwNaiAGaiEGQgAhCQwCC0EAIAZBKEH4jMCAABCMgICAAAALIBYgBmohCyANQQJ2QQFqQf7///8HcSEHQgAhCQNAIAsiBkEEaiILIAlCIIYgCzUCAIQiCUKAlOvcA4AiCj4CACAGIAkgCkKAlOvcA359QiCGIAY1AgCEIglCgJTr3AOAIgo+AgAgCSAKQoCU69wDfn0hCSAGQXhqIQsgB0F+aiIHDQALIA1BBHENAQsgBkF8aiIGIAlCIIYgBjUCAIRCgJTr3AOAPgIACyAIQXdqIghBCUsNAAsCQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkAgCEECdCgC6J/AgABBAXQiC0UNAAJAAkACQAJAAkAgBCgC7A4iBkEoSw0AAkAgBg0AQQAhBgwFCyALrSEJIAZBAnQiBkF8aiIIDQEgBEHMDWogBmohBkIAIQoMAgtBACAGQShB+IzAgAAQjICAgAAACyAIQQJ2QQFqQf7///8HcSELIAYgBEHMDWpqQXhqIQdCACEKA0AgByIGQQRqIgcgCkIghiAHNQIAhCIKIAmAIhQ+AgAgBiAKIBQgCX59QiCGIAY1AgCEIgogCYAiFD4CACAKIBQgCX59IQogBkF4aiEHIAtBfmoiCw0ACyAIQQRxDQELIAZBfGoiBiAKQiCGIAY1AgCEIAmAPgIACyAEKALsDiEGCyAEKALYCSIOIAYgDiAGSxsiG0EoSw0BAkACQCAbDQBBACEbDAELQQAhCEEAIQ0CQAJAAkAgG0EBRg0AIBtBAXEhHCAbQT5xIRdBACEIIARBzA1qIQYgBEG4CGohC0EAIQ0DQCAGIAsoAgAiFiAGKAIAaiIHIAhBAXFqIhU2AgAgBkEEaiIIIAtBBGooAgAiGSAIKAIAaiIIIAcgFkkgFSAHSXJqIgc2AgAgCCAZSSAHIAhJciEIIAtBCGohCyAGQQhqIQYgFyANQQJqIg1HDQALIBxFDQELIARBzA1qIA1BAnQiBmoiCyAEQbgIaiAGaigCACIHIAsoAgBqIgYgCGoiCzYCACAGIAdJDQEgCyAGSQ0BDAILIAhFDQELIBtBKEYNAyAEQcwNaiAbQQJ0akEBNgIAIBtBAWohGwsgBCAbNgLsDiAEKAKACyIdIBsgHSAbSxsiBkEpTw0DIAZBAnQhBiAEQcwNakF8aiELAkACQANAIAZFDQEgCyAGaigCACIHIAZBfGoiBiAEQeAJamooAgAiCEYNAAsgByAITw0AAkAgDg0AQQAhDiAEQQA2AtgJDAILIA5BAnQiDUF8aiIGQQJ2QQFqIgtBA3EhCAJAAkACQCAGQQxPDQBCACEJIARBuAhqIQYMAQsgC0H8////B3EhC0IAIQkgBEG4CGohBgNAIAYgBjUCAEIKfiAJfCIJPgIAIAZBBGoiByAHNQIAQgp+IAlCIIh8Igk+AgAgBkEIaiIHIAc1AgBCCn4gCUIgiHwiCT4CACAGQQxqIgcgBzUCAEIKfiAJQiCIfCIJPgIAIAlCIIghCSAGQRBqIQYgC0F8aiILDQALIAhFDQELIAhBAnQhCwNAIAYgBjUCAEIKfiAJfCIJPgIAIAZBBGohBiAJQiCIIQkgC0F8aiILDQALCwJAIAlQDQAgDkEoRg0HIARBuAhqIA1qIAmnNgIAIA5BAWohDgsgBCAONgLYCQwBCyAYQQFqIRgLQQAhHkEBIRYCQAJAIBjBIgYgEEgiHw0AIBggEGvBIA8gBiAQayAPSRsiFw0BC0EAIRcMEQsgBEGEC2ogBEHgCWpBpAH8CgAAIARBhAtqQQEQs4CAgAAhICAEQagMaiAEQeAJakGkAfwKAAAgBEGoDGpBAhCzgICAACEhIARBzA1qIARB4AlqQaQB/AoAACAEQeAJakF8aiEiIARBhAtqQXxqISMgBEGoDGpBfGohHCAEQcwNakF8aiEbIARBzA1qQQMQs4CAgAAhJCAgKAKgASElICEoAqABISYgJCgCoAEhJ0EAISgCQAJAA0AgKCEpIA5BKU8NCCApQQFqISggDkECdCEHQQAhBgNAIAcgBkYNAyAEQbgIaiAGaiELIAZBBGohBiALKAIARQ0ACyAnIA4gJyAOSxsiKkEpTw0JICpBAnQhBgJAAkADQCAGRQ0BIBsgBmohCyAGQXxqIgYgBEG4CGpqKAIAIgcgCygCACILRg0AC0EAISsgByALSQ0BC0EBIQhBACENAkACQAJAICpBAUYNACAqQQFxISwgKkE+cSEOQQAhDUEBIQggBEG4CGohBiAEQcwNaiELA0AgBiAGKAIAIhYgCygCAEF/c2oiByAIQQFxaiIVNgIAIAZBBGoiCCAIKAIAIhkgC0EEaigCAEF/c2oiCCAHIBZJIBUgB0lyaiIHNgIAIAggGUkgByAISXIhCCALQQhqIQsgBkEIaiEGIA4gDUECaiINRw0ACyAsRQ0BCyAEQbgIaiANQQJ0IgZqIgsgCygCACILICQgBmooAgBBf3NqIgYgCGoiBzYCACAGIAtJDQEgByAGSQ0BDBULIAhFDRQLIAQgKjYC2AlBCCErICohDgsgJiAOICYgDksbIipBKU8NCiAqQQJ0IQYCQAJAA0AgBkUNASAcIAZqIQsgBkF8aiIGIARBuAhqaigCACIHIAsoAgAiC0YNAAsgByALTw0AIA4hKgwBCwJAICpFDQBBASEIQQAhDQJAAkAgKkEBRg0AICpBAXEhLCAqQT5xIQ5BACENQQEhCCAEQbgIaiEGIARBqAxqIQsDQCAGIAYoAgAiFiALKAIAQX9zaiIHIAhBAXFqIhU2AgAgBkEEaiIIIAgoAgAiGSALQQRqKAIAQX9zaiIIIAcgFkkgFSAHSXJqIgc2AgAgCCAZSSAHIAhJciEIIAtBCGohCyAGQQhqIQYgDiANQQJqIg1HDQALICxFDQELIARBuAhqIA1BAnQiBmoiCyALKAIAIgsgISAGaigCAEF/c2oiBiAIaiIHNgIAIAYgC0kNASAHIAZJDQEMFAsgCEUNEwsgBCAqNgLYCSArQQRyISsLICUgKiAlICpLGyIsQSlPDQsgLEECdCEGAkACQANAIAZFDQEgIyAGaiELIAZBfGoiBiAEQbgIamooAgAiByALKAIAIgtGDQALIAcgC08NACAqISwMAQsCQCAsRQ0AQQEhCEEAIQ0CQAJAICxBAUYNACAsQQFxISogLEE+cSEOQQAhDUEBIQggBEG4CGohBiAEQYQLaiELA0AgBiAGKAIAIhYgCygCAEF/c2oiByAIQQFxaiIVNgIAIAZBBGoiCCAIKAIAIhkgC0EEaigCAEF/c2oiCCAHIBZJIBUgB0lyaiIHNgIAIAggGUkgByAISXIhCCALQQhqIQsgBkEIaiEGIA4gDUECaiINRw0ACyAqRQ0BCyAEQbgIaiANQQJ0IgZqIgsgCygCACILICAgBmooAgBBf3NqIgYgCGoiBzYCACAGIAtJDQEgByAGSQ0BDBMLIAhFDRILIAQgLDYC2AkgK0ECaiErCyAdICwgHSAsSxsiDkEpTw0MIA5BAnQhBgJAAkADQCAGRQ0BICIgBmohCyAGQXxqIgYgBEG4CGpqKAIAIgcgCygCACILRg0ACyAHIAtPDQAgLCEODAELAkAgDkUNAEEBIQhBACENAkACQCAOQQFGDQAgDkEBcSEsIA5BPnEhKkEAIQ1BASEIIARBuAhqIQYgBEHgCWohCwNAIAYgBigCACIWIAsoAgBBf3NqIgcgCEEBcWoiFTYCACAGQQRqIgggCCgCACIZIAtBBGooAgBBf3NqIgggByAWSSAVIAdJcmoiBzYCACAIIBlJIAcgCElyIQggC0EIaiELIAZBCGohBiAqIA1BAmoiDUcNAAsgLEUNAQsgBEG4CGogDUECdCIGaiILIAsoAgAiCyAEQeAJaiAGaigCAEF/c2oiBiAIaiIHNgIAIAYgC0kNASAHIAZJDQEMEgsgCEUNEQsgBCAONgLYCSArQQFqISsLICkgD0YNASAEQSxqIClqICtBMGo6AAACQAJAIA4NAEEAIQ4MAQsgDkECdCINQXxqIgZBAnZBAWoiC0EDcSEIAkACQAJAIAZBDE8NAEIAIQkgBEG4CGohBgwBCyALQfz///8HcSELQgAhCSAEQbgIaiEGA0AgBiAGNQIAQgp+IAl8Igk+AgAgBkEEaiIHIAc1AgBCCn4gCUIgiHwiCT4CACAGQQhqIgcgBzUCAEIKfiAJQiCIfCIJPgIAIAZBDGoiByAHNQIAQgp+IAlCIIh8Igk+AgAgCUIgiCEJIAZBEGohBiALQXxqIgsNAAsgCEUNAQsgCEECdCELA0AgBiAGNQIAQgp+IAl8Igk+AgAgBkEEaiEGIAlCIIghCSALQXxqIgsNAAsLIAlQDQAgDkEoRg0OIARBuAhqIA1qIAmnNgIAIA5BAWohDgsgBCAONgLYCSAoIBdHDQALQQAhFgwSCyAPIA9ByJ7AgAAQi4CAgAAACyAXIA9LDQsgFyApRg0RIBcgKWsiBkUNESAEQSxqIClqQTAgBvwLAAwRC0HAjMCAAEEbQfiMwIAAEI6AgIAAAAtBACAbQShB+IzAgAAQjICAgAAAC0EoQShB+IzAgAAQi4CAgAAAC0EAIAZBKEH4jMCAABCMgICAAAALQShBKEH4jMCAABCLgICAAAALQQAgDkEoQfiMwIAAEIyAgIAAAAtBACAqQShB+IzAgAAQjICAgAAAC0EAICpBKEH4jMCAABCMgICAAAALQQAgLEEoQfiMwIAAEIyAgIAAAAtBACAOQShB+IzAgAAQjICAgAAAC0EoQShB+IzAgAAQi4CAgAAACyApIBcgD0HYnsCAABCMgICAAAALQduMwIAAQRpB+IzAgAAQjoCAgAAAC0HbjMCAAEEaQfiMwIAAEI6AgIAAAAtB24zAgABBGkH4jMCAABCOgICAAAALQduMwIAAQRpB+IzAgAAQjoCAgAAACwJAAkACQAJAAkACQCAdRQ0AIB1BAnQiDUF8aiIGQQJ2QQFqIgtBA3EhCAJAAkACQCAGQQxPDQBCACEJIARB4AlqIQYMAQsgC0H8////B3EhC0IAIQkgBEHgCWohBgNAIAYgBjUCAEIFfiAJfCIJPgIAIAZBBGoiByAHNQIAQgV+IAlCIIh8Igk+AgAgBkEIaiIHIAc1AgBCBX4gCUIgiHwiCT4CACAGQQxqIgcgBzUCAEIFfiAJQiCIfCIJPgIAIAlCIIghCSAGQRBqIQYgC0F8aiILDQALIAhFDQELIAhBAnQhCwNAIAYgBjUCAEIFfiAJfCIJPgIAIAZBBGohBiAJQiCIIQkgC0F8aiILDQALCwJAIAlQRQ0AIB0hHgwBCyAdQShGDQEgBEHgCWogDWogCac2AgAgHUEBaiEeCyAEIB42AoALIB4gDiAeIA5LGyIGQSlPDQEgBkECdCEGIARBuAhqQXxqIQggBEHgCWpBfGohDQJAAkADQCAGRQ0BIA0gBmohCyAIIAZqIQcgBkF8aiEGIAcoAgAiByALKAIAIgtGDQALIAcgC0sgByALSWtB/wFxDgIAAQYLAkAgFkUNAEEAIRcMBwsgF0F/aiIGIA9PDQMgBEEsaiAGai0AAEEBcUUNBQsgFyAPSw0DIARBLGogF2ohByAXIQYCQANAIAYiC0UNASALQX9qIgYgBEEsamotAABBOUYNAAsgBEEsaiAGaiIGIAYtAABBAWo6AAAgFyALayIGRQ0FIARBLGogC2pBMCAG/AsADAULQTEhBgJAIBYNACAEQTE6ACxBMCEGIBdBf2oiC0UNACAEQS1qQTAgC/wLAAsgGEEBaiEYIB8NBCAXIA9PDQQgByAGOgAAIBdBAWohFwwEC0EoQShB+IzAgAAQi4CAgAAAC0EAIAZBKEH4jMCAABCMgICAAAALIAYgD0GYnsCAABCLgICAAAALQQAgFyAPQaiewIAAEIyAgIAAAAsgFyAPTQ0AQQAgFyAPQbiewIAAEIyAgIAAAAsgBEEsaiEIC0Hsi8CAAEHti8CAACAFQQBIIgYbQeyLwIAAQQEgBhsgAhshC0EBIAVBH3YgAhshBwJAIBjBIBBMDQAgBEEIaiAIIBcgGCAMIARBzA1qELaAgIAAIAQoAgwhBiAEKAIIIQgMAQtBAiEGIARBAjsBzA0CQCADQf//A3ENAEEBIQYgBEEBNgLUDSAEQfSLwIAANgLQDSAEQcwNaiEIDAELIAQgDDYC3A0gBEEAOwHYDSAEQQI2AtQNIARB9YvAgAA2AtANIARBzA1qIQgLIAQgBjYCtAwgBCAINgKwDCAEIAc2AqwMIAQgCzYCqAwgACAEQagMahC7gICAACEGIARB8A5qJICAgIAAIAYLyQEBAn8jgICAgABBEGsiBCSAgICAAEEAQQAoArSswIAAIgVBAWo2ArSswIAAAkAgBUEASA0AAkACQEEALQCsrMCAAA0AQQBBAToArKzAgABBAEEAKAKorMCAAEEBajYCqKzAgABBACgCsKzAgAAiBUF/TA0CIAVBAWoiASAFTg0BELSAgIAAAAsgBEEIaiAAIAEoAhgRgoCAgACAgICAAAwBC0EAIAFBf2o2ArCswIAAQQBBADoArKzAgAAgAkUNABDBgICAAAALAAsDAAALCQAgAEEANgIACx4AIABBACkCyKLAgAA3AgggAEEAKQLAosCAADcCAAsOAEEAQQE6ALiswIAAAAsLACAAEMaAgIAAAAuMAQEDfyOAgICAAEEQayIBJICAgIAAAkAgACgCACICKAIEIgNBAXFFDQAgAigCACECIAEgA0EBdjYCBCABIAI2AgAgAUGIosCAACAAKAIIIgAtAAggAC0ACRDAgICAAAALIAFBfzYCACABIAA2AgwgAUGkosCAACAAKAIIIgAtAAggAC0ACRDAgICAAAALhAEBA38CQAJAAkAgACgCACIBQQFIDQAgACgCBCICQXxqKAIAIgBBeHEiA0EEQQggAEEDcSIAGyABakkNAQJAIABFDQAgAyABQSdqSw0DCyACEI2AgIAACw8LQeCiwIAAQS5BkKPAgAAQjoCAgAAAC0Ggo8CAAEEuQdCjwIAAEI6AgIAAAAtUAAJAIAAoAgBBf0YNACABKAIAIAAoAgQgACgCCCABKAIEKAIMEYGAgIAAgICAgAAPCyABKAIAIAEoAgQgACgCDCgCACIAKAIAIAAoAgQQrICAgAAL/QECAn8BfiOAgICAAEEgayICJICAgIAAAkAgASgCAEF/Rw0AIAEoAgwhAyACQQA2AhggAkKAgICAEDcCECACQRBqQfChwIAAIAMoAgAiAygCACADKAIEEKyAgIAAGiACIAIoAhgiAzYCCCACIAIpAhAiBDcDACABIAM2AgggASAENwIACyABKAIIIQMgAUEANgIIIAEpAgAhBCABQoCAgIAQNwIAIAIgAzYCGCACIAQ3AxACQEEMEIiAgIAAIgENAEEEQQwQlICAgAAACyABIAIoAhg2AgggASACKQMQNwIAIABBrKTAgAA2AgQgACABNgIAIAJBIGokgICAgAALoQECAn8BfiOAgICAAEEgayICJICAgIAAAkAgASgCAEF/Rw0AIAEoAgwhAyACQQA2AhwgAkKAgICAEDcCFCACQRRqQfChwIAAIAMoAgAiAygCACADKAIEEKyAgIAAGiACIAIoAhwiAzYCECACIAIpAhQiBDcDCCABIAM2AgggASAENwIACyAAQaykwIAANgIEIAAgATYCACACQSBqJICAgIAAC58BAQF/I4CAgIAAQRBrIgMkgICAgAACQCACIAFqIgEgAk8NAEEAQQAQhoCAgAAACyADQQRqIAAoAgAiAiAAKAIEIAEgAkEBdCICIAEgAksbIgJBCCACQQhLGyICEMyAgIAAAkAgAygCBEEBRw0AIAMoAgggAygCDBCGgICAAAALIAMoAgghASAAIAI2AgAgACABNgIEIANBEGokgICAgAALgQEBAX9BACEEAkACQCADQQBODQBBASEBQQQhAgwBCwJAAkAgAUUNACACIAFBASADEIeAgIAAIQQMAQsgAxCIgICAACEECwJAAkAgBA0AQQEhASAAQQE2AgQMAQsgACAENgIEQQAhAQtBCCECIAMhBAsgACACaiAENgIAIAAgATYCAAuCAQEDfwJAAkACQCAAKAIAIgFFDQAgACgCBCICQXxqKAIAIgBBeHEiA0EEQQggAEEDcSIAGyABakkNAQJAIABFDQAgAyABQSdqSw0DCyACEI2AgIAACw8LQeCiwIAAQS5BkKPAgAAQjoCAgAAAC0Ggo8CAAEEuQdCjwIAAEI6AgIAAAAseACAAQQApAtiiwIAANwIIIABBACkC0KLAgAA3AgALWgEBfwJAAkACQCACIAAoAgAgACgCCCIDa00NACAAIAMgAhDLgICAACAAKAIIIQMMAQsgAkUNAQsgAkUNACAAKAIEIANqIAEgAvwKAAALIAAgAyACajYCCEEAC5oCAQZ/IAAoAgghAgJAAkAgAUGAAU8NAEEBIQMMAQsCQCABQYAQTw0AQQIhAwwBC0EDQQQgAUGAgARJGyEDCwJAIAMgACgCACACa00NACAAIAIgAxDLgICAAAsgACgCBCACaiEEAkACQCABQYABSQ0AIAFBP3FBgH9yIQUgAUEGdiEGAkAgAUGAEE8NACAEIAU6AAEgBCAGQcABcjoAAAwCCyABQQx2IQcgBkE/cUGAf3IhBgJAIAFB//8DSw0AIAQgBToAAiAEIAY6AAEgBCAHQeABcjoAAAwCCyAEIAU6AAMgBCAGOgACIAQgB0E/cUGAf3I6AAEgBCABQRJ2QXByOgAADAELIAQgAToAAAsgACADIAJqNgIIQQALFAAgAEHwocCAACABIAIQrICAgAALJAAgASgCACAAKAIAIAAoAgQgASgCBCgCDBGBgICAAICAgIAAC0wBAn8gASgCBCECIAEoAgAhAwJAQQgQiICAgAAiAQ0AQQRBCBCUgICAAAALIAEgAjYCBCABIAM2AgAgAEGcpMCAADYCBCAAIAE2AgALFAAgAEGcpMCAADYCBCAAIAE2AgALDAAgACABKQIANwMAC8MCAQR/QR8hAgJAIAFBgICACE8NACABQSYgAUEIdmciAmt2QQFxIAJBAXRyQT5zIQILIABCADcCECAAIAI2AhwgAkECdEHYqMCAAGohAwJAQQAoAvSrwIAAQQEgAnQiBHENACADIAA2AgAgACADNgIYIAAgADYCDCAAIAA2AghBAEEAKAL0q8CAACAEcjYC9KvAgAAPCwJAAkACQCADKAIAIgQoAgRBeHEgAUcNACAEIQIMAQsgAUEAQRkgAkEBdmsgAkEfRht0IQMDQCAEIANBHXZBBHFqIgUoAhAiAkUNAiADQQF0IQMgAiEEIAIoAgRBeHEgAUcNAAsLIAIoAggiAyAANgIMIAIgADYCCCAAQQA2AhggACACNgIMIAAgAzYCCA8LIAVBEGogADYCACAAIAQ2AhggACAANgIMIAAgADYCCAsNACAAIAEQxICAgAAAC68EAgR/A30jgICAgABBEGshASAAvCICQR92IQMCQAJAAkACQAJAAkACQCACQf////8HcSIEQdDYupUESQ0AAkAgBEGAgID8B00NACAADwsCQCAEQZfkxZUESw0AIAJBf0oNAiABQwAAgIAgAJU4AgggASoCCBoMAgsCQCACQX9KDQAgAUMAAICAIACVOAIIIAEqAggaQwAAAAAhBSAEQbTjv5YETQ0CDAcLIABDAAAAf5QPCwJAIARBmOTF9QNLDQAgBEGAgIDIA00NAkEAIQRDAAAAACEGIAAhBQwFCyAEQZKrlPwDTQ0CCyAAQzuquD+UIANBAnQqAuCkwIAAkvwAIQQMAgsgASAAQwAAAH+SOAIMIAEqAgwaIABDAACAP5IPCyADQQFzIANrIQQLIAAgBLIiBUMAcjG/lJIiACAFQ46+vzWUIgaTIQULIAAgBSAFIAUgBZQiByAHQxVSNbuUQ4+qKj6SlJMiB5RDAAAAQCAHk5UgBpOSQwAAgD+SIQUgBEUNAAJAAkACQAJAIARB/wBKDQAgBEGCf04NAyAFQwAAgAyUIQUgBEGbfk0NASAEQeYAaiEEDAMLIAVDAAAAf5QhBSAEQf4BSw0BIARBgX9qIQQMAgsgBUMAAIAMlCEFIARBtn0gBEG2fUsbQcwBaiEEDAELIAVDAAAAf5QhBSAEQf0CIARB/QJJG0GCfmohBAsgBSAEQRd0QYCAgPwDakGAgID8B3G+lCEFCyAFCwoAIAAQ2ICAgAALryIICX8BfAp/AXwIfwF8BH8DfCOAgICAAEGwBGsiBiSAgICAACAGQgA3A5gBIAZCADcDkAEgBkIANwOIASAGQgA3A4ABIAZCADcDeCAGQgA3A3AgBkIANwNoIAZCADcDYCAGQgA3A1ggBkIANwNQIAZCADcDSCAGQgA3A0AgBkIANwM4IAZCADcDMCAGQgA3AyggBkIANwMgIAZCADcDGCAGQgA3AxAgBkIANwMIIAZCADcDACAGQgA3A7gCIAZCADcDsAIgBkIANwOoAiAGQgA3A6ACIAZCADcDmAIgBkIANwOQAiAGQgA3A4gCIAZCADcDgAIgBkIANwP4ASAGQgA3A/ABIAZCADcD6AEgBkIANwPgASAGQgA3A9gBIAZCADcD0AEgBkIANwPIASAGQgA3A8ABIAZCADcDuAEgBkIANwOwASAGQgA3A6gBIAZCADcDoAEgBkIANwPYAyAGQgA3A9ADIAZCADcDyAMgBkIANwPAAyAGQgA3A7gDIAZCADcDsAMgBkIANwOoAyAGQgA3A6ADIAZCADcDmAMgBkIANwOQAyAGQgA3A4gDIAZCADcDgAMgBkIANwP4AiAGQgA3A/ACIAZCADcD6AIgBkIANwPgAiAGQgA3A9gCIAZCADcD0AIgBkIANwPIAiAGQgA3A8ACIAZB4ANqQQBB0AD8CwAgBUECdCgC6KTAgAAiByABQX9qIghqIQkgBEF9akEYbSIKQQAgCkEAShsiCyAIayEMIAtBAnQgAUECdGtB/KTAgABqIQ0gBiEKQQAhDgNAAkACQCAMIA5qQQBODQBEAAAAAAAAAAAhDwwBCyANKAIAtyEPCyAKIA85AwAgCkEIaiEKIA1BBGohDSAOQQFqIg4gCU0NAAsgAUEBcSEQQQAgAUF+cWshCSABQQN0IAZqQXBqIRFBACEMA0BEAAAAAAAAAAAhDwJAAkACQCAIDQBBACEKDAELQQAhDSARIQogACEOA0AgDyAOKwMAIApBCGorAwCioCAOQQhqKwMAIAorAwCioCEPIApBcGohCiAOQRBqIQ4gCSANQX5qIg1HDQALIBBFDQFBACANayEKCyAPIAAgCkEDdGorAwAgBiAMIAhqIAprQQN0aisDAKKgIQ8LIAZBwAJqIAxBA3RqIA85AwAgEUEIaiERIAxBAWoiDCAHTQ0AC0QAAAAAAADwf0QAAAAAAADgfyAEIAtBaGxqIhJBaGoiE0H+D0siFBtEAAAAAAAAAABEAAAAAAAAYAMgE0G5cEkiFRtEAAAAAAAA8D8gE0GCeEgiFhsgE0H/B0oiFxsgE0H9FyATQf0XSRtBgnBqIBJB6XdqIBQbIhggE0HwaCATQfBoSxtBkg9qIBJBsQdqIBUbIhkgEyAWGyAXG0H/B2qtQjSGv6IhGiABQQFxIRtBACABQX5xayEJIAZB4ANqQXxqIhwgB0ECdGohHUEvIBJrQR9xIR5BMCASa0EfcSEfIAZBeGohICAGQcACakF4aiEhIBNBf2ohIiAHIQwCQANAIAZBwAJqIAwiEEEDdCIKaisDACEPAkAgEEUNACAGQeADaiEOA0AgDiAPIA9EAAAAAAAAcD6i/AK3IiNEAAAAAAAAcMGioPwCNgIAICEgCmorAwAgI6AhDyAOQQRqIQ4gCkF4aiIKDQALCwJAAkACQCAXDQAgFg0BIBMhCgwCCyAPRAAAAAAAAOB/oiIPRAAAAAAAAOB/oiAPIBQbIQ8gGCEKDAELIA9EAAAAAAAAYAOiIg9EAAAAAAAAYAOiIA8gFRshDyAZIQoLIA8gCkH/B2qtQjSGv6IiDyAPRAAAAAAAAMA/opxEAAAAAAAAIMCioCIPIA/8AiIkt6EhDwJAAkACQAJAAkACQCATQQBKIiUNAAJAIBMNACAGQeADaiAQQQJ0akF8aigCAEEXdSEmDAILQQIhJkEAIScgD0QAAAAAAADgP2ZFDQUMAgsgBkHgA2ogEEECdGpBfGoiCiAKKAIAIgogCiAfdSIKIB90ayIONgIAIA4gHnUhJiAKICRqISQLICZBAUgNAQtBASEOAkAgEEUNAEEAIQ1BACEMAkAgEEEBRg0AIBBBAXEhJyAQQR5xIQRBACENIAZB4ANqIQpBACEMA0AgCigCACEOAkACQAJAAkAgDEUNAEH///8HIQwMAQsgDkUNAUGAgIAIIQwLIAogDCAOazYCAEEAIQwMAQtBASEMCyAKQQRqIhEoAgAhDgJAAkACQAJAIAwNAEH///8HIQwMAQsgDkUNAUGAgIAIIQwLIBEgDCAOazYCAEEBIQxBACEODAELQQAhDEEBIQ4LIApBCGohCiAEIA1BAmoiDUcNAAsgJ0UNAQsgBkHgA2ogDUECdGoiDSgCACEKAkACQCAMRQ0AQf///wchDgwBC0EBIQ4gCkUNAUGAgIAIIQ4LIA0gDiAKazYCAEEAIQ4LAkAgJUUNAEH///8DIQoCQAJAICIOAgEAAgtB////ASEKCyAGQeADaiAQQQJ0akF8aiINIA0oAgAgCnE2AgALICRBAWohJCAmQQJGDQELICYhJwwBC0QAAAAAAADwPyAPoSIPIA8gGqEgDhshD0ECIScLAkAgD0QAAAAAAAAAAGINACAdIQogECEMAkAgByAQQX9qIg5LDQAgHCAQQQJ0aiEKQQAhDQJAA0AgCigCACANciENIA5FDQEgCkF8aiEKIAcgDkF/aiIOTQ0ACwsgHSEKIBAhDCANRQ0AIAZB4ANqIBBBAnRqQXxqIQoDQCAQQX9qIRAgE0FoaiETIAooAgAhDiAKQXxqIQogDkUNAAwECwsDQCAMQQFqIQwgCigCACEOIApBfGohCiAORQ0ACyAQIAxPDQEgEEEBaiEKICAgASAQakEDdGohBANAIAYgECABaiIQQQN0aiAKIhEgC2pBAnQoAvikwIAAtzkDAAJAAkACQCAIDQBBACEKRAAAAAAAAAAAIQ8MAQtEAAAAAAAAAAAhD0EAIQ0gBCEKIAAhDgNAIA8gDisDACAKQQhqKwMAoqAgDkEIaisDACAKKwMAoqAhDyAKQXBqIQogDkEQaiEOIAkgDUF+aiINRw0ACyAbRQ0BQQAgDWshCgsgDyAAIApBA3RqKwMAIAYgECAKa0EDdGorAwCioCEPCyAGQcACaiARQQN0aiAPOQMAIARBCGohBCARIRAgEUEBaiIKIAxNDQAMAgsLCwJAAkACQAJAQQAgE2siCkH/B0oNACAKQYJ4Tg0DIA9EAAAAAAAAYAOiIQ8gCkG4cE0NAUHJByATayEKDAMLIA9EAAAAAAAA4H+iIQ8gCkH+D0sNAUGBeCATayEKDAILIA9EAAAAAAAAYAOiIQ8gCkHwaCAKQfBoSxtBkg9qIQoMAQsgD0QAAAAAAADgf6IhDyAKQf0XIApB/RdJG0GCcGohCgsCQCAPIApB/wdqrUI0hr+iIg9EAAAAAAAAcEFmDQAgBkHgA2ogEEECdGogD/wCNgIADAELIAZB4ANqIBBBAWoiCkECdGogD0QAAAAAAABwPqL8AiIONgIAIAZB4ANqIBBBAnRqIA8gDrdEAAAAAAAAcMGioPwCNgIAIAohECASIRMLAkACQAJAAkAgE0H/B0oNACATQYJ4SA0BRAAAAAAAAPA/IQ8MAwsgE0H+D0sNASATQYF4aiETRAAAAAAAAOB/IQ8MAgsCQCATQbhwTQ0AIBNByQdqIRNEAAAAAAAAYAMhDwwCCyATQfBoIBNB8GhLG0GSD2ohE0QAAAAAAAAAACEPDAELIBNB/RcgE0H9F0kbQYJwaiETRAAAAAAAAPB/IQ8LIA8gE0H/B2qtQjSGv6IhDwJAAkAgEEEBcUUNACAQIQ0MAQsgBkHAAmogEEEDdGogDyAGQeADaiAQQQJ0aigCALeiOQMAIA9EAAAAAAAAcD6iIQ8gEEF/aiENCwJAIBBFDQAgDUECdCAGQeADampBfGohCiANQQN0IAZBwAJqakF4aiEOA0AgDiAPRAAAAAAAAHA+oiIjIAooAgC3ojkDACAOQQhqIA8gCkEEaigCALeiOQMAIApBeGohCiAOQXBqIQ4gI0QAAAAAAABwPqIhDyANQX5qIg1Bf0cNAAsLIBBBAWohISAGQcACaiAQQQN0aiEJIBAhCgNAAkACQAJAIAcgECAKIhFrIgQgByAESRsiAA0ARAAAAAAAAAAAIQ9BACEODAELIABBAWpBfnEhDEQAAAAAAAAAACEPQQAhCkEAIQ4DQCAPIApBgKfAgABqKwMAIAkgCmoiDSsDAKKgIApBiKfAgABqKwMAIA1BCGorAwCioCEPIApBEGohCiAMIA5BAmoiDkcNAAsgAEEBcQ0BCyAPIA5BA3QrA4CnwIAAIAZBwAJqIA4gEWpBA3RqKwMAoqAhDwsgBkGgAWogBEEDdGogDzkDACAJQXhqIQkgEUF/aiEKIBENAAsCQAJAAkACQCAFDgQBAgIAAQtEAAAAAAAAAAAhKAJAIBBFDQAgECEOAkAgEEEBcUUNACAGQaABaiAQQQN0aiIKQXhqIg4gDisDACIPIAorAwAiI6AiGjkDACAKICMgDyAaoaA5AwAgEEF/aiEOCyAQQQFGDQAgDkEDdCAGQaABampBcGohCgNAIAogCisDACIjIApBCGoiDSsDACIaIApBEGoiCSsDACIpoCIPoCIqOQMAIAkgKSAaIA+hoDkDACANIA8gIyAqoaA5AwAgCkFwaiEKIA5BfmoiDg0ACyAQQQFGDQAgEEEDdCAGQaABampBeGohCiAQIQ4DQCAKIAorAwAiDyAKQQhqIg0rAwAiI6AiGjkDACANICMgDyAaoaA5AwAgCkF4aiEKIA5BAkshDSAOQX9qIQ4gDQ0ACyAGQaABaiAQQQN0aiEKRAAAAAAAAAAAISgDQCAoIAorAwCgISggEEECSyEOIApBeGohCiAQQX9qIRAgDg0ACwsgBisDoAEhDwJAICcNACACIA85AwAgAiAoOQMQIAIgBisDqAE5AwgMAwsgAiAPmjkDACACICiaOQMQIAIgBisDqAGaOQMIDAILAkACQCAhQQNxIg0NAEQAAAAAAAAAACEPIBAhDgwBCyAGQaABaiAQQQN0aiEKRAAAAAAAAAAAIQ8gECEOA0AgDkF/aiEOIA8gCisDAKAhDyAKQXhqIQogDUF/aiINDQALCwJAIBBBA0kNACAOQQN0IAZBoAFqakFoaiEKA0AgDyAKQRhqKwMAoCAKQRBqKwMAoCAKQQhqKwMAoCAKKwMAoCEPIApBYGohCiAOQXxqIg5Bf0cNAAsLIAIgD5ogDyAnGzkDAAwBCwJAAkAgIUEDcSINDQBEAAAAAAAAAAAhDyAQIQ4MAQsgBkGgAWogEEEDdGohCkQAAAAAAAAAACEPIBAhDgNAIA5Bf2ohDiAPIAorAwCgIQ8gCkF4aiEKIA1Bf2oiDQ0ACwsCQCAQQQNJDQAgDkEDdCAGQaABampBaGohCgNAIA8gCkEYaisDAKAgCkEQaisDAKAgCkEIaisDAKAgCisDAKAhDyAKQWBqIQogDkF8aiIOQX9HDQALCyACIA+aIA8gJxs5AwAgBisDoAEgD6EhDwJAIBBFDQAgEEEDcSEOQQEhCgJAIBBBf2pBA0kNACAQQXxxIQkgBkGgAWpBIGohCkEAIQ0DQCAPIApBaGorAwCgIApBcGorAwCgIApBeGorAwCgIAorAwCgIQ8gCkEgaiEKIAkgDUEEaiINRw0ACyAORQ0BIA1BAWohCgsgBkGgAWogCkEDdGohCgNAIA8gCisDAKAhDyAKQQhqIQogDkF/aiIODQALCyACIA+aIA8gJxs5AwgLIAZBsARqJICAgIAAICRBB3EL1goGAX8BfAJ/AXwBfwF8I4CAgIAAQRBrIgEkgICAgAAgALshAgJAAkACQAJAIAC8IgNB/////wdxIgRB25+k+gNJDQACQCAEQdKn7YMESQ0AAkAgBEHW44iHBEkNAAJAAkACQAJAAkAgBEH////7B0sNACABQgA3AwgCQAJAIARB2p+k7gRLDQAgAiACRIPIyW0wX+Q/okQAAAAAAAA4Q6BEAAAAAAAAOMOgIgVEAAAAUPsh+b+ioCAFRGNiGmG0EFG+oqAhAiAF/AIhBAwBCyABIAQgBEEXdkHqfmoiBkEXdGu+uzkDACABQQEgAUEIakEBIAZBABDagICAACEEAkAgA0EASA0AIAErAwghAgwBC0EAIARrIQQgASsDCJohAgsgBEEDcQ4EAgMEAQILIAAgAJMhAAwJCyACIAIgAqIiBaIiByAFIAWioiAFRKdGO4yHzcY+okR058ri+QAqv6CiIAIgByAFRLL7bokQEYE/okR3rMtUVVXFv6CioKC2IQAMCAsgAiACoiICRIFeDP3//9+/okQAAAAAAADwP6AgAiACoiIFREI6BeFTVaU/oqAgAiAFoiACRGlQ7uBCk/k+okQnHg/oh8BWv6CioLYhAAwHCyACIAKiIgUgApqiIgcgBSAFoqIgBUSnRjuMh83GPqJEdOfK4vkAKr+goiAHIAVEsvtuiRARgT+iRHesy1RVVcW/oKIgAqGgtiEADAYLIAIgAqIiAkSBXgz9///fv6JEAAAAAAAA8D+gIAIgAqIiBURCOgXhU1WlP6KgIAIgBaIgAkRpUO7gQpP5PqJEJx4P6IfAVr+goqC2jCEADAULIARB39u/hQRLDQICQCADQX9MDQAgAkTSITN/fNkSwKAiBSAFIAWiIgKiIgcgAiACoqIgAkSnRjuMh83GPqJEdOfK4vkAKr+goiAFIAcgAkSy+26JEBGBP6JEd6zLVFVVxb+goqCgtiEADAULRNIhM3982RLAIAKhIgUgBSAFoiICoiIHIAIgAqKiIAJEp0Y7jIfNxj6iRHTnyuL5ACq/oKIgBSAHIAJEsvtuiRARgT+iRHesy1RVVcW/oKKgoLYhAAwECyAEQeOX24AESw0CAkAgA0F/TA0ARBgtRFT7Ifk/IAKhIgUgBSAFoiICoiIHIAIgAqKiIAJEp0Y7jIfNxj6iRHTnyuL5ACq/oKIgBSAHIAJEsvtuiRARgT+iRHesy1RVVcW/oKKgoLYhAAwECyACRBgtRFT7Ifk/oCIFIAUgBaIiAqIiByACIAKioiACRKdGO4yHzcY+okR058ri+QAqv6CiIAUgByACRLL7bokQEYE/okR3rMtUVVXFv6CioKC2IQAMAwsCQCAEQYCAgMwDSQ0AIAIgAqIiAkSBXgz9///fv6JEAAAAAAAA8D+gIAIgAqIiBURCOgXhU1WlP6KgIAIgBaIgAkRpUO7gQpP5PqJEJx4P6IfAVr+goqC2IQAMAwsgASAAQwAAgHuSOAIIIAEqAggaQwAAgD8hAAwCC0QYLURU+yEZwEQYLURU+yEZQCADQX9KGyACoCICIAKiIgJEgV4M/f//37+iRAAAAAAAAPA/oCACIAKiIgVEQjoF4VNVpT+ioCACIAWiIAJEaVDu4EKT+T6iRCceD+iHwFa/oKKgtiEADAELRBgtRFT7IQnARBgtRFT7IQlAIANBf0obIAKgIgIgAqIiAkSBXgz9///fv6JEAAAAAAAA8D+gIAIgAqIiBURCOgXhU1WlP6KgIAIgBaIgAkRpUO7gQpP5PqJEJx4P6IfAVr+goqC2jCEACyABQRBqJICAgIAAIAALCgAgABDbgICAAAtuAQZ+IAAgA0L/////D4MiBSABQv////8PgyIGfiIHIANCIIgiCCAGfiIGIAUgAUIgiCIJfnwiBUIghnwiCjcDACAAIAggCX4gBSAGVK1CIIYgBUIgiIR8IAogB1StfCAEIAF+IAMgAn58fDcDCAuCAgICfwJ9AkACQAJAAkAgALwiAUGAgIAESA0AIAFB////+wdLDQNBgX8hAiABQYCAgPwDRw0BQwAAAAAPCwJAIABDAAAAAFwNAEMAAID/DwsgAUEASA0BIABDAAAATJS8IQFB6H4hAgsgAUGN9qsCaiIBQRd2IAJqsiIDQ4BxMT+UIAFB////A3FB84nU+QNqvkMAAIC/kiIAIAND0fcXN5QgACAAQwAAAECSlSIDIAAgAEMAAAA/lJQiBCADIAOUIgAgACAAlCIAQ+7pkT6UQ6qqKj+SlCAAIABDJp54PpRDE87MPpKUkpKUkiAEk5KSDwsgACAAk0MAAAAAlSEACyAAC+YKBgF/AXwCfwF8AX8BfCOAgICAAEEQayIBJICAgIAAIAC7IQICQAJAIAC8IgNB/////wdxIgRB25+k+gNJDQACQCAEQdKn7YMESQ0AAkAgBEHW44iHBEkNAAJAAkACQAJAAkAgBEH////7B0sNACABQgA3AwgCQAJAIARB2p+k7gRLDQAgAiACRIPIyW0wX+Q/okQAAAAAAAA4Q6BEAAAAAAAAOMOgIgVEAAAAUPsh+b+ioCAFRGNiGmG0EFG+oqAhAiAF/AIhBAwBCyABIAQgBEEXdkHqfmoiBkEXdGu+uzkDACABQQEgAUEIakEBIAZBABDagICAACEEAkAgA0EASA0AIAErAwghAgwBC0EAIARrIQQgASsDCJohAgsgBEEDcQ4EAgMEAQILIAAgAJMhAAwHCyACIAKiIgJEgV4M/f//37+iRAAAAAAAAPA/oCACIAKiIgVEQjoF4VNVpT+ioCACIAWiIAJEaVDu4EKT+T6iRCceD+iHwFa/oKKgtowhAAwGCyACIAIgAqIiBaIiByAFIAWioiAFRKdGO4yHzcY+okR058ri+QAqv6CiIAIgByAFRLL7bokQEYE/okR3rMtUVVXFv6CioKC2IQAMBQsgAiACoiICRIFeDP3//9+/okQAAAAAAADwP6AgAiACoiIFREI6BeFTVaU/oqAgAiAFoiACRGlQ7uBCk/k+okQnHg/oh8BWv6CioLYhAAwECyACIAKiIgUgApqiIgcgBSAFoqIgBUSnRjuMh83GPqJEdOfK4vkAKr+goiAHIAVEsvtuiRARgT+iRHesy1RVVcW/oKIgAqGgtiEADAMLAkAgBEHg27+FBEkNAEQYLURU+yEZwEQYLURU+yEZQCADQX9KGyACoCIFIAUgBaIiAqIiByACIAKioiACRKdGO4yHzcY+okR058ri+QAqv6CiIAUgByACRLL7bokQEYE/okR3rMtUVVXFv6CioKC2IQAMAwsCQCADQQBIDQAgAkTSITN/fNkSwKAiAiACoiICRIFeDP3//9+/okQAAAAAAADwP6AgAiACoiIFREI6BeFTVaU/oqAgAiAFoiACRGlQ7uBCk/k+okQnHg/oh8BWv6CioLaMIQAMAwsgAkTSITN/fNkSQKAiAiACoiICRIFeDP3//9+/okQAAAAAAADwP6AgAiACoiIFREI6BeFTVaU/oqAgAiAFoiACRGlQ7uBCk/k+okQnHg/oh8BWv6CioLYhAAwCCwJAIARB5JfbgARJDQBEGC1EVPshCcBEGC1EVPshCUAgA0F/ShsgAqAiBSAFoiICIAWaoiIHIAIgAqKiIAJEp0Y7jIfNxj6iRHTnyuL5ACq/oKIgByACRLL7bokQEYE/okR3rMtUVVXFv6CiIAWhoLYhAAwCCwJAIANBAEgNACACRBgtRFT7Ifm/oCICIAKiIgJEgV4M/f//37+iRAAAAAAAAPA/oCACIAKiIgVEQjoF4VNVpT+ioCACIAWiIAJEaVDu4EKT+T6iRCceD+iHwFa/oKKgtiEADAILIAJEGC1EVPsh+T+gIgIgAqIiAkSBXgz9///fv6JEAAAAAAAA8D+gIAIgAqIiBURCOgXhU1WlP6KgIAIgBaIgAkRpUO7gQpP5PqJEJx4P6IfAVr+goqC2jCEADAELAkAgBEGAgIDMA0kNACACIAKiIgUgAqIiByAFIAWioiAFRKdGO4yHzcY+okR058ri+QAqv6CiIAcgBUSy+26JEBGBP6JEd6zLVFVVxb+goiACoKC2IQAMAQsgASAAQwAAgAOUIABDAACAe5IgBEGAgIAESRs4AgggASoCCBoLIAFBEGokgICAgAAgAAsKACAAEN+AgIAAC7QCAwN/AX0CfCOAgICAAEEQayEBAkACQCAAvCICQf////8HcSIDQYCA8JcESw0AIANBgYCAmANPDQEgAEMAAIA/kg8LAkACQCADQYCAgPwHSw0AAkAgAkH///+XBEoNACACQQBODQMgAkH//9eYfEsNAiACQf//A3FFDQMgAUMBAACAIACVOAIMIAEqAgwaDAMLIABDAAAAf5QhAAsgAA8LIAFDAQAAgCAAlTgCDCABKgIMGkMAAAAADwsgAEMAAEBJkiIEvEEIaiIDQQ9xQQN0KwPAp8CAACIFIAAgBEMAAEDJkpO7IgZEAAAAAL6/zj+iRAAAAABDLuY/oCAFIAaiIgWioCAGRAAAAMDJsoM/okQAAACANGusP6AgBiAGoiAFoqKgIANBBHZB/wdqrUI0hr+itgv6CAUBfwF8An8CfAF/I4CAgIAAQRBrIgEkgICAgAAgALshAgJAAkAgALwiA0H/////B3EiBEHbn6T6A0kNAAJAIARB0qftgwRJDQACQCAEQdbjiIcESQ0AAkAgBEH////7B0sNACABQgA3AwgCQAJAIARB2p+k7gRLDQAgAiACRIPIyW0wX+Q/okQAAAAAAAA4Q6BEAAAAAAAAOMOgIgVEAAAAUPsh+b+ioCAFRGNiGmG0EFG+oqAhBiAF/AIhBAwBCyABIAQgBEEXdkHqfmoiB0EXdGu+uzkDACABQQEgAUEIakEBIAdBABDagICAACEEAkAgA0EASA0AIAErAwghBgwBC0EAIARrIQQgASsDCJohBgtEAAAAAAAA8L8gBiAGIAYgBqIiAqIiBSACRHKfmTj9EsE/okSfyRg0TVXVP6CioCAFIAIgAqIiBqIgAkTOM4yQ8x2ZP6JE/lqGHclUqz+gIAYgAkTNG5e/uWKDP6JETvTs/K1daD+goqCioCICoyACIARBAXEbtiEADAQLIAAgAJMhAAwDCwJAIARB4Nu/hQRJDQBEGC1EVPshGcBEGC1EVPshGUAgA0F/ShsgAqAiBiAGIAYgBqIiAqIiBiACRHKfmTj9EsE/okSfyRg0TVXVP6CioCAGIAIgAqIiBaIgAkTOM4yQ8x2ZP6JE/lqGHclUqz+gIAUgAkTNG5e/uWKDP6JETvTs/K1daD+goqCioLYhAAwDC0QAAAAAAADwv0TSITN/fNkSwETSITN/fNkSQCADQX9KGyACoCIGIAYgBiAGoiICoiIGIAJEcp+ZOP0SwT+iRJ/JGDRNVdU/oKKgIAYgAiACoiIFoiACRM4zjJDzHZk/okT+WoYdyVSrP6AgBSACRM0bl7+5YoM/okRO9Oz8rV1oP6CioKKgo7YhAAwCCwJAIARB5JfbgARJDQBEGC1EVPshCcBEGC1EVPshCUAgA0F/ShsgAqAiBiAGIAYgBqIiAqIiBiACRHKfmTj9EsE/okSfyRg0TVXVP6CioCAGIAIgAqIiBaIgAkTOM4yQ8x2ZP6JE/lqGHclUqz+gIAUgAkTNG5e/uWKDP6JETvTs/K1daD+goqCioLYhAAwCC0QAAAAAAADwv0QYLURU+yH5v0QYLURU+yH5PyADQX9KGyACoCIGIAYgBiAGoiICoiIGIAJEcp+ZOP0SwT+iRJ/JGDRNVdU/oKKgIAYgAiACoiIFoiACRM4zjJDzHZk/okT+WoYdyVSrP6AgBSACRM0bl7+5YoM/okRO9Oz8rV1oP6CioKKgo7YhAAwBCwJAIARBgICAzANJDQAgAiACoiIGIAKiIgUgBkRyn5k4/RLBP6JEn8kYNE1V1T+goiACoCAFIAYgBqIiAqIgBkTOM4yQ8x2ZP6JE/lqGHclUqz+gIAIgBkTNG5e/uWKDP6JETvTs/K1daD+goqCioLYhAAwBCyABIABDAACAA5QgAEMAAIB7kiAEQYCAgARJGzgCCCABKgIIGgsgAUEQaiSAgICAACAACwoAIAAQ4oCAgAALpwEAAkACQAJAAkAgAUH/AEoNACABQYJ/Tg0DIABDAACADJQhACABQZt+TQ0BIAFB5gBqIQEMAwsgAEMAAAB/lCEAIAFB/gFLDQEgAUGBf2ohAQwCCyAAQwAAgAyUIQAgAUG2fSABQbZ9SxtBzAFqIQEMAQsgAEMAAAB/lCEAIAFB/QIgAUH9AkkbQYJ+aiEBCyAAIAFBF3RBgICA/ANqQYCAgPwHcb6UC8IMBQF9A38BfQR/A31DAACAPyECAkACQAJAIAC8IgNBgICA/ANGDQAgAbwiBEH/////B3EiBUUNAAJAAkACQCAAiyIGvCIHQYCAgPwHSw0AIAVBgICA/AdLDQAgA0EATg0BQQIhCCAFQf///9sESw0CIAVBgICA/ANJDQFBACEIIAVBlgEgBUEXdmsiCXYiCiAJdCAFRw0CQQIgCkEBcWshCAwCCyAAIAGSDwtBACEICwJAAkACQAJAAkAgBUGAgID8A0YNACAFQYCAgPwHRw0BAkACQCAHQYCAgPwDSiAHQYCAgPwDSGtB/wFxDgIHAQALQwAAAAAgAYwgBEF/ShsPCyABQwAAAAAgBEF/ShsPCyAEQX9MDQEgAA8LAkACQCAEQYCAgPgDRg0AIARBgICAgARHDQEgACAAlA8LIANBf0oNAgsCQAJAAkACQAJAAkAgB0UNACAHQf////8DcUGAgID8A0cNAQtDAACAPyAGlSAGIARBAEgbIQIgA0EATg0IIAcgCGpBgICA/ANHDQEgAiACkyIAIACVDwtDAACAPyELIANBAE4NAyAIDgIBAgMLIAKMIAIgCEEBRhsPCyAAIACTIgAgAJUPC0MAAIC/IQsLAkAgBUGAgIDoBEsNACAGQwAAgEuUvCAHIAdBgICABEkiAxsiCEH///8DcSIHQYCAgPwDciEFIAhBF3VB6X5BgX8gAxtqIQhBACEDAkAgB0HyiPMASQ0AAkAgB0HX5/YCTw0AQQEhAwwBCyAHQYCAgPgDciEFIAhBAWohCAsgA0ECdCIHKgLIqMCAAEMAAIA/IAcqAsCowIAAIgAgBb4iDJKVIgIgDCAAkyIGIAVBAXZBgOD//wFxIANBFXRqQYCAgIICar4iDSAGIAKUIga8QYBgcb4iApSTIAAgDZMgDJIgApSTlCIAIAIgApQiDEMAAEBAkiAAIAYgApKUIAYgBpQiACAAlCAAIAAgACAAIABDQvFTPpRDVTJsPpKUQwWjiz6SlEOrqqo+kpRDt23bPpKUQ5qZGT+SlJIiDZK8QYBgcb4iAJQgBiANIABDAABAwJIgDJOTlJIiBiAGIAIgAJQiApK8QYBgcb4iACACk5NDTzh2P5QgAEPGI/a4lJKSIgIgByoC0KjAgAAiBiACIABDAEB2P5QiDJKSIAiyIgKSvEGAYHG+IgAgApMgBpMgDJOTIQIMAwsCQCAHQfj///sDSQ0AAkAgB0GHgID8A0sNACAGQwAAgL+SIgBDcKXsNpQgACAAlEMAAAA/IAAgAEMAAIC+lEOrqqo+kpSTlEM7qri/lJIiAiACIABDAKq4P5QiBpK8QYBgcb4iACAGk5MhAgwECwJAIARBAEoNACALQ2BCog2UQ2BCog2UDwsgC0PK8klxlEPK8klxlA8LAkAgBEEASA0AIAtDYEKiDZRDYEKiDZQPCyALQ8rySXGUQ8rySXGUDwtDAACAPyAAlQ8LIACRDwsCQAJAAkAgACAEQYBgcb4iBpQiDCABIAaTIACUIAEgApSSIgGSIgC8IgVBgICAmARKDQAgBUGAgICYBEYNASAAvEH/////B3EiA0GAgNiYBEsNBSAFQYCA2Jh8Rw0CIAEgACAMk19FDQIgC0NgQqINlENgQqINlA8LIAtDyvJJcZRDyvJJcZQPCyABQzyqODOSIAAgDJNeDQIgALxB/////wdxIQMLQQAhBAJAIANBgICA+ANNDQBBAEGAgIAEIANBF3ZBAmp2IAVqIgNB////A3FBgICABHJBFiADQRd2IgdrdiIEayAEIAVBAEgbIQQgASAMQYCAgHwgB0EBanUgA3G+kyIMkrwhBQsCQAJAIARBF3QgBUGAgH5xviIAQwByMT+UIgIgAEOMvr81lCABIAAgDJOTQxhyMT+UkiIGkiIAIAAgACAAIACUIgEgASABIAEgAUNMuzEzlEMO6t21kpRDVbOKOJKUQ2ELNruSlEOrqio+kpSTIgGUIAFDAAAAwJKVIAYgACACk5MiASAAIAGUkpOTQwAAgD+SIgC8aiIFQYCAgARIDQAgBb4hAAwBCyAAIAQQ5ICAgAAhAAsgCyAAlCECCyACDwsgC0PK8klxlEPK8klxlA8LIAtDYEKiDZRDYEKiDZQLDAAgACABEOWAgIAACwu3LAIAQYCAwAAL2CgWc2xpY2UgaW5kZXggc3RhcnRzIGF0IMANIGJ1dCBlbmRzIGF0IMAAIGluZGV4IG91dCBvZiBib3VuZHM6IHRoZSBsZW4gaXMgwBIgYnV0IHRoZSBpbmRleCBpcyDAABJyYW5nZSBzdGFydCBpbmRleCDAIiBvdXQgb2YgcmFuZ2UgZm9yIHNsaWNlIG9mIGxlbmd0aCDAABByYW5nZSBlbmQgaW5kZXggwCIgb3V0IG9mIHJhbmdlIGZvciBzbGljZSBvZiBsZW5ndGggwAAkbWluID4gbWF4LCBvciBlaXRoZXIgd2FzIE5hTi4gbWluID0gwAgsIG1heCA9IMAAEGFzc2VydGlvbiBgbGVmdCDAFyByaWdodGAgZmFpbGVkCiAgbGVmdDogwAkKIHJpZ2h0OiDAAC9ydXN0Yy81OGNmOGY5YzM1YjM1NTE5OTcyNzYyN2QwN2FlMzRhNGUyODQ2ZDY3L2xpYnJhcnkvY29yZS9zcmMvbnVtL2ltcC9mbHQyZGVjL3N0cmF0ZWd5L2dyaXN1LnJzAC9ydXN0Yy81OGNmOGY5YzM1YjM1NTE5OTcyNzYyN2QwN2FlMzRhNGUyODQ2ZDY3L2xpYnJhcnkvY29yZS9zcmMvbnVtL2ltcC9kaXlfZmxvYXQucnMAc3JjL2RydW1zLnJzAC9ydXN0Yy81OGNmOGY5YzM1YjM1NTE5OTcyNzYyN2QwN2FlMzRhNGUyODQ2ZDY3L2xpYnJhcnkvc3RkL3NyYy9zeXMvc3luYy9yd2xvY2svbm9fdGhyZWFkcy5ycwAvcnVzdGMvNThjZjhmOWMzNWIzNTUxOTk3Mjc2MjdkMDdhZTM0YTRlMjg0NmQ2Ny9saWJyYXJ5L2NvcmUvc3JjL251bS9pbXAvZmx0MmRlYy9zdHJhdGVneS9kcmFnb24ucnMAL3J1c3RjLzU4Y2Y4ZjljMzViMzU1MTk5NzI3NjI3ZDA3YWUzNGE0ZTI4NDZkNjcvbGlicmFyeS9jb3JlL3NyYy9udW0vaW1wL2JpZ251bS5ycwBzcmMvb3ZlcnNhbXBsZS5ycwAvcnVzdGMvNThjZjhmOWMzNWIzNTUxOTk3Mjc2MjdkMDdhZTM0YTRlMjg0NmQ2Ny9saWJyYXJ5L2FsbG9jL3NyYy9yYXdfdmVjL21vZC5ycwAvcnVzdGMvNThjZjhmOWMzNWIzNTUxOTk3Mjc2MjdkMDdhZTM0YTRlMjg0NmQ2Ny9saWJyYXJ5L2NvcmUvc3JjL251bS9pbXAvZmx0MmRlYy9tb2QucnMAL3J1c3QvZGVwcy9kbG1hbGxvYy0wLjIuMTQvc3JjL2RsbWFsbG9jLnJzAC9ydXN0Yy81OGNmOGY5YzM1YjM1NTE5OTcyNzYyN2QwN2FlMzRhNGUyODQ2ZDY3L2xpYnJhcnkvY29yZS9zcmMvbnVtL2YzMi5ycwD4AxAASwAAAEUGAAAJAAAAEgMQABEAAABtAAAACQAAABIDEAARAAAAbgAAAAkAAAASAxAAEQAAAHQAAAASAAAAEgMQABEAAADJAAAAFgAAAPABEAAMAAAAewEAABsAAADwARAADAAAAKIBAAAdAAAA8AEQAAwAAAAbAgAAGQAAAPABEAAMAAAA2gMAACoAAADwARAADAAAAN8DAAAeAAAA8AEQAAwAAADgAwAAEgAAAPABEAAMAAAA4AMAAAkAAADwARAADAAAAAUEAAASAAAA8AEQAAwAAABLBAAAFAAAAPABEAAMAAAAzAAAACsAAAAAAEBAZmbmP2ZmZkDNzCzAZmYmQM3MLEAAACBAAAAgQM3MjD/NzCxAZmaWQM3MzL3NzMw/MzNTwM3MjD/NzIw/MzMTQM3MTECamRk/ZmYmQDMz87/NzAxAzczMvpqZmb7wARAADAAAAFkAAAARAAAAAAECAwRjYXBhY2l0eSBvdmVyZmxvdwAAJAMQAFAAAAAcAAAABQAAADAxMjM0NTY3ODlhYmNkZWYAAAAABAAAAAQAAAAFAAAALStOYU5pbmYwMC4wZTBhc3NlcnRpb24gZmFpbGVkOiBidWYubGVuKCkgPj0gbWF4bGVuAHUDEABXAAAAiwIAAA0AAACaARAAVQAAAC4AAAAJAAAAYXNzZXJ0aW9uIGZhaWxlZDogb3RoZXIgPiAwYXNzZXJ0aW9uIGZhaWxlZDogbm9ib3Jyb3cAAAC/AhAAUgAAAIQBAAABAAAAYXNzZXJ0aW9uIGZhaWxlZDogZGlnaXRzIDwgNDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwPT0wMDAxMDIwMzA0MDUwNjA3MDgwOTEwMTExMjEzMTQxNTE2MTcxODE5MjAyMTIyMjMyNDI1MjYyNzI4MjkzMDMxMzIzMzM0MzUzNjM3MzgzOTQwNDE0MjQzNDQ0NTQ2NDc0ODQ5NTA1MTUyNTM1NDU1NTY1NzU4NTk2MDYxNjI2MzY0NjU2NjY3Njg2OTcwNzE3MjczNzQ3NTc2Nzc3ODc5ODA4MTgyODM4NDg1ODY4Nzg4ODk5MDkxOTI5Mzk0OTU5Njk3OTg5OS5hdHRlbXB0IHRvIGRpdmlkZSBieSB6ZXJvYXNzZXJ0aW9uIGZhaWxlZDogIWJ1Zi5pc19lbXB0eSgpAAB1AxAAVwAAALcAAAAFAAAAYXNzZXJ0aW9uIGZhaWxlZDogYnVmWzBdID4gYicwJwB1AxAAVwAAALgAAAAFAAAAdQMQAFcAAAAJAQAABQAAAHUDEABXAAAACgEAAAUAAABlZS0A30UaPQPPGubB+8z+AAAAAMrGmscX/nCr3PvU/gAAAABP3Ly+/LF3//b73P4AAAAADNZrQe+RVr4R/OT+AAAAADz8f5CtH9CNLPzs/gAAAACDmlUxKFxR00b89P4AAAAAtcmmrY+scZ1h/Pz+AAAAAMuL7iN3Ipzqe/wE/wAAAABtU3hAkUnMrpb8DP8AAAAAV862XXkSPIKx/BT/AAAAADdW+002lBDCy/wc/wAAAABPmEg4b+qWkOb8JP8AAAAAxzqCJcuFdNcA/Sz/AAAAAPSXv5fNz4agG/00/wAAAADlrCoXmAo07zX9PP8AAAAAjrI1KvtnOLJQ/UT/AAAAADs/xtLf1MiEa/1M/wAAAAC6zdMaJ0TdxYX9VP8AAAAAlsklu86fa5Og/Vz/AAAAAISlYn0kbKzbuv1k/wAAAAD22l8NWGaro9X9bP8AAAAAJvHD3pP44vPv/XT/AAAAALiA/6qorbW1Cv58/wAAAACLSnxsBV9ihyX+hP8AAAAAUzDBNGD/vMk//oz/AAAAAFUmupGMhU6WWv6U/wAAAAC9filwJHf533T+nP8AAAAAj7jluJ+936aP/qT/AAAAAJR9dIjPX6n4qf6s/wAAAADPm6iPk3BEucT+tP8AAAAAaxUPv/jwCIrf/rz/AAAAALYxMWVVJbDN+f7E/wAAAACsf3vQxuI/mRT/zP8AAAAABjsrKsQQXOQu/9T/AAAAANOSc2mZJCSqSf/c/wAAAAAOygCD8rWH/WP/5P8AAAAA6xoRkmQI5bx+/+z/AAAAAMyIUG8JzLyMmf/0/wAAAAAsZRniWBe30bP//P8AAAAAAAAAAAAAQJzO/wQAAAAAAAAAAAAQpdTo6P8MAAAAAAAAAGKsxet4rQMAFAAAAAAAhAmU+Hg5P4EeABwAAAAAALMVB8l7zpfAOAAkAAAAAABwXOp7zjJ+j1MALAAAAAAAaIDpq6Q40tVtADQAAAAAAEUimhcmJ0+fiAA8AAAAAAAn+8TUMaJj7aIARAAAAAAAqK3IjDhl3rC9AEwAAAAAANtlqxqOCMeD2ABUAAAAAACaHXFC+R1dxPIAXAAAAAAAWOcbpixpTZINAWQAAAAAAOqNcBpk7gHaJwFsAAAAAABKd++amaNtokIBdAAAAAAAhWt9tHt4CfJcAXwAAAAAAHcY3Xmh5FS0dwGEAAAAAADCxZtbkoZbhpIBjAAAAAAAPV2WyMVTNcisAZQAAAAAALOgl/pctCqVxwGcAAAAAADjX6CZvZ9G3uEBpAAAAAAAJYw52zTCm6X8AawAAAAAAFyfmKNymsb2FgK0AAAAAADOvulUU7/ctzECvAAAAAAA4kEi8hfz/IhMAsQAAAAAAKV4XNObziDMZgLMAAAAAADfUyF781oWmIEC1AAAAAAAOjAfl9y1oOKbAtwAAAAAAJaz41xT0dmotgLkAAAAAAA8RKek2Xyb+9AC7AAAAAAAEESkp0xMdrvrAvQAAAAAABqcQLbvjquLBgP8AAAAAAAshFemEO8f0CADBAEAAAAAKTGR6eWkEJs7AwwBAAAAAJ0MnKH7mxDnVQMUAQAAAAAp9Dti2SAorHADHAEAAAAAhc+nel5LRICLAyQBAAAAAC3drANA5CG/pQMsAQAAAACP/0ReL5xnjsADNAEAAAAAQbiMnJ0XM9TaAzwBAAAAAKkb47SS2xme9QNEAQAAAADZd9+6br+W6w8ETAEAAAAAYXNzZXJ0aW9uIGZhaWxlZDogZC5tYW50ID4gMDcBEABiAAAA3gEAAAUAAAA3ARAAYgAAAH8AAAAVAAAANwEQAGIAAAA1AgAAEQAAADcBEABiAAAAbgIAAAkAAAA3ARAAYgAAAKsAAAAFAAAAYXNzZXJ0aW9uIGZhaWxlZDogZC5taW51cyA+IDAAAAA3ARAAYgAAAKwAAAAFAAAAYXNzZXJ0aW9uIGZhaWxlZDogZC5wbHVzID4gMDcBEABiAAAArQAAAAUAAABhc3NlcnRpb24gZmFpbGVkOiBkLm1hbnQgKyBkLnBsdXMgPCAoMSA8PCA2MSkAAAA3ARAAYgAAALEAAAAFAAAANwEQAGIAAAAMAQAAEQAAADcBEABiAAAAQgEAAAkAAABhc3NlcnRpb24gZmFpbGVkOiBkLm1hbnQuY2hlY2tlZF9zdWIoZC5taW51cykuaXNfc29tZSgpADcBEABiAAAArwAAAAUAAABhc3NlcnRpb24gZmFpbGVkOiBkLm1hbnQuY2hlY2tlZF9hZGQoZC5wbHVzKS5pc19zb21lKCkAADcBEABiAAAArgAAAAUAAABbAhAAYwAAAHQBAAAkAAAAWwIQAGMAAAB5AQAALwAAAFsCEABjAAAAhgEAABIAAABbAhAAYwAAAGgBAAANAAAAWwIQAGMAAABOAQAAIgAAAFsCEABjAAAAeAAAAAUAAABbAhAAYwAAAHkAAAAFAAAAWwIQAGMAAAB6AAAABQAAAFsCEABjAAAAxAAAAAkAAABbAhAAYwAAAP0AAAANAAAAWwIQAGMAAAAEAQAAEgAAAFsCEABjAAAAfAAAAAUAAABbAhAAYwAAAHsAAAAFAAAAAQAAAAoAAABkAAAA6AMAABAnAACghgEAQEIPAICWmAAA4fUFAMqaO8Fv8oYjAAAAge+shVtBbS3uBAAAAR9qv2TtOG7tl6fa9Pk/6QNPGAABPpUuCZnfA/04FQ8v5HQj7PXP0wjcBMTasM28GX8zpgMmH+lOAgAAAXwumFuH075yn9nYhy8VEsZQ3mtwbkrPD9iV1W5xsiawZsatJDYVHVrTQjwOVP9jwHNVzBfv+WXyKLxV98fcgNztbvTO79xf91MFADcBEABiAAAA8QIAACYAAAA3ARAAYgAAAOUCAAAmAAAANwEQAGIAAADOAgAAJgAAADB4MDEyMzQ1Njc4OUFCQ0RFRgAABgAAAAwAAAAEAAAABwAAAAgAAAAJAAAAAAAAAAgAAAAEAAAACgAAAAsAAAAMAAAADQAAAA4AAAAQAAAABAAAAA8AAAAQAAAAEQAAABIAAABc9ulf3AL2ufHBcGzyYcEkOzdNSoIQRQnDpWHRPyA6j2Fzc2VydGlvbiBmYWlsZWQ6IHBzaXplID49IHNpemUgKyBtaW5fb3ZlcmhlYWQAAM0DEAAqAAAA6QQAAAkAAABhc3NlcnRpb24gZmFpbGVkOiBwc2l6ZSA8PSBzaXplICsgbWF4X292ZXJoZWFkAADNAxAAKgAAAO8EAAANAAAAzQMQACoAAABNBQAAHgAAAHJ3bG9jayBvdmVyZmxvd2VkIHJlYWQgbG9ja3P9ARAAXQAAABgAAAAsAAAAAAAAAAgAAAAEAAAAEwAAAAYAAAAMAAAABAAAABQAAAALBQYBAQAAADQFEABgBRAAdAUQAIwFEACQBRAACwUGEAsAAAAAAAA/AAAAvwMAAAAEAAAABAAAAAYAAACD+aIARE5uAPwpFQDRVycA3TT1AGLbwAA8mZUAQZBDAGNR/gC73qsAt2HFADpuJADSTUIASQbgAAnqLgAcktEA6x3+ACmxHADoPqcA9TWCAES7LgCc6YQAtCZwAEF+XwDWkTkAU4M5AJz0OQCLX4QAKPm9APgfOwDe/5cAD5gFABEv7wAKWosAbR9tAM9+NgAJyycARk+3AJ5mPwAt6l8Auid1AOXrxwA9e/EA9zkHAJJSigD7a+oAH7FfAAhdjQAwA1YAe/xGAPCrawAgvM8ANvSaAOOpHQBeYZEACBvmAIWZZQCgFF8AjUBoAIDY/wAnc00ABgYxAMpWFQDJqHMAe+JgAGuMwAAAAABA+yH5PwAAAAAtRHQ+AAAAgJhG+DwAAABgUcx4OwAAAICDG/A5AAAAQCAlejgAAACAIoLjNgAAAAAd82k1zTt/Zp6g5j+HAetzFKHnP9ugKkLlrOg/kPCjgpHE6T+t01qZn+jqP5xShd2bGew/h6T73BhY7T/akKSir6TuPwAAAAAAAPA/D4n5bFi18D97UX08uHLxPzhidW56OPI/FbcxCv4G8z8iNBJMpt7zPycqNtXav/Q/KVRI3Qer9T8AAIA/AADAPwAAAADcz9E1AAAAAADAFT8AQdiowAALzAMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQD/DwAA", Ei, Di, Oi = !1;
function ki() {
	return Di ??= (async () => {
		let e = Uint8Array.from(atob(Ti.slice(Ti.indexOf(",") + 1)), (e) => e.charCodeAt(0));
		Ei = await WebAssembly.compile(e);
	})().catch((e) => {
		Di = void 0, Oi || (Oi = !0, console.warn("Rackloose DSP unavailable, so Ladder filters and Analog drums play Digital:", e));
	}), Di;
}
var Ai = () => Ei, ji = [
	Si,
	Ci,
	wi
].map((e) => ({
	source: e,
	contexts: /* @__PURE__ */ new WeakMap()
}));
async function Mi(e) {
	await Promise.all([ki(), ...ji.map(({ source: t, contexts: n }) => {
		let r = n.get(e);
		if (!r) {
			let i = URL.createObjectURL(new Blob([t], { type: "text/javascript" }));
			r = e.audioWorklet.addModule(i).finally(() => URL.revokeObjectURL(i)), n.set(e, r), r.catch(() => n.delete(e));
		}
		return r;
	})]);
}
function Ni(e, t, n, r) {
	let i = 0, a = !1, o, s = /* @__PURE__ */ new Map(), c = (e) => {
		for (let t of s.values()) clearTimeout(t.timer), e ? t.reject(e) : t.resolve();
		s.clear();
	};
	return e.port.onmessage = ({ data: e }) => {
		if (a) return;
		typeof e.reduction == "number" && Number.isFinite(e.reduction) && n?.(e.reduction);
		let t = e.id === void 0 ? void 0 : s.get(e.id);
		t && (clearTimeout(t.timer), t.resolve(), s.delete(e.id));
	}, e.onprocessorerror = () => {
		a || (o = /* @__PURE__ */ Error(`${t} audio processor failed. Reload the patch to retry.`), c(o), r?.(o));
	}, {
		flush() {
			return o ? Promise.reject(o) : a ? Promise.resolve() : new Promise((n, r) => {
				let a = ++i, o = setTimeout(() => {
					s.delete(a), r(/* @__PURE__ */ Error(`${t} did not finish preparing audio. Try again.`));
				}, 5e3);
				s.set(a, {
					resolve: n,
					reject: r,
					timer: o
				}), e.port.postMessage({
					type: "flush",
					id: a
				});
			});
		},
		dispose() {
			a || (a = !0, e.port.postMessage({ type: "dispose" }), c(), e.port.onmessage = null, e.onprocessorerror = null, e.port.close());
		}
	};
}
// src/audio/drumEngine.ts
var Pi = {
	boom: 0,
	punch: 1,
	orbit: 2,
	strike: 3,
	forge: 4
}, Fi = {
	boom: [["open", "hat"]],
	punch: [["open", "hat"]],
	strike: [["open", "hat"]],
	forge: [["open", "hat"], ["open", "pedal"]]
}, Ii = (e) => 2 ** (e / 12), Li = 8;
function Ri(e, t, n, r) {
	let i = zi(e, t, n, r);
	return Array.from({ length: Li }, (e, r) => r === 7 ? n[`${t}Pan`] ?? 0 : i[r] ?? 0);
}
function zi(e, t, n, r) {
	if (e === "orbit") return [
		Ii(n.pitch + n[`${t}Tune`]),
		n[`${t}Decay`],
		Math.min(1, n[`${t}Level`]),
		n[`${t}Tone`]
	];
	if (r) {
		let e = Ii(n[`${t}Tune`]), i = r.sample(t).length / (r.rate * e), a = Math.min(2e4, (r.tone ?? ((e) => 700 * 20 ** e))(n[`${t}Tone`]));
		return [
			r.rate * e,
			n[`${t}Decay`],
			a,
			n[`${t}Level`] * (r.peak ?? 1.6),
			Math.min(i, n[`${t}Decay`] * 2) + .01
		];
	}
	return t === "kick" ? e === "punch" ? [
		n.kickTune,
		n.kickDecay,
		n.kickClick
	] : [n.kickTune, n.kickDecay] : t === "snare" ? [
		n.snareTone,
		n.snappy,
		Ii(n.snareTune),
		n.snareDecay
	] : t === "rim" ? [Ii(n.rimTune), n.rimDecay] : t === "clap" ? [Ot(n.clapTone, 3), n.clapDecay] : t === "lowTom" ? [95 * Ii(n.tomTune), n.tomDecay] : t === "highTom" ? [145 * Ii(n.highTomTune), n.highTomDecay * .85] : t === "bell" ? [Ii(n.bellTune), n.bellDecay] : [n[`${t}Decay`], Ot(n[`${t}Tone`], 2)];
}
function Bi(e, t, n) {
	let r = n[`${t}Level`] ?? 1;
	return e === "boom" || e === "punch" ? r : e === "orbit" ? Math.max(1, r) : 1;
}
function Vi(e, t, n, { keep: r, onError: i }) {
	let a = Ai();
	if (!a) return null;
	let o = Z[t].drum.voices.map((e) => e.id), s = t === "strike" ? ai : t === "forge" ? bi : void 0, c = (Fi[t] ?? []).map(([e, t]) => [o.indexOf(e), o.indexOf(t)]), l;
	try {
		l = r(new AudioWorkletNode(e, "rackloose-drums-v1", {
			numberOfInputs: 0,
			numberOfOutputs: 1,
			outputChannelCount: [2],
			processorOptions: {
				module: a,
				kit: Pi[t],
				chokes: c
			}
		}));
	} catch (e) {
		return console.warn(`${Z[t].name} Analog engine unavailable, so it plays Digital:`, e), null;
	}
	l.connect(n);
	let u = Ni(l, Z[t].name, void 0, i), d = /* @__PURE__ */ new Set();
	return {
		trigger(e, n, r, i = 1) {
			let a = o.indexOf(e);
			a < 0 || (s && !d.has(e) && (d.add(e), l.port.postMessage({
				type: "sample",
				voice: a,
				pcm: s.sample(e)
			})), l.port.postMessage({
				type: "hit",
				time: n,
				voice: a,
				velocity: i * Bi(t, e, r),
				params: Ri(t, e, r, s)
			}));
		},
		cancelScheduled(e) {
			l.port.postMessage({
				type: "cancel",
				time: e
			});
		},
		dispose: u.dispose,
		flush: u.flush
	};
}
function Hi(e, t, n, r, i) {
	let a, o, s = i?.input ?? n, c = () => a ??= i ? i.classic() : t === "strike" ? oi(e, s) : ti(e, t, s, r), l = () => o === void 0 ? o = Vi(e, t, s, r) : o;
	return {
		trigger(e, t, n, r) {
			(n.engine === 1 ? l() ?? c() : c()).trigger(e, t, n, r);
		},
		cancelScheduled(e) {
			a?.cancelScheduled(e), o?.cancelScheduled(e);
		},
		dispose() {
			a?.dispose(), o?.dispose(), i?.dispose();
		},
		flush: () => o?.flush() ?? Promise.resolve()
	};
}
// src/audio/envelope.ts
function Ui(e) {
	let t = [], n = (e) => {
		let n = t.findIndex(([t]) => t > e);
		if (n === 0 || !t.length) return 0;
		if (n < 0) return t[t.length - 1][1];
		let [r, i] = t[n - 1], [a, o] = t[n];
		return i + (o - i) * (e - r) / (a - r);
	}, r = (r, ...i) => {
		let a = n(r);
		Qr(e, r), e.setValueAtTime(a, r);
		for (let [t, n] of i) e.linearRampToValueAtTime(n, t);
		t = [
			...t.filter(([e]) => e < r).slice(-16),
			[r, a],
			...i
		];
	};
	return {
		on(e, t, n, i, a) {
			r(e, [e + n, t], [e + n + i, t * a]);
		},
		off(e, t) {
			r(e, [e + t, 0]);
		}
	};
}
// src/audio/ladder.ts
function Wi(e, { keep: t, onError: n, name: r }, i, a, o = []) {
	let s = t(e.createGain());
	s.gain.value = 0, s.connect(a);
	let c, l, u = !1, d = () => {
		let a = Ai();
		if (c || u || !a) return !!c;
		try {
			c = t(new AudioWorkletNode(e, "rackloose-ladder-v1", {
				numberOfInputs: 1,
				numberOfOutputs: 1,
				outputChannelCount: [1],
				processorOptions: { module: a }
			}));
		} catch (e) {
			return u = !0, console.warn(`${r} Ladder filter unavailable, so it plays Digital:`, e), !1;
		}
		for (let e of o) e.connect(c.parameters.get("detune"));
		return i.connect(c).connect(s), l = Ni(c, r, void 0, n), !0;
	};
	return {
		apply(t, n, r) {
			let i = t && d();
			if (r(s.gain, i ? n.level : 0), c) {
				let t = (e) => c.parameters.get(e);
				r(t("cutoff"), n.cutoff), r(t("resonance"), n.resonance), r(t("drive"), n.drive), r(t("detune"), n.detune ?? 0);
				let i = t("mode"), a = e.currentTime;
				i.cancelScheduledValues(a), i.setValueAtTime(n.mode ?? 0, a);
			}
			return i;
		},
		flush: () => l?.flush() ?? Promise.resolve(),
		dispose: () => l?.dispose()
	};
}
// src/audio/monarch.ts
var Gi = [
	"sine",
	"triangle",
	"sawtooth",
	"square"
], Ki = 1.4, qi = (e) => {
	let t = 1 + e * 5;
	return t / Math.tanh(t) / Math.sqrt(8 ** e);
}, Ji = 1500, Yi = 2400, Xi = 5, Zi = 261.625565;
function Qi(e, t, { keep: n, source: r, onError: i }) {
	let a = (t = 1) => {
		let r = n(e.createGain());
		return r.gain.value = t, r;
	}, o = a(), s = a(), c = a(), l = n(e.createWaveShaper()), u = n(e.createBiquadFilter());
	u.type = "lowpass", u.Q.value = .5, o.connect(u);
	let d = [n(e.createBiquadFilter()), n(e.createBiquadFilter())], f = a(0), p = a(), m = a(.5), h = a(), g = a(), _ = li(e, r, (e) => e * e), v = a(0), y = a(), b = a(), x = a(), S = a(0), C = a(0), w = a(0), T = a(0);
	_.bend.connect(v), v.connect(y), _.mod.connect(C.gain), x.connect(C), S.connect(C), C.connect(w), C.connect(T), c.connect(l).connect(d[0]).connect(d[1]).connect(g).connect(f).connect(p);
	let E = Wi(e, {
		keep: n,
		onError: i,
		name: "MONARCH"
	}, c, f, [
		s,
		h,
		m,
		T
	]), D = r(e.createConstantSource()), O = r(e.createConstantSource());
	D.offset.value = 0, O.offset.value = 0, D.connect(f.gain), O.connect(h), u.connect(m);
	for (let e of d) e.type = "lowpass", s.connect(e.detune), h.connect(e.detune), m.connect(e.detune), T.connect(e.detune);
	let ee = [
		1,
		2,
		3
	].map((t) => {
		let n = r(e.createOscillator()), i = a();
		return n.frequency.value = Zi, n.connect(i).connect(c), t < 3 ? (u.connect(n.detune), v.connect(n.detune), w.connect(n.detune)) : (u.connect(b).connect(n.detune), y.connect(n.detune), n.connect(x)), {
			osc: n,
			level: i
		};
	}), k = r(e.createBufferSource()), te = a(0);
	k.buffer = t, k.loop = !0, k.connect(te).connect(c), k.connect(S);
	let A = {}, j = !1, M = -1, N = (t, n) => {
		j ? t.setTargetAtTime(n, e.currentTime, .008) : t.value = n;
	}, P = [[Ui(D.offset), "amp"], [Ui(O.offset), "filter"]];
	return {
		pitch: o,
		cv: s,
		output: p,
		apply(t) {
			A = t;
			let n = t.osc3Mode === 1;
			ee.forEach(({ osc: e, level: n }, r) => {
				let i = `osc${r + 1}`;
				e.type = Gi[t[`${i}Wave`]], N(e.detune, t[`${i}Octave`] * 1200 + t[`${i}Detune`]), N(n.gain, t[`${i}Level`] * .23);
			}), N(ee[2].osc.frequency, n ? Xi : Zi), N(b.gain, +!n), N(y.gain, +!n), N(v.gain, t.bendRange * 100), N(x.gain, 1 - t.modMix), N(S.gain, t.modMix), N(w.gain, t.modDest === 1 ? 0 : Ji), N(T.gain, t.modDest === 0 ? 0 : Yi), N(te.gain, t.noise * .15), N(p.gain, t.level), N(u.frequency, t.glide ? Math.min(e.sampleRate * .45, 1 / (2 * Math.PI * t.glide)) : e.sampleRate * .45), N(m.gain, t.tracking), N(h.gain, t.envAmount * 4800), d.forEach((e, n) => {
				N(e.frequency, t.cutoff), N(e.Q, n === 0 ? .707 + t.resonance * 5 : .707);
			});
			let r = E.apply(t.filterModel === 1, {
				cutoff: t.cutoff,
				resonance: t.resonance,
				drive: t.drive,
				level: Ki * qi(t.drive)
			}, N);
			if (N(g.gain, +!r), M !== t.drive) {
				M = t.drive;
				let e = 1 + t.drive * 5;
				l.curve = Float32Array.from({ length: 2049 }, (t, n) => Math.tanh(e * (n / 1024 - 1)) / Math.tanh(e)), l.oversample = "2x";
			}
			j = !0;
		},
		noteOn(e, t) {
			for (let [n, r] of P) n.on(t, e, A[`${r}Attack`], A[`${r}Decay`], A[`${r}Sustain`]);
		},
		noteOff(e) {
			for (let [t, n] of P) t.off(e, A[`${n}Release`]);
		},
		wheel: _.move,
		flush: E.flush,
		dispose: E.dispose
	};
}
// src/audio/oracle.ts
var $i = .25, ea = .98, ta = [
	[
		4,
		-3,
		70
	],
	[
		-5,
		2,
		-40
	],
	[
		1,
		6,
		110
	],
	[
		-2,
		-6,
		-90
	],
	[
		6,
		1,
		20
	]
], na = 261.625565;
function ra(e, t, { keep: n, source: r, onError: i }) {
	let a = (t = 1) => {
		let r = n(e.createGain());
		return r.gain.value = t, r;
	}, o = (t = 0) => {
		let n = r(e.createConstantSource());
		return n.offset.value = t, n;
	}, s = (e) => Float32Array.from({ length: 1025 }, (t, n) => Math.tanh(e * (n / 512 - 1)) / Math.tanh(e)), c = (t, r, i) => {
		let a = n(e.createWaveShaper());
		return a.curve = s(24), a.oversample = "4x", t.connect(a), r.connect(a), ui(a, i);
	}, l = a(), u = a(), d = a(.5), f = a(), p = n(e.createBiquadFilter());
	p.type = "highpass", p.frequency.value = 20, p.Q.value = -3.01, d.connect(p).connect(f);
	let m = r(e.createBufferSource()), h = a(0);
	m.buffer = t, m.loop = !0, m.connect(h);
	let g = li(e, r), _ = a(0), v = a(0), y = r(e.createOscillator()), b = a(), x = a(0), S = a(0), C = a(0), w = a(0), T = a(0);
	g.bend.connect(_), g.mod.connect(v).connect(S.gain), y.connect(b).connect(S), m.connect(x).connect(S), S.connect(C), S.connect(w), S.connect(T);
	let E = ta.map((t) => {
		let s = o(), f = o(), p = o(), m = o(), g = o(), v = r(e.createOscillator()), y = r(e.createOscillator());
		v.type = "sawtooth", v.frequency.value = na, y.frequency.value = na;
		let b = a(), x = a(0), S = a(), E = a(), D = a(), O = a(0), ee = a(), k = a();
		v.connect(b).connect(S), x.connect(S);
		let te = c(v, m, x);
		y.connect(D).connect(ee), O.connect(ee);
		let A = c(y, g, O), j = a(), M = a(0), N = a(), P = [n(e.createBiquadFilter()), n(e.createBiquadFilter())];
		S.connect(E).connect(j), ee.connect(k).connect(j), h.connect(j), j.connect(P[0]).connect(P[1]).connect(N).connect(M).connect(d), f.connect(M.gain);
		let ne = a(), re = a(), ie = a(0), ae = a(0), oe = a(), se = a(0), F = a(0);
		p.connect(re), p.connect(ie).connect(oe), ee.connect(ae).connect(oe), oe.connect(se).connect(v.detune), oe.connect(F);
		for (let e of [v.detune, y.detune]) s.connect(e), l.connect(e), C.connect(e), _.connect(e);
		s.connect(ne), l.connect(ne), w.connect(m.offset), w.connect(g.offset);
		let ce = [
			ne,
			re,
			F,
			u,
			T
		];
		for (let e of P) {
			e.type = "lowpass";
			for (let t of ce) t.connect(e.detune);
		}
		return {
			drift: t,
			note: s,
			amp: f,
			filterEnv: p,
			a: v,
			b: y,
			aWidth: m,
			bWidth: g,
			aComparator: te,
			bComparator: A,
			aSaw: b,
			aPulse: x,
			aLevel: E,
			bWave: D,
			bPulse: O,
			bLevel: k,
			filters: P,
			classic: N,
			ladder: Wi(e, {
				keep: n,
				onError: i,
				name: "ORACLE"
			}, j, M, ce),
			tracking: ne,
			envDepth: re,
			polyEnv: ie,
			polyB: ae,
			polyA: se,
			polyFilter: F,
			pitched: !1
		};
	}), D = new di(E.length), O = {}, ee = !1, k = (t, n) => {
		ee ? t.setTargetAtTime(n, e.currentTime, .008) : t.value = n;
	}, te = (e, t, n, r, i) => {
		let a = Math.max(.001, O[`${t}Attack`]);
		Qr(e, r), i && e.setValueAtTime(0, r), e.linearRampToValueAtTime(n, r + a), e.setTargetAtTime(n * O[`${t}Sustain`], r + a, Math.max(.001, O[`${t}Decay`]) / 3);
	}, A = (e, t, n) => {
		Qr(e, n), e.setTargetAtTime(0, n, Math.max(.001, O[`${t}Release`]) / 4);
	}, j = (e, t) => {
		for (let { index: n, pending: r } of D.release(e, O.ampRelease, t)) {
			let t = E[n];
			r && Qr(t.note.offset, e), A(t.amp.offset, "amp", e), A(t.filterEnv.offset, "filter", e);
		}
	};
	return {
		pitch: l,
		cv: u,
		output: f,
		apply(e) {
			O = e;
			let t = e.vintage, n = e.aShape, r = e.bShape, i = e.polyDest, a = e.lfoDest;
			for (let a of E) {
				k(a.a.detune, e.aOctave * 1200 + a.drift[0] * t), k(a.b.detune, e.bOctave * 1200 + e.bFine + a.drift[1] * t), a.b.type = r === 1 ? "triangle" : "sawtooth", k(a.aSaw.gain, n === 1 ? 0 : n === 2 ? .7 : 1), k(a.aPulse.gain, n === 0 ? 0 : n === 2 ? .7 : 1), k(a.bWave.gain, r === 2 ? 0 : 1), k(a.bPulse.gain, +(r === 2)), a.aComparator(n !== 0, !ee), a.bComparator(r === 2, !ee), k(a.aWidth.offset, 2 * e.aWidth - 1), k(a.bWidth.offset, 2 * e.bWidth - 1), k(a.aLevel.gain, e.aLevel * .25), k(a.bLevel.gain, e.bLevel * .25), k(a.polyEnv.gain, e.polyEnv * 3600), k(a.polyB.gain, e.polyOscB * 2400), k(a.polyA.gain, i === 1 ? 0 : 1), k(a.polyFilter.gain, i === 0 ? 0 : 1), k(a.tracking.gain, e.tracking), k(a.envDepth.gain, e.envAmount * 6e3), a.filters.forEach((n, r) => {
					k(n.frequency, e.cutoff), k(n.detune, a.drift[2] * t), k(n.Q, r === 0 ? -3.01 + e.resonance * 20 : -3.01);
				});
				let o = a.ladder.apply(e.filterModel === 1, {
					cutoff: e.cutoff,
					resonance: e.resonance,
					drive: $i,
					level: ea,
					detune: a.drift[2] * t
				}, k);
				k(a.classic.gain, +!o);
			}
			y.type = [
				"triangle",
				"sawtooth",
				"square"
			][e.lfoShape], k(y.frequency, e.lfoRate), k(S.gain, e.lfoAmount), k(v.gain, 1 - e.lfoAmount), k(b.gain, 1 - e.lfoMix), k(x.gain, e.lfoMix), k(C.gain, a === 0 ? 300 : 0), k(w.gain, a === 1 ? .9 : 0), k(T.gain, a === 2 ? 2400 : 0), k(_.gain, e.bendRange * 100), k(h.gain, e.noise * .2), k(f.gain, e.level), ee = !0;
		},
		noteOn(e, t, n, r) {
			j(n, r);
			let i = /* @__PURE__ */ new Set();
			for (let a of (lt[O.chord]?.[1] ?? [0]).slice(0, E.length)) {
				let o = D.allocate(n, i), s = E[o], c = (e + a - 60) * 100;
				i.add(o), D.start(o, r, n), Qr(s.note.offset, n);
				let l = !s.pitched;
				O.glide > 0 && !l ? s.note.offset.setTargetAtTime(c, n, O.glide / 3) : s.note.offset.setValueAtTime(c, n), s.pitched = !0, te(s.amp.offset, "amp", t, n, l), te(s.filterEnv.offset, "filter", t, n, l);
			}
		},
		noteOff: j,
		wheel: g.move,
		flush: () => Promise.all(E.map((e) => e.ladder.flush())).then(() => void 0),
		dispose: () => {
			for (let e of E) e.ladder.dispose();
		}
	};
}
// src/audio/aurora.ts
var ia = .25, aa = 1.22, oa = 2400, sa = 120;
function ca(e, { keep: t, source: n, onError: r }) {
	let i = (n = 1) => {
		let r = t(e.createGain());
		return r.gain.value = n, r;
	}, a = () => {
		let t = n(e.createConstantSource());
		return t.offset.value = 0, t;
	}, o = i(), s = i(), c = i(), l = i(.22);
	l.connect(c);
	let u = n(e.createOscillator()), d = i(0), f = i(0), p = i(0);
	u.connect(d), u.connect(f), u.connect(p);
	let m = li(e, n), h = i(0), g = i(0), _ = i(0), v = i(0);
	m.bend.connect(h), m.bend.connect(g), m.mod.connect(_.gain), u.connect(_).connect(v);
	let y = Float32Array.from({ length: 2049 }, (e, t) => Math.tanh(24 * (t / 1024 - 1))), b = Array.from({ length: 8 }, (c, u) => {
		let m = a(), _ = a(), b = a(), x = i(), S = i(0), C = i(), w = i(), T = i(0), E = [0, 1].map(() => {
			let r = n(e.createOscillator()), s = a(), c = i(), l = i(0), u = i(), p = i();
			r.frequency.value = 261.625565;
			let g = t(e.createWaveShaper());
			return g.curve = y, g.oversample = "4x", r.connect(c).connect(p), r.connect(g), s.connect(g), l.connect(p), p.connect(u).connect(x), m.connect(r.detune), o.connect(r.detune), d.connect(r.detune), f.connect(s.offset), h.connect(r.detune), v.connect(r.detune), {
				osc: r,
				width: s,
				raw: c,
				pulse: l,
				level: u,
				out: p,
				pulsed: ui(g, l)
			};
		});
		E[1].out.connect(T).connect(E[0].osc.detune);
		let D = t(e.createBiquadFilter()), O = [t(e.createBiquadFilter()), t(e.createBiquadFilter())];
		D.type = "highpass", D.Q.value = -3.01;
		let ee = i(0), k = i(1);
		x.connect(D).connect(O[0]), O[0].connect(ee).connect(S), O[0].connect(O[1]).connect(k).connect(S), _.connect(S.gain), S.connect(l), m.connect(C), o.connect(C), b.connect(w);
		for (let e of O) e.type = "lowpass", C.connect(e.detune), w.connect(e.detune), s.connect(e.detune), p.connect(e.detune), g.connect(e.detune);
		return {
			note: m,
			oscillators: E,
			hpf: D,
			filters: O,
			twoPole: ee,
			fourPole: k,
			ladder: Wi(e, {
				keep: t,
				onError: r,
				name: "AURORA"
			}, D, S, [
				C,
				w,
				s,
				p,
				g
			]),
			tracking: C,
			amount: w,
			cross: T,
			amp: Ui(_.offset),
			env: Ui(b.offset),
			pitched: !1,
			drift: [
				3,
				-4,
				1,
				5,
				-2,
				4,
				-5,
				2
			][u]
		};
	}), x = new di(8), S = {}, C = !1, w = (t, n) => {
		C ? t.setTargetAtTime(n, e.currentTime, .008) : t.value = n;
	}, T = (e, t) => {
		for (let { index: n, pending: r } of x.release(e, S.ampRelease, t)) {
			let t = b[n];
			r && Qr(t.note.offset, e), t.amp.off(e, S.ampRelease), t.env.off(e, S.filterRelease);
		}
	};
	return {
		pitch: o,
		cv: s,
		output: c,
		apply(e) {
			S = e;
			for (let t of b) {
				t.oscillators.forEach((n, r) => {
					let i = `osc${r + 1}`, a = e[`${i}Wave`];
					n.osc.type = [
						"sawtooth",
						"sawtooth",
						"triangle",
						"sine"
					][a], w(n.osc.detune, e[`${i}Octave`] * 1200 + e[`${i}Detune`] + t.drift * e.vintage * (r ? -.7 : 1)), w(n.width.offset, 2 * e[`${i}Width`] - 1), w(n.raw.gain, a === 1 ? 0 : 1), w(n.pulse.gain, +(a === 1)), n.pulsed(a === 1, !C), w(n.level.gain, r ? e.blend : 1 - e.blend);
				}), w(t.cross.gain, e.crossMod * 1800), w(t.hpf.frequency, e.hpf);
				let n = t.ladder.apply(e.filterModel === 1, {
					cutoff: e.cutoff,
					resonance: e.resonance,
					drive: ia,
					level: aa,
					mode: +(e.slope === 0),
					detune: t.drift * e.vintage * 9
				}, w);
				w(t.twoPole.gain, +(!n && e.slope === 0)), w(t.fourPole.gain, +(!n && e.slope === 1)), t.filters.forEach((n, r) => {
					w(n.frequency, e.cutoff), w(n.Q, r ? -3.01 : -3.01 + e.resonance * 17), w(n.detune, t.drift * e.vintage * 9);
				}), w(t.tracking.gain, e.tracking), w(t.amount.gain, e.envAmount * 6e3);
			}
			u.type = [
				"triangle",
				"sine",
				"square"
			][e.lfoShape], w(u.frequency, e.lfoRate), w(d.gain, e.lfoPitch * 100), w(f.gain, e.lfoWidth * .8), w(p.gain, e.lfoFilter * 2400), w(c.gain, e.level), w(h.gain, e.bendRange * 100), w(g.gain, e.bendFilter * oa), w(v.gain, e.leverLfo * sa), C = !0;
		},
		noteOn(e, t, n, r) {
			T(n, r);
			let i = /* @__PURE__ */ new Set();
			for (let a of lt[S.chord]?.[1] ?? [0]) {
				let o = x.allocate(n, i), s = b[o], c = (e + a - 60) * 100;
				i.add(o), x.start(o, r, n), Qr(s.note.offset, n), S.glide && s.pitched ? s.note.offset.setTargetAtTime(c, n, S.glide / 3) : s.note.offset.setValueAtTime(c, n), s.pitched = !0, s.amp.on(n, t, S.ampAttack, S.ampDecay, S.ampSustain), s.env.on(n, 1, S.filterAttack, S.filterDecay, S.filterSustain);
			}
		},
		noteOff: T,
		wheel: m.move,
		flush: () => Promise.all(b.map((e) => e.ladder.flush())).then(() => void 0),
		dispose: () => {
			for (let e of b) e.ladder.dispose();
		}
	};
}
// src/audio/prism.ts
function la(e, { keep: t, source: n, onError: r }) {
	let i = t(new AudioWorkletNode(e, "rackloose-prism-v1", {
		numberOfInputs: 3,
		numberOfOutputs: 1,
		outputChannelCount: [1],
		processorOptions: { module: Ai() }
	})), a = t(e.createGain()), o = t(e.createGain());
	a.connect(i, 0, 0), o.connect(i, 0, 1);
	let s = li(e, n), c = t(e.createGain());
	c.gain.value = 0, s.bend.connect(c).connect(i, 0, 0), s.mod.connect(i, 0, 2);
	let l = {};
	return {
		pitch: a,
		cv: o,
		output: i,
		...Ni(i, "PRISM", void 0, r),
		apply(t) {
			l = t, c.gain.setTargetAtTime(t.bendRange * 100, e.currentTime, .008), i.port.postMessage({
				type: "params",
				time: e.currentTime,
				params: t
			});
		},
		wheel: s.move,
		noteOn(e, t, n, r) {
			i.port.postMessage({
				type: "on",
				time: n,
				key: r,
				velocity: t,
				notes: (lt[l.chord]?.[1] ?? [0]).map((t) => e + t)
			});
		},
		noteOff(e, t) {
			i.port.postMessage({
				type: "off",
				time: e,
				key: t
			});
		}
	};
}
// src/audio/studio.ts
function ua(e, t, n, r) {
	let i = n(new AudioWorkletNode(e, "rackloose-studio-v1", {
		numberOfInputs: 1,
		numberOfOutputs: 1,
		outputChannelCount: [2],
		channelCount: 2,
		channelCountMode: "explicit",
		processorOptions: { type: t }
	})), a = 0;
	return {
		input: i,
		output: i,
		...Ni(i, Z[t].name, (e) => {
			a = e;
		}, r),
		get reduction() {
			return a;
		},
		apply(t) {
			i.port.postMessage({
				type: "params",
				time: e.currentTime,
				params: t
			});
		}
	};
}
// src/audio/sieve.ts
var da = [
	"lowpass",
	"highpass",
	"bandpass"
], fa = [
	0,
	3,
	2
], pa = .2, ma = [
	.1,
	1,
	2.5,
	4,
	6,
	9,
	12
], ha = [
	[
		.8,
		.1,
		-.8,
		-1.3,
		-1.9,
		-2.3,
		-2
	],
	[
		-4.1,
		-4.6,
		-5.3,
		-6,
		-6.7,
		-6.9,
		-4.7
	],
	[
		-6.9,
		2,
		6.4,
		9.1,
		12.1,
		16.8,
		22.8
	]
];
function ga(e, t) {
	let n = ha[e], r = 0;
	for (; r < ma.length - 2 && t > ma[r + 1];) r++;
	let i = Math.min(1, Math.max(0, (t - ma[r]) / (ma[r + 1] - ma[r])));
	return 10 ** (-(n[r] + i * (n[r + 1] - n[r])) / 20);
}
var _a = (e) => Math.min(1, Math.max(0, (e - .1) / 11.9));
function va(e, { keep: t, onError: n }) {
	let r = () => t(e.createGain()), i = r(), a = r(), o = r(), s = r(), c = t(e.createBiquadFilter());
	i.connect(c).connect(s).connect(o), a.connect(c.detune);
	let l = Wi(e, {
		keep: t,
		onError: n,
		name: "SIEVE"
	}, i, o, [a]), u = !1, d = (t, n) => {
		u ? t.setTargetAtTime(n, e.currentTime, .008) : t.value = n;
	};
	return {
		input: i,
		cv: a,
		output: o,
		apply(e) {
			c.type = da[e.mode], d(c.frequency, e.cutoff), d(c.Q, e.resonance);
			let t = l.apply(e.filterModel === 1, {
				cutoff: e.cutoff,
				resonance: _a(e.resonance),
				drive: pa,
				level: ga(e.mode, e.resonance),
				mode: fa[e.mode]
			}, d);
			d(s.gain, +!t), u = !0;
		},
		flush: l.flush,
		dispose: l.dispose
	};
}
// src/audio/rust.ts
var ya = 4097;
function ba(e, t, n, r, i) {
	let a = 1 + 60 * t ** 2, o = .6 * n, s = .25 * i;
	return Float32Array.from({ length: ya }, (t, n) => {
		let i = n / 4096 * 2 - 1, c = Math.sign(i) * Math.max(0, Math.abs(i) - s) / (1 - s), l = a * c + o * Math.min(1, a * Math.abs(c) * 4);
		switch (yt[e]) {
			case "Rectify": return Math.abs(Math.tanh(1.5 * l));
			case "Fold": return Math.sin(Math.PI / 2 * l);
			case "Crush": {
				let e = 2 ** (r - 1);
				return Math.round(Math.tanh(l) * e) / e;
			}
			case "Broken": return l > 0 ? Math.tanh(3 * l) : Math.max(-.3, l * 1.5);
			default: return Math.max(-1, Math.min(1, l));
		}
	});
}
function xa(e, t) {
	let n = t(e.createGain()), r = t(e.createGain()), i = t(e.createBiquadFilter()), a = t(e.createWaveShaper()), o = t(e.createBiquadFilter()), s = t(e.createBiquadFilter()), c = t(e.createGain()), l = t(e.createGain()), u = t(e.createGain());
	i.type = "peaking", i.Q.value = 1.1, i.gain.value = 9, o.type = "highpass", o.frequency.value = 30, s.type = "lowpass", s.Q.value = .5, n.connect(c).connect(u), n.connect(r).connect(i).connect(a).connect(o).connect(s).connect(l).connect(u);
	let d = "", f = !1;
	return {
		input: n,
		cv: r.gain,
		output: u,
		apply(t) {
			let n = (t, n) => {
				f ? t.setTargetAtTime(n, e.currentTime, .01) : t.value = n;
			}, r = [
				t.mode,
				t.drive,
				t.bias,
				t.crush,
				t.starve
			].join();
			r !== d && (a.curve = ba(t.mode, t.drive, t.bias, t.crush, t.starve), a.oversample = yt[t.mode] === "Crush" ? "none" : "2x", d = r), n(i.frequency, t.body), n(s.frequency, 1500 * 12 ** t.tone), n(c.gain, 1 - t.mix), n(l.gain, t.mix * (.7 - .25 * t.drive)), n(u.gain, t.level * 1.4), f = !0;
		}
	};
}
// src/audio/processors.ts
var Sa = (e) => 10 ** (e / 20), Ca = (e, t, n, r) => {
	r ? e.value = t : e.setTargetAtTime(t, n, .008);
}, wa = [
	[2e-4, .3],
	[2e-4, .45],
	[4e-4, .6],
	[4e-4, .75],
	[4e-4, .9],
	[2e-4, 1]
], Ta = 24, Ea = 6;
function Da(e, t, n) {
	let r = Sa(e), i = e + t, a = Sa(i), o = (e) => 20 * Math.log10(e), s = (e, t) => e < r ? e : r + (1 - Math.exp(-t * (e - r))) / t, c = (e, t) => e < r ? 1 : (o(s(e * 1.001, t)) - o(s(e, t))) / (o(e * 1.001) - o(e)), l = .1, u = 1e4, d = 5;
	for (let e = 0; e < 15; e++) c(a, d) < 1 / n ? u = d : l = d, d = Math.sqrt(l * u);
	return (1 / (1 < a ? s(1, d) : Sa(o(s(a, d)) + (0 - i) / n))) ** .6;
}
function Oa(e, { keep: t }) {
	let n = (n = 1) => {
		let r = t(e.createGain());
		return r.gain.value = n, r;
	}, r = (n, r, i = 0) => {
		let a = t(e.createBiquadFilter());
		return a.type = n, a.frequency.value = r, a.gain.value = i, a.Q.value = -3.01, a;
	}, i = n(), a = n(), o = t(e.createWaveShaper()), s = n(), c = .2, l = .5 * (1 - Math.tanh(c) ** 2);
	o.curve = Float32Array.from({ length: 2049 }, (e, t) => (Math.tanh(2 * (t / 1024 - 1) + c) - Math.tanh(c)) / l), o.oversample = "2x";
	let u = t(e.createDynamicsCompressor());
	u.knee.value = Ta, u.ratio.value = Ea, i.connect(a).connect(o).connect(r("highpass", 12)).connect(r("lowshelf", 90, 1)).connect(r("highshelf", 9e3, -1)).connect(u).connect(s);
	let d = !0, f = NaN, p = 1;
	return {
		input: i,
		output: s,
		compressor: u,
		apply(t) {
			let n = e.currentTime, [r, i] = wa[t.time] ?? wa[1];
			f !== t.threshold && (f = t.threshold, p = Da(t.threshold, Ta, Ea)), Ca(a.gain, Sa(t.input) / 4, n, d), Ca(u.threshold, t.threshold, n, d), u.attack.value = r, u.release.value = i, Ca(s.gain, Sa(t.output) / p, n, d), d = !1;
		}
	};
}
function ka(e, t) {
	return [
		{
			type: "highpass",
			frequency: e.hpf <= 16 ? 0 : e.hpf,
			Q: -3.01,
			gain: 0
		},
		{
			type: e.lfBell ? "peaking" : "lowshelf",
			frequency: e.lfFreq,
			Q: .7,
			gain: e.lfGain
		},
		{
			type: "peaking",
			frequency: e.lmfFreq,
			Q: e.lmfQ,
			gain: e.lmfGain
		},
		{
			type: "peaking",
			frequency: e.hmfFreq,
			Q: e.hmfQ,
			gain: e.hmfGain
		},
		{
			type: e.hfBell ? "peaking" : "highshelf",
			frequency: e.hfFreq,
			Q: .7,
			gain: e.hfGain
		},
		{
			type: "lowpass",
			frequency: e.lpf >= 22e3 ? t : Math.min(e.lpf, t),
			Q: -3.01,
			gain: 0
		}
	];
}
function Aa({ type: e, frequency: t, Q: n, gain: r }, i, a) {
	let o = a / 2;
	if (e === "highpass" && t <= 0 || e === "lowpass" && t >= o) return 0;
	let s = 10 ** (r / 40), c = 2 * Math.PI * t / a, l = Math.cos(c), u = Math.sin(c), d = u / (2 * 10 ** (n / 20)), f = u / (2 * n), p = u / 2 * Math.SQRT2 * 2 * Math.sqrt(s), [m, h, g, _, v, y] = {
		lowpass: [
			(1 - l) / 2,
			1 - l,
			(1 - l) / 2,
			1 + d,
			-2 * l,
			1 - d
		],
		highpass: [
			(1 + l) / 2,
			-(1 + l),
			(1 + l) / 2,
			1 + d,
			-2 * l,
			1 - d
		],
		peaking: [
			1 + f * s,
			-2 * l,
			1 - f * s,
			1 + f / s,
			-2 * l,
			1 - f / s
		],
		lowshelf: [
			s * (s + 1 - (s - 1) * l + p),
			2 * s * (s - 1 - (s + 1) * l),
			s * (s + 1 - (s - 1) * l - p),
			s + 1 + (s - 1) * l + p,
			-2 * (s - 1 + (s + 1) * l),
			s + 1 + (s - 1) * l - p
		],
		highshelf: [
			s * (s + 1 + (s - 1) * l + p),
			-2 * s * (s - 1 + (s + 1) * l),
			s * (s + 1 + (s - 1) * l - p),
			s + 1 - (s - 1) * l + p,
			2 * (s - 1 - (s + 1) * l),
			s + 1 - (s - 1) * l - p
		]
	}[e] ?? [
		1,
		0,
		0,
		1,
		0,
		0
	], b = 2 * Math.PI * i / a, x = Math.cos(b), S = Math.sin(b), C = Math.cos(2 * b), w = Math.sin(2 * b), T = (e, t, n) => Math.hypot(e + t * x + n * C, t * S + n * w);
	return 20 * Math.log10(T(m, h, g) / T(_, v, y));
}
function ja(e, { keep: t }) {
	let n = (n = 1) => {
		let r = t(e.createGain());
		return r.gain.value = n, r;
	}, r = n(), i = n(), a = n(0), o = n(), s = e.sampleRate / 2, c = Array.from({ length: 6 }, () => t(e.createBiquadFilter()));
	c.reduce((e, t) => e.connect(t), r).connect(i).connect(o), r.connect(a).connect(o);
	let l = !0;
	return {
		input: r,
		output: o,
		apply(t) {
			let n = e.currentTime;
			ka(t, s).forEach((e, t) => {
				let r = c[t];
				r.type !== e.type && (r.type = e.type), e.frequency <= 0 || e.frequency >= s ? (r.frequency.cancelScheduledValues(n), r.frequency.setValueAtTime(e.frequency, n)) : Ca(r.frequency, e.frequency, n, l), Ca(r.Q, e.Q, n, l), Ca(r.gain, e.gain, n, l);
			}), Ca(i.gain, +!t.active, n, l), Ca(a.gain, +!!t.active, n, l), Ca(o.gain, Sa(t.output), n, l), l = !1;
		}
	};
}
// src/audio/session.ts
function Ma() {
	let e = typeof navigator > "u" ? void 0 : navigator.audioSession;
	if (!e || e.type === "playback") return () => {};
	let t = e.type;
	return e.type = "playback", () => {
		e.type === "playback" && (e.type = t);
	};
}
// src/audio/engine.ts
var Na = [
	"sine",
	"triangle",
	"sawtooth",
	"square"
], Pa = (e, t) => `${e}:${t}`, Fa = (e, t, n) => {
	e.setTargetAtTime(t, n, .008);
}, Ia = .5, La = .09, Ra = 4, za = 120;
function Ba({ analyser: e, data: t }) {
	e.getFloatTimeDomainData(t);
	let n = 0;
	for (let e of t) n = Math.max(n, Math.abs(e));
	return n > 0 ? Math.max(-60, 20 * Math.log10(n)) : -60;
}
function Va(e, t = 0, n = 2, r = !1, i = 0) {
	let a = e.createBuffer(r ? 2 : 1, Math.ceil(e.sampleRate * n), e.sampleRate), o = 90210;
	for (let n = 0; n < a.numberOfChannels; n++) {
		let r = a.getChannelData(n), s = 0;
		for (let n = 0; n < r.length; n++) {
			o ^= o << 13, o ^= o >>> 17, o ^= o << 5;
			let a = (o >>> 0) / 2 ** 31 - 1;
			s = t === 1 ? .93 * s + .2 * a : t === 2 ? (s + .035 * a) / 1.035 : a, r[n] = s * (i ? Math.exp(-n / e.sampleRate / i * 5) : 1);
		}
	}
	return a;
}
var Ha = "seq", Ua = "manual", Wa = "audition", Ga = {
	bend: 0,
	mod: 0
}, Ka = () => ({
	bend: [],
	mod: []
}), qa = class {
	context;
	onError;
	master;
	nodes = [];
	sources = [];
	started = !1;
	runtime = /* @__PURE__ */ new Map();
	outputs = /* @__PURE__ */ new Map();
	inputs = /* @__PURE__ */ new Map();
	cvAmounts = /* @__PURE__ */ new Map();
	notes = /* @__PURE__ */ new Map();
	white = null;
	mix = Nn;
	open = {};
	muted = !1;
	manualTarget = null;
	manualOwned = /* @__PURE__ */ new Set();
	targets = /* @__PURE__ */ new Map();
	pulses = /* @__PURE__ */ new Map();
	dictators = /* @__PURE__ */ new Map();
	take = null;
	manualKeys = /* @__PURE__ */ new Set();
	hands = /* @__PURE__ */ new Map();
	holding = /* @__PURE__ */ new Map();
	laneDriven = /* @__PURE__ */ new Set();
	patch;
	constructor(e, t, n = e.destination, r = Nn, i) {
		this.context = e, this.onError = i, this.patch = t, this.master = this.keep(e.createGain());
		let a = this.keep(e.createDynamicsCompressor());
		a.threshold.value = -12, a.knee.value = 12, a.ratio.value = 8, a.attack.value = .003, a.release.value = .15, this.master.connect(a).connect(n);
		for (let e of t.modules) this.buildModule(e);
		for (let e of t.modules) kn(e.type) && this.targets.set(e.id, Rn(t, e.id));
		for (let n of t.cables) {
			let r = this.outputs.get(Pa(n.from.moduleId, n.from.portId)), i = this.inputs.get(Pa(n.to.moduleId, n.to.portId));
			if (!r || !i || this.isNoteCable(n)) continue;
			let a = Z[t.modules.find((e) => e.id === n.to.moduleId).type].ports.find((e) => e.id === n.to.portId);
			if (a.kind === "cv") {
				let t = this.keep(e.createGain());
				t.gain.value = n.amount * (a.scale ?? 1), r.connect(t), "setValueAtTime" in i, t.connect(i), this.cvAmounts.set(n.id, t);
			} else "setValueAtTime" in i, r.connect(i);
		}
		this.applyPatch(t, !0), this.setMix(r, !0);
		for (let e of this.sources) e.start(0);
		this.started = !0;
	}
	keep(e) {
		return this.nodes.push(e), e;
	}
	isNoteCable(e) {
		let t = this.patch.modules.find((t) => t.id === e.from.moduleId)?.type;
		return e.to.portId === "pitch" && Dn(this.patch.modules.find((t) => t.id === e.to.moduleId).type) && !!t && kn(t);
	}
	polyNote(e, t, n, r) {
		let i = this.patch.cables.find((t) => t.to.moduleId === e && this.isNoteCable(t));
		return i ? 60 + ((i.from.moduleId === t ? n : this.noteAt(i.from.moduleId, r)) - 60) * i.amount : 60;
	}
	noteAt(e, t) {
		let n = this.notes.get(e) ?? [];
		for (let e = n.length - 1; e >= 0; e--) if (n[e].time <= t) return n[e].note;
		return 48;
	}
	get main() {
		return (this.patch.modules.find((e) => e.type === "performance") ?? this.patch.modules[0]).id;
	}
	gain(e = 1) {
		let t = this.keep(this.context.createGain());
		return t.gain.value = e, t;
	}
	source(e) {
		return "offset" in e && Zr(e.offset, this.context), this.started && e.start(this.context.currentTime), this.keep(e), this.sources.push(e), e;
	}
	buildModule(e) {
		let { context: t } = this, n = (t) => Pa(e.id, t), r = (e, t) => this.inputs.set(n(e), t), i = this.gain(), a = (e, t, r = !0) => this.outputs.set(n(e), r ? t.connect(i) : t), o = !1, s = (e, n) => {
			o ? Fa(e, n, t.currentTime) : e.value = n;
		}, c = () => {}, l, u, d, f, p, m, h, g, _, v, y, b = (e) => {
			p = this.source(t.createConstantSource()), p.offset.value = 0;
			let n = this.gain(1200);
			p.connect(n), "setValueAtTime" in e, n.connect(e);
		};
		switch (e.type) {
			case "performance":
			case "dictator":
				l = this.source(t.createConstantSource()), l.offset.value = -1, a("pitch", l, !1);
				break;
			case "oscillator": {
				let e = this.source(t.createOscillator()), n = this.gain();
				e.frequency.value = 261.625565, e.connect(n), r("pitch", e.detune), b(e.detune), r("fm", e.detune), a("out", n), c = (t) => {
					e.type = Na[t.wave], s(e.detune, t.octave * 1200 + t.tune * 100 + t.fine), s(n.gain, t.level * .35);
				};
				break;
			}
			case "monarch":
				this.white ??= Va(t, 0, 1), f = Qi(t, this.white, {
					onError: this.onError,
					keep: (e) => this.keep(e),
					source: (e) => this.source(e)
				}), r("pitch", f.pitch), b(f.pitch), r("cv", f.cv), a("out", f.output), c = f.apply;
				break;
			case "oracle":
			case "aurora":
			case "prism": {
				this.white ??= Va(t, 0, 1);
				let n = {
					onError: this.onError,
					keep: (e) => this.keep(e),
					source: (e) => this.source(e)
				};
				g = e.type === "oracle" ? ra(t, this.white, n) : e.type === "aurora" ? ca(t, n) : la(t, n), r("pitch", g.pitch), r("cv", g.cv), a("out", g.output), c = g.apply;
				break;
			}
			case "compressor":
				_ = Oa(t, { keep: (e) => this.keep(e) }), r("in", _.input), a("out", _.output), c = _.apply;
				break;
			case "cohere":
			case "talon":
			case "brit":
				m = ua(t, e.type, (e) => this.keep(e), this.onError), r("in", m.input), a("out", m.output), c = m.apply;
				break;
			case "equalizer": {
				let e = ja(t, { keep: (e) => this.keep(e) });
				r("in", e.input), a("out", e.output), c = e.apply;
				break;
			}
			case "noise": {
				let n = this.source(t.createBufferSource()), r = this.gain();
				n.buffer = Va(t, e.params.color), n.loop = !0, n.connect(r), a("out", r), c = (e) => s(r.gain, e.level * .3);
				break;
			}
			case "mixer": {
				let e = () => {
					let e = this.keep(t.createAnalyser());
					return e.fftSize = 512, {
						analyser: e,
						data: new Float32Array(e.fftSize)
					};
				}, n = this.gain(), i = this.gain(), o = this.keep(t.createChannelSplitter(2));
				y = {
					channels: [],
					bus: [e(), e()]
				}, n.connect(i).connect(o), y.bus.forEach(({ analyser: e }, t) => o.connect(e, t));
				let l = ft.map((i, a) => {
					let o = this.gain(), s = this.gain(), c = e(), l = [this.gain(), this.gain()], u = this.gain(), d = this.keep(t.createChannelSplitter(2)), f = this.keep(t.createChannelMerger(2));
					return u.channelCount = 2, u.channelCountMode = "explicit", u.channelInterpretation = "speakers", o.connect(s).connect(u).connect(d), s.connect(c.analyser), l.forEach((e, t) => d.connect(e, t).connect(f, 0, t)), f.connect(n), r(i, o), y.channels.push(c), {
						id: ft[a],
						level: o,
						gate: s,
						sides: l
					};
				});
				v = Object.fromEntries(l.map(({ id: e, gate: t }) => [e, t])), a("out", i), c = (e) => {
					for (let { id: t, level: n, sides: [r, i] } of l) {
						let a = e[pt(t)];
						s(n.gain, e[t]), s(r.gain, a > 0 ? Math.cos(a * Math.PI / 2) : 1), s(i.gain, a < 0 ? Math.cos(-a * Math.PI / 2) : 1);
					}
					s(i.gain, e.master);
				};
				break;
			}
			case "filter":
				h = va(t, {
					keep: (e) => this.keep(e),
					onError: this.onError
				}), r("in", h.input), r("cv", h.cv), a("out", h.output), c = h.apply;
				break;
			case "amplifier": {
				let t = this.gain(), n = this.gain();
				t.connect(n), t.gain.value = +!this.patch.cables.some((t) => t.to.moduleId === e.id && t.to.portId === "cv"), r("in", t), r("cv", t.gain), a("out", n), c = (e) => s(n.gain, e.level);
				break;
			}
			case "envelope": {
				let e = this.source(t.createConstantSource());
				e.offset.value = 0, a("out", e), u = Ui(e.offset);
				break;
			}
			case "lfo": {
				let e = this.source(t.createOscillator());
				r("cv", e.frequency), a("out", e), c = (t) => {
					e.type = Na[t.wave], s(e.frequency, t.rate);
				};
				break;
			}
			case "delay": {
				let e = this.gain(), n = this.gain(), i = this.gain(), o = this.gain(), l = this.keep(t.createDelay(1)), u = this.gain();
				e.connect(i).connect(n), e.connect(l).connect(o).connect(n), l.connect(u).connect(l), r("in", e), a("out", n), c = (e) => {
					s(l.delayTime, e.time), s(u.gain, e.feedback), s(i.gain, 1 - e.mix), s(o.gain, e.mix);
				};
				break;
			}
			case "reverb": {
				let e = this.gain(), n = this.gain(), i = this.gain(), o = this.gain(), l = this.keep(t.createConvolver());
				e.connect(i).connect(n), e.connect(l).connect(o).connect(n), r("in", e), a("out", n);
				let u = -1;
				c = (e) => {
					u !== e.decay && (l.buffer = Va(t, 0, e.decay, !0, e.decay), u = e.decay), s(i.gain, 1 - e.mix), s(o.gain, e.mix);
				};
				break;
			}
			case "boom":
			case "punch":
			case "orbit":
			case "strike":
			case "forge": {
				let n = this.gain(), o = this.gain(), l = this.gain(), u = this.gain();
				n.connect(o).connect(i).connect(u), l.connect(u), r("chain", l), a("out", u, !1), this.white ??= Va(t, 0, 1);
				let f = e.type === "forge" ? xi(t, n, (e) => this.keep(e)) : void 0;
				d = Hi(t, e.type, n, {
					keep: (e) => this.keep(e),
					start: (e) => this.source(e),
					noise: this.white,
					onError: this.onError
				}, f), c = (e) => {
					f?.apply(e), s(o.gain, e.level * Ia);
				};
				break;
			}
			case "rust": {
				let e = xa(t, (e) => this.keep(e));
				r("in", e.input), r("cv", e.cv), a("out", e.output), c = e.apply;
				break;
			}
			case "output": r("in", this.master), c = (e) => s(this.master.gain, this.muted ? 0 : e.volume * .8);
		}
		for (let t of Z[e.type].ports) {
			let e = t.copyOf && this.outputs.get(n(t.copyOf));
			e && this.outputs.set(n(t.id), e);
		}
		this.runtime.set(e.id, {
			module: e,
			apply: (e) => {
				c(e), o = !0;
			},
			gate: i,
			channels: v,
			meters: y,
			pitch: l,
			envelope: u,
			drums: d,
			monarch: f,
			sieve: h,
			poly: g,
			valve: _,
			studio: m,
			manualPitch: p
		});
	}
	applyPatch(e, t = !1) {
		for (let n of e.modules) {
			let e = this.runtime.get(n.id);
			e && (t || JSON.stringify(e.module.params) !== JSON.stringify(n.params)) && (e.apply(n.params), e.module = n);
		}
		for (let n of e.cables) {
			let r = this.cvAmounts.get(n.id);
			if (r && (t || this.patch.cables.find((e) => e.id === n.id)?.amount !== n.amount)) {
				let t = e.modules.find((e) => e.id === n.to.moduleId), i = Z[t.type].ports.find((e) => e.id === n.to.portId)?.scale ?? 1;
				Fa(r.gain, this.manualTarget === n.to.moduleId && n.to.portId === "pitch" && !Dn(t.type) ? 0 : n.amount * i, this.context.currentTime);
			}
		}
		this.patch = e;
	}
	gatedBy(e) {
		let t = new Set(this.patch.cables.filter((t) => t.from.moduleId === e && rn(this.patch, t.from)?.kind === "gate").map((e) => e.to.moduleId));
		return [...this.runtime.values()].filter((e) => (e.envelope || e.monarch || e.poly) && t.has(e.module.id));
	}
	setMix(e, t = !1) {
		this.mix = e, this.open = zn(this.patch, e);
		let n = (e, n) => {
			t ? e.gain.value = +!!n : Fa(e.gain, +!!n, this.context.currentTime);
		};
		for (let { module: t, gate: r, channels: i } of this.runtime.values()) {
			n(r, this.open[t.id] !== !1);
			for (let [r, a] of Object.entries(i ?? {})) n(a, Vn(t, r, e));
		}
	}
	openEnvelope(e, t, n, r, i, a) {
		if (e.monarch) {
			e.monarch.noteOn(t, n);
			return;
		}
		if (e.poly) {
			e.poly.noteOn(this.polyNote(e.module.id, a, r, n), t, n, i);
			return;
		}
		let o = e.module.params;
		e.envelope?.on(n, t, o.attack, o.decay, o.sustain);
	}
	closeEnvelope(e, t, n) {
		e.monarch && e.monarch.noteOff(t), e.poly?.noteOff(t, n), e.envelope?.off(t, e.module.params.release);
	}
	setNote(e, t, n) {
		let r = this.runtime.get(e)?.pitch;
		r && (r.offset.cancelScheduledValues(n), r.offset.setValueAtTime((t - 60) / 12, n), this.notes.set(e, [...(this.notes.get(e) ?? []).filter((e) => e.time < n).slice(-63), {
			time: n,
			note: t
		}]));
	}
	gateOn(e, t, n, r) {
		if (this.open[e] !== !1) for (let i of this.gatedBy(e)) this.manualOwned.has(i.module.id) || this.openEnvelope(i, n, r, t, Ha, e);
	}
	noteOn(e, t = 1, n = this.context.currentTime, r = this.main) {
		this.manualTarget !== r && (this.setNote(r, e, n), this.gateOn(r, e, t, n));
	}
	noteOff(e = this.context.currentTime, t = this.main) {
		for (let n of this.gatedBy(t)) this.manualOwned.has(n.module.id) || this.closeEnvelope(n, e, Ha);
	}
	sequence(e, t, n, r) {
		let i = t % 16, a = e.filter((e) => e !== this.manualTarget).flatMap((e) => {
			let t = Rt(this.patch, e)[i], a = this.runtime.get(e)?.module.params.lag;
			return t?.enabled && Hn(e, i, this.mix) ? [{
				id: e,
				step: t,
				at: this.lagged(n, a),
				end: this.lagged(n + r * t.gate, a)
			}] : [];
		});
		for (let { id: e, step: t, at: n } of a) this.setNote(e, t.note, n);
		for (let { id: e, step: t, at: n, end: r } of a) if (this.gateOn(e, t.note, t.velocity, n), this.noteOff(r, e), this.open[e] !== !1) for (let t of this.targets.get(e) ?? []) this.pulse(t, n, e);
	}
	setTake(e) {
		this.take = e;
	}
	dictatorState(e) {
		let t = this.dictators.get(e);
		return t || this.dictators.set(e, t = {
			sounding: [],
			line: new P()
		}), t;
	}
	clipNotes(e, t, n, r) {
		let i = this.take?.id === e.id ? this.take : null, a = r ? [] : D(e.notes ?? [], t, n).filter(([e]) => !i || !M(e, i.covered));
		return i ? T([...a, ...D(i.notes, t, n)]) : a;
	}
	dictatorStep(e, t, n, r) {
		if (!(t < 0)) for (let i of e) {
			let e = this.patch.modules.find((e) => e.id === i);
			if (!e || e.type !== "dictator" || !this.runtime.has(i)) continue;
			let a = this.dictatorState(i), o = C(e.params.length), s = t * 240, c = s % o, l = (t) => this.lagged(n + (t - s) / 240 * r, e.params.lag), u = [];
			for (let e of a.sounding) e.end <= s + 240 && u.push({
				tick: Math.max(s, e.end),
				ends: e
			});
			if (this.open[i] !== !1) {
				let t = this.take?.id === i && this.take.hideFrom !== null && s >= this.take.hideFrom;
				for (let n of this.clipNotes(e, c, c + 240, t)) u.push({
					tick: s + n[0] - c,
					note: n
				});
			}
			u.sort((e, t) => e.tick - t.tick || ("ends" in e ? -1 : 0) - ("ends" in t ? -1 : 0));
			let d = this.gatedBy(i), f = this.kitsOf(i), p = this.manualTarget === i, m = d.filter((e) => e.poly && (p || !this.manualOwned.has(e.module.id))), h = p ? [] : d.filter((e) => !e.poly && !this.manualOwned.has(e.module.id));
			this.open[i] !== !1 && this.laneStep(e, s, c, o, l, d);
			for (let e of u) {
				let t = l(e.tick);
				if ("ends" in e) {
					a.sounding = a.sounding.filter((t) => t !== e.ends);
					for (let n of m) n.poly.noteOff(t, e.ends.key);
					let n = a.line.off(e.ends.id);
					if (n === null) for (let e of h) this.closeEnvelope(e, t, Ha);
					else if (n && !p) {
						this.setNote(i, n.note, t);
						for (let e of h) this.openEnvelope(e, n.velocity / 127, t, n.note, Ha, i);
					}
					continue;
				}
				let [n, r, u, d] = e.note, g = `dictator:${i}:${u}`;
				for (let e of a.sounding.filter((e) => e.note === u)) a.sounding = a.sounding.filter((t) => t !== e), a.line.off(e.id);
				let _ = {
					id: `${e.tick}:${u}`,
					key: g,
					note: u,
					end: Math.min(s - c + o, s + n - c + r)
				};
				a.sounding.push(_), a.line.on(_.id, u, d), p || this.setNote(i, u, t);
				for (let e of m) e.poly.noteOn(this.polyNote(e.module.id, i, u, t), d / 127, t, g);
				for (let e of h) this.openEnvelope(e, d / 127, t, u, Ha, i);
				this.drumNote(f, u, d / 127, t, i);
				for (let e of this.targets.get(i) ?? []) f.some((t) => t.module.id === e) || this.pulse(e, t, i);
			}
		}
	}
	wheelOf(e) {
		let t = this.runtime.get(e);
		return t?.monarch?.wheel ?? t?.poly?.wheel;
	}
	laneStep(e, t, n, r, i, a) {
		let o = this.take?.id === e.id ? this.take : null;
		for (let s of U) {
			let c = o?.lanes?.[s] ?? Gt(e, s), l = Ve(c, n, r);
			if (l === null) continue;
			let u = [[n, l], ...Be(c, n + 1, n + 240)];
			for (let e of a) {
				let r = this.wheelOf(e.module.id);
				if (r && !this.holding.get(e.module.id)?.has(s)) {
					for (let [e, a] of u) r(s, Fe(s, a), i(t + e - n));
					this.laneDriven.add(`${e.module.id}:${s}`);
				}
			}
		}
	}
	handWheel(e, t, n, r) {
		let i = this.context.currentTime;
		for (let a of e) {
			let e = this.wheelOf(a);
			if (!e) continue;
			this.hands.set(a, {
				...this.hands.get(a) ?? Ga,
				[t]: n
			});
			let o = this.holding.get(a) ?? /* @__PURE__ */ new Set(), s = r && !o.has(t);
			r ? o.add(t) : o.delete(t), this.holding.set(a, o), e(t, n, i, s);
		}
	}
	restoreHands(e) {
		for (let [t, n] of e) {
			let e = this.wheelOf(t);
			if (e) {
				this.hands.set(t, { ...n });
				for (let t of U) e(t, n[t], this.context.currentTime);
			}
		}
	}
	kitsOf(e) {
		return this.patch.cables.filter((t) => t.from.moduleId === e && t.to.portId === "trig" && rn(this.patch, t.from)?.kind === "gate").flatMap((e) => {
			let t = this.runtime.get(e.to.moduleId);
			return t?.drums ? [t] : [];
		});
	}
	drumNote(e, t, n, r, i) {
		for (let a of e) {
			let e = F(Z[a.module.type].drum?.voices ?? [], t);
			e && Vn(a.module, e, this.mix) && (a.drums.trigger(e, this.lagged(r, a.module.params[`${e}Lag`]), a.module.params, n), this.pulse(a.module.id, r, i));
		}
	}
	releaseDictator(e, t) {
		let n = this.dictators.get(e);
		if (n) {
			for (let r of this.gatedBy(e)) {
				if (r.poly) for (let e of n.sounding) r.poly.noteOff(t, e.key);
				else n.line.size && !this.manualOwned.has(r.module.id) && this.closeEnvelope(r, t, Ha);
				for (let e of U) this.laneDriven.delete(`${r.module.id}:${e}`) && !this.holding.get(r.module.id)?.has(e) && this.wheelOf(r.module.id)?.(e, this.hands.get(r.module.id)?.[e] ?? 0, t, !0);
			}
			n.sounding = [], n.line.clear();
		}
	}
	lagged(e, t = 0) {
		return Math.max(this.context.currentTime, e + t / 1e3);
	}
	pulse(e, t, n) {
		this.pulses.set(e, [...(this.pulses.get(e) ?? []).slice(-63), {
			time: t,
			sequencer: n
		}]);
	}
	lastPulse(e, t) {
		let n = this.pulses.get(e);
		if (!n) return -1;
		let r = n.length - 1;
		for (; r >= 0 && n[r].time > t;) r--;
		return r > 0 && n.splice(0, r), r < 0 ? -1 : n[0].time;
	}
	mixerLevels(e) {
		let t = this.runtime.get(e)?.meters;
		return t ? {
			channels: t.channels.map(Ba),
			bus: t.bus.map(Ba)
		} : null;
	}
	manualOn(e, t, n = Ua, r = 1) {
		this.manualTarget !== e && this.manualOff();
		let i = this.runtime.get(e), a = this.context.currentTime;
		if (i) {
			if (this.manualTarget = e, i.poly) this.manualOwned = /* @__PURE__ */ new Set([e]), i.poly.noteOff(a, Ha), i.poly.noteOn(t, r, a, n);
			else if (i.module.type === "dictator") {
				let i = this.gatedBy(e);
				if (this.manualOwned = new Set(i.map((e) => e.module.id)), this.open[e] === !1) return;
				this.setNote(e, t, a), this.manualKeys.add(n), this.drumNote(this.kitsOf(e), t, r, a, e);
				for (let o of i) o.poly ? o.poly.noteOn(this.polyNote(o.module.id, e, t, a), r, a, `${Ua}:${n}`) : this.openEnvelope(o, r, a, t, Ua, e);
			} else {
				if (i.module.type === "performance") {
					if (this.manualOwned = new Set(this.gatedBy(e).map((e) => e.module.id)), this.setNote(e, t, a), this.open[e] === !1) return;
				} else {
					let n = An(this.patch, e);
					this.manualOwned = new Set(i.monarch ? [e] : this.patch.cables.filter((e) => n.has(e.to.moduleId) && this.runtime.get(e.from.moduleId)?.envelope).map((e) => e.from.moduleId));
					for (let t of this.patch.cables) t.to.moduleId === e && t.to.portId === "pitch" && this.cvAmounts.get(t.id)?.gain.setValueAtTime(0, a);
					i.manualPitch?.offset.setValueAtTime((t - 60) / 12, a);
				}
				for (let n of this.manualOwned) {
					let i = this.runtime.get(n);
					i.poly?.noteOff(a, Ha), this.openEnvelope(i, r, a, t, Ua, e);
				}
			}
		}
	}
	manualRelease(e, t) {
		let n = this.context.currentTime, r = this.runtime.get(this.manualTarget ?? "");
		if (r?.module.type !== "dictator") r?.poly?.noteOff(n, e);
		else {
			this.manualKeys.delete(e);
			for (let i of this.manualOwned) {
				let a = this.runtime.get(i);
				a?.poly ? a.poly.noteOff(n, `${Ua}:${e}`) : a && t && (this.setNote(r.module.id, t.note, n), this.openEnvelope(a, t.velocity, n, t.note, Ua, r.module.id));
			}
		}
	}
	manualOff() {
		let e = this.context.currentTime, t = this.manualTarget, n = this.runtime.get(t ?? "")?.module.type === "dictator";
		for (let t of this.manualOwned) {
			let r = this.runtime.get(t);
			if (r?.poly && n) for (let t of this.manualKeys) r.poly.noteOff(e, `${Ua}:${t}`);
			else r && this.closeEnvelope(r, e);
		}
		this.manualKeys.clear(), this.runtime.get(t ?? "")?.manualPitch?.offset.setValueAtTime(0, e);
		for (let n of this.patch.cables) n.to.moduleId === t && n.to.portId === "pitch" && this.cvAmounts.get(n.id)?.gain.setValueAtTime(n.amount * 1200, e);
		this.manualOwned.clear(), this.manualTarget = null;
	}
	reduction(e) {
		return this.runtime.get(e)?.studio?.reduction ?? this.runtime.get(e)?.valve?.compressor.reduction ?? 0;
	}
	drumStep(e, t, n) {
		for (let { module: r, drums: i } of this.runtime.values()) {
			let a = r.type === "skitter";
			if (!(i || a) || n && r.id !== n || a && this.open[r.id] === !1) continue;
			let o = vn(r, e).filter(([e]) => Vn(r, e, this.mix)), s = yr(this.patch.sequencer.bpm, this.patch.sequencer.swing, e % 16), c = (e) => e > 2 ? r.params.rollFade ?? 0 : 0;
			for (let [e, n] of o) for (let o = 0; o < n; o++) {
				let l = t + o * s / n, u = 1 - c(n) * o / n;
				a ? this.skitterHit(r, e, l, u, s / n) : i.trigger(e, this.lagged(l, r.params[`${e}Lag`]), r.params, u);
			}
			o.length && this.pulse(r.id, t, r.id);
		}
	}
	skitterTargets(e, t) {
		return this.patch.cables.filter((n) => n.from.moduleId === e && (rn(this.patch, n.from)?.copyOf ?? n.from.portId) === t).map((e) => this.runtime.get(e.to.moduleId)).filter((e) => !!e);
	}
	skitterHit(e, t, n, r, i) {
		if (t === "synth") for (let t of this.skitterTargets(e.id, "gate")) !this.manualOwned.has(t.module.id) && (t.envelope || t.monarch || t.poly) && (this.openEnvelope(t, r, n, 60, Ha, e.id), this.closeEnvelope(t, n + i * (e.params.gate ?? .5), Ha), this.pulse(t.module.id, n, e.id));
		else for (let i of this.skitterTargets(e.id, "trig")) {
			let a = ht[i.module.type]?.[t];
			a && i.drums && Vn(i.module, a, this.mix) && (i.drums.trigger(a, this.lagged(n, i.module.params[`${a}Lag`]), i.module.params, r), this.pulse(i.module.id, n, e.id));
		}
	}
	skitterKits(e) {
		return this.patch.modules.some((t) => t.id === e && t.type === "skitter") ? this.skitterTargets(e, "trig").filter((e) => e.drums).map((e) => e.module.id) : [];
	}
	hit(e, t, n = this.context.currentTime, r = 1) {
		let i = this.runtime.get(e);
		i && Vn(i.module, t, this.mix) && (i.module.type === "skitter" ? this.open[e] !== !1 && this.skitterHit(i.module, t, n, r, .12) : i.drums?.trigger(t, n, i.module.params, r));
	}
	cancelModule(e, t = this.context.currentTime) {
		let n = this.runtime.get(e);
		for (let [n, r] of this.pulses) this.pulses.set(n, r.filter((n) => n.sequencer !== e || n.time <= t));
		if (n?.drums && n.drums.cancelScheduled(t), n?.module.type === "skitter") {
			for (let n of this.skitterKits(e)) this.runtime.get(n).drums.cancelScheduled(t);
			for (let n of this.gatedBy(e)) this.manualOwned.has(n.module.id) || this.closeEnvelope(n, t, Ha);
		}
		n?.module.type === "dictator" && this.releaseDictator(e, t), n?.pitch && (this.noteOff(t, e), this.manualTarget !== e && (Qr(n.pitch.offset, t), this.notes.set(e, (this.notes.get(e) ?? []).filter((e) => e.time <= t))));
	}
	cancelScheduled(e = this.context.currentTime) {
		for (let t of this.patch.modules) On(t.type) && this.cancelModule(t.id, e);
	}
	setMute(e) {
		this.muted = e, Fa(this.master.gain, e ? 0 : this.patch.modules.find((e) => e.type === "output").params.volume * .8, this.context.currentTime);
	}
	async flush() {
		await Promise.all([...this.runtime.values()].map((e) => Promise.all([
			e.poly?.flush?.(),
			e.studio?.flush(),
			e.monarch?.flush(),
			e.sieve?.flush(),
			e.drums?.flush?.()
		])));
	}
	dispose() {
		for (let { poly: e, studio: t, monarch: n, sieve: r } of this.runtime.values()) e?.dispose?.(), t?.dispose(), n?.dispose(), r?.dispose();
		this.master.gain.cancelScheduledValues(this.context.currentTime), this.master.gain.value = 0;
		for (let { drums: e } of this.runtime.values()) e?.dispose();
		for (let e of this.sources) e.stop();
		for (let e of this.nodes) e.disconnect();
		this.sources = [], this.nodes = [];
	}
}, Ja = (e) => JSON.stringify({
	modules: e.modules.map((e) => [
		e.id,
		e.type,
		e.type === "noise" ? e.params.color : null
	]).sort(),
	cables: e.cables.map((e) => [
		e.id,
		e.from,
		e.to
	]).sort()
}), Ya = class {
	patch;
	onError;
	context = null;
	graph = null;
	analyser = null;
	timer = null;
	notes = new vr();
	target = null;
	running = /* @__PURE__ */ new Map();
	nextTime = 0;
	count = 0;
	timeline = [];
	frozen = -1;
	remaining = .04;
	muted = !1;
	mix = Nn;
	suspended = !1;
	disposed = !1;
	revision = 0;
	manualRevision = 0;
	transportRevision = 0;
	moduleRevisions = /* @__PURE__ */ new Map();
	releaseSession = null;
	inputs = /* @__PURE__ */ new Map();
	velocities = /* @__PURE__ */ new Map();
	past = [];
	clickOn = !1;
	countIn = {
		left: 0,
		total: 0
	};
	clicks = /* @__PURE__ */ new Map();
	armed = null;
	take = null;
	onTake;
	hands = /* @__PURE__ */ new Map();
	holding = /* @__PURE__ */ new Set();
	strokes = {};
	heard = {
		notes: [],
		open: /* @__PURE__ */ new Map(),
		strokes: Ka()
	};
	offset = 0;
	held = /* @__PURE__ */ new Map();
	playing = !1;
	constructor(e, t) {
		this.patch = e, this.onError = t;
	}
	get activeNote() {
		return this.notes.current;
	}
	get activeNotes() {
		return this.poly ? this.notes.entries.map(([, e]) => e) : this.notes.current === null ? [] : [this.notes.current];
	}
	get poly() {
		let e = this.patch.modules.find((e) => e.id === this.target)?.type;
		return !!e && (Dn(e) || e === "dictator");
	}
	get armedId() {
		return this.armed;
	}
	get recording() {
		return !!this.take;
	}
	takeNotes(e) {
		return this.take?.id === e ? this.take.notes : null;
	}
	arm(e) {
		this.take && this.take.id !== e && this.finishTake(), this.armed = e;
	}
	async record(e = 0) {
		let t = this.armed, n = this.patch.modules.find((e) => e.id === t && e.type === "dictator");
		if (!t || !n || this.take || this.suspended || this.disposed) return !1;
		let r = this.playing, i = r ? Math.max(0, Math.round(this.tickOf() ?? this.count * 240)) : this.count * 240, a = this.take = {
			id: t,
			start: i,
			replace: n.params.mode === 1,
			grid: n.params.qrec ? x[n.params.quantize]?.[1] ?? null : null,
			notes: [],
			open: /* @__PURE__ */ new Map(),
			covered: [],
			strokes: Ka()
		};
		return this.showTake(), r ? this.running.has(t) || await this.play(t) : await this.play(void 0, e * 16), this.take === a ? this.playing ? (this.showTake(), !0) : (this.take = null, this.graph?.setTake(null), !1) : !1;
	}
	discardTake() {
		let e = this.take;
		if (!e) return 0;
		let t = e.notes.length + e.open.size;
		e.notes = [], e.open.clear(), e.covered = [], e.strokes = Ka(), e.start = Math.max(e.start, Math.round(this.tickOf() ?? e.start));
		for (let e of U) this.strokes[e]?.take && (this.strokes[e] = void 0);
		return this.showTake(), t;
	}
	showTake() {
		let e = this.take;
		this.graph?.setTake(e && {
			id: e.id,
			notes: e.notes,
			hideFrom: e.replace ? e.start : null,
			covered: e.replace ? e.covered : [],
			lanes: this.takeLanes(e.id, e.strokes)
		});
	}
	takeLanes(e, t) {
		let n = this.patch.modules.find((t) => t.id === e);
		return n ? Object.fromEntries(U.filter((e) => t[e].length).map((e) => [e, Ke(Gt(n, e), t[e], C(n.params.length))])) : {};
	}
	get canCapture() {
		return this.heard.notes.length > 0 || U.some((e) => this.heard.strokes[e].length);
	}
	takeHeard(e) {
		let t = this.playing && this.ready ? this.tickOf() : null;
		for (let e of U) this.strokes[e] && !this.strokes[e].take && this.closeStroke(e, t);
		let { notes: n, strokes: r } = this.heard, i = [...n.map((e) => e[0]), ...U.flatMap((e) => r[e].map((e) => e.at(-1)[0]))], a = i.length ? A(Math.max(...i)) : 0, o = j(n, e, a), s = Object.fromEntries(U.map((t) => [t, qe(r[t], a - e, a)]));
		return this.heard.notes = [], this.heard.strokes = Ka(), {
			notes: o,
			strokes: s
		};
	}
	setRecordOffset(e) {
		this.offset = Number.isFinite(e) ? Math.max(-100, Math.min(100, e)) : 0;
	}
	inputTick(e) {
		return this.tick(), this.tickOf((e ?? performance.now()) - this.offset);
	}
	finishTake() {
		let e = this.take;
		if (!e) return;
		let t = Math.round(this.tickOf() ?? e.start);
		for (let n of [...e.open.keys()]) this.captureEnd(n, void 0, t);
		this.closeStrokes(), this.take = null;
		let n = this.patch.modules.find((t) => t.id === e.id);
		n ? (this.graph?.setTake({
			id: e.id,
			notes: e.notes,
			hideFrom: null,
			covered: [],
			lanes: this.takeLanes(e.id, e.strokes)
		}), this.onTake?.(e.id, e.notes, e.replace ? [...e.covered, ...te(e.start, t, C(n.params.length))] : [], e.replace, e.strokes)) : this.graph?.setTake(null);
	}
	captureStart(e, t, n, r) {
		let i = this.take, a = this.inputTick(r);
		if (a === null || a < i.start - za) return;
		let o = Math.max(i.start, Math.round(a));
		i.open.set(e, {
			start: i.grid ? O(o, i.grid) : o,
			raw: o,
			note: t,
			velocity: Math.round(n * 127)
		});
	}
	captureEnd(e, t, n) {
		let r = this.take, i = r?.open.get(e), a = this.patch.modules.find((e) => e.id === r?.id);
		if (!r || !i) return;
		r.open.delete(e);
		let o = n ?? Math.round(this.inputTick(t) ?? i.raw + 1);
		!a || r.notes.length >= 2048 || (r.notes = T([...r.notes, k(i.start, Math.max(1, o - i.raw), i.note, i.velocity, C(a.params.length))]), this.showTake());
	}
	hearStart(e, t, n, r, i) {
		let a = this.inputTick(r);
		a === null || a < -za || this.patch.modules.find((e) => e.id === i)?.type === "noise" || this.heard.open.set(e, {
			raw: Math.max(0, Math.round(a)),
			note: t,
			velocity: Math.round(n * 127)
		});
	}
	hearEnd(e, t) {
		let n = this.heard.open.get(e);
		if (!n) return;
		this.heard.open.delete(e);
		let r = Math.round(this.inputTick(t) ?? n.raw + 1), i = [...this.heard.notes, [
			n.raw,
			Math.max(1, r - n.raw),
			n.note,
			n.velocity
		]];
		this.heard.notes = i.filter(([e]) => e > n.raw - v).slice(-y);
	}
	wheel(e, t, n, r, i) {
		if (this.suspended || this.disposed) return;
		let a = Zt(this.patch, e);
		for (let e of a) this.hands.set(e, {
			...this.hands.get(e) ?? Ga,
			[t]: n
		});
		r ? this.holding.add(t) : this.holding.delete(t), a.length && this.recordWheel(t, Ie(t, n), r, this.take?.id === e, i), this.ready ? this.graph.handWheel(a, t, n, r) : r && this.unlock().then((e) => {
			e && this.graph.handWheel(a, t, this.hands.get(a[0])?.[t] ?? n, this.holding.has(t));
		}).catch((e) => this.onError?.(e));
	}
	recordWheel(e, t, n, r, i) {
		let a = this.inputTick(i), o = r && !!this.take;
		this.strokes[e] && this.strokes[e].take !== o && this.closeStroke(e, a);
		let s = this.strokes[e];
		if (a !== null && a >= -za) {
			let r = [Math.max(0, Math.round(a)), t];
			s ? (s.points = Je(s.points, r), !n && s.points.at(-1)[0] < r[0] && (s.points = [...s.points, r])) : n && (this.strokes[e] = {
				points: [r],
				take: o
			});
		}
		n || this.closeStroke(e);
	}
	closeStroke(e, t) {
		let n = this.strokes[e];
		if (this.strokes[e] = void 0, !n?.points.length) return;
		let r = n.points.at(-1);
		if (t != null && Math.round(t) > r[0] && (n.points = [...n.points, [Math.round(t), r[1]]]), n.take && this.take) {
			this.take.strokes[e] = [...this.take.strokes[e], n.points], this.showTake();
			return;
		}
		let i = n.points.at(-1)[0];
		this.heard.strokes[e] = [...this.heard.strokes[e], n.points].filter((e) => e.at(-1)[0] > i - v);
	}
	closeStrokes() {
		let e = this.playing && this.ready ? this.tickOf() : null;
		for (let t of U) this.closeStroke(t, e);
	}
	wheelLevels(e) {
		let t = Zt(this.patch, e);
		if (!t.length) return null;
		let n = { ...this.hands.get(t[0]) ?? Ga }, r = this.playing && this.ready ? this.tickOf() : null;
		if (r === null || r < 0) return n;
		let i = this.patch.modules.filter((e) => e.type === "dictator" && this.running.has(e.id) && this.patch.cables.some((n) => n.from.moduleId === e.id && n.to.moduleId === t[0] && n.to.portId === "gate"));
		for (let e of U) if (!this.holding.has(e)) for (let t of i) {
			let i = C(t.params.length), a = Ve((this.take?.id === t.id ? this.takeLanes(t.id, this.take.strokes)[e] : void 0) ?? Gt(t, e), r % i, i);
			if (a !== null) {
				n[e] = Fe(e, a);
				break;
			}
		}
		return n;
	}
	reduction(e) {
		return this.ready ? this.graph.reduction(e) : 0;
	}
	get sampleRate() {
		return this.context?.sampleRate ?? 48e3;
	}
	get ready() {
		return !!this.graph && this.context?.state === "running";
	}
	get sounding() {
		let e = this.context?.currentTime ?? 0;
		for (; this.timeline.length > 1 && this.timeline[1].time <= e;) this.past.push(this.timeline.shift());
		for (; this.past.length && this.past[0].time + this.past[0].duration < e - Ra;) this.past.shift();
		return this.playing && this.timeline[0]?.time <= e ? this.timeline[0] : null;
	}
	get clock() {
		let e = this.sounding;
		return e && e.count >= 0 ? e.count : this.frozen;
	}
	get countingIn() {
		let e = this.sounding?.count;
		return e !== void 0 && e < 0 ? e : null;
	}
	clockSteps() {
		return this.sounding, [...this.past, ...this.timeline];
	}
	tickOf(e = performance.now()) {
		if (!this.context || !this.playing) return null;
		let t = this.context, n = typeof t.getOutputTimestamp == "function" ? t.getOutputTimestamp() : null, r = re(e, n && {
			contextTime: n.contextTime ?? 0,
			performanceTime: n.performanceTime ?? 0
		}, {
			currentTime: t.currentTime,
			latency: (t.outputLatency || 0) + (t.baseLatency || 0),
			now: performance.now()
		});
		return ne(this.clockSteps(), r);
	}
	setClick(e) {
		this.clickOn = e, !e && this.context && this.cancelClicks(this.context.currentTime, !1);
	}
	click(e, t, n = !1) {
		let r = this.context;
		if (!r) return;
		let i = r.createOscillator(), a = r.createGain();
		i.frequency.value = t ? 1760 : 1320, a.gain.setValueAtTime(t ? .45 : .3, e), a.gain.exponentialRampToValueAtTime(.001, e + .04), i.connect(a).connect(r.destination), i.start(e), i.stop(e + .05), i.onended = () => {
			i.disconnect(), a.disconnect(), this.clicks.delete(i);
		}, this.clicks.set(i, n);
	}
	cancelClicks(e, t = !0) {
		for (let [n, r] of this.clicks) if (t || !r) try {
			n.stop(e);
		} catch {}
	}
	get step() {
		return this.clock < 0 ? -1 : this.clock % 16;
	}
	modulePlaying(e) {
		return this.playing && this.running.has(e);
	}
	moduleClock(e) {
		let t = this.clock;
		return this.running.has(e) && t >= this.running.get(e) ? t : -1;
	}
	pulsing(e) {
		if (!this.graph || !this.context || !this.ready) return !1;
		let t = this.context.currentTime - (this.context.outputLatency || 0), n = this.graph.lastPulse(e, t);
		return n >= 0 && t - n < La;
	}
	mixerLevels(e) {
		let t = {
			channels: ft.map(() => -60),
			bus: [-60, -60]
		}, n = this.graph && this.ready ? this.graph.mixerLevels(e) : null;
		if (!n || !this.context) return this.held.delete(e), t;
		let r = this.context.currentTime, i = this.held.get(e), a = i ? (r - i.time) * 24 : 0, o = (e, t, n) => Math.max(e, n ? n[t] - a : -60), s = {
			channels: n.channels.map((e, t) => o(e, t, i?.levels.channels)),
			bus: n.bus.map((e, t) => o(e, t, i?.levels.bus))
		};
		return this.held.set(e, {
			time: r,
			levels: s
		}), s;
	}
	get meter() {
		if (!this.analyser || !this.ready) return 0;
		let e = new Float32Array(this.analyser.fftSize);
		return this.analyser.getFloatTimeDomainData(e), Math.min(1, Math.sqrt(e.reduce((e, t) => e + t * t, 0) / e.length) * 6);
	}
	async unlock() {
		if (this.suspended || this.disposed) return !1;
		let e = this.revision;
		if (!this.context) {
			if (typeof AudioContext > "u") throw Error("Web Audio is unavailable in this browser. Try a current Chrome or Safari.");
			this.releaseSession = Ma(), this.context = new AudioContext({ latencyHint: "interactive" }), this.analyser = this.context.createAnalyser(), this.analyser.fftSize = 256, this.analyser.connect(this.context.destination);
		}
		let t = this.context;
		if (await t.resume(), this.disposed || this.suspended || e !== this.revision) return !1;
		try {
			await Mi(t);
		} catch (t) {
			if (this.disposed || this.suspended || e !== this.revision) return !1;
			throw t;
		}
		return this.disposed || this.suspended || e !== this.revision ? !1 : (this.graph || (this.graph = new qa(this.context, this.patch, this.analyser, this.mix, (e) => {
			this.panic(), this.onError?.(e);
		}), this.graph.setMute(this.muted), this.graph.restoreHands(this.hands)), !0);
	}
	unlockForInput(e, t = !1) {
		return e === void 0 ? this.unlock() : (this.inputs.get(e)?.cancel(), new Promise((n, r) => {
			let i = () => {
				this.inputs.get(e) === a && this.inputs.delete(e);
			}, a = {
				started: !1,
				cancel: () => {
					i(), n(!1);
				},
				start: (e) => {
					a.started = !0, e.then((e) => {
						i(), n(e);
					}, (e) => {
						i(), r(e);
					});
				}
			};
			this.inputs.set(e, a), (!t || this.ready) && a.start(this.unlock());
		}));
	}
	lifted(e) {
		if (e !== void 0 && !this.inputs.has(e)) return;
		let t = [...this.inputs.values()].filter((e) => !e.started);
		if (!t.length) return;
		let n = this.unlock();
		for (let e of t) e.start(n);
	}
	update(e) {
		let t = Ja(e) !== Ja(this.patch);
		this.patch = e;
		for (let t of this.running.keys()) e.modules.some((e) => e.id === t && On(e.type)) || this.running.delete(t);
		if (this.target && !e.modules.some((e) => e.id === this.target) && this.releaseManual(), this.playing && !this.running.size && this.pause(), this.graph && this.context) {
			if (t) {
				if (this.graph.dispose(), this.graph = new qa(this.context, e, this.analyser, this.mix, (e) => {
					this.panic(), this.onError?.(e);
				}), this.graph.setMute(this.muted), this.graph.restoreHands(this.hands), this.showTake(), this.target && this.poly) for (let [e, t] of this.notes.entries) this.graph.manualOn(this.target, t, e, this.velocityOf(e));
				else this.notes.current !== null && this.target && this.graph.manualOn(this.target, this.notes.current, void 0, this.velocityOf());
				for (let e of this.timeline) e.time >= this.context.currentTime && this.schedule([...this.running.keys()], e);
			} else this.graph.applyPatch(e), this.take || this.graph.setTake(null);
		}
	}
	async press(e, t, n = this.patch.modules[0].id, r = !1, i = 1, a) {
		if (this.suspended || this.disposed) return;
		n !== this.target && this.releaseManual(), this.target = n, this.notes.press(e, t), this.velocities.set(e, i), e !== Wa && (this.take?.id === n ? this.captureStart(e, t, i, a) : this.hearStart(e, t, i, a, n));
		let o = this.manualRevision, s = !this.ready;
		await this.unlockForInput(e, r) && o === this.manualRevision && this.target === n && (this.poly ? this.notes.has(e) ? this.graph.manualOn(n, t, e, i) : s && this.tap(n, t, e, i) : this.notes.current === null ? s && this.tap(n, t, void 0, i) : this.graph.manualOn(n, this.notes.current, void 0, this.velocityOf()));
	}
	audition(e, t, n) {
		return this.release(Wa), this.press(Wa, e, t, !1, n);
	}
	endAudition() {
		this.release(Wa);
	}
	velocityOf(e = this.notes.entries.at(-1)?.[0]) {
		return e !== void 0 && this.velocities.get(e) || 1;
	}
	tap(e, t, n, r = 1) {
		let i = this.manualRevision;
		this.graph.manualOn(e, t, n, r), setTimeout(() => {
			i === this.manualRevision && this.target === e && this.graph && (n === void 0 ? this.notes.current === null && this.graph.manualOff() : this.notes.has(n) || this.graph.manualRelease(n));
		}, 150);
	}
	release(e, t) {
		if (this.captureEnd(e, t), this.hearEnd(e, t), this.poly) {
			if (!this.notes.has(e)) return;
			this.velocities.delete(e);
			let t = this.notes.current, n = this.notes.release(e);
			n === null ? this.graph?.manualOff() : this.graph?.manualRelease(e, t === n ? void 0 : {
				note: n,
				velocity: this.velocityOf()
			});
			return;
		}
		let n = this.notes.current, r = this.notes.release(e);
		this.velocities.delete(e), n !== r && (r !== null && this.target ? this.graph?.manualOn(this.target, r, void 0, this.velocityOf()) : this.graph?.manualOff());
	}
	async hit(e, t, n, r = !1, i = 1) {
		if (this.suspended || this.disposed) return;
		let a = this.manualRevision;
		await this.unlockForInput(n, r) && a === this.manualRevision && this.graph.hit(e, t, void 0, i);
	}
	cancel(e) {
		this.inputs.get(e)?.cancel(), this.release(e);
	}
	releaseManual() {
		for (let e of [...this.take?.open.keys() ?? []]) this.captureEnd(e);
		for (let e of [...this.heard.open.keys()]) this.hearEnd(e);
		this.manualRevision++, this.notes.clear(), this.velocities.clear(), this.graph?.manualOff(), this.target = null;
		for (let e of this.inputs.values()) e.cancel();
	}
	schedule(e, t) {
		if (!this.graph) return;
		let n = e.filter((e) => this.patch.modules.some((t) => t.id === e && t.type === "performance")), r = e.filter((e) => this.patch.modules.some((t) => t.id === e && t.type === "dictator"));
		this.graph.sequence(n, t.count, t.time, t.duration), this.graph.dictatorStep(r, t.count, t.time, t.duration);
		for (let i of e) !n.includes(i) && !r.includes(i) && this.graph.drumStep(t.count, t.time, i);
	}
	startClock(e = 0) {
		this.playing = !0, this.nextTime = this.context.currentTime + Math.max(.01, this.remaining), this.timeline = [], this.past = [], this.countIn = {
			left: e,
			total: e
		}, this.tick(), this.timer = setInterval(() => this.tick(), 25);
	}
	async play(e, t = 0) {
		let n = this.transportRevision, r = this.patch.modules.filter((t) => On(t.type) && (!e || t.id === e)).map((e) => ({
			id: e.id,
			revision: this.moduleRevisions.get(e.id)
		}));
		if (!await this.unlock() || n !== this.transportRevision) return;
		let i = r.filter((e) => e.revision === this.moduleRevisions.get(e.id) && this.patch.modules.some((t) => t.id === e.id)).map((e) => e.id);
		if (i.length) {
			if (this.playing) {
				let e = this.timeline.filter((e) => e.time > this.context.currentTime);
				for (let t of i) if (!this.running.has(t)) {
					this.running.set(t, e[0]?.count ?? this.count);
					for (let n of e) this.schedule([t], n);
				}
			} else {
				this.running.clear();
				for (let e of i) this.running.set(e, this.count);
				this.startClock(t);
			}
		}
	}
	async rejoin() {
		if (!this.playing || this.countingIn !== null || this.countIn.left) return [];
		let e = this.patch.modules.filter((e) => On(e.type) && !this.running.has(e.id)).map((e) => e.id);
		return e.length ? (await this.play(), e.filter((e) => this.running.has(e))) : [];
	}
	stopModule(e) {
		let t = this.graph?.skitterKits(e) ?? [];
		if (this.moduleRevisions.set(e, (this.moduleRevisions.get(e) ?? 0) + 1), this.running.delete(e), this.graph?.cancelModule(e), t.length && this.graph && this.context) {
			let e = [...this.running.keys()].filter((e) => t.includes(e) || this.graph.skitterKits(e).some((e) => t.includes(e)));
			for (let t of this.timeline) t.time >= this.context.currentTime && this.schedule(e, t);
		}
		this.running.size || this.pause();
	}
	tick() {
		if (this.context && this.graph && this.playing) for (; this.nextTime < this.context.currentTime + .1 + 50 / 1e3;) {
			let { bpm: e, swing: t } = this.patch.sequencer;
			if (this.countIn.left) {
				let n = this.countIn.total - this.countIn.left, r = yr(e, t, n);
				this.timeline.push({
					count: n - this.countIn.total,
					time: this.nextTime,
					duration: r
				}), n % 4 == 0 && this.click(this.nextTime, n % 16 == 0, !0), this.countIn.left--, this.nextTime += r;
				continue;
			}
			let n = yr(e, t, this.count % 16), r = {
				count: this.count,
				time: this.nextTime,
				duration: n
			};
			this.timeline.push(r), this.clickOn && this.count % 4 == 0 && this.click(r.time, this.count % 16 == 0), this.schedule([...this.running.keys()], r), this.nextTime += n, this.count++;
		}
	}
	pause() {
		if (this.transportRevision++, !this.playing) return;
		this.finishTake(), this.closeStrokes();
		for (let e of [...this.heard.open.keys()]) this.hearEnd(e);
		let e = this.context.currentTime, t = this.sounding;
		t && t.count >= 0 && (this.frozen = t.count);
		let n = this.timeline.find((t) => t.time > e && t.count >= 0);
		this.countIn.left || (t?.count ?? 0) < 0 ? (this.count = this.timeline.find((e) => e.count >= 0)?.count ?? this.count, this.remaining = .04) : (this.count = n?.count ?? this.count, this.remaining = Math.max(0, (n?.time ?? this.nextTime) - e)), this.playing = !1, this.timer && clearInterval(this.timer), this.timer = null, this.timeline = [], this.past = [], this.countIn = {
			left: 0,
			total: 0
		}, this.cancelClicks(e), this.graph?.cancelScheduled();
	}
	rewind() {
		this.playing ? this.seek(0) : this.reset();
	}
	reset() {
		this.pause(), this.running.clear(), this.frozen = -1, this.count = 0, this.remaining = .04, this.heard = {
			notes: [],
			open: /* @__PURE__ */ new Map(),
			strokes: Ka()
		};
	}
	seek(e) {
		if (this.suspended || this.disposed || !Number.isFinite(e)) return;
		let t = Math.max(0, Math.round(e));
		for (let [e, n] of this.running) this.running.set(e, Math.min(n, t));
		if (this.closeStrokes(), this.heard = {
			notes: [],
			open: /* @__PURE__ */ new Map(),
			strokes: Ka()
		}, !this.playing || !this.context) {
			this.count = t, this.frozen = t, this.remaining = .04;
			return;
		}
		let n = this.context.currentTime, r = this.timeline.filter((e) => e.time > n && e.count >= 0), i = (r[0]?.count ?? this.count) * 240, a = this.take;
		if (r.length && (this.timeline = this.timeline.filter((e) => !r.includes(e)), this.nextTime = r[0].time, this.cancelClicks(n, !1), this.graph?.cancelScheduled(r[0].time)), a) {
			let e = this.patch.modules.find((e) => e.id === a.id);
			for (let e of [...a.open.keys()]) this.captureEnd(e, void 0, i);
			a.replace && e && (a.covered = [...a.covered, ...te(a.start, i, C(e.params.length))]), a.start = t * 240, this.showTake();
		}
		this.count = t, this.tick();
	}
	stop() {
		this.reset();
	}
	setMute(e) {
		this.muted = e, this.graph?.setMute(e);
	}
	setMix(e) {
		this.mix = e, this.graph?.setMix(e);
	}
	panic() {
		this.revision++, this.reset(), this.releaseManual(), this.graph?.dispose(), this.graph = null;
	}
	setSuspended(e) {
		this.suspended = e, e && this.panic();
	}
	dispose() {
		this.disposed = !0, this.panic(), this.analyser?.disconnect(), this.context && this.context.close().catch(() => {}), this.context = null, this.releaseSession?.(), this.releaseSession = null;
	}
};
async function Xa(e, t = 4, n = Nn) {
	let r = 44100, i = br(e, t, .04), a = new OfflineAudioContext(2, Math.ceil((i.duration + 2.04) * r), r);
	e.modules.some((e) => [
		"prism",
		"cohere",
		"talon",
		"brit"
	].includes(e.type) || e.params.filterModel === 1 || e.params.engine === 1) && await Mi(a);
	let o = new qa(a, e, a.destination, n), s = e.modules.filter((e) => e.type === "performance").map((e) => e.id), c = e.modules.filter((e) => e.type === "dictator").map((e) => e.id);
	i.events.forEach(({ time: e, duration: t }, n) => {
		o.sequence(s, n, e, t), o.dictatorStep(c, n, e, t), o.drumStep(n, e);
	});
	try {
		return await o.flush(), await a.startRendering();
	} finally {
		o.dispose();
	}
}
function Za(e) {
	let t = e.numberOfChannels, n = e.length * t * 2, r = new ArrayBuffer(44 + n), i = new DataView(r), a = (e, t) => {
		for (let n = 0; n < t.length; n++) i.setUint8(e + n, t.charCodeAt(n));
	};
	a(0, "RIFF"), i.setUint32(4, 36 + n, !0), a(8, "WAVE"), a(12, "fmt "), i.setUint32(16, 16, !0), i.setUint16(20, 1, !0), i.setUint16(22, t, !0), i.setUint32(24, e.sampleRate, !0), i.setUint32(28, e.sampleRate * t * 2, !0), i.setUint16(32, t * 2, !0), i.setUint16(34, 16, !0), a(36, "data"), i.setUint32(40, n, !0);
	let o = Array.from({ length: t }, (t, n) => e.getChannelData(n));
	for (let n = 0; n < e.length; n++) for (let e = 0; e < t; e++) {
		let r = Math.max(-1, Math.min(1, o[e][n]));
		i.setInt16(44 + (n * t + e) * 2, Math.round(r * (r < 0 ? 32768 : 32767)), !0);
	}
	return r;
}
var $ = {
	app: "_app_ciu76_1",
	toolbar: "_toolbar_ciu76_26",
	brand: "_brand_ciu76_27",
	brandMark: "_brandMark_ciu76_31",
	toolbarActions: "_toolbarActions_ciu76_32",
	audioButton: "_audioButton_ciu76_34",
	statusLed: "_statusLed_ciu76_35",
	rackLight: "_rackLight_ciu76_35",
	deviceLed: "_deviceLed_ciu76_35",
	patchBar: "_patchBar_ciu76_41",
	patchRow: "_patchRow_ciu76_42",
	barGroup: "_barGroup_ciu76_43",
	rackActions: "_rackActions_ciu76_46",
	patchIdentity: "_patchIdentity_ciu76_49",
	patchName: "_patchName_ciu76_50",
	nameField: "_nameField_ciu76_53",
	dirtyMark: "_dirtyMark_ciu76_56",
	saveStatus: "_saveStatus_ciu76_58",
	saveLed: "_saveLed_ciu76_59",
	visuallyHidden: "_visuallyHidden_ciu76_62",
	historyActions: "_historyActions_ciu76_63",
	icon: "_icon_ciu76_64",
	addButton: "_addButton_ciu76_66",
	presetsButton: "_presetsButton_ciu76_67",
	flipButton: "_flipButton_ciu76_71",
	rackHeading: "_rackHeading_ciu76_72",
	rack: "_rack_ciu76_35",
	module: "_module_ciu76_75",
	revealFlash: "_revealFlash_ciu76_1",
	moduleHeader: "_moduleHeader_ciu76_92",
	moduleIdentity: "_moduleIdentity_ciu76_93",
	moduleName: "_moduleName_ciu76_94",
	moduleSubtitle: "_moduleSubtitle_ciu76_95",
	moduleTools: "_moduleTools_ciu76_96",
	moduleNumber: "_moduleNumber_ciu76_97",
	screw: "_screw_ciu76_99",
	screwTL: "_screwTL_ciu76_101",
	screwTR: "_screwTR_ciu76_101",
	screwBL: "_screwBL_ciu76_101",
	screwBR: "_screwBR_ciu76_101",
	moduleBody: "_moduleBody_ciu76_102",
	controls: "_controls_ciu76_103",
	knobControl: "_knobControl_ciu76_104",
	controlLabel: "_controlLabel_ciu76_105",
	dial: "_dial_ciu76_106",
	dialTicks: "_dialTicks_ciu76_107",
	dialCap: "_dialCap_ciu76_108",
	knobValue: "_knobValue_ciu76_111",
	selectControl: "_selectControl_ciu76_112",
	choiceGlyph: "_choiceGlyph_ciu76_114",
	moduleDecoration: "_moduleDecoration_ciu76_115",
	deviceLabel: "_deviceLabel_ciu76_117",
	envelopeGraphic: "_envelopeGraphic_ciu76_119",
	drumPads: "_drumPads_ciu76_121",
	drumLane: "_drumLane_ciu76_123",
	laneLevel: "_laneLevel_ciu76_124",
	voiceButton: "_voiceButton_ciu76_127",
	pads: "_pads_ciu76_128",
	padGroup: "_padGroup_ciu76_129",
	pad: "_pad_ciu76_128",
	euclid: "_euclid_ciu76_137",
	euclidHeading: "_euclidHeading_ciu76_139",
	euclidCell: "_euclidCell_ciu76_140",
	orbitRings: "_orbitRings_ciu76_141",
	orbitPath: "_orbitPath_ciu76_143",
	mixButtons: "_mixButtons_ciu76_145",
	muteToggle: "_muteToggle_ciu76_147",
	soloToggle: "_soloToggle_ciu76_148",
	clearToggle: "_clearToggle_ciu76_149",
	swapToggle: "_swapToggle_ciu76_149",
	sequenceBody: "_sequenceBody_ciu76_151",
	step: "_step_ciu76_151",
	stepCell: "_stepCell_ciu76_153",
	sequenceTop: "_sequenceTop_ciu76_155",
	lcd: "_lcd_ciu76_156",
	lcdDots: "_lcdDots_ciu76_159",
	numberField: "_numberField_ciu76_160",
	fader: "_fader_ciu76_163",
	swingField: "_swingField_ciu76_171",
	transport: "_transport_ciu76_173",
	playButton: "_playButton_ciu76_174",
	transportCaption: "_transportCaption_ciu76_176",
	steps: "_steps_ciu76_177",
	stepLed: "_stepLed_ciu76_179",
	stepNumber: "_stepNumber_ciu76_183",
	sequenceHint: "_sequenceHint_ciu76_184",
	lcdStack: "_lcdStack_ciu76_186",
	stepTransport: "_stepTransport_ciu76_187",
	transportKeys: "_transportKeys_ciu76_188",
	stepEditButton: "_stepEditButton_ciu76_190",
	stepEditor: "_stepEditor_ciu76_193",
	meters: "_meters_ciu76_195",
	meterRow: "_meterRow_ciu76_196",
	muteButton: "_muteButton_ciu76_197",
	rackBottom: "_rackBottom_ciu76_198",
	aboutButton: "_aboutButton_ciu76_199",
	keyboardPanel: "_keyboardPanel_ciu76_200",
	keyboardTop: "_keyboardTop_ciu76_201",
	keyHint: "_keyHint_ciu76_201",
	keyControls: "_keyControls_ciu76_203",
	octaveControls: "_octaveControls_ciu76_204",
	keysToggle: "_keysToggle_ciu76_204",
	piano: "_piano_ciu76_205",
	playSurface: "_playSurface_ciu76_207",
	wheels: "_wheels_ciu76_208",
	wheelSlot: "_wheelSlot_ciu76_209",
	wheel: "_wheel_ciu76_208",
	wheelRidges: "_wheelRidges_ciu76_212",
	wheelMark: "_wheelMark_ciu76_213",
	wheelLabel: "_wheelLabel_ciu76_216",
	whiteKey: "_whiteKey_ciu76_220",
	blackKey: "_blackKey_ciu76_222",
	toastAnchor: "_toastAnchor_ciu76_225",
	toast: "_toast_ciu76_225",
	library: "_library_ciu76_228",
	libraryHeading: "_libraryHeading_ciu76_229",
	libraryGrid: "_libraryGrid_ciu76_230",
	presetBrowser: "_presetBrowser_ciu76_232",
	presetActions: "_presetActions_ciu76_233",
	sectionLabel: "_sectionLabel_ciu76_234",
	presetList: "_presetList_ciu76_235",
	presetRow: "_presetRow_ciu76_236",
	presetLoad: "_presetLoad_ciu76_238",
	presetConfirm: "_presetConfirm_ciu76_241",
	dangerButton: "_dangerButton_ciu76_242",
	presetEmpty: "_presetEmpty_ciu76_243",
	factoryCategory: "_factoryCategory_ciu76_245",
	factoryCategoryLabel: "_factoryCategoryLabel_ciu76_245",
	factoryGrid: "_factoryGrid_ciu76_246",
	saveDialog: "_saveDialog_ciu76_247",
	saveTitle: "_saveTitle_ciu76_248",
	saveWarning: "_saveWarning_ciu76_250",
	saveNote: "_saveNote_ciu76_251",
	saveButtons: "_saveButtons_ciu76_252",
	saveButton: "_saveButton_ciu76_252",
	miniDevice: "_miniDevice_ciu76_253",
	routingBar: "_routingBar_ciu76_254",
	legend: "_legend_ciu76_255",
	portGroups: "_portGroups_ciu76_257",
	portGroup: "_portGroup_ciu76_257",
	portHeading: "_portHeading_ciu76_257",
	portRow: "_portRow_ciu76_257",
	socketControl: "_socketControl_ciu76_257",
	jacks: "_jacks_ciu76_259",
	socket: "_socket_ciu76_257",
	trim: "_trim_ciu76_262",
	cables: "_cables_ciu76_265",
	cableHits: "_cableHits_ciu76_265",
	cable: "_cable_ciu76_265",
	cableLine: "_cableLine_ciu76_269",
	cableShadow: "_cableShadow_ciu76_269",
	cableHit: "_cableHit_ciu76_265",
	loosePlug: "_loosePlug_ciu76_271",
	helpBackdrop: "_helpBackdrop_ciu76_273",
	help: "_help_ciu76_273",
	helpHeading: "_helpHeading_ciu76_273",
	about: "_about_ciu76_199",
	aboutFacts: "_aboutFacts_ciu76_275",
	aboutTagline: "_aboutTagline_ciu76_275",
	aboutCopyright: "_aboutCopyright_ciu76_275",
	exportControls: "_exportControls_ciu76_282",
	hitLed: "_hitLed_ciu76_282",
	globalControls: "_globalControls_ciu76_318",
	globalTransport: "_globalTransport_ciu76_319",
	playStoppedButton: "_playStoppedButton_ciu76_323",
	rewindButton: "_rewindButton_ciu76_323",
	clearAllButton: "_clearAllButton_ciu76_324",
	positionField: "_positionField_ciu76_329",
	globalPosition: "_globalPosition_ciu76_330",
	clickButton: "_clickButton_ciu76_332",
	clickLed: "_clickLed_ciu76_332",
	keyboardTarget: "_keyboardTarget_ciu76_334",
	midiToggle: "_midiToggle_ciu76_336",
	midiLed: "_midiLed_ciu76_337",
	routingHint: "_routingHint_ciu76_339",
	moduleNameButton: "_moduleNameButton_ciu76_341",
	moduleTransport: "_moduleTransport_ciu76_344",
	clearPatternButton: "_clearPatternButton_ciu76_348",
	performancePads: "_performancePads_ciu76_352",
	orbitEditor: "_orbitEditor_ciu76_358",
	orbitVoiceEditor: "_orbitVoiceEditor_ciu76_359",
	orbitEditorHeading: "_orbitEditorHeading_ciu76_360",
	orbitSteps: "_orbitSteps_ciu76_364",
	groupControls: "_groupControls_ciu76_372",
	grMeter: "_grMeter_ciu76_389",
	grUnit: "_grUnit_ciu76_392",
	grNeedle: "_grNeedle_ciu76_393",
	eqGraphic: "_eqGraphic_ciu76_408",
	countInField: "_countInField_ciu76_418",
	soundEditor: "_soundEditor_ciu76_452",
	editorHeading: "_editorHeading_ciu76_453",
	fmDisplay: "_fmDisplay_ciu76_456",
	operatorTabs: "_operatorTabs_ciu76_458",
	console: "_console_ciu76_496",
	channelStrip: "_channelStrip_ciu76_497",
	mixBus: "_mixBus_ciu76_497",
	scribble: "_scribble_ciu76_499",
	channelSource: "_channelSource_ciu76_501",
	scribbleLink: "_scribbleLink_ciu76_503",
	faderValue: "_faderValue_ciu76_508",
	faderBay: "_faderBay_ciu76_511",
	faderScale: "_faderScale_ciu76_512",
	faderSlot: "_faderSlot_ciu76_514",
	faderCap: "_faderCap_ciu76_516",
	levelMeter: "_levelMeter_ciu76_519",
	processorHint: "_processorHint_ciu76_537",
	britPanel: "_britPanel_ciu76_554",
	britSection: "_britSection_ciu76_555",
	britWell: "_britWell_ciu76_557",
	panelLegend: "_panelLegend_ciu76_558",
	marconi: "_marconi_ciu76_562",
	marconiRing: "_marconiRing_ciu76_562",
	marconiSkirt: "_marconiSkirt_ciu76_567",
	marconiFlutes: "_marconiFlutes_ciu76_568",
	marconiDome: "_marconiDome_ciu76_570",
	marconiPointer: "_marconiPointer_ciu76_572",
	ringPointer: "_ringPointer_ciu76_577",
	britCurve: "_britCurve_ciu76_580",
	britSwitch: "_britSwitch_ciu76_582",
	britLamp: "_britLamp_ciu76_584",
	talonPanel: "_talonPanel_ciu76_588",
	talonSection: "_talonSection_ciu76_589",
	talonWell: "_talonWell_ciu76_591",
	talonKnob: "_talonKnob_ciu76_592",
	talonGrip: "_talonGrip_ciu76_595",
	talonCap: "_talonCap_ciu76_596",
	talonIndex: "_talonIndex_ciu76_597",
	talonLamps: "_talonLamps_ciu76_600",
	talonLed: "_talonLed_ciu76_605",
	talonLatches: "_talonLatches_ciu76_607",
	talonPush: "_talonPush_ciu76_608",
	talonMeter: "_talonMeter_ciu76_610",
	talonSwitch: "_talonSwitch_ciu76_617",
	talonLamp: "_talonLamp_ciu76_600",
	talonOutput: "_talonOutput_ciu76_621",
	rollBrush: "_rollBrush_ciu76_636",
	orbitDevice: "_orbitDevice_ciu76_700",
	engineSwitch: "_engineSwitch_ciu76_717",
	engineCaption: "_engineCaption_ciu76_719",
	togglePlate: "_togglePlate_ciu76_721",
	toggleLegend: "_toggleLegend_ciu76_723",
	toggle: "_toggle_ciu76_721",
	toggleSlot: "_toggleSlot_ciu76_733",
	toggleKnob: "_toggleKnob_ciu76_736",
	toggleBrim: "_toggleBrim_ciu76_739",
	toggleRib: "_toggleRib_ciu76_741",
	toggleCap: "_toggleCap_ciu76_743",
	dictatorBody: "_dictatorBody_ciu76_762",
	armButton: "_armButton_ciu76_766",
	armLed: "_armLed_ciu76_767",
	recordLed: "_recordLed_ciu76_767",
	recordBlink: "_recordBlink_ciu76_1",
	quantizeRow: "_quantizeRow_ciu76_771",
	lampButton: "_lampButton_ciu76_774",
	lampLed: "_lampLed_ciu76_775",
	noteStripFrame: "_noteStripFrame_ciu76_777",
	stripSeek: "_stripSeek_ciu76_777",
	noteStrip: "_noteStrip_ciu76_777",
	playhead: "_playhead_ciu76_780",
	dictatorActions: "_dictatorActions_ciu76_781",
	playsControl: "_playsControl_ciu76_782",
	offsetControl: "_offsetControl_ciu76_782",
	midiTracks: "_midiTracks_ciu76_783",
	recordButton: "_recordButton_ciu76_784",
	editButton: "_editButton_ciu76_789",
	pianoRoll: "_pianoRoll_ciu76_790",
	rollTools: "_rollTools_ciu76_791",
	rollToolGroup: "_rollToolGroup_ciu76_792",
	rollStatus: "_rollStatus_ciu76_796",
	rollClose: "_rollClose_ciu76_797",
	rollScroller: "_rollScroller_ciu76_798",
	rollCanvas: "_rollCanvas_ciu76_799",
	rollRulerRow: "_rollRulerRow_ciu76_800",
	rollCorner: "_rollCorner_ciu76_801",
	rollLaneLabel: "_rollLaneLabel_ciu76_801",
	rollRuler: "_rollRuler_ciu76_800",
	rollBody: "_rollBody_ciu76_803",
	rollKeys: "_rollKeys_ciu76_804",
	rollWhite: "_rollWhite_ciu76_805",
	rollBlack: "_rollBlack_ciu76_805",
	rollGrid: "_rollGrid_ciu76_807",
	rollShade: "_rollShade_ciu76_809",
	rollRowLine: "_rollRowLine_ciu76_809",
	rollOctave: "_rollOctave_ciu76_809",
	rollBar: "_rollBar_ciu76_810",
	rollBeat: "_rollBeat_ciu76_810",
	rollStep: "_rollStep_ciu76_810",
	rollNote: "_rollNote_ciu76_811",
	rollTake: "_rollTake_ciu76_812",
	rollCursor: "_rollCursor_ciu76_813",
	rollMarquee: "_rollMarquee_ciu76_814",
	rollLaneRow: "_rollLaneRow_ciu76_816",
	rollLane: "_rollLane_ciu76_801",
	rollLaneTabs: "_rollLaneTabs_ciu76_820",
	rollLaneCentre: "_rollLaneCentre_ciu76_825",
	rollWheelArea: "_rollWheelArea_ciu76_826",
	rollWheelLine: "_rollWheelLine_ciu76_826",
	moduleSlot: "_moduleSlot_ciu76_835",
	moduleTape: "_moduleTape_ciu76_839",
	tapeBody: "_tapeBody_ciu76_843",
	tapePeel: "_tapePeel_ciu76_845",
	tapeField: "_tapeField_ciu76_846",
	tapeText: "_tapeText_ciu76_847"
};
// src/components/Knob.tsx
function Qa(e, t) {
	return e.choices ? e.choices[t] ?? "" : e.unit === "ms" ? t ? `${t > 0 ? "+" : "−"}${Math.abs(t)}ms` : "On beat" : e.unit === "Hz" && t >= 1e3 ? `${(t / 1e3).toFixed(1)}k` : e.unit === "s" && t < .001 ? `${Math.round(t * 1e6)}μs` : e.unit === "s" && t < 1 ? `${e.step < .001 ? Number((t * 1e3).toFixed(2)) : Math.round(t * 1e3)}ms` : `${Number(t.toFixed(2))}${e.unit ?? ""}`;
}
function $a({ param: e, value: t, onChange: n, prefix: r = "", format: i, disabled: a = !1, travel: o = 130 }) {
	let s = u(null), c = hr(e, t), l = Math.max(4, Math.ceil(-Math.log10(e.step)));
	function d(t) {
		let r = Math.max(0, Math.min(1, t)), i = e.logarithmic ? e.min * (e.max / e.min) ** r : e.min + r * (e.max - e.min);
		n(Math.max(e.min, Math.min(e.max, Number((Math.round(i / e.step) * e.step).toFixed(l)))));
	}
	function f(e) {
		e.isPrimary && e.button === 0 && (s.current = {
			y: e.clientY,
			fraction: c
		}, e.currentTarget.setPointerCapture(e.pointerId), e.preventDefault());
	}
	let p = i ? i(t) : Qa(e, t);
	return {
		props: {
			role: "slider",
			tabIndex: a ? -1 : 0,
			"aria-disabled": a || void 0,
			"aria-label": `${r} ${e.label}`.trim(),
			"aria-valuemin": e.min,
			"aria-valuemax": e.max,
			"aria-valuenow": t,
			"aria-valuetext": p,
			onPointerDown: a ? void 0 : f,
			onPointerMove: (e) => {
				s.current && d(s.current.fraction + (s.current.y - e.clientY) / o);
			},
			onPointerUp: () => {
				s.current = null;
			},
			onPointerCancel: () => {
				s.current = null;
			},
			onLostPointerCapture: () => {
				s.current = null;
			},
			onDoubleClick: a ? void 0 : () => n(e.initial),
			onKeyDown: (r) => {
				!a && [
					"ArrowUp",
					"ArrowRight",
					"ArrowDown",
					"ArrowLeft",
					"Home",
					"End"
				].includes(r.key) && (r.preventDefault(), r.key === "Home" ? n(e.min) : r.key === "End" ? n(e.max) : e.logarithmic ? d(c + (["ArrowUp", "ArrowRight"].includes(r.key) ? .025 : -.025)) : n(Math.max(e.min, Math.min(e.max, Number((t + (["ArrowUp", "ArrowRight"].includes(r.key) ? e.step : -e.step)).toFixed(l))))));
			}
		},
		fraction: c,
		display: p
	};
}
function eo({ param: e, value: t, onChange: n, prefix: r = "", format: i, trim: a = !1, disabled: o = !1, caption: s }) {
	let { props: c, fraction: l, display: u } = $a({
		param: e,
		value: t,
		onChange: n,
		prefix: r,
		format: i,
		disabled: o
	}), d = /* @__PURE__ */ h("div", {
		className: a ? `${$.dial} ${$.trim}` : $.dial,
		...c,
		title: a ? `${e.label} ${u}` : void 0,
		children: [/* @__PURE__ */ m("span", { className: $.dialTicks }), /* @__PURE__ */ m("span", {
			className: $.dialCap,
			style: { transform: `rotate(${-135 + l * 270}deg)` },
			children: /* @__PURE__ */ m("span", {})
		})]
	});
	return a ? d : /* @__PURE__ */ h("div", {
		className: $.knobControl,
		title: e.hint,
		children: [
			/* @__PURE__ */ m("span", {
				className: $.controlLabel,
				children: s ?? e.label
			}),
			d,
			/* @__PURE__ */ m("span", {
				className: $.knobValue,
				children: u
			})
		]
	});
}
// src/components/CableLayer.tsx
var to = (e) => `${e.moduleId}:${e.portId}`, no = (e, t) => {
	let n = Math.min(140, Math.abs(e.y - t.y) * .2 + Math.abs(e.x - t.x) * .25 + 40);
	return `M${e.x},${e.y} C${e.x + 12},${e.y + n} ${t.x - 12},${t.y + n} ${t.x},${t.y}`;
};
function ro({ patch: e, rackRef: t, selected: n, onSelect: r, drag: i }) {
	let [a, o] = d({}), [c, l] = d(null);
	s(() => {
		let e = t.current;
		if (!e) return;
		function n() {
			let t = e.getBoundingClientRect(), n = {};
			e.querySelectorAll("[data-port-key]").forEach((r) => {
				let i = r.getBoundingClientRect();
				n[r.dataset.portKey] = {
					x: i.x - t.x + i.width / 2 + e.scrollLeft,
					y: i.y - t.y + i.height / 2 + e.scrollTop
				};
			}), o(n);
		}
		n();
		let r = new ResizeObserver(n);
		return r.observe(e), e.querySelectorAll("article").forEach((e) => r.observe(e)), window.addEventListener("resize", n), () => {
			r.disconnect(), window.removeEventListener("resize", n);
		};
	}, [e.modules, t]);
	let u = (t) => {
		let n = e.modules.find((e) => e.id === t.moduleId), r = Z[n.type].ports, i = rn(e, t), a = on(r, i), o = n.type === "mixer" && i.direction === "in" ? `Channel ${i.id.toUpperCase()}: ${Yn(e, n.id, i.id).source}` : i.label;
		return `${Z[n.type].name} ${o}${a && a > 1 ? ` ${a}` : ""}`;
	}, f = i && rn(e, i.anchor), g = i && a[to(i.anchor)], _ = i && (i.target ? a[to(i.target)] : i.point), v = f && g && _ ? f.direction === "out" ? no(g, _) : no(_, g) : null, y = e.cables.flatMap((t) => {
		let n = a[to(t.from)], r = a[to(t.to)];
		return n && r && t.id !== i?.cableId ? [{
			cable: t,
			path: no(n, r),
			kind: rn(e, t.from).kind
		}] : [];
	});
	return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("svg", {
		className: $.cableHits,
		"aria-label": "Patch cables",
		"data-analytics-private": e.modules.some((e) => e.label) ? "" : void 0,
		children: y.map(({ cable: e, path: t }) => /* @__PURE__ */ m("path", {
			className: $.cableHit,
			d: t,
			role: "button",
			tabIndex: 0,
			"aria-label": `Cable from ${u(e.from)} to ${u(e.to)}`,
			onClick: () => r(e.id),
			onPointerEnter: () => l(e.id),
			onPointerLeave: () => l((t) => t === e.id ? null : t),
			onKeyDown: (t) => {
				(t.key === "Enter" || t.key === " ") && (t.preventDefault(), r(e.id));
			}
		}, e.id))
	}), /* @__PURE__ */ h("svg", {
		className: $.cables,
		"aria-hidden": "true",
		children: [y.map(({ cable: e, path: t, kind: r }) => /* @__PURE__ */ h("g", {
			className: $.cable,
			"data-kind": r,
			"data-selected": n === e.id,
			"data-hovered": c === e.id,
			children: [/* @__PURE__ */ m("path", {
				className: $.cableShadow,
				d: t
			}), /* @__PURE__ */ m("path", {
				className: $.cableLine,
				d: t
			})]
		}, e.id)), v && /* @__PURE__ */ h("g", {
			className: $.cable,
			"data-kind": f.kind,
			"data-held": "true",
			"data-snapped": !!i.target,
			"data-invalid": !!i.error,
			children: [
				/* @__PURE__ */ m("path", {
					className: $.cableShadow,
					d: v
				}),
				/* @__PURE__ */ m("path", {
					className: $.cableLine,
					d: v
				}),
				!i.target && /* @__PURE__ */ m("circle", {
					className: $.loosePlug,
					cx: _.x,
					cy: _.y,
					r: 8
				})
			]
		})]
	})] });
}
// src/audio/studio-processor.js
var io = [
	1e-4,
	3e-4,
	.001,
	.003,
	.01,
	.03
], ao = [
	.1,
	.3,
	.6,
	1.2
], oo = [
	1,
	2,
	3,
	4,
	6,
	10,
	20,
	100
], so = [
	35,
	60,
	110,
	220
], co = [
	360,
	700,
	1600,
	3200,
	4800,
	7200
], lo = [
	0,
	50,
	80,
	160,
	300
], uo = (e) => 10 ** (e / 20), fo = [
	1,
	0,
	0,
	0,
	0
];
function po(e, t, n, r, i) {
	if (!t) return fo.slice();
	let a = 2 * Math.PI * Math.min(t, i * .45) / i, o = Math.cos(a), s = Math.sin(a), c = 10 ** (n / 40), l = s / (2 * r), u = s * Math.sqrt(2 * c), d, f, p, m, h, g;
	if (e === "pole") {
		let e = Math.tan(a / 2);
		return [
			1 / (1 + e),
			-1 / (1 + e),
			0,
			(e - 1) / (e + 1),
			0
		];
	}
	return e === "highpass" ? [d, f, p, m, h, g] = [
		(1 + o) / 2,
		-(1 + o),
		(1 + o) / 2,
		1 + l,
		-2 * o,
		1 - l
	] : e === "bell" ? [d, f, p, m, h, g] = [
		1 + l * c,
		-2 * o,
		1 - l * c,
		1 + l / c,
		-2 * o,
		1 - l / c
	] : e === "low" ? [d, f, p, m, h, g] = [
		c * (c + 1 - (c - 1) * o + u),
		2 * c * (c - 1 - (c + 1) * o),
		c * (c + 1 - (c - 1) * o - u),
		c + 1 + (c - 1) * o + u,
		-2 * (c - 1 + (c + 1) * o),
		c + 1 + (c - 1) * o - u
	] : [d, f, p, m, h, g] = [
		c * (c + 1 + (c - 1) * o + u),
		-2 * c * (c - 1 + (c + 1) * o),
		c * (c + 1 + (c - 1) * o - u),
		c + 1 - (c - 1) * o + u,
		2 * (c - 1 - (c + 1) * o),
		c + 1 - (c - 1) * o - u
	], [
		d / m,
		f / m,
		p / m,
		h / m,
		g / m
	];
}
function mo(e, t) {
	let n = lo[e.hpf] ?? 0;
	return [
		po("pole", n, 0, 1, t),
		po("highpass", n, 0, 1, t),
		po("low", so[e.lfFreq] ?? 110, e.lfGain, .7, t),
		po("bell", co[e.midFreq] ?? 1600, e.midGain, .75, t),
		po("high", 12e3, e.hfGain, .7, t)
	];
}
function ho(e, t, n = 48e3) {
	if (e.active) return 0;
	let r = 2 * Math.PI * t / n, i = (e, t, n) => Math.hypot(e + t * Math.cos(r) + n * Math.cos(2 * r), t * Math.sin(r) + n * Math.sin(2 * r));
	return mo(e, n).reduce((e, [t, n, r, a, o]) => e + 20 * Math.log10(i(t, n, r) / i(1, a, o)), 0);
}
function go(e, t) {
	let n, r, i;
	return e === "cohere" ? (n = [
		2,
		4,
		10
	][t.ratio] ?? 4, r = t.threshold + [
		-3,
		0,
		2
	][t.ratio], i = [
		9,
		6,
		3
	][t.ratio]) : (n = oo[t.ratio] ?? 6, r = [
		-18,
		-26,
		-24,
		-22,
		-20,
		-18,
		-16,
		-18
	][t.ratio], i = [
		0,
		15,
		12,
		9,
		6,
		4,
		2,
		3
	][t.ratio], t.fierce && (n = Math.max(12, n * 2), r -= 3, i = 2)), [
		1 - 1 / n,
		r,
		i
	];
}
function _o(e, t, n, r) {
	if (!t) return 0;
	let i = e - n;
	return i <= -r / 2 ? 0 : i >= r / 2 ? -i * t : -t * (i + r / 2) ** 2 / (2 * r);
}
var vo = class {
	constructor(e) {
		this.c = fo.slice(), this.target = fo.slice(), this.z1 = 0, this.z2 = 0, this.smooth = 1 - Math.exp(-1 / (e * .008));
	}
	set(e, t) {
		this.target = e, t && (this.c = e.slice());
	}
	run(e) {
		let t = this.c;
		for (let e = 0; e < 5; e++) t[e] += (this.target[e] - t[e]) * this.smooth;
		let n = t[0] * e + this.z1;
		return this.z1 = t[1] * e - t[3] * n + this.z2, this.z2 = t[2] * e - t[4] * n, n;
	}
}, yo = Float64Array.from({ length: 49 }, (e, t) => {
	let n = t - 24, r = .1125;
	return (n ? Math.sin(2 * Math.PI * r * n) / (Math.PI * n) : 2 * r) * (.42 - .5 * Math.cos(2 * Math.PI * t / 48) + .08 * Math.cos(4 * Math.PI * t / 48));
}), bo = yo.reduce((e, t) => e + t, 0);
for (let e = 0; e < yo.length; e++) yo[e] /= bo;
var xo = class {
	constructor() {
		this.buffer = /* @__PURE__ */ new Float64Array(49), this.index = 0;
	}
	push(e) {
		this.buffer[this.index] = e, this.index = (this.index + 1) % 49;
	}
	run(e) {
		this.buffer[this.index] = e;
		let t = 0, n = this.index;
		for (let e = 0; e < 49; e++) t += yo[e] * this.buffer[n], --n < 0 && (n = 48);
		return this.index = (this.index + 1) % 49, t;
	}
}, So = class {
	constructor() {
		this.buffer = /* @__PURE__ */ new Float64Array(13), this.index = 0;
	}
	push(e) {
		this.index = this.index ? this.index - 1 : 12, this.buffer[this.index] = e;
	}
	run(e) {
		let t = 0, n = this.index;
		for (let r = e; r < 49; r += 4) t += yo[r] * this.buffer[n], ++n > 12 && (n = 0);
		return t;
	}
}, Co = class {
	constructor() {
		this.buffer = /* @__PURE__ */ new Float64Array(12), this.index = 0;
	}
	run(e) {
		let t = this.buffer[this.index];
		return this.buffer[this.index] = e, this.index = (this.index + 1) % this.buffer.length, t;
	}
}, wo = class {
	constructor(e) {
		this.up = new So(), this.down = new xo(), this.clean = new Co(), this.previous = 0, this.blocked = 0, this.dc = Math.exp(-2 * Math.PI * 5 / e);
	}
	run(e, t, n) {
		let r = 0, i = Math.tanh(n), a = t * (1 - i * i);
		this.up.push(e * 4);
		for (let e = 0; e < 4; e++) {
			let o = this.up.run(e), s = (Math.tanh(t * o + n) - i) / a;
			e === 0 ? r = this.down.run(s - o) : this.down.push(s - o);
		}
		return this.blocked = r - this.previous + this.dc * this.blocked, this.previous = r, this.clean.run(e) + this.blocked;
	}
}, To = class {
	constructor(e, t) {
		this.type = e, this.rate = t, this.params = null, this.events = [], this.disposed = !1, this.reduction = 0, this.gain = [0, 0], this.memory = [0, 0], this.input = 1, this.output = 1, this.wet = 1, this.drive = 0, this.smooth = 1 - Math.exp(-1 / (t * .008)), this.channels = Array.from({ length: 2 }, () => ({
			filters: Array.from({ length: 5 }, () => new vo(t)),
			hp: new vo(t),
			emphasis: new vo(t),
			audioPole: new vo(t),
			audioHp: new vo(t),
			color: new wo(t),
			dry: new Co(),
			clean: new Co(),
			amount: .15,
			bias: 0
		}));
	}
	enqueue(e) {
		this.events.push(e), this.events.sort((e, t) => e.time - t.time);
	}
	configure(e) {
		let t = !this.params;
		this.params = { ...e }, this.inputTarget = uo(this.type === "talon" ? e.input : 0), this.outputTarget = uo(e.output), this.wetTarget = +!e.active, this.driveTarget = e.drive ?? 0, t && (this.input = this.inputTarget, this.output = this.outputTarget, this.wet = this.wetTarget, this.drive = this.driveTarget), this.type !== "brit" && (this.curveTarget = go(this.type, e), this.linkTarget = this.type === "cohere" ? 1 : e.link, this.attackTarget = this.type === "cohere" ? io[e.attack] : e.attack, this.releaseTarget = this.type === "cohere" ? ao[e.release] ?? .3 : e.release, t && (this.curve = this.curveTarget.slice(), this.link = this.linkTarget, this.attack = this.attackTarget, this.release = this.releaseTarget));
		for (let n of this.channels) {
			this.type === "brit" && mo(e, this.rate).forEach((e, r) => n.filters[r].set(e, t));
			let r = this.type === "cohere" ? [
				0,
				30,
				60,
				106,
				125,
				185
			][e.scHpf] : e.detectorHp ? 80 : 0;
			n.hp.set(po("highpass", r, 0, Math.SQRT1_2, this.rate), t), n.emphasis.set(po("bell", 6e3, e.detectorBand ? 10 : 0, 1, this.rate), t), n.audioPole.set(po("pole", e.audioHp ? 49.01 : 0, 0, 1, this.rate), t), n.audioHp.set(po("highpass", e.audioHp ? 44.915 : 0, 0, .691, this.rate), t), t && this.type === "talon" && (n.amount = [
				.15,
				.8,
				1.5
			][e.color], n.bias = e.color === 1 ? .3 : 0);
		}
	}
	envelope(e, t) {
		let n = this.params, r = _o(e, this.curve[0], this.curve[1], this.curve[2]), i = this.gain[t];
		this.memory[t] += (Math.max(0, -i) - this.memory[t]) * (1 - Math.exp(-1 / (this.rate * .6)));
		let a = this.release;
		this.type === "cohere" && n.release === 4 && (a = .1 + Math.min(1.1, this.memory[t] * .09)), this.type === "talon" && (n.ratio === 5 ? a = Math.min(20, this.release * (1 + this.memory[t] * .9)) : n.ratio === 7 ? a *= .45 + Math.min(1.5, Math.max(0, -i) / 15) : a *= [
			1,
			1.15,
			1.05,
			1,
			.9,
			1,
			.8,
			1
		][n.ratio], n.ratio !== 5 && (a = Math.min(3.5, a)), n.fierce && (a *= .65));
		let o = r < i ? this.attack : a;
		return this.gain[t] += (r - i) * (1 - Math.exp(-1 / (o * this.rate))), uo(this.gain[t]);
	}
	render(e, t, n = 0) {
		if (this.disposed) {
			t.forEach((e) => e.fill(0));
			return;
		}
		let r = t[0].length;
		for (let i = 0; i < r; i++) {
			let r = (n + i) / this.rate;
			for (; this.events.length && this.events[0].time <= r;) this.configure(this.events.shift().params);
			if (!this.params) {
				t.forEach((e) => {
					e[i] = 0;
				});
				continue;
			}
			let a = this.params;
			this.input += (this.inputTarget - this.input) * this.smooth, this.output += (this.outputTarget - this.output) * this.smooth, this.wet += (this.wetTarget - this.wet) * this.smooth, this.drive += (this.driveTarget - this.drive) * this.smooth;
			let o = e[0]?.[i] ?? 0, s = e[1]?.[i] ?? o, c = o * this.input, l = s * this.input, u = 1, d = 1;
			if (this.type !== "brit") {
				for (let e = 0; e < 3; e++) this.curve[e] += (this.curveTarget[e] - this.curve[e]) * this.smooth;
				this.link += (this.linkTarget - this.link) * this.smooth, this.attack += (this.attackTarget - this.attack) * this.smooth, this.release += (this.releaseTarget - this.release) * this.smooth;
				let e = this.channels[0], t = this.channels[1], n = 20 * Math.log10(Math.max(1e-12, Math.abs(e.emphasis.run(e.hp.run(c))))), r = 20 * Math.log10(Math.max(1e-12, Math.abs(t.emphasis.run(t.hp.run(l))))), i = Math.max(n, r);
				this.envelope(n + this.link * (i - n), 0), this.envelope(r + this.link * (i - r), 1);
				let a = Math.min(this.gain[0], this.gain[1]), o = Math.max(this.memory[0], this.memory[1]), s = this.link * this.smooth;
				for (let e = 0; e < 2; e++) this.gain[e] += (a - this.gain[e]) * s, this.memory[e] += (o - this.memory[e]) * s;
				u = uo(this.gain[0]), d = uo(this.gain[1]), this.reduction = Math.min(this.gain[0], this.gain[1]) * this.wet;
			}
			for (let e = 0; e < t.length; e++) {
				let n = this.channels[e], r = e === 0 ? o : s, f = e === 0 ? c : l;
				if (this.type === "brit") {
					for (let e of n.filters) f = e.run(f);
					f = n.color.run(f, .22 * uo(this.drive), .12);
				} else if (this.type === "talon") {
					f = n.audioHp.run(n.audioPole.run(f * (e === 0 ? u : d)));
					let t = [
						.15,
						.8,
						1.5
					][a.color] * (1 + Math.min(2, -this.gain[e] / 20));
					n.amount += (t - n.amount) * this.smooth, n.bias += ((a.color === 1 ? .3 : 0) - n.bias) * this.smooth, f = n.color.run(f, n.amount, n.bias);
				} else f = n.clean.run(f * (e === 0 ? u : d));
				let p = n.dry.run(r);
				t[e][i] = p + this.wet * (f * this.output - p);
			}
		}
	}
};
if (typeof registerProcessor < "u") {
	class e extends AudioWorkletProcessor {
		constructor(e) {
			super(), this.dsp = new To(e.processorOptions.type, sampleRate), this.meterFrames = 0, this.port.onmessage = ({ data: e }) => {
				e.type === "flush" ? this.port.postMessage({ id: e.id }) : e.type === "dispose" ? (this.dsp.disposed = !0, this.dsp.events = []) : this.dsp.enqueue(e);
			};
		}
		process(e, t) {
			return this.dsp.render(e[0] ?? [], t[0], currentFrame), this.meterFrames += t[0][0].length, this.meterFrames >= sampleRate / 25 && (this.meterFrames = 0, this.port.postMessage({ reduction: this.dsp.reduction })), !this.dsp.disposed;
		}
	}
	registerProcessor("rackloose-studio-v1", e);
}
// src/components/Glyphs.tsx
var Eo = (e) => e.map((t, n) => `${n ? "L" : "M"}${(2 + n * 44 / (e.length - 1)).toFixed(1)} ${(17 - t * 14).toFixed(1)}`).join(" ");
function Do(e, t) {
	let n = t, r = .5, i = Array.from({ length: 25 }, () => (n = n * 16807 % 2147483647, r += (n / 2147483647 - r) * e, r)), a = Math.min(...i), o = Math.max(...i);
	return Eo(i.map((e) => .1 + (e - a) / (o - a) * .8));
}
var Oo = {
	Sine: Eo(Array.from({ length: 33 }, (e, t) => .5 + .5 * Math.sin(t / 32 * Math.PI * 4))),
	Triangle: Eo([
		0,
		1,
		0,
		1,
		0
	]),
	Saw: "M2 17L24 3V17L46 3V17",
	Square: "M2 17V3H13V17H24V3H35V17H46V3",
	Pulse: "M2 17V3H8V17H24V3H30V17H46",
	"Saw + Pulse": "M2 17L13 13.5V6.5L24 3V17L35 13.5V6.5L46 3V17",
	"Low-pass": "M2 7H24C30 7 31 3 33 6C35 10 38 17 46 18",
	"High-pass": "M2 18C10 17 13 10 15 6C17 3 18 7 24 7H46",
	"Band-pass": "M2 18C14 17 18 4 24 4C30 4 34 17 46 18",
	White: Do(1, 7),
	Pink: Do(.45, 11),
	Brown: Do(.16, 23),
	Bell: "M2 14C14 14 18 4 24 4C30 4 34 14 46 14",
	"Low shelf": "M2 6H14C20 6 22 14 30 14H46",
	"High shelf": "M2 14H18C26 14 28 6 34 6H46"
};
function ko({ param: e, value: t }) {
	let n = e.choices?.[t] ?? "", r = Oo[n === "Shelf" ? e.id === "hfBell" ? "High shelf" : "Low shelf" : n];
	return r ? /* @__PURE__ */ m("svg", {
		className: $.choiceGlyph,
		viewBox: "0 0 48 20",
		"aria-hidden": "true",
		children: /* @__PURE__ */ m("path", { d: r })
	}) : null;
}
function Ao({ params: e, brit: t = !1, rate: n = 48e3 }) {
	let r = ka(e, 24e3), i = (e) => 25 - Math.max(-18, Math.min(18, e)) * 22 / 18, a = Array.from({ length: 72 }, (a, o) => {
		let s = 20 * 1e3 ** (o / 71);
		return `${o ? "L" : "M"}${(3 + o * 114 / 71).toFixed(1)} ${i(t ? ho(e, s, n) : r.reduce((e, t) => e + Aa(t, s, 48e3), 0)).toFixed(1)}`;
	}).join("");
	return /* @__PURE__ */ h("svg", {
		className: $.eqGraphic,
		viewBox: "0 0 120 50",
		role: t ? "img" : void 0,
		"aria-label": t ? `BRIT filter response, 20 Hz to 20 kHz, at ${n / 1e3} kHz` : void 0,
		"aria-hidden": !t || void 0,
		"data-bypassed": e.active === 1,
		children: [
			[
				100,
				1e3,
				1e4
			].map((e) => /* @__PURE__ */ m("line", {
				x1: 3 + Math.log10(e / 20) / 3 * 114,
				x2: 3 + Math.log10(e / 20) / 3 * 114,
				y1: "3",
				y2: "47"
			}, e)),
			/* @__PURE__ */ m("line", {
				x1: "3",
				x2: "117",
				y1: "25",
				y2: "25"
			}),
			/* @__PURE__ */ m("path", { d: a })
		]
	});
}
function jo({ reduction: e, label: t, max: n = 20 }) {
	let r = Math.min(n, Math.max(0, -e)), i = (e) => 45 - e / n * 90, a = (e, t) => {
		let n = (i(e) - 90) * Math.PI / 180;
		return [60 + Math.cos(n) * t, 60 + Math.sin(n) * t].map((e) => Number(e.toFixed(1)));
	};
	return /* @__PURE__ */ m("div", {
		className: $.grMeter,
		role: "meter",
		"aria-label": t,
		"aria-valuemin": 0,
		"aria-valuemax": n,
		"aria-valuenow": r,
		"aria-valuetext": `${r} dB gain reduction`,
		children: /* @__PURE__ */ h("svg", {
			viewBox: "0 0 120 50",
			"aria-hidden": "true",
			children: [
				/* @__PURE__ */ m("path", { d: `M${a(0, 48).join(" ")}A48 48 0 0 0 ${a(n, 48).join(" ")}` }),
				[
					0,
					n / 4,
					n / 2,
					n * 3 / 4,
					n
				].map((e) => {
					let [t, n] = a(e, 48), [r, i] = a(e, 53), [o, s] = a(e, 40);
					return /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("line", {
						x1: t,
						y1: n,
						x2: r,
						y2: i
					}), /* @__PURE__ */ m("text", {
						x: o,
						y: s,
						textAnchor: "middle",
						dominantBaseline: "middle",
						children: e
					})] }, e);
				}),
				/* @__PURE__ */ m("text", {
					className: $.grUnit,
					x: "8",
					y: "45",
					children: "GR dB"
				}),
				/* @__PURE__ */ m("line", {
					className: $.grNeedle,
					x1: "60",
					y1: "60",
					x2: "60",
					y2: "8",
					style: { transform: `rotate(${i(r)}deg)` }
				})
			]
		})
	});
}
var [Mo, No, , Po] = Z.envelope.params;
function Fo({ params: e }) {
	let t = (t) => 9 + hr(t, e[t.id]) * 24, n = 3 + t(Mo), r = n + t(No), i = 117 - t(Po), a = 40 - e.sustain * 35, o = [
		["A", (3 + n) / 2],
		["D", (n + r) / 2],
		["S", (r + i) / 2],
		["R", (i + 117) / 2]
	];
	return /* @__PURE__ */ h("svg", {
		className: $.envelopeGraphic,
		viewBox: "0 0 120 50",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ m("path", { d: `M3 40L${n.toFixed(1)} 5L${r.toFixed(1)} ${a.toFixed(1)}L${i.toFixed(1)} ${a.toFixed(1)}L117 40` }), o.map(([e, t]) => /* @__PURE__ */ m("text", {
			x: t.toFixed(1),
			y: "48",
			textAnchor: "middle",
			children: e
		}, e))]
	});
}
var Io = {
	play: /* @__PURE__ */ m("path", { d: "M3.5 2.2v9.6L11.6 7z" }),
	pause: /* @__PURE__ */ m("path", { d: "M3 2.2h2.9v9.6H3zM8.1 2.2H11v9.6H8.1z" }),
	stop: /* @__PURE__ */ m("path", { d: "M2.8 2.8h8.4v8.4H2.8z" }),
	reset: /* @__PURE__ */ m("path", { d: "M2.4 2.2h2v9.6h-2zM11.8 2.2v9.6L4.9 7z" }),
	undo: /* @__PURE__ */ m("path", {
		d: "M5.2 2.4 1.6 5.8l3.6 3.4V7.1h3.2a2.6 2.6 0 0 1 0 5.2H6.6v1.5h1.8a4.1 4.1 0 0 0 0-8.2H5.2z",
		transform: "translate(0 -1.2)"
	}),
	redo: /* @__PURE__ */ m("path", {
		d: "M8.8 2.4l3.6 3.4-3.6 3.4V7.1H5.6a2.6 2.6 0 0 0 0 5.2h1.8v1.5H5.6a4.1 4.1 0 0 1 0-8.2h3.2z",
		transform: "translate(0 -1.2)"
	})
};
function Lo({ name: e }) {
	return /* @__PURE__ */ m("svg", {
		className: $.icon,
		viewBox: "0 0 14 14",
		"aria-hidden": "true",
		focusable: "false",
		children: Io[e]
	});
}
// src/components/MixButtons.tsx
function Ro({ mixKey: e, label: t, mix: n, onToggle: r, solo: i = !0, onClear: a, clearable: o, onSwap: s }) {
	let c = n.muted.has(e), l = n.soloed.has(e);
	return /* @__PURE__ */ h("span", {
		className: $.mixButtons,
		children: [
			/* @__PURE__ */ m("button", {
				className: $.muteToggle,
				"aria-label": `Mute ${t}`,
				"aria-pressed": c,
				title: `Mute ${t}`,
				onClick: () => r(e, "muted"),
				children: "M"
			}),
			i && /* @__PURE__ */ m("button", {
				className: $.soloToggle,
				"aria-label": `Solo ${t}`,
				"aria-pressed": l,
				title: `Solo ${t}`,
				onClick: () => r(e, "soloed"),
				children: "S"
			}),
			a && /* @__PURE__ */ m("button", {
				className: $.clearToggle,
				"aria-label": `Clear ${t} mutes and solos`,
				title: `Clear ${t} mutes and solos`,
				disabled: !o,
				onClick: a,
				children: "CLR"
			}),
			s && /* @__PURE__ */ m("button", {
				className: $.swapToggle,
				"aria-label": `Swap ${t} mute and solo`,
				title: `Swap ${t} mute and solo`,
				disabled: !c && !l,
				onClick: s,
				children: "SWAP"
			})
		]
	});
}
// src/components/Drums.tsx
var zo = [
	[1, "1/16"],
	[2, "1/32"],
	[3, "×3 · 1/32T"],
	[4, "×4 · 1/64"],
	[6, "×6 · 1/64T"]
], Bo = {
	2: "1/32",
	3: "1/32 triplet",
	4: "1/64",
	6: "1/64 triplet"
}, Vo = (e) => (t) => {
	if (t <= 0) return "-∞ dB";
	let n = 20 * Math.log10(t / e.initial);
	return Math.abs(n) < .05 ? "0 dB" : `${n > 0 ? "+" : ""}${n.toFixed(1)} dB`;
};
function Ho({ module: e, voice: t, onParams: n, labelled: r }) {
	let i = Z[e.type], a = i.params.find((e) => e.id === `${t}Level`);
	if (!a) return null;
	let o = /* @__PURE__ */ m(eo, {
		trim: !0,
		param: a,
		prefix: i.name,
		format: Vo(a),
		value: e.params[a.id],
		onChange: (e) => n({ [a.id]: e })
	});
	return r ? /* @__PURE__ */ h("div", {
		className: $.laneLevel,
		children: [o, /* @__PURE__ */ m("span", {
			"aria-hidden": "true",
			children: "LEVEL"
		})]
	}) : o;
}
function Uo(e, t, n, r) {
	let i = e.params, a = 1 << n, o = hn(i[`${t}Pattern`], n), s = _n(e, t, n), c = (e) => Object.fromEntries(_t.map((n) => [vt(t, n), n === e ? i[vt(t, n)] | a : i[vt(t, n)] & ~a]));
	return r === 1 ? {
		[`${t}Pattern`]: i[`${t}Pattern`] ^ a,
		...o ? c(0) : {}
	} : {
		[`${t}Pattern`]: i[`${t}Pattern`] | a,
		...c(o && s === r ? 0 : r)
	};
}
function Wo({ name: e, brush: t, onBrush: n }) {
	return /* @__PURE__ */ h("div", {
		className: $.rollBrush,
		role: "group",
		"aria-label": `${e} pad mode`,
		children: [/* @__PURE__ */ m("span", { children: "NOTE" }), zo.map(([e, r]) => /* @__PURE__ */ m("button", {
			"aria-pressed": t === e,
			onClick: () => n(e),
			children: r
		}, e))]
	});
}
function Go({ module: e, mix: t, onMix: n, step: r, onParams: i, onAudition: a, disabled: o, selected: s, onSelect: c, brush: l = 1 }) {
	let u = Z[e.type], d = u.params.some((e) => e.id === vt(u.drum.voices[0].id, 2));
	return /* @__PURE__ */ m("div", {
		className: $.drumPads,
		children: u.drum.voices.map((f) => {
			let p = `${f.id}Pattern`, g = e.params[p];
			return /* @__PURE__ */ h("div", {
				className: $.drumLane,
				"data-silent": !Vn(e, f.id, t),
				children: [
					/* @__PURE__ */ m("button", {
						className: $.voiceButton,
						"aria-label": `Play ${u.name} ${f.label}`,
						"aria-pressed": c ? s === f.id : void 0,
						disabled: o,
						onClick: () => {
							c?.(f.id), a(f.id);
						},
						children: f.label
					}),
					/* @__PURE__ */ m(Ro, {
						mixKey: Pn(e.id, f.id),
						label: `${u.name} ${f.label}`,
						mix: t,
						onToggle: n
					}),
					/* @__PURE__ */ m(Ho, {
						labelled: !0,
						module: e,
						voice: f.id,
						onParams: i
					}),
					/* @__PURE__ */ m("div", {
						className: $.pads,
						children: [
							0,
							1,
							2,
							3
						].map((t) => /* @__PURE__ */ m("div", {
							className: $.padGroup,
							"data-group": t,
							children: [
								0,
								1,
								2,
								3
							].map((n) => {
								let a = t * 4 + n, o = hn(g, a), s = o && d ? _n(e, f.id, a) : 1;
								return /* @__PURE__ */ h("button", {
									className: $.pad,
									"data-current": r === a,
									"data-roll": s > 1 ? s : void 0,
									"aria-pressed": o,
									"aria-label": `${u.name} ${f.label} step ${a + 1}${s > 1 ? `, ${Bo[s]}` : ""}`,
									onClick: () => i(d ? Uo(e, f.id, a, l) : { [p]: g ^ 1 << a }),
									children: [/* @__PURE__ */ m("span", {}), s > 1 && /* @__PURE__ */ m("small", { children: s })]
								}, a);
							})
						}, t))
					})
				]
			}, f.id);
		})
	});
}
var Ko = [
	"Steps",
	"Hits",
	"Shift"
];
function qo({ module: t, mix: n, onMix: r, onParams: i, onAudition: a, disabled: o, clock: s, selected: c, onSelect: l, controls: u }) {
	let d = Z[t.type], f = d.drum.voices.find((e) => e.id === c), p = bn(t, c);
	return /* @__PURE__ */ h("div", {
		className: $.orbitEditor,
		children: [
			/* @__PURE__ */ h("div", {
				className: $.euclid,
				role: "group",
				"aria-label": `${d.name} rhythm`,
				children: [
					/* @__PURE__ */ m("span", { children: "VOICE / EDIT" }),
					/* @__PURE__ */ m("span", {}),
					[...Ko, "Level"].map((e) => /* @__PURE__ */ m("span", {
						className: $.euclidHeading,
						children: e
					}, e)),
					d.drum.voices.map((s) => /* @__PURE__ */ h(e, { children: [
						/* @__PURE__ */ m("button", {
							className: $.voiceButton,
							"aria-label": `Play ${d.name} ${s.label}`,
							"aria-pressed": c === s.id,
							disabled: o,
							"data-silent": !Vn(t, s.id, n),
							onClick: () => {
								l(s.id), a(s.id);
							},
							children: s.label
						}),
						/* @__PURE__ */ m(Ro, {
							mixKey: Pn(t.id, s.id),
							label: `${d.name} ${s.label}`,
							mix: n,
							onToggle: r
						}),
						Ko.map((e) => {
							let n = d.params.find((t) => t.id === `${s.id}${e}`);
							return /* @__PURE__ */ h("div", {
								className: $.euclidCell,
								children: [/* @__PURE__ */ m(eo, {
									trim: !0,
									param: n,
									prefix: d.name,
									disabled: e !== "Steps" && !!t.params[`${s.id}Custom`],
									value: t.params[n.id],
									onChange: (e) => i({ [n.id]: e })
								}), /* @__PURE__ */ m("output", { children: t.params[n.id] })]
							}, e);
						}),
						/* @__PURE__ */ m(Ho, {
							module: t,
							voice: s.id,
							onParams: i
						})
					] }, s.id))
				]
			}),
			/* @__PURE__ */ h("div", {
				className: $.orbitVoiceEditor,
				role: "group",
				"aria-label": `Edit ORBIT ${f.label}`,
				children: [
					/* @__PURE__ */ h("div", {
						className: $.orbitEditorHeading,
						children: [
							/* @__PURE__ */ h("label", { children: ["EDIT VOICE ", /* @__PURE__ */ m("select", {
								"aria-label": "Orbit edit voice",
								value: c,
								onChange: (e) => l(e.target.value),
								children: d.drum.voices.map((e) => /* @__PURE__ */ m("option", {
									value: e.id,
									children: e.label
								}, e.id))
							})] }),
							/* @__PURE__ */ m("span", { children: t.params[`${c}Custom`] ? "CUSTOM" : "EUCLIDEAN" }),
							/* @__PURE__ */ m("button", {
								disabled: !Cn(t, c),
								onClick: () => i(Sn(t, c)),
								"aria-label": `Generate ORBIT ${f.label} rhythm`,
								title: Cn(t, c) ? "Spread this lane’s hits evenly" : "Already Euclidean: turn Steps, Hits or Shift",
								children: "Generate"
							})
						]
					}),
					/* @__PURE__ */ m("div", {
						className: $.controls,
						children: [
							"Tune",
							"Decay",
							"Tone",
							"Pan",
							"Lag"
						].map((e) => {
							let n = d.params.find((t) => t.id === `${c}${e}`);
							return /* @__PURE__ */ m(eo, {
								param: {
									...n,
									label: e
								},
								prefix: `ORBIT ${f.label}`,
								value: t.params[n.id],
								onChange: (e) => i({ [n.id]: e })
							}, n.id);
						})
					}),
					/* @__PURE__ */ m("div", {
						className: $.orbitSteps,
						children: p.map((e, n) => /* @__PURE__ */ h("button", {
							className: $.pad,
							"aria-pressed": e,
							"data-current": s >= 0 && s % p.length === n,
							"aria-label": `ORBIT ${f.label} step ${n + 1}`,
							onClick: () => {
								let e = xn(t, c, n);
								i({
									[`${c}Pattern`]: e[`${c}Pattern`],
									[`${c}Custom`]: 1
								});
							},
							children: [/* @__PURE__ */ m("span", {}), n + 1]
						}, n))
					}),
					/* @__PURE__ */ m("small", { children: "Tap a step to customize. Generate makes it Euclidean again." })
				]
			}),
			/* @__PURE__ */ h("div", {
				className: $.orbitDevice,
				children: [/* @__PURE__ */ m(Yo, {
					module: t,
					clock: s
				}), u]
			})
		]
	});
}
var Jo = [
	70,
	59,
	48,
	37,
	26,
	15
];
function Yo({ module: e, clock: t }) {
	return /* @__PURE__ */ m("svg", {
		className: $.orbitRings,
		viewBox: "0 0 160 160",
		"aria-hidden": "true",
		children: Z[e.type].drum.voices.map(({ id: n }, r) => {
			let i = bn(e, n), a = Jo[r], o = t < 0 ? -1 : t % i.length;
			return /* @__PURE__ */ h("g", {
				"data-voice": n,
				children: [/* @__PURE__ */ m("circle", {
					className: $.orbitPath,
					cx: "80",
					cy: "80",
					r: a
				}), i.map((e, t) => {
					let n = t / i.length * 2 * Math.PI - Math.PI / 2;
					return /* @__PURE__ */ m("circle", {
						cx: (80 + a * Math.cos(n)).toFixed(2),
						cy: (80 + a * Math.sin(n)).toFixed(2),
						r: t === o ? 3.8 : e ? 3 : 1.4,
						"data-hit": e,
						"data-current": t === o
					}, t);
				})]
			}, n);
		})
	});
}
// src/components/SoundEditors.tsx
function Xo({ module: e, onParams: t, onAudition: n, disabled: r, selected: i, onSelect: a }) {
	let o = Z[e.type], s = o.drum.voices.find((e) => e.id === i);
	return /* @__PURE__ */ h("div", {
		className: $.soundEditor,
		role: "group",
		"aria-label": `${o.name} voice editor`,
		children: [/* @__PURE__ */ h("div", {
			className: $.editorHeading,
			children: [/* @__PURE__ */ h("label", { children: [/* @__PURE__ */ m("span", { children: "EDIT VOICE" }), /* @__PURE__ */ m("select", {
				"aria-label": `${o.name} edit voice`,
				value: i,
				onChange: (e) => a(e.target.value),
				children: o.drum.voices.map((e) => /* @__PURE__ */ m("option", {
					value: e.id,
					children: e.label
				}, e.id))
			})] }), /* @__PURE__ */ h("button", {
				disabled: r,
				onClick: () => n(i),
				children: ["Audition ", s.label]
			})]
		}), /* @__PURE__ */ m("div", {
			className: $.controls,
			children: o.params.filter((e) => e.voice === i && !e.pattern && e.id !== `${i}Level`).map((n) => /* @__PURE__ */ m(eo, {
				param: {
					...n,
					label: n.label.slice(s.label.length + 1)
				},
				prefix: `${o.name} ${s.label}`,
				value: e.params[n.id],
				onChange: (e) => t({ [n.id]: e })
			}, n.id))
		})]
	});
}
var Zo = [
	"2→1 + 4→3 + 6→5",
	"3→2→1 + 6→5→4",
	"6→5→4→3→2→1",
	"5+6→4→1+2+3",
	"4→2→1 + 6→5→3→1",
	"1 + 2 + 3 + 4 + 5 + 6"
];
function Qo({ module: e, onParams: t }) {
	let [n, r] = d(1);
	return /* @__PURE__ */ h("div", {
		className: $.soundEditor,
		role: "group",
		"aria-label": "PRISM operator editor",
		children: [
			/* @__PURE__ */ h("div", {
				className: $.fmDisplay,
				children: [
					/* @__PURE__ */ m("span", { children: dt[e.params.algorithm] }),
					/* @__PURE__ */ m("strong", { children: Zo[e.params.algorithm] }),
					/* @__PURE__ */ m("small", { children: "16 VOICES · SIX OPERATORS · PHASE MODULATION" })
				]
			}),
			/* @__PURE__ */ m("div", {
				className: $.operatorTabs,
				role: "group",
				"aria-label": "Select PRISM operator",
				children: [
					1,
					2,
					3,
					4,
					5,
					6
				].map((e) => /* @__PURE__ */ h("button", {
					"aria-pressed": n === e,
					"aria-label": `Edit PRISM operator ${e}`,
					onClick: () => r(e),
					children: ["OP ", e]
				}, e))
			}),
			/* @__PURE__ */ m("div", {
				className: $.controls,
				children: Z.prism.params.filter((e) => e.voice === `op${n}`).map((r) => /* @__PURE__ */ m(eo, {
					param: r,
					prefix: `PRISM Operator ${n}`,
					value: e.params[r.id],
					onChange: (e) => t({ [r.id]: e })
				}, r.id))
			})
		]
	});
}
// src/components/PanelLegend.tsx
function $o({ size: e, height: t, inner: n, marks: r }) {
	let i = (n, r) => [e / 2 + n * Math.sin(r * Math.PI / 180), t / 2 - n * Math.cos(r * Math.PI / 180)], a = (e, t) => n + 10 + (e.length - 1) * 2.2 * Math.abs(Math.sin(t * Math.PI / 180));
	return /* @__PURE__ */ m("svg", {
		className: $.panelLegend,
		width: e,
		height: t,
		style: {
			width: e,
			height: t
		},
		viewBox: `0 0 ${e} ${t}`,
		"aria-hidden": "true",
		children: r.map(({ angle: e, text: t, lit: r }, o) => {
			let [s, c] = i(n, e), [l, u] = i(n + (t ? 4 : 2.5), e), [d, f] = i(a(t ?? "", e), e);
			return /* @__PURE__ */ h("g", {
				"data-lit": r || void 0,
				children: [/* @__PURE__ */ m("line", {
					x1: s,
					y1: c,
					x2: l,
					y2: u
				}), t && /* @__PURE__ */ m("text", {
					x: d,
					y: f,
					textAnchor: "middle",
					dominantBaseline: "central",
					children: t
				})]
			}, o);
		})
	});
}
// src/components/Brit.tsx
var es = (e) => Z.brit.params.find((t) => t.id === e), ts = (e, t) => {
	let n = Math.min(270, (t - 1) * 45);
	return -n / 2 + e * n / (t - 1);
}, ns = (e, t) => e.choices ? ts(t, e.choices.length) : -135 + hr(e, t) * 270, rs = 104, is = (e) => ({
	"--size": `${e}px`,
	"--height": `${rs}px`
});
function as({ angle: e, skirt: t }) {
	return /* @__PURE__ */ h(p, { children: [
		t && /* @__PURE__ */ m("span", { className: $.marconiSkirt }),
		/* @__PURE__ */ m("span", { className: $.marconiFlutes }),
		/* @__PURE__ */ m("span", { className: $.marconiDome }),
		/* @__PURE__ */ m("span", {
			className: $.marconiPointer,
			style: { transform: `rotate(${e}deg)` }
		})
	] });
}
var os = (e, t) => [...Array.from({ length: 11 }, (e, t) => ({ angle: -135 + t * 27 })), ...t.map(([t, n]) => ({
	angle: ns(e, t),
	text: n
}))], ss = (e, t) => e.map((n, r) => ({
	angle: ts(r, e.length),
	text: n,
	lit: r === t
}));
function cs({ module: e, prefix: t, onParams: n, id: r, color: i, size: a, knob: o, skirt: s, title: c, labels: l, marks: u }) {
	let d = es(r), f = e.params[r], { props: p, display: g } = $a({
		param: d,
		value: f,
		prefix: t,
		onChange: (e) => n({ [r]: e })
	});
	return /* @__PURE__ */ h("div", {
		className: $.britSection,
		children: [
			/* @__PURE__ */ m("strong", { children: c }),
			/* @__PURE__ */ h("div", {
				className: $.britWell,
				style: is(a),
				children: [/* @__PURE__ */ m($o, {
					size: a,
					height: rs,
					inner: o / 2 + 3,
					marks: l ? ss(l, f) : os(d, u ?? [])
				}), /* @__PURE__ */ m("div", {
					className: $.marconi,
					"data-color": i,
					"data-skirt": s || void 0,
					style: { "--knob": `${o}px` },
					...p,
					children: /* @__PURE__ */ m(as, {
						angle: ns(d, f),
						skirt: s
					})
				})]
			}),
			!l && /* @__PURE__ */ m("span", {
				className: $.knobValue,
				children: g
			})
		]
	});
}
function ls({ module: e, prefix: t, onParams: n, frequency: r, gain: i, color: a, title: o, labels: s }) {
	let c = es(r), l = es(i), u = $a({
		param: c,
		value: e.params[r],
		prefix: t,
		onChange: (e) => n({ [r]: e })
	}), d = $a({
		param: l,
		value: e.params[i],
		prefix: t,
		onChange: (e) => n({ [i]: e })
	});
	return /* @__PURE__ */ h("div", {
		className: $.britSection,
		children: [
			/* @__PURE__ */ m("strong", { children: o }),
			/* @__PURE__ */ h("div", {
				className: $.britWell,
				style: is(112),
				children: [
					/* @__PURE__ */ m($o, {
						size: 112,
						height: rs,
						inner: 36,
						marks: ss(s, e.params[r])
					}),
					/* @__PURE__ */ m("div", {
						className: $.marconiRing,
						style: { "--ring": "66px" },
						...u.props,
						children: /* @__PURE__ */ m("span", {
							className: $.ringPointer,
							style: { transform: `rotate(${ns(c, e.params[r])}deg)` }
						})
					}),
					/* @__PURE__ */ m("div", {
						className: $.marconi,
						"data-color": a,
						style: { "--knob": "38px" },
						...d.props,
						children: /* @__PURE__ */ m(as, { angle: ns(l, e.params[i]) })
					})
				]
			}),
			/* @__PURE__ */ m("span", {
				className: $.knobValue,
				children: d.display
			})
		]
	});
}
function us({ module: e, onParams: t, rate: n }) {
	let r = Z.brit.name, i = e.params.active === 0, a = (n) => ({
		module: e,
		onParams: t,
		prefix: `${r} ${n}`
	});
	return /* @__PURE__ */ h("div", {
		className: $.britPanel,
		"data-bypassed": !i,
		children: [
			/* @__PURE__ */ m(cs, {
				...a("Signal"),
				id: "hpf",
				color: "blue",
				size: 96,
				knob: 46,
				title: "High pass",
				labels: [
					"OFF",
					"50",
					"80",
					"160",
					"300"
				]
			}),
			/* @__PURE__ */ m(ls, {
				...a("Low shelf"),
				frequency: "lfFreq",
				gain: "lfGain",
				color: "grey",
				title: "Low · Hz",
				labels: [
					"35",
					"60",
					"110",
					"220"
				]
			}),
			/* @__PURE__ */ m(ls, {
				...a("Mid bell"),
				frequency: "midFreq",
				gain: "midGain",
				color: "blue",
				title: "Mid · kHz",
				labels: [
					".36",
					".7",
					"1.6",
					"3.2",
					"4.8",
					"7.2"
				]
			}),
			/* @__PURE__ */ m(cs, {
				...a("High shelf · 12 kHz"),
				id: "hfGain",
				color: "grey",
				size: 88,
				knob: 44,
				title: "High · 12k",
				marks: [
					[-16, "−16"],
					[0, "0"],
					[16, "+16"]
				]
			}),
			/* @__PURE__ */ m(cs, {
				...a("Signal"),
				id: "drive",
				color: "red",
				size: 100,
				knob: 64,
				skirt: !0,
				title: "Drive",
				marks: [
					[0, "0"],
					[12, "12"],
					[24, "24"]
				]
			}),
			/* @__PURE__ */ m(cs, {
				...a("Signal"),
				id: "output",
				color: "grey",
				size: 80,
				knob: 36,
				title: "Output",
				marks: [
					[-18, "−18"],
					[0, "0"],
					[18, "+18"]
				]
			}),
			/* @__PURE__ */ h("div", {
				className: $.britSection,
				children: [/* @__PURE__ */ m("strong", { children: "EQ" }), /* @__PURE__ */ h("button", {
					className: $.britSwitch,
					"aria-pressed": i,
					"aria-label": `${r} EQ in`,
					title: i ? "EQ in. Press to bypass." : "Bypassed. Press to switch the EQ in.",
					onClick: () => t({ active: +!!i }),
					children: [/* @__PURE__ */ m("span", { className: $.britLamp }), "IN"]
				})]
			}),
			/* @__PURE__ */ h("div", {
				className: `${$.britSection} ${$.britCurve}`,
				children: [/* @__PURE__ */ m("strong", { children: "Response" }), /* @__PURE__ */ m(Ao, {
					params: e.params,
					brit: !0,
					rate: n
				})]
			})
		]
	});
}
// src/components/Talon.tsx
var ds = Z.talon.name, fs = (e) => Z.talon.params.find((t) => t.id === e), ps = (e) => `${ds} ${e.group} ${e.label}`, ms = (e, t) => -135 + hr(e, t) * 270, hs = 108, gs = [
	1,
	2,
	3,
	4,
	6,
	8,
	10,
	14,
	20,
	30
];
function _s({ module: e, onParams: t, id: n, size: r, knob: i, title: a, marks: o }) {
	let s = fs(n), c = e.params[n], { props: l, display: u } = $a({
		param: s,
		value: c,
		prefix: `${ds} ${s.group}`,
		onChange: (e) => t({ [n]: e })
	}), d = [...Array.from({ length: 11 }, (e, t) => ({ angle: -135 + t * 27 })), ...o.map(([e, t]) => ({
		angle: ms(s, e),
		text: t
	}))];
	return /* @__PURE__ */ h("div", {
		className: $.talonSection,
		children: [
			/* @__PURE__ */ m("strong", { children: a }),
			/* @__PURE__ */ h("div", {
				className: $.talonWell,
				style: {
					"--size": `${r}px`,
					"--height": `${hs}px`
				},
				children: [/* @__PURE__ */ m($o, {
					size: r,
					height: hs,
					inner: i / 2 + 4,
					marks: d
				}), /* @__PURE__ */ h("div", {
					className: $.talonKnob,
					style: { "--knob": `${i}px` },
					...l,
					children: [
						/* @__PURE__ */ m("span", { className: $.talonGrip }),
						/* @__PURE__ */ m("span", { className: $.talonCap }),
						/* @__PURE__ */ m("span", {
							className: $.talonIndex,
							style: { transform: `rotate(${ms(s, c)}deg)` }
						})
					]
				})]
			}),
			/* @__PURE__ */ m("span", {
				className: $.knobValue,
				children: u
			})
		]
	});
}
function vs({ module: e, onParams: t, id: n, title: r, button: i, captions: a = [] }) {
	let o = fs(n), s = e.params[n], c = o.choices.length;
	function l(e) {
		let r = {
			ArrowDown: s + 1,
			ArrowRight: s + 1,
			ArrowUp: s - 1,
			ArrowLeft: s - 1,
			Home: 0,
			End: c - 1
		}[e.key];
		if (r === void 0) return;
		e.preventDefault();
		let i = Math.max(0, Math.min(c - 1, r));
		t({ [n]: i }), e.currentTarget.querySelectorAll("[role=\"radio\"]")[i].focus();
	}
	return /* @__PURE__ */ h("div", {
		className: $.talonSection,
		children: [
			/* @__PURE__ */ m("strong", { children: r }),
			/* @__PURE__ */ m("div", {
				className: $.talonLamps,
				role: "radiogroup",
				"aria-label": ps(o),
				onKeyDown: l,
				children: o.choices.map((e, r) => /* @__PURE__ */ h("button", {
					type: "button",
					role: "radio",
					"aria-checked": r === s,
					tabIndex: r === s ? 0 : -1,
					onClick: () => t({ [n]: r }),
					children: [
						/* @__PURE__ */ m("span", { className: $.talonLed }),
						e,
						a[r] && /* @__PURE__ */ m("small", {
							"aria-hidden": "true",
							children: a[r]
						})
					]
				}, e))
			}),
			/* @__PURE__ */ m("button", {
				type: "button",
				className: $.talonPush,
				"aria-label": `${ps(o)}: next`,
				title: `Step to the next ${o.label.toLowerCase()} mode`,
				onClick: () => t({ [n]: (s + 1) % c }),
				children: i
			})
		]
	});
}
function ys({ module: e, onParams: t, id: n, text: r }) {
	let i = fs(n), a = e.params[n] === 1;
	return /* @__PURE__ */ h("button", {
		type: "button",
		className: $.talonPush,
		"aria-pressed": a,
		"aria-label": ps(i),
		title: `${i.label}: ${i.choices[e.params[n]]}`,
		onClick: () => t({ [n]: +!a }),
		children: [/* @__PURE__ */ m("span", { className: $.talonLed }), r]
	});
}
function bs({ reduction: e, label: t }) {
	let n = Math.min(40, Math.max(0, -e));
	return /* @__PURE__ */ h("div", {
		className: $.talonSection,
		children: [/* @__PURE__ */ m("strong", { children: "GR" }), /* @__PURE__ */ m("div", {
			className: $.talonMeter,
			role: "meter",
			"aria-label": t,
			"aria-valuemin": 0,
			"aria-valuemax": 40,
			"aria-valuenow": n,
			"aria-valuetext": `${n} dB gain reduction`,
			children: gs.map((e) => /* @__PURE__ */ h("span", {
				"data-lit": n >= e,
				"data-hot": e > 10 || void 0,
				children: [/* @__PURE__ */ m("i", {}), e]
			}, e))
		})]
	});
}
function xs({ module: e, onParams: t, reduction: n, label: r }) {
	let i = {
		module: e,
		onParams: t
	}, a = e.params.active === 0;
	return /* @__PURE__ */ h("div", {
		className: $.talonPanel,
		"data-bypassed": !a,
		children: [
			/* @__PURE__ */ m(_s, {
				...i,
				id: "input",
				size: 100,
				knob: 60,
				title: "Input",
				marks: [
					[-12, "−12"],
					[0, "0"],
					[12, "12"],
					[30, "30"]
				]
			}),
			/* @__PURE__ */ m(_s, {
				...i,
				id: "attack",
				size: 84,
				knob: 46,
				title: "Attack · ms",
				marks: [
					[5e-5, ".05"],
					[.001, "1"],
					[.01, "10"],
					[.03, "30"]
				]
			}),
			/* @__PURE__ */ m(_s, {
				...i,
				id: "release",
				size: 84,
				knob: 46,
				title: "Release · s",
				marks: [
					[.05, ".05"],
					[.3, ".3"],
					[1, "1"],
					[3.5, "3.5"]
				]
			}),
			/* @__PURE__ */ m(vs, {
				...i,
				id: "ratio",
				title: "Ratio",
				button: "Ratio"
			}),
			/* @__PURE__ */ h("div", {
				className: $.talonSection,
				children: [/* @__PURE__ */ m(vs, {
					...i,
					id: "color",
					title: "Harmonics",
					button: "Dist",
					captions: [
						"",
						"2nd",
						"3rd"
					]
				}), /* @__PURE__ */ h("div", {
					className: $.talonLatches,
					children: [/* @__PURE__ */ m(ys, {
						...i,
						id: "audioHp",
						text: "HP 65"
					}), /* @__PURE__ */ m(ys, {
						...i,
						id: "fierce",
						text: "Fierce"
					})]
				})]
			}),
			/* @__PURE__ */ h("div", {
				className: $.talonSection,
				children: [/* @__PURE__ */ m("strong", { children: "Detector" }), /* @__PURE__ */ h("div", {
					className: $.talonLatches,
					children: [
						/* @__PURE__ */ m(ys, {
							...i,
							id: "detectorHp",
							text: "HP 80"
						}),
						/* @__PURE__ */ m(ys, {
							...i,
							id: "detectorBand",
							text: "Band 6k"
						}),
						/* @__PURE__ */ m(ys, {
							...i,
							id: "link",
							text: "Link"
						})
					]
				})]
			}),
			/* @__PURE__ */ h("div", {
				className: $.talonOutput,
				children: [
					/* @__PURE__ */ m(bs, {
						reduction: n,
						label: r
					}),
					/* @__PURE__ */ m(_s, {
						...i,
						id: "output",
						size: 100,
						knob: 60,
						title: "Output",
						marks: [
							[-30, "−30"],
							[-12, "−12"],
							[0, "0"],
							[12, "+12"]
						]
					}),
					/* @__PURE__ */ h("div", {
						className: $.talonSection,
						children: [/* @__PURE__ */ m("strong", { children: "Comp" }), /* @__PURE__ */ h("button", {
							type: "button",
							className: $.talonSwitch,
							"aria-pressed": a,
							"aria-label": `${ds} in`,
							title: a ? "In. Press to bypass." : "Bypassed. Press to switch TALON in.",
							onClick: () => t({ active: +!!a }),
							children: [/* @__PURE__ */ m("span", { className: $.talonLamp }), "IN"]
						})]
					})
				]
			}),
			e.params.ratio === 5 && /* @__PURE__ */ m("p", {
				className: $.processorHint,
				children: "Opto recovery lengthens with sustained reduction, up to 20 s."
			})
		]
	});
}
// src/components/EngineSwitch.tsx
var Ss = [
	0,
	.14,
	.28,
	.42,
	.56,
	.7,
	.84
];
function Cs({ module: e, param: t, name: n, onParams: r }) {
	let i = e.params[t.id] === 1, [a, o] = t.choices;
	return /* @__PURE__ */ h("button", {
		type: "button",
		role: "switch",
		className: $.engineSwitch,
		"aria-checked": i,
		"aria-label": `${n} ${t.label}`,
		"data-modeled": i,
		title: `${t.label}: ${i ? o : a}. Slide to ${i ? a : o}.`,
		onClick: () => r({ [t.id]: +!i }),
		children: [/* @__PURE__ */ m("span", {
			className: $.engineCaption,
			children: t.label
		}), /* @__PURE__ */ h("span", {
			className: $.togglePlate,
			"aria-hidden": "true",
			children: [
				/* @__PURE__ */ m("span", {
					className: $.toggleLegend,
					"data-lit": !i,
					children: a
				}),
				/* @__PURE__ */ h("span", {
					className: $.toggle,
					children: [/* @__PURE__ */ m("span", { className: $.toggleSlot }), /* @__PURE__ */ h("span", {
						className: $.toggleKnob,
						children: [
							/* @__PURE__ */ m("span", { className: $.toggleBrim }),
							Ss.map((e) => /* @__PURE__ */ m("span", {
								className: $.toggleRib,
								style: { "--f": e }
							}, e)),
							/* @__PURE__ */ m("span", { className: $.toggleCap })
						]
					})]
				}),
				/* @__PURE__ */ m("span", {
					className: $.toggleLegend,
					"data-lit": i,
					children: o
				})
			]
		})]
	});
}
// src/components/Mixer.tsx
var ws = 112, Ts = [
	[1, "0"],
	[10 ** (-3 / 20), "3"],
	[.5, "6"],
	[10 ** (-10 / 20), "10"],
	[.1, "20"],
	[0, "∞"]
], Es = [
	-48,
	-42,
	-36,
	-30,
	-24,
	-18,
	-12,
	-9,
	-6,
	-3,
	0
], Ds = (e) => Z.mixer.params.find((t) => t.id === e), Os = (e) => e <= 0 ? "−∞" : `${(20 * Math.log10(e)).toFixed(1).replace("-", "−")} dB`, ks = (e) => Math.abs(e) < .005 ? "C" : `${e < 0 ? "L" : "R"}${Math.round(Math.abs(e) * 100)}`;
function As({ level: e, label: t }) {
	let n = Math.round(e);
	return /* @__PURE__ */ m("div", {
		className: $.levelMeter,
		role: "meter",
		"aria-label": t,
		"aria-valuemin": Es[0],
		"aria-valuemax": 0,
		"aria-valuenow": Math.max(Es[0], Math.min(0, n)),
		"aria-valuetext": e < Es[0] ? "Silent" : `${n} dB`,
		children: Es.map((t) => /* @__PURE__ */ m("i", {
			"data-lit": e >= t,
			"data-zone": t >= -3 ? "hot" : t >= -9 ? "warm" : void 0
		}, t))
	});
}
function js({ param: e, value: t, prefix: n, onChange: r, children: i }) {
	let { props: a, fraction: o, display: s } = $a({
		param: e,
		value: t,
		prefix: n,
		onChange: r,
		format: Os,
		travel: ws
	});
	return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ h("div", {
		className: $.faderBay,
		style: { "--travel": `${ws}px` },
		children: [
			/* @__PURE__ */ m("span", {
				className: $.faderScale,
				"aria-hidden": "true",
				children: Ts.map(([e, t]) => /* @__PURE__ */ m("span", {
					style: { "--at": e },
					children: t
				}, t))
			}),
			/* @__PURE__ */ m("div", {
				className: $.faderSlot,
				...a,
				children: /* @__PURE__ */ m("span", {
					className: $.faderCap,
					style: { "--at": o }
				})
			}),
			i
		]
	}), /* @__PURE__ */ m("span", {
		className: $.faderValue,
		children: s
	})] });
}
function Ms({ module: e, patch: t, mix: n, levels: r, onParams: i, onToggle: a, onSwap: o, onGoTo: s }) {
	let c = Z[e.type].name;
	return /* @__PURE__ */ h("div", {
		className: $.console,
		children: [ft.map((l, u) => {
			let { source: d, tooltip: f, connected: p, named: g, deviceId: _ } = Yn(t, e.id, l), v = l.toUpperCase(), y = pt(l), b = Pn(e.id, l);
			return /* @__PURE__ */ h("div", {
				className: $.channelStrip,
				role: "group",
				"aria-label": `${c} channel ${v}: ${d}`,
				"data-plugged": p,
				"data-silent": !Vn(e, l, n),
				"data-analytics-private": g ? "" : void 0,
				children: [
					_ ? /* @__PURE__ */ h("button", {
						type: "button",
						className: `${$.scribble} ${$.scribbleLink}`,
						"aria-label": `${d} ${v}, go to this device`,
						title: f,
						onClick: () => s(_),
						children: [/* @__PURE__ */ m("span", {
							className: $.channelSource,
							"data-source-name": !0,
							children: d
						}), /* @__PURE__ */ m("b", { children: v })]
					}) : /* @__PURE__ */ h("div", {
						className: $.scribble,
						children: [/* @__PURE__ */ m("span", {
							className: $.channelSource,
							"data-source-name": !0,
							children: d
						}), /* @__PURE__ */ m("b", { children: v })]
					}),
					/* @__PURE__ */ m(eo, {
						param: Ds(y),
						prefix: c,
						value: e.params[y],
						format: ks,
						caption: "PAN",
						onChange: (e) => i({ [y]: e })
					}),
					/* @__PURE__ */ m(Ro, {
						mixKey: b,
						label: `${c} channel ${v}`,
						mix: n,
						onToggle: a,
						onSwap: () => o(b)
					}),
					/* @__PURE__ */ m(js, {
						param: Ds(l),
						prefix: c,
						value: e.params[l],
						onChange: (e) => i({ [l]: e }),
						children: /* @__PURE__ */ m(As, {
							level: r.channels[u],
							label: `${c} channel ${v} level`
						})
					})
				]
			}, l);
		}), /* @__PURE__ */ h("div", {
			className: $.mixBus,
			role: "group",
			"aria-label": `${c} mix bus`,
			children: [/* @__PURE__ */ h("div", {
				className: $.scribble,
				children: [/* @__PURE__ */ m("span", {
					className: $.channelSource,
					children: "MIX BUS"
				}), /* @__PURE__ */ m("b", { children: "L · R" })]
			}), /* @__PURE__ */ h(js, {
				param: Ds("master"),
				prefix: c,
				value: e.params.master,
				onChange: (e) => i({ master: e }),
				children: [/* @__PURE__ */ m(As, {
					level: r.bus[0],
					label: `${c} mix bus left level`
				}), /* @__PURE__ */ m(As, {
					level: r.bus[1],
					label: `${c} mix bus right level`
				})]
			})]
		})]
	});
}
// src/components/ModuleTape.tsx
var Ns = (e) => [...e].reduce((e, t) => (e * 31 + t.charCodeAt(0)) % 3, 1);
function Ps({ module: e, slot: t, onName: n }) {
	let r = Z[e.type], a = `${r.name} ${t}`, o = Ns(e.id), s = e.label, [c, l] = d(null), f = c !== null, g = u(null), _ = u(null), v = u(null), y = u(!1), b = u(!1);
	i(() => {
		f ? (g.current?.focus(), g.current?.select()) : b.current && (b.current = !1, (v.current ?? _.current)?.focus());
	}, [f]);
	function x() {
		y.current = !0, l(s ?? "");
	}
	function S(e, t) {
		y.current && (y.current = !1, b.current = t, l(null), e !== null && n(e));
	}
	function C(e) {
		e.key === "Escape" ? (e.preventDefault(), S(null, !0)) : e.key === "Enter" && e.target === g.current && (e.preventDefault(), S(c, !0));
	}
	return /* @__PURE__ */ h(p, { children: [e.type === "output" ? /* @__PURE__ */ m("span", {
		className: $.moduleName,
		children: r.name
	}) : /* @__PURE__ */ m("button", {
		ref: _,
		type: "button",
		className: $.moduleNameButton,
		"aria-label": `Name ${a}`,
		title: s ? "Rename this device" : "Name this device",
		onClick: x,
		children: r.name
	}), /* @__PURE__ */ h("span", {
		className: $.moduleSlot,
		"data-taped": f || !!s,
		"data-subtitle": r.subtitle,
		children: [/* @__PURE__ */ m("span", {
			className: $.moduleSubtitle,
			children: r.subtitle
		}), f ? /* @__PURE__ */ m("span", {
			className: $.moduleTape,
			"data-tear": o,
			"data-analytics-private": "",
			onKeyDown: C,
			onBlur: (e) => {
				e.currentTarget.contains(e.relatedTarget) || S(c, !1);
			},
			children: /* @__PURE__ */ h("span", {
				className: $.tapeBody,
				children: [/* @__PURE__ */ m("span", {
					className: $.tapeField,
					"data-value": c,
					children: /* @__PURE__ */ m("input", {
						ref: g,
						"data-tape-input": "",
						"aria-label": `Name for ${a}`,
						maxLength: 40,
						size: 1,
						placeholder: "Name it",
						value: c,
						onChange: (e) => l(e.target.value)
					})
				}), /* @__PURE__ */ m("button", {
					type: "button",
					className: $.tapePeel,
					"aria-label": `Remove name from ${a}`,
					title: "Peel the tape off",
					onMouseDown: (e) => e.preventDefault(),
					onClick: () => S("", !0),
					children: "×"
				})]
			})
		}) : s && /* @__PURE__ */ m("span", {
			className: $.moduleTape,
			"data-tear": o,
			"data-analytics-private": "",
			children: /* @__PURE__ */ m("button", {
				ref: v,
				type: "button",
				className: $.tapeBody,
				"aria-label": `Rename ${s}, ${a}`,
				title: s,
				onClick: x,
				children: /* @__PURE__ */ m("span", {
					className: $.tapeText,
					children: s
				})
			})
		})]
	})] });
}
// src/components/TempoInput.tsx
var Fs = 40, Is = 240;
function Ls({ bpm: e, onChange: t }) {
	let [n, r] = d(String(e)), o = a();
	return i(() => {
		r(String(e));
	}, [e]), /* @__PURE__ */ h("div", {
		className: $.numberField,
		children: [
			/* @__PURE__ */ m("label", {
				htmlFor: o,
				children: "BPM"
			}),
			/* @__PURE__ */ m("input", {
				id: o,
				"aria-label": "Tempo",
				type: "number",
				min: Fs,
				max: Is,
				step: 1,
				value: n,
				onChange: (e) => {
					r(e.target.value);
					let n = Number(e.target.value);
					n >= Fs && n <= Is && t(n);
				},
				onBlur: () => {
					let i = n === "" ? e : Math.max(Fs, Math.min(Is, Number(n)));
					r(String(i)), t(i);
				}
			}),
			/* @__PURE__ */ m("input", {
				className: $.fader,
				type: "range",
				min: Fs,
				max: Is,
				step: 1,
				value: e,
				"aria-label": "Tempo slider",
				"aria-valuetext": `${e} BPM`,
				onChange: (e) => t(Number(e.target.value))
			})
		]
	});
}
// src/components/Presets.tsx
var Rs = (e) => new Date(e).toLocaleString(void 0, {
	dateStyle: "medium",
	timeStyle: "short"
});
function zs({ presets: e, openId: t, dirty: n, onLoad: r, onLoadFactory: a, onExport: o, onDelete: s, onSaveAs: c, onImport: l, onExportCurrent: f, onClose: g }) {
	let [_, v] = d(null), y = u(null), b = u(null);
	return i(() => {
		_ && y.current?.focus();
	}, [_]), /* @__PURE__ */ h("div", {
		ref: b,
		tabIndex: -1,
		className: `${$.library} ${$.presetBrowser}`,
		role: "region",
		"aria-label": "Presets",
		"data-analytics-private": "",
		children: [
			/* @__PURE__ */ h("div", {
				className: $.libraryHeading,
				children: [/* @__PURE__ */ m("strong", { children: "PRESETS" }), /* @__PURE__ */ h("span", {
					className: $.presetActions,
					children: [
						/* @__PURE__ */ m("button", {
							onClick: (e) => c(e.currentTarget),
							title: "Save a copy under a new name (⇧⌘S / Ctrl+Shift+S)",
							children: "Save as…"
						}),
						/* @__PURE__ */ m("button", {
							onClick: l,
							title: "Add a .json patch file to My Presets",
							children: "↑ Import file…"
						}),
						/* @__PURE__ */ m("button", {
							onClick: f,
							title: "Download the rack as a .json patch file",
							children: "↓ Export file"
						}),
						/* @__PURE__ */ m("button", {
							"aria-label": "Close presets",
							onClick: g,
							children: "×"
						})
					]
				})]
			}),
			/* @__PURE__ */ m("strong", {
				className: $.sectionLabel,
				children: "MY PRESETS · SAVED IN THIS BROWSER"
			}),
			e.length ? /* @__PURE__ */ m("ul", {
				className: $.presetList,
				"aria-label": "My presets",
				children: e.map((e) => {
					let { id: i, patch: { name: a } } = e, c = i === t;
					return /* @__PURE__ */ m("li", {
						className: $.presetRow,
						"data-open": c,
						children: _ === i ? /* @__PURE__ */ h(p, { children: [
							/* @__PURE__ */ h("span", {
								className: $.presetConfirm,
								children: [
									"Delete “",
									a,
									"”? This can’t be undone."
								]
							}),
							/* @__PURE__ */ m("button", {
								className: $.dangerButton,
								"aria-label": `Confirm delete ${a}`,
								onClick: () => {
									v(null), s(e), b.current?.focus();
								},
								children: "Delete"
							}),
							/* @__PURE__ */ m("button", {
								ref: y,
								"aria-label": `Keep ${a}`,
								onClick: () => v(null),
								children: "Keep"
							})
						] }) : /* @__PURE__ */ h(p, { children: [
							/* @__PURE__ */ h("button", {
								className: $.presetLoad,
								"aria-label": `Load ${a}`,
								"aria-current": c || void 0,
								onClick: () => r(e),
								children: [/* @__PURE__ */ m("strong", { children: a }), /* @__PURE__ */ m("small", { children: c ? n ? "OPEN · UNSAVED CHANGES" : "OPEN" : `Saved ${Rs(e.savedAt)}` })]
							}),
							/* @__PURE__ */ m("button", {
								"aria-label": `Export ${a}`,
								title: `Download ${a} as a .json patch file`,
								onClick: () => o(e.patch),
								children: "↓ Export"
							}),
							/* @__PURE__ */ m("button", {
								"aria-label": `Delete ${a}`,
								title: `Delete ${a} from this browser`,
								onClick: () => v(i),
								children: "Delete"
							})
						] })
					}, i);
				})
			}) : /* @__PURE__ */ m("p", {
				className: $.presetEmpty,
				children: "Nothing saved yet. Save keeps your rack here under its name; Import file adds a patch you exported."
			}),
			/* @__PURE__ */ m("strong", {
				className: $.sectionLabel,
				children: "FACTORY"
			}),
			/* @__PURE__ */ m("div", {
				role: "group",
				"aria-label": "Factory presets",
				children: or.map(([e, t]) => /* @__PURE__ */ h("div", {
					className: $.factoryCategory,
					children: [/* @__PURE__ */ m("span", {
						className: $.factoryCategoryLabel,
						"aria-hidden": "true",
						children: e.toUpperCase()
					}), /* @__PURE__ */ m("div", {
						className: $.factoryGrid,
						role: "group",
						"aria-label": `${e} presets`,
						children: t.map((e) => /* @__PURE__ */ m("button", {
							title: e,
							onClick: () => a(e),
							children: e
						}, e))
					})]
				}, e))
			})
		]
	});
}
function Bs({ initialName: e, presets: t, onSave: n, onCancel: r }) {
	let [o, s] = d(e), c = u(null), l = a(), f = a(), p = Wr(t, o), g = !o.trim();
	i(() => {
		c.current?.select();
	}, []);
	function _(e) {
		if (e.key === "Escape") {
			e.preventDefault(), r();
			return;
		}
		if (e.key !== "Tab") return;
		let t = [...e.currentTarget.querySelectorAll("input, button:not(:disabled)")], n = t[0], i = t.at(-1);
		e.shiftKey && document.activeElement === n ? (e.preventDefault(), i?.focus()) : !e.shiftKey && document.activeElement === i && (e.preventDefault(), n?.focus());
	}
	return /* @__PURE__ */ m("div", {
		className: $.helpBackdrop,
		children: /* @__PURE__ */ m("div", {
			className: $.saveDialog,
			"data-analytics-private": "",
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": l,
			"aria-describedby": f,
			onKeyDown: _,
			children: /* @__PURE__ */ h("form", {
				onSubmit: (e) => {
					e.preventDefault(), g || n(o);
				},
				children: [
					/* @__PURE__ */ m("strong", {
						id: l,
						className: $.saveTitle,
						children: "Save preset"
					}),
					/* @__PURE__ */ h("label", { children: ["Name", /* @__PURE__ */ m("input", {
						ref: c,
						autoFocus: !0,
						"aria-label": "Preset name",
						maxLength: 100,
						value: o,
						onChange: (e) => s(e.target.value)
					})] }),
					p && /* @__PURE__ */ h("p", {
						className: $.saveWarning,
						role: "status",
						children: [
							"“",
							p.patch.name,
							"” is already in My Presets. Saving replaces it."
						]
					}),
					/* @__PURE__ */ m("p", {
						id: f,
						className: $.saveNote,
						children: "Saved in this browser. Export a file to back it up or move it to another browser."
					}),
					/* @__PURE__ */ h("div", {
						className: $.saveButtons,
						children: [/* @__PURE__ */ m("button", {
							type: "button",
							onClick: r,
							children: "Cancel"
						}), /* @__PURE__ */ m("button", {
							type: "submit",
							className: $.saveButton,
							disabled: g,
							children: p ? "Replace" : "Save"
						})]
					})
				]
			})
		})
	});
}
// src/components/Live.tsx
function Vs() {
	let e = {
		pulsing: /* @__PURE__ */ new Set(),
		meter: 0,
		reductions: {},
		mixerLevels: {},
		wheels: null
	}, t = /* @__PURE__ */ new Set();
	return {
		get: () => e,
		set(n) {
			if (!Object.keys(n).every((t) => n[t] === e[t])) {
				e = {
					...e,
					...n
				};
				for (let e of t) e();
			}
		},
		subscribe(e) {
			return t.add(e), () => {
				t.delete(e);
			};
		}
	};
}
var Hs = t(null);
function Us({ select: e, children: t }) {
	let n = r(Hs), i = () => e(n.get());
	return /* @__PURE__ */ m(p, { children: t(f(n.subscribe, i, i)) });
}
// src/components/Wheels.tsx
var Ws = 80, Gs = .03, Ks = .05, qs = .25;
function Js({ levels: e, disabled: t, onMove: n }) {
	return /* @__PURE__ */ h("div", {
		className: $.wheels,
		role: "group",
		"aria-label": "Wheels",
		children: [/* @__PURE__ */ m(Ys, {
			kind: "bend",
			label: "Pitch",
			level: e.bend,
			disabled: t,
			onMove: n
		}), /* @__PURE__ */ m(Ys, {
			kind: "mod",
			label: "Mod",
			level: e.mod,
			disabled: t,
			onMove: n
		})]
	});
}
function Ys({ kind: e, label: t, level: n, disabled: r, onMove: a }) {
	let o = e === "bend", s = o ? -1 : 0, [c, l] = d(null), f = u(null), p = u(0), g = u(!1), _ = c ?? n, v = (e) => Math.max(s, Math.min(1, e)), y = () => {
		cancelAnimationFrame(p.current), p.current = 0;
	};
	i(() => y, []);
	let b = (t, n) => {
		let r = v(o && Math.abs(t) < Gs ? 0 : t);
		l(r), a(e, r, !0, n);
	}, x = (t) => {
		if (y(), !o || t === 0) {
			l(null), a(e, t, !1);
			return;
		}
		let n = performance.now(), r = (i) => {
			let o = Math.max(0, 1 - (i - n) / Ws);
			if (o > 0) {
				let n = t * o * o;
				l(n), a(e, n, !0), p.current = requestAnimationFrame(r);
			} else p.current = 0, l(null), a(e, 0, !1);
		};
		p.current = requestAnimationFrame(r);
	}, S = (e) => {
		r || e.button !== 0 || (e.preventDefault(), e.currentTarget.focus(), e.currentTarget.setPointerCapture(e.pointerId), y(), f.current = {
			pointer: e.pointerId,
			y: e.clientY,
			from: _
		}, b(_, e.timeStamp));
	}, C = (e) => {
		let t = f.current;
		if (!t || t.pointer !== e.pointerId) return;
		let n = e.currentTarget.clientHeight / (o ? 2 : 1) || 1;
		b(t.from + (t.y - e.clientY) / n, e.timeStamp);
	}, w = (e) => {
		f.current?.pointer === e.pointerId && (f.current = null, x(c ?? _));
	}, T = (e) => {
		let t = {
			ArrowUp: Ks,
			ArrowRight: Ks,
			ArrowDown: -.05,
			ArrowLeft: -.05,
			PageUp: qs,
			PageDown: -.25
		}[e.key], n = e.key === "Home" ? s : e.key === "End" ? 1 : t === void 0 ? null : v(_ + t);
		r || n === null || (e.preventDefault(), y(), g.current = !0, b(n));
	}, E = () => {
		g.current && (g.current = !1, x(c ?? _));
	}, D = Math.round(_ * 100);
	return /* @__PURE__ */ h("div", {
		className: $.wheelSlot,
		children: [/* @__PURE__ */ h("div", {
			className: $.wheel,
			"data-kind": e,
			"data-held": c !== null,
			role: "slider",
			tabIndex: r ? -1 : 0,
			"aria-disabled": r || void 0,
			"aria-label": `${t} wheel`,
			"aria-orientation": "vertical",
			"aria-valuemin": s * 100,
			"aria-valuemax": 100,
			"aria-valuenow": D,
			"aria-valuetext": o ? D ? `${D > 0 ? "Up" : "Down"} ${Math.abs(D)}%` : "Centre" : `${D}%`,
			title: o ? "Pitch wheel: drag up or down to bend; it springs back when let go. Each synth’s Bend sets how far." : "Mod wheel: drag up to bring in modulation; it stays where you leave it. Double-click takes it back down.",
			style: { "--wheel": _ },
			onPointerDown: S,
			onPointerMove: C,
			onPointerUp: w,
			onPointerCancel: w,
			onLostPointerCapture: w,
			onDoubleClick: () => {
				!o && !r && (b(0), x(0));
			},
			onKeyDown: T,
			onKeyUp: E,
			onBlur: E,
			children: [/* @__PURE__ */ m("span", {
				className: $.wheelRidges,
				"aria-hidden": "true"
			}), /* @__PURE__ */ m("span", {
				className: $.wheelMark,
				"aria-hidden": "true"
			})]
		}), /* @__PURE__ */ m("span", {
			className: $.wheelLabel,
			"aria-hidden": "true",
			children: t.toUpperCase()
		})]
	});
}
// src/components/seek.ts
var Xs = 4, Zs = (e) => `Bar ${Math.floor(e / 16) + 1}, beat ${Math.floor(e % 16 / Xs) + 1}`;
function Qs(e, t, n, r) {
	let i = u(null), a = u({
		step: 0,
		at: -Infinity
	}), o = (e) => Math.max(0, Math.min(t - Xs, Math.floor(e / Xs) * Xs)), s = (e) => {
		let n = e.currentTarget.getBoundingClientRect();
		return o((e.clientX - n.left) / n.width * t);
	}, c = n ?? 0;
	return {
		role: "slider",
		tabIndex: 0,
		"aria-label": `${e} playhead`,
		"aria-valuemin": 0,
		"aria-valuemax": t - 1,
		"aria-valuenow": c,
		"aria-valuetext": Zs(c),
		onPointerDown(e) {
			if (e.pointerType === "mouse" && e.button !== 0) return;
			let t = e.pointerType === "touch", n = s(e);
			i.current = {
				pointer: e.pointerId,
				x: e.clientX,
				y: e.clientY,
				touch: t,
				step: n
			}, t || (e.currentTarget.setPointerCapture?.(e.pointerId), r(n));
		},
		onPointerMove(e) {
			let t = i.current;
			if (!t || t.pointer !== e.pointerId) return;
			if (t.touch) {
				Math.hypot(e.clientX - t.x, e.clientY - t.y) > 8 && (i.current = null);
				return;
			}
			let n = s(e);
			n !== t.step && (t.step = n, r(n));
		},
		onPointerUp(e) {
			let t = i.current;
			i.current = null, t?.touch && t.pointer === e.pointerId && r(t.step);
		},
		onPointerCancel() {
			i.current = null;
		},
		onLostPointerCapture(e) {
			i.current?.pointer === e.pointerId && !i.current.touch && (i.current = null);
		},
		onKeyDown(e) {
			let n = o(e.timeStamp - a.current.at < 300 ? a.current.step : c), i = e.shiftKey ? 16 : Xs, s = {
				ArrowLeft: n - i,
				ArrowDown: n - i,
				ArrowRight: n + i,
				ArrowUp: n + i,
				PageDown: n - 16,
				PageUp: n + 16,
				Home: 0,
				End: t - 16
			}[e.key];
			s !== void 0 && (e.preventDefault(), e.stopPropagation(), a.current = {
				step: o(s),
				at: e.timeStamp
			}, r(o(s)));
		}
	};
}
// src/pianoRoll.ts
function $s(e) {
	let t = [...e].sort((e, t) => e.note[0] - t.note[0] || e.note[2] - t.note[2] || Number(t.selected) - Number(e.selected)), n = [], r = /* @__PURE__ */ new Set();
	for (let e of t) {
		let t = n.at(-1);
		t && t[0] === e.note[0] && t[2] === e.note[2] || (e.selected && r.add(n.length), n.push(e.note));
	}
	return {
		notes: n,
		selected: r
	};
}
var ec = (e, t, n) => $s(e.map((e, r) => t.has(r) ? {
	note: n(e),
	selected: !0
} : {
	note: e,
	selected: !1
})), tc = (e, t, n) => Math.max(t, Math.min(n, e)), nc = (e, t) => t ? Math.floor(e / t) * t : Math.round(e), rc = (e, t) => t ? Math.round(e / t) * t : Math.round(e);
function ic(e, t, n) {
	for (let r = e.length - 1; r >= 0; r--) {
		let [i, a, o] = e[r];
		if (o === n && i <= t && t < i + a) return r;
	}
	return -1;
}
function ac(e, t, n, r, i) {
	let a = /* @__PURE__ */ new Set();
	return e.forEach(([e, o, s], c) => {
		s >= r && s <= i && e < n && e + o > t && a.add(c);
	}), a;
}
function oc(e, t, n, r, i, a) {
	if (e.length >= 2048) return {
		notes: [...e],
		selected: /* @__PURE__ */ new Set()
	};
	let o = tc(Math.round(t), 0, a - 1), s = [
		o,
		tc(Math.round(n), 1, a - o),
		tc(Math.round(r), 0, 127),
		tc(Math.round(i), 1, 127)
	];
	return $s([...e.map((e) => ({
		note: e,
		selected: !1
	})), {
		note: s,
		selected: !0
	}]);
}
var sc = (e, t) => ({
	notes: e.filter((e, n) => !t.has(n)),
	selected: /* @__PURE__ */ new Set()
});
function cc(e, t, n, r, i) {
	let a = e.filter((e, n) => t.has(n));
	if (!a.length) return {
		notes: [...e],
		selected: /* @__PURE__ */ new Set()
	};
	let o = Math.min(...a.map((e) => e[0])), s = Math.max(...a.map((e) => e[0])), c = Math.min(...a.map((e) => e[2])), l = Math.max(...a.map((e) => e[2])), u = tc(Math.round(n), -o, i - 1 - s), d = tc(Math.round(r), -c, 127 - l);
	return ec(e, t, ([e, t, n, r]) => [
		e + u,
		Math.min(t, i - e - u),
		n + d,
		r
	]);
}
function lc(e, t, n, r, i = 1) {
	return ec(e, t, ([e, t, a, o]) => [
		e,
		tc(Math.round(t + n), Math.min(i, r - e), r - e),
		a,
		o
	]);
}
function uc(e, t, n, r = !1) {
	return ec(e, t, ([e, t, i, a]) => [
		e,
		t,
		i,
		tc(Math.round(r ? n : a + n), 1, 127)
	]);
}
function dc(e, t, n, r, i) {
	return ec(e, t, ([e, t, a, o]) => {
		let s = O(e, n, r, i);
		return [
			s,
			tc(t, 1, i - s),
			a,
			o
		];
	});
}
function fc(e, t, n, r) {
	let i = e.filter((e, n) => t.has(n));
	if (!i.length) return {
		notes: [...e],
		selected: /* @__PURE__ */ new Set()
	};
	let a = Math.min(...i.map((e) => e[0])), o = Math.max(...i.map((e) => e[0] + e[1])), s = Math.max(n, Math.ceil((o - a) / n) * n), c = i.map(([e, t, n, i]) => [
		e + s,
		Math.min(t, r - e - s),
		n,
		i
	]).filter(([e]) => e < r).slice(0, Math.max(0, y - e.length));
	return $s([...e.map((e) => ({
		note: e,
		selected: !1
	})), ...c.map((e) => ({
		note: e,
		selected: !0
	}))]);
}
// src/components/PianoRoll.tsx
var pc = 11, mc = 42, hc = 16, gc = 48, _c = 3, vc = 64, yc = 1408, bc = /* @__PURE__ */ new Set([
	1,
	3,
	6,
	8,
	10
]), xc = {
	3840: "1 bar",
	1920: "1/2",
	960: "1/4",
	480: "1/8",
	320: "1/8T",
	240: "1/16",
	160: "1/16T",
	120: "1/32"
}, Sc = (e) => xc[e] ?? `${e} ticks`, Cc = (e, t, n) => Math.max(t, Math.min(n, e)), wc = (e, t) => e.length === t.length && e.every((e, n) => e.every((e, r) => e === t[n][r])), Tc = (e, t) => e.length === t.length && e.every(([e, n], r) => e === t[r][0] && n === t[r][1]), Ec = [
	[
		"vel",
		"VEL",
		"Velocity",
		"Velocity: drag a note’s bar to set how hard it is played"
	],
	[
		"bend",
		"PITCH",
		"Pitch",
		"Pitch wheel: draw bends up or down from the centre line. Each synth’s Bend sets how far the wheel reaches."
	],
	[
		"mod",
		"MOD",
		"Mod",
		"Mod wheel: draw how far it is pushed up, bringing in each synth’s modulation"
	]
], Dc = (e, t) => e === "bend" ? gc / 2 - t * (gc / 2 - 3) : 45 - t * 42, Oc = (e, t) => e === "bend" ? `Pitch ${t > 0 ? "+" : ""}${t}` : `Mod ${t}`;
function kc({ name: e, notes: t, bends: n, mods: r, take: l, loop: f, grid: g, clock: _, disabled: v, onChange: y, onWheels: b, onAudition: S, onAuditionEnd: C, onClose: w, onSeek: T, handle: E }) {
	let D = f / 240, O = a().replace(/[^\w-]/g, ""), ee = a(), [k, te] = d("select"), [A, j] = d(g), [M, N] = d(13), [P, ne] = d(() => /* @__PURE__ */ new Set()), [re, ae] = d(null), [oe, se] = d(null), [F, ce] = d(() => ({
		tick: 0,
		pitch: t[0]?.[2] ?? 60
	})), [I, L] = d(!1), [le, R] = d({
		length: null,
		velocity: 100
	}), [ue, de] = d(null), [z, B] = d(!1), [fe, pe] = d(null), [V, me] = d("vel"), [he, ge] = d(null), [_e, ve] = d(null), ye = u(null), be = a(), xe = u(null), Se = u(null), Ce = u(null), we = u(t), Te = u(null), H = D * M, Ee = A ?? 240, De = {
		length: z && le.length !== null ? le.length : Ee,
		velocity: z ? le.velocity : 100
	}, Oe = (e) => e / 240 * M, ke = (e) => (127 - e) * pc;
	i(() => {
		t !== we.current && (we.current = t, ne(/* @__PURE__ */ new Set()), ae(null), se(null), xe.current = null);
	}, [t]), s(() => {
		let e = Se.current;
		e && N(Cc(Math.floor((e.clientWidth - mc) / D), _c, vc));
	}, [D]), s(() => {
		let e = Se.current;
		if (!e) return;
		let t = we.current.map((e) => e[2]), n = t.length ? (Math.min(...t) + Math.max(...t)) / 2 : 60;
		e.scrollTop = ke(n) - (e.clientHeight - hc - gc) / 2;
	}, []);
	let U = _ < 0 ? null : Oe(_ % D * 240), je = u(null), Me = Qs(e, D, _ < 0 ? null : _ % D, T);
	s(() => {
		let e = Se.current, t = je.current;
		if (je.current = U, !e || U === null || xe.current || ye.current) return;
		let n = (t) => t >= e.scrollLeft && t < e.scrollLeft + e.clientWidth - mc;
		!n(U) && (l || t !== null && n(t)) && (e.scrollLeft = Math.floor(U / (16 * M)) * 16 * M);
	}, [
		U,
		l,
		M
	]);
	let Ne = re?.notes ?? t, Pe = re?.selected ?? P, Le = Ne.reduce((e, [t]) => e + +(t < f), 0), Re = (e, n) => {
		we.current = e.notes, ne(e.selected), ae(null), wc(e.notes, t) || y(e.notes, n);
		let r = e.selected.size === 1 ? e.notes[[...e.selected][0]] : null;
		r && R({
			length: r[1],
			velocity: r[3]
		});
	}, ze = (e) => {
		let t = Ce.current.getBoundingClientRect();
		return {
			tick: Cc((e.clientX - t.left) / M * 240, 0, f - 1),
			pitch: Cc(127 - Math.floor((e.clientY - t.top) / pc), 0, 127),
			x: e.clientX,
			y: e.clientY
		};
	}, Be = (e, t, n = !1) => {
		v || S(e, t, n);
	}, Ve = () => C(), Ge = (e, t) => {
		let n = Se.current;
		if (!n) return;
		let r = Oe(e), i = ke(t), a = n.clientWidth - mc, o = n.clientHeight - hc - gc;
		(r < n.scrollLeft || r > n.scrollLeft + a - 24) && (n.scrollLeft = r - a / 3), (i < n.scrollTop || i > n.scrollTop + o - pc) && (n.scrollTop = i - o / 2);
	};
	function Ke(e) {
		if (e.button !== 0 || v || xe.current) return;
		e.preventDefault(), Ce.current?.focus({ preventScroll: !0 });
		let n = e.pointerType === "touch", r = ze(e), i = ic(t, r.tick, r.pitch), a = {
			pointer: e.pointerId,
			hit: i,
			tick: r.tick,
			pitch: r.pitch,
			x: r.x,
			y: r.y,
			moved: !1,
			extend: e.shiftKey,
			result: null,
			heard: r.pitch
		};
		if (i >= 0) {
			let [o, s, c, l] = t[i], u = P;
			if (e.shiftKey ? (u = new Set(P), u.has(i) ? u.delete(i) : u.add(i)) : P.has(i) || (u = /* @__PURE__ */ new Set([i])), ne(u), ce({
				tick: o,
				pitch: c
			}), !u.has(i)) return;
			let d = Oe(o + s) - (r.x - Ce.current.getBoundingClientRect().left) < Math.min(7, Oe(s) / 3);
			xe.current = {
				...a,
				kind: d ? "resize" : "move",
				origin: t,
				selected: u,
				anchor: d ? o + s : o,
				heard: c
			}, Be(c, l, n);
		} else if (k === "draw") {
			let e = oc(t, nc(r.tick, A), De.length, r.pitch, De.velocity, f);
			if (!e.selected.size) return;
			let [i, o] = e.notes[[...e.selected][0]];
			ae(e), ce({
				tick: i,
				pitch: r.pitch
			}), xe.current = {
				...a,
				kind: "draw",
				origin: e.notes,
				selected: e.selected,
				anchor: i + o,
				result: e
			}, Te.current = {
				note: r.pitch,
				tick: i,
				at: performance.now()
			}, Be(r.pitch, De.velocity, n);
		} else {
			let n = e.shiftKey ? new Set(P) : /* @__PURE__ */ new Set();
			ne(n), se([
				r.tick,
				r.tick,
				r.pitch,
				r.pitch
			]), ce({
				tick: nc(r.tick, A),
				pitch: r.pitch
			}), xe.current = {
				...a,
				kind: "marquee",
				origin: t,
				selected: n,
				anchor: r.tick
			};
		}
		e.currentTarget.setPointerCapture(e.pointerId);
	}
	function qe(e) {
		let t = xe.current;
		if (!t || t.pointer !== e.pointerId || t.kind === "velocity") return;
		let n = ze(e);
		if (!t.moved && Math.hypot(n.x - t.x, n.y - t.y) < 4) return;
		if (t.moved = !0, t.kind === "marquee") {
			let e = Math.min(t.tick, n.tick), r = Math.max(t.tick, n.tick), i = Math.min(t.pitch, n.pitch), a = Math.max(t.pitch, n.pitch), o = ac(t.origin, e, r, i, a);
			for (let e of t.selected) o.add(e);
			se([
				e,
				r,
				i,
				a
			]), ne(o);
			return;
		}
		let r = n.tick - t.tick;
		if (t.kind === "move") {
			let i = t.origin[t.hit][2] + n.pitch - t.pitch;
			t.result = cc(t.origin, t.selected, rc(t.anchor + r, A) - t.anchor, n.pitch - t.pitch, f), i !== t.heard && i >= 0 && i <= 127 && (t.heard = i, Ve(), Be(i, t.origin[t.hit][3], e.pointerType === "touch"));
		} else t.result = lc(t.origin, t.selected, rc(t.anchor + r, A) - t.anchor, f, A ?? 30);
		ae(t.result);
	}
	function Je(e) {
		let t = xe.current;
		t && t.pointer === e.pointerId && (xe.current = null, Ve(), se(null), t.kind !== "marquee" && (!t.moved && t.kind !== "draw" ? (!t.extend && t.hit >= 0 && ne(/* @__PURE__ */ new Set([t.hit])), ae(null)) : t.result ? Re(t.result) : ae(null)));
	}
	function Ye(e) {
		let t = xe.current;
		t && t.pointer === e.pointerId && (xe.current = null, Ve(), ae(null), se(null));
	}
	function Xe(e) {
		if (v) return;
		let n = ze(e), r = ic(t, n.tick, n.pitch), i = Te.current;
		r >= 0 && !(i && performance.now() - i.at < 600 && t[r][2] === i.note && t[r][0] === i.tick) ? Re(sc(t, /* @__PURE__ */ new Set([r]))) : r < 0 && k === "select" && Re(oc(t, nc(n.tick, A), De.length, n.pitch, De.velocity, f));
	}
	function Ze(e) {
		if (e.button !== 0 || v || xe.current) return;
		let n = e.currentTarget.getBoundingClientRect(), r = e.clientX - n.left, i = -1, a = 8;
		if (t.forEach(([e], t) => {
			let n = Math.abs(Oe(e) + 1 - r) - (P.has(t) ? .5 : 0);
			e < f && n < a && (i = t, a = n);
		}), i < 0) return;
		e.preventDefault();
		let o = P.has(i) ? P : /* @__PURE__ */ new Set([i]);
		ne(o), xe.current = {
			kind: "velocity",
			pointer: e.pointerId,
			origin: t,
			selected: o,
			hit: i,
			anchor: t[i][3],
			tick: 0,
			pitch: 0,
			x: e.clientX,
			y: e.clientY,
			moved: !0,
			extend: !1,
			result: null,
			heard: -1
		}, e.currentTarget.setPointerCapture(e.pointerId), W(e);
	}
	function W(e) {
		let t = xe.current;
		if (!t || t.pointer !== e.pointerId || t.kind !== "velocity") return;
		let n = e.currentTarget.getBoundingClientRect(), r = Cc(Math.round((1 - (e.clientY - n.top - 3) / 42) * 127), 1, 127);
		t.result = t.selected.size === 1 ? uc(t.origin, t.selected, r, !0) : uc(t.origin, t.selected, r - t.anchor), ae(t.result);
	}
	function G(e) {
		let t = xe.current;
		t && t.pointer === e.pointerId && (xe.current = null, t.result ? Re(t.result) : ae(null));
	}
	function K(e, t) {
		let n = t.currentTarget.getBoundingClientRect(), r = t.clientY - n.top, i = Cc(Math.floor((t.clientX - n.left) / M * 240), 0, f - 1), a = e === "bend" ? Cc((gc / 2 - r) / (gc / 2 - 3), -1, 1) : Cc((45 - r) / 42, 0, 1);
		return [i, Ie(e, e === "bend" && Math.abs(a) < .04 ? 0 : a)];
	}
	function q(e, t) {
		let n = A ?? 30;
		for (let [r, i] of We(e.kind, e.last, t, n)) r < f && e.cells.set(r, i);
		e.last = t, e.low = Math.min(e.low, t[0]), e.high = Math.max(e.high, t[0]);
		let r = Math.floor(e.low / n) * n, i = Math.min(f, (Math.floor(e.high / n) + 1) * n);
		e.result = e.erase ? Ue(e.origin, r, i) : He(e.origin, r, i, [...e.cells], f, Ae[e.kind].rest), ge(e.result), ve(e.erase ? null : t);
	}
	function J(e) {
		if (V === "vel" || e.button !== 0 || v || xe.current || ye.current) return;
		e.preventDefault();
		let t = K(V, e);
		ye.current = {
			pointer: e.pointerId,
			kind: V,
			origin: V === "bend" ? n : r,
			cells: /* @__PURE__ */ new Map(),
			last: t,
			erase: e.altKey,
			low: t[0],
			high: t[0],
			result: null
		}, e.currentTarget.setPointerCapture(e.pointerId), q(ye.current, t);
	}
	function Y(e) {
		let t = ye.current;
		t && t.pointer === e.pointerId && q(t, K(t.kind, e));
	}
	function Qe(e) {
		let t = ye.current;
		t && t.pointer === e.pointerId && (ye.current = null, ge(null), ve(null), e.type !== "pointercancel" && t.result && !Tc(t.result, t.origin) && b(t.kind, t.result));
	}
	let $e = () => new Set(t.flatMap(([e], t) => e < f ? [t] : []));
	function et(e) {
		let n = [...$e()];
		if (!n.length) return;
		let r = P.size ? Math.min(...P) : -1, i = n[(((r >= 0 ? n.indexOf(r) : n.findIndex((e) => t[e][0] >= F.tick) - +(e > 0)) + e) % n.length + n.length) % n.length];
		ne(/* @__PURE__ */ new Set([i])), ce({
			tick: t[i][0],
			pitch: t[i][2]
		}), Ge(t[i][0], t[i][2]), Be(t[i][2], t[i][3]), window.setTimeout(Ve, 160);
	}
	function tt(e) {
		if (xe.current || v || e.defaultPrevented) return;
		let n = e.key, r = e.metaKey || e.ctrlKey, i = P.size > 0, a = null;
		if (r && n.toLowerCase() === "a") ne($e());
		else if (r && n.toLowerCase() === "d") i && (a = fc(t, P, Math.max(Ee, 960), f));
		else if (r || e.altKey) return;
		else if (n === "Delete" || n === "Backspace") {
			if (i) a = sc(t, P);
			else return;
		} else if (n === "ArrowUp" || n === "ArrowDown") {
			let r = (n === "ArrowUp" ? 1 : -1) * (e.shiftKey ? 12 : 1);
			if (i) a = cc(t, P, 0, r, f);
			else {
				let e = Cc(F.pitch + r, 0, 127);
				ce({
					...F,
					pitch: e
				}), Ge(F.tick, e);
			}
		} else if (n === "ArrowLeft" || n === "ArrowRight") {
			let r = n === "ArrowRight" ? 1 : -1;
			if (i && e.shiftKey) a = lc(t, P, r * Ee, f, Ee);
			else if (i) a = cc(t, P, r * Ee, 0, f);
			else {
				let t = Cc(nc(F.tick, A) + r * (e.shiftKey ? 3840 : Ee), 0, f - Ee);
				ce({
					...F,
					tick: t
				}), Ge(t, F.pitch);
			}
		} else if (n === "n" || n === "N") a = oc(t, F.tick, De.length, F.pitch, De.velocity, f), Be(F.pitch, De.velocity), window.setTimeout(Ve, 160);
		else if (n === "]" || n === "[") et(n === "]" ? 1 : -1);
		else if (n === "Escape") i ? ne(/* @__PURE__ */ new Set()) : w();
		else return;
		if (e.preventDefault(), e.stopPropagation(), a) {
			Re(a);
			let e = a.notes[Math.min(...a.selected)];
			e && (ce({
				tick: e[0],
				pitch: e[2]
			}), Ge(e[0], e[2]));
		}
	}
	let nt = P.size === 1 ? t[[...P][0]] : null, rt = _e && V !== "vel" ? `${Oc(V, _e[1])} at ${ie(Math.floor(_e[0] / 240), D)}` : nt ? `${_r(nt[2])} at ${ie(Math.floor(nt[0] / 240), D)}, ${Sc(nt[1])}, velocity ${nt[3]}` : P.size ? `${P.size} of ${Le} notes selected` : `${Le} ${Le === 1 ? "note" : "notes"} · cursor ${_r(F.pitch)} at ${ie(Math.floor(F.tick / 240), D)}`, it = P.size ? t[Math.min(...P)]?.[3] ?? "" : "", at = (e, n) => {
		P.size && Re(e(t, P), n);
	};
	o(E, () => ({ quantize: (e) => v || !P.size ? 0 : (Re(dc(t, P, e, 1, f)), P.size) }));
	let ot = c(() => Array.from({ length: 128 }, (e, t) => {
		let n = 127 - t, r = bc.has(n % 12);
		return /* @__PURE__ */ h("g", {
			"data-pitch": n,
			"data-down": n === fe,
			children: [
				/* @__PURE__ */ m("rect", {
					y: t * pc,
					width: mc,
					height: pc,
					className: $.rollWhite
				}),
				r && /* @__PURE__ */ m("rect", {
					y: t * pc,
					width: mc * .6,
					height: pc,
					className: $.rollBlack
				}),
				n % 12 == 0 && /* @__PURE__ */ m("text", {
					x: 39,
					y: t * pc + pc - 2,
					children: _r(n)
				})
			]
		}, n);
	}), [fe]), st = (e) => Cc(127 - Math.floor((e.clientY - e.currentTarget.getBoundingClientRect().top) / pc), 0, 127), ct = () => {
		fe !== null && (pe(null), Ve());
	}, X = c(() => Ne.map(([e, t, n, r], i) => e < f && /* @__PURE__ */ m("rect", {
		className: $.rollNote,
		x: Oe(e),
		y: ke(n) + 1,
		width: Math.max(3, Oe(t) - 1),
		height: 9,
		rx: 2,
		fillOpacity: .5 + r / 127 * .5,
		"data-note": n,
		"data-tick": e,
		"data-length": t,
		"data-velocity": r,
		"data-selected": Pe.has(i)
	}, i)), [
		Ne,
		Pe,
		f,
		M
	]), lt = Math.ceil(D / 16), [ut, dt] = Ec.find(([e]) => e === V).slice(2), ft = V === "vel" ? null : he ?? (V === "bend" ? n : r), pt = ft?.filter(([e]) => e < f).length ?? 0, mt = c(() => {
		if (V === "vel" || !ft) return null;
		let e = ft.filter(([e]) => e < f);
		if (!e.length) return null;
		let t = (e) => Dc(V, Fe(V, e)), n = `M0 ${t(e.at(-1)[1])}`;
		for (let [r, i] of e) n += `H${Oe(r)}V${t(i)}`;
		return n += `H${H}`, {
			line: n,
			area: `${n}V${Dc(V, 0)}H0Z`
		};
	}, [
		V,
		ft,
		f,
		M,
		H
	]);
	return /* @__PURE__ */ h("div", {
		className: $.pianoRoll,
		role: "group",
		"aria-label": `${e} piano roll`,
		children: [
			/* @__PURE__ */ h("div", {
				className: $.rollTools,
				children: [
					/* @__PURE__ */ h("span", {
						className: $.rollToolGroup,
						role: "group",
						"aria-label": "Tool",
						children: [
							/* @__PURE__ */ m("button", {
								"aria-pressed": k === "select",
								onClick: () => te("select"),
								title: "Drag across notes to select them; double-click to add one",
								children: "Select"
							}),
							/* @__PURE__ */ m("button", {
								"aria-pressed": k === "draw",
								onClick: () => te("draw"),
								title: "Click to draw a note, drag right or left to set its length",
								children: "Draw"
							}),
							/* @__PURE__ */ m("button", {
								"aria-pressed": z,
								onClick: () => B(!z),
								title: "New notes take the length and velocity of the last note you drew or edited. Off, each starts one Snap step long at velocity 100.",
								children: "Inherit"
							})
						]
					}),
					/* @__PURE__ */ h("label", {
						className: $.playsControl,
						title: "Where notes land as you draw, move and resize them; Off places them freely. Quantize, beside the clip's settings, is separate.",
						children: ["SNAP", /* @__PURE__ */ h("select", {
							"aria-label": "Snap",
							value: A ?? 0,
							onChange: (e) => j(Number(e.target.value) || null),
							children: [x.map(([e, t]) => /* @__PURE__ */ m("option", {
								value: t,
								children: e
							}, t)), /* @__PURE__ */ m("option", {
								value: 0,
								children: "Off"
							})]
						})]
					}),
					/* @__PURE__ */ h("span", {
						className: $.rollToolGroup,
						role: "group",
						"aria-label": "Zoom",
						children: [/* @__PURE__ */ m("button", {
							"aria-label": "Zoom out",
							title: "Zoom out",
							disabled: M <= _c,
							onClick: () => N(Math.max(_c, Math.floor(M / 1.5))),
							children: "−"
						}), /* @__PURE__ */ m("button", {
							"aria-label": "Zoom in",
							title: "Zoom in",
							disabled: M >= vc,
							onClick: () => N(Math.min(vc, Math.ceil(M * 1.5))),
							children: "＋"
						})]
					}),
					/* @__PURE__ */ h("label", {
						className: $.playsControl,
						title: "The selected notes' velocity, 1 to 127, as hard as each is played. The bars under the grid set it by dragging.",
						children: ["VEL", /* @__PURE__ */ m("input", {
							type: "number",
							min: 1,
							max: 127,
							"aria-label": "Velocity of the selected notes",
							disabled: v || !P.size,
							value: ue ?? it,
							onChange: (e) => {
								let t = Number(e.target.value);
								de(e.target.value), e.target.value && t >= 1 && t <= 127 && at((e, n) => uc(e, n, Math.round(t), !0), "roll-velocity");
							},
							onBlur: () => de(null)
						})]
					}),
					/* @__PURE__ */ m("span", {
						className: $.rollToolGroup,
						role: "group",
						"aria-label": "Transpose",
						children: [
							[
								-12,
								"down an octave",
								"−12"
							],
							[
								-1,
								"down a semitone",
								"−1"
							],
							[
								1,
								"up a semitone",
								"+1"
							],
							[
								12,
								"up an octave",
								"+12"
							]
						].map(([e, t, n]) => /* @__PURE__ */ m("button", {
							"aria-label": `Transpose ${t}`,
							title: `Move the selected notes ${t}${Math.abs(e) === 12 ? " (Shift+↑/↓)" : " (↑/↓)"}`,
							disabled: v || !P.size,
							onClick: () => at((t, n) => cc(t, n, 0, e, f)),
							children: n
						}, e))
					}),
					/* @__PURE__ */ m("button", {
						disabled: v || !P.size,
						onClick: () => at((e, t) => fc(e, t, Math.max(Ee, 960), f)),
						title: "Copy the selected notes to just after them (⌘D / Ctrl+D)",
						children: "Duplicate"
					}),
					/* @__PURE__ */ m("button", {
						disabled: v || !P.size,
						onClick: () => at(sc),
						"aria-label": "Delete the selected notes",
						title: "Delete the selected notes (Delete)",
						children: "Delete"
					}),
					/* @__PURE__ */ m("button", {
						disabled: !Le,
						onClick: () => ne($e()),
						title: "Select every note in the clip (⌘A / Ctrl+A)",
						children: "Select all"
					}),
					V !== "vel" && /* @__PURE__ */ h("button", {
						disabled: v || !(V === "bend" ? n : r).length,
						onClick: () => b(V, []),
						"aria-label": `Clear the ${ut} lane`,
						title: `Delete every point in the ${ut.toUpperCase()} lane, leaving the wheel at rest. Undo brings them back.`,
						children: ["Clear ", V === "bend" ? "PITCH" : "MOD"]
					}),
					/* @__PURE__ */ m("span", {
						className: $.rollStatus,
						"aria-live": "polite",
						children: rt
					}),
					/* @__PURE__ */ m("button", {
						className: $.rollClose,
						"aria-label": "Close piano roll",
						title: "Close the piano roll",
						onClick: w,
						children: "×"
					})
				]
			}),
			/* @__PURE__ */ m("div", {
				ref: Se,
				className: $.rollScroller,
				children: /* @__PURE__ */ h("div", {
					className: $.rollCanvas,
					style: { width: mc + H },
					children: [
						/* @__PURE__ */ h("div", {
							className: $.rollRulerRow,
							children: [/* @__PURE__ */ m("span", { className: $.rollCorner }), /* @__PURE__ */ h("svg", {
								className: $.rollRuler,
								width: H,
								height: hc,
								style: {
									width: H,
									height: hc
								},
								...Me,
								children: [Array.from({ length: lt }, (e, t) => /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("line", {
									x1: t * 16 * M,
									x2: t * 16 * M,
									y1: 0,
									y2: hc
								}), /* @__PURE__ */ m("text", {
									x: t * 16 * M + 3,
									y: 12,
									children: t + 1
								})] }, t)), U !== null && /* @__PURE__ */ m("line", {
									className: $.playhead,
									x1: U,
									x2: U,
									y1: 0,
									y2: hc
								})]
							})]
						}),
						/* @__PURE__ */ h("div", {
							className: $.rollBody,
							children: [/* @__PURE__ */ m("svg", {
								className: $.rollKeys,
								width: mc,
								height: yc,
								style: {
									width: mc,
									height: yc
								},
								"aria-hidden": "true",
								onPointerDown: (e) => {
									if (e.pointerType !== "mouse" || e.button !== 0) return;
									let t = st(e);
									pe(t), Be(t, 100);
								},
								onPointerMove: (e) => {
									if (fe === null) return;
									let t = st(e);
									t !== fe && (Ve(), pe(t), Be(t, 100));
								},
								onPointerUp: ct,
								onPointerLeave: ct,
								onPointerCancel: ct,
								children: ot
							}), /* @__PURE__ */ h("svg", {
								ref: Ce,
								className: $.rollGrid,
								width: H,
								height: yc,
								style: {
									width: H,
									height: yc
								},
								tabIndex: 0,
								role: "application",
								"aria-label": `${e} notes`,
								"aria-describedby": ee,
								"data-notes": Le,
								"data-tool": k,
								onPointerDown: Ke,
								onPointerMove: qe,
								onPointerUp: Je,
								onPointerCancel: Ye,
								onLostPointerCapture: Je,
								onDoubleClick: Xe,
								onKeyDown: tt,
								onFocus: () => L(!0),
								onBlur: () => L(!1),
								children: [
									/* @__PURE__ */ h("defs", { children: [/* @__PURE__ */ m("pattern", {
										id: `${O}rows`,
										width: H,
										height: 132,
										patternUnits: "userSpaceOnUse",
										children: Array.from({ length: 12 }, (e, t) => {
											let n = 127 - t;
											return /* @__PURE__ */ h("g", { children: [bc.has(n % 12) && /* @__PURE__ */ m("rect", {
												y: t * pc,
												width: H,
												height: pc,
												className: $.rollShade
											}), /* @__PURE__ */ m("line", {
												x1: 0,
												x2: H,
												y1: (t + 1) * pc,
												y2: (t + 1) * pc,
												className: n % 12 == 0 ? $.rollOctave : $.rollRowLine
											})] }, t);
										})
									}), /* @__PURE__ */ m("pattern", {
										id: `${O}beats`,
										width: 16 * M,
										height: yc,
										patternUnits: "userSpaceOnUse",
										children: Array.from({ length: 16 }, (e, t) => (t % 4 == 0 || M >= 8) && /* @__PURE__ */ m("line", {
											x1: t * M,
											x2: t * M,
											y1: 0,
											y2: yc,
											className: t === 0 ? $.rollBar : t % 4 == 0 ? $.rollBeat : $.rollStep
										}, t))
									})] }),
									/* @__PURE__ */ m("rect", {
										width: H,
										height: yc,
										fill: `url(#${O}rows)`
									}),
									/* @__PURE__ */ m("rect", {
										width: H,
										height: yc,
										fill: `url(#${O}beats)`
									}),
									X,
									l?.map(([e, t, n], r) => e < f && /* @__PURE__ */ m("rect", {
										className: $.rollTake,
										x: Oe(e),
										y: ke(n) + 1,
										width: Math.max(3, Oe(t) - 1),
										height: 9,
										rx: 2
									}, `take${r}`)),
									I && !P.size && /* @__PURE__ */ m("rect", {
										className: $.rollCursor,
										x: Oe(F.tick),
										y: ke(F.pitch),
										width: Math.max(3, Oe(De.length)),
										height: pc
									}),
									oe && /* @__PURE__ */ m("rect", {
										className: $.rollMarquee,
										x: Oe(oe[0]),
										y: ke(oe[3]),
										width: Oe(oe[1] - oe[0]),
										height: (oe[3] - oe[2] + 1) * pc
									}),
									U !== null && /* @__PURE__ */ m("line", {
										className: $.playhead,
										x1: U,
										x2: U,
										y1: 0,
										y2: yc
									})
								]
							})]
						}),
						/* @__PURE__ */ h("div", {
							className: $.rollLaneRow,
							children: [/* @__PURE__ */ m("span", {
								className: `${$.rollLaneLabel} ${$.rollLaneTabs}`,
								role: "tablist",
								"aria-label": "Lane",
								"aria-orientation": "vertical",
								children: Ec.map(([e, t, , n]) => /* @__PURE__ */ m("button", {
									role: "tab",
									"aria-selected": V === e,
									"aria-controls": be,
									tabIndex: V === e ? 0 : -1,
									title: n,
									onClick: () => me(e),
									onKeyDown: (e) => {
										let t = e.key === "ArrowDown" ? 1 : e.key === "ArrowUp" ? -1 : 0;
										if (!t) return;
										e.preventDefault();
										let n = Ec[(Ec.findIndex(([e]) => e === V) + t + Ec.length) % Ec.length][0];
										me(n), (e.currentTarget.parentElement?.querySelector(`[data-lane="${n}"]`))?.focus();
									},
									"data-lane": e,
									children: t
								}, e))
							}), V === "vel" ? /* @__PURE__ */ m("svg", {
								id: be,
								className: $.rollLane,
								width: H,
								height: gc,
								style: {
									width: H,
									height: gc
								},
								role: "img",
								"aria-label": "Note velocities",
								"data-lane": "vel",
								onPointerDown: Ze,
								onPointerMove: W,
								onPointerUp: G,
								onPointerCancel: Ye,
								onLostPointerCapture: G,
								children: Ne.map(([e, , , t], n) => e < f && /* @__PURE__ */ m("rect", {
									x: Oe(e),
									y: 45 - t / 127 * 42,
									width: 3,
									height: t / 127 * 42,
									"data-velocity": t,
									"data-selected": Pe.has(n)
								}, n))
							}) : /* @__PURE__ */ h("svg", {
								id: be,
								className: $.rollLane,
								width: H,
								height: gc,
								style: {
									width: H,
									height: gc
								},
								role: "img",
								"aria-label": `${ut} wheel lane, ${pt} ${pt === 1 ? "point" : "points"}`,
								"data-lane": V,
								"data-points": pt,
								onPointerDown: J,
								onPointerMove: Y,
								onPointerUp: Qe,
								onPointerCancel: Qe,
								onLostPointerCapture: Qe,
								children: [
									/* @__PURE__ */ m("title", { children: `${dt}${dt.endsWith(".") ? "" : "."} Alt-drag erases.` }),
									V === "bend" && /* @__PURE__ */ m("line", {
										className: $.rollLaneCentre,
										x1: 0,
										x2: H,
										y1: gc / 2,
										y2: gc / 2
									}),
									mt && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", {
										className: $.rollWheelArea,
										d: mt.area
									}), /* @__PURE__ */ m("path", {
										className: $.rollWheelLine,
										d: mt.line
									})] }),
									U !== null && /* @__PURE__ */ m("line", {
										className: $.playhead,
										x1: U,
										x2: U,
										y1: 0,
										y2: gc
									})
								]
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ h("p", {
				id: ee,
				className: $.visuallyHidden,
				children: [
					k === "select" ? "Drag across notes to select them; double-click to add one. " : "Click to draw a note and drag right or left to set its length. ",
					z ? "New notes take the length and velocity of the last note drawn or edited. " : "New notes start one Snap step long at velocity 100. ",
					"Drag a note to move it, or its right edge to resize; double-click deletes it. Under the grid, VEL, PITCH and MOD pick the lane: drag in PITCH or MOD to draw the wheel's moves, and Alt-drag to erase them. Keys: arrows move the selection or the cursor, Shift+←/→ resizes, Shift+↑/↓ moves an octave, N adds a note at the cursor, [ and ] step through notes, Delete removes and ⌘D duplicates. Click or drag the bar numbers to move the playhead, or tap them on a touch screen, where dragging the keys or bar numbers scrolls."
				]
			})
		]
	});
}
// src/components/Dictator.tsx
var Ac = [
	"monarch",
	"oracle",
	"aurora",
	"prism"
], jc = (e) => Ac.includes(e.type) || Qt(e.type), Mc = [], Nc = [], Pc = Array.from({ length: 41 }, (e, t) => t * 5 - 100);
function Fc({ module: e, patch: t, name: n, clock: r, take: i, armed: a, recording: o, disabled: s, control: c, transport: l, plays: d, offset: f, editing: p, grid: g, onParam: _, onPlays: v, onArm: y, onClear: b, onQuantize: S, onCapture: w, onDiscard: T, onOffset: E, onEditing: D, onNotes: O, onWheels: ee, onAudition: k, onAuditionEnd: te, onSeek: A, importing: j, onExportMidi: M, onImportMidi: N, onImportTracks: P, onImportCancel: ne }) {
	let re = u(null), ae = u(null), oe = u(null), se = e.notes ?? Mc, F = C(e.params.length), ce = F / 240, I = t.modules.filter(jc), L = se.length + (i?.length ?? 0), le = o && a, R = e.params.qrec === 1, ue = x[e.params.quantize]?.[0] ?? "1/16";
	return /* @__PURE__ */ h("div", {
		className: $.dictatorBody,
		children: [
			/* @__PURE__ */ h("div", {
				className: $.sequenceTop,
				children: [
					/* @__PURE__ */ h("div", {
						className: $.lcd,
						children: [
							/* @__PURE__ */ m("small", { children: le ? "RECORDING" : "CLIP" }),
							/* @__PURE__ */ m("strong", { children: ie(Math.max(0, r), ce).split(".").slice(0, 2).join(".") }),
							/* @__PURE__ */ m("span", {
								className: $.lcdDots,
								"aria-hidden": "true"
							})
						]
					}),
					/* @__PURE__ */ h("button", {
						className: $.armButton,
						"aria-pressed": a,
						"data-recording": le,
						disabled: s,
						"aria-label": `${a ? "Disarm" : "Arm"} ${n} to record`,
						title: "Arm this DICTATOR to record into it: the keys play through it, and RECORD or R records what you play. With more than one DICTATOR, only the armed one records; arming another disarms this one.",
						onClick: y,
						children: [/* @__PURE__ */ m("span", { className: $.armLed }), "ARM"]
					}),
					/* @__PURE__ */ h("div", {
						className: $.controls,
						children: [
							c("length"),
							c("mode"),
							c("lag")
						]
					}),
					/* @__PURE__ */ h("div", {
						className: $.transport,
						children: [l, /* @__PURE__ */ m("span", {
							className: $.transportCaption,
							children: "LOOPING CLIP / POLY"
						})]
					})
				]
			}),
			/* @__PURE__ */ h("div", {
				className: $.quantizeRow,
				children: [
					c("quantize"),
					/* @__PURE__ */ m("button", {
						disabled: s || !se.some(([e]) => e < F),
						"aria-label": `Quantize notes in ${n}`,
						onClick: () => S(p ? oe.current?.quantize(g) ?? 0 : 0),
						title: `Move note starts onto the ${ue} grid now: the notes selected in the piano roll, or else every note. Undo moves them back.`,
						children: "Quantize"
					}),
					/* @__PURE__ */ h("button", {
						className: $.lampButton,
						"aria-pressed": R,
						disabled: s,
						"aria-label": `Auto-quantize ${n} while recording`,
						onClick: () => _("qrec", +!R),
						title: Z.dictator.params.find((e) => e.id === "qrec")?.hint,
						children: [/* @__PURE__ */ m("span", { className: $.lampLed }), "AUTO"]
					})
				]
			}),
			p ? /* @__PURE__ */ m(kc, {
				handle: oe,
				name: n,
				notes: se,
				take: i,
				loop: F,
				grid: g,
				clock: r,
				disabled: s,
				onChange: O,
				bends: e.bends ?? Nc,
				mods: e.mods ?? Nc,
				onWheels: ee,
				onAudition: k,
				onAuditionEnd: te,
				onSeek: A,
				onClose: () => {
					D(!1), re.current?.focus();
				}
			}) : /* @__PURE__ */ m(Lc, {
				name: n,
				notes: se,
				take: i,
				loop: F,
				position: r < 0 ? null : r % ce,
				onSeek: A,
				label: `${n} clip, ${L} ${L === 1 ? "note" : "notes"}`
			}),
			/* @__PURE__ */ h("div", {
				className: $.dictatorActions,
				children: [
					/* @__PURE__ */ h("label", {
						className: $.playsControl,
						title: "Patch this clip's Pitch and Gate into an instrument in one step. Undo puts the cables back.",
						children: ["PLAYS", /* @__PURE__ */ h("select", {
							"data-analytics-private": I.some((e) => e.label) ? "" : void 0,
							"aria-label": `${n} plays`,
							value: d ?? "",
							disabled: s,
							onChange: (e) => {
								e.target.value && v(e.target.value);
							},
							children: [/* @__PURE__ */ m("option", {
								value: "",
								children: d === null ? "Choose…" : "Patched by hand"
							}), I.map((e) => /* @__PURE__ */ m("option", {
								value: e.id,
								children: Gn(t, e)
							}, e.id))]
						})]
					}),
					/* @__PURE__ */ m("button", {
						ref: re,
						className: $.editButton,
						"aria-pressed": p,
						"aria-label": `Edit ${n} notes`,
						title: "Open the clip in the piano roll to draw, move and resize its notes",
						onClick: () => D(!p),
						children: "EDIT"
					}),
					le ? /* @__PURE__ */ m("button", {
						onClick: T,
						title: "Throw away this take so far and keep recording (Backspace)",
						children: "Discard take"
					}) : /* @__PURE__ */ m("button", {
						disabled: s || o,
						onClick: w,
						"aria-label": `Capture into ${n}`,
						title: "Keep what you just played with the transport running, without having pressed RECORD",
						children: "Capture"
					}),
					/* @__PURE__ */ m("button", {
						disabled: s || !wn(t, e),
						onClick: b,
						"aria-label": `Clear ${n} notes`,
						title: "Delete every note in the clip, and its PITCH and MOD lanes. Undo brings them back.",
						children: "Clear"
					}),
					/* @__PURE__ */ m("button", {
						disabled: !se.some(([e]) => e < F),
						onClick: M,
						"aria-label": `Export ${n} as a MIDI file`,
						title: "Save the clip as a .mid file, for a DAW or another Rackloose",
						children: "Export .mid"
					}),
					/* @__PURE__ */ m("button", {
						disabled: s || le,
						onClick: () => ae.current?.click(),
						"aria-label": `Import a MIDI file into ${n}`,
						title: "Replace the clip with the notes of a .mid file, up to 16 bars",
						children: "Import .mid"
					}),
					/* @__PURE__ */ m("input", {
						ref: ae,
						type: "file",
						accept: ".mid,.midi,audio/midi,audio/x-midi",
						hidden: !0,
						"aria-label": `MIDI file for ${n}`,
						onChange: (e) => {
							let t = e.target.files?.[0];
							e.target.value = "", t && N(t);
						}
					}),
					/* @__PURE__ */ h("label", {
						className: $.offsetControl,
						title: "If the notes you record land later than you played them, as with Bluetooth headphones or a slow keyboard, record them this much earlier; if they land early, later. It changes only what is recorded, never what you hear, and is kept in this browser, for every DICTATOR.",
						children: ["REC TIMING", /* @__PURE__ */ m("select", {
							"aria-label": "Recording timing",
							value: f,
							onChange: (e) => E(Number(e.target.value)),
							children: Pc.map((e) => /* @__PURE__ */ m("option", {
								value: e,
								children: e > 0 ? `${e} ms earlier` : e < 0 ? `${-e} ms later` : "As played"
							}, e))
						})]
					})
				]
			}),
			j && /* @__PURE__ */ m(Ic, {
				importing: j,
				onPick: P,
				onCancel: ne
			})
		]
	});
}
function Ic({ importing: e, onPick: t, onCancel: n }) {
	let [r, i] = d("all"), a = (e) => `${e} ${e === 1 ? "note" : "notes"}`;
	return /* @__PURE__ */ h("div", {
		className: $.midiTracks,
		role: "group",
		"aria-label": `Tracks of ${e.file}`,
		children: [
			/* @__PURE__ */ h("span", { children: [
				e.file,
				" has ",
				e.tracks.length,
				" tracks."
			] }),
			/* @__PURE__ */ h("select", {
				"aria-label": "Track to import",
				value: r,
				autoFocus: !0,
				onChange: (e) => i(e.target.value),
				children: [/* @__PURE__ */ h("option", {
					value: "all",
					children: ["All tracks · ", a(e.tracks.reduce((e, t) => e + t.notes.length, 0))]
				}), e.tracks.map((e, t) => /* @__PURE__ */ h("option", {
					value: t,
					children: [
						e.name,
						" · ch ",
						e.channel + 1,
						e.channel === 9 ? " drums" : "",
						" · ",
						a(e.notes.length)
					]
				}, t))]
			}),
			/* @__PURE__ */ m("button", {
				onClick: () => t(r === "all" ? null : Number(r)),
				children: "Import"
			}),
			/* @__PURE__ */ m("button", {
				onClick: n,
				children: "Cancel"
			})
		]
	});
}
function Lc({ name: e, notes: t, take: n, loop: r, position: i, onSeek: a, label: o }) {
	let s = Qs(e, r / 240, i, a), c = i === null ? null : i * 240, l = [...t, ...n ?? []].filter(([e]) => e < r), u = l.length ? Math.min(...l.map((e) => e[2])) : 48, d = l.length ? Math.max(...l.map((e) => e[2])) : 59, f = Math.max(12, d - u + 1), p = d + Math.floor((f - (d - u + 1)) / 2), _ = ([e, t, n, i], a, o) => /* @__PURE__ */ m("rect", {
		x: e,
		y: p - n,
		width: Math.max(t, r / 400),
		height: 1,
		"data-take": a,
		opacity: .45 + i / 127 * .55,
		children: /* @__PURE__ */ h("title", { children: [
			_r(n),
			" · velocity ",
			i
		] })
	}, `${a ? "t" : "n"}${o}`);
	return /* @__PURE__ */ h("div", {
		className: $.noteStripFrame,
		children: [/* @__PURE__ */ h("svg", {
			className: $.noteStrip,
			role: "img",
			"aria-label": o,
			"data-notes": l.length,
			viewBox: `0 0 ${r} ${f}`,
			preserveAspectRatio: "none",
			children: [
				Array.from({ length: r / g - 1 }, (e, t) => /* @__PURE__ */ m("line", {
					x1: (t + 1) * g,
					x2: (t + 1) * g,
					y1: 0,
					y2: f,
					vectorEffect: "non-scaling-stroke"
				}, t)),
				t.filter(([e]) => e < r).map((e, t) => _(e, !1, t)),
				n?.map((e, t) => _(e, !0, t)),
				c !== null && /* @__PURE__ */ m("line", {
					className: $.playhead,
					x1: c,
					x2: c,
					y1: 0,
					y2: f,
					vectorEffect: "non-scaling-stroke"
				})
			]
		}), /* @__PURE__ */ m("div", {
			className: $.stripSeek,
			...s
		})]
	});
}
// ../../../../../rackloose.svg?inline
var Rc = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2064%2064'%3e%3crect%20x='5'%20y='6'%20width='54'%20height='52'%20rx='3'%20fill='%23303337'%20stroke='%23101214'%20stroke-width='2'/%3e%3cpath%20d='M10%2010v44M54%2010v44'%20stroke='%23777'%20stroke-width='3'/%3e%3crect%20x='14'%20y='12'%20width='36'%20height='17'%20fill='%23b9503a'%20stroke='%23111'/%3e%3crect%20x='14'%20y='31'%20width='36'%20height='20'%20fill='%23a0ac9b'%20stroke='%23111'/%3e%3cg%20fill='%23232626'%20stroke='%23dfdfca'%3e%3ccircle%20cx='23'%20cy='21'%20r='5'/%3e%3ccircle%20cx='41'%20cy='21'%20r='5'/%3e%3c/g%3e%3cpath%20d='M23%2021v-4m18%204%203-3'%20stroke='%23fff'%20stroke-width='2'/%3e%3cg%20fill='%231b2221'%20stroke='%23555'%3e%3ccircle%20cx='22'%20cy='39'%20r='3'/%3e%3ccircle%20cx='42'%20cy='44'%20r='3'/%3e%3c/g%3e%3cpath%20d='M22%2039c-6%2020%2027%2020%2020%205'%20fill='none'%20stroke='%23f4bb50'%20stroke-width='3'/%3e%3cpath%20d='M7%208h50'%20stroke='%23a9abad'/%3e%3c/svg%3e", zc = {
	channels: Array(8).fill(-60),
	bus: [-60, -60]
}, Bc = [
	"a",
	"w",
	"s",
	"e",
	"d",
	"f",
	"t",
	"g",
	"y",
	"h",
	"u",
	"j",
	"k",
	"o",
	"l",
	"p",
	";",
	"'"
], Vc = [...new Set(Object.values(S))].sort((e, t) => e - t), Hc = [
	"a",
	"s",
	"d",
	"f",
	"g",
	"h",
	"j",
	"k",
	"l",
	";",
	"'",
	"z",
	"x",
	"c",
	"v",
	"b"
], Uc = /* @__PURE__ */ new Set([
	1,
	3,
	6,
	8,
	10
]), Wc = "input:not([type]), input[type=\"text\"], input[type=\"search\"], textarea, [contenteditable=\"true\"]", Gc = 30, Kc = 40, qc = {
	id: "depth",
	label: "Depth",
	min: -1,
	max: 1,
	step: .01,
	initial: 1
}, Jc = (e) => `${Math.round(e * 100)}%`, Yc = [
	"boom",
	"punch",
	"strike",
	"forge"
], Xc = {
	oscillator: "1V / OCT",
	filter: "CV CONTROL",
	delay: "WARM REPEATS",
	boom: "LONG LOW END",
	punch: "FOUR ON THE FLOOR",
	skitter: "NO SOUND · ALL BOUNCE",
	forge: "HIT IT HARDER",
	rust: "NOTHING CLEAN"
}, Zc = {
	boom: "ANALOG KIT · 11 VOICES",
	punch: "DANCE FLOOR KIT · 5 VOICES",
	strike: "ORIGINAL DIGITAL KIT · 16 VOICES",
	forge: "INDUSTRIAL KIT · 11 VOICES"
};
function Qc(e, t, n) {
	let r = URL.createObjectURL(new Blob([e], { type: t })), i = document.createElement("a");
	i.href = r, i.download = n, i.click(), setTimeout(() => URL.revokeObjectURL(r), 1e3);
}
var $c = (e) => {
	let [t, n] = e.dataset.portKey.split(":");
	return {
		moduleId: t,
		portId: n
	};
}, el = (e, t) => e === t || !!e && !!t && an(e, t), tl = (e, t) => e.error === t.error && e.inside === t.inside && e.cableId === t.cableId && an(e.anchor, t.anchor) && e.point.x === t.point.x && e.point.y === t.point.y && el(e.target, t.target), nl = (e, t) => an(e.from, t) ? e.to : e.from, rl = (e, t) => ({
	...e,
	cables: e.cables.filter((e) => e.id !== t)
});
function il(e) {
	try {
		let t = localStorage.getItem(`${e}:baselinePatch`);
		if (t) {
			let e = fr(t);
			return {
				signature: dr(e),
				patch: e
			};
		}
	} catch {}
	return null;
}
function al(e, { signature: t, patch: n }) {
	localStorage.setItem(`${e}:baseline`, t), localStorage.setItem(`${e}:baselinePatch`, ur(n));
}
function ol({ key: e, patch: t, open: n }) {
	let r = mr(localStorage, e, t);
	return r || (n ? localStorage.setItem(`${e}:open`, n) : localStorage.removeItem(`${e}:open`)), r;
}
var sl = {
	bend: 0,
	mod: 0
}, cl = (e) => U.reduce((t, n) => t + e[n].length, 0);
function ll(e, t) {
	return [e && `${e} ${e === 1 ? "note" : "notes"}`, t && `${t} wheel ${t === 1 ? "move" : "moves"}`].filter(Boolean).join(" and ");
}
function ul({ keysEnabled: e = !0, suspended: t = !1, storageKey: r = "rackloose.patch.v1", linkBrand: o = !0, onEvent: s }) {
	let f = u(s);
	i(() => {
		f.current = s;
	});
	let g = n((e) => {
		try {
			f.current?.(e);
		} catch {}
	}, []), [v, y] = d(() => lr()), b = u(v), T = u(null), E = u(null), D = u(null), O = u(null), k = u(null), te = u(null), A = u(null), [j, M] = d(!1), [P, ne] = d(!1), [re, se] = d(null), [ce, I] = d(!1), [L, le] = d(null), [R, ue] = d(null), [de, z] = l((e, t) => ({
		text: t,
		serial: e.serial + 1
	}), {
		text: "Ready when you are. Enable audio, then play a key or start the pattern.",
		serial: 0
	}), B = de.text, [fe, pe] = d(!0), [V, me] = d(!1), [he, ge] = d(!1), [_e, ve] = d(!1), [ye, be] = d(-1), [xe, Se] = d([]), [Ce, we] = d(48e3), [Te] = d(Vs), [H, Ee] = d(127), [De, Oe] = d(!1), [ke, je] = d(null), [Me, Ne] = d(null), [Pe, Ie] = d(!1), [Le, Re] = d(1), [ze, Be] = d(null), Ve = u(() => {}), [He, Ue] = d(3), [We, Ge] = d(!0), [Ke, qe] = d(null), Je = u(/* @__PURE__ */ new Map()), [Ye, Ze] = d(null), [W, G] = d(null), [K, q] = d(null), [J, Y] = d(null), [Qe, $e] = d(null), [et, nt] = d(4), [rt, it] = d(!1), [at, ot] = d(Nn), [st, ct] = d("performance"), X = u("performance"), [lt, ut] = d(/* @__PURE__ */ new Set()), dt = u(/* @__PURE__ */ new Map()), [ft, pt] = d({}), [mt, ht] = d({}), [gt, _t] = d(null), [vt, yt] = d(null), [bt, xt] = d(!1), [St, Ct] = d(null), wt = u(null), Tt = u(!1), Et = u(() => {}), Dt = u(() => {}), Ot = u(!0), kt = u(/* @__PURE__ */ new Set()), [At, Mt] = d({}), [Pt, Kt] = d(null), [Yt, Xt] = d({}), [cn, ln] = d({
		undo: 0,
		redo: 0
	}), un = u(Nn), fn = u(!1), hn = u(3), gn = u(Nr()), _n = u(null), [vn, yn] = d([]), [bn, xn] = d({}), [Sn, Cn] = d(""), Dn = u(""), [kn, An] = d(null), Pn = u(null), In = u(null), Rn = u(null), Bn = u(0), Vn = u(!1), Un = u(null), Jn = u(0), Qn = a(), tr = a(), nr = a(), rr = a(), ir = `${r}:presets`, ar = vn.find((e) => e.id === bn[Sn]) ?? null, or = ar?.id ?? null, sr = Yt[Sn] ?? null, cr = c(() => dr(v), [v]), mr = c(() => ar ? dr(ar.patch) : sr?.signature ?? null, [ar, sr]), hr = mr !== null && cr !== mr, gr = ar?.patch ?? sr?.patch ?? null;
	i(() => {
		b.current = v, T.current?.update(v);
	}, [v]), i(() => {
		let e = new Ya(b.current, (e) => z(e.message));
		T.current = e, e.onTake = (...e) => Ve.current(...e);
		let n = 0, r = 0;
		function i(t) {
			let a = Te.get(), o = b.current.modules.filter((t) => Ln(t.type) && e.pulsing(t.id)).map((e) => e.id), s = e.wheelLevels(X.current), c = a.wheels, l = (e) => Math.round(e * 500) / 500;
			if (Te.set({
				pulsing: o.length === a.pulsing.size && o.every((e) => a.pulsing.has(e)) ? a.pulsing : new Set(o),
				wheels: s && c && l(s.bend) === c.bend && l(s.mod) === c.mod ? c : s && {
					bend: l(s.bend),
					mod: l(s.mod)
				}
			}), t - r > 40) {
				we(e.sampleRate), be(e.clock), je(e.countingIn), me(e.playing), ge(e.ready), Ie(e.recording);
				let n = e.armedId, i = n ? e.takeNotes(n) : null;
				Be((e) => e?.id === n && e?.notes === i || !e && !i ? e : i && n ? {
					id: n,
					notes: i
				} : null), Se((t) => {
					let n = e.activeNotes;
					return n.length === t.length && n.every((e, n) => e === t[n]) ? t : n;
				}), Mt((t) => {
					let n = Object.fromEntries(b.current.modules.filter((e) => On(e.type)).map((t) => [t.id, {
						playing: e.modulePlaying(t.id),
						clock: e.moduleClock(t.id)
					}]));
					return JSON.stringify(n) === JSON.stringify(t) ? t : n;
				});
				let o = Object.fromEntries(b.current.modules.filter((e) => [
					"compressor",
					"cohere",
					"talon"
				].includes(e.type)).map((t) => [t.id, Math.round(e.reduction(t.id) * 2) / 2])), s = Object.fromEntries(b.current.modules.filter((e) => e.type === "mixer").map((t) => {
					let { channels: n, bus: r } = e.mixerLevels(t.id), i = {
						channels: n.map(Math.round),
						bus: r.map(Math.round)
					}, o = a.mixerLevels[t.id];
					return [t.id, o && JSON.stringify(o) === JSON.stringify(i) ? o : i];
				}));
				Te.set({
					meter: e.meter,
					reductions: JSON.stringify(o) === JSON.stringify(a.reductions) ? a.reductions : o,
					mixerLevels: Object.keys(s).length === Object.keys(a.mixerLevels).length && Object.entries(s).every(([e, t]) => a.mixerLevels[e] === t) ? a.mixerLevels : s
				}), r = t;
			}
			n = requestAnimationFrame(i);
		}
		n = requestAnimationFrame(i);
		let a = () => {
			document.hidden ? e.setSuspended(!0) : e.setSuspended(t);
		};
		document.addEventListener("visibilitychange", a);
		let o = E.current, s = (t) => e.lifted(`pointer-${t.pointerId}`), c = () => e.lifted();
		return o?.addEventListener("pointerup", s, !0), o?.addEventListener("touchend", c, !0), () => {
			cancelAnimationFrame(n), document.removeEventListener("visibilitychange", a), o?.removeEventListener("pointerup", s, !0), o?.removeEventListener("touchend", c, !0), e.dispose(), T.current = null;
		};
	}, [t, Te]), i(() => {
		T.current?.setSuspended(t);
	}, [t]), i(() => {
		pe(!0);
		let e = setTimeout(() => pe(!1), Math.min(9e3, 3500 + de.text.length * 40));
		return () => clearTimeout(e);
	}, [de]), i(() => {
		T.current?.setMute(_e);
	}, [_e, t]), i(() => {
		T.current?.setClick(De);
	}, [De, t]);
	let [vr, yr] = d(0);
	i(() => {
		let e = 0;
		try {
			e = Math.round(Number(localStorage.getItem(`${r}:recordOffset`) ?? 0));
		} catch {}
		yr(Number.isFinite(e) ? Math.max(-100, Math.min(100, e)) : 0);
	}, [r]), i(() => {
		T.current?.setRecordOffset(vr);
	}, [vr]);
	let br = n((e) => {
		yr(e);
		try {
			e ? localStorage.setItem(`${r}:recordOffset`, String(e)) : localStorage.removeItem(`${r}:recordOffset`);
		} catch {}
	}, [r]);
	i(() => {
		T.current?.setMix(at);
	}, [at, t]);
	let xr = n((e) => {
		b.current = e.patch, un.current = e.mix, fn.current = e.mainMuted, hn.current = e.octave, Dn.current = e.session, y(e.patch), ot(e.mix), ve(e.mainMuted), Ue(e.octave), Cn(e.session);
	}, []), Sr = n(() => {
		gn.current = Nr(), ln({
			undo: 0,
			redo: 0
		});
	}, []), Cr = n((e, t = null) => {
		let n = {
			patch: b.current,
			mix: un.current,
			mainMuted: fn.current,
			octave: hn.current,
			session: Dn.current
		}, r = {
			...n,
			...typeof e == "function" ? e(n) : e
		};
		(r.patch !== n.patch || r.mix !== n.mix || r.mainMuted !== n.mainMuted || r.octave !== n.octave || r.session !== n.session) && (gn.current = Pr(gn.current, n, t, Date.now()), ln({
			undo: gn.current.past.length,
			redo: 0
		}), xr(r));
	}, [xr]), Q = n((e, t = null) => Cr((t) => ({ patch: e(t.patch) }), t), [Cr]), wr = n((e, t) => {
		let n = b.current.modules.find((t) => t.id === e), r = Object.keys(t);
		if (!n || r.every((e) => n.params[e] === t[e])) return;
		let i = r.length === 1 ? Z[n.type].params.find((e) => e.id === r[0]) : void 0;
		Q((n) => ({
			...n,
			modules: n.modules.map((n) => n.id === e ? {
				...n,
				params: {
					...n.params,
					...t
				}
			} : n)
		}), i && !i.choices && !i.pattern ? `param:${e}:${i.id}` : null);
	}, [Q]), Er = n((e, t) => Cr((n) => ({ mix: Xn(n.mix, e, t) })), [Cr]), Ar = n((e) => Cr((t) => ({ mix: Zn(t.mix, e) })), [Cr]), jr = n((e) => {
		let t = Dn.current;
		Xt((n) => ({
			...n,
			[t]: {
				signature: dr(e),
				patch: e
			}
		}));
	}, []);
	i(() => {
		let e, t = {
			presets: [],
			error: null
		}, n = null;
		try {
			_n.current && _n.current.key !== r && ol(_n.current), e = pr(localStorage, r), t = Vr(localStorage, `${r}:presets`), n = localStorage.getItem(`${r}:open`);
		} catch {
			e = {
				patch: null,
				error: "Local save unavailable. Export a patch file to keep your work."
			};
		}
		(e.error ?? t.error) && z(e.error ?? t.error);
		let i = e.patch ?? lr(), a = e.patch ? il(r) : null;
		T.current?.panic(), X.current = Vt(i).id, ct(X.current);
		let o = Nt("session");
		yn(t.presets), xn(n && t.presets.some((e) => e.id === n) ? { [o]: n } : {}), An(null), xr({
			patch: i,
			mix: Nn,
			mainMuted: !1,
			octave: hn.current,
			session: o
		}), Sr(), Xt({ [o]: a ?? {
			signature: dr(i),
			patch: i
		} }), ue(null), le(r);
	}, [
		r,
		xr,
		Sr
	]), i(() => {
		if (L !== r) return;
		let e = _n.current = {
			key: r,
			patch: v,
			open: or
		}, t = setTimeout(() => {
			try {
				ue({ error: ol(e) });
			} catch {
				ue({ error: "Local save unavailable. Export a patch file to keep your work." });
			}
		}, 400);
		return () => clearTimeout(t);
	}, [
		v,
		or,
		L,
		r
	]), i(() => {
		if (L === r && sr) try {
			al(r, sr);
		} catch {}
	}, [
		sr,
		L,
		r
	]), i(() => {
		let e = (e) => {
			if (e.key === ir || e.key === null) try {
				yn(Vr(localStorage, ir).presets);
			} catch {}
		};
		return window.addEventListener("storage", e), () => window.removeEventListener("storage", e);
	}, [ir]), i(() => {
		let e = () => {
			if (_n.current) try {
				ol(_n.current);
			} catch {}
		};
		return window.addEventListener("pagehide", e), () => {
			window.removeEventListener("pagehide", e), e();
		};
	}, []), i(() => () => {
		cancelAnimationFrame(Bn.current), cancelAnimationFrame(Jn.current);
	}, []), i(() => (Ot.current = !0, xt(kr()), () => {
		Ot.current = !1, wt.current?.(), wt.current = null;
	}), []);
	let Rr = n((e) => z(e instanceof Error ? e.message : "Audio could not start. Try enabling it again."), []), zr = n((e, t = !1, n) => {
		(!t || kt.current.has(e)) && (kt.current.delete(e), t ? T.current?.cancel(e) : T.current?.release(e, n), dt.current.delete(e) && ut(new Set(dt.current.values())));
	}, []), Br = n((e) => {
		let t = `pointer-${e.pointerId}`;
		kt.current.has(t) && zr(t, !1, e.timeStamp);
	}, [zr]), Jr = n(() => {
		T.current?.releaseManual(), kt.current.clear(), dt.current.clear(), ut(/* @__PURE__ */ new Set());
	}, []), Yr = n((e, n, r, i) => {
		t || T.current?.wheel(X.current, e, n, r, i);
	}, [t]), Xr = n((e, n, r = !1, i) => {
		if (t) return;
		let a = b.current, o = a.modules.find((e) => e.id === X.current) ?? Vt(a), s = Z[o.type];
		if (!En(o.type)) {
			z("Add an instrument or sequencer to play from the keys.");
			return;
		}
		jn(a, o.id) || z(`${s.name} has no audio path to MAIN. Flip the rack to connect it.`);
		let c = o.type === "dictator" ? tn(a, o.id) : null;
		if (c) {
			let t = Z[c.type].drum.voices[n];
			if (!t || dt.current.has(e)) return;
			dt.current.set(e, t.id), ut(new Set(dt.current.values())), T.current?.press(e, oe[t.id], o.id, r, H / 127, i).catch(Rr);
		} else if (s.drum) {
			let t = s.drum.voices[n];
			if (!t || dt.current.has(e)) return;
			dt.current.set(e, t.id), ut(new Set(dt.current.values())), T.current?.hit(o.id, t.id, e, r).catch(Rr);
		} else o.type === "noise" && (dt.current.set(e, "noise"), ut(new Set(dt.current.values()))), T.current?.press(e, o.type === "noise" ? 60 : (He + 1) * 12 + n, o.id, r, H / 127, i).catch(Rr);
	}, [
		Rr,
		t,
		He,
		H
	]), Zr = n((e, t) => pt((n) => n[e] === t ? n : {
		...n,
		[e]: t
	}), []), Qr = n((e, n) => {
		t || T.current?.hit(e, n).catch(Rr);
	}, [Rr, t]), $r = n(() => {
		T.current?.playing ? T.current.pause() : (g({ name: "transport_play" }), T.current?.play().catch(Rr));
	}, [Rr, g]), ei = n(() => {
		T.current?.rejoin().then((e) => {
			let t = e.map((e) => b.current.modules.find((t) => t.id === e)).filter((e) => !!e).map((e) => Gn(b.current, e));
			t.length && z(`${t.length > 1 ? `${t.slice(0, -1).join(", ")} and ${t.at(-1)}` : t[0]} ${t.length > 1 ? "play" : "plays"} again, in time with the rest.`);
		}).catch(Rr);
	}, [Rr]), ti = n((e) => {
		En(e.type) && X.current !== e.id && (Jr(), X.current = e.id, ct(e.id));
	}, [Jr]), ni = n((e) => {
		T.current?.arm(e), Ne(e);
		let t = e && b.current.modules.find((t) => t.id === e);
		t && ti(t);
	}, [ti]), ri = n(() => {
		let e = T.current;
		if (!e || t) return;
		if (e.recording) {
			e.finishTake();
			return;
		}
		let n = b.current.modules.filter((e) => e.type === "dictator"), r = n.find((t) => t.id === e.armedId)?.id ?? n.find((e) => e.id === X.current)?.id ?? (n.length === 1 ? n[0].id : null);
		r ? (ni(r), e.record(e.playing ? 0 : Le).then((e) => {
			e && g({ name: "record_start" }), e && z(`Recording into ${Gn(b.current, b.current.modules.find((e) => e.id === r))}. Play the keys; RECORD or R stops.`);
		}).catch(Rr)) : z(n.length ? "Arm a DICTATOR to record into: its ARM button, beside its clip." : "Add a DICTATOR to record what you play: Add device, then DICTATOR.");
	}, [
		t,
		ni,
		Le,
		Rr,
		g
	]), ii = n(() => {
		let e = T.current?.discardTake() ?? 0;
		z(e ? `Discarded ${e} ${e === 1 ? "note" : "notes"}. Still recording: play again.` : "Nothing recorded yet. Still recording.");
	}, []), ai = n((e) => {
		let t = T.current, n = b.current.modules.find((t) => t.id === e);
		if (!t || !n || t.recording) return;
		let { notes: r, strokes: i } = t.takeHeard(C(n.params.length)), a = Gn(b.current, n), o = cl(i);
		!r.length && !o ? z("Nothing to capture yet. Play the keys or the wheels while the transport runs, then Capture keeps it.") : (Cr((t) => ({ patch: Jt(Wt(t.patch, e, N(Ht(t.patch, e), r, !1, [])), e, i) })), z(`Captured ${ll(r.length, o)} into ${a}. Undo takes ${r.length + o === 1 ? "it" : "them"} back.`));
	}, [Cr]), oi = n((e, n) => {
		let r = T.current, i = b.current.modules.find((t) => t.id === e);
		if (!r || !i || t) return;
		let a = w(i.params.length), o = Math.max(0, r.clock);
		r.seek(o - o % a + n);
	}, [t]);
	i(() => {
		Ve.current = (e, t, n, r, i) => {
			let a = b.current.modules.find((t) => t.id === e);
			if (!a) return;
			let o = a.notes ?? [], s = N(o, t, r, n), c = cl(i), l = Jt(b.current, e, i).modules.find((t) => t.id === e), u = s.length !== o.length || s.some((e, t) => e.some((e, n) => e !== o[t][n])) || U.some((e) => JSON.stringify(Gt(l, e)) !== JSON.stringify(Gt(a, e)));
			u && Cr((t) => ({ patch: Jt(Wt(t.patch, e, s), e, i) })), _n.current &&= {
				..._n.current,
				patch: b.current
			};
			let d = Gn(b.current, a);
			z(t.length || c ? `Recorded ${ll(t.length, c)} into ${d}. Undo takes the take back.` : u ? `Cleared what ${d} passed over. Undo brings it back.` : "Recording stopped. Nothing was played.");
		};
	}, [Cr]), i(() => {
		if (!e || t || re || kn !== null) return;
		let n = (e) => {
			let t = e.key.toLowerCase();
			t !== "r" && !(t === "backspace" && T.current?.recording) || e.repeat || e.defaultPrevented || e.metaKey || e.ctrlKey || e.altKey || (e.target instanceof Element ? e.target : null)?.closest("input, select, textarea, [contenteditable=\"true\"]") || (e.preventDefault(), t === "r" ? ri() : ii());
		};
		return window.addEventListener("keydown", n), () => window.removeEventListener("keydown", n);
	}, [
		e,
		t,
		re,
		kn,
		ri,
		ii
	]), i(() => {
		if (!e || t || re || kn !== null) {
			Jr();
			return;
		}
		function n(e) {
			if (e.defaultPrevented || e.metaKey || e.ctrlKey || e.altKey || e.target instanceof Element && e.target.closest("input, select, textarea, [contenteditable=\"true\"]")) return;
			let t = b.current.modules.find((e) => e.id === X.current), n = t?.type === "dictator" ? tn(b.current, t.id) : null, r = t && (Z[(n ?? t).type].drum?.voices.length ?? +(t.type === "noise")), i = r ? Hc.slice(0, r) : Bc, a = e.key.toLowerCase();
			if (!r && (a === "z" || a === "x")) {
				e.preventDefault(), e.repeat || Cr((e) => ({ octave: Math.min(6, Math.max(1, e.octave + (a === "x" ? 1 : -1))) }), "octave");
				return;
			}
			if ((!r || n) && S[a] !== void 0) {
				e.preventDefault(), Ee(S[a]);
				return;
			}
			let o = i.indexOf(a);
			o >= 0 && (e.preventDefault(), e.repeat || Xr(`key-${e.code}`, o, !1, e.timeStamp));
		}
		let r = (e) => zr(`key-${e.code}`, !1, e.timeStamp);
		return window.addEventListener("keydown", n), window.addEventListener("keyup", r), window.addEventListener("blur", Jr), () => {
			window.removeEventListener("keydown", n), window.removeEventListener("keyup", r), window.removeEventListener("blur", Jr), Jr();
		};
	}, [
		e,
		t,
		Xr,
		zr,
		$r,
		re,
		kn,
		Jr,
		Cr
	]), i(() => {
		Et.current = ({ on: n, note: r, velocity: i, timeStamp: a }) => {
			let o = `midi-${r}`;
			if (zr(o, !1, a), !n || !e || t) return;
			let s = b.current, c = s.modules.find((e) => e.id === X.current) ?? Vt(s);
			if (!En(c.type)) return;
			let l = c.type === "dictator" ? tn(s, c.id) : null, u = Z[(l ?? c).type].drum, d = u ? F(u.voices, r) : c.type === "noise" ? "noise" : null;
			(!u || d) && (d && (dt.current.set(o, d), ut(new Set(dt.current.values()))), u && !l ? T.current?.hit(c.id, d, o, !1, i / 127).catch(Rr) : T.current?.press(o, c.type === "noise" ? 60 : r, c.id, !1, i / 127, a).catch(Rr));
		};
	}, [
		e,
		t,
		zr,
		Rr
	]), i(() => {
		Dt.current = ({ kind: t, value: n, timeStamp: r }) => {
			e && Yr(t, Fe(t, n), n !== Ae[t].rest, r);
		};
	}, [e, Yr]);
	async function si() {
		if (wt.current) wt.current(), wt.current = null, Ct(null), Jr(), z("MIDI input off.");
		else if (!Tt.current) {
			Tt.current = !0;
			try {
				let e = [], t = await Mr((e) => Et.current(e), (t) => {
					e = t, Ct(t);
				}, (e) => Dt.current(e));
				if (!Ot.current) {
					t();
					return;
				}
				wt.current = t, z(e.length ? `MIDI on: ${e.join(", ")} plays the keyboard’s device.` : "MIDI on. Connect a MIDI keyboard to play the keyboard’s device.");
			} catch {
				z("MIDI access was blocked. Allow MIDI devices for this site in the browser, then turn MIDI on again.");
			} finally {
				Tt.current = !1;
			}
		}
	}
	i(() => {
		if (!e || t || re || kn !== null) return;
		let n = (e) => {
			if (e.code !== "Space" || e.metaKey || e.ctrlKey || e.altKey) return;
			let t = e.target instanceof Element ? e.target : null;
			t?.closest(Wc) || (E.current?.contains(t) || !e.defaultPrevented && !t?.closest("button, [role=\"button\"], [role=\"slider\"], input, select, [contenteditable=\"true\"]")) && (e.preventDefault(), e.stopPropagation(), e.type === "keydown" && !e.repeat && $r());
		};
		return window.addEventListener("keydown", n, !0), window.addEventListener("keyup", n, !0), () => {
			window.removeEventListener("keydown", n, !0), window.removeEventListener("keyup", n, !0);
		};
	}, [
		e,
		t,
		re,
		kn,
		$r
	]), i(() => {
		if (!Qe) return;
		let e = D.current, t = e?.querySelector(`[data-module-id="${Qe}"]`);
		if (e && t) {
			let n = t.offsetTop - 6, r = t.offsetTop + t.offsetHeight + 6, i = matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth";
			n < e.scrollTop || r - n > e.clientHeight ? e.scrollTo({
				top: n,
				behavior: i
			}) : r > e.scrollTop + e.clientHeight && e.scrollTo({
				top: r - e.clientHeight,
				behavior: i
			});
		}
		let n = setTimeout(() => $e(null), 1400);
		return () => clearTimeout(n);
	}, [Qe]);
	let ci = n(() => {
		Rn.current = null, cancelAnimationFrame(Bn.current), Bn.current = 0, q(null);
	}, []), li = n(() => {
		let e = Rn.current;
		return !e?.moved || e.cancelled ? !1 : (e.cancelled = !0, cancelAnimationFrame(Bn.current), Bn.current = 0, q(null), !0);
	}, []), ui = n((e) => {
		let t = (e === "undo" ? Fr : Ir)(gn.current, {
			patch: b.current,
			mix: un.current,
			mainMuted: fn.current,
			octave: hn.current,
			session: Dn.current
		});
		if (!t) return;
		gn.current = t.history, ln({
			undo: t.history.past.length,
			redo: t.history.future.length
		}), Rn.current && (Vn.current = !0), ci(), G(null), Kt(null), Ze((e) => e && t.state.patch.cables.some((t) => t.id === e) ? e : null), t.state.patch.modules.some((e) => e.id === X.current) || (Jr(), X.current = Vt(t.state.patch).id, ct(X.current)), xr(t.state);
		let n = e === "undo" ? t.history.past.length : t.history.future.length;
		z(`${e === "undo" ? "Undone" : "Redone"}. ${n} more ${n === 1 ? "step" : "steps"} to ${e}.`);
	}, [
		xr,
		Jr,
		ci
	]);
	i(() => {
		let t = (t) => {
			t.key !== "Escape" || t.defaultPrevented || (li() ? (t.preventDefault(), z("Drag cancelled. Your cables are unchanged.")) : (W || Pt || Ye) && (e || E.current?.contains(t.target)) && (t.preventDefault(), G(null), Kt(null), Ze(null), z(Pt ? "Plug back in its jack." : "Patching cancelled.")));
		}, n = () => li();
		return window.addEventListener("keydown", t, !0), window.addEventListener("blur", n), () => {
			window.removeEventListener("keydown", t, !0), window.removeEventListener("blur", n);
		};
	}, [
		W,
		Pt,
		Ye,
		e,
		li
	]), i(() => {
		if (!Ye) return;
		let t = (t) => {
			if (t.key !== "Delete" && t.key !== "Backspace" || t.defaultPrevented || t.metaKey || t.ctrlKey || t.altKey) return;
			let n = t.target instanceof Element ? t.target : null;
			n?.closest("input, select, textarea, [contenteditable=\"true\"]") || !e && !E.current?.contains(n) || (t.preventDefault(), Q((e) => rl(e, Ye)), Ze(null), G(null), Kt(null), z("Cable removed. Undo puts it back."));
		};
		return window.addEventListener("keydown", t, !0), () => window.removeEventListener("keydown", t, !0);
	}, [
		Ye,
		e,
		Q
	]), i(() => {
		let n = (n) => {
			if (n.defaultPrevented || n.altKey || !(n.metaKey || n.ctrlKey) || re || kn !== null) return;
			let r = n.key.toLowerCase(), i = r === "z" && !n.shiftKey, a = r === "z" && n.shiftKey || r === "y" && n.ctrlKey && !n.shiftKey;
			if (!i && !a) return;
			let o = n.target instanceof Element ? n.target : null;
			(E.current?.contains(o) || e && !t && !o?.closest("input, select, textarea, [contenteditable=\"true\"]")) && (o?.closest("[data-tape-input]") || (n.preventDefault(), ui(i ? "undo" : "redo")));
		};
		return window.addEventListener("keydown", n, !0), () => window.removeEventListener("keydown", n, !0);
	}, [
		e,
		t,
		re,
		kn,
		ui
	]);
	let di = n((e) => {
		try {
			let t = e(Vr(localStorage, ir).presets);
			if (t.length > 200) return "My Presets holds up to 200 presets. Delete or export some first.";
			let n = Hr(localStorage, ir, t);
			return n || yn(t), n;
		} catch {
			return Lr;
		}
	}, [ir]), fi = n((e, t) => {
		let n = di((n) => Ur(n, {
			id: e,
			savedAt: Date.now(),
			patch: t
		}));
		if (n) {
			z(n);
			return;
		}
		let r = Dn.current;
		xn((t) => ({
			...t,
			[r]: e
		})), jr(t), z(`Saved “${t.name}” in this browser.`), g({ name: "patch_save" });
	}, [
		di,
		jr,
		g
	]), pi = n((e) => {
		In.current = e ?? (document.activeElement instanceof HTMLElement ? document.activeElement : null), An(b.current.name);
	}, []), mi = n((e) => {
		let t = b.current;
		!ar || !t.name.trim() || Wr(vn, t.name, ar.id) ? pi(e) : fi(ar.id, t);
	}, [
		ar,
		vn,
		pi,
		fi
	]);
	i(() => {
		let n = (n) => {
			if (n.defaultPrevented || n.altKey || !(n.metaKey || n.ctrlKey) || n.key.toLowerCase() !== "s") return;
			let r = n.target instanceof Element ? n.target : null, i = !!E.current?.contains(r);
			re || kn !== null ? i && n.preventDefault() : (i || e && !t && !r?.closest("input, select, textarea, [contenteditable=\"true\"]")) && (n.preventDefault(), n.shiftKey ? pi() : mi());
		};
		return window.addEventListener("keydown", n, !0), () => window.removeEventListener("keydown", n, !0);
	}, [
		e,
		t,
		re,
		kn,
		mi,
		pi
	]);
	function hi(e, t, n, r = null) {
		Q((r) => {
			let i = Rt(r, e), a = i[t];
			return !a || Object.keys(n).every((e) => a[e] === n[e]) ? r : zt(r, e, i.map((e, r) => r === t ? {
				...e,
				...n
			} : e));
		}, r && `${r}:${e}`);
	}
	function gi(e, t) {
		Q((n) => n.sequencer[e] === t ? n : {
			...n,
			sequencer: {
				...n.sequencer,
				[e]: t
			}
		}, e);
	}
	function _i(e, t) {
		Q((n) => n.cables.some((n) => n.id === e && n.amount !== t) ? {
			...n,
			cables: n.cables.map((n) => n.id === e ? {
				...n,
				amount: t
			} : n)
		} : n, `depth:${e}`);
	}
	function vi(e, t, n = null) {
		ci(), Kt(null), T.current?.panic(), Jr();
		let r = Nt("session");
		n && xn((e) => ({
			...e,
			[r]: n
		})), Cr({
			patch: e,
			mix: Nn,
			mainMuted: !1,
			session: r
		}), jr(e), I(!1), X.current = Vt(e).id, ct(X.current), qe(null), Ze(null), G(null), z(hr ? `${t} Undo brings back your unsaved changes.` : t);
	}
	function yi() {
		gr && hr && (Rn.current && (Vn.current = !0), ci(), G(null), Kt(null), qe(null), Ze((e) => e && gr.cables.some((t) => t.id === e) ? e : null), gr.modules.some((e) => e.id === X.current) || (Jr(), X.current = Vt(gr).id, ct(X.current)), Cr({ patch: gr }), z(`Reverted to “${gr.name}” as ${ar ? "last saved" : "loaded"}. Undo brings back your changes.`));
	}
	function bi() {
		An(null);
		let e = In.current;
		In.current = null, e?.isConnected && e.focus();
	}
	function xi(e) {
		e !== b.current.name && Q((t) => ({
			...t,
			name: e
		})), fi(Wr(vn, e)?.id ?? Nt("preset"), b.current), bi();
	}
	function Si(e) {
		let t = di((t) => t.filter((t) => t.id !== e.id));
		z(t ?? `Deleted “${e.patch.name}” from this browser.${e.id === or ? " The rack still has it; Save adds it back." : ""}`);
	}
	function Ci(e) {
		let t = `${Kr(e.name)}.rackloose.json`;
		Qc(ur(e), "application/json", t), z(`Exported ${t}. Import it in any browser to add it to My Presets.`), g({ name: "patch_export" });
	}
	function wi(e) {
		let t = Gn(v, e), n = C(e.params.length), r = v.modules.find((t) => t.id === en(v, e.id)), i = (e.notes ?? []).filter(([e]) => e < n).map(([e, t, r, i]) => [
			e,
			Math.min(t, n - e),
			r,
			i
		]), a = Xe(Gt(e, "bend"), n), o = Xe(Gt(e, "mod"), n), s = `${Kr(v.name)}-${Kr(t)}.mid`;
		Qc(Tr([{
			name: r ? `${t} - ${Gn(v, r)}` : t,
			notes: i,
			bends: a,
			mods: o,
			channel: tn(v, e.id) ? 9 : 0
		}], v.sequencer.bpm), "audio/midi", s);
		let c = [a.length && "pitch bend", o.length && "mod wheel"].filter(Boolean).join(" and ");
		z(`Exported ${s}: ${i.length} ${i.length === 1 ? "note" : "notes"}${c ? ` with ${c}` : ""} at ${v.sequencer.bpm} BPM.`);
	}
	async function Ti(e, t) {
		try {
			if (t.size > 1e6) throw Error("MIDI files must be smaller than 1 MB.");
			let n = Dr(new Uint8Array(await t.arrayBuffer()));
			if (!n.tracks.length) {
				yt(null), z(`${t.name} has no notes to import.`);
				return;
			}
			n.tracks.length === 1 ? Ei(e, t.name, n.tracks) : yt({
				id: e,
				file: t.name,
				song: n
			});
		} catch (e) {
			Rr(e);
		}
	}
	function Ei(e, t, n) {
		yt(null);
		let r = b.current.modules.find((t) => t.id === e);
		if (!r) return;
		let i = {
			bends: n.find((e) => e.bends?.length)?.bends,
			mods: n.find((e) => e.mods?.length)?.mods
		}, a = Or(n.flatMap((e) => e.notes), Ut(b.current, e), i), o = Gn(b.current, r);
		Q((t) => qt(qt(Wt({
			...t,
			modules: t.modules.map((t) => t.id === e ? {
				...t,
				params: {
					...t.params,
					length: a.length
				}
			} : t)
		}, e, a.notes), e, "bend", a.bends), e, "mod", a.mods));
		let s = a.dropped ? ` ${a.dropped} ${a.dropped === 1 ? "note was" : "notes were"} left out: past 16 bars, repeated, or over the note limit.` : "", c = [a.bends.length && "pitch bend", a.mods.length && "mod wheel"].filter(Boolean).join(" and ");
		z(`Imported ${a.notes.length} ${a.notes.length === 1 ? "note" : "notes"}${c ? ` with ${c}` : ""} from ${t} into ${o}, ${_[a.length]} ${a.length ? "bars" : "bar"} long.${s} Undo puts the clip back.`);
	}
	function Di(e) {
		g({
			name: "module_add",
			module_type: e
		});
		let t = It(e), n = b.current.modules.find((e) => e.id === X.current && jc(e)), r = n && (Qt(n.type) ? ["trig"] : ["pitch", "gate"]).every((e) => !sn(b.current, {
			moduleId: n.id,
			portId: e
		}));
		Q((i) => {
			let a = Bt(i, [
				...i.modules.slice(0, -1),
				t,
				i.modules.at(-1)
			]);
			return e === "dictator" && r ? $t(a, t.id, n.id) : a;
		});
		let i = e !== "dictator" && wn({
			...b.current,
			modules: [...b.current.modules, t]
		}, t);
		ti(t), ne(!1), $e(t.id), z(`${Z[e].name} added${i ? " with a starter pattern. CLEAR empties it; flip" : ". Flip"} the rack to connect it.`);
	}
	function Oi(e) {
		let t = {
			...e,
			id: Nt(),
			params: { ...e.params },
			...e.type === "performance" ? { steps: Rt(b.current, e.id) } : {}
		};
		Q((n) => {
			let r = [...n.modules];
			r.splice(r.findIndex((t) => t.id === e.id) + 1, 0, t);
			let i = t.notes ? Wt(Bt(n, r), t.id, t.notes) : Bt(n, r);
			return U.reduce((e, n) => Gt(t, n).length ? qt(e, t.id, n, Gt(t, n)) : e, i);
		}), ti(t), $e(t.id), z(`${Z[e.type].name} duplicated without its cables.`);
	}
	function ki(e) {
		if (e.key === "Tab") {
			let t = e.currentTarget.querySelectorAll("button");
			t.length === 1 && (e.preventDefault(), t[0].focus());
		}
	}
	function Ai() {
		se(null), (re === "about" ? te : k).current?.focus();
	}
	function ji(e, t, n = null) {
		try {
			let r = Mn(b.current, e, t, n);
			if (G(null), Kt(null), r === b.current) {
				z("Plug back in its jack.");
				return;
			}
			Cr({ patch: r }), z(n ? "Cable moved." : "Connected. Flip to the front to hear your patch.");
		} catch (e) {
			Rr(e);
		}
	}
	function Mi(e) {
		Q((t) => rl(t, e)), Ze(null), Kt(null), z("Cable unplugged. Undo puts it back.");
	}
	function Ni(e) {
		if (Vn.current) {
			Vn.current = !1;
			return;
		}
		let t = sn(b.current, e);
		if (Pt) {
			t?.id === Pt.cableId && !an(e, Pt.anchor) ? (Kt(null), z("Plug back in its jack.")) : ji(Pt.anchor, e, Pt.cableId);
			return;
		}
		if (W && an(W, e)) {
			G(null), z("Patching cancelled.");
			return;
		}
		if (W) {
			ji(W, e);
			return;
		}
		if (t) {
			Kt({
				cableId: t.id,
				anchor: nl(t, e)
			}), Ze(t.id), z("Plug lifted. Choose a free jack, or tap empty rack space to unplug. Tap the jack again or press Escape to put it back.");
			return;
		}
		let n = rn(b.current, e);
		n && (G(e), Ze(null), z(`Choose a free ${n.kind.toUpperCase()} ${n.direction === "out" ? "input" : "output"}. Escape cancels.`));
	}
	function Pi(e) {
		j && !e.target.closest("button, [role=\"button\"], [role=\"slider\"], input, select, label, a") && (Pt ? Mi(Pt.cableId) : W ? (G(null), z("Patching cancelled.")) : Ze(null));
	}
	function Fi(e) {
		let t = D.current;
		if (!t) return null;
		let n = t.getBoundingClientRect(), r = e.clientX >= n.left && e.clientX <= n.right && e.clientY >= n.top && e.clientY <= n.bottom, i = null, a = Gc;
		r && t.querySelectorAll("[data-port-key]").forEach((t) => {
			let r = t.getBoundingClientRect(), o = r.left + r.width / 2, s = r.top + r.height / 2, c = e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom ? -1 : Math.hypot(o - e.clientX, s - e.clientY);
			c >= a || s < n.top || s > n.bottom || (i = $c(t), a = c);
		});
		let o = !!i && an(i, e.anchor), s = i && !o ? dn(b.current, e.anchor, i, e.cableId) : null;
		return {
			anchor: e.anchor,
			cableId: e.cableId,
			target: s || o ? null : i,
			candidate: i,
			error: s,
			inside: r,
			point: {
				x: e.clientX - n.left + t.scrollLeft,
				y: e.clientY - n.top + t.scrollTop
			}
		};
	}
	function Ii() {
		let e = Rn.current, t = D.current;
		if (!e?.moved || e.cancelled || !t) {
			Bn.current = 0;
			return;
		}
		let n = t.getBoundingClientRect(), r = n.top + Kc - e.clientY, i = e.clientY - (n.bottom - Kc);
		r > 0 ? t.scrollTop -= Math.ceil(Math.min(r, Kc) / 3) : i > 0 && (t.scrollTop += Math.ceil(Math.min(i, Kc) / 3));
		let a = Fi(e);
		q((e) => e && a && tl(e, a) ? e : a), Bn.current = requestAnimationFrame(Ii);
	}
	function Li(e, t) {
		if (!e.isPrimary || e.button !== 0) return;
		e.stopPropagation(), Vn.current = !1;
		let n = sn(b.current, t);
		Rn.current = {
			pointerId: e.pointerId,
			anchor: n ? nl(n, t) : t,
			cableId: n?.id ?? null,
			x: e.clientX,
			y: e.clientY,
			clientX: e.clientX,
			clientY: e.clientY,
			moved: !1,
			cancelled: !1
		}, e.currentTarget.setPointerCapture(e.pointerId);
	}
	function Ri(e) {
		let t = Rn.current;
		if (t && t.pointerId === e.pointerId && !t.cancelled) {
			if (t.clientX = e.clientX, t.clientY = e.clientY, !t.moved) {
				if (Math.hypot(e.clientX - t.x, e.clientY - t.y) <= 5) return;
				t.moved = !0, G(null), Kt(null), Ze(t.cableId), z(t.cableId ? "Plug pulled out. Drop it on a free jack, or on empty rack space to unplug. Escape puts it back." : "Drop the plug on a free highlighted jack. Escape cancels.");
			}
			Bn.current ||= requestAnimationFrame(Ii);
		}
	}
	function zi(e, t = !1) {
		let n = Rn.current;
		if (!n || n.pointerId !== e.pointerId) return;
		t || (n.clientX = e.clientX, n.clientY = e.clientY), n.moved ||= Math.hypot(n.clientX - n.x, n.clientY - n.y) > 5;
		let r = Fi(n);
		ci(), (n.moved || n.cancelled) && (Vn.current = !0), n.moved && !n.cancelled && (r?.error ? z(`${r.error}${n.cableId ? " The plug went back in its jack." : ""}`) : r?.target ? (ji(n.anchor, r.target, n.cableId), n.cableId && Ze(n.cableId)) : n.cableId && r?.inside && !r.candidate ? Mi(n.cableId) : z(n.cableId ? "Plug back in its jack." : "Connection cancelled. Your cables are unchanged."));
	}
	function Bi() {
		Rn.current && (Vn.current = !0, ci());
	}
	function Vi(e) {
		let t = Pt?.anchor ?? W;
		t && !Rn.current && e.pointerType === "mouse" && (Un.current = {
			anchor: t,
			cableId: Pt?.cableId ?? null,
			clientX: e.clientX,
			clientY: e.clientY
		}, Jn.current ||= requestAnimationFrame(() => {
			Jn.current = 0;
			let e = Un.current && Fi(Un.current);
			Y((t) => t && e && tl(t, e) ? t : e);
		}));
	}
	async function Hi(e) {
		if (e) {
			try {
				if (e.size > 1e6) throw Error("Patch files must be smaller than 1 MB.");
				let t = await e.text(), n = fr(t);
				g({ name: "patch_import" });
				let r = n.cables.length;
				try {
					let e = JSON.parse(t);
					Array.isArray(e.cables) && (r = e.cables.length);
				} catch {}
				let i = r - n.cables.length, a = i > 0 ? ` ${i} ${i === 1 ? "cable shared a jack" : "cables shared jacks"} with no spare left, so ${i === 1 ? "it was" : "they were"} left out.` : "", o = n.name.trim() ? n.name : "Imported patch", s = Wr(vn, o);
				if (s && dr(s.patch) === dr({
					...n,
					name: s.patch.name
				})) vi(s.patch, `“${s.patch.name}” is already in My Presets, so it opened.${a}`, s.id);
				else {
					let e = {
						id: Nt("preset"),
						savedAt: Date.now(),
						patch: {
							...n,
							name: s ? Gr(vn, o) : o
						}
					}, t = di((t) => Ur(t, e));
					vi(e.patch, t ? `Opened “${e.patch.name}”. ${t}${a}` : `Imported “${e.patch.name}” into My Presets.${s ? ` You already had a different “${s.patch.name}”.` : ""}${a}`, t ? null : e.id);
				}
			} catch (e) {
				Rr(e);
			}
			O.current && (O.current.value = "");
		}
	}
	async function Ui() {
		it(!0), z("Rendering your patch…");
		try {
			Qc(Za(await Xa(v, et, at)), "audio/wav", `${Kr(v.name)}.wav`), z("WAV exported. Your loop includes a two-second effects tail."), g({
				name: "wav_export",
				loops: et
			});
		} catch (e) {
			Rr(e);
		} finally {
			it(!1);
		}
	}
	let Wi = v.cables.find((e) => e.id === Ye), Gi = Pt?.anchor ?? W, Ki = Pt?.cableId ?? null, qi = K ?? (j && Gi && J && an(J.anchor, Gi) && J.cableId === Ki ? J : null);
	function Ji(e) {
		$e(e), D.current?.querySelector(`[data-module-id="${e}"] .${$.moduleNameButton}`)?.focus({ preventScroll: !0 });
	}
	let Yi = K?.anchor ?? Gi, Xi = K ? K.cableId : Ki, Zi = qi?.cableId ?? null;
	function Qi(e, t, n) {
		let r = Z[e.type], i = {
			moduleId: e.id,
			portId: t.id
		}, a = !!Yi && an(Yi, i), o = sn(v, i), s = !!o && (o.id !== Zi || a), c = t.direction === "in" ? "input" : "output", l = e.type === "mixer" && t.direction === "in" ? Yn(v, e.id, t.id) : null, u = l ? `Channel ${t.id.toUpperCase()}: ${l.source}` : t.label;
		return /* @__PURE__ */ m("button", {
			className: $.socket,
			"data-port-key": `${e.id}:${t.id}`,
			"data-kind": t.kind,
			"data-jack": n ?? void 0,
			"data-connected": s,
			"data-compatible": !!Yi && !a && !dn(v, Yi, i, Xi),
			"data-pending": a,
			"data-lifted": !!Pt && o?.id === Pt.cableId && !a,
			"data-target": !!qi?.target && an(qi.target, i),
			"data-selected-end": !!Wi && Wi.id !== Zi && (an(Wi.from, i) || an(Wi.to, i)),
			"aria-label": `${r.name} ${u} ${c}${n && n > 1 ? ` ${n}` : ""}`,
			"aria-description": `${t.kind.toUpperCase()} ${c}${l?.tooltip ? ` · ${l.tooltip}` : ""}`,
			title: `${u}${l?.tooltip ? ` · ${l.tooltip}` : ""}${n ? ` · jack ${n}` : ""} · ${t.kind.toUpperCase()}${o ? " · plugged" : ""}`,
			onClick: () => Ni(i),
			onPointerDown: (e) => Li(e, i),
			onPointerMove: Ri,
			onPointerUp: (e) => zi(e),
			onPointerCancel: Bi,
			onLostPointerCapture: (e) => zi(e, !0),
			children: /* @__PURE__ */ m("span", {})
		}, t.id);
	}
	function $i(e) {
		let t = Z[e.type];
		return /* @__PURE__ */ m("div", {
			className: $.portGroups,
			children: ["in", "out"].filter((e) => t.ports.some((t) => t.direction === e)).map((n) => {
				let r = t.ports.filter((e) => e.direction === n);
				return /* @__PURE__ */ h("div", {
					className: $.portGroup,
					"data-direction": n,
					children: [/* @__PURE__ */ m("span", {
						className: $.portHeading,
						children: n === "in" ? "INPUTS" : "OUTPUTS"
					}), /* @__PURE__ */ m("div", {
						className: $.portRow,
						children: r.filter((e) => !e.copyOf).map((i) => {
							let a = r.filter((e) => e === i || e.copyOf === i.id), o = n === "in" && i.kind === "cv", s = o ? v.cables.find((t) => an(t.to, {
								moduleId: e.id,
								portId: i.id
							})) : void 0, c = e.type === "mixer" && n === "in" ? Yn(v, e.id, i.id) : null;
							return /* @__PURE__ */ h("div", {
								className: $.socketControl,
								"data-source": !!c,
								"data-trim": o,
								"data-jacks": a.length,
								"data-analytics-private": c?.named ? "" : void 0,
								children: [
									a.length > 1 ? /* @__PURE__ */ m("div", {
										className: $.jacks,
										children: a.map((n) => Qi(e, n, on(t.ports, n)))
									}) : Qi(e, i, null),
									o && /* @__PURE__ */ m(eo, {
										trim: !0,
										param: qc,
										value: s?.amount ?? qc.initial,
										format: Jc,
										prefix: `${t.name} ${i.label}`,
										disabled: !s,
										onChange: (e) => {
											s && _i(s.id, e);
										}
									}),
									/* @__PURE__ */ m("span", {
										title: c?.tooltip || void 0,
										children: c?.source ?? i.label
									}),
									(n !== "in" || i.kind !== "audio") && /* @__PURE__ */ h("small", { children: [i.kind.toUpperCase(), s && ` · ${Jc(s.amount)}`] })
								]
							}, i.id);
						})
					})]
				}, n);
			})
		});
	}
	function ea(e) {
		let t = ft[e.id];
		return Z[e.type].drum?.voices.some((e) => e.id === t) ? t : void 0;
	}
	function ta(e, t, n) {
		return t.choices ? /* @__PURE__ */ h("label", {
			className: $.selectControl,
			title: t.hint,
			children: [
				/* @__PURE__ */ m("span", {
					className: $.controlLabel,
					children: t.label
				}),
				/* @__PURE__ */ m("select", {
					"aria-label": `${n} ${t.label}`,
					value: e.params[t.id],
					onChange: (n) => wr(e.id, { [t.id]: Number(n.target.value) }),
					children: t.choices.map((e, t) => /* @__PURE__ */ m("option", {
						value: t,
						children: e
					}, e))
				}),
				/* @__PURE__ */ m(ko, {
					param: t,
					value: e.params[t.id]
				})
			]
		}, t.id) : /* @__PURE__ */ m(eo, {
			param: t,
			prefix: n,
			value: e.params[t.id],
			onChange: (n) => wr(e.id, { [t.id]: n })
		}, t.id);
	}
	function na(e) {
		let t = Z[e.type], n = [...new Set(t.params.filter((e) => e.group && !e.voice).map((e) => e.group))];
		return n.length ? /* @__PURE__ */ m("div", {
			className: $.groupControls,
			"data-type": e.type,
			children: n.map((n) => /* @__PURE__ */ h("fieldset", {
				"data-group": n,
				children: [/* @__PURE__ */ m("legend", { children: n }), /* @__PURE__ */ m("div", {
					className: $.controls,
					children: t.params.filter((e) => e.group === n && !tt.includes(e.id)).map((r) => ta(e, r, `${t.name} ${n}`))
				})]
			}, n))
		}) : null;
	}
	function ra(e) {
		let t = Z[e.type];
		return /* @__PURE__ */ m("div", {
			className: $.controls,
			children: t.params.filter((e) => !e.voice && !e.group && !tt.includes(e.id)).map((n) => ta(e, n, t.name))
		});
	}
	function ia(e) {
		return Wn(v, e);
	}
	function aa(e, t) {
		Q((n) => qn(n, e.id, t)), e.label && !Kn(t) && z("Name removed. Undo brings it back.");
	}
	function oa(e) {
		let n = !!At[e.id]?.playing;
		return /* @__PURE__ */ h("button", {
			className: $.playButton,
			disabled: t,
			"aria-label": `${n ? "Stop" : "Play"} ${ia(e)} sequencer`,
			"data-playing": n,
			onClick: () => {
				T.current?.modulePlaying(e.id) ? T.current.stopModule(e.id) : T.current?.play(e.id).catch(Rr);
			},
			children: [/* @__PURE__ */ m(Lo, { name: n ? "stop" : "play" }), /* @__PURE__ */ m("span", { children: n ? "STOP" : "PLAY" })]
		});
	}
	function sa(e) {
		let n = ia(e), r = e.type === "performance" ? "steps" : "hits";
		return /* @__PURE__ */ m("button", {
			className: $.clearPatternButton,
			disabled: t || !wn(v, e),
			"aria-label": `Clear ${n} pattern`,
			title: `Clear every ${e.type === "performance" ? "step" : "hit"} in the pattern. Undo brings them back.`,
			onClick: () => {
				Q((t) => Tn(t, e.id)), z(`${Gn(v, e)} cleared. Undo brings its ${r} back.`);
			},
			children: /* @__PURE__ */ m("span", { children: "CLEAR" })
		});
	}
	let ca = V && ke === null && !t && v.modules.some((e) => On(e.type) && !At[e.id]?.playing), la = v.modules.find((e) => e.id === st) ?? Vt(v), ua = Z[la.type], da = la.type === "dictator" ? tn(v, la.id) : null, fa = Z[(da ?? la).type], pa = fa.drum?.voices ?? (la.type === "noise" ? [{
		id: "noise",
		label: "Noise"
	}] : null), ma = !pa && Zt(v, la.id).length > 0, ha = (e) => {
		ua.drum && !t && Zr(la.id, e);
	}, ga = pa && pa.length > 6 ? Math.ceil(pa.length / 2) : 6, _a = jn(v, la.id) ? null : `${ua.name} needs an audio path to MAIN. Flip the rack to connect it.`;
	function va(e) {
		let n = ia(e), r = Z.dictator, i = Me === e.id, a = C(e.params.length), o = x[e.params.quantize]?.[1] ?? 240;
		return /* @__PURE__ */ m(Fc, {
			module: e,
			patch: v,
			name: n,
			clock: V ? At[e.id]?.clock ?? -1 : ye,
			take: ze?.id === e.id ? ze.notes : null,
			onSeek: (t) => oi(e.id, t),
			armed: i,
			recording: Pe,
			disabled: t,
			offset: vr,
			onOffset: br,
			onCapture: () => ai(e.id),
			onDiscard: ii,
			transport: oa(e),
			control: (t) => ta(e, r.params.find((e) => e.id === t), n),
			onParam: (t, n) => wr(e.id, { [t]: n }),
			plays: en(v, e.id),
			editing: gt === e.id,
			grid: o,
			onEditing: (t) => {
				_t(t ? e.id : null), t && ti(e);
			},
			onNotes: (t, n) => Q((n) => Wt(n, e.id, t), n ? `${e.id}:${n}` : null),
			onWheels: (t, n) => {
				Q((r) => qt(r, e.id, t, n)), n.length || z(`${Gn(v, e)}'s ${t === "bend" ? "PITCH" : "MOD"} lane cleared. Undo brings it back.`);
			},
			importing: vt?.id === e.id ? {
				file: vt.file,
				tracks: vt.song.tracks
			} : null,
			onExportMidi: () => wi(e),
			onImportMidi: (t) => void Ti(e.id, t),
			onImportTracks: (t) => {
				vt && Ei(e.id, vt.file, t === null ? vt.song.tracks : [vt.song.tracks[t]]);
			},
			onImportCancel: () => yt(null),
			onAudition: (n, r, i) => {
				t || Pe || i && !T.current?.ready || T.current?.audition(n, e.id, r / 127).catch(Rr);
			},
			onAuditionEnd: () => T.current?.endAudition(),
			onArm: () => {
				i ? (Pe && T.current?.finishTake(), ni(null)) : ni(e.id);
			},
			onPlays: (t) => {
				let n = v.modules.find((e) => e.id === t);
				if (n) try {
					Q((n) => $t(n, e.id, t)), z(`${Gn(v, e)} plays ${Gn(v, n)}. Undo puts the cables back as they were.`);
				} catch (e) {
					Rr(e);
				}
			},
			onClear: () => {
				Q((t) => Tn(t, e.id)), z(`${Gn(v, e)} cleared. Undo brings its ${e.notes?.length ? "notes" : "wheel moves"} back.`);
			},
			onQuantize: (t) => {
				t || Q((t) => Wt(t, e.id, ee(e.notes ?? [], o, 1, a))), z(`${t ? `${t} selected ${t === 1 ? "note" : "notes"}` : `${n}'s notes`} moved onto the ${x[e.params.quantize]?.[0] ?? "1/16"} grid. Undo moves them back.`);
			}
		});
	}
	function ya(e = !1) {
		e && Ke && Je.current.get(Ke.moduleId)?.focus(), qe(null);
	}
	function ba(e) {
		let t = Rt(v, e.id), n = At[e.id]?.clock ?? -1, r = n < 0 ? -1 : n % 16, i = ia(e), a = i !== Z[e.type].name, o = Ke?.moduleId === e.id, s = o ? Ke.index : null, c = s === null ? null : t[s];
		return /* @__PURE__ */ h("div", {
			className: $.sequenceBody,
			"data-editing": o,
			children: [
				/* @__PURE__ */ h("div", {
					className: $.sequenceTop,
					children: [
						/* @__PURE__ */ h("div", {
							className: $.lcdStack,
							children: [/* @__PURE__ */ h("div", {
								className: $.lcd,
								children: [
									/* @__PURE__ */ m("small", { children: "SEQUENCER" }),
									/* @__PURE__ */ h("strong", { children: [r >= 0 ? String(r + 1).padStart(2, "0") : "16", /* @__PURE__ */ m("span", { children: "STEPS" })] }),
									/* @__PURE__ */ m("span", {
										className: $.lcdDots,
										"aria-hidden": "true"
									})
								]
							}), /* @__PURE__ */ m("span", {
								className: $.transportCaption,
								children: "16TH NOTE / MONO"
							})]
						}),
						Z.performance.params.map((t) => ta(e, t, i)),
						/* @__PURE__ */ h("div", {
							className: `${$.transport} ${$.stepTransport}`,
							children: [oa(e), /* @__PURE__ */ h("div", {
								className: $.transportKeys,
								children: [sa(e), /* @__PURE__ */ m("button", {
									ref: (t) => {
										t ? Je.current.set(e.id, t) : Je.current.delete(e.id);
									},
									className: $.stepEditButton,
									"aria-pressed": o,
									"aria-label": `Edit ${i} steps`,
									title: "Pick a step to set its note, velocity and gate. Turn EDIT off to switch steps on and off again.",
									onClick: () => qe(o ? null : {
										moduleId: e.id,
										index: null
									}),
									children: "EDIT"
								})]
							})]
						})
					]
				}),
				/* @__PURE__ */ m("div", {
					className: $.steps,
					role: "group",
					"aria-label": `${i} steps`,
					children: t.map((t, n) => /* @__PURE__ */ h("div", {
						className: $.stepCell,
						children: [/* @__PURE__ */ h("button", {
							className: $.step,
							"data-enabled": t.enabled,
							"data-silent": !Hn(e.id, n, at),
							"data-current": r === n,
							"data-editing": s === n,
							"aria-label": `Step ${n + 1}: ${t.enabled ? _r(t.note) : "rest"}`,
							"aria-pressed": o ? s === n : t.enabled,
							onClick: () => {
								o ? qe({
									moduleId: e.id,
									index: n
								}) : hi(e.id, n, { enabled: !t.enabled });
							},
							children: [
								/* @__PURE__ */ m("span", { className: $.stepLed }),
								/* @__PURE__ */ m("span", {
									className: $.stepNumber,
									children: String(n + 1).padStart(2, "0")
								}),
								/* @__PURE__ */ m("strong", { children: t.enabled || o ? _r(t.note) : "—" })
							]
						}), /* @__PURE__ */ m(Ro, {
							mixKey: Fn(e.id, n),
							label: a ? `${i} step ${n + 1}` : `step ${n + 1}`,
							mix: at,
							onToggle: Er
						})]
					}, n))
				}),
				s !== null && c && /* @__PURE__ */ h("div", {
					className: $.stepEditor,
					children: [
						/* @__PURE__ */ h("strong", { children: ["STEP ", String(s + 1).padStart(2, "0")] }),
						/* @__PURE__ */ h("label", { children: [/* @__PURE__ */ m("input", {
							type: "checkbox",
							checked: c.enabled,
							onChange: (t) => hi(e.id, s, { enabled: t.target.checked })
						}), "Note on"] }),
						/* @__PURE__ */ h("label", { children: ["Note", /* @__PURE__ */ m("select", {
							"aria-label": "Step note",
							value: c.note,
							onChange: (t) => hi(e.id, s, { note: Number(t.target.value) }),
							children: Array.from({ length: 73 }, (e, t) => t + 24).map((e) => /* @__PURE__ */ m("option", {
								value: e,
								children: _r(e)
							}, e))
						})] }),
						/* @__PURE__ */ h("label", { children: [
							"Velocity",
							/* @__PURE__ */ m("input", {
								"aria-label": "Step velocity",
								type: "range",
								min: 0,
								max: 1,
								step: .01,
								value: c.velocity,
								onChange: (t) => hi(e.id, s, { velocity: Number(t.target.value) }, `step:${s}:velocity`)
							}),
							/* @__PURE__ */ h("output", { children: [Math.round(c.velocity * 100), "%"] })
						] }),
						/* @__PURE__ */ h("label", { children: [
							"Gate",
							/* @__PURE__ */ m("input", {
								"aria-label": "Step gate",
								type: "range",
								min: .1,
								max: .95,
								step: .01,
								value: c.gate,
								onChange: (t) => hi(e.id, s, { gate: Number(t.target.value) }, `step:${s}:gate`)
							}),
							/* @__PURE__ */ h("output", { children: [Math.round(c.gate * 100), "%"] })
						] }),
						/* @__PURE__ */ m("button", {
							onClick: () => ya(!0),
							"aria-label": "Close step editor",
							children: "×"
						})
					]
				}),
				/* @__PURE__ */ h("div", {
					className: $.sequenceHint,
					children: [o ? "Click a step to edit it. Turn EDIT off to switch steps on and off." : "Click a step to switch it on or off. EDIT sets its note, velocity & gate.", /* @__PURE__ */ m("span", { children: "PATCHABLE PITCH + GATE" })]
				})
			]
		});
	}
	let xa = zn(v, at), Sa = qr(hr, R), Ca = nn(v), wa = /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("img", {
		className: $.brandMark,
		src: Rc,
		width: "48",
		height: "48",
		alt: ""
	}), /* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("strong", { children: "Rackloose" }), /* @__PURE__ */ m("small", { children: "MODULAR SYNTHESIZER" })] })] }), Ta = qi || W || Pt ? Xi ? "Drop the plug on a free highlighted jack, or on empty rack space to unplug. Escape puts it back." : "Choose a free highlighted jack. Escape cancels." : Wi ? "Drag either plug to move it. Delete unplugs this cable." : "One cable per jack. Drag from a jack to patch; drag a plug to move or unplug it.";
	return /* @__PURE__ */ m(Hs.Provider, {
		value: Te,
		children: /* @__PURE__ */ h("section", {
			ref: E,
			className: $.app,
			"aria-label": "Rackloose modular synthesizer",
			onKeyDown: (e) => {
				e.key !== "Escape" || e.defaultPrevented || (re ? Ai() : kn === null ? ce ? (I(!1), Pn.current?.focus()) : P ? (ne(!1), A.current?.focus()) : W || Ye || Pt ? (G(null), Ze(null), Kt(null), z(Pt ? "Plug back in its jack." : "Patching cancelled.")) : Ke && ya(!0) : bi());
			},
			children: [
				/* @__PURE__ */ h("header", {
					className: $.toolbar,
					children: [o ? /* @__PURE__ */ m("a", {
						className: $.brand,
						href: "https://www.rackloose.com/",
						target: "_blank",
						rel: "noopener noreferrer",
						title: "Open Rackloose in a new tab",
						children: wa
					}) : /* @__PURE__ */ m("div", {
						className: $.brand,
						children: wa
					}), /* @__PURE__ */ h("div", {
						className: $.toolbarActions,
						children: [
							/* @__PURE__ */ h("button", {
								className: $.audioButton,
								"data-ready": he,
								disabled: t,
								onClick: () => {
									he ? (T.current?.panic(), z("Audio stopped.")) : T.current?.unlock().then(() => z("Audio enabled. Play A–K, tap a key, or start the pattern.")).catch(Rr);
								},
								children: [/* @__PURE__ */ m("span", { className: $.statusLed }), he ? "Audio on" : "Enable audio"]
							}),
							/* @__PURE__ */ m("button", {
								onClick: () => {
									T.current?.panic(), z("Panic: all sound and pending notes cleared.");
								},
								title: "Immediately silence all sound",
								children: "Panic"
							}),
							/* @__PURE__ */ m("button", {
								ref: k,
								onClick: () => {
									g({ name: "guide_open" }), se("guide");
								},
								"aria-label": "Open user guide",
								title: "User guide",
								children: "?"
							})
						]
					})]
				}),
				/* @__PURE__ */ m("div", {
					className: $.patchBar,
					children: /* @__PURE__ */ h("div", {
						className: $.patchRow,
						children: [
							/* @__PURE__ */ h("div", {
								className: $.patchIdentity,
								children: [/* @__PURE__ */ h("label", {
									className: $.patchName,
									"data-analytics-private": "",
									children: [/* @__PURE__ */ m("span", { children: "PATCH" }), /* @__PURE__ */ h("span", {
										className: $.nameField,
										"data-value": v.name,
										children: [/* @__PURE__ */ m("input", {
											"aria-label": "Patch name",
											"aria-describedby": hr ? rr : void 0,
											maxLength: 100,
											size: 1,
											value: v.name,
											onChange: (e) => {
												let t = e.target.value;
												Q((e) => e.name === t ? e : {
													...e,
													name: t
												}, "name");
											}
										}), hr && /* @__PURE__ */ h("span", {
											id: rr,
											className: $.dirtyMark,
											title: "Unsaved changes",
											children: [/* @__PURE__ */ m("span", {
												"aria-hidden": "true",
												children: "*"
											}), /* @__PURE__ */ m("span", {
												className: $.visuallyHidden,
												children: "Unsaved changes"
											})]
										})]
									})]
								}), /* @__PURE__ */ m("span", {
									className: $.saveStatus,
									"data-save-status": !0,
									"data-state": Sa.state,
									"aria-live": "polite",
									title: Sa.detail || void 0,
									children: Sa.text && /* @__PURE__ */ h(p, { children: [
										/* @__PURE__ */ m("span", {
											className: $.saveLed,
											"aria-hidden": "true"
										}),
										/* @__PURE__ */ m("span", { children: Sa.text }),
										Sa.state === "failed" && /* @__PURE__ */ m("span", {
											className: $.visuallyHidden,
											children: Sa.detail
										})
									] })
								})]
							}),
							/* @__PURE__ */ h("span", {
								className: $.barGroup,
								role: "group",
								"aria-label": "Save and presets",
								children: [/* @__PURE__ */ m("button", {
									"aria-label": "Save to My Presets",
									title: "Save to My Presets in this browser (⌘S / Ctrl+S)",
									onClick: (e) => mi(e.currentTarget),
									children: "Save"
								}), /* @__PURE__ */ m("button", {
									ref: Pn,
									className: $.presetsButton,
									"aria-expanded": ce,
									onClick: () => {
										I(!ce), ne(!1);
									},
									children: "Presets"
								})]
							}),
							/* @__PURE__ */ h("span", {
								className: `${$.barGroup} ${$.exportControls}`,
								role: "group",
								"aria-label": "Export audio",
								children: [/* @__PURE__ */ m("select", {
									"aria-label": "Export loop count",
									title: "Loops to render",
									value: et,
									onChange: (e) => nt(Number(e.target.value)),
									children: [
										1,
										2,
										4,
										8
									].map((e) => /* @__PURE__ */ h("option", {
										value: e,
										children: [
											e,
											" ",
											e === 1 ? "loop" : "loops"
										]
									}, e))
								}), /* @__PURE__ */ m("button", {
									disabled: rt,
									"aria-busy": rt,
									title: "Render every sequencer to a WAV file",
									onClick: () => void Ui(),
									children: rt ? "Rendering…" : "↓ Export WAV"
								})]
							}),
							/* @__PURE__ */ m("input", {
								ref: O,
								type: "file",
								accept: ".json,application/json",
								hidden: !0,
								"aria-label": "Import patch file",
								onChange: (e) => void Hi(e.target.files?.[0])
							}),
							/* @__PURE__ */ h("div", {
								className: $.rackActions,
								children: [/* @__PURE__ */ h("span", {
									className: `${$.barGroup} ${$.historyActions}`,
									role: "group",
									"aria-label": "Edit history",
									children: [
										/* @__PURE__ */ m("button", {
											"aria-label": "Undo",
											title: "Undo (⌘Z / Ctrl+Z)",
											disabled: !cn.undo,
											onClick: () => ui("undo"),
											children: /* @__PURE__ */ m(Lo, { name: "undo" })
										}),
										/* @__PURE__ */ m("button", {
											"aria-label": "Redo",
											title: "Redo (⇧⌘Z / Ctrl+Y)",
											disabled: !cn.redo,
											onClick: () => ui("redo"),
											children: /* @__PURE__ */ m(Lo, { name: "redo" })
										}),
										/* @__PURE__ */ m("button", {
											title: `Revert to the patch as ${ar ? "last saved" : "loaded"}`,
											disabled: !hr || !gr,
											onClick: yi,
											children: "Revert"
										})
									]
								}), /* @__PURE__ */ h("span", {
									className: $.barGroup,
									role: "group",
									"aria-label": "Rack",
									children: [/* @__PURE__ */ m("button", {
										ref: A,
										className: $.addButton,
										"aria-expanded": P,
										onClick: () => {
											ne(!P), I(!1);
										},
										children: "＋ Add device"
									}), /* @__PURE__ */ h("button", {
										className: $.flipButton,
										"aria-label": j ? "Show front" : "Flip rack",
										"aria-pressed": j,
										onClick: () => {
											ci(), M(!j), G(null), Ze(null), Kt(null), z(j ? "Front panel. Turn a knob and make it yours." : "Rear panel. Drag from one jack to another, or tap one then the other.");
										},
										children: ["⇄ ", j ? "Show front" : "Flip rack"]
									})]
								})]
							})
						]
					})
				}),
				ce && /* @__PURE__ */ m(zs, {
					presets: vn,
					openId: or,
					dirty: hr,
					onSaveAs: pi,
					onImport: () => O.current?.click(),
					onExportCurrent: () => Ci(v),
					onExport: Ci,
					onDelete: Si,
					onLoad: (e) => {
						g({
							name: "preset_load",
							source: "user"
						}), vi(e.patch, `Loaded “${e.patch.name}” from My Presets.`, e.id);
					},
					onLoadFactory: (e) => {
						g({
							name: "preset_load",
							source: "factory",
							preset: e
						}), vi(lr(e), `${e} loaded. Your rack is patched and ready to play.`);
					},
					onClose: () => {
						I(!1), Pn.current?.focus();
					}
				}),
				P && /* @__PURE__ */ h("div", {
					className: $.library,
					role: "region",
					"aria-label": "Device library",
					children: [/* @__PURE__ */ h("div", {
						className: $.libraryHeading,
						children: [/* @__PURE__ */ m("strong", { children: "MAKE ROOM FOR SOMETHING NEW." }), /* @__PURE__ */ m("button", {
							"aria-label": "Close device library",
							onClick: () => ne(!1),
							children: "×"
						})]
					}), /* @__PURE__ */ m("div", {
						className: $.libraryGrid,
						children: jt.map((e) => /* @__PURE__ */ h("button", {
							"data-device": Z[e].color,
							disabled: v.modules.length >= 32,
							onClick: () => Di(e),
							children: [
								/* @__PURE__ */ h("span", {
									className: $.miniDevice,
									children: ["◉ ◉ ", /* @__PURE__ */ m("span", { children: "▰" })]
								}),
								/* @__PURE__ */ m("strong", { children: Z[e].name }),
								/* @__PURE__ */ m("small", { children: Z[e].subtitle })
							]
						}, e))
					})]
				}),
				/* @__PURE__ */ h("div", {
					className: $.rackHeading,
					children: [/* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m("span", { className: $.rackLight }), j ? "REAR PANEL / SIGNAL ROUTING" : "YOUR RACK / FRONT PANEL"] }), /* @__PURE__ */ h("span", { children: [
						v.modules.length,
						" DEVICES · ",
						v.cables.length,
						" CONNECTIONS"
					] })]
				}),
				j && /* @__PURE__ */ h("div", {
					className: $.routingBar,
					children: [/* @__PURE__ */ m("span", { children: Ta }), /* @__PURE__ */ h("span", {
						className: $.legend,
						children: [
							/* @__PURE__ */ m("i", { "data-kind": "audio" }),
							" AUDIO ",
							/* @__PURE__ */ m("i", { "data-kind": "cv" }),
							" CV ",
							/* @__PURE__ */ m("i", { "data-kind": "gate" }),
							" GATE"
						]
					})]
				}),
				/* @__PURE__ */ h("div", {
					className: $.rack,
					ref: D,
					"data-holding": !!qi,
					onClick: Pi,
					onPointerMove: Vi,
					onPointerLeave: () => Y(null),
					children: [
						j && /* @__PURE__ */ m(ro, {
							patch: v,
							rackRef: D,
							selected: Ye,
							onSelect: (e) => {
								Ze(e), G(null), Kt(null);
							},
							drag: qi
						}),
						v.modules.map((e, n) => {
							let r = Z[e.type], i = Ft(e.type), a = Yc.includes(e.type), o = (t) => Zr(e.id, t);
							return /* @__PURE__ */ h("article", {
								className: $.module,
								"data-module-id": e.id,
								"data-device": r.color,
								"data-rear": j,
								"data-revealed": Qe === e.id,
								"data-silent": xa[e.id] === !1,
								"data-keyboard-target": la.id === e.id,
								"aria-current": la.id === e.id ? "true" : void 0,
								onPointerDown: () => {
									j || ti(e);
								},
								onFocus: () => {
									j || ti(e);
								},
								"aria-label": `${r.name} ${r.subtitle}`,
								children: [
									/* @__PURE__ */ m("span", { className: `${$.screw} ${$.screwTL}` }),
									/* @__PURE__ */ m("span", { className: `${$.screw} ${$.screwTR}` }),
									/* @__PURE__ */ m("span", { className: `${$.screw} ${$.screwBL}` }),
									/* @__PURE__ */ m("span", { className: `${$.screw} ${$.screwBR}` }),
									/* @__PURE__ */ h("div", {
										className: $.moduleHeader,
										children: [
											/* @__PURE__ */ h("div", {
												className: $.moduleIdentity,
												children: [Ln(e.type) && /* @__PURE__ */ m(Us, {
													select: (t) => t.pulsing.has(e.id),
													children: (e) => /* @__PURE__ */ m("span", {
														className: $.hitLed,
														"data-lit": e,
														title: "Flashes on each sequencer hit",
														"aria-hidden": "true"
													})
												}), /* @__PURE__ */ m(Ps, {
													module: e,
													slot: n + 1,
													onName: (t) => aa(e, t)
												})]
											}),
											!j && i && /* @__PURE__ */ m(Cs, {
												module: e,
												param: i,
												name: r.name,
												onParams: (t) => wr(e.id, t)
											}),
											/* @__PURE__ */ h("div", {
												className: $.moduleTools,
												children: [
													e.type !== "output" && /* @__PURE__ */ m(Ro, {
														mixKey: e.id,
														label: r.name,
														mix: at,
														onToggle: Er,
														clearable: $n(e, at),
														onClear: () => Cr((t) => ({ mix: er(t.mix, e) })),
														onSwap: () => Ar(e.id)
													}),
													/* @__PURE__ */ m("span", {
														className: $.moduleNumber,
														children: String(n + 1).padStart(2, "0")
													}),
													!Lt(v, e.id) && /* @__PURE__ */ h(p, { children: [
														/* @__PURE__ */ m("button", {
															"aria-label": `Move ${r.name} up`,
															disabled: n === 0,
															onClick: () => Q((t) => mn(t, e.id, -1)),
															children: "↑"
														}),
														/* @__PURE__ */ m("button", {
															"aria-label": `Move ${r.name} down`,
															disabled: n === v.modules.length - 2,
															onClick: () => Q((t) => mn(t, e.id, 1)),
															children: "↓"
														}),
														/* @__PURE__ */ m("button", {
															"aria-label": `Duplicate ${r.name}`,
															disabled: v.modules.length >= 32,
															onClick: () => Oi(e),
															children: "⧉"
														}),
														/* @__PURE__ */ m("button", {
															"aria-label": `Remove ${r.name}`,
															onClick: () => {
																ci(), Kt(null), X.current === e.id && ti(Vt({
																	...v,
																	modules: v.modules.filter((t) => t.id !== e.id)
																})), Q((t) => pn(t, e.id)), Ze(null), G(null), z(`${r.name} removed. Undo brings it back with its cables.`);
															},
															children: "×"
														})
													] })
												]
											})
										]
									}),
									j ? $i(e) : e.type === "performance" ? ba(e) : e.type === "dictator" ? va(e) : /* @__PURE__ */ h(p, { children: [
										r.drum && /* @__PURE__ */ h("div", {
											className: $.moduleTransport,
											children: [
												oa(e),
												sa(e),
												/* @__PURE__ */ h("span", { children: [
													"SHARED TEMPO · ",
													v.sequencer.bpm,
													" BPM"
												] })
											]
										}),
										r.drum?.mode !== "euclid" && /* @__PURE__ */ h("div", {
											className: $.moduleBody,
											"data-head": r.drum ? "drum" : void 0,
											children: [
												e.type === "mixer" ? /* @__PURE__ */ m(Us, {
													select: (t) => t.mixerLevels[e.id] ?? zc,
													children: (t) => /* @__PURE__ */ m(Ms, {
														module: e,
														patch: v,
														mix: at,
														levels: t,
														onParams: (t) => wr(e.id, t),
														onToggle: Er,
														onSwap: Ar,
														onGoTo: Ji
													})
												}) : ra(e),
												a && /* @__PURE__ */ m(Xo, {
													module: e,
													selected: ea(e) ?? r.drum.voices[0].id,
													onSelect: o,
													onParams: (t) => wr(e.id, t),
													onAudition: (t) => Qr(e.id, t),
													disabled: t
												}),
												e.type === "skitter" && /* @__PURE__ */ m(Wo, {
													name: r.name,
													brush: mt[e.id] ?? 1,
													onBrush: (t) => ht((n) => ({
														...n,
														[e.id]: t
													}))
												}),
												e.type !== "mixer" && /* @__PURE__ */ m("div", {
													className: $.moduleDecoration,
													children: e.type === "output" ? /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(Us, {
														select: (e) => e.meter,
														children: (e) => /* @__PURE__ */ m("div", {
															className: $.meters,
															"aria-label": "Output level",
															role: "meter",
															"aria-valuemin": 0,
															"aria-valuemax": 1,
															"aria-valuenow": Number(e.toFixed(3)),
															children: [0, 1].map((t) => /* @__PURE__ */ h("div", {
																className: $.meterRow,
																children: [/* @__PURE__ */ m("span", { children: t === 0 ? "L" : "R" }), Array.from({ length: 18 }, (t, n) => /* @__PURE__ */ m("i", {
																	"data-lit": n / 18 < e,
																	"data-hot": n > 14
																}, n))]
															}, t))
														})
													}), /* @__PURE__ */ m("button", {
														"aria-pressed": _e,
														onClick: () => Cr((e) => ({ mainMuted: !e.mainMuted })),
														className: $.muteButton,
														children: _e ? "UNMUTE" : "MUTE"
													})] }) : e.type === "envelope" ? /* @__PURE__ */ m(Fo, { params: e.params }) : ["compressor", "cohere"].includes(e.type) ? /* @__PURE__ */ m(Us, {
														select: (t) => t.reductions[e.id] ?? 0,
														children: (e) => /* @__PURE__ */ m(jo, {
															reduction: e,
															label: `${r.name} ${n + 1} gain reduction`
														})
													}) : e.type === "equalizer" ? /* @__PURE__ */ m(Ao, { params: e.params }) : /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("span", { className: $.deviceLed }), /* @__PURE__ */ h("span", {
														className: $.deviceLabel,
														children: [
															Xc[e.type] ?? "RACKLOOSE",
															/* @__PURE__ */ m("br", {}),
															/* @__PURE__ */ m("small", { children: Zc[e.type] ?? "PATCH. PLAY. REPEAT." })
														]
													})] })
												})
											]
										}),
										e.type === "brit" ? /* @__PURE__ */ m(us, {
											module: e,
											rate: Ce,
											onParams: (t) => wr(e.id, t)
										}) : e.type === "talon" ? /* @__PURE__ */ m(Us, {
											select: (t) => t.reductions[e.id] ?? 0,
											children: (t) => /* @__PURE__ */ m(xs, {
												module: e,
												reduction: t,
												label: `${r.name} ${n + 1} gain reduction`,
												onParams: (t) => wr(e.id, t)
											})
										}) : na(e),
										e.type === "prism" && /* @__PURE__ */ m(Qo, {
											module: e,
											onParams: (t) => wr(e.id, t)
										}),
										r.drum?.mode === "euclid" && /* @__PURE__ */ m(qo, {
											module: e,
											selected: ea(e) ?? r.drum.voices[0].id,
											onSelect: o,
											clock: At[e.id]?.clock ?? -1,
											mix: at,
											onMix: Er,
											disabled: t,
											onParams: (t) => wr(e.id, t),
											onAudition: (t) => Qr(e.id, t),
											controls: ra(e)
										}),
										r.drum?.mode === "steps" && /* @__PURE__ */ m(Go, {
											module: e,
											brush: mt[e.id] ?? 1,
											...a ? {
												selected: ea(e) ?? r.drum.voices[0].id,
												onSelect: o
											} : {},
											mix: at,
											onMix: Er,
											step: (At[e.id]?.clock ?? -1) < 0 ? -1 : At[e.id].clock % 16,
											disabled: t,
											onParams: (t) => wr(e.id, t),
											onAudition: (t) => Qr(e.id, t)
										})
									] })
								]
							}, e.id);
						}),
						/* @__PURE__ */ h("div", {
							className: $.rackBottom,
							children: [/* @__PURE__ */ m("button", {
								ref: te,
								className: $.aboutButton,
								"aria-label": "About Rackloose",
								title: "About Rackloose",
								onClick: () => se("about"),
								children: "RACKLOOSE / BY MICHAEL ZICK © 2026"
							}), /* @__PURE__ */ m("span", { children: "NO RULES. JUST SIGNAL." })]
						})
					]
				}),
				/* @__PURE__ */ m("div", {
					className: $.toastAnchor,
					children: /* @__PURE__ */ m("div", {
						className: $.toast,
						role: "status",
						"data-analytics-private": "",
						"data-shown": fe,
						children: B
					})
				}),
				/* @__PURE__ */ h("div", {
					className: $.keyboardPanel,
					children: [
						/* @__PURE__ */ h("div", {
							className: $.globalControls,
							role: "group",
							"aria-label": "Global controls",
							children: [
								/* @__PURE__ */ h("div", {
									className: $.globalTransport,
									children: [
										/* @__PURE__ */ h("button", {
											className: $.playButton,
											disabled: t,
											onClick: $r,
											"data-playing": V,
											"aria-label": V ? "Pause all sequencers" : "Play all sequencers",
											children: [/* @__PURE__ */ m(Lo, { name: V ? "pause" : "play" }), /* @__PURE__ */ m("span", { children: V ? "PAUSE ALL" : "PLAY ALL" })]
										}),
										/* @__PURE__ */ h("button", {
											className: $.playStoppedButton,
											disabled: !ca,
											onClick: ei,
											"aria-label": "Play stopped sequencers",
											title: "Start every stopped sequencer again, in time with the rest. Mutes, solos and patch edits stay as they are.",
											children: [/* @__PURE__ */ m(Lo, { name: "play" }), /* @__PURE__ */ m("span", { children: "PLAY STOPPED" })]
										}),
										/* @__PURE__ */ h("button", {
											className: $.rewindButton,
											onClick: () => T.current?.rewind(),
											"aria-label": "Rewind to the start",
											title: "Back to bar 1. Playing, it carries on from there.",
											children: [/* @__PURE__ */ m(Lo, { name: "reset" }), /* @__PURE__ */ m("span", { children: "REWIND" })]
										}),
										/* @__PURE__ */ m("button", {
											className: $.clearAllButton,
											disabled: !at.muted.size && !at.soloed.size && !_e,
											onClick: () => {
												Cr({
													mix: Nn,
													mainMuted: !1
												}), z("All mutes and solos cleared.");
											},
											"aria-label": "Clear all mutes and solos",
											children: /* @__PURE__ */ m("span", { children: "CLR ALL" })
										}),
										/* @__PURE__ */ h("button", {
											className: $.recordButton,
											disabled: t,
											"data-recording": Pe,
											"aria-pressed": Pe,
											"aria-label": Pe ? "Stop recording" : "Record",
											title: "Record into the armed DICTATOR (R)",
											onClick: ri,
											children: [/* @__PURE__ */ m("span", { className: $.recordLed }), /* @__PURE__ */ m("span", { children: Pe ? "STOP REC" : "RECORD" })]
										}),
										/* @__PURE__ */ h("label", {
											className: $.countInField,
											title: "Bars of clicks before recording starts from a stop",
											children: ["PRE", /* @__PURE__ */ m("select", {
												"aria-label": "Count-in",
												value: Le,
												onChange: (e) => Re(Number(e.target.value)),
												children: [
													0,
													1,
													2
												].map((e) => /* @__PURE__ */ m("option", {
													value: e,
													children: e ? `${e} bar${e > 1 ? "s" : ""}` : "Off"
												}, e))
											})]
										}),
										/* @__PURE__ */ h("button", {
											className: $.clickButton,
											"aria-pressed": De,
											title: "Click on every beat while the transport runs. It never reaches MAIN or an export.",
											onClick: () => Oe(!De),
											children: [/* @__PURE__ */ m("span", { className: $.clickLed }), /* @__PURE__ */ m("span", { children: "CLICK" })]
										})
									]
								}),
								/* @__PURE__ */ m(Ls, {
									bpm: v.sequencer.bpm,
									onChange: (e) => gi("bpm", e)
								}),
								/* @__PURE__ */ h("label", {
									className: $.swingField,
									children: [
										"SWING",
										/* @__PURE__ */ m("input", {
											className: $.fader,
											type: "range",
											min: 0,
											max: .6,
											step: .01,
											value: v.sequencer.swing,
											"aria-label": "Swing",
											onChange: (e) => gi("swing", Number(e.target.value))
										}),
										/* @__PURE__ */ h("span", { children: [Math.round(v.sequencer.swing * 100), "%"] })
									]
								})
							]
						}),
						/* @__PURE__ */ h("div", {
							className: $.keyboardTop,
							children: [
								/* @__PURE__ */ h("strong", {
									className: $.keyboardTarget,
									"data-analytics-private": la.label ? "" : void 0,
									children: ["KEYBOARD → ", Gn(v, la)]
								}),
								_a ? /* @__PURE__ */ m("span", {
									className: $.routingHint,
									title: _a,
									children: _a
								}) : e && /* @__PURE__ */ m("span", {
									className: $.keyHint,
									children: pa ? `${pa.length > 11 ? "Home row + Z X C V B" : "Home row · pads"}${da ? " · 1–0 velocity" : ""}` : "A–' notes · Z X octave · 1–0 velocity"
								}),
								/* @__PURE__ */ h("div", {
									className: $.positionField,
									title: `Where the transport is, as bar.beat.16th, counting through the longest loop in the rack: ${Ca / 16} ${Ca > 16 ? "bars" : "bar"}`,
									children: [/* @__PURE__ */ m("span", {
										"aria-hidden": "true",
										children: "POSITION"
									}), /* @__PURE__ */ m("span", {
										className: $.globalPosition,
										"aria-label": "Global position",
										"data-count-in": ke !== null,
										children: ke === null ? ie(Math.max(0, ye), Ca) : ae(ke)
									})]
								}),
								/* @__PURE__ */ h("div", {
									className: $.keyControls,
									children: [
										(!pa || da) && /* @__PURE__ */ h("div", {
											className: $.octaveControls,
											children: [
												!pa && /* @__PURE__ */ h(p, { children: [
													/* @__PURE__ */ m("button", {
														"aria-label": "Lower keyboard octave",
														disabled: He === 1,
														onClick: () => Cr((e) => ({ octave: Math.max(1, e.octave - 1) }), "octave"),
														children: "−"
													}),
													/* @__PURE__ */ h("span", { children: ["OCT ", He] }),
													/* @__PURE__ */ m("button", {
														"aria-label": "Raise keyboard octave",
														disabled: He === 6,
														onClick: () => Cr((e) => ({ octave: Math.min(6, e.octave + 1) }), "octave"),
														children: "＋"
													})
												] }),
												/* @__PURE__ */ m("button", {
													"aria-label": "Lower keyboard velocity",
													disabled: H === Vc[0],
													onClick: () => Ee(Vc[Math.max(0, Vc.indexOf(H) - 1)]),
													children: "−"
												}),
												/* @__PURE__ */ h("span", {
													title: "Velocity of the notes you play: 1–0 on the keyboard",
													children: ["VEL ", H]
												}),
												/* @__PURE__ */ m("button", {
													"aria-label": "Raise keyboard velocity",
													disabled: H === Vc.at(-1),
													onClick: () => Ee(Vc[Math.min(Vc.length - 1, Vc.indexOf(H) + 1)]),
													children: "＋"
												})
											]
										}),
										bt && /* @__PURE__ */ h("button", {
											className: $.midiToggle,
											"aria-pressed": St !== null,
											"aria-label": "MIDI input",
											title: St === null ? "Play the keyboard’s device from a MIDI keyboard" : St.length ? `MIDI in: ${St.join(", ")}` : "MIDI on: no MIDI keyboard connected",
											onClick: () => void si(),
											children: [/* @__PURE__ */ m("span", {
												className: $.midiLed,
												"data-connected": !!St?.length
											}), "MIDI"]
										}),
										/* @__PURE__ */ m("button", {
											className: $.keysToggle,
											"aria-expanded": We,
											"aria-controls": Qn,
											onClick: () => Ge(!We),
											children: We ? "Hide keys" : "Show keys"
										})
									]
								})
							]
						}),
						/* @__PURE__ */ m("div", {
							id: Qn,
							hidden: !We,
							children: pa ? /* @__PURE__ */ m("div", {
								className: $.performancePads,
								"data-voices": pa.length,
								"data-rows": pa.length > 6 ? 2 : 1,
								style: { "--pad-columns": ga },
								"aria-label": `${fa.name} performance pads`,
								children: pa.map((n, r) => /* @__PURE__ */ h("button", {
									"data-playing": lt.has(n.id),
									"aria-label": `Keyboard ${fa.name} ${n.label}`,
									disabled: t,
									onPointerDown: (e) => {
										e.button === 0 && (e.preventDefault(), e.currentTarget.setPointerCapture(e.pointerId), kt.current.add(`pointer-${e.pointerId}`), Xr(`pointer-${e.pointerId}`, r, e.pointerType !== "mouse", e.timeStamp), ha(n.id));
									},
									onPointerUp: (e) => zr(`pointer-${e.pointerId}`, !1, e.timeStamp),
									onPointerCancel: (e) => zr(`pointer-${e.pointerId}`, !0),
									onLostPointerCapture: Br,
									onKeyDown: (e) => {
										e.key !== "Enter" && e.key !== " " || e.repeat || (e.preventDefault(), e.stopPropagation(), Xr(`pad-${n.id}`, r), ha(n.id));
									},
									onKeyUp: (e) => {
										(e.key === "Enter" || e.key === " ") && (e.preventDefault(), zr(`pad-${n.id}`));
									},
									onBlur: () => zr(`pad-${n.id}`),
									children: [/* @__PURE__ */ m("span", { children: n.label }), e && /* @__PURE__ */ m("small", { children: Hc[r].toUpperCase() })]
								}, n.id))
							}) : /* @__PURE__ */ h("div", {
								className: $.playSurface,
								children: [ma && /* @__PURE__ */ m(Us, {
									select: (e) => e.wheels,
									children: (e) => /* @__PURE__ */ m(Js, {
										levels: e ?? sl,
										disabled: t,
										onMove: Yr
									})
								}), /* @__PURE__ */ m("div", {
									className: $.piano,
									"aria-label": "Piano keyboard",
									children: Bc.map((e, n) => {
										let r = (He + 1) * 12 + n, i = Uc.has(n % 12);
										return /* @__PURE__ */ h("button", {
											className: i ? $.blackKey : $.whiteKey,
											"data-note": r,
											"data-playing": xe.includes(r),
											"aria-label": `Play ${_r(r)}`,
											disabled: t,
											onPointerDown: (e) => {
												e.button === 0 && (e.preventDefault(), e.currentTarget.setPointerCapture(e.pointerId), kt.current.add(`pointer-${e.pointerId}`), Xr(`pointer-${e.pointerId}`, n, e.pointerType !== "mouse", e.timeStamp));
											},
											onPointerUp: (e) => zr(`pointer-${e.pointerId}`, !1, e.timeStamp),
											onPointerCancel: (e) => zr(`pointer-${e.pointerId}`, !0),
											onLostPointerCapture: Br,
											onKeyDown: (e) => {
												e.key !== "Enter" && e.key !== " " || e.repeat || (e.preventDefault(), e.stopPropagation(), Xr(`piano-${r}`, n));
											},
											onKeyUp: (e) => {
												(e.key === "Enter" || e.key === " ") && (e.preventDefault(), zr(`piano-${r}`));
											},
											onBlur: () => zr(`piano-${r}`),
											children: [/* @__PURE__ */ m("span", { children: Bc[n].toUpperCase() }), !i && /* @__PURE__ */ m("small", { children: _r(r) })]
										}, n);
									})
								})]
							})
						})
					]
				}),
				re === "guide" && /* @__PURE__ */ m("div", {
					className: $.helpBackdrop,
					children: /* @__PURE__ */ h("div", {
						className: $.help,
						role: "dialog",
						"aria-modal": "true",
						"aria-labelledby": tr,
						"data-analytics-private": "",
						onKeyDown: ki,
						children: [
							/* @__PURE__ */ h("div", {
								className: $.helpHeading,
								children: [
									/* @__PURE__ */ m("img", {
										src: "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2064%2064'%3e%3crect%20x='5'%20y='6'%20width='54'%20height='52'%20rx='3'%20fill='%23303337'%20stroke='%23101214'%20stroke-width='2'/%3e%3cpath%20d='M10%2010v44M54%2010v44'%20stroke='%23777'%20stroke-width='3'/%3e%3crect%20x='14'%20y='12'%20width='36'%20height='17'%20fill='%23b9503a'%20stroke='%23111'/%3e%3crect%20x='14'%20y='31'%20width='36'%20height='20'%20fill='%23a0ac9b'%20stroke='%23111'/%3e%3cg%20fill='%23232626'%20stroke='%23dfdfca'%3e%3ccircle%20cx='23'%20cy='21'%20r='5'/%3e%3ccircle%20cx='41'%20cy='21'%20r='5'/%3e%3c/g%3e%3cpath%20d='M23%2021v-4m18%204%203-3'%20stroke='%23fff'%20stroke-width='2'/%3e%3cg%20fill='%231b2221'%20stroke='%23555'%3e%3ccircle%20cx='22'%20cy='39'%20r='3'/%3e%3ccircle%20cx='42'%20cy='44'%20r='3'/%3e%3c/g%3e%3cpath%20d='M22%2039c-6%2020%2027%2020%2020%205'%20fill='none'%20stroke='%23f4bb50'%20stroke-width='3'/%3e%3cpath%20d='M7%208h50'%20stroke='%23a9abad'/%3e%3c/svg%3e",
										width: "34",
										height: "34",
										alt: ""
									}),
									/* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("small", { children: "RACKLOOSE · MODULAR SYNTHESIZER" }), /* @__PURE__ */ m("h2", {
										id: tr,
										children: "User Guide"
									})] }),
									/* @__PURE__ */ m("button", {
										autoFocus: !0,
										onClick: Ai,
										"aria-label": "Close user guide",
										children: "×"
									})
								]
							}),
							/* @__PURE__ */ m("h3", { children: "Transport" }),
							/* @__PURE__ */ h("p", { children: [
								"Play All starts every sequencer and turns into Pause All while anything plays. Play Stopped starts every sequencer you stopped while the transport plays again, in time, and leaves mutes, solos and the patch alone. Rewind goes back to bar 1: playing, it plays on from there. Type a tempo or drag the small fader under it; the change is heard right away. Space always plays and pauses, whichever control has focus, except while typing in a text field. Each STEP–16, DICTATOR and drum machine also has its own Play/Stop, locked to the shared tempo, swing and position. POSITION, in the keyboard bar, shows it as bar.beat.16th of the longest loop: 11.2.1 is bar 11, beat 2, its first 16th. CLICK sounds each beat, higher on the first, straight to your speakers: it is never in an export. RECORD, or ",
								/* @__PURE__ */ m("strong", { children: "R" }),
								", records into a DICTATOR (see Recording)."
							] }),
							/* @__PURE__ */ m("h3", { children: "Playing" }),
							/* @__PURE__ */ h("p", { children: [
								"Click a device to aim the keyboard at it. Click its printed name to write your own on a strip of masking tape, like Lead synth or Big drums. Click the tape to change it, then its × to peel it off. SUM’s channels and their signal paths use the names you write: a channel goes by the name nearest it, on an effect, its instrument, or the sequencer playing it. Click a channel’s name to go to that device. MONARCH, ORACLE, AURORA, PRISM, SOLID and DICTATOR play on ",
								/* @__PURE__ */ m("strong", { children: "A W S E D F T G Y H U J K O L P ; '" }),
								", eighteen keys from C to the F above. ",
								/* @__PURE__ */ m("strong", { children: "Z" }),
								" and ",
								/* @__PURE__ */ m("strong", { children: "X" }),
								", or OCT, shift the octave, and the number keys set how hard you play, from ",
								/* @__PURE__ */ m("strong", { children: "1" }),
								" (softest) to ",
								/* @__PURE__ */ m("strong", { children: "0" }),
								" (full), shown as VEL. MONARCH plays one note at a time; ORACLE plays up to five, AURORA eight and PRISM sixteen. Their Chord setting turns every note, from the keys or STEP–16, into a chord. The chrome Engine switch in a device’s header slides between Digital, its black tab on the left, and Analog, its red tab on the right. On MONARCH, ORACLE, AURORA and SIEVE, Analog is a Moog-style ladder filter that self-oscillates near full Resonance; on PRISM it adds a ladder to every voice, set in its Filter section. Drum machines get pads on the home row, ",
								/* @__PURE__ */ m("strong", { children: "A S D F G H J K L ; '" }),
								", plus ",
								/* @__PURE__ */ m("strong", { children: "Z X C V B" }),
								" for STRIKE’s remaining five voices. STATIC holds noise on A. STEP–16 plays whatever its Pitch and Gate cables reach, and effects keep the last instrument. The light beside each instrument and drum machine flashes every time a sequencer plays it. Hide keys keeps every global control."
							] }),
							/* @__PURE__ */ m("p", { children: "Left of the keys sit a pitch wheel and a mod wheel, for MONARCH, ORACLE, AURORA and PRISM, or a DICTATOR or STEP–16 that plays one. Drag them up and down, or focus one and use the arrows; a MIDI keyboard’s wheels move them too. The pitch wheel springs back to the centre when you let go, and each synth’s Bend sets how far it reaches, up to 12 semitones. The mod wheel stays where you leave it, and a double-click takes it back down. Each does what it did on the synth it is modelled on. On MONARCH it sets how much of the Mod mix, Osc 3 or noise, reaches the oscillators or the filter; switch Osc 3 to LFO for a vibrato. On ORACLE it brings in the LFO and noise beyond the LFO’s own Amount. On AURORA it brings in LFO vibrato, as deep as LFO mod, and VCF bend lets the pitch wheel sweep the filter too. On PRISM it deepens vibrato, tremolo or brightness, as Mod to picks, as far as Mod range." }),
							/* @__PURE__ */ m("h3", { children: "Recording" }),
							/* @__PURE__ */ h("p", { children: [
								"DICTATOR records what you play on the keys as MIDI notes, in a looping clip of 1 to 16 bars, and plays them back on whatever its Pitch and Gate cables reach: pick an instrument under PLAYS to patch it in one step. ARM a DICTATOR, which takes the keyboard, then press RECORD or ",
								/* @__PURE__ */ m("strong", { children: "R" }),
								". With more than one DICTATOR, only the armed one records, and arming another disarms it; with none armed, RECORD uses the DICTATOR the keys play, or asks you to arm one. From a stop, PRE counts in 0, 1 or 2 bars with the click before every sequencer starts; while playing, recording starts at once. Each key is its own note, so chords record as chords, at the velocity VEL shows, placed where you heard them. Every pass round the loop adds notes (Overdub), or Record set to Replace clears what the playhead passes. In the QUANTIZE row, which picks a grid from quarter notes to 1/32s, the Quantize button moves note starts onto it now (the notes selected in the piano roll, or else every note), and the AUTO lamp moves each note onto it as you record. RECORD, R, Pause or Panic stops, and the take is one step that Undo takes back whole; Backspace while recording throws the take away so far and keeps recording. Capture keeps what you just played with the transport running, without RECORD. Moving a wheel while recording writes its moves into the clip’s PITCH and MOD lanes, replacing them only where you moved it, and Capture keeps wheel moves too. If what you record lands late, as with Bluetooth headphones, REC TIMING records it up to 100 ms earlier, in this browser; it never changes what you hear. Lag plays the clip up to 50 ms late or early against the beat, which you hear against the click or other parts. DICTATOR’s mute and solo work like STEP–16’s, and Export WAV renders its whole clip. Rest the pointer on any control to see what it does."
							] }),
							/* @__PURE__ */ m("p", { children: "EDIT opens the clip in a piano roll. Draw clicks a note onto the SNAP grid, or drags it longer; Select drags across notes to select them. Drag a note to move it, its right edge to resize it, or the velocity lane under it to set how hard it plays; double-click deletes it. VEL, PITCH and MOD, beside the lane, pick what it shows: drag in PITCH or MOD to draw the wheel’s moves, a step per SNAP cell or smoothly with SNAP off, Alt-drag to erase them, and Clear PITCH or Clear MOD empties the lane. The wheel holds each value until the next, round the loop, and a wheel you hold takes over from the lane until you let go. With the roll focused, the arrows move the selection, or a cursor, by a SNAP step or a semitone, Shift+arrows resize it or move it an octave, N adds a note at the cursor, [ and ] step through the notes, Delete removes them, ⌘A or Ctrl+A selects all, ⌘D or Ctrl+D duplicates, and Escape clears the selection, then closes the roll. On a touch screen, a finger draws on the grid and scrolls on the keys or the bar numbers. Each edit is one step that Undo takes back." }),
							/* @__PURE__ */ m("p", { children: "Click or drag DICTATOR’s strip, or the piano roll’s bar numbers, to move the playhead there, or tap them on a touch screen; with one focused, the arrows move it a beat and Shift+arrows a bar. The playhead is the shared position, so every sequencer moves with it, whether stopped, playing or recording." }),
							/* @__PURE__ */ m("p", { children: "Pick a drum machine under PLAYS and DICTATOR plays it by General MIDI note, the kick on 36, snare 38, closed hat 42 and so on, as hard as each note was played; the keyboard then shows that kit’s pads, which record as those notes. Export .mid saves the clip as a MIDI file for a DAW, and Import .mid replaces it with a file’s notes, one track or all of them. MIDI, beside the keys, plays the keyboard’s device from a MIDI keyboard in Chrome, Edge or Firefox once the browser has your permission, and records like the keys, at the velocity you play." }),
							/* @__PURE__ */ m("h3", { children: "Knobs and steps" }),
							/* @__PURE__ */ m("p", { children: "Drag a knob up or down, or use the arrow keys; double-click restores its default. Click a STEP–16 step to switch it on or off, as on a drum machine’s pads. To set a step’s note, velocity and gate, turn on EDIT, beside CLEAR under Play, which dashes every step’s border, and click the step; its Note on box switches it too. Turn EDIT off, or press Escape, to switch steps with a click again. A step that is off keeps its note for when you switch it back on, and CLEAR, under Play, turns every step into a rest the same way. A STEP–16’s Lag moves all its notes up to 50 ms ahead of the beat (turn it left) or behind it (right); centred is On beat. Add device adds more STEP–16s: each has its own 16 steps, Play/Stop and step mutes, and plays whatever its own Pitch and Gate cables reach, so separate parts can drive separate instruments. Typing in a field never plays notes." }),
							/* @__PURE__ */ m("h3", { children: "Patching cables" }),
							/* @__PURE__ */ m("p", { children: "Flip the rack to patch. Each jack holds one cable. Drag from an empty jack to a free one; jacks that can take it light up. Drag a plugged jack to pull its plug out: drop it on a free jack to move it, or on empty rack space to unplug it. You can also tap a plugged jack to lift its plug, then tap a free jack. Escape or a bad drop puts the plug back, and Delete unplugs a selected cable. Every output has a spare jack, and STEP–16 has three Pitch and three Gate jacks, so one signal can feed several places. Amber is audio, blue is CV and coral is gate; types must match. The trim beside a CV input sets its depth. SUM mixes eight channels and names each one after the instrument feeding it, through any effects; hover the name to see the chain." }),
							/* @__PURE__ */ m("h3", { children: "Mixing on SUM" }),
							/* @__PURE__ */ m("p", { children: "SUM is laid out like a console. Each channel strip has Pan, M and S, a fader and a level meter: green, amber from −9 dB and red from −3 dB. Drag a fader or pan knob, or use the arrow keys; double-click returns it to its default. The MIX BUS fader on the right sets the level of the whole mix, with its own left and right meters." }),
							/* @__PURE__ */ m("h3", { children: "Drums" }),
							/* @__PURE__ */ m("p", { children: "AURORA is an eight-voice Jupiter-8-inspired polysynth: blend two oscillators, shape them with high-pass and 12/24 dB low-pass filters, and animate pulse width with the LFO. PRISM is a focused DX7-inspired FM synth: choose one of six algorithms, then select an operator to edit its ratio, level and envelope. Brightness controls modulation depth; Velocity makes quieter sequenced notes softer in tone. Both use their own envelopes and work with STEP–16 Pitch and Gate, or directly from the keyboard." }),
							/* @__PURE__ */ m("p", { children: "STRIKE has sixteen vintage digital drum lanes, original generated one-shots inspired by LinnDrum. BOOM has eleven voices: kick, snare, rim, clap, closed and open hat, low and high tom, crash, ride and bell. A closed hat cuts off a ringing open hat. On BOOM, PUNCH, STRIKE and FORGE, click a voice’s name, tap its performance pad or pick it under Edit voice to hear it and shape it in the voice editor, with its own knobs, such as Tune, Decay and Tone, its Pan and its Lag. Lag moves just that voice up to 50 ms ahead of the beat (turn it left) or behind it (right), like hats pushed ahead or a snare laid back. ORBIT shows the same knobs for the lane you pick. Every drum machine’s Engine toggle picks Digital or Analog, which builds each voice from modeled analog circuits (or, on STRIKE and FORGE, plays its one-shots through a ladder tone filter) at the same level. Every device starts Analog, presets and older patches included. The knob marked LEVEL on each drum lane, in ORBIT’s Level column, sets that voice’s level: centred leaves it as it was, down silences it and full adds 6 dB. Hover it to read the change; double-click resets it. Click pads to program a voice’s steps. CLEAR, beside a drum machine’s Play, empties the pattern it came with, rolls and custom rings included, so you can start from silence; ORBIT’s rings keep their Steps and Shift, so Generate refills them. ORBIT voices each have Steps, Hits and Shift; tap its step pads for a custom rhythm, and Generate turns it back into a Euclidean one, spreading the hits you tapped evenly if the lane had no Hits. A drum machine’s Chain in passes another instrument through. SKITTER is a trap step sequencer that makes no sound: patch Trig out into a drum machine’s Trig in and its lanes play that kit’s kick, snare, clap, hats and perc, or patch Synth gate into MONARCH, CONTOUR or a polysynth. Pick a note under Note, then tap a step to play it as a 1/16, a pair of 1/32s, or a roll of 1/32 triplets, 1/64s or 1/64 triplets. FORGE is an industrial rock kit with its own Drive and gated Room, and RUST distorts anything patched into it, from fuzz to crushed bits." }),
							/* @__PURE__ */ m("h3", { children: "Dynamics and EQ" }),
							/* @__PURE__ */ m("p", { children: "VALVE is a tube limiter: Input drives the tube, Threshold sets where it starts to hold the level back, and Time constant picks how fast it lets go, from 1 (quick) to 6 (slow). The needle shows the gain reduction. CONSOLE is a channel EQ: high- and low-pass filters, LF and HF that switch between shelf and bell, and two sweepable mids with Q. The screen draws the curve you hear, and EQ Out bypasses it. Every factory preset carves at least one instrument with it." }),
							/* @__PURE__ */ m("h3", { children: "Mute and solo" }),
							/* @__PURE__ */ m("p", { children: "M mutes and S solos a device, drum voice, SUM channel or step, and the two are exclusive. CLR clears one device’s mutes and solos, with its voices’, channels’ or steps’, and SWAP turns a muted device or SUM channel soloed or a soloed one muted; CLR ALL clears everything, MAIN’s mute included. Silenced parts dim. These settings last for this session." }),
							/* @__PURE__ */ m("h3", { children: "Undo and unsaved changes" }),
							/* @__PURE__ */ h("p", { children: [
								"Undo and Redo, or ",
								/* @__PURE__ */ m("strong", { children: "⌘Z" }),
								" and ",
								/* @__PURE__ */ m("strong", { children: "⇧⌘Z" }),
								" (",
								/* @__PURE__ */ m("strong", { children: "Ctrl+Z" }),
								" and ",
								/* @__PURE__ */ m("strong", { children: "Ctrl+Y" }),
								"), step through your last 50 changes: knobs, steps, CLEAR, recorded takes, tempo, cables, devices, presets, mutes, solos and octave. A ",
								/* @__PURE__ */ m("strong", { children: "*" }),
								" after the patch name means it has changed since you last saved it to My Presets or loaded it, and Revert puts it back that way as one more step, so Undo brings your changes back. While it has changed, the line under the name says whether those edits are saved in this browser, which brings them back after a reload; if it says Not saved, export a file to keep them. Revert leaves mutes, solos and the transport alone: Play Stopped starts what you stopped, and Rewind only moves back to bar 1."
							] }),
							/* @__PURE__ */ m("h3", { children: "Presets and files" }),
							/* @__PURE__ */ h("p", { children: [
								"Your rack keeps itself between visits. Save, or ",
								/* @__PURE__ */ m("strong", { children: "⌘S" }),
								" (",
								/* @__PURE__ */ m("strong", { children: "Ctrl+S" }),
								"), keeps it in My Presets in this browser: the first save asks for a name, and later saves update that preset. Type a new name in PATCH and save to rename it; Save as… (",
								/* @__PURE__ */ m("strong", { children: "⇧⌘S" }),
								") makes a copy. Presets lists My Presets above the factory presets. Export downloads a preset as a .json file, Import file adds one to My Presets, and Delete removes your own presets. Export WAV renders the number of loops chosen next to it, every sequencer from the start, effects and mutes included, but not MAIN’s Mute. Once you edit the rack, the line under the patch name says whether your edits are kept in this browser, and messages appear briefly over the bottom of the rack. Panic silences everything at once."
							] })
						]
					})
				}),
				re === "about" && /* @__PURE__ */ m("div", {
					className: $.helpBackdrop,
					children: /* @__PURE__ */ h("div", {
						className: `${$.help} ${$.about}`,
						role: "dialog",
						"aria-modal": "true",
						"aria-labelledby": nr,
						onKeyDown: ki,
						children: [
							/* @__PURE__ */ h("div", {
								className: $.helpHeading,
								children: [
									/* @__PURE__ */ m("img", {
										src: "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2064%2064'%3e%3crect%20x='5'%20y='6'%20width='54'%20height='52'%20rx='3'%20fill='%23303337'%20stroke='%23101214'%20stroke-width='2'/%3e%3cpath%20d='M10%2010v44M54%2010v44'%20stroke='%23777'%20stroke-width='3'/%3e%3crect%20x='14'%20y='12'%20width='36'%20height='17'%20fill='%23b9503a'%20stroke='%23111'/%3e%3crect%20x='14'%20y='31'%20width='36'%20height='20'%20fill='%23a0ac9b'%20stroke='%23111'/%3e%3cg%20fill='%23232626'%20stroke='%23dfdfca'%3e%3ccircle%20cx='23'%20cy='21'%20r='5'/%3e%3ccircle%20cx='41'%20cy='21'%20r='5'/%3e%3c/g%3e%3cpath%20d='M23%2021v-4m18%204%203-3'%20stroke='%23fff'%20stroke-width='2'/%3e%3cg%20fill='%231b2221'%20stroke='%23555'%3e%3ccircle%20cx='22'%20cy='39'%20r='3'/%3e%3ccircle%20cx='42'%20cy='44'%20r='3'/%3e%3c/g%3e%3cpath%20d='M22%2039c-6%2020%2027%2020%2020%205'%20fill='none'%20stroke='%23f4bb50'%20stroke-width='3'/%3e%3cpath%20d='M7%208h50'%20stroke='%23a9abad'/%3e%3c/svg%3e",
										width: "34",
										height: "34",
										alt: ""
									}),
									/* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("small", { children: "RACKLOOSE · MODULAR SYNTHESIZER" }), /* @__PURE__ */ m("h2", {
										id: nr,
										children: "About Rackloose"
									})] }),
									/* @__PURE__ */ m("button", {
										autoFocus: !0,
										onClick: Ai,
										"aria-label": "Close about Rackloose",
										children: "×"
									})
								]
							}),
							/* @__PURE__ */ h("dl", {
								className: $.aboutFacts,
								children: [
									/* @__PURE__ */ m("dt", { children: "Version" }),
									/* @__PURE__ */ m("dd", { children: "2.13.0" }),
									/* @__PURE__ */ m("dt", { children: "By" }),
									/* @__PURE__ */ m("dd", { children: "Michael Zick" })
								]
							}),
							/* @__PURE__ */ m("p", {
								className: $.aboutTagline,
								children: "Small studio. Endless possibilities."
							}),
							/* @__PURE__ */ m("p", {
								className: $.aboutCopyright,
								children: "© 2026 Michael Zick"
							})
						]
					})
				}),
				kn !== null && /* @__PURE__ */ m(Bs, {
					initialName: kn,
					presets: vn,
					onSave: xi,
					onCancel: bi
				})
			]
		})
	});
}
export { ul as RacklooseApp, fr as parsePatch, lr as preset, ur as serializePatch };
