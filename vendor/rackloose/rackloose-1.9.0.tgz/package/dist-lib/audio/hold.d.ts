type Event = {
    type: 'set' | 'ramp' | 'target';
    time: number;
    value: number;
    constant: number;
};
/** The level `events` give at `time`, following Web Audio's rules for the three event types Rackloose schedules. */
export declare function levelAt(events: Event[], base: number, time: number): number;
/**
 * Lets `holdAt` stop `param` exactly where it would be at a future time in browsers without `cancelAndHoldAtTime`
 * (Firefox), by recording this one param's automation. Does nothing where the method exists; never touches the prototype.
 */
export declare function holdable<T extends AudioParam>(param: T): T;
/**
 * `cancelAndHoldAtTime`, which Firefox lacks. There a `holdable` param stops at its scheduled level at `time`; any other
 * param holds its current value, which is exact only for `time` at or near the present.
 */
export declare function holdAt(param: AudioParam, time: number): void;
export {};
