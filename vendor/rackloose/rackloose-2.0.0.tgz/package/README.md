# Rackloose

An original, playable modular synthesizer for the browser, inspired by hardware studio racks. A standalone instrument page and a reusable React component share the same instrument and Web Audio engine.

## Run locally

Use Node 24 (`nvm use` if you use nvm) and npm. The Analog engines (ladder filters and analog-modeled drums) are Rust compiled to WebAssembly, so building also needs [Rust from rustup](https://rustup.rs) with its WebAssembly target:

```sh
rustup target add wasm32-unknown-unknown   # once
npm ci
npm run dev
```

`npm run dev`, `npm test` and both builds first run `npm run build:wasm`, which compiles `crates/rackloose-dsp` into `src/audio/generated/` (git-ignored). Cargo rebuilds only when the crate changes.

Open http://127.0.0.1:5173. **Play All**, **Reset**, tempo (typed, or dragged on the small slider under it), swing, and **CLR ALL** live above the keyboard and stay available with the keys hidden or the rack flipped. Play All becomes **Pause All** while anything plays; pausing holds the shared position. Reset stops and rewinds to step 1. Each STEP–16, BOOM, PUNCH, and ORBIT also has its own Play/Stop: starting one joins the next sixteenth-note boundary at the shared position, without starting or stopping other sequencers. Space always toggles global play/pause, whichever control has focus, except while typing in a text field such as the patch name.

Click a playable module's panel or focus its controls to select the keyboard target. The highlighted module and **KEYBOARD →** label identify it, including the rack number for duplicates. Effects retain the last selected instrument. MONARCH, ORACLE and SOLID use the piano or **A W S E D F T G Y H U J K** with octave controls. MONARCH and SOLID play the most recent held key; ORACLE gives each held key its own voice, up to five, and releasing one key leaves the others sounding. STEP–16 routes keys through its pitch/gate cables and is the initial target; playing an added STEP–16 from the keys takes over only that one, and the others keep their sequences. STATIC has a held Noise pad on A, using its connected amplitude-control path. Selecting a percussion module changes the keyboard to voice pads along the home row:

| Key | BOOM | PUNCH | ORBIT |
| --- | --- | --- | --- |
| A | Kick | Kick | Skin |
| S | Snare | Snare | Wood |
| D | Rim | Clap | Sand |
| F | Clap | Hat | Metal |
| G | Hat | Open | Shaker |
| H | Open | — | Tom |
| J | Lo tom | — | — |
| K | Hi tom | — | — |
| L | Crash | — | — |
| ; | Ride | — | — |
| ' | Bell | — | — |

Up to six pads fit on one row; BOOM's eleven wrap onto two.

Pads trigger once per press, allow simultaneous voices, and never edit or record the pattern. Manual notes take priority only on the selected instrument; other sequencers keep playing. Keys always follow existing audio cables and effects, so a disconnected instrument remains silent. Switching targets releases held notes. Typing in fields never plays notes; note keys work while a knob is focused, alongside its arrow-key controls. Drag knobs vertically and double-click to reset. **Hide keys** gives the rack more room.

**Flip rack** reveals the sockets. **Each jack holds one cable.** Every output has a numbered spare jack, and STEP–16's Pitch and Gate have three each, so one signal can reach several inputs without stacking cables. Drag from an empty jack to a free one, in either direction; only free, compatible jacks light up. Drag a plugged jack to pull its plug out: the cable follows the pointer, and dropping it on a free jack moves it while dropping it on empty rack space unplugs it. Tapping a plugged jack (or focusing it and pressing Enter) lifts its plug the same way; with a mouse it follows the pointer until you tap a free jack, tap the same jack to put it back, or tap empty rack space to unplug it. Click a cable to select it; Delete or Backspace removes the selected or lifted cable. Escape, occupied or incompatible jacks, and drops outside the rack leave cables unchanged. The rack scrolls near its edges. Amber is audio, blue is CV, coral is gate; signal types must match. The trim beside each CV input controls modulation depth. External cycles are rejected; ECHO supplies bounded internal feedback. Rear-panel patching retains the keyboard target.

## Devices and signal conventions

| Device | Purpose |
| --- | --- |
| STEP–16 | Sixteen-step sequencer / keyboard pitch and gate source. The first is permanent; add more for separate parts |
| SOLID | Sine, triangle, saw, and square oscillator |
| STATIC | White, pink, and brown noise |
| SUM | Eight-channel console in the SSL manner. Each channel strip is named after the instrument feeding it, through any effects, and has pan, mute and solo, a long-throw fader and an LED level meter; the mix bus fader and its stereo meter set the whole mix |
| SIEVE | Low-pass, high-pass, and band-pass filter: a Digital biquad or an Analog multimode ladder |
| LEVEL | Amplifier; CV input controls its amplitude when patched |
| CONTOUR | Attack, decay, sustain, release envelope |
| PULSE | Low-frequency modulation oscillator |
| ECHO | Delay with internal feedback and dry/wet mix |
| SPACE | Stereo convolution reverb with generated impulse responses |
| BOOM | Analog-style drum machine: long sub kick, snare, rim, clap, closed/open hats, low/high toms, crash, ride, and cowbell lanes; Digital or Analog engine |
| PUNCH | Dance floor drum machine: punchy kick, snare, clap, and closed/open hats; Digital or Analog engine |
| ORBIT | Six editable percussion voices: Skin, Wood, Sand, Metal, Shaker, and Tom; Euclidean or custom rhythms; Digital or Analog engine |
| MONARCH | Vintage mono synth with three oscillators, noise, a saturated four-pole low-pass filter (Digital biquads or an Analog Moog-style ladder), two envelopes, and glide |
| ORACLE | Five-voice poly synth in the Prophet mould: two oscillators with pulse width, poly-mod, LFO, four-pole low-pass filter (Digital or an Analog ladder), two envelopes, glide, per-voice Vintage drift, and chord memory |
| AURORA | Eight-voice Jupiter-8-inspired polysynth: dual oscillators, PWM, cross-mod, high-pass, 12/24 dB low-pass (Digital or an Analog ladder), two envelopes, LFO, glide, drift and chord memory |
| STRIKE | Sixteen-lane LinnDrum-inspired digital kit, using original generated one-shots with per-voice tune, decay, tone, level and pan; Digital or Analog engine |
| SKITTER | Trap step sequencer that makes no sound. Lanes for kick, snare, clap, hat, open hat, perc and a synth gate; any step plays a 1/16, a pair of 1/32s, or a roll of 1/32 triplets, 1/64s or 1/64 triplets, with Roll fade softening each roll. **Trig out** plays the matching voices of any drum machine's **Trig in**; **Synth gate** opens MONARCH, CONTOUR or a polysynth |
| FORGE | Industrial rock kit: driven kick, cracking snare, closed, pedal and open hats, crash, china, ride, floor and rack toms, and an anvil. Kit Drive and a gated Room are connected only while turned up; Digital or Analog engine |
| RUST | Abrasive distortion: Fuzz, Rectify, Fold, Crush (bit depth, aliasing on purpose) and Broken (lopsided clipping), with Body choosing what breaks up, Starve choking quiet tails, Bias, Tone, Mix and a Drive CV input |
| PRISM | Six-operator, sixteen-voice DX7-inspired FM synth with six focused algorithms, editable operator envelopes, and a ladder filter per voice on its Analog engine |
| VALVE | Variable-mu tube limiter in the Fairchild style: tube saturation, six time constants, and a gain-reduction meter |
| CONSOLE | British console channel EQ in the SSL style: high- and low-pass filters, LF and HF shelf or bell, and two sweepable mids with Q. Every factory preset carves at least one instrument with it |
| COHERE | Stereo bus compressor: three ratios, stepped attack/release, Auto recovery, detector HP and reduction meter |
| TALON | Harmonic compressor: eight curves including Opto and Crush, Clean/Even/Odd, independent audio/detector filters, Fierce and stereo link |
| BRIT | Three-band Class A EQ: broad shelves, fixed-Q mid, 18 dB/octave HP, drive and a filter response display |
| MAIN | Permanent master gain, output meter, and compressor |

**Add device** adds more STEP–16s. Each one carries its own 16 steps, step editor, step mutes and Play/Stop, runs on the shared clock, tempo and swing, and plays whatever its own three Pitch and three Gate jacks reach, so a bass line, chords and a lead can each drive different instruments. Every Pitch moves before any gate opens on a step, so ORACLE gated by one STEP–16 and pitched by another hears that step's note. Each STEP–16's **Lag** knob, beside its display, moves all of its notes up to 50 ms ahead of the beat (turned left) or behind it (turned right), keeping their length, while the clock and the other STEP–16s stay on the grid; centred reads On beat. The first STEP–16 stays in slot 1; added ones move, duplicate (with their steps) and remove like any device, and their mute, step and transport labels carry their rack number, such as STEP–16 #5.

Pitch CV is one volt per octave, with C4 at 0 V. SOLID pitch/FM inputs scale CV by 1,200 cents; SIEVE cutoff modulation scales by 2,400 cents. CONTOUR outputs a 0–1 envelope, scaled by note velocity; PULSE outputs bipolar modulation. Gate events drive connected envelopes at scheduled audio times. CONTOUR and MONARCH's envelopes start each new note from the level the last one reached and each release from the key-up, so retriggering a ringing note never clicks. No samples or assets need external services. STRIKE generates its original one-shot buffers locally; it does not use recordings from LinnDrum.

Every instrument and drum machine has a hit LED beside its name that flashes each time a sequencer plays it: drum machines on their own hits, and instruments on the steps of the STEP–16 whose Pitch or Gate reaches them, directly or through what it controls, such as CONTOUR opening a LEVEL the instrument passes through.

SUM's pan keeps the near side at unity and turns the far side down, so a centred channel sounds exactly as it did before pan existed, and its meters read each channel after its fader and mute, and the mix bus after its fader. Patches saved before 1.9.0 load with every channel centred and the mix bus at unity.

Drum devices store their rhythms in the patch and follow the global tempo and swing. Click pads to program BOOM and PUNCH or tap voice names to audition. Every drum machine also has a **Trig in** gate jack for SKITTER. SKITTER's **Note** buttons choose what a pad tap writes: 1/16 toggles a step, and 1/32, ×3, ×4 or ×6 splits that 16th into evenly spaced hits (swing included); tapping a step already set that way takes it back to a 1/16. Its kick, snare, clap, hat and open hat lanes play the kit voices of the same name, and Perc plays BOOM's or STRIKE's rim, FORGE's anvil or ORBIT's wood. Note values are stored as extra step masks, so they save in patch format v1. ORBIT spreads each lane's Hits across its Steps, rotated by Shift; shorter lanes create polymeters. Each of its six voices has Tune, Decay, Tone, Pan, Lag, and Level. Select a voice in the editor and tap step pads to seed a Custom rhythm from the generated pattern. **Generate** returns to Euclidean mode. Custom masks survive length changes and save/load. Legacy patches keep their original three sounds; the additional lanes start with zero hits.

Drum voices are monophonic, and the closed hats on BOOM and PUNCH choke their open hats. Every drum lane has a level knob marked LEVEL between its mute and solo buttons and its pads (in a narrow rack, under its voice name), and ORBIT's sits in its Level column: unity at its centre, silent at zero and +6 dB at full. Hovering shows the change in dB and a double-click resets it. On BOOM, PUNCH and ORBIT it scales the voice after the voice's own saturation, so it changes loudness rather than tone, and patches from before the knob play every voice at unity. BOOM, PUNCH, STRIKE and FORGE edit one voice at a time in a voice editor: click a voice's name, tap its performance pad or pick it under **Edit voice**, and its own knobs appear, ending in its Pan and Lag. **Lag** moves that one voice up to 50 ms ahead of the beat (turned left) or behind it (turned right), in whole milliseconds, such as hats pushed ahead or a snare laid back, without moving the rest of the kit or the clock; centred reads On beat. SKITTER's hits follow the Lag of the kit they play, and tapping a voice's name or pad plays it at once. A hit pulled ahead of the very first step plays as soon as the sequencer starts, and patches from before Lag play every voice on the beat. On BOOM every voice has at least two: the kick Tune and Decay; the snare Tune, Decay, Tone and Snappy; the rim Tune and Decay; the clap Tone and Decay; each hat and cymbal its Decay and Tone; each tom its own Tune and Decay; and the bell Tune and Decay. PUNCH's kick has Tune, Decay and Click, its snare and clap the same knobs as BOOM's, and its hats Decay and Tone. Every new knob starts where that voice already sounded, so older patches play as they did; one saved when BOOM's two toms shared a Tune and Decay gives both toms those settings. Patches from before BOOM's newer voices keep their sound, with the new lanes empty. Every drum voice's Pan is equal-power: centred, BOOM, PUNCH and ORBIT voices play at unity on both sides, exactly as before they had one, and hard to one side they play 3 dB louder there and silent on the other. Chain in passes other instruments at unity even when that drum device is stopped or muted. MONARCH has individual oscillator waveform/octave/detune/level, noise level, cutoff/resonance/drive, filter envelope amount and keyboard tracking, separate filter/amp envelopes, glide, and master level. Its **Engine** toggle picks Analog (a Moog-style ladder, whose input Drive pushes) or Digital (saturation into two cascaded biquads). See [Digital and Analog engines](#digital-and-analog-engines). Pitch CV, Gate, Cutoff CV, and Audio out keep it patchable; targeted keyboard playing uses its internal envelopes directly.

ORACLE and AURORA have the same four port types; PRISM replaces Cutoff CV with Brightness CV. Both audio outputs carry the same signal. A STEP–16 Pitch cable into a polyphonic instrument carries notes rather than a voltage: each voice takes its note when it starts, so release tails keep their pitch while the next chord plays. The cable's trim scales the note around C4 as it would a voltage, and without one ORACLE plays C4, like MONARCH. Other CV into Pitch, such as PULSE vibrato, reaches every voice. Voices are allocated from scheduled times, so live playing and export match: a new note takes the voice silent longest, then the one released longest ago, and only then steals the oldest held note. **Chord** (Maj 7, Min 7, Maj 9, Min 9, Min 11 or Dom 9) turns every note, from the keys or STEP–16, into up to five voices. Pulse waves come from a comparator on each saw, so Width and the LFO's PW destination modulate pulse width with native nodes.

AURORA uses eight independent dual-oscillator voices. Each oscillator offers saw, pulse, triangle and sine, octave, detune and pulse width; Source mix blends them and adds oscillator-2 cross-modulation. Its high-pass and selectable 12/24 dB low-pass, two envelopes, three-destination LFO, glide and deterministic Vintage drift provide a focused Jupiter-8-inspired palette. Like ORACLE, it has per-note sequencer pitch and chord memory, so release tails retain their notes.

PRISM provides six sine operators and sixteen voices. Its algorithms are Three pairs, Twin stacks, Serial stack, Shared modulation, Branched and Additive; the display shows their routing, with arrows from modulator to carrier. Select OP 1–6 to edit ratio, detune, level and ADSR. Brightness scales phase modulation, Feedback feeds operator 6, Velocity adjusts timbre with sequencer velocity, and the LFO adds vibrato. These are focused original patches and controls, not DX7 SysEx or a complete hardware recreation. A self-contained inline AudioWorklet supplies the same sample-timed phase-modulation engine in live audio and OfflineAudioContext exports. The standalone and React builds include it; the host needs no separate asset path. Worklet setup happens on audio activation, and exports wait for the event queue before rendering.

STRIKE has kick, snare, sidestick, clap, closed/open hats, three toms, two congas, cabasa, tambourine, cowbell, crash and ride. Its deterministic drum models are printed to 28 kHz companded 8-bit-style buffers, then played with adjustable pitch, decay, tone, level and stereo pan. These approximate vintage sampled drums with original generated sounds. Select a voice in **EDIT VOICE** to adjust it; its level is the knob on its lane. Closed hats choke open hats; every lane retriggers monophonically, and Chain in remains audible when the kit is muted. All sixteen lanes have pads and keyboard shortcuts: the existing **A S D F G H J K L ; '** followed by **Z X C V B**.

VALVE drives an asymmetric tube curve into a soft-knee compressor whose ratio rises with level. Time constants 1–6 follow the original attack times; Web Audio limits release to one second, so the slow settings (up to 25 s on the hardware) are scaled into 0.3–1 s. VALVE removes the compressor's automatic make-up gain, so a signal below the threshold passes at unity and Output alone sets the level. CONSOLE's high-pass is off fully anticlockwise (16 Hz) and its low-pass fully clockwise (22 kHz). Its screen draws the response from the same filter settings the audio uses, and **EQ Out** bypasses all six filters.

**Presets** in the patch bar opens the preset browser: your own presets, under **My Presets**, above the factory presets. Hip-hop, trap and R&B come first. The rack opens on **High Dive**, the first of three trap starters (High Dive, Undertow and Deep End) with SKITTER rolling BOOM's hats, followed by Trap Soul, Late Night Hip-Hop and Boom Bap; the original Groove and House starters come next, and two industrial rock originals put FORGE and RUST to work, neither with a cymbal crash: **Rust Machine**, a slow, dry, funky crawl at 93 BPM in F minor, with a squelching sixteenth bass, clean Fm7 to B♭m7 guitar chops, a dark pad and a distorted line, its hats pushed a little ahead and its snare laid a little behind the beat with Lag; and **Dead Highway**, a drop-D stomp at 124 BPM, with a palm-muted chug that walks down A–G–F–E into every bar, B-movie stabs crushed to five bits and straight eighths with a tom run into the turnaround. Every other factory preset is an original arrangement written for its style, with each part on its own STEP–16 or spare jack, its own SUM channel, and the processing that style's records used: TALON on the drums, BRIT on the part that needs colour, and VALVE or COHERE between SUM and MAIN. Every factory preset also carves at least one instrument on CONSOLE the way a desk channel would: the low end it doesn't need filtered off, the boxiness cut from the low mids, and presence or air brought forward.

| Preset | BPM | Swing | Character |
| --- | --- | --- | --- |
| High Dive | 76 | 0% | Pop-trap in A minor, and the rack's opener: a bright pluck hook over AURORA Am9 to Fmaj7, an 808 on the roots, claps on 2 and 4, SKITTER's hats breaking into 1/32s on the last beat, VALVE on the bus |
| Undertow | 72 | 5% | A warm ballad in G: ORACLE strums Gmaj9 to Cmaj9, a soft sine lead sings on top, SKITTER's Synth lane bounces the 808 and its triplet hat rolls lead into each snare |
| Deep End | 64 | 4% | Slow and ominous in G minor: a driven 808 sinks from G to E♭ and climbs back through F♯, MONARCH answers with a few long gliding accents in a deep ECHO and SPACE, BOOM keeps 2 and 4, SKITTER's hats break into triplets and 1/64s, a rim ticks in the gap |
| Trap Soul | 68 | 6% | Modern R&B over a southern trap beat: ORACLE plays Fm9 to B♭m9 through CONSOLE and SPACE, a second STEP–16 slides MONARCH's 808 through BRIT, BOOM runs through VALVE, a PRISM bell answers in echo |
| Late Night Hip-Hop | 72 | 24% | AURORA Am7 and Gm7 over F and E♭ bass make Fmaj9 to E♭maj9; BOOM leans into an Opto TALON, ORBIT shaker, a dark CONSOLE then COHERE on the bus |
| Boom Bap | 84 | 18% | One STEP–16 doubles a round MONARCH bass under PRISM e-piano chords on BRIT, Dm9 to Gm9; BOOM knocks through TALON (Odd), ORBIT adds wood and shaker, VALVE on the bus |
| Vintage Bass | 94 | 10% | G-funk: a sliding MONARCH bass on BRIT under AURORA Gm9 to Cm9, a portamento sine whistle in ECHO, a laid-back STRIKE kit through TALON |
| Vintage Lead | 120 | 0% | Italo disco: a square-and-saw MONARCH hook in ECHO, an octave-bouncing bass on BRIT, AURORA Am7–F6–G6 strings, BOOM through TALON |
| Roots Reggae | 76 | 20% | One drop: kick and rim together on beat 3, a round A-minor to D-minor bass on BRIT, an AURORA organ bubble, an ORACLE skank in ECHO and SPACE, ORBIT chops |
| Dub Session | 70 | 18% | BOOM through TALON into SPACE, ORBIT accents into a long ECHO, a dry E-minor sub on BRIT, an ORACLE Em7 skank repeating into its own echo, a PRISM melodica in a hall |
| Broken Beat | 108 | 10% | A displaced PUNCH kit through TALON, ORBIT congas, ORACLE Cm9 to Fm9 stabs in ECHO and a bouncing MONARCH bass on BRIT |
| Orbit Percussion | 96 | 8% | All six ORBIT rings against each other, left dry, over a half-time BOOM kick, a PRISM kalimba ostinato in ECHO and a sine sub that BRIT gives enough harmonics to carry |

Six 80s arrangements split their parts between AURORA, PRISM and MONARCH, play STRIKE as the drum machine, and run the mix into COHERE:

| Preset | BPM | Swing | Character |
| --- | --- | --- | --- |
| Neon Skyline | 112 | 0% | Synthwave: AURORA Am7 and Em7 pads over an F–C PRISM bass make Fmaj9 to Cmaj9, a MONARCH arpeggio in ECHO, and a STRIKE room that TALON Crush gates |
| Digital Boogie | 116 | 12% | A PRISM slap bass popping octaves on BRIT, AURORA Em9 to Am9 stabs, and STRIKE claps, sixteenth hats and cowbell through TALON |
| Midnight Ballad | 76 | 4% | A slow jam: PRISM e-piano B♭maj9 to E♭maj9 in ECHO, an AURORA string swell, a sliding fretless-style MONARCH bass and a gated STRIKE snare |
| New Wave Motion | 132 | 0% | A driving eighth-note MONARCH bass on BRIT, one Dm7 pad that turns B♭maj9 over the bass, a PRISM bell hook in ECHO and STRIKE tom fills |
| Glass Arcade | 108 | 0% | A glassy PRISM arpeggio from Cmaj7 to Am7 in ECHO, a square MONARCH melody on BRIT, an AURORA pulse bass jumping octaves and a clean STRIKE kit |
| Analog Sunrise | 96 | 6% | Balearic: AURORA Dmaj9 to Gmaj9 pads with BRIT air into SPACE, a PRISM pluck in ECHO, a sine sub, and ORBIT shakers and woodblock in place of a kit |

All presets load silently and start with Play All.

## Digital and Analog engines

Rackloose's analog-modeled DSP is written in Rust (`crates/rackloose-dsp`), compiled to WebAssembly and run in AudioWorklets, 2x oversampled. Ten devices have a chrome **Engine** toggle in their header, a top-hat slide switch on a legend plate: slide it right to the red **Analog** tab or left to the black **Digital** tab. Every device, factory preset and older patch starts Analog, and the Digital sound is always one flip away (and one undo back):

- **MONARCH, ORACLE, AURORA and SIEVE:** Analog is a zero-delay-feedback Moog ladder filter with saturation inside its feedback loop. Resonance self-oscillates near full, as on a Moog, and the filter envelope, key tracking, LFO and Cutoff CV still move the cutoff every sample. AURORA's 12 dB slope taps the ladder's second stage; SIEVE's High-pass and Band-pass mix the ladder's stages into four-pole responses.
- **PRISM:** Analog adds a ladder per voice, opened by the voice's first carrier envelope (Env amount) and its note (Key track) in its Filter section. Digital is PRISM with no filter.
- **BOOM, PUNCH, ORBIT, STRIKE and FORGE:** Analog voices are built from pitched modes that bend with their own level, as struck skins do, noise through saturating zero-delay-feedback filters, band-limited square banks for hats and cymbals, and beater clicks. STRIKE and FORGE play their one-shots through cubic interpolation and a ladder tone filter. Hits start sample-accurately, retriggers and chokes fade instead of cutting, and Analog voices follow hit velocity, so SKITTER's roll fade shapes them.

A patch saved on Digital stays Digital. Each Rust path is level-matched to its Digital counterpart by measurement, so switching changes the character rather than the balance of a mix; both sound the same live and in export. If the browser can't run WebAssembly, every device plays Digital. The [filter prototype](rackloose-filter-test/README.md) documents the ladder and offers a side-by-side comparison, and [the DSP notes](docs/rust-dsp.md) cover each model and its calibration.

## Undo and unsaved changes

**Undo** and **Redo** sit in the patch bar; ⌘Z / Ctrl+Z undoes, and ⇧⌘Z, Ctrl+Shift+Z or Ctrl+Y redoes. The last 50 steps are kept. Undo covers everything you change: knobs, steps, tempo, swing, the patch name, cables and their depth, adding, moving or removing devices, loading a preset or patch file, mute/solo/CLR/CLR ALL, MAIN's Mute, and the keyboard octave. A continuous knob turn or a burst of typing counts as one step. **Revert**, beside them, puts the patch back as it was last saved to My Presets or loaded, as one more step, so Undo brings the changes back. It is available while the **\*** shows and leaves the transport, mutes and solos, and where Save goes alone; the transport's **RESET** only returns sequencers to their first step. The shortcuts work anywhere inside the app, and outside it only while `keysEnabled` is on and focus isn't in a host text field. History starts fresh when the app opens or `storageKey` changes.

A **\*** after the patch name marks unsaved changes to anything a patch file stores. For a rack that belongs to one of My Presets, it compares the rack with that preset as last saved; otherwise it compares with the factory preset or file as loaded. It clears when you save to My Presets, load a preset, import a patch, revert, or undo back to the saved state. Undoing a load also returns Save to the preset the rack came from. Exporting a file leaves it alone, and mute/solo and the octave don't count, because patches don't store them.

The **?** button opens the **User Guide**, which explains transport, playing, patching, drums, mute/solo, undo and saving.

Every device header, drum voice lane, SUM channel and sequencer step has **M** (mute) and **S** (solo) buttons; they are exclusive, so turning one on turns the other off. Each device header has **CLR** to clear all of that device's mutes and solos at once, including its drum voices, SUM's channels or STEP–16's steps. Global **CLR ALL** clears every module, voice, channel and step mute/solo plus MAIN's Mute, without changing playback, patterns, levels, or cables. Muting a source silences it, muting a processor or modulator closes its output, muting STEP–16 stops its notes, and muting a drum device silences its voices while Chain in still passes. Soloing a device keeps only the sound sources that feed it; soloing CONTOUR, PULSE or STEP–16 solos what they drive, and Chain in doesn't count as feeding, so soloing BOOM plays BOOM alone. Drum voice, SUM channel and step solos apply within their own device or pattern, so soloing one SUM channel silences SUM's other channels. Silenced parts dim. Mute and solo are session-only: they aren't autosaved or written to patch files, and loading a preset or patch clears them. MAIN keeps its own temporary Mute.

Opening the app is silent; drums sound only while the pattern plays or when a voice is auditioned. An oscillator patched straight into MAIN produces a continuous drone once audio is enabled; gate-controlled playing requires CONTOUR → LEVEL amplitude CV. Local Stop and global Pause/Reset cancel queued triggers, release sequencer gates, and let existing effects decay. **Panic** cuts all sources and pending starts immediately. Monophonic targets use last-note priority; polyphonic targets keep independently held notes. Live playing overrides only the targeted instrument while held.

## Save and export

The current patch autosaves under `rackloose.patch.v1` in browser localStorage, and is written again when the page closes; the light beside the patch name shows whether it is saved, and turns amber when browser storage is unavailable. Messages about what just happened appear briefly over the bottom of the rack. Named presets work like documents:

- **Save** (⌘S / Ctrl+S) keeps the rack in **My Presets** in this browser. The first save of a factory preset or new rack asks for a name; after that, Save updates the same preset, and a new name typed in PATCH renames it. A name another of your presets already has asks before replacing it.
- **Save as…** (⇧⌘S / Ctrl+Shift+S) saves a copy under a new name, and the rack carries on as that copy.
- **Presets** lists My Presets alphabetically, marking the open one, with **Export** and **Delete** for each. Delete asks first and cannot be undone. Factory presets can't be deleted. Loading any preset closes the browser and is one undo step.
- **Export file** downloads the rack, unsaved changes included, as `<name>.rackloose.json`, a plain v1 patch.
- **Import file…** validates a patch and adds it to My Presets. A patch identical to one already there just opens it; a different one with a taken name becomes `Name (2)`.

My Presets are stored under `<storageKey>:presets`, and the preset the rack belongs to under `<storageKey>:open`. Both are validated on every read, and entries that fail are skipped. Other open tabs update their list when one changes it. The last saved or loaded state, which the unsaved-changes star compares with and Revert returns to, is kept under `<storageKey>:baselinePatch`, and its signature, which versions before 2.0.0 read, under `<storageKey>:baseline`. A rack saved by one of those versions has no stored patch, so it counts as saved as it opens. Denied storage, full storage, or an invalid saved patch never prevent playing or file exports. Files contain only module definitions, values, cable endpoints/depths, patch name, and sequencer settings; the first STEP–16's steps stay in `sequencer.steps` and each added STEP–16 saves its own `steps` on its module, so older v1 patches load unchanged; playback state, keyboard target, mute/solo, and browser AudioNodes are not saved. New Orbit and BOOM parameters default safely when absent from older v1 patches; malformed supplied values are rejected. Older patches that stacked several cables on one output jack load with the extras moved to its spare jacks; any cable that still has no free jack is dropped, and opening a file says how many.

**Export WAV**, in the patch bar beside Presets, renders 1, 2, 4, or 8 loops (chosen in the menu beside it) of the sequence and drums at 44.1 kHz, stereo 16-bit PCM, including a 40 ms scheduling lead-in and a two-second tail. Offline rendering shares the live graph and scheduling functions. It renders every sequencer from the beginning, independent of the keyboard target, manual playing, paused position, or temporarily stopped modules. The master level and any mute/solo are included; MAIN's temporary Mute button is not. Long reverb/high-feedback tails may extend beyond the export’s two-second tail.

## Builds

```sh
npm run build       # deployable static app in dist/
npm run build:lib   # ESM React component, CSS and TypeScript declarations in dist-lib/
npm run preview    # serve the standalone production build
```

Static assets use relative URLs. The standalone app is hosted at **https://rackloose.michaelzick.com** through its own Cloudflare Worker. No backend, account, API keys, or analytics are required. The package is private to prevent accidental npm publication. `npm pack` always rebuilds the library before creating an archive containing the component, stylesheet, icon, and this guide. See [release and deployment instructions](docs/releases.md) for immutable tagged releases and Workers Builds settings.

## Mike OS integration

Mike OS consumes a pinned release archive in its own repository. The instrument's source and tests remain here; the website's window adapter supplies its existing desktop chrome and lifecycle state.

Copy the release archive and manifest into the host's `vendor/rackloose/` directory, verify the checksum, and install the archive from that committed path. The installed component uses the host's React; it needs no sibling checkout or registry credentials. Import the stylesheet once from the lazy-loaded client adapter and put the component inside the existing `Window` chrome. The library includes a preserved `"use client"` boundary and externalizes React; it can be imported by a Next.js client wrapper without creating audio during server rendering.

```tsx
'use client';

import { RacklooseApp } from 'rackloose';
import 'rackloose/style.css';
import Window, { type WindowChrome } from './Window';

export default function RacklooseWindow(
  { powerOn, ...chrome }: WindowChrome & { powerOn: boolean },
) {
  return (
    <Window
      {...chrome}
      title="Rackloose"
      zoomable
      minSize={{ width: 340, height: 440 }}
      className="rackloose-window"
    >
      <RacklooseApp
        keysEnabled={chrome.active && !chrome.collapsed && powerOn}
        suspended={chrome.collapsed || !powerOn}
        storageKey="mz.rackloose.patch.v1"
      />
    </Window>
  );
}
```

Give the host window’s content a defined height (for example, `height: min(780px, calc(100dvh - 90px))`), `min-height: 0`, and flex sizing so the rack scrolls inside its window. Rackloose styles are scoped; it supplies neither desktop chrome nor global styles. Its content responds to the window’s container width. Use the original `rackloose/icon.svg` package asset as the Finder application icon.

Register an application item and window ID in the host’s desktop state, expose it in Applications and the corresponding menu, and lazy-load this wrapper from the desktop window renderer. Bind keyboard availability exactly like Calculator; inactive windows may continue sequencing. Closing the window must unmount the wrapper. Collapsing or sleeping suspends audio; resuming requires a fresh user interaction. Rackloose has no Finder/menu dependencies, and it never handles Return as a global shortcut.

| Prop | Default | Contract |
| --- | --- | --- |
| `keysEnabled` | `true` | Enables computer keyboard shortcuts; disabling releases held manual notes. Pointer controls remain usable. |
| `suspended` | `false` | Stops and silences all playback; disables play/piano activation until resumed. |
| `storageKey` | `rackloose.patch.v1` | Origin-local namespace for the autosave and My Presets. Changing it loads that namespace or the High Dive default. |

The app also suspends when the document becomes hidden and disposes all nodes, timers, listeners and its AudioContext on unmount. Reopening restores the autosaved patch without autoplaying.

Phones start audio only when a finger lifts, while keys and pads play on touch down, so a key or pad touched while audio is off starts audio once, as the finger lifts, and still sounds that tap's note. Canceled touches are discarded, including while audio is starting; a later unrelated control cannot replay them. On iPhone and iPad the app sets the Audio Session API's type to `playback` when audio starts, so it plays through Silent mode like a music app, and puts the previous type back on unmount.

Host lifecycle checks (activation, collapse, close/reopen) run against the dev-only `tests/host.html` harness, which drives `RacklooseApp` the way Mike OS does. The standalone page frames the instrument in a dark header with expand/contract and close buttons.

## Verify

COHERE, TALON and BRIT are original behavioral models; see
[studio processor details](docs/studio-processors.md) for their controls,
calibration, validation and limits. Four original electro patches demonstrate
them: French Touch, Distortion Disco, Electro Pogo and Electroclash. Patches containing them require 1.8.0 or later;
existing v1 patches remain compatible. SUM shows the same source names on both
panels, including upstream instruments through effects. Audio input sockets
retain signal-kind tooltips and accessible descriptions without a repeated
AUDIO caption; CV/GATE and depth captions remain visible.

```sh
rustup target add wasm32-unknown-unknown
npx playwright install chromium
npm run verify
```

`verify` also runs the Rust DSP's tests (`npm run test:dsp`).

The gate builds both bundles before browser tests. The built-library harness
at `tests/library-host.html` checks embedded worklet startup, WAV export and
host disposal, alongside source DSP measurements at 44.1 and 48 kHz.

Vitest covers legacy Orbit compatibility, custom rhythm round-trips, new presets and their names, one cable per jack with spare-jack migration, in-place cable moves, patch signatures for the unsaved-changes star, My Presets storage validation, unique names and export file names, the 50-step undo history, drum lane levels and their dB readout, BOOM and PUNCH voice knobs and pans loading older patches as they sounded, a Lag on every drum voice and STEP–16 that older patches load on the beat, CONSOLE on an instrument in every factory preset (both toms from the one pair) and reaching the Analog engine, patch topology/validation, safe persistence, Euclidean spacing and drum lanes, monophonic note priority, envelopes resuming from the level they interrupt, ORACLE voice allocation and chords, CONSOLE's response curve and VALVE's make-up gain, Trap Soul's routing, SUM's eight channels with three-channel patches and the source named on each channel, added STEP–16s with their own saved steps, step mutes and permanence, swing/bar duration, PCM headers/clamping, the playback audio session and its release, and server rendering. The normal gate runs Chromium UI tests, touch input and host lifecycle checks. WebKit remains available only as an optional manual check: `npx playwright install webkit` followed by `npm run test:webkit`. The real OfflineAudioContext tests run in Chromium only, covering 440 Hz pitch, silence without gates/disconnected output, envelope release, filter/CV effects, drum voices including BOOM's eleven, kick pitch, hat choke on PUNCH and BOOM, lane levels that silence or lift only their own voice by 6 dB on both engines, equal-power pans on every kit and engine that centre at the level each voice had before, each new BOOM and PUNCH tune, tone and decay knob moving its voice alike on both engines, Lag moving a kick and a STEP–16 note by exactly its milliseconds on both engines while auditions stay on time and a hit pulled ahead of the first step plays at once, SUM channel mutes and solos, chained audio, finite samples, WAV duration and tails, and audible, finite stereo renders of every 80s preset; a phone-sized Chromium that enforces the gesture rule checks that the first tap on a key sounds and claims the playback audio session. CI runs Playwright on one worker. Additional checks cover independent transport, keyboard targeting and pads, all-mix clearing, the Play All/Pause All toggle, dragging a plug out of its jack, spare jacks, the unsaved-changes star, Revert to a loaded or saved patch, a labelled level knob on every drum lane, the BOOM and PUNCH voice editors with a Pan and Lag on every voice, the STEP–16 Lag knob and its readout, saving, renaming, exporting, importing and deleting named presets, undo/redo of every kind of change, the User Guide, MONARCH pitch/filter/glide, click-free MONARCH and CONTOUR retriggers and key-ups, ORACLE held keys, chords, note cables and release tails, several STEP–16s driving separate instruments in export and from the keys, adding, editing, playing, duplicating and saving added STEP–16s, VALVE's unity gain and limiting, CONSOLE's filters and bypass against the browser's own biquad response, the larger patch name, queued-trigger cancellation, and new preset renders. It captures front/rear and expanded instrument views at 1440×1000, 800×600 and 375×812 under `test-results/`.

Browser tests validate generated audio and browser rendering; they do not certify hardware output latency or every physical mobile device. MONARCH and SOLID are intentionally monophonic; ORACLE has five voices, AURORA eight, and PRISM sixteen; there is no MIDI, arranger, recording, accounts, or cloud storage.

See [WebKit CI diagnostics](docs/webkit-ci.md) for the archived Linux audio-backend investigation. WebKit diagnostics are no longer an automatic CI or release requirement.

Created by Codex
