"use client";
import { Fragment as e, createContext as t, useCallback as n, useContext as r, useEffect as i, useId as a, useLayoutEffect as o, useMemo as s, useReducer as c, useRef as l, useState as u, useSyncExternalStore as d } from "react";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
//#region src/presetKit.ts
var h = (e) => [...e].reduce((e, t, n) => t === "x" ? e | 1 << n : e, 0), g = (e, t, n) => [...e].map((e, r) => ({
	note: t[r],
	enabled: e !== ".",
	velocity: e === "X" ? 1 : e === "o" ? .5 : .74,
	gate: typeof n == "number" ? n : n[r]
})), _ = (...e) => e.flatMap(([e, t]) => Array(t).fill(e)), v = (e) => Number((45 / e).toFixed(3)), y = (...e) => Object.fromEntries(Array.from({ length: 6 }, (t, n) => {
	let [r, i, a, o, s, c, l] = e[n] ?? [
		1,
		0,
		0,
		.005,
		.3,
		0,
		.2
	];
	return Object.entries({
		Ratio: r,
		Detune: i,
		Level: a,
		Attack: o,
		Decay: s,
		Sustain: c,
		Release: l
	}).map(([e, t]) => [`op${n + 1}${e}`, t]);
}).flat()), b = {
	epiano: y([
		1,
		0,
		.85,
		.002,
		1.8,
		.12,
		.7
	], [
		1,
		0,
		.45,
		.002,
		1,
		.05,
		.5
	], [
		1,
		4,
		.45,
		.002,
		1.4,
		.1,
		.6
	], [
		14,
		0,
		.2,
		.002,
		.12,
		0,
		.1
	], [
		1,
		-4,
		.35,
		.002,
		1.6,
		.1,
		.6
	], [
		1,
		0,
		.12,
		.002,
		.6,
		0,
		.3
	]),
	bell: y([
		1,
		0,
		.8,
		.002,
		2.2,
		0,
		1.4
	], [
		3.5,
		0,
		.5,
		.002,
		1.4,
		0,
		1
	], [
		2,
		3,
		.35,
		.002,
		1.5,
		0,
		1
	], [
		7,
		0,
		.3,
		.002,
		.6,
		0,
		.5
	], [
		4,
		0,
		.12,
		.002,
		.9,
		0,
		.6
	], [
		10.5,
		0,
		.15,
		.002,
		.3,
		0,
		.3
	]),
	reed: y([
		1,
		0,
		.8,
		.03,
		.4,
		.8,
		.25
	], [
		2,
		0,
		.5,
		.03,
		.5,
		.6,
		.3
	], [
		1,
		6,
		.3,
		.03,
		.4,
		.8,
		.25
	], [
		2,
		0,
		.3,
		.03,
		.5,
		.5,
		.3
	]),
	kalimba: y([
		1,
		0,
		.85,
		.002,
		.7,
		0,
		.4
	], [
		3,
		0,
		.35,
		.002,
		.08,
		0,
		.08
	], [
		1,
		5,
		.4,
		.002,
		.5,
		0,
		.3
	], [
		7,
		0,
		.18,
		.002,
		.04,
		0,
		.04
	]),
	slap: y([
		1,
		0,
		.9,
		.002,
		.35,
		.25,
		.08
	], [
		1,
		0,
		.65,
		.002,
		.15,
		.05,
		.06
	], [
		1,
		3,
		.5,
		.002,
		.3,
		.2,
		.08
	], [
		3,
		0,
		.35,
		.002,
		.05,
		0,
		.04
	], [
		.5,
		0,
		.35,
		.002,
		.4,
		.3,
		.08
	], [
		.5,
		0,
		.1,
		.002,
		.2,
		0,
		.06
	]),
	bass: y([
		1,
		0,
		.9,
		.002,
		.4,
		.3,
		.1
	], [
		1,
		0,
		.55,
		.002,
		.25,
		.1,
		.08
	], [
		.5,
		0,
		.5,
		.002,
		.5,
		.4,
		.1
	], [
		1,
		0,
		.2,
		.002,
		.15,
		0,
		.08
	]),
	pluck: y([
		1,
		0,
		.8,
		.002,
		.45,
		0,
		.3
	], [
		2,
		0,
		.4,
		.002,
		.15,
		0,
		.1
	], [
		2,
		3,
		.35,
		.002,
		.35,
		0,
		.25
	], [
		5,
		0,
		.2,
		.002,
		.06,
		0,
		.05
	])
};
function x(e, t, n, r, i) {
	let a = {
		version: 1,
		name: e,
		modules: Object.entries(r).map(([e, { type: t, params: n, lanes: r, euclid: i, steps: a }], o) => {
			let s = W(t, e), c = U[t].drum?.voices ?? [];
			if (r) for (let e of c) s.params[`${e.id}Pattern`] = h(r[e.id] ?? "");
			if (i) for (let e of c) {
				let [t, n, r = 0] = i[e.id] ?? [0, s.params[`${e.id}Steps`]];
				Object.assign(s.params, {
					[`${e.id}Hits`]: t,
					[`${e.id}Steps`]: n,
					[`${e.id}Shift`]: r
				});
			}
			return Object.assign(s.params, n), a && o > 0 ? {
				...s,
				steps: a
			} : s;
		}),
		cables: [],
		sequencer: {
			bpm: t,
			swing: n,
			steps: Object.values(r)[0].steps
		}
	};
	for (let [e, t, n, r, o] of i) a = Ke(a, {
		moduleId: e,
		portId: t
	}, {
		moduleId: n,
		portId: r
	}, o);
	return a;
}
var S = (e, t, n = "") => [[
	e,
	`pitch${n}`,
	t,
	"pitch"
], [
	e,
	`gate${n}`,
	t,
	"gate"
]], C = (...e) => e.slice(1).map((t, n) => [
	e[n],
	"out",
	t,
	"in"
]), w = (e, t, ...n) => [...e.flatMap((e, n) => [...C(...e), [
	e.at(-1),
	"out",
	t,
	"abcdefgh"[n]
]]), ...C(t, ...n)], T = (e, ...t) => w(e, "mixer", ...t, "output");
function E(e) {
	return e === "Vintage Bass" ? x(e, 94, .1, {
		performance: {
			type: "performance",
			steps: g("X..o.xx.X..x.xx.", [
				43,
				43,
				43,
				43,
				43,
				46,
				48,
				48,
				36,
				36,
				36,
				48,
				48,
				46,
				41,
				41
			], [
				.9,
				.5,
				.5,
				.5,
				.5,
				.6,
				.9,
				.5,
				.9,
				.5,
				.5,
				.45,
				.5,
				.6,
				.9,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Wave: 3,
				osc2Detune: 4,
				osc2Level: .4,
				osc3Wave: 1,
				osc3Level: .55,
				cutoff: 480,
				resonance: .3,
				drive: .3,
				envAmount: .45,
				filterAttack: .004,
				filterDecay: .25,
				filterSustain: .25,
				filterRelease: .15,
				ampAttack: .004,
				ampDecay: .4,
				ampSustain: .8,
				ampRelease: .08,
				glide: .04,
				level: .75
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 2,
				midFreq: 1,
				midGain: 3,
				drive: 6
			}
		},
		melody: {
			type: "performance",
			steps: g("x".repeat(16), _([86, 6], [84, 1], [82, 1], [79, 6], [77, 1], [79, 1]), .95)
		},
		whistle: {
			type: "monarch",
			params: {
				osc1Wave: 0,
				osc1Level: .9,
				osc2Level: 0,
				osc3Level: 0,
				cutoff: 6e3,
				resonance: 0,
				drive: 0,
				envAmount: 0,
				tracking: 0,
				ampAttack: .03,
				ampDecay: .3,
				ampSustain: 1,
				ampRelease: .3,
				glide: .12,
				level: .5
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(94),
				feedback: .35,
				mix: .25
			}
		},
		chords: {
			type: "performance",
			steps: g("x.......x.......", _([55, 8], [60, 8]), .95)
		},
		keys: {
			type: "aurora",
			params: {
				osc1Wave: 2,
				osc2Wave: 1,
				osc2Detune: 8,
				blend: .45,
				cutoff: 1600,
				resonance: .1,
				envAmount: .2,
				filterAttack: .05,
				filterDecay: .8,
				filterSustain: .4,
				ampAttack: .04,
				ampDecay: .9,
				ampSustain: .7,
				ampRelease: 1.6,
				lfoWidth: .3,
				chord: 4,
				vintage: .4,
				level: .6
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 150,
				lmfGain: -3,
				lmfFreq: 400,
				lmfQ: 1.2,
				hmfGain: 2,
				hmfFreq: 2500,
				hmfQ: .8,
				hfGain: 2,
				hfFreq: 1e4
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 1.8,
				mix: .25
			}
		},
		drums: {
			type: "strike",
			params: {
				level: 1,
				kickDecay: .4,
				snareTune: -2,
				snareDecay: .3,
				clapLevel: .55,
				hatDecay: .06,
				hatLevel: .45,
				hatPan: .2,
				openLevel: .4,
				openPan: .2,
				tambourineLevel: .3,
				tambourinePan: -.3
			},
			lanes: {
				kick: "x......xx.x.....",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "x.xxx.x.x.xxx.x.",
				open: ".....x.......x..",
				tambourine: "....x.......x..."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .01,
				release: .15,
				color: 1,
				detectorHp: 1,
				output: 7
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: .6,
				c: .7,
				d: .7
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 0,
				attack: 4,
				release: 4,
				output: 2
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("performance", "monarch"),
		...S("melody", "whistle"),
		...S("chords", "keys"),
		...T([
			["drums", "talon"],
			["monarch", "brit"],
			[
				"keys",
				"console",
				"space"
			],
			["whistle", "echo"]
		], "cohere")
	]) : e === "Vintage Lead" ? x(e, 120, 0, {
		performance: {
			type: "performance",
			steps: g("X.xx.xx.X.xxX.xx", [
				76,
				76,
				76,
				74,
				74,
				72,
				74,
				74,
				72,
				72,
				69,
				72,
				71,
				71,
				67,
				71
			], .7)
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 3,
				osc1Level: .7,
				osc2Detune: 9,
				osc2Level: .5,
				osc3Wave: 3,
				osc3Octave: 1,
				osc3Level: .2,
				cutoff: 2600,
				resonance: .25,
				drive: .2,
				envAmount: .35,
				tracking: .6,
				filterDecay: .2,
				filterSustain: .4,
				ampAttack: .004,
				ampDecay: .25,
				ampSustain: .7,
				ampRelease: .15,
				glide: .025,
				level: .6
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 200,
				lmfGain: -2,
				lmfFreq: 500,
				hmfGain: 3,
				hmfFreq: 3e3,
				hfGain: 2,
				hfFreq: 12e3
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(120),
				feedback: .3,
				mix: .22
			}
		},
		octaves: {
			type: "performance",
			steps: g("XxXxXxXxXxXxXxXx", [
				33,
				45,
				33,
				45,
				33,
				45,
				33,
				45,
				29,
				41,
				29,
				41,
				31,
				43,
				31,
				43
			], .5)
		},
		bass: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Detune: 6,
				osc2Level: .4,
				osc3Level: .3,
				cutoff: 600,
				resonance: .3,
				envAmount: .5,
				filterDecay: .12,
				filterSustain: .3,
				ampAttack: .002,
				ampDecay: .15,
				ampSustain: .5,
				ampRelease: .05,
				level: .7
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 1,
				lfGain: 2,
				midFreq: 3,
				midGain: 2,
				drive: 6
			}
		},
		chords: {
			type: "performance",
			steps: g("x.......x...x...", _([57, 8], [50, 4], [52, 4]), .95)
		},
		strings: {
			type: "aurora",
			params: {
				osc2Wave: 0,
				osc2Detune: 12,
				hpf: 200,
				cutoff: 3e3,
				envAmount: .15,
				filterAttack: .1,
				filterDecay: .8,
				filterSustain: .6,
				ampAttack: .08,
				ampDecay: .6,
				ampSustain: .8,
				ampRelease: 1.2,
				lfoRate: .5,
				lfoWidth: .2,
				chord: 2,
				vintage: .4,
				level: .7
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2,
				mix: .3
			}
		},
		drums: {
			type: "boom",
			params: {
				kickTune: 52,
				kickDecay: .5,
				snareTone: .55,
				snappy: .7,
				hatDecay: .04,
				openDecay: .25,
				level: .85
			},
			lanes: {
				kick: "x...x...x...x...",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "xx.xxx.xxx.xxx.x",
				open: "..x...x...x...x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .003,
				release: .1,
				color: 1,
				detectorHp: 1,
				output: 5
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: .75,
				c: 1,
				d: .45
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 1,
				attack: 4,
				release: 1,
				output: 2
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("performance", "monarch"),
		...S("octaves", "bass"),
		...S("chords", "strings"),
		...T([
			["drums", "talon"],
			["bass", "brit"],
			["strings", "space"],
			[
				"monarch",
				"console",
				"echo"
			]
		], "cohere")
	]) : e === "Boom Bap" ? x(e, 84, .18, {
		performance: {
			type: "performance",
			steps: g("X.....x.X..x..x.", _([50, 8], [55, 6], [50, 2]), [
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.4,
				.5,
				.95,
				.5,
				.5,
				.4,
				.5,
				.5,
				.6,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 1,
				osc1Octave: -1,
				osc1Level: .8,
				osc2Wave: 0,
				osc2Octave: -1,
				osc2Detune: 0,
				osc2Level: .3,
				osc3Wave: 0,
				osc3Octave: -2,
				osc3Level: .55,
				cutoff: 420,
				resonance: .1,
				drive: .3,
				envAmount: .25,
				tracking: .4,
				filterDecay: .3,
				filterSustain: .3,
				ampAttack: .006,
				ampDecay: .5,
				ampSustain: .75,
				ampRelease: .12,
				glide: .03,
				level: .8
			}
		},
		delay: {
			type: "delay",
			params: {
				time: v(84),
				feedback: .3,
				mix: .18
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 50,
				kickDecay: .55,
				snareTone: .4,
				snappy: .45,
				hatDecay: .05,
				level: .85
			},
			lanes: {
				kick: "x.....x...x..x..",
				snare: "....x.......x...",
				hat: "x.x.x.x.x.x.x.xx"
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .8,
				woodTune: 3,
				woodLevel: .4,
				shakerDecay: .08,
				shakerLevel: .5
			},
			euclid: {
				wood: [
					3,
					16,
					3
				],
				shaker: [
					8,
					16,
					1
				]
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 40,
				lfGain: 3,
				lfFreq: 80,
				lfBell: 1,
				lmfGain: -3,
				lmfFreq: 450,
				lmfQ: 1.2,
				hmfGain: 3.5,
				hmfFreq: 3e3,
				hmfQ: 1.2,
				lpf: 12e3
			}
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .1,
				brightness: .8,
				velocity: .75,
				lfoRate: 4.5,
				lfoDepth: .03,
				chord: 4,
				level: .7,
				...b.epiano
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 3,
				midFreq: 1,
				midGain: 2,
				hfGain: -6,
				drive: 10,
				output: 4
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .006,
				release: .15,
				color: 2,
				detectorHp: 1,
				output: 5
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: .5,
				c: .45,
				d: 1
			}
		},
		valve: {
			type: "compressor",
			params: {
				input: 1,
				threshold: -16,
				time: 1,
				output: 1
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("performance", "monarch"),
		...S("performance", "prism", 3),
		...T([
			[
				"boom",
				"console",
				"talon"
			],
			[
				"prism",
				"brit",
				"delay"
			],
			["monarch"],
			["orbit"]
		], "valve")
	]) : e === "Late Night Hip-Hop" ? x(e, 72, .24, {
		performance: {
			type: "performance",
			steps: g("X.....o.X....x..", _([41, 8], [39, 5], [46, 3]), [
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.95,
				.5,
				.5,
				.5,
				.5,
				.7,
				.5,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 1,
				osc1Level: .8,
				osc2Wave: 0,
				osc2Detune: 0,
				osc2Level: .3,
				osc3Wave: 0,
				osc3Level: .4,
				cutoff: 520,
				resonance: .1,
				drive: .12,
				envAmount: .3,
				filterDecay: .4,
				ampAttack: .008,
				ampDecay: .6,
				ampSustain: .8,
				ampRelease: .25,
				glide: .05,
				level: .8
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2,
				lfFreq: 80,
				lmfGain: -3,
				lmfFreq: 250,
				hmfGain: 3,
				hmfFreq: 1200,
				lpf: 8e3
			}
		},
		chords: {
			type: "performance",
			steps: g("x.......x.....o.", _([57, 8], [55, 8]), .95)
		},
		keys: {
			type: "aurora",
			params: {
				osc1Wave: 1,
				osc1Width: .3,
				osc2Wave: 2,
				osc2Octave: 1,
				blend: .4,
				cutoff: 1400,
				envAmount: .25,
				filterAttack: .01,
				filterDecay: 1.2,
				ampAttack: .06,
				ampDecay: 1.5,
				ampSustain: .6,
				ampRelease: 2,
				lfoWidth: .35,
				lfoFilter: .05,
				chord: 2,
				vintage: .5,
				level: .6
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 3,
				midFreq: 0,
				midGain: -3,
				hfGain: -5,
				drive: 8,
				output: 3
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2.4,
				mix: .3
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 47,
				kickDecay: .7,
				snareTone: .3,
				snappy: .35,
				hatDecay: .04,
				openDecay: .3,
				level: .85
			},
			lanes: {
				kick: "x......x..x.....",
				snare: "....x.......x...",
				rim: "..............x.",
				hat: "..x...x...x...x."
			}
		},
		orbit: {
			type: "orbit",
			params: {
				pitch: -4,
				level: .8,
				shakerLevel: .5
			},
			euclid: { shaker: [
				6,
				16,
				2
			] }
		},
		talon: {
			type: "talon",
			params: {
				input: 4,
				ratio: 5,
				attack: .01,
				release: .4,
				color: 1,
				output: 9
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: .6,
				c: .55,
				d: 1
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 25,
				lpf: 9e3,
				lfGain: 1.5,
				lfFreq: 120,
				lfBell: 1,
				hfGain: -2,
				hfFreq: 6e3
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -18,
				ratio: 0,
				attack: 4,
				release: 4,
				output: 3
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("performance", "monarch"),
		...S("chords", "keys"),
		...T([
			["boom", "talon"],
			["monarch", "bassEq"],
			[
				"keys",
				"brit",
				"space"
			],
			["orbit"]
		], "console", "cohere")
	]) : e === "Roots Reggae" ? x(e, 76, .2, {
		performance: {
			type: "performance",
			steps: g("..X...x.X..x.xx.", [
				33,
				33,
				33,
				33,
				33,
				33,
				36,
				36,
				38,
				38,
				38,
				38,
				38,
				41,
				40,
				40
			], [
				.65,
				.65,
				.85,
				.65,
				.65,
				.65,
				.5,
				.65,
				.85,
				.65,
				.65,
				.45,
				.65,
				.5,
				.85,
				.65
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 1,
				osc1Level: .7,
				osc2Wave: 0,
				osc2Octave: 1,
				osc2Detune: 0,
				osc2Level: .15,
				osc3Wave: 0,
				osc3Octave: 0,
				osc3Level: .5,
				cutoff: 520,
				resonance: .05,
				drive: .15,
				envAmount: .15,
				filterDecay: .3,
				ampAttack: .006,
				ampDecay: .35,
				ampSustain: .7,
				ampRelease: .12,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 3,
				midFreq: 0,
				midGain: -3,
				hfGain: -4,
				drive: 4
			}
		},
		bubble: {
			type: "performance",
			steps: g("..xx..xx..xx..xx", _([57, 8], [50, 8]), .6)
		},
		organ: {
			type: "aurora",
			params: {
				osc1Wave: 1,
				osc2Wave: 3,
				osc2Octave: 1,
				osc2Detune: 0,
				blend: .5,
				cutoff: 2600,
				resonance: 0,
				slope: 0,
				envAmount: 0,
				ampAttack: .003,
				ampDecay: .2,
				ampSustain: .85,
				ampRelease: .04,
				lfoRate: 6,
				lfoPitch: .01,
				lfoWidth: 0,
				chord: 2,
				vintage: .2,
				level: .45
			}
		},
		skank: {
			type: "performance",
			steps: g("....X.......X...", _([69, 8], [62, 8]), .35)
		},
		guitar: {
			type: "oracle",
			params: {
				bShape: 2,
				bFine: 5,
				cutoff: 2800,
				resonance: .2,
				envAmount: .3,
				filterDecay: .12,
				filterSustain: 0,
				ampAttack: .002,
				ampDecay: .14,
				ampSustain: 0,
				ampRelease: .08,
				chord: 2,
				level: 1
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 250,
				lmfGain: -3,
				lmfFreq: 500,
				lmfQ: 1.2,
				hmfGain: 3.5,
				hmfFreq: 2200,
				hmfQ: 1.4,
				lpf: 9e3
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(76),
				feedback: .4,
				mix: .3
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 1.6,
				mix: .22
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 46,
				kickDecay: .6,
				snareTone: .5,
				hatDecay: .05,
				openDecay: .35,
				level: .85
			},
			lanes: {
				kick: "........x.......",
				rim: "........x.......",
				hat: "x.x.x...x.x.x..x",
				open: "......x.......x."
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .8,
				metalDecay: .09,
				metalTone: .7,
				metalLevel: .5,
				sandDecay: .06,
				sandLevel: .55
			},
			euclid: {
				metal: [
					2,
					16,
					4
				],
				sand: [
					2,
					16,
					4
				]
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 1,
				ratio: 2,
				attack: .01,
				release: .25,
				color: 1,
				output: 6
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: 1,
				c: .8,
				d: .7,
				e: .9
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 0,
				attack: 4,
				release: 4,
				output: 2
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("performance", "monarch"),
		...S("bubble", "organ"),
		...S("skank", "guitar"),
		...T([
			["boom", "talon"],
			["orbit"],
			["monarch", "brit"],
			["organ"],
			[
				"guitar",
				"console",
				"echo",
				"space"
			]
		], "cohere")
	]) : e === "Dub Session" ? x(e, 70, .18, {
		performance: {
			type: "performance",
			steps: g("X..x..x.X..x..x.", [
				28,
				28,
				28,
				28,
				28,
				28,
				31,
				31,
				33,
				33,
				33,
				31,
				31,
				31,
				26,
				26
			], [
				.85,
				.5,
				.5,
				.4,
				.5,
				.5,
				.6,
				.5,
				.85,
				.5,
				.5,
				.5,
				.5,
				.5,
				.7,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 0,
				osc1Level: .7,
				osc2Wave: 1,
				osc2Octave: 1,
				osc2Detune: 0,
				osc2Level: .12,
				osc3Wave: 0,
				osc3Octave: 0,
				osc3Level: .45,
				cutoff: 300,
				resonance: .1,
				drive: .25,
				envAmount: .1,
				ampAttack: .01,
				ampDecay: .4,
				ampSustain: .8,
				ampRelease: .2,
				glide: .02,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 3,
				midFreq: 0,
				midGain: -3,
				hfGain: -8,
				drive: 6
			}
		},
		skank: {
			type: "performance",
			steps: g("....x.......x...", _([64, 16]), .3)
		},
		guitar: {
			type: "oracle",
			params: {
				bShape: 2,
				bFine: 5,
				cutoff: 2400,
				resonance: .2,
				envAmount: .3,
				filterDecay: .12,
				filterSustain: 0,
				ampAttack: .002,
				ampDecay: .15,
				ampSustain: 0,
				ampRelease: .1,
				chord: 2,
				level: 1
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 220,
				lmfGain: -3,
				lmfFreq: 450,
				hmfGain: 3,
				hmfFreq: 1800,
				lpf: 6e3
			}
		},
		repeats: {
			type: "delay",
			params: {
				time: Number((60 / 70).toFixed(3)),
				feedback: .6,
				mix: .4
			}
		},
		melody: {
			type: "performance",
			steps: g("X.....X.X.X...X.", [
				71,
				71,
				71,
				71,
				71,
				71,
				74,
				74,
				71,
				71,
				69,
				69,
				69,
				69,
				67,
				67
			], .95)
		},
		melodica: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: 0,
				brightness: .9,
				velocity: .5,
				lfoRate: 5,
				lfoDepth: .12,
				level: 1,
				...b.reed
			}
		},
		hall: {
			type: "reverb",
			params: {
				decay: 2.2,
				mix: .3
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 45,
				kickDecay: 1.2,
				snareTone: .35,
				snappy: .5,
				hatDecay: .06,
				openDecay: .5,
				level: .8
			},
			lanes: {
				kick: "x..x......x.....",
				snare: "....x.......x...",
				rim: ".......x........",
				hat: "x.x.x.x.x.x.x...",
				open: "..............x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 3,
				ratio: 2,
				attack: .003,
				release: .2,
				color: 2,
				output: 8
			}
		},
		reverb: {
			type: "reverb",
			params: {
				decay: 1.4,
				mix: .2
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .9,
				skinTune: 5,
				skinDecay: .25,
				skinLevel: 1,
				woodLevel: .5
			},
			euclid: {
				skin: [
					1,
					16,
					12
				],
				wood: [
					2,
					16,
					6
				]
			}
		},
		delay: {
			type: "delay",
			params: {
				time: v(70),
				feedback: .55,
				mix: .45
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: 1,
				c: .7,
				d: 1,
				e: 1
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 0,
				attack: 4,
				release: 4,
				output: 2
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("performance", "monarch"),
		...S("skank", "guitar"),
		...S("melody", "melodica"),
		...T([
			[
				"boom",
				"talon",
				"reverb"
			],
			["orbit", "delay"],
			["monarch", "brit"],
			[
				"guitar",
				"console",
				"repeats"
			],
			["melodica", "hall"]
		], "cohere")
	]) : e === "Trap Soul" ? x(e, 68, .06, {
		performance: {
			type: "performance",
			steps: g("X.......X.....x.", _([53, 8], [58, 8]), [
				.95,
				.65,
				.65,
				.65,
				.65,
				.65,
				.65,
				.65,
				.95,
				.65,
				.65,
				.65,
				.65,
				.65,
				.6,
				.65
			])
		},
		oracle: {
			type: "oracle",
			params: {
				aLevel: .7,
				bLevel: .6,
				bFine: 6,
				noise: .03,
				cutoff: 1300,
				resonance: .12,
				envAmount: .3,
				tracking: .4,
				filterAttack: .005,
				filterDecay: .9,
				filterSustain: .25,
				filterRelease: 1.6,
				ampAttack: .01,
				ampDecay: 1.2,
				ampSustain: .6,
				ampRelease: 2.4,
				lfoRate: .35,
				lfoAmount: .12,
				lfoDest: 2,
				vintage: .45,
				chord: 4,
				level: 1
			}
		},
		equalizer: {
			type: "equalizer",
			params: {
				hpf: 140,
				lmfGain: -3,
				lmfFreq: 380,
				lmfQ: 1.2,
				hmfGain: 2,
				hmfFreq: 2800,
				hmfQ: .8,
				hfGain: 3,
				hfFreq: 9e3,
				lpf: 16e3,
				output: 4
			}
		},
		reverb: {
			type: "reverb",
			params: {
				decay: 2.6,
				mix: .3
			}
		},
		performance2: {
			type: "performance",
			steps: g("X.....x.X..x..x.", [
				53,
				53,
				53,
				53,
				53,
				53,
				53,
				53,
				58,
				58,
				58,
				56,
				56,
				56,
				60,
				60
			], [
				.95,
				.65,
				.65,
				.65,
				.65,
				.65,
				.6,
				.65,
				.95,
				.65,
				.65,
				.5,
				.65,
				.65,
				.5,
				.65
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 0,
				osc1Octave: -2,
				osc1Level: .8,
				osc2Wave: 1,
				osc2Octave: -1,
				osc2Detune: 0,
				osc2Level: .12,
				osc3Level: 0,
				cutoff: 700,
				resonance: 0,
				drive: .55,
				envAmount: .1,
				tracking: .3,
				ampAttack: .003,
				ampDecay: .8,
				ampSustain: .75,
				ampRelease: 1.1,
				glide: .07,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 2,
				midFreq: 1,
				midGain: 4,
				drive: 12,
				output: -2
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 52,
				kickDecay: .32,
				snareTone: .65,
				snappy: .8,
				hatDecay: .035,
				openDecay: .3,
				level: .8
			},
			lanes: {
				kick: "x.....x.x.....x.",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "x.x.x.xxx.x.x.xx",
				open: "...........x...."
			}
		},
		compressor: {
			type: "compressor",
			params: {
				input: 3,
				threshold: -26,
				time: 1,
				output: 8
			}
		},
		bells: {
			type: "performance",
			steps: g("..X...X...X..X..", [
				84,
				84,
				84,
				84,
				84,
				84,
				80,
				80,
				80,
				80,
				82,
				82,
				82,
				77,
				77,
				77
			], .5)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .05,
				brightness: 1,
				velocity: .6,
				level: 1,
				...b.bell
			}
		},
		delay: {
			type: "delay",
			params: {
				time: v(68),
				feedback: .4,
				mix: .3
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: .55,
				c: 1,
				d: 1
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -18,
				ratio: 0,
				attack: 4,
				release: 4,
				scHpf: 2,
				output: 2
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("performance", "oracle"),
		...S("performance2", "monarch"),
		...S("bells", "prism"),
		...T([
			[
				"oracle",
				"equalizer",
				"reverb"
			],
			["monarch", "brit"],
			["boom", "compressor"],
			["prism", "delay"]
		], "cohere")
	]) : e === "Broken Beat" ? x(e, 108, .1, {
		performance: {
			type: "performance",
			steps: g("X..x..x...x..x.x", [
				36,
				36,
				36,
				48,
				48,
				48,
				34,
				34,
				34,
				34,
				41,
				41,
				41,
				44,
				44,
				43
			], .4)
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Wave: 3,
				osc2Detune: 5,
				osc2Level: .35,
				osc3Wave: 0,
				osc3Level: .45,
				cutoff: 700,
				resonance: .35,
				drive: .3,
				envAmount: .55,
				filterDecay: .14,
				filterSustain: .15,
				ampAttack: .003,
				ampDecay: .2,
				ampSustain: .4,
				ampRelease: .06,
				level: .7
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 2,
				lfGain: 2,
				midFreq: 2,
				midGain: 3,
				drive: 8
			}
		},
		stabs: {
			type: "performance",
			steps: g("X..x...x..x..x..", _([48, 7], [53, 9]), .4)
		},
		keys: {
			type: "oracle",
			params: {
				aShape: 2,
				bFine: 8,
				cutoff: 1800,
				resonance: .15,
				envAmount: .45,
				filterDecay: .25,
				filterSustain: .2,
				ampAttack: .003,
				ampDecay: .35,
				ampSustain: .3,
				ampRelease: .25,
				chord: 4,
				vintage: .4,
				level: .9
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 160,
				lmfGain: -2.5,
				lmfFreq: 350,
				hmfGain: 3,
				hmfFreq: 2800,
				hfGain: 2,
				hfFreq: 9e3
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(108),
				feedback: .3,
				mix: .2
			}
		},
		punch: {
			type: "punch",
			params: {
				kickTune: 54,
				kickClick: .55,
				kickDecay: .4,
				snareTone: .55,
				snappy: .65,
				hatDecay: .04,
				openDecay: .2,
				level: .85
			},
			lanes: {
				kick: "x.....x..x...x..",
				snare: "....x.......x...",
				clap: "....x..........x",
				hat: "x.xxx.x.x.xxx.x.",
				open: ".....x.......x.."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .004,
				release: .12,
				color: 2,
				detectorHp: 1,
				output: 5
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .5,
				skinTune: 5,
				tomTune: 7,
				sandLevel: .6
			},
			euclid: {
				skin: [3, 8],
				tom: [
					2,
					16,
					3
				],
				sand: [5, 12]
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: .5,
				c: .85,
				d: .8
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 1,
				attack: 4,
				release: 1,
				output: 2
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("performance", "monarch"),
		...S("stabs", "keys"),
		...T([
			["punch", "talon"],
			["orbit"],
			["monarch", "brit"],
			[
				"keys",
				"console",
				"echo"
			]
		], "cohere")
	]) : x(e, 96, .08, {
		performance: {
			type: "performance",
			steps: g("X..X..X.X..X..X.", [
				62,
				62,
				62,
				65,
				65,
				65,
				69,
				69,
				67,
				67,
				67,
				72,
				72,
				72,
				69,
				69
			], .5)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: 0,
				brightness: .9,
				velocity: .6,
				level: 1,
				...b.kalimba
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 180,
				lmfGain: -2,
				lmfFreq: 400,
				hmfGain: 2.5,
				hmfFreq: 3500,
				hfGain: 3,
				hfFreq: 1e4
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(96),
				feedback: .35,
				mix: .25
			}
		},
		bass: {
			type: "performance",
			steps: g("X......o..x.....", _([38, 10], [36, 6]), [
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.6,
				.5,
				.5,
				.95,
				.5,
				.5,
				.5,
				.5,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 0,
				osc1Level: .8,
				osc2Wave: 1,
				osc2Detune: 0,
				osc2Level: .2,
				osc3Level: 0,
				cutoff: 300,
				resonance: 0,
				drive: .2,
				envAmount: .1,
				ampAttack: .006,
				ampDecay: .6,
				ampSustain: .8,
				ampRelease: .2,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 2,
				midFreq: 1,
				midGain: 4,
				drive: 10
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 44,
				kickDecay: .9,
				level: .85
			},
			lanes: { kick: "x.......x......." }
		},
		talon: {
			type: "talon",
			params: {
				input: 3,
				ratio: 4,
				attack: .002,
				release: .2,
				color: 2,
				output: 4
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .65,
				woodLevel: .5,
				metalLevel: .35,
				shakerLevel: .45
			},
			euclid: {
				skin: [
					5,
					16,
					2
				],
				wood: [
					3,
					8,
					2
				],
				sand: [7, 12],
				metal: [2, 15],
				shaker: [
					9,
					16,
					2
				],
				tom: [
					3,
					14,
					1
				]
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .75,
				b: .8,
				c: 1,
				d: .6
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -18,
				ratio: 0,
				attack: 4,
				release: 4,
				output: 2
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("performance", "prism"),
		...S("bass", "monarch"),
		...T([
			["boom", "talon"],
			["orbit"],
			[
				"prism",
				"console",
				"echo"
			],
			["monarch", "brit"]
		], "cohere")
	]);
}
//#endregion
//#region src/retroPresets.ts
var D = (...e) => w(e, "mixer", "cohere", "main"), O = {
	cohere: {
		type: "cohere",
		params: {
			threshold: -16,
			ratio: 0,
			attack: 4,
			release: 4,
			scHpf: 2,
			output: 2
		}
	},
	main: {
		type: "output",
		params: { volume: .7 }
	}
};
function ee(e) {
	return e === "Neon Skyline" ? x(e, 112, 0, {
		pads: {
			type: "performance",
			steps: g("X.......X.......", _([57, 8], [52, 8]), .95)
		},
		aurora: {
			type: "aurora",
			params: {
				osc2Wave: 0,
				osc2Detune: 12,
				hpf: 150,
				cutoff: 2400,
				envAmount: .2,
				filterAttack: .1,
				filterDecay: 1.5,
				filterSustain: .5,
				ampAttack: .08,
				ampDecay: 1,
				ampSustain: .8,
				ampRelease: 2.2,
				lfoRate: .4,
				lfoWidth: .3,
				chord: 2,
				vintage: .5,
				level: .8
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 180,
				lmfGain: -3,
				lmfFreq: 400,
				lmfQ: 1,
				hmfGain: 2,
				hmfFreq: 3e3,
				hmfQ: .8,
				hfGain: 3,
				hfFreq: 12e3
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2.6,
				mix: .35
			}
		},
		bass: {
			type: "performance",
			steps: g("X.x.X.x.X.x.X.x.", _([41, 8], [36, 8]), .55)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .2,
				brightness: 1,
				velocity: .6,
				level: 1,
				...b.bass
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 2,
				midFreq: 2,
				midGain: 2,
				hfGain: 1,
				drive: 8,
				output: 8
			}
		},
		arp: {
			type: "performance",
			steps: g("XxxxXxxxXxxxXxxx", [
				69,
				72,
				76,
				79,
				81,
				79,
				76,
				72,
				67,
				72,
				76,
				79,
				84,
				79,
				76,
				72
			], .5)
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 3,
				osc1Level: .7,
				osc2Detune: 5,
				osc2Level: .4,
				osc3Level: 0,
				cutoff: 2200,
				resonance: .3,
				envAmount: .4,
				filterDecay: .12,
				filterSustain: .1,
				ampAttack: .002,
				ampDecay: .18,
				ampSustain: .2,
				ampRelease: .12,
				level: .55
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(112),
				feedback: .35,
				mix: .3
			}
		},
		strike: {
			type: "strike",
			params: {
				level: 1,
				kickDecay: .4,
				snareTune: -2,
				snareDecay: .3,
				clapLevel: .5,
				hatLevel: .4,
				hatPan: .2,
				tambourineLevel: .3,
				tambourinePan: -.3
			},
			lanes: {
				kick: "x...x...x...x...",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "x.x.x.x.x.x.x.x.",
				tambourine: "....x.......x..."
			}
		},
		room: {
			type: "reverb",
			params: {
				decay: 1.2,
				mix: .3
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 0,
				ratio: 7,
				attack: 2e-4,
				release: .08,
				color: 2,
				output: 12
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: .75,
				c: .6,
				d: .45
			}
		},
		...O
	}, [
		...S("pads", "aurora"),
		...S("bass", "prism"),
		...S("arp", "monarch"),
		...D([
			"strike",
			"room",
			"talon"
		], ["prism", "brit"], [
			"aurora",
			"console",
			"space"
		], ["monarch", "echo"])
	]) : e === "Digital Boogie" ? x(e, 116, .12, {
		bass: {
			type: "performance",
			steps: g("X..x..x.X.xx..x.", [
				40,
				40,
				40,
				52,
				52,
				52,
				40,
				40,
				45,
				45,
				45,
				57,
				57,
				57,
				43,
				43
			], [
				.6,
				.5,
				.5,
				.3,
				.5,
				.5,
				.6,
				.5,
				.6,
				.5,
				.5,
				.3,
				.5,
				.5,
				.6,
				.5
			])
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .3,
				brightness: 1.1,
				velocity: .8,
				level: 1,
				...b.slap
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 2,
				lfGain: 2,
				midFreq: 3,
				midGain: 3,
				drive: 6,
				output: 8
			}
		},
		stabs: {
			type: "performance",
			steps: g("..X..x....X..x..", _([52, 8], [57, 8]), .6)
		},
		aurora: {
			type: "aurora",
			params: {
				osc2Detune: 8,
				cutoff: 2600,
				envAmount: .4,
				filterDecay: .2,
				filterSustain: .2,
				ampAttack: .003,
				ampDecay: .3,
				ampSustain: .2,
				ampRelease: .2,
				lfoWidth: .2,
				chord: 4,
				vintage: .35,
				level: .6
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 150,
				lmfGain: -2.5,
				lmfFreq: 350,
				lmfQ: 1,
				hmfGain: 3,
				hmfFreq: 2500,
				hmfQ: 1,
				hfGain: 2,
				hfFreq: 1e4
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 1.2,
				mix: .2
			}
		},
		strike: {
			type: "strike",
			params: {
				level: 1,
				kickDecay: .35,
				snareDecay: .25,
				clapLevel: .6,
				hatDecay: .05,
				hatLevel: .35,
				hatPan: .2,
				bellLevel: .35,
				bellPan: -.25
			},
			lanes: {
				kick: "x.....x.x.....x.",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "x".repeat(16),
				bell: "......x.......x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .003,
				release: .1,
				color: 1,
				detectorHp: 1,
				output: 9
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: .75,
				c: .75
			}
		},
		...O
	}, [
		...S("bass", "prism"),
		...S("stabs", "aurora"),
		...D(["strike", "talon"], ["prism", "brit"], [
			"aurora",
			"console",
			"space"
		])
	]) : e === "Midnight Ballad" ? x(e, 76, .04, {
		keys: {
			type: "performance",
			steps: g("X.....x.X.....x.", _([58, 8], [51, 8]), .9)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .08,
				brightness: .75,
				velocity: .75,
				lfoRate: 4.5,
				lfoDepth: .04,
				chord: 3,
				level: .7,
				...b.epiano
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 100,
				lmfGain: -2,
				lmfFreq: 300,
				lmfQ: 1,
				hmfGain: 2.5,
				hmfFreq: 1800,
				hmfQ: 1,
				hfGain: 1.5,
				hfFreq: 1e4
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(76),
				feedback: .25,
				mix: .15
			}
		},
		strings: {
			type: "performance",
			steps: g("X.......X.......", _([58, 8], [63, 8]), .95)
		},
		aurora: {
			type: "aurora",
			params: {
				osc1Wave: 0,
				osc2Wave: 0,
				osc2Detune: 10,
				hpf: 250,
				cutoff: 2200,
				envAmount: .15,
				filterAttack: .15,
				filterDecay: 1.5,
				filterSustain: .6,
				ampAttack: .12,
				ampDecay: 1.2,
				ampSustain: .8,
				ampRelease: 2.8,
				lfoRate: .3,
				lfoWidth: .3,
				chord: 1,
				vintage: .45,
				level: .8
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2.8,
				mix: .4
			}
		},
		bass: {
			type: "performance",
			steps: g("X.....x.X.....x.", _([34, 6], [41, 2], [39, 6], [46, 2]), [
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.8,
				.5,
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.8,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 1,
				osc1Level: .8,
				osc2Wave: 0,
				osc2Detune: 0,
				osc2Level: .3,
				osc3Wave: 0,
				osc3Level: .3,
				cutoff: 700,
				resonance: .15,
				drive: .15,
				envAmount: .25,
				filterDecay: .5,
				filterSustain: .4,
				ampAttack: .01,
				ampDecay: .8,
				ampSustain: .7,
				ampRelease: .3,
				glide: .08,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 2,
				midFreq: 1,
				midGain: 2,
				hfGain: -3,
				drive: 4
			}
		},
		strike: {
			type: "strike",
			params: {
				level: .9,
				kickDecay: .45,
				snareTune: -3,
				snareDecay: .5,
				hatLevel: .35,
				hatPan: .2,
				rideLevel: .3,
				ridePan: -.2
			},
			lanes: {
				kick: "x.......x..x....",
				snare: "....x.......x...",
				hat: "x...x...x...x...",
				ride: "..x...x...x...x."
			}
		},
		room: {
			type: "reverb",
			params: {
				decay: 1.6,
				mix: .35
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 0,
				ratio: 6,
				attack: 5e-4,
				release: .12,
				color: 1,
				output: 8
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .75,
				b: 1,
				c: .55,
				d: .4
			}
		},
		...O
	}, [
		...S("keys", "prism"),
		...S("strings", "aurora"),
		...S("bass", "monarch"),
		...D([
			"strike",
			"room",
			"talon"
		], [
			"prism",
			"console",
			"echo"
		], ["aurora", "space"], ["monarch", "brit"])
	]) : e === "New Wave Motion" ? x(e, 132, 0, {
		bass: {
			type: "performance",
			steps: g("X.x.x.x.X.x.x.x.", [
				38,
				38,
				38,
				38,
				38,
				38,
				50,
				50,
				34,
				34,
				34,
				34,
				34,
				34,
				46,
				46
			], .6)
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Detune: 7,
				osc2Level: .5,
				osc3Wave: 3,
				osc3Level: .35,
				cutoff: 900,
				resonance: .3,
				drive: .35,
				envAmount: .45,
				filterDecay: .15,
				filterSustain: .3,
				ampAttack: .002,
				ampDecay: .15,
				ampSustain: .6,
				ampRelease: .05,
				level: .7
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 2,
				lfGain: 2,
				midFreq: 2,
				midGain: 4,
				hfGain: 2,
				drive: 10
			}
		},
		pad: {
			type: "performance",
			steps: g("x.......x.......", _([50, 16]), .95)
		},
		aurora: {
			type: "aurora",
			params: {
				osc1Wave: 1,
				osc1Width: .35,
				osc2Wave: 0,
				osc2Detune: 9,
				hpf: 180,
				cutoff: 2600,
				envAmount: .2,
				filterAttack: .15,
				filterDecay: 1,
				filterSustain: .5,
				ampAttack: .06,
				ampDecay: .8,
				ampSustain: .75,
				ampRelease: 1.6,
				lfoRate: .7,
				lfoWidth: .45,
				chord: 2,
				vintage: .35,
				level: .7
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 1.8,
				mix: .25
			}
		},
		hook: {
			type: "performance",
			steps: g("X..X..X...X..X..", [
				81,
				81,
				81,
				77,
				77,
				77,
				74,
				74,
				74,
				74,
				76,
				76,
				76,
				77,
				77,
				77
			], .6)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .05,
				brightness: 1.1,
				velocity: .6,
				level: 1,
				...b.bell
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(132),
				feedback: .35,
				mix: .25
			}
		},
		strike: {
			type: "strike",
			params: {
				level: 1,
				kickDecay: .35,
				snareDecay: .3,
				hatDecay: .05,
				hatLevel: .4,
				hatPan: .2,
				midTomPan: .3,
				lowTomPan: -.3
			},
			lanes: {
				kick: "x.......x.x.....",
				snare: "....x.......x...",
				hat: "x.x.x.x.x.x.x...",
				midTom: "..............x.",
				lowTom: "...............x"
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 35,
				lfGain: 3,
				lfFreq: 70,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 380,
				lmfQ: 1.2,
				hmfGain: 3,
				hmfFreq: 4500,
				hmfQ: 1,
				hfGain: 2,
				hfFreq: 1e4
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 4,
				attack: .002,
				release: .1,
				color: 2,
				detectorHp: 1,
				output: 10
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: .65,
				c: .55,
				d: .7
			}
		},
		...O
	}, [
		...S("bass", "monarch"),
		...S("pad", "aurora"),
		...S("hook", "prism"),
		...D([
			"strike",
			"console",
			"talon"
		], ["monarch", "brit"], ["aurora", "space"], ["prism", "echo"])
	]) : e === "Glass Arcade" ? x(e, 108, 0, {
		arp: {
			type: "performance",
			steps: g("XxxxXxxxXxxxXxxx", [
				72,
				76,
				79,
				83,
				84,
				83,
				79,
				76,
				69,
				72,
				76,
				79,
				81,
				79,
				76,
				72
			], .5)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: 0,
				brightness: 1.2,
				velocity: .6,
				level: 1,
				...b.bell,
				op1Decay: .6,
				op1Release: .4,
				op3Decay: .5,
				op3Release: .3
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(108),
				feedback: .4,
				mix: .3
			}
		},
		melody: {
			type: "performance",
			steps: g("X.x.x...X.x.xx..", [
				76,
				76,
				79,
				79,
				81,
				81,
				79,
				79,
				76,
				76,
				74,
				74,
				72,
				74,
				74,
				74
			], .75)
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 3,
				osc1Level: .8,
				osc2Wave: 3,
				osc2Detune: 6,
				osc2Level: .35,
				osc3Level: 0,
				cutoff: 3200,
				resonance: .15,
				envAmount: .2,
				filterDecay: .2,
				filterSustain: .6,
				ampAttack: .003,
				ampDecay: .2,
				ampSustain: .75,
				ampRelease: .1,
				glide: .02,
				level: .55
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 2,
				midFreq: 3,
				midGain: 3,
				hfGain: 2,
				drive: 4,
				output: 4
			}
		},
		bass: {
			type: "performance",
			steps: g("X.x.X.x.X.x.X.x.", [
				36,
				36,
				48,
				48,
				36,
				36,
				48,
				48,
				33,
				33,
				45,
				45,
				33,
				33,
				45,
				45
			], .55)
		},
		aurora: {
			type: "aurora",
			params: {
				osc1Wave: 1,
				osc1Width: .25,
				osc2Wave: 1,
				osc2Octave: -1,
				osc2Detune: 0,
				osc2Width: .5,
				blend: .4,
				cutoff: 1400,
				resonance: .2,
				envAmount: .4,
				filterDecay: .15,
				filterSustain: .2,
				ampAttack: .002,
				ampDecay: .2,
				ampSustain: .5,
				ampRelease: .06,
				lfoWidth: 0,
				level: 1
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 35,
				lfGain: 2,
				lfFreq: 90,
				lmfGain: -3,
				lmfFreq: 300,
				lmfQ: 1,
				hmfGain: 2,
				hmfFreq: 1200,
				hmfQ: 1,
				lpf: 8e3
			}
		},
		strike: {
			type: "strike",
			params: {
				level: 1,
				kickDecay: .3,
				snareDecay: .22,
				hatDecay: .04,
				hatLevel: .4,
				hatPan: .2,
				openLevel: .35,
				openPan: .2
			},
			lanes: {
				kick: "x.....x.x.......",
				snare: "....x.......x...",
				hat: "x.x.x.x.x.x.x...",
				open: "..............x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 3,
				ratio: 3,
				attack: 3e-4,
				release: .1,
				color: 0,
				detectorHp: 1,
				output: 10
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: 1,
				c: .3,
				d: .85
			}
		},
		...O
	}, [
		...S("arp", "prism"),
		...S("melody", "monarch"),
		...S("bass", "aurora"),
		...D(["strike", "talon"], ["prism", "echo"], ["monarch", "brit"], ["aurora", "console"])
	]) : x(e, 96, .06, {
		pads: {
			type: "performance",
			steps: g("X.......X.......", _([50, 8], [55, 8]), .95)
		},
		aurora: {
			type: "aurora",
			params: {
				osc1Wave: 0,
				osc2Wave: 2,
				osc2Octave: 1,
				osc2Detune: 6,
				blend: .4,
				hpf: 120,
				cutoff: 2e3,
				envAmount: .15,
				filterAttack: .12,
				filterDecay: 1.5,
				filterSustain: .6,
				ampAttack: .1,
				ampDecay: 1.2,
				ampSustain: .8,
				ampRelease: 2.4,
				lfoRate: .25,
				lfoWidth: .3,
				lfoFilter: .05,
				chord: 3,
				vintage: .4,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 2,
				midFreq: 0,
				midGain: -2,
				hfGain: 5,
				drive: 3
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2.8,
				mix: .35
			}
		},
		pluck: {
			type: "performance",
			steps: g("X.XX.X.XX.X.XX.X", [
				74,
				74,
				78,
				81,
				81,
				85,
				85,
				81,
				79,
				79,
				83,
				86,
				86,
				83,
				83,
				79
			], .5)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: 0,
				brightness: .9,
				velocity: .6,
				level: 1,
				...b.pluck,
				op1Level: 1
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 200,
				lmfGain: -2,
				lmfFreq: 450,
				lmfQ: 1,
				hmfGain: 2,
				hmfFreq: 3e3,
				hmfQ: .8,
				hfGain: 3,
				hfFreq: 12e3
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(96),
				feedback: .45,
				mix: .3
			}
		},
		bass: {
			type: "performance",
			steps: g("X.....x.X.....x.", _([38, 8], [43, 8]), [
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 0,
				osc1Level: .8,
				osc2Wave: 1,
				osc2Detune: 0,
				osc2Level: .25,
				osc3Level: 0,
				cutoff: 400,
				resonance: 0,
				drive: .1,
				envAmount: .1,
				ampAttack: .01,
				ampDecay: .6,
				ampSustain: .8,
				ampRelease: .3,
				glide: .04,
				level: .8
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .9,
				woodTune: 5,
				woodLevel: .45,
				sandLevel: .5,
				shakerDecay: .08,
				shakerLevel: .55
			},
			euclid: {
				wood: [3, 8],
				sand: [
					5,
					16,
					2
				],
				shaker: [
					8,
					16,
					1
				]
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .7,
				b: 1,
				c: .53,
				d: 1
			}
		},
		...O,
		cohere: {
			type: "cohere",
			params: {
				threshold: -14,
				ratio: 0,
				attack: 5,
				release: 4,
				output: 1
			}
		}
	}, [
		...S("pads", "aurora"),
		...S("pluck", "prism"),
		...S("bass", "monarch"),
		...D([
			"aurora",
			"brit",
			"space"
		], [
			"prism",
			"console",
			"echo"
		], ["monarch"], ["orbit"])
	]);
}
//#endregion
//#region src/studioPresets.ts
var te = (...e) => w(e, "sum", "cohere", "main");
function ne(e) {
	return e === "French Touch" ? x(e, 123, .08, {
		seq: {
			type: "performance",
			steps: g("X.xx.x.xX.x.X.xx", [
				33,
				33,
				45,
				33,
				33,
				43,
				43,
				45,
				38,
				38,
				50,
				38,
				48,
				48,
				45,
				43
			], .5)
		},
		stabs: {
			type: "performance",
			steps: g("..X..x.x..X..x..", _([57, 8], [62, 8]), .55)
		},
		bass: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Wave: 3,
				osc2Detune: 5,
				osc2Level: .45,
				osc3Wave: 3,
				osc3Level: .5,
				cutoff: 520,
				resonance: .35,
				drive: .35,
				envAmount: .55,
				tracking: .6,
				filterAttack: .003,
				filterDecay: .16,
				filterSustain: .12,
				filterRelease: .08,
				ampAttack: .003,
				ampDecay: .3,
				ampSustain: .7,
				ampRelease: .06,
				glide: .015,
				level: .75
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 2,
				lfGain: 2.5,
				midFreq: 1,
				midGain: 3,
				drive: 8,
				output: -2
			}
		},
		keys: {
			type: "aurora",
			params: {
				osc2Wave: 0,
				osc2Detune: 9,
				hpf: 180,
				cutoff: 2200,
				envAmount: .35,
				filterAttack: .002,
				filterDecay: .22,
				filterSustain: .2,
				ampAttack: .004,
				ampDecay: .35,
				ampSustain: .5,
				ampRelease: .22,
				lfoWidth: 0,
				chord: 4,
				vintage: .35,
				level: .75
			}
		},
		sieve: {
			type: "filter",
			params: {
				cutoff: 1100,
				resonance: 4.5
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 150,
				lmfGain: -3,
				lmfFreq: 350,
				lmfQ: 1,
				hmfGain: 3,
				hmfFreq: 2e3,
				hmfQ: 1,
				hfGain: 2,
				hfFreq: 1e4
			}
		},
		sweep: {
			type: "lfo",
			params: {
				wave: 1,
				rate: .12
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(123),
				feedback: .3,
				mix: .2
			}
		},
		drums: {
			type: "punch",
			params: {
				kickTune: 52,
				kickClick: .45,
				kickDecay: .5,
				snappy: .6,
				hatDecay: .04,
				openDecay: .28,
				level: .85
			},
			lanes: {
				kick: "x...x...x...x...",
				clap: "....x.......x...",
				hat: "...x...x...x...x",
				open: "..x...x...x...x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .008,
				release: .12,
				color: 1,
				detectorHp: 1,
				output: 5
			}
		},
		sum: {
			type: "mixer",
			params: {
				a: .8,
				b: .9,
				c: .55
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 1,
				attack: 4,
				release: 1,
				output: 3
			}
		},
		main: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("seq", "bass"),
		...S("stabs", "keys"),
		[
			"sweep",
			"out",
			"sieve",
			"cv",
			.8
		],
		...te(["drums", "talon"], [
			"keys",
			"sieve",
			"console",
			"echo"
		], ["bass", "brit"])
	]) : e === "Distortion Disco" ? x(e, 116, 0, {
		seq: {
			type: "performance",
			steps: g("Xx.xX.x.Xx.xX.xx", [
				28,
				40,
				40,
				28,
				38,
				38,
				40,
				40,
				31,
				43,
				43,
				31,
				33,
				33,
				35,
				38
			], .6)
		},
		stabs: {
			type: "performance",
			steps: g("..X....x..X..x..", _([64, 8], [57, 8]), .7)
		},
		bass: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Detune: 14,
				osc2Level: .6,
				osc3Wave: 3,
				osc3Octave: 1,
				osc3Level: .3,
				cutoff: 650,
				resonance: .25,
				drive: 1,
				envAmount: .5,
				tracking: .7,
				filterDecay: .2,
				filterSustain: .3,
				ampAttack: .002,
				ampDecay: .2,
				ampSustain: .8,
				ampRelease: .05,
				level: .7
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 2,
				lfGain: 3,
				midFreq: 1,
				midGain: 6,
				hfGain: -4,
				drive: 20,
				output: -2
			}
		},
		prophet: {
			type: "oracle",
			params: {
				bFine: 10,
				aLevel: .8,
				bLevel: .7,
				cutoff: 1400,
				resonance: .2,
				envAmount: .5,
				filterAttack: .005,
				filterDecay: .3,
				filterSustain: .3,
				filterRelease: .2,
				ampAttack: .004,
				ampDecay: .5,
				ampSustain: .55,
				ampRelease: .25,
				chord: 2,
				vintage: .45,
				level: .9
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 120,
				lmfGain: -3,
				lmfFreq: 400,
				lmfQ: 1,
				hmfGain: 3,
				hmfFreq: 2500,
				hmfQ: 1,
				hfGain: 1.5,
				hfFreq: 9e3,
				lpf: 14e3
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 1.4,
				mix: .18
			}
		},
		drums: {
			type: "strike",
			params: {
				level: .85,
				kickDecay: .35,
				kickLevel: 1,
				snareDecay: .25,
				snareLevel: .85,
				clapLevel: .6,
				hatDecay: .06,
				hatLevel: .5,
				hatPan: -.15,
				openLevel: .45,
				tambourineLevel: .4,
				tambourinePan: .25
			},
			lanes: {
				kick: "x...x...x...x...",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "x.x.x.x.x.x.x...",
				open: "..............x.",
				tambourine: "..x...x...x...x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 8,
				ratio: 6,
				attack: .001,
				release: .1,
				color: 2,
				fierce: 1,
				detectorHp: 1,
				output: 5
			}
		},
		sum: {
			type: "mixer",
			params: {
				a: 1,
				b: .9,
				c: .6
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -18,
				ratio: 2,
				attack: 3,
				release: 1,
				output: 4
			}
		},
		main: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("seq", "bass"),
		...S("stabs", "prophet"),
		...te(["drums", "talon"], [
			"prophet",
			"console",
			"space"
		], ["bass", "brit"])
	]) : e === "Electro Pogo" ? x(e, 128, 0, {
		seq: {
			type: "performance",
			steps: g(".xXx.xXx.xXx.xXx", [
				38,
				38,
				50,
				38,
				38,
				38,
				50,
				38,
				34,
				34,
				46,
				34,
				36,
				36,
				48,
				36
			], .6)
		},
		hook: {
			type: "performance",
			steps: g("X.x.xx.x.X.xX.x.", [
				69,
				69,
				74,
				74,
				77,
				76,
				76,
				74,
				74,
				77,
				77,
				74,
				76,
				76,
				79,
				79
			], .7)
		},
		bass: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Detune: 8,
				osc2Level: .5,
				osc3Wave: 3,
				osc3Level: .45,
				cutoff: 500,
				resonance: .4,
				drive: .55,
				envAmount: .6,
				filterDecay: .12,
				filterSustain: .15,
				ampDecay: .18,
				ampSustain: .6,
				ampRelease: .04,
				level: .7
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2,
				lfFreq: 70,
				lfBell: 1,
				lmfGain: -3,
				lmfFreq: 280,
				lmfQ: 1.2,
				hmfGain: 3,
				hmfFreq: 1200,
				hmfQ: 1.2,
				lpf: 9e3
			}
		},
		lead: {
			type: "oracle",
			params: {
				bOctave: 1,
				bFine: 6,
				bLevel: .5,
				cutoff: 2600,
				resonance: .3,
				envAmount: .35,
				filterDecay: .25,
				filterSustain: .4,
				ampAttack: .003,
				ampDecay: .3,
				ampSustain: .65,
				ampRelease: .15,
				glide: .035,
				level: 1
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 2,
				midFreq: 3,
				midGain: 4,
				hfGain: 4,
				drive: 6,
				output: 6
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(128),
				feedback: .32,
				mix: .22
			}
		},
		drums: {
			type: "punch",
			params: {
				kickTune: 50,
				kickClick: .7,
				kickDecay: .45,
				snareTone: .6,
				snappy: .8,
				hatDecay: .035,
				openDecay: .2,
				level: .85
			},
			lanes: {
				kick: "x...x...x...x...",
				snare: "....x.......x..x",
				clap: "....x.......x...",
				hat: "xx.xxx.xxx.xxx.x",
				open: "..x...x...x...x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .006,
				release: .09,
				color: 1,
				detectorHp: 1,
				output: 5
			}
		},
		sum: {
			type: "mixer",
			params: {
				a: .8,
				b: .8,
				c: .5
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -14,
				ratio: 1,
				attack: 5,
				release: 4,
				scHpf: 2,
				output: 2
			}
		},
		main: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("seq", "bass"),
		...S("hook", "lead"),
		...te(["drums", "talon"], [
			"lead",
			"brit",
			"echo"
		], ["bass", "console"])
	]) : x(e, 126, 0, {
		seq: {
			type: "performance",
			steps: g("XxxxXxxxXxxxXxxx", [
				36,
				48,
				36,
				48,
				36,
				48,
				36,
				48,
				32,
				44,
				32,
				44,
				34,
				46,
				34,
				46
			], .45)
		},
		hook: {
			type: "performance",
			steps: g("..X..x.x..X..x..", [
				75,
				75,
				75,
				75,
				75,
				74,
				74,
				72,
				72,
				72,
				75,
				75,
				75,
				74,
				74,
				74
			], .8)
		},
		bass: {
			type: "monarch",
			params: {
				osc1Wave: 3,
				osc1Level: .8,
				osc2Detune: -7,
				osc2Level: .5,
				osc3Wave: 3,
				osc3Level: .35,
				cutoff: 420,
				resonance: .75,
				drive: .6,
				envAmount: .7,
				tracking: .6,
				filterAttack: .002,
				filterDecay: .11,
				filterSustain: 0,
				filterRelease: .05,
				ampAttack: .002,
				ampDecay: .15,
				ampSustain: .5,
				ampRelease: .04,
				level: .7
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 35,
				lmfGain: -2.5,
				lmfFreq: 300,
				lmfQ: 1,
				hmfGain: 3.5,
				hmfFreq: 1500,
				hmfQ: 1.5,
				lpf: 11e3
			}
		},
		fm: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .35,
				brightness: 1,
				velocity: .7,
				lfoRate: 5.5,
				lfoDepth: .12,
				level: .55,
				...y([
					1,
					0,
					.9,
					.005,
					.8,
					.6,
					.25
				], [
					1,
					0,
					.55,
					.02,
					.4,
					.35,
					.2
				], [
					1,
					9,
					.8,
					.005,
					.8,
					.6,
					.25
				], [
					3,
					0,
					.25,
					.003,
					.25,
					.1,
					.15
				], [
					2,
					-6,
					.35,
					.005,
					.6,
					.4,
					.25
				], [
					1,
					0,
					.35,
					.003,
					.3,
					.15,
					.15
				])
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 2,
				midFreq: 1,
				midGain: 3,
				hfGain: 2,
				drive: 10,
				output: 12
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(126),
				feedback: .38,
				mix: .28
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2.2,
				mix: .22
			}
		},
		drums: {
			type: "boom",
			params: {
				kickTune: 48,
				kickDecay: .4,
				snareTone: .6,
				snappy: .75,
				hatDecay: .05,
				level: .85
			},
			lanes: {
				kick: "x...x...x...x...",
				snare: "....x.......x...",
				clap: "....x.......x...",
				rim: "...x.....x...x..",
				hat: "x.x.x.x.x.x.x.x.",
				bell: "..x..x....x..x.."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 4,
				attack: .003,
				release: .15,
				color: 2,
				fierce: 1,
				detectorHp: 1,
				output: 8
			}
		},
		sum: {
			type: "mixer",
			params: {
				a: .8,
				b: .8,
				c: .42
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 1,
				attack: 4,
				release: 1,
				scHpf: 2,
				output: 3
			}
		},
		main: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("seq", "bass"),
		...S("hook", "fm"),
		...te(["drums", "talon"], [
			"fm",
			"brit",
			"echo",
			"space"
		], ["bass", "console"])
	]);
}
//#endregion
//#region src/trapPresets.ts
var re = (e, t, n) => ({
	performance: {
		type: "performance",
		steps: e
	},
	oscillator: {
		type: "oscillator",
		params: {
			wave: n.wave,
			octave: n.octave,
			level: 1
		}
	},
	filter: {
		type: "filter",
		params: {
			cutoff: n.cutoff,
			resonance: n.resonance
		}
	},
	amplifier: {
		type: "amplifier",
		params: { level: .8 }
	},
	envelope: {
		type: "envelope",
		params: {
			attack: n.attack,
			decay: n.decay,
			sustain: n.sustain,
			release: n.release
		}
	},
	delay: {
		type: "delay",
		params: {
			time: v(t),
			feedback: .38,
			mix: n.echo
		}
	},
	space: {
		type: "reverb",
		params: {
			decay: 2.6,
			mix: n.space
		}
	}
}), ie = [
	[
		"oscillator",
		"out",
		"filter",
		"in"
	],
	[
		"filter",
		"out",
		"amplifier",
		"in"
	],
	[
		"amplifier",
		"out",
		"delay",
		"in"
	],
	[
		"delay",
		"out",
		"space",
		"in"
	],
	[
		"performance",
		"pitch",
		"oscillator",
		"pitch"
	],
	[
		"performance",
		"gate",
		"envelope",
		"gate"
	],
	[
		"envelope",
		"out",
		"amplifier",
		"cv",
		1
	]
], ae = (e) => ({
	type: "monarch",
	params: {
		osc1Wave: 0,
		osc1Octave: 0,
		osc1Level: .9,
		osc2Wave: 1,
		osc2Octave: 1,
		osc2Detune: 0,
		osc2Level: .08,
		osc3Level: 0,
		cutoff: 700,
		resonance: 0,
		drive: .45,
		envAmount: .1,
		tracking: .3,
		ampAttack: .003,
		ampDecay: 1.2,
		ampSustain: .7,
		ampRelease: .9,
		glide: .06,
		level: .4,
		...e
	}
}), oe = (e, t, n = {}) => ({
	type: "skitter",
	lanes: e,
	params: {
		...n,
		...Object.fromEntries(Object.entries(t).flatMap(([e, t]) => Object.entries(t).map(([t, n]) => [`${e}Roll${t}`, h(n)])))
	}
}), se = (e, t) => ({
	type: "boom",
	lanes: e,
	params: {
		kickTune: 49,
		kickDecay: .55,
		snareTone: .35,
		snappy: .55,
		hatDecay: .045,
		openDecay: .35,
		level: .85,
		...t
	}
}), k = {
	cohere: {
		type: "cohere",
		params: {
			threshold: -18,
			ratio: 1,
			attack: 4,
			release: 4,
			scHpf: 2,
			output: 4
		}
	},
	output: {
		type: "output",
		params: { volume: .7 }
	}
};
function ce(e) {
	return e === "High Dive" ? x(e, 76, 0, {
		...re(g("X.x.x..x..x.x...", [
			76,
			76,
			74,
			74,
			72,
			72,
			72,
			69,
			69,
			69,
			72,
			72,
			76,
			76,
			76,
			76
		], [
			.6,
			.6,
			.6,
			.6,
			.8,
			.8,
			.8,
			.9,
			.9,
			.9,
			.6,
			.6,
			.9,
			.9,
			.9,
			.9
		]), 76, {
			wave: 1,
			octave: 0,
			cutoff: 2600,
			resonance: 2,
			attack: .002,
			decay: .5,
			sustain: .15,
			release: .45,
			echo: .3,
			space: .35
		}),
		chords: {
			type: "performance",
			steps: g("X.......X.......", _([60, 8], [53, 8]), .95)
		},
		aurora: {
			type: "aurora",
			params: {
				osc1Wave: 0,
				osc2Wave: 2,
				osc2Detune: 4,
				blend: .45,
				hpf: 220,
				cutoff: 1800,
				resonance: .1,
				envAmount: .15,
				filterAttack: .2,
				filterDecay: 1.4,
				filterSustain: .5,
				ampAttack: .25,
				ampDecay: 1.2,
				ampSustain: .75,
				ampRelease: 1.8,
				lfoRate: .3,
				lfoPitch: 0,
				lfoWidth: .2,
				chord: 1,
				vintage: .3,
				level: .5
			}
		},
		bass: {
			type: "performance",
			steps: g("X.....x...X.....", _([33, 8], [29, 8]), [
				.95,
				.6,
				.6,
				.6,
				.6,
				.6,
				.7,
				.6,
				.6,
				.6,
				.95,
				.6,
				.6,
				.6,
				.6,
				.6
			])
		},
		monarch: ae({ level: .32 }),
		skitter: oe({
			hat: "x.x.x.x.x.x.xx.x",
			open: "..............x."
		}, { hat: { 2: "............xx.x" } }),
		boom: se({
			kick: "x.....x...x.....",
			snare: "....x.......x...",
			clap: "....x.......x..."
		}, {
			kickDecay: .45,
			snareTone: .5,
			snappy: .7
		}),
		console: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2.5,
				lfFreq: 60,
				lfBell: 1,
				lmfGain: -3.5,
				lmfFreq: 400,
				lmfQ: 1.4,
				hmfGain: 3,
				hmfFreq: 4e3,
				hfGain: 1.5,
				hfFreq: 1e4
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: .9,
				c: .95,
				d: .8
			}
		},
		valve: {
			type: "compressor",
			params: {
				input: 0,
				threshold: -20,
				time: 2,
				output: 3
			}
		},
		output: k.output
	}, [
		...ie,
		...S("chords", "aurora"),
		...S("bass", "monarch"),
		[
			"skitter",
			"trig",
			"boom",
			"trig"
		],
		...w([
			["boom", "console"],
			["monarch"],
			["space"],
			["aurora"]
		], "mixer", "valve", "output")
	]) : e === "Deep End" ? x(e, 64, .04, {
		performance: {
			type: "performance",
			steps: g("..X.......x.x...", _([74, 10], [75, 2], [74, 4]), [
				.9,
				.9,
				.95,
				.9,
				.9,
				.9,
				.9,
				.9,
				.9,
				.9,
				.9,
				.9,
				.95,
				.9,
				.9,
				.9
			])
		},
		lead: {
			type: "monarch",
			params: {
				osc1Wave: 0,
				osc1Octave: 0,
				osc1Level: .8,
				osc2Wave: 1,
				osc2Octave: 0,
				osc2Detune: 7,
				osc2Level: .25,
				osc3Level: 0,
				cutoff: 2800,
				resonance: 0,
				drive: 0,
				envAmount: 0,
				tracking: .5,
				ampAttack: .012,
				ampDecay: 1.2,
				ampSustain: .4,
				ampRelease: 1.4,
				glide: .18,
				level: .75
			}
		},
		delay: {
			type: "delay",
			params: {
				time: v(64),
				feedback: .45,
				mix: .32
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 3,
				mix: .42
			}
		},
		bass: {
			type: "performance",
			steps: g("X.........x...x.", _([31, 10], [27, 4], [30, 2]), [
				.95,
				.6,
				.6,
				.6,
				.6,
				.6,
				.6,
				.6,
				.6,
				.6,
				.95,
				.6,
				.6,
				.6,
				.7,
				.6
			])
		},
		monarch: ae({
			drive: .55,
			glide: .08,
			ampDecay: 1.6,
			ampRelease: 1.4,
			level: .3
		}),
		skitter: oe({
			hat: "x.x.x.x.x.x.x.xx",
			perc: "...........x...."
		}, { hat: {
			2: "...............x",
			3: "......x.........",
			4: "..........x.....",
			6: "..............x."
		} }, { rollFade: .4 }),
		boom: se({
			kick: "x.........x.....",
			snare: "....x.......x...",
			clap: "....x.......x..."
		}, {
			kickDecay: .6,
			snareTone: .25,
			snappy: .45
		}),
		console: {
			type: "equalizer",
			params: {
				hpf: 35,
				lfGain: 2.5,
				lfFreq: 55,
				lfBell: 1,
				lmfGain: -3.5,
				lmfFreq: 350,
				lmfQ: 1.2,
				hmfGain: 2.5,
				hmfFreq: 3500,
				lpf: 12e3
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: .8,
				c: 1
			}
		},
		valve: {
			type: "compressor",
			params: {
				input: 0,
				threshold: -20,
				time: 2,
				output: 3
			}
		},
		output: k.output
	}, [
		...S("performance", "lead"),
		...S("bass", "monarch"),
		[
			"skitter",
			"trig",
			"boom",
			"trig"
		],
		...w([
			["boom", "console"],
			["monarch"],
			[
				"lead",
				"delay",
				"space"
			]
		], "mixer", "valve", "output")
	]) : x(e, 72, .05, {
		...re(g("X...x.x.X...x...", _([71, 4], [67, 2], [69, 2], [71, 4], [74, 4]), .9), 72, {
			wave: 0,
			octave: 0,
			cutoff: 3200,
			resonance: 1,
			attack: .02,
			decay: .8,
			sustain: .5,
			release: .6,
			echo: .25,
			space: .4
		}),
		chords: {
			type: "performance",
			steps: g("X.....x.X.....x.", _([55, 8], [48, 8]), [
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.7,
				.5,
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.7,
				.5
			])
		},
		oracle: {
			type: "oracle",
			params: {
				aShape: 0,
				aLevel: .6,
				bShape: 1,
				bFine: 4,
				bLevel: .7,
				cutoff: 2600,
				resonance: .1,
				envAmount: .35,
				tracking: .5,
				filterAttack: .002,
				filterDecay: .35,
				filterSustain: .1,
				ampAttack: .003,
				ampDecay: .9,
				ampSustain: .15,
				ampRelease: .8,
				vintage: .35,
				chord: 3,
				level: .75
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 120,
				lmfGain: -3,
				lmfFreq: 300,
				lmfQ: 1.2,
				hmfGain: 2,
				hmfFreq: 2500,
				hmfQ: .8,
				hfGain: 2.5,
				hfFreq: 1e4
			}
		},
		bass: {
			type: "performance",
			steps: g("X.......X.......", _([31, 8], [36, 8]), .5)
		},
		monarch: ae({
			ampRelease: .6,
			level: .32
		}),
		skitter: oe({
			hat: "x.xxx.x.x.xxx.x.",
			open: ".......x........",
			synth: "x......x..x...x."
		}, {
			hat: { 3: "...x.......x...." },
			synth: { 2: "..............x." }
		}, { gate: .7 }),
		boom: se({
			kick: "x......x..x.....",
			snare: "....x.......x..."
		}, {
			kickDecay: .5,
			snareTone: .3,
			snappy: .5
		}),
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: .9,
				c: .8,
				d: .9
			}
		},
		...k
	}, [
		...ie,
		...S("chords", "oracle"),
		[
			"bass",
			"pitch",
			"monarch",
			"pitch"
		],
		[
			"skitter",
			"trig",
			"boom",
			"trig"
		],
		[
			"skitter",
			"gate",
			"monarch",
			"gate"
		],
		...w([
			["boom"],
			["monarch"],
			["space"],
			["oracle", "console"]
		], "mixer", "cohere", "output")
	]);
}
//#endregion
//#region src/industrialPresets.ts
function le(e) {
	return e === "Rust Machine" ? x(e, 93, .08, {
		seq: {
			type: "performance",
			steps: g("X.xX.xx.X.xX.xxo", [
				29,
				29,
				29,
				41,
				41,
				29,
				32,
				32,
				34,
				34,
				34,
				36,
				36,
				39,
				36,
				32
			], [
				.45,
				.4,
				.35,
				.3,
				.4,
				.35,
				.4,
				.4,
				.45,
				.4,
				.35,
				.4,
				.4,
				.3,
				.35,
				.3
			])
		},
		bass: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Wave: 3,
				osc2Detune: 6,
				osc2Level: .45,
				osc3Wave: 0,
				osc3Octave: -1,
				osc3Level: .4,
				cutoff: 420,
				resonance: .72,
				drive: .4,
				envAmount: .75,
				tracking: .5,
				filterAttack: .002,
				filterDecay: .12,
				filterSustain: .05,
				filterRelease: .06,
				ampAttack: .002,
				ampDecay: .2,
				ampSustain: .6,
				ampRelease: .05,
				level: .7
			}
		},
		fuzz: {
			type: "rust",
			params: {
				mode: 0,
				drive: .35,
				bias: .15,
				body: 160,
				tone: .5,
				mix: .4,
				level: .6
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 32,
				lfGain: 2,
				lfFreq: 80,
				lmfGain: -3,
				lmfFreq: 280,
				lmfQ: 1.2,
				hmfGain: 3,
				hmfFreq: 1400,
				hmfQ: 1.4,
				lpf: 9e3
			}
		},
		chops: {
			type: "performance",
			steps: g("..x..X..x..x.X..", _([53, 8], [58, 8]), .25)
		},
		guitar: {
			type: "oracle",
			params: {
				aShape: 1,
				aWidth: .3,
				bShape: 2,
				bFine: 4,
				bLevel: .5,
				cutoff: 3400,
				resonance: .1,
				envAmount: .3,
				filterDecay: .1,
				filterSustain: 0,
				ampAttack: .002,
				ampDecay: .12,
				ampSustain: 0,
				ampRelease: .06,
				chord: 2,
				vintage: .25,
				level: .9
			}
		},
		guitarEq: {
			type: "equalizer",
			params: {
				hpf: 250,
				lmfGain: -3,
				lmfFreq: 500,
				lmfQ: 1.2,
				hmfGain: 3,
				hmfFreq: 2500,
				hmfQ: 1,
				hfGain: 2,
				hfFreq: 9e3,
				output: 2
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(93),
				feedback: .25,
				mix: .18
			}
		},
		pad: {
			type: "performance",
			steps: g("X.......X.......", _([53, 8], [46, 8]), .95)
		},
		aurora: {
			type: "aurora",
			params: {
				osc1Wave: 0,
				osc2Wave: 1,
				osc2Detune: 9,
				blend: .45,
				hpf: 150,
				cutoff: 900,
				resonance: .15,
				envAmount: .1,
				filterAttack: .4,
				filterDecay: 1.6,
				filterSustain: .6,
				ampAttack: .6,
				ampDecay: 1.5,
				ampSustain: .8,
				ampRelease: 2.4,
				lfoRate: .2,
				lfoWidth: .25,
				lfoFilter: .05,
				chord: 4,
				vintage: .5,
				level: .65
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2.6,
				mix: .4
			}
		},
		lead: {
			type: "performance",
			steps: g("X.......x...x...", _([53, 8], [51, 4], [48, 4]), .9)
		},
		power: {
			type: "monarch",
			params: {
				osc1Level: .7,
				osc2Detune: 12,
				osc2Level: .6,
				osc3Wave: 3,
				osc3Octave: -1,
				osc3Level: .4,
				cutoff: 1800,
				resonance: .2,
				drive: .6,
				envAmount: .2,
				filterDecay: .4,
				filterSustain: .6,
				ampAttack: .01,
				ampDecay: .4,
				ampSustain: .8,
				ampRelease: .2,
				glide: .03,
				level: .45
			}
		},
		grind: {
			type: "rust",
			params: {
				mode: 1,
				drive: .6,
				bias: .2,
				starve: .2,
				body: 700,
				tone: .5,
				mix: .85,
				level: .4
			}
		},
		forge: {
			type: "forge",
			params: {
				level: .9,
				drive: .25,
				room: .08,
				kickLevel: 1,
				kickDecay: .4,
				snareLevel: .9,
				snareDecay: .3,
				snareTone: .6,
				snareLag: 8,
				hatLevel: .45,
				hatDecay: .05,
				hatPan: .2,
				hatLag: -3,
				openLevel: .4,
				openPan: .2,
				openLag: -3,
				anvilLevel: .3,
				anvilPan: -.4
			},
			lanes: {
				kick: "x.....x...x..x..",
				snare: "....x.......x...",
				hat: "xxxxxxxxxxx.xxxx",
				open: "...........x....",
				anvil: "..............x."
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: .6,
				c: 1,
				d: 1,
				e: .55
			}
		},
		valve: {
			type: "compressor",
			params: {
				input: 1,
				threshold: -18,
				time: 1,
				output: 1
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("seq", "bass"),
		...S("chops", "guitar"),
		...S("pad", "aurora"),
		...S("lead", "power"),
		...w([
			["forge"],
			[
				"bass",
				"fuzz",
				"bassEq"
			],
			[
				"guitar",
				"guitarEq",
				"echo"
			],
			["aurora", "space"],
			["power", "grind"]
		], "mixer", "valve", "output")
	]) : x(e, 124, 0, {
		riff: {
			type: "performance",
			steps: g("X.xxX.xxX.xxXxxx", [
				38,
				38,
				38,
				38,
				41,
				41,
				38,
				38,
				43,
				43,
				38,
				38,
				45,
				43,
				41,
				40
			], [
				.7,
				.4,
				.35,
				.35,
				.7,
				.4,
				.35,
				.35,
				.7,
				.4,
				.35,
				.35,
				.5,
				.5,
				.5,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Detune: -12,
				osc2Level: .6,
				osc3Wave: 3,
				osc3Octave: -1,
				osc3Level: .5,
				cutoff: 1800,
				resonance: .15,
				drive: .85,
				envAmount: .35,
				filterDecay: .12,
				filterSustain: .4,
				ampAttack: .002,
				ampDecay: .15,
				ampSustain: .8,
				ampRelease: .03,
				level: .75
			}
		},
		broken: {
			type: "rust",
			params: {
				mode: 0,
				drive: .75,
				bias: .3,
				starve: .2,
				body: 250,
				tone: .55,
				mix: 1,
				level: .5
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 4,
				ratio: 4,
				attack: .002,
				release: .15,
				color: 2,
				output: 5
			}
		},
		riffEq: {
			type: "equalizer",
			params: {
				hpf: 80,
				lfGain: 2,
				lfFreq: 110,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 400,
				lmfQ: 1.2,
				hmfGain: 3,
				hmfFreq: 2500,
				hmfQ: 1,
				lpf: 9e3
			}
		},
		stabs: {
			type: "performance",
			steps: g("X.....X.....X...", _([62, 6], [56, 6], [57, 4]), .6)
		},
		oracle: {
			type: "oracle",
			params: {
				aShape: 2,
				aLevel: .8,
				bLevel: .7,
				bFine: 18,
				cutoff: 2600,
				resonance: .3,
				envAmount: .4,
				filterDecay: .25,
				filterSustain: .3,
				ampAttack: .002,
				ampDecay: .35,
				ampSustain: .3,
				ampRelease: .3,
				chord: 2,
				vintage: .5,
				level: .5
			}
		},
		crush: {
			type: "rust",
			params: {
				mode: 3,
				drive: .5,
				crush: 5,
				body: 800,
				tone: .6,
				mix: .7,
				level: .45
			}
		},
		forge: {
			type: "forge",
			params: {
				level: 1,
				drive: .5,
				room: .25,
				kickLevel: 1,
				snareLevel: .95,
				hatLevel: .5,
				hatPan: .25,
				highTomLevel: .8,
				highTomPan: -.2,
				lowTomLevel: .85,
				lowTomPan: .2
			},
			lanes: {
				kick: "x.....x.x.x.....",
				snare: "....x.......x...",
				hat: "x.x.x.x.x.x.x...",
				highTom: ".............x..",
				lowTom: "..............xx"
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 3,
				lfFreq: 65,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 380,
				lmfQ: 1.4,
				hmfGain: 3,
				hmfFreq: 4500,
				hmfQ: 1,
				hfGain: 1.5,
				hfFreq: 1e4
			}
		},
		sum: {
			type: "mixer",
			params: {
				a: .7,
				b: .95,
				c: .38
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -18,
				ratio: 1,
				attack: 3,
				release: 4,
				output: 5.5
			}
		},
		main: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("riff", "monarch"),
		...S("stabs", "oracle"),
		...w([
			["forge", "drumEq"],
			[
				"monarch",
				"broken",
				"talon",
				"riffEq"
			],
			["oracle", "crush"]
		], "sum", "cohere", "main")
	]);
}
//#endregion
//#region src/model.ts
var A = (e, t, n, r, i, a = .01, o, s = !1) => ({
	id: e,
	label: t,
	min: n,
	max: r,
	initial: i,
	step: a,
	unit: o,
	logarithmic: s
}), j = (e, t, n, r) => ({
	id: e,
	label: t,
	choices: n,
	initial: r,
	min: 0,
	max: n.length - 1,
	step: 1
}), M = (e, t, n = "audio", r) => ({
	id: e,
	label: t,
	kind: n,
	direction: "in",
	scale: r
}), N = (e, t, n = "audio") => ({
	id: e,
	label: t,
	kind: n,
	direction: "out"
}), P = (e, t = 2) => Array.from({ length: t }, (t, n) => n ? {
	...e,
	id: `${e.id}${n + 1}`,
	copyOf: e.id
} : e), F = (e) => ({
	...e,
	legacyDefault: e.initial
}), ue = (e) => F(A(e, "Lag", -50, 50, 0, 1, "ms")), de = ["filterModel", "engine"], fe = (e) => F(j(e, "Engine", ["Digital", "Analog"], 1)), I = (e, t) => ({
	id: `${e}Pattern`,
	label: "Pattern",
	min: 0,
	max: 65535,
	step: 1,
	initial: [...t].reduce((e, t, n) => t === "x" ? e | 1 << n : e, 0),
	pattern: !0,
	voice: e
}), pe = (e, t, n, r, i) => [
	{
		...A(`${e}Steps`, `${t} steps`, 1, 16, n, 1),
		voice: e
	},
	{
		...A(`${e}Hits`, `${t} hits`, 0, 16, r, 1),
		voice: e
	},
	{
		...A(`${e}Shift`, `${t} shift`, 0, 15, i, 1),
		voice: e
	}
], me = [
	"Skin",
	"Wood",
	"Sand",
	"Metal",
	"Shaker",
	"Tom"
].map((e) => ({
	id: e.toLowerCase(),
	label: e
})), he = ({ id: e, label: t }, n) => {
	let [r, i, a] = [
		[
			16,
			5,
			2
		],
		[
			8,
			3,
			0
		],
		[
			12,
			8,
			0
		],
		[
			16,
			0,
			0
		],
		[
			16,
			0,
			0
		],
		[
			16,
			0,
			0
		]
	][n], o = (t) => ({
		...F(t),
		voice: e
	});
	return [
		...pe(e, t, r, i, a).map((e) => n > 2 ? o(e) : e),
		o(A(`${e}Tune`, `${t} tune`, -24, 24, 0, 1, "st")),
		o(A(`${e}Decay`, `${t} decay`, .02, 2, [
			.32,
			.07,
			.07,
			.5,
			.12,
			.4
		][n], .01, "s", !0)),
		o(A(`${e}Tone`, `${t} tone`, 0, 1, .5)),
		o(A(`${e}Level`, `${t} level`, 0, 2, 1)),
		o(A(`${e}Pan`, `${t} pan`, -1, 1, 0)),
		o({
			...ue(`${e}Lag`),
			label: `${t} lag`
		}),
		o(j(`${e}Custom`, `${t} rhythm`, ["Euclidean", "Custom"], 0)),
		o(I(e, "................"))
	];
}, ge = (e, t) => [
	A(`${e}Attack`, "Attack", .002, 2, .008, .001, "s", !0),
	A(`${e}Decay`, "Decay", .01, 3, .25, .01, "s", !0),
	A(`${e}Sustain`, "Sustain", 0, 1, e === "amp" ? .65 : .2),
	A(`${e}Release`, "Release", .01, 4, .2, .01, "s", !0)
].map((e) => ({
	...e,
	group: t
})), _e = [
	M("chain", "Chain in"),
	M("trig", "Trig in", "gate"),
	...P(N("out", "Drums out"))
], L = (e, t) => t.map((t) => ({
	...t,
	group: e
})), ve = [
	["Off", [0]],
	["Maj 7", [
		0,
		4,
		7,
		11
	]],
	["Min 7", [
		0,
		3,
		7,
		10
	]],
	["Maj 9", [
		0,
		4,
		7,
		11,
		14
	]],
	["Min 9", [
		0,
		3,
		7,
		10,
		14
	]],
	["Min 11", [
		0,
		3,
		10,
		14,
		17
	]],
	["Dom 9", [
		0,
		4,
		7,
		10,
		14
	]]
], ye = [
	["kick", "Kick"],
	["snare", "Snare"],
	["rim", "Sidestick"],
	["clap", "Clap"],
	["hat", "Closed hat"],
	["open", "Open hat"],
	["lowTom", "Low tom"],
	["midTom", "Mid tom"],
	["highTom", "High tom"],
	["lowConga", "Low conga"],
	["highConga", "High conga"],
	["cabasa", "Cabasa"],
	["tambourine", "Tambourine"],
	["bell", "Cowbell"],
	["crash", "Crash"],
	["ride", "Ride"]
].map(([e, t]) => ({
	id: e,
	label: t
})), be = [
	"Three pairs",
	"Twin stacks",
	"Serial stack",
	"Shared modulation",
	"Branched",
	"Additive"
], xe = [
	"a",
	"b",
	"c",
	"d",
	"e",
	"f",
	"g",
	"h"
], Se = (e) => `${e}Pan`, Ce = [
	["kick", "Kick"],
	["snare", "Snare"],
	["clap", "Clap"],
	["hat", "Hat"],
	["open", "Open hat"],
	["perc", "Perc"],
	["synth", "Synth"]
].map(([e, t]) => ({
	id: e,
	label: t
})), R = {
	boom: {
		kick: "kick",
		snare: "snare",
		clap: "clap",
		hat: "hat",
		open: "open",
		perc: "rim"
	},
	punch: {
		kick: "kick",
		snare: "snare",
		clap: "clap",
		hat: "hat",
		open: "open"
	},
	strike: {
		kick: "kick",
		snare: "snare",
		clap: "clap",
		hat: "hat",
		open: "open",
		perc: "rim"
	},
	forge: {
		kick: "kick",
		snare: "snare",
		hat: "hat",
		open: "open",
		perc: "anvil"
	},
	orbit: {
		kick: "skin",
		snare: "sand",
		clap: "sand",
		hat: "shaker",
		open: "metal",
		perc: "wood"
	}
}, z = [
	["kick", "Kick"],
	["snare", "Snare"],
	["hat", "Closed hat"],
	["pedal", "Pedal hat"],
	["open", "Open hat"],
	["lowTom", "Floor tom"],
	["highTom", "Rack tom"],
	["crash", "Crash"],
	["china", "China"],
	["ride", "Ride"],
	["anvil", "Anvil"]
].map(([e, t]) => ({
	id: e,
	label: t
})), B = [
	2,
	3,
	4,
	6
], we = (e, t) => `${e}Roll${t}`, Te = [
	"Fuzz",
	"Rectify",
	"Fold",
	"Crush",
	"Broken"
], Ee = (e, t) => e.flatMap(({ id: e, label: n }) => [
	A(`${e}Tune`, "Tune", -24, 24, 0, 1, "st"),
	A(`${e}Decay`, "Decay", .03, 4, t(e), .01, "s", !0),
	A(`${e}Tone`, "Tone", 0, 1, .7),
	A(`${e}Level`, "Level", 0, 1.6, .8),
	A(`${e}Pan`, "Pan", -1, 1, 0),
	ue(`${e}Lag`)
].map((t) => ({
	...t,
	voice: e,
	label: `${n} ${t.label}`
}))), De = [
	["kick", "Kick"],
	["snare", "Snare"],
	["rim", "Rim"],
	["clap", "Clap"],
	["hat", "Hat"],
	["open", "Open"],
	["lowTom", "Lo tom"],
	["highTom", "Hi tom"],
	["crash", "Crash"],
	["ride", "Ride"],
	["bell", "Bell"]
].map(([e, t]) => ({
	id: e,
	label: t
})), Oe = [
	["kick", "Kick"],
	["snare", "Snare"],
	["clap", "Clap"],
	["hat", "Hat"],
	["open", "Open"]
].map(([e, t]) => ({
	id: e,
	label: t
})), ke = (e) => e.map(({ id: e, label: t }) => F({
	...A(`${e}Level`, `${t} level`, 0, 2, 1),
	voice: e
})), Ae = (e, t) => e.flatMap(({ id: e, label: n }) => [
	...t[e],
	F(A(`${e}Pan`, "Pan", -1, 1, 0)),
	ue(`${e}Lag`)
].map((t) => ({
	...t,
	voice: e,
	label: `${n} ${t.label}`
}))), je = (e) => F(A(e, "Tune", -12, 12, 0, 1, "st")), V = (e, t, n, r, i = .01) => A(e, "Decay", t, n, r, i, "s", !0), Me = (e) => F(A(e, "Tone", 0, 1, .5)), H = (e, t) => 2 ** ((e - .5) * t), Ne = {
	kick: [A("kickTune", "Tune", 30, 90, 49, 1, "Hz"), A("kickDecay", "Decay", .1, 2.5, .8, .01, "s", !0)],
	snare: [
		je("snareTune"),
		F(V("snareDecay", .05, 1, .2)),
		A("snareTone", "Tone", 0, 1, .5),
		A("snappy", "Snappy", 0, 1, .6)
	],
	rim: [je("rimTune"), F(V("rimDecay", .01, .3, .03, .001))],
	clap: [Me("clapTone"), F(V("clapDecay", .05, 1.5, .2))],
	hat: [V("hatDecay", .02, .6, .06), Me("hatTone")],
	open: [F(V("openDecay", .1, 1.2, .4)), Me("openTone")],
	lowTom: [je("tomTune"), F(V("tomDecay", .1, 1.5, .45))],
	highTom: [{
		...je("highTomTune"),
		legacyFrom: "tomTune"
	}, {
		...F(V("highTomDecay", .1, 1.5, .45)),
		legacyFrom: "tomDecay"
	}],
	crash: [F(V("crashDecay", .3, 3, 1.6)), Me("crashTone")],
	ride: [F(V("rideDecay", .2, 2.5, 1)), Me("rideTone")],
	bell: [A("bellTune", "Tune", -12, 12, 0, 1, "st"), F(V("bellDecay", .05, 1.5, .32))]
}, Pe = {
	kick: [
		A("kickTune", "Tune", 40, 90, 55, 1, "Hz"),
		V("kickDecay", .1, 1.2, .45),
		A("kickClick", "Click", 0, 1, .5)
	],
	snare: [
		je("snareTune"),
		F(V("snareDecay", .05, 1, .18)),
		A("snareTone", "Tone", 0, 1, .5),
		A("snappy", "Snappy", 0, 1, .7)
	],
	clap: [Me("clapTone"), F(V("clapDecay", .05, 1.5, .24))],
	hat: [V("hatDecay", .02, .3, .05), Me("hatTone")],
	open: [V("openDecay", .1, 1, .35), Me("openTone")]
}, U = {
	performance: {
		name: "STEP–16",
		subtitle: "PATTERN & NOTE CONTROLLER",
		color: "performance",
		params: [ue("lag")],
		ports: [...P(N("pitch", "Pitch · 1V/oct", "cv"), 3), ...P(N("gate", "Note gate", "gate"), 3)]
	},
	oscillator: {
		name: "SOLID",
		subtitle: "ANALOG OSCILLATOR",
		color: "oscillator",
		params: [
			j("wave", "Waveform", [
				"Sine",
				"Triangle",
				"Saw",
				"Square"
			], 2),
			A("octave", "Octave", -3, 3, 0, 1),
			A("tune", "Tune", -12, 12, 0, 1, "st"),
			A("fine", "Fine", -50, 50, 0, 1, "ct"),
			A("level", "Level", 0, 1, .7)
		],
		ports: [
			M("pitch", "Pitch · 1V/oct", "cv", 1200),
			M("fm", "FM", "cv", 1200),
			...P(N("out", "Audio out"))
		]
	},
	noise: {
		name: "STATIC",
		subtitle: "NOISE GENERATOR",
		color: "noise",
		params: [j("color", "Color", [
			"White",
			"Pink",
			"Brown"
		], 0), A("level", "Level", 0, 1, .4)],
		ports: [...P(N("out", "Audio out"))]
	},
	mixer: {
		name: "SUM",
		subtitle: "EIGHT CHANNEL MIXER",
		color: "mixer",
		params: [
			...xe.map((e, t) => {
				let n = A(e, `Channel ${e.toUpperCase()}`, 0, 1, .7);
				return t > 2 ? F(n) : n;
			}),
			...xe.map((e) => F(A(Se(e), `Channel ${e.toUpperCase()} pan`, -1, 1, 0))),
			F(A("master", "Mix bus", 0, 1, 1))
		],
		ports: [...xe.map((e) => M(e, `Channel ${e.toUpperCase()}`)), ...P(N("out", "Mix out"))]
	},
	filter: {
		name: "SIEVE",
		subtitle: "MULTIMODE FILTER",
		color: "filter",
		params: [
			j("mode", "Mode", [
				"Low-pass",
				"High-pass",
				"Band-pass"
			], 0),
			A("cutoff", "Cutoff", 40, 18e3, 1400, 1, "Hz", !0),
			A("resonance", "Resonance", .1, 12, 2.5, .1),
			fe("filterModel")
		],
		ports: [
			M("in", "Audio in"),
			M("cv", "Cutoff CV", "cv", 2400),
			...P(N("out", "Audio out"))
		]
	},
	amplifier: {
		name: "LEVEL",
		subtitle: "VOLTAGE CONTROLLED AMPLIFIER",
		color: "amplifier",
		params: [A("level", "Level", 0, 1, .8)],
		ports: [
			M("in", "Audio in"),
			M("cv", "Amplitude CV", "cv", 1),
			...P(N("out", "Audio out"))
		]
	},
	envelope: {
		name: "CONTOUR",
		subtitle: "ADSR ENVELOPE",
		color: "envelope",
		params: [
			A("attack", "Attack", .002, 2, .01, .001, "s", !0),
			A("decay", "Decay", .01, 3, .2, .01, "s", !0),
			A("sustain", "Sustain", 0, 1, .5),
			A("release", "Release", .01, 4, .18, .01, "s", !0)
		],
		ports: [M("gate", "Note gate", "gate"), ...P(N("out", "Envelope CV", "cv"))]
	},
	lfo: {
		name: "PULSE",
		subtitle: "LOW FREQUENCY OSCILLATOR",
		color: "lfo",
		params: [j("wave", "Waveform", [
			"Sine",
			"Triangle",
			"Saw",
			"Square"
		], 0), A("rate", "Rate", .05, 20, 2, .05, "Hz", !0)],
		ports: [M("cv", "Rate CV", "cv", 5), ...P(N("out", "Modulation CV", "cv"))]
	},
	delay: {
		name: "ECHO",
		subtitle: "FEEDBACK DELAY",
		color: "delay",
		params: [
			A("time", "Time", .02, 1, .28, .01, "s"),
			A("feedback", "Feedback", 0, .85, .32),
			A("mix", "Mix", 0, 1, .22)
		],
		ports: [M("in", "Audio in"), ...P(N("out", "Audio out"))]
	},
	reverb: {
		name: "SPACE",
		subtitle: "STEREO REVERBERATOR",
		color: "reverb",
		params: [A("decay", "Decay", .2, 3, 1.5, .1, "s"), A("mix", "Mix", 0, 1, .25)],
		ports: [M("in", "Audio in"), ...P(N("out", "Audio out"))]
	},
	boom: {
		name: "BOOM",
		subtitle: "ANALOG DRUM MACHINE",
		color: "boom",
		ports: _e,
		drum: {
			mode: "steps",
			voices: De
		},
		params: [
			...Ae(De, Ne),
			A("level", "Level", 0, 1, .8),
			fe("engine"),
			I("kick", "x......x..x....."),
			I("snare", "....x.......x..."),
			I("hat", "x.x.x.x.x.x.x.x."),
			I("bell", "...........x..x."),
			...[
				"rim",
				"clap",
				"open",
				"lowTom",
				"highTom",
				"crash",
				"ride"
			].map((e) => F(I(e, "................"))),
			...ke(De)
		]
	},
	punch: {
		name: "PUNCH",
		subtitle: "DANCE FLOOR DRUM MACHINE",
		color: "punch",
		ports: _e,
		drum: {
			mode: "steps",
			voices: Oe
		},
		params: [
			...Ae(Oe, Pe),
			A("level", "Level", 0, 1, .8),
			fe("engine"),
			I("kick", "x...x...x...x..."),
			I("snare", "............x..x"),
			I("clap", "....x.......x..."),
			I("hat", "xx..xx..xx..xx.."),
			I("open", "..x...x...x...x."),
			...ke(Oe)
		]
	},
	orbit: {
		name: "ORBIT",
		subtitle: "EUCLIDEAN PERCUSSION",
		color: "orbit",
		ports: _e,
		drum: {
			mode: "euclid",
			voices: me
		},
		params: [
			A("pitch", "Pitch", -12, 12, 0, 1, "st"),
			A("level", "Level", 0, 1, .7),
			fe("engine"),
			...me.flatMap(he)
		]
	},
	monarch: {
		name: "MONARCH",
		subtitle: "VINTAGE MONOSYNTH",
		color: "monarch",
		ports: [
			M("pitch", "Pitch · 1V/oct", "cv", 1200),
			M("gate", "Note gate", "gate"),
			M("cv", "Cutoff CV", "cv", 2400),
			...P(N("out", "Audio out"))
		],
		params: [
			...[
				1,
				2,
				3
			].flatMap((e) => [
				j(`osc${e}Wave`, "Waveform", [
					"Sine",
					"Triangle",
					"Saw",
					"Square"
				], 2),
				A(`osc${e}Octave`, "Octave", -3, 3, e === 3 ? -1 : 0, 1),
				A(`osc${e}Detune`, "Detune", -50, 50, e === 2 ? 7 : 0, 1, "ct"),
				A(`osc${e}Level`, "Level", 0, 1, e === 1 ? .7 : .35)
			].map((t) => ({
				...t,
				group: `Oscillator ${e}`
			}))),
			...[
				fe("filterModel"),
				A("cutoff", "Cutoff", 40, 18e3, 1100, 1, "Hz", !0),
				A("resonance", "Resonance", 0, 1, .2),
				A("drive", "Drive", 0, 1, .25),
				A("envAmount", "Env amount", -1, 1, .5),
				A("tracking", "Key track", 0, 1, .5)
			].map((e) => ({
				...e,
				group: "Filter"
			})),
			...ge("filter", "Filter envelope"),
			...ge("amp", "Amplifier envelope"),
			...[
				A("noise", "Noise", 0, 1, 0),
				A("glide", "Glide", 0, 1, 0, .01, "s"),
				A("level", "Level", 0, 1, .7)
			].map((e) => ({
				...e,
				group: "Performance"
			}))
		]
	},
	oracle: {
		name: "ORACLE",
		subtitle: "FIVE-VOICE POLYSYNTH",
		color: "oracle",
		ports: [
			M("pitch", "Pitch · 1V/oct", "cv", 1200),
			M("gate", "Note gate", "gate"),
			M("cv", "Cutoff CV", "cv", 2400),
			...P(N("out", "Audio out"))
		],
		params: [
			...L("Poly-Mod", [
				A("polyEnv", "Filt env", 0, 1, 0),
				A("polyOscB", "Osc B", 0, 1, 0),
				j("polyDest", "Dest", [
					"Freq A",
					"Filter",
					"Both"
				], 0)
			]),
			...L("Oscillator A", [
				A("aOctave", "Octave", -2, 2, 0, 1),
				j("aShape", "Shape", [
					"Saw",
					"Pulse",
					"Saw + Pulse"
				], 0),
				A("aWidth", "Width", .05, .95, .5)
			]),
			...L("Oscillator B", [
				A("bOctave", "Octave", -2, 2, 0, 1),
				A("bFine", "Fine", -50, 50, 7, 1, "ct"),
				j("bShape", "Shape", [
					"Saw",
					"Triangle",
					"Pulse"
				], 0),
				A("bWidth", "Width", .05, .95, .5)
			]),
			...L("LFO", [
				A("lfoRate", "Rate", .05, 20, 4, .05, "Hz", !0),
				j("lfoShape", "Shape", [
					"Triangle",
					"Saw",
					"Square"
				], 0),
				A("lfoAmount", "Amount", 0, 1, 0),
				j("lfoDest", "Dest", [
					"Pitch",
					"PW",
					"Filter"
				], 0)
			]),
			...L("Mixer", [
				A("aLevel", "Osc A", 0, 1, .8),
				A("bLevel", "Osc B", 0, 1, .6),
				A("noise", "Noise", 0, 1, 0)
			]),
			...L("Filter", [
				fe("filterModel"),
				A("cutoff", "Cutoff", 40, 18e3, 1600, 1, "Hz", !0),
				A("resonance", "Resonance", 0, 1, .15),
				A("envAmount", "Env amount", 0, 1, .4),
				A("tracking", "Key track", 0, 1, .5)
			]),
			...ge("filter", "Filter envelope"),
			...ge("amp", "Amplifier envelope"),
			...L("Voices", [
				A("glide", "Glide", 0, 1, 0, .01, "s"),
				A("vintage", "Vintage", 0, 1, .3),
				j("chord", "Chord", ve.map(([e]) => e), 0),
				A("level", "Level", 0, 1, .7)
			])
		]
	},
	aurora: {
		name: "AURORA",
		subtitle: "EIGHT-VOICE ANALOG POLYSYNTH",
		color: "aurora",
		ports: [
			M("pitch", "Pitch · 1V/oct", "cv", 1200),
			M("gate", "Note gate", "gate"),
			M("cv", "Cutoff CV", "cv", 2400),
			...P(N("out", "Audio out"))
		],
		params: [
			...[1, 2].flatMap((e) => L(`Oscillator ${e}`, [
				j(`osc${e}Wave`, "Waveform", [
					"Saw",
					"Pulse",
					"Triangle",
					"Sine"
				], e === 1 ? 0 : 1),
				A(`osc${e}Octave`, "Octave", -2, 2, 0, 1),
				A(`osc${e}Detune`, "Detune", -50, 50, e === 2 ? 6 : 0, 1, "ct"),
				A(`osc${e}Width`, "Width", .05, .95, .5)
			])),
			...L("Source mix", [
				A("blend", "Osc 1 / 2", 0, 1, .5),
				A("crossMod", "Cross mod", 0, 1, 0),
				A("hpf", "High-pass", 20, 3e3, 20, 1, "Hz", !0)
			]),
			...L("Filter", [
				fe("filterModel"),
				A("cutoff", "Cutoff", 40, 18e3, 2200, 1, "Hz", !0),
				A("resonance", "Resonance", 0, 1, .15),
				j("slope", "Slope", ["12 dB", "24 dB"], 1),
				A("envAmount", "Env amount", -1, 1, .35),
				A("tracking", "Key track", 0, 1, .5)
			]),
			...ge("filter", "Filter envelope"),
			...ge("amp", "Amplifier envelope"),
			...L("LFO", [
				A("lfoRate", "Rate", .05, 20, .6, .05, "Hz", !0),
				j("lfoShape", "Waveform", [
					"Triangle",
					"Sine",
					"Square"
				], 0),
				A("lfoPitch", "Pitch", 0, 1, 0),
				A("lfoWidth", "PWM", 0, 1, .15),
				A("lfoFilter", "Filter", 0, 1, 0)
			]),
			...L("Voices", [
				A("glide", "Glide", 0, 1, 0, .01, "s"),
				A("vintage", "Vintage", 0, 1, .25),
				j("chord", "Chord", ve.map(([e]) => e), 0),
				A("level", "Level", 0, 1, .65)
			])
		]
	},
	strike: {
		name: "STRIKE",
		subtitle: "VINTAGE DIGITAL DRUM MACHINE",
		color: "strike",
		ports: _e,
		drum: {
			mode: "steps",
			voices: ye
		},
		params: [
			A("level", "Level", 0, 1, .8),
			fe("engine"),
			...ye.flatMap(({ id: e, label: t }) => [I(e, e === "kick" ? "x.......x.x....." : e === "snare" ? "....x.......x..." : e === "hat" ? "x.x.x.x.x.x.x.x." : "................"), ...[
				A(`${e}Tune`, "Tune", -24, 24, 0, 1, "st"),
				A(`${e}Decay`, "Decay", .03, 3, ["crash", "ride"].includes(e) ? 1.8 : e === "open" ? .45 : e === "hat" ? .08 : .35, .01, "s", !0),
				A(`${e}Tone`, "Tone", 0, 1, .7),
				A(`${e}Level`, "Level", 0, 1.6, .8),
				A(`${e}Pan`, "Pan", -1, 1, 0),
				ue(`${e}Lag`)
			].map((n) => ({
				...n,
				voice: e,
				label: `${t} ${n.label}`
			}))])
		]
	},
	prism: {
		name: "PRISM",
		subtitle: "SIX-OPERATOR FM SYNTH",
		color: "prism",
		ports: [
			M("pitch", "Pitch · 1V/oct", "cv", 1200),
			M("gate", "Note gate", "gate"),
			M("cv", "Brightness CV", "cv", 1),
			...P(N("out", "Audio out"))
		],
		params: [
			...L("Sound", [
				j("algorithm", "Algorithm", be, 0),
				A("feedback", "Feedback", 0, 1, .08),
				A("brightness", "Brightness", 0, 2, .8),
				A("velocity", "Velocity", 0, 1, .7)
			]),
			...L("Performance", [
				A("lfoRate", "LFO rate", .05, 20, 5, .05, "Hz", !0),
				A("lfoDepth", "Vibrato", 0, 1, 0),
				j("chord", "Chord", ve.map(([e]) => e), 0),
				A("level", "Level", 0, 1, .65)
			]),
			...L("Filter", [fe("filterModel"), ...[
				A("filterCutoff", "Cutoff", 40, 18e3, 9e3, 1, "Hz", !0),
				A("filterResonance", "Resonance", 0, 1, .15),
				A("filterDrive", "Drive", 0, 1, .2),
				A("filterEnv", "Env amount", -1, 1, .25),
				A("filterTrack", "Key track", 0, 1, .5)
			].map(F)]),
			...Array.from({ length: 6 }, (e, t) => {
				let n = `op${t + 1}`;
				return [
					A(`${n}Ratio`, "Ratio", .5, 16, t % 2 ? 2 : 1, .5),
					A(`${n}Detune`, "Detune", -50, 50, 0, 1, "ct"),
					A(`${n}Level`, "Level", 0, 1, t < 2 ? .8 : .4),
					A(`${n}Attack`, "Attack", .002, 2, .005, .001, "s", !0),
					A(`${n}Decay`, "Decay", .01, 3, t % 2 ? .35 : 1.2, .01, "s", !0),
					A(`${n}Sustain`, "Sustain", 0, 1, t % 2 ? .05 : .25),
					A(`${n}Release`, "Release", .01, 4, .25, .01, "s", !0)
				].map((e) => ({
					...e,
					voice: n
				}));
			}).flat()
		]
	},
	compressor: {
		name: "VALVE",
		subtitle: "VARIABLE-MU LIMITER",
		color: "compressor",
		ports: [M("in", "Audio in"), ...P(N("out", "Audio out"))],
		params: [
			A("input", "Input", -12, 18, 0, .5, "dB"),
			A("threshold", "Threshold", -40, 0, -18, .5, "dB"),
			j("time", "Time constant", [
				"1",
				"2",
				"3",
				"4",
				"5",
				"6"
			], 1),
			A("output", "Output", -12, 12, 0, .5, "dB")
		]
	},
	equalizer: {
		name: "CONSOLE",
		subtitle: "FOUR-BAND CHANNEL EQ",
		color: "equalizer",
		ports: [M("in", "Audio in"), ...P(N("out", "Audio out"))],
		params: [
			j("active", "EQ", ["In", "Out"], 0),
			A("output", "Output", -12, 12, 0, .5, "dB"),
			...L("Filters", [A("hpf", "High-pass", 16, 350, 16, 1, "Hz", !0), A("lpf", "Low-pass", 3e3, 22e3, 22e3, 10, "Hz", !0)]),
			...L("LF", [
				A("lfGain", "Gain", -15, 15, 0, .5, "dB"),
				A("lfFreq", "Freq", 30, 450, 100, 1, "Hz", !0),
				j("lfBell", "Shape", ["Shelf", "Bell"], 0)
			]),
			...L("LMF", [
				A("lmfGain", "Gain", -15, 15, 0, .5, "dB"),
				A("lmfFreq", "Freq", 200, 2500, 600, 1, "Hz", !0),
				A("lmfQ", "Q", .5, 4, 1, .1)
			]),
			...L("HMF", [
				A("hmfGain", "Gain", -15, 15, 0, .5, "dB"),
				A("hmfFreq", "Freq", 600, 7e3, 2500, 10, "Hz", !0),
				A("hmfQ", "Q", .5, 4, 1, .1)
			]),
			...L("HF", [
				A("hfGain", "Gain", -15, 15, 0, .5, "dB"),
				A("hfFreq", "Freq", 1500, 16e3, 8e3, 10, "Hz", !0),
				j("hfBell", "Shape", ["Shelf", "Bell"], 0)
			])
		]
	},
	cohere: {
		name: "COHERE",
		subtitle: "STEREO BUS COMPRESSOR",
		color: "cohere",
		ports: [M("in", "Audio in"), ...P(N("out", "Audio out"))],
		params: [...L("Dynamics", [
			A("threshold", "Threshold", -40, 10, -18, .5, "dB"),
			j("ratio", "Ratio", [
				"2:1",
				"4:1",
				"10:1"
			], 1),
			j("attack", "Attack", [
				"0.1 ms",
				"0.3 ms",
				"1 ms",
				"3 ms",
				"10 ms",
				"30 ms"
			], 4),
			j("release", "Release", [
				"0.1 s",
				"0.3 s",
				"0.6 s",
				"1.2 s",
				"Auto"
			], 4)
		]), ...L("Bus", [
			j("scHpf", "Detector HP", [
				"Off",
				"30 Hz",
				"60 Hz",
				"106 Hz",
				"125 Hz",
				"185 Hz"
			], 0),
			A("output", "Makeup", -12, 20, 0, .5, "dB"),
			j("active", "Process", ["In", "Bypass"], 0)
		])]
	},
	talon: {
		name: "TALON",
		subtitle: "HARMONIC DYNAMICS PROCESSOR",
		color: "talon",
		ports: [M("in", "Audio in"), ...P(N("out", "Audio out"))],
		params: [
			...L("Dynamics", [
				A("input", "Input", -12, 30, 0, .5, "dB"),
				j("ratio", "Ratio", [
					"1:1",
					"2:1",
					"3:1",
					"4:1",
					"6:1",
					"10:1 Opto",
					"20:1",
					"Crush"
				], 4),
				A("attack", "Attack", 5e-5, .03, .003, 5e-5, "s", !0),
				A("release", "Release", .05, 3.5, .3, .01, "s", !0)
			]),
			...L("Character", [
				j("color", "Harmonics", [
					"Clean",
					"Even",
					"Odd"
				], 0),
				j("audioHp", "Audio HP", ["Off", "65 Hz"], 0),
				j("fierce", "Fierce", ["Off", "On"], 0)
			]),
			...L("Detector", [
				j("detectorHp", "High-pass", ["Off", "80 Hz"], 0),
				j("detectorBand", "Emphasis", ["Off", "6 kHz"], 0),
				j("link", "Stereo link", ["Off", "On"], 1)
			]),
			...L("Output", [A("output", "Output", -30, 12, 0, .5, "dB"), j("active", "Process", ["In", "Bypass"], 0)])
		]
	},
	brit: {
		name: "BRIT",
		subtitle: "THREE-BAND CLASS A EQUALIZER",
		color: "brit",
		ports: [M("in", "Audio in"), ...P(N("out", "Audio out"))],
		params: [
			...L("Low shelf", [j("lfFreq", "Freq", [
				"35 Hz",
				"60 Hz",
				"110 Hz",
				"220 Hz"
			], 2), A("lfGain", "Gain", -16, 16, 0, .5, "dB")]),
			...L("Mid bell", [j("midFreq", "Freq", [
				"360 Hz",
				"700 Hz",
				"1.6 kHz",
				"3.2 kHz",
				"4.8 kHz",
				"7.2 kHz"
			], 2), A("midGain", "Gain", -18, 18, 0, .5, "dB")]),
			...L("High shelf · 12 kHz", [A("hfGain", "Gain", -16, 16, 0, .5, "dB")]),
			...L("Signal", [
				j("hpf", "High-pass", [
					"Off",
					"50 Hz",
					"80 Hz",
					"160 Hz",
					"300 Hz"
				], 0),
				A("drive", "Drive", 0, 24, 0, .5, "dB"),
				A("output", "Output", -18, 18, 0, .5, "dB"),
				j("active", "Process", ["In", "Bypass"], 0)
			])
		]
	},
	skitter: {
		name: "SKITTER",
		subtitle: "TRAP STEP SEQUENCER · 1/16 · 1/32 · ROLLS",
		color: "skitter",
		ports: [...P(N("trig", "Trig out · drums", "gate")), ...P(N("gate", "Synth gate", "gate"))],
		drum: {
			mode: "steps",
			voices: Ce
		},
		params: [
			A("rollFade", "Roll fade", 0, 1, .35),
			A("gate", "Gate", .1, 1, .5),
			...Ce.flatMap(({ id: e }) => [I(e, {
				snare: "....x.......x...",
				hat: "x.x.x.x.x.x.x.x."
			}[e] ?? "................"), ...B.map((t) => ({
				...I(e, "................"),
				id: we(e, t),
				label: `Roll ×${t}`
			}))])
		]
	},
	forge: {
		name: "FORGE",
		subtitle: "INDUSTRIAL DRUM KIT",
		color: "forge",
		ports: _e,
		drum: {
			mode: "steps",
			voices: z
		},
		params: [
			A("level", "Level", 0, 1, .8),
			fe("engine"),
			A("drive", "Drive", 0, 1, .35),
			A("room", "Room", 0, 1, .2),
			...z.map(({ id: e }) => I(e, {
				kick: "x.......x.x.....",
				snare: "....x.......x...",
				hat: "x.x.x.x.x.x.x.x."
			}[e] ?? "................")),
			...Ee(z, (e) => ({
				crash: 2.4,
				china: 1.6,
				ride: 2.6,
				open: .7,
				hat: .09,
				pedal: .12,
				lowTom: .7,
				highTom: .55,
				anvil: 1,
				kick: .5,
				snare: .45
			})[e] ?? .4)
		]
	},
	rust: {
		name: "RUST",
		subtitle: "INDUSTRIAL DISTORTION",
		color: "rust",
		ports: [
			M("in", "Audio in"),
			M("cv", "Drive CV", "cv", 4),
			...P(N("out", "Audio out"))
		],
		params: [
			j("mode", "Mode", Te, 0),
			A("drive", "Drive", 0, 1, .6),
			A("bias", "Bias", 0, 1, .15),
			A("crush", "Bits", 2, 12, 6, 1),
			A("starve", "Starve", 0, 1, 0),
			A("body", "Body", 60, 2e3, 220, 1, "Hz", !0),
			A("tone", "Tone", 0, 1, .55),
			A("mix", "Mix", 0, 1, 1),
			A("level", "Level", 0, 1, .6)
		]
	},
	output: {
		name: "MAIN",
		subtitle: "STEREO MASTER OUTPUT",
		color: "output",
		params: [A("volume", "Master", 0, 1, .65)],
		ports: [M("in", "Audio in")]
	}
}, Fe = Object.keys(U).filter((e) => e !== "output"), Ie = 0, Le = (e = "module") => `${e}-${Date.now().toString(36)}-${++Ie}`, W = (e, t = Le()) => ({
	id: t,
	type: e,
	params: Object.fromEntries(U[e].params.map((e) => [e.id, e.initial]))
}), Re = (e) => U[e].params.find((e) => de.includes(e.id)), ze = (e) => e === "performance" ? {
	...W(e),
	steps: Array.from({ length: 16 }, (e, t) => ({
		enabled: t % 4 == 0,
		note: 48,
		velocity: .8,
		gate: .5
	}))
} : W(e), Be = (e, t) => {
	let n = e.modules.findIndex((e) => e.id === t);
	return n === 0 || e.modules[n]?.type === "output";
}, Ve = (e, t) => e.modules[0].id === t ? e.sequencer.steps : e.modules.find((e) => e.id === t)?.steps ?? e.sequencer.steps;
function He(e, t, n) {
	return e.modules[0].id === t ? {
		...e,
		sequencer: {
			...e.sequencer,
			steps: n
		}
	} : {
		...e,
		modules: e.modules.map((e) => e.id === t ? {
			...e,
			steps: n
		} : e)
	};
}
var G = (e, t) => {
	let n = e.modules.find((e) => e.id === t.moduleId);
	return n && U[n.type].ports.find((e) => e.id === t.portId);
}, K = (e, t) => e.moduleId === t.moduleId && e.portId === t.portId;
function Ue(e, t) {
	let n = e.filter((e) => (e.copyOf ?? e.id) === (t.copyOf ?? t.id));
	return n.length > 1 ? n.indexOf(t) + 1 : null;
}
var We = (e, t) => e.cables.find((e) => K(e.from, t) || K(e.to, t));
function Ge(e, t, n) {
	let r = G(e, t), i = G(e, n);
	if (!r || !i) return "That socket no longer exists.";
	if (r.direction !== "out" || i.direction !== "in") return "Connect an output to an input.";
	if (r.kind !== i.kind) return `A ${r.kind.toUpperCase()} output needs a ${r.kind.toUpperCase()} input.`;
	if (e.cables.some((e) => K(e.to, n))) return "That input already has a cable. Pull its plug out first.";
	if (e.cables.some((e) => K(e.from, t))) return "That output jack already has a cable. Use its spare jack, or pull the plug out first.";
	let a = /* @__PURE__ */ new Set(), o = (n) => n === t.moduleId || !a.has(n) && (a.add(n), e.cables.filter((e) => e.from.moduleId === n).some((e) => o(e.to.moduleId)));
	return o(n.moduleId) ? "External feedback loops are not supported. Use ECHO’s feedback control." : null;
}
function Ke(e, t, n, r = 1) {
	let i = Ge(e, t, n);
	if (i) throw Error(i);
	return {
		...e,
		cables: [...e.cables, {
			id: Le("cable"),
			from: t,
			to: n,
			amount: r
		}]
	};
}
function qe(e, t, n) {
	let r = G(e, t), i = G(e, n);
	return !r || !i || r.direction === i.direction ? null : r.direction === "out" ? {
		from: t,
		to: n
	} : {
		from: n,
		to: t
	};
}
function Je(e, t, n, r = null) {
	if (!G(e, t) || !G(e, n)) return "That socket no longer exists.";
	let i = qe(e, t, n);
	return i ? Ge(r ? {
		...e,
		cables: e.cables.filter((e) => e.id !== r)
	} : e, i.from, i.to) : "Connect an output to an input.";
}
function Ye(e, t, n, r) {
	if (!e.cables.find((e) => e.id === t)) throw Error("That cable no longer exists.");
	let i = Je(e, n, r, t);
	if (i) throw Error(i);
	let a = qe(e, n, r);
	return {
		...e,
		cables: e.cables.map((e) => e.id === t ? {
			...e,
			...a
		} : e)
	};
}
function Xe(e, t) {
	return Be(e, t) ? e : {
		...e,
		modules: e.modules.filter((e) => e.id !== t),
		cables: e.cables.filter((e) => e.from.moduleId !== t && e.to.moduleId !== t)
	};
}
function Ze(e, t, n) {
	let r = [...e.modules], i = r.findIndex((e) => e.id === t), a = i + n;
	return i < 1 || a < 1 || a >= r.length - 1 || Be(e, t) ? e : ([r[i], r[a]] = [r[a], r[i]], {
		...e,
		modules: r
	});
}
var Qe = (e, t) => (e >> t & 1) == 1;
function $e(e, t, n = 0) {
	let r = Math.max(1, Math.min(16, Math.round(e))), i = Math.max(0, Math.min(r, Math.round(t))), a = Math.round(n);
	return Array.from({ length: r }, (e, t) => ((t - a) % r + r) % r * i % r < i);
}
function et(e, t, n) {
	let r = e.params;
	return [...B].reverse().find((e) => Qe(r[we(t, e)] ?? 0, n)) ?? 1;
}
var tt = (e, t) => q(e, t).map((n) => [n, et(e, n, t % 16)]);
function q(e, t) {
	let n = U[e.type].drum, r = e.params;
	return n ? n.voices.filter(({ id: i }) => {
		if (n.mode === "steps") return Qe(r[`${i}Pattern`], t % 16);
		let a = J(e, i);
		return a[t % a.length];
	}).map((e) => e.id) : [];
}
function J(e, t) {
	let n = e.params, r = n[`${t}Steps`];
	return n[`${t}Custom`] ? Array.from({ length: r }, (e, r) => Qe(n[`${t}Pattern`], r)) : $e(r, n[`${t}Hits`], n[`${t}Shift`]);
}
function nt(e, t, n) {
	let r = e.params[`${t}Custom`] ? e.params[`${t}Pattern`] : J(e, t).reduce((e, t, n) => e | (t ? 1 << n : 0), 0);
	return {
		...e.params,
		[`${t}Custom`]: 1,
		[`${t}Pattern`]: r ^ 1 << n
	};
}
function rt(e, t) {
	let n = e.params;
	if (n[`${t}Hits`]) return { [`${t}Custom`]: 0 };
	let r = n[`${t}Custom`] ? J(e, t).filter(Boolean).length : 0;
	return {
		[`${t}Custom`]: 0,
		[`${t}Hits`]: r || Math.max(1, Math.round(n[`${t}Steps`] * 3 / 8))
	};
}
var it = (e, t) => !!e.params[`${t}Custom`] || !e.params[`${t}Hits`], at = (e) => [
	"performance",
	"oscillator",
	"monarch",
	"oracle",
	"aurora",
	"prism",
	"strike",
	"noise",
	"boom",
	"punch",
	"orbit",
	"forge"
].includes(e), ot = (e) => [
	"oracle",
	"aurora",
	"prism"
].includes(e), st = (e) => e === "performance" || !!U[e].drum;
function ct(e, t) {
	let n = /* @__PURE__ */ new Set([t]);
	for (let t of n) for (let r of e.cables) r.from.moduleId === t && G(e, r.from)?.kind === "audio" && n.add(r.to.moduleId);
	return n;
}
function lt(e, t) {
	let n = e.modules.find((e) => e.id === t);
	if (n?.type === "performance" || n?.type === "skitter") {
		let n = /* @__PURE__ */ new Set([t]);
		for (let t of n) for (let r of e.cables) r.from.moduleId === t && G(e, r.from)?.kind !== "audio" && n.add(r.to.moduleId);
		return [...n].some((n) => n !== t && lt(e, n));
	}
	let r = ct(e, t);
	return e.modules.some((e) => e.type === "output" && r.has(e.id));
}
function ut(e, t, n, r = null) {
	let i = qe(e, t, n);
	if (!i) throw Error("Connect an output to an input.");
	if (!r) return Ke(e, i.from, i.to);
	let a = e.cables.find((e) => e.id === r);
	return a && K(a.from, i.from) && K(a.to, i.to) ? e : Ye(e, r, i.from, i.to);
}
var dt = {
	muted: /* @__PURE__ */ new Set(),
	soloed: /* @__PURE__ */ new Set()
}, ft = (e, t) => `${e}:${t}`, pt = (e, t) => `${e}:step:${t}`, mt = /* @__PURE__ */ new Set([
	"oscillator",
	"noise",
	"boom",
	"punch",
	"orbit",
	"monarch",
	"oracle",
	"aurora",
	"prism",
	"strike",
	"forge"
]), ht = (e) => mt.has(e);
function gt(e, t) {
	let n = /* @__PURE__ */ new Set([t]);
	for (let t of n) for (let r of e.cables) r.from.moduleId === t && G(e, r.from)?.kind !== "audio" && n.add(r.to.moduleId);
	return n.delete(t), e.modules.filter((t) => mt.has(t.type) && [...ct(e, t.id)].some((e) => n.has(e))).map((e) => e.id);
}
function _t(e, t) {
	let n = new Set(e.modules.map((e) => e.id)), r = new Set([...t.soloed].filter((e) => n.has(e)));
	for (let t of r) for (let n of e.cables) n.from.moduleId === t && G(e, n.from)?.kind !== "audio" && r.add(n.to.moduleId);
	let i = (t, n = /* @__PURE__ */ new Set()) => r.has(t) ? !0 : !n.has(t) && (n.add(t), e.cables.some((e) => e.from.moduleId === t && e.to.portId !== "chain" && i(e.to.moduleId, n)));
	return Object.fromEntries(e.modules.filter((e) => e.type !== "output").map((e) => [e.id, !t.muted.has(e.id) && (!r.size || !mt.has(e.type) || i(e.id))]));
}
var vt = (e) => U[e].drum?.voices.map((e) => e.id) ?? (e === "mixer" ? xe : []);
function Y(e, t, n) {
	let r = vt(e.type).some((t) => n.soloed.has(ft(e.id, t)));
	return !n.muted.has(ft(e.id, t)) && (!r || n.soloed.has(ft(e.id, t)));
}
function yt(e, t, n) {
	return !n.muted.has(pt(e, t)) && (!Array.from({ length: 16 }, (t, n) => pt(e, n)).some((e) => n.soloed.has(e)) || n.soloed.has(pt(e, t)));
}
function bt(e, t, n) {
	let r = [], i = We(e, {
		moduleId: t,
		portId: n
	});
	for (; i;) {
		let t = e.modules.find((e) => e.id === i.from.moduleId);
		if (!t || r.includes(t) || (r.unshift(t), mt.has(t.type) || t.type === "mixer")) break;
		let n = U[t.type].ports.filter((e) => e.direction === "in" && e.kind === "audio");
		i = n.length === 1 ? We(e, {
			moduleId: t.id,
			portId: n[0].id
		}) : void 0;
	}
	return r;
}
function xt(e, t) {
	let n = U[t.type].name;
	return e.modules.filter((e) => e.type === t.type).length > 1 ? `${n} #${e.modules.findIndex((e) => e.id === t.id) + 1}` : n;
}
function St(e, t, n) {
	let r = bt(e, t, n), i = n.toUpperCase();
	return {
		source: r.length ? xt(e, r[0]) : `Channel ${i}`,
		tooltip: r.map((t) => xt(e, t)).join(" → "),
		connected: r.length > 0
	};
}
function Ct(e, t, n) {
	let r = new Set(e.muted), i = new Set(e.soloed), [a, o] = n === "muted" ? [r, i] : [i, r];
	return a.delete(t) || (a.add(t), o.delete(t)), {
		muted: r,
		soloed: i
	};
}
var wt = (e, t) => t === e.id || t.startsWith(`${e.id}:`), Tt = (e, t) => [...t.muted, ...t.soloed].some((t) => wt(e, t));
function Et(e, t) {
	return Tt(t, e) ? {
		muted: new Set([...e.muted].filter((e) => !wt(t, e))),
		soloed: new Set([...e.soloed].filter((e) => !wt(t, e)))
	} : e;
}
var Dt = [
	"Vintage Bass",
	"Vintage Lead",
	"Boom Bap",
	"Late Night Hip-Hop",
	"Roots Reggae",
	"Dub Session",
	"Trap Soul",
	"Broken Beat",
	"Orbit Percussion"
], Ot = [
	"Neon Skyline",
	"Digital Boogie",
	"Midnight Ballad",
	"New Wave Motion",
	"Glass Arcade",
	"Analog Sunrise"
], kt = [
	"French Touch",
	"Distortion Disco",
	"Electro Pogo",
	"Electroclash"
], At = [
	"High Dive",
	"Undertow",
	"Deep End"
], jt = ["Rust Machine", "Dead Highway"], Mt = [
	...At,
	"Trap Soul",
	"Late Night Hip-Hop",
	"Boom Bap"
], Nt = Dt.filter((e) => !Mt.includes(e)), Pt = [
	...Mt,
	"Groove",
	"House",
	...Nt,
	...Ot,
	...kt,
	...jt
], X = (e, t) => e.includes(t);
function Ft(e = "High Dive") {
	if (X(At, e)) return ce(e);
	if (X(jt, e)) return le(e);
	if (X(kt, e)) return ne(e);
	if (X(Ot, e)) return ee(e);
	if (X(Dt, e)) return E(e);
	let t = e === "Groove" ? ["boom", "orbit"] : ["punch"], n = [
		"performance",
		"oscillator",
		"filter",
		"amplifier",
		"equalizer",
		"envelope",
		"lfo",
		"delay",
		...t,
		"output"
	].map((e) => W(e, e)), r = (e) => n.find((t) => t.type === e);
	e === "Groove" ? (Object.assign(r("envelope").params, {
		decay: .16,
		sustain: .3
	}), Object.assign(r("equalizer").params, {
		hpf: 30,
		lfGain: 2,
		lfFreq: 90,
		lmfGain: -3,
		lmfFreq: 350,
		hmfGain: 2.5,
		hmfFreq: 1500,
		lpf: 1e4
	}), r("delay").params.mix = .15) : (r("oscillator").params.wave = 3, Object.assign(r("filter").params, {
		cutoff: 900,
		resonance: 5
	}), Object.assign(r("envelope").params, {
		attack: .002,
		decay: .14,
		sustain: 0,
		release: .08
	}), Object.assign(r("equalizer").params, {
		hpf: 40,
		lfGain: 2,
		lfFreq: 70,
		lfBell: 1,
		lmfGain: -3,
		lmfFreq: 300,
		hmfGain: 2,
		hmfFreq: 2e3,
		lpf: 12e3
	}), r("delay").params.mix = .12);
	let i = [
		36,
		36,
		43,
		36,
		48,
		36,
		46,
		43,
		36,
		36,
		43,
		48,
		46,
		43,
		38,
		43
	], a = (t) => e === "House" ? t % 4 != 0 : t !== 1 && t !== 9, o = {
		version: 1,
		name: e,
		modules: n,
		cables: [],
		sequencer: {
			bpm: e === "Groove" ? 94 : 124,
			swing: e === "Groove" ? .12 : 0,
			steps: i.map((e, t) => ({
				enabled: a(t),
				note: e,
				velocity: t % 4 == 0 ? 1 : .75,
				gate: .65
			}))
		}
	}, s = ["delay", ...t];
	for (let [e, n, r, i, a] of [
		[
			"oscillator",
			"out",
			"filter",
			"in",
			1
		],
		[
			"filter",
			"out",
			"amplifier",
			"in",
			1
		],
		[
			"amplifier",
			"out",
			"equalizer",
			"in",
			1
		],
		[
			"equalizer",
			"out",
			"delay",
			"in",
			1
		],
		...t.map((e, t) => [
			s[t],
			"out",
			e,
			"chain",
			1
		]),
		[
			s.at(-1),
			"out",
			"output",
			"in",
			1
		],
		[
			"performance",
			"pitch",
			"oscillator",
			"pitch",
			1
		],
		[
			"performance",
			"gate",
			"envelope",
			"gate",
			1
		],
		[
			"envelope",
			"out",
			"amplifier",
			"cv",
			1
		],
		[
			"lfo",
			"out",
			"filter",
			"cv",
			.12
		]
	]) o = Ke(o, {
		moduleId: e,
		portId: n
	}, {
		moduleId: r,
		portId: i
	}, a);
	return o;
}
function It(e) {
	return JSON.stringify(e, null, 2);
}
function Lt(e) {
	let t = e.cables.map((e) => JSON.stringify([
		e.from.moduleId,
		e.from.portId,
		e.to.moduleId,
		e.to.portId,
		e.amount
	])).sort();
	return JSON.stringify({
		name: e.name,
		modules: e.modules,
		sequencer: e.sequencer,
		cables: t
	});
}
function Rt(e) {
	if (e.length > 1e6) throw Error("Patch files must be smaller than 1 MB.");
	let t = JSON.parse(e), n = (e) => typeof e == "object" && !!e && !Array.isArray(e), r = () => {
		throw Error("This is not a valid Rackloose v1 patch.");
	}, i = (e) => !Array.isArray(e) || e.length !== 16 ? r() : e.map((e) => !n(e) || typeof e.enabled != "boolean" || typeof e.note != "number" || !Number.isInteger(e.note) || e.note < 24 || e.note > 96 || typeof e.velocity != "number" || !Number.isFinite(e.velocity) || e.velocity < 0 || e.velocity > 1 || typeof e.gate != "number" || !Number.isFinite(e.gate) || e.gate < .1 || e.gate > .95 ? r() : {
		enabled: e.enabled,
		note: e.note,
		velocity: e.velocity,
		gate: e.gate
	});
	if (!n(t) || t.version !== 1 || typeof t.name != "string" || t.name.length > 100 || !Array.isArray(t.modules) || !Array.isArray(t.cables) || !n(t.sequencer) || t.modules.length < 2 || t.modules.length > 32 || t.cables.length > 128) return r();
	let a = /* @__PURE__ */ new Set(), o = t.modules.map((e, t) => {
		if (!n(e) || typeof e.id != "string" || !/^[\w-]{1,80}$/.test(e.id) || a.has(e.id) || typeof e.type != "string" || !Object.hasOwn(U, e.type) || !n(e.params)) return r();
		a.add(e.id);
		let o = e.type, s = e.params, c = Object.fromEntries(U[o].params.map((e) => {
			let t = s[e.id] === void 0 ? e.legacyFrom !== void 0 && s[e.legacyFrom] !== void 0 ? s[e.legacyFrom] : e.legacyDefault : s[e.id];
			return typeof t != "number" || !Number.isFinite(t) || t < e.min || t > e.max || (e.choices || e.pattern) && !Number.isInteger(t) ? r() : [e.id, t];
		}));
		return o === "performance" && t > 0 ? {
			id: e.id,
			type: o,
			params: c,
			steps: i(e.steps)
		} : {
			id: e.id,
			type: o,
			params: c
		};
	});
	if (o[0].type !== "performance" || o.filter((e) => e.type === "output").length !== 1 || o.at(-1)?.type !== "output") return r();
	let s = t.sequencer;
	if (typeof s.bpm != "number" || !Number.isFinite(s.bpm) || s.bpm < 40 || s.bpm > 240 || typeof s.swing != "number" || !Number.isFinite(s.swing) || s.swing < 0 || s.swing > .6) return r();
	let c = i(s.steps), l = {
		version: 1,
		name: t.name,
		modules: o,
		cables: [],
		sequencer: {
			bpm: s.bpm,
			swing: s.swing,
			steps: c
		}
	}, u = /* @__PURE__ */ new Set();
	for (let e of t.cables) {
		if (!n(e) || typeof e.id != "string" || !/^[\w-]{1,80}$/.test(e.id) || u.has(e.id) || !n(e.from) || !n(e.to) || typeof e.from.moduleId != "string" || typeof e.from.portId != "string" || typeof e.to.moduleId != "string" || typeof e.to.portId != "string" || typeof e.amount != "number" || !Number.isFinite(e.amount) || e.amount < -1 || e.amount > 1) return r();
		u.add(e.id);
		let t = {
			moduleId: e.from.moduleId,
			portId: e.from.portId
		}, i = {
			moduleId: e.to.moduleId,
			portId: e.to.portId
		}, a = G(l, t);
		if (a && l.cables.some((e) => K(e.from, t))) {
			let e = U[l.modules.find((e) => e.id === t.moduleId).type].ports.find((e) => (e.copyOf ?? e.id) === (a.copyOf ?? a.id) && !l.cables.some((n) => K(n.from, {
				moduleId: t.moduleId,
				portId: e.id
			})));
			if (!e) continue;
			t.portId = e.id;
		}
		if (Ge(l, t, i) || G(l, t)?.kind !== "cv" && e.amount !== 1) return r();
		l = {
			...l,
			cables: [...l.cables, {
				id: e.id,
				from: t,
				to: i,
				amount: e.amount
			}]
		};
	}
	return l;
}
function zt(e, t) {
	try {
		let n = e.getItem(t);
		return {
			patch: n ? Rt(n) : null,
			error: null
		};
	} catch {
		return {
			patch: null,
			error: "Saved patch unavailable. You can still play and export patch files."
		};
	}
}
function Bt(e, t, n) {
	try {
		return e.setItem(t, It(n)), null;
	} catch {
		return "Local save unavailable. Export a patch file to keep your work.";
	}
}
var Vt = (e, t) => e.logarithmic ? Math.log(t / e.min) / Math.log(e.max / e.min) : (t - e.min) / (e.max - e.min), Ht = [
	"C",
	"C♯",
	"D",
	"D♯",
	"E",
	"F",
	"F♯",
	"G",
	"G♯",
	"A",
	"A♯",
	"B"
], Ut = (e) => `${Ht[e % 12]}${Math.floor(e / 12) - 1}`, Wt = class {
	notes = /* @__PURE__ */ new Map();
	press(e, t) {
		return this.notes.delete(e), this.notes.set(e, t), this.current;
	}
	release(e) {
		return this.notes.delete(e), this.current;
	}
	clear() {
		this.notes.clear();
	}
	has(e) {
		return this.notes.has(e);
	}
	get current() {
		return [...this.notes.values()].at(-1) ?? null;
	}
	get entries() {
		return [...this.notes];
	}
}, Gt = (e, t, n) => 60 / e / 4 * (n % 2 == 0 ? 1 + t : 1 - t);
function Kt(e, t, n = 0) {
	let r = [], i = n;
	for (let n = 0; n < t * 16; n++) {
		let t = n % 16, a = Gt(e.sequencer.bpm, e.sequencer.swing, t);
		r.push({
			step: e.sequencer.steps[t],
			index: t,
			time: i,
			duration: a
		}), i += a;
	}
	return {
		events: r,
		duration: i - n
	};
}
var qt = () => ({
	past: [],
	future: [],
	key: null,
	at: 0
});
function Jt(e, t, n, r) {
	return n !== null && n === e.key && r - e.at < 1e3 && !e.future.length ? {
		...e,
		at: r
	} : {
		past: [...e.past, t].slice(-50),
		future: [],
		key: n,
		at: r
	};
}
function Yt(e, t) {
	let n = e.past.at(-1);
	return n === void 0 ? null : {
		state: n,
		history: {
			past: e.past.slice(0, -1),
			future: [t, ...e.future],
			key: null,
			at: 0
		}
	};
}
function Xt(e, t) {
	let [n, ...r] = e.future;
	return n === void 0 ? null : {
		state: n,
		history: {
			past: [...e.past, t].slice(-50),
			future: r,
			key: null,
			at: 0
		}
	};
}
var Zt = "This browser could not save to My Presets. Export a file to keep your work.", Qt = 100, $t = (e, t) => e.trim().toLocaleLowerCase() === t.trim().toLocaleLowerCase(), en = (e, t) => e.patch.name.localeCompare(t.patch.name, void 0, {
	sensitivity: "base",
	numeric: !0
}) || e.savedAt - t.savedAt;
function tn(e, t) {
	try {
		let n = e.getItem(t);
		if (!n) return {
			presets: [],
			error: null
		};
		let r = JSON.parse(n);
		if (typeof r != "object" || !r || !("presets" in r) || !Array.isArray(r.presets)) throw Error("Not a preset list");
		let i = [], a = /* @__PURE__ */ new Set();
		for (let e of r.presets.slice(0, 200)) try {
			if (typeof e != "object" || !e) continue;
			let { id: t, savedAt: n, patch: r } = e;
			if (typeof t != "string" || !/^[\w-]{1,80}$/.test(t) || a.has(t) || typeof n != "number" || !Number.isFinite(n)) continue;
			let o = Rt(JSON.stringify(r));
			if (i.some((e) => $t(e.patch.name, o.name))) continue;
			a.add(t), i.push({
				id: t,
				savedAt: n,
				patch: o
			});
		} catch {}
		return {
			presets: i.sort(en),
			error: null
		};
	} catch {
		return {
			presets: [],
			error: "My Presets could not be read. Export files to keep your presets."
		};
	}
}
function nn(e, t, n) {
	try {
		return e.setItem(t, JSON.stringify({
			version: 1,
			presets: n
		})), null;
	} catch {
		return Zt;
	}
}
function rn(e, t) {
	return [...e.filter((e) => e.id !== t.id && !$t(e.patch.name, t.patch.name)), t].sort(en);
}
var an = (e, t, n) => e.find((e) => e.id !== n && $t(e.patch.name, t));
function on(e, t) {
	for (let n = 1;; n++) {
		let r = n === 1 ? "" : ` (${n})`, i = `${t.slice(0, Qt - r.length).trimEnd()}${r}`;
		if (!an(e, i)) return i;
	}
}
function sn(e) {
	return e.trim().toLowerCase().replace(/[^a-z0-9_-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80).replace(/-+$/, "") || "rackloose-patch";
}
//#endregion
//#region src/audio/hold.ts
var cn = /* @__PURE__ */ new WeakMap(), ln = 64;
function un(e, t, n) {
	let r = () => t, i = 0;
	for (let t of e) if (t.type === "ramp") {
		if (t.time > n) {
			let e = r(i);
			return e + (t.value - e) * (n - i) / (t.time - i);
		}
		r = () => t.value, i = t.time;
	} else {
		if (t.time > n) break;
		let e = r(t.time), a = t.time;
		r = t.type === "set" ? () => t.value : (n) => t.value + (e - t.value) * Math.exp(-(n - a) / t.constant), i = t.time;
	}
	return r(n);
}
function dn(e, t) {
	if (typeof e.cancelAndHoldAtTime == "function" || cn.has(e)) return e;
	let n = [], { setValueAtTime: r, linearRampToValueAtTime: i, setTargetAtTime: a, cancelScheduledValues: o } = e, s, c = (r) => {
		s ??= e.value;
		let i = n.length;
		for (; i && n[i - 1].time > r.time;) i--;
		if (n.splice(i, 0, r), t && n.length > ln) {
			let e = -1;
			for (let r = 0; r < n.length && n[r].time <= t.currentTime - 1; r++) n[r].type !== "ramp" && (e = r);
			e > 0 && (s = un(n.slice(0, e), s, n[e].time), n.splice(0, e));
		}
	};
	return Object.assign(e, {
		setValueAtTime(t, n) {
			return c({
				type: "set",
				time: n,
				value: t,
				constant: 0
			}), r.call(e, t, n);
		},
		linearRampToValueAtTime(t, n) {
			return c({
				type: "ramp",
				time: n,
				value: t,
				constant: 0
			}), i.call(e, t, n);
		},
		setTargetAtTime(t, n, r) {
			return c({
				type: "target",
				time: n,
				value: t,
				constant: r
			}), a.call(e, t, n, r);
		},
		cancelScheduledValues(t) {
			return n.splice(0, n.length, ...n.filter((e) => e.time < t)), o.call(e, t);
		}
	}), cn.set(e, {
		events: n,
		hold: (t) => {
			let r = un(n, s ?? e.value, t), i = n.find((e) => e.time >= t);
			e.cancelScheduledValues(t), i?.type === "ramp" ? e.linearRampToValueAtTime(r, t) : e.setValueAtTime(r, t);
		}
	}), e;
}
function fn(e, t) {
	if (typeof e.cancelAndHoldAtTime == "function") {
		e.cancelAndHoldAtTime(t);
		return;
	}
	let n = cn.get(e)?.hold;
	if (n) n(t);
	else {
		let n = e.value;
		e.cancelScheduledValues(t), e.setValueAtTime(n, t);
	}
}
//#endregion
//#region src/audio/drums.ts
var pn = [
	205.3,
	304.4,
	369.6,
	522.7,
	540,
	800
], mn = (e) => 2 ** (e / 12);
function hn(e, t, n, { keep: r, start: i, noise: a }) {
	let o = /* @__PURE__ */ new Set(), s = /* @__PURE__ */ new Map(), c = (t = 0, i = n) => {
		let a = r(e.createGain());
		return a.gain.value = t, a.connect(i), a;
	}, l = /* @__PURE__ */ new Set(), u = (e, t, n) => {
		l.add(e), e.setValueAtTime(t, n);
	}, d = /* @__PURE__ */ new Map(), f = (t) => {
		let n = d.get(t);
		return n || (n = r(e.createStereoPanner()), n.channelCount = 1, n.channelCountMode = "explicit", n.connect(c(Math.SQRT2)), d.set(t, n)), n;
	}, p = (t, n, i = .7) => {
		let a = r(e.createBiquadFilter());
		return a.type = t, a.frequency.value = n, a.Q.value = i, a;
	}, m = (...e) => (e.reduce((e, t) => e.connect(t)), e.at(-1)), h = null, g = () => (h || (h = i(e.createBufferSource()), h.buffer = a, h.loop = !0), h), _ = (t, n) => {
		let a = r(e.createGain());
		return a.gain.value = n, {
			sum: a,
			oscillators: t.map((t) => {
				let n = i(e.createOscillator());
				return n.type = "square", n.frequency.value = t, n.connect(a), n;
			})
		};
	}, v = (e, t, ...n) => {
		let r = c(0, f(e)), i = n.map((e) => e.frequency.value);
		return m(t, ...n, r), {
			gain: r.gain,
			tune: (e, t) => n.forEach((n, r) => u(n.frequency, i[r] * e, t))
		};
	}, y = /* @__PURE__ */ new Map(), b = (t, n, r, i, a = 5e-4) => {
		dn(t, e);
		let o = y.get(t) ?? [], s = o.filter((t) => t.time < e.currentTime).at(-1);
		y.set(t, [
			...s ? [s] : [],
			...o.filter((t) => t.time >= e.currentTime),
			{
				time: n,
				peak: r,
				decay: i,
				rise: a
			}
		].sort((e, t) => e.time - t.time)), t.setTargetAtTime(r, n, a), t.setTargetAtTime(0, n + a * 5, i / 4.6);
	}, x = (e, t) => e.setTargetAtTime(0, t, .003);
	function S(e) {
		if (o.delete(e)) {
			for (let t of [
				...e.sources,
				...e.nodes,
				e.vca
			]) t.disconnect();
			s.get(e.voice) === e && s.delete(e.voice);
		}
	}
	function C(t, n, r, i, a, c = f(t)) {
		let l = e.createGain(), u = [];
		l.gain.value = 0, dn(l.gain, e), l.connect(c);
		let d = {
			voice: t,
			vca: l,
			nodes: u,
			sources: a(l, u),
			start: n,
			end: n + i * 1.25 + .05,
			naturalEnd: n + i * 1.25 + .05,
			decay: i
		};
		l.gain.setValueAtTime(0, n), l.gain.linearRampToValueAtTime(r, n + .0015), l.gain.setTargetAtTime(0, n + .0015, i / 4.6);
		for (let e of d.sources) e.start(n), e.stop(d.end);
		d.sources[0].onended = () => S(d), o.add(d);
		let p = s.get(t), [m, h] = p && p.start > n ? [d, p] : [p, d];
		if (s.set(t, h), m && o.has(m) && m.end > h.start) {
			m.vca.gain.setTargetAtTime(0, h.start, .002), m.end = h.start + .03, m.chokeAt = h.start;
			for (let e of m.sources) e.stop(m.end);
		}
	}
	let w = (t, n, r, i, a = 1) => {
		let o = e.createOscillator();
		if (o.type = r, o.frequency.value = i, a === 1) o.connect(t);
		else {
			let r = e.createGain();
			r.gain.value = a, o.connect(r).connect(t), n.push(r);
		}
		return o;
	}, T = (e, t, n, r, i) => {
		e.frequency.setValueAtTime(n * r, t), e.frequency.exponentialRampToValueAtTime(n, t + i);
	}, E = () => {};
	if (t === "boom") {
		let e = v("snare", g(), p("highpass", 1800)), t = v("rim", g(), p("highpass", 5e3)), n = v("clap", g(), p("bandpass", 1e3, 1.4)), r = _(pn, .5).sum, i = p("highpass", 5e3), a = v("hat", r, p("bandpass", 1e4, 1), p("highpass", 7e3)), o = v("open", r, p("bandpass", 1e4, 1), p("highpass", 7e3)), s = v("crash", r, p("bandpass", 7e3, .5), i);
		m(g(), c(.35, i));
		let l = v("ride", _(pn.map((e) => e * 1.13), .5).sum, p("bandpass", 4800, 2.5), p("highpass", 3e3)), u = _([540, 800], .5), d = v("bell", u.sum, p("bandpass", 2640, 1.4)), f = (e, t, n, r, i) => C(e, t, .9 * i, r, (e, r) => {
			let i = w(e, r, "sine", n), a = w(e, r, "triangle", n * 1.5, .15);
			return T(i, t, n, 1.6, .06), T(a, t, n * 1.5, 1.6, .06), [i, a];
		});
		E = (r, i, c) => {
			let p = c[`${r}Level`] ?? 1;
			if (r === "kick") C("kick", i, p, c.kickDecay, (e) => {
				let t = w(e, [], "sine", c.kickTune);
				return T(t, i, c.kickTune, 2, .025), [t];
			});
			else if (r === "snare") {
				let t = c.snareTone, n = mn(c.snareTune);
				C("snare", i, .55 * p, .65 * c.snareDecay, (e, r) => [w(e, r, "sine", 185 * n, 1 - .6 * t), w(e, r, "sine", 330 * n, .35 + .65 * t)]), b(e.gain, i, .6 * c.snappy * p, c.snareDecay);
			} else if (r === "rim") {
				let e = mn(c.rimTune);
				C("rim", i, .7 * p, c.rimDecay, (t, n) => [w(t, n, "triangle", 455 * e, .6), w(t, n, "triangle", 1667 * e)]), b(t.gain, i, .5 * p, .008 / .03 * c.rimDecay);
			} else if (r === "clap") {
				n.tune(H(c.clapTone, 3), i);
				for (let e of [
					0,
					.01,
					.021
				]) b(n.gain, i + e, 1.4 * p, .016, 4e-4);
				b(n.gain, i + .032, 1.4 * p, c.clapDecay);
			} else if (r === "hat") x(o.gain, i), a.tune(H(c.hatTone, 2), i), b(a.gain, i, 1.25 * p, c.hatDecay);
			else if (r === "open") o.tune(H(c.openTone, 2), i), b(o.gain, i, p, c.openDecay);
			else if (r === "lowTom") f("lowTom", i, 95 * mn(c.tomTune), c.tomDecay, p);
			else if (r === "highTom") f("highTom", i, 145 * mn(c.highTomTune), c.highTomDecay * .85, p);
			else if (r === "crash") s.tune(H(c.crashTone, 2), i), b(s.gain, i, .75 * p, c.crashDecay, .002);
			else if (r === "ride") l.tune(H(c.rideTone, 2), i), b(l.gain, i, .8 * p, c.rideDecay, .001);
			else if (r === "bell") {
				let e = mn(c.bellTune);
				u.oscillators.forEach((t, n) => t.frequency.setValueAtTime([540, 800][n] * e, i)), b(d.gain, i, .9 * p, c.bellDecay);
			}
		};
	} else if (t === "punch") {
		let t = c(1, f("kick")), n = r(e.createWaveShaper()), i = c(1, n), a = c(0, i);
		n.curve = Float32Array.from({ length: 1025 }, (e, t) => Math.tanh(2.2 * (t / 512 - 1)) / Math.tanh(2.2)), n.oversample = "2x", n.connect(t), m(g(), p("lowpass", 4e3), a);
		let o = p("lowpass", 6e3), s = v("snare", g(), p("highpass", 1200), o), l = v("clap", g(), p("bandpass", 1100, 1.6)), d = r(e.createGain());
		m(_(pn.map((e) => e * 1.5), .5).sum, d), m(g(), c(.35, d));
		let h = v("hat", d, p("highpass", 7500)), y = v("open", d, p("highpass", 7500));
		E = (e, n, r) => {
			let c = r[`${e}Level`] ?? 1;
			if (e === "kick") u(t.gain, c, n), C("kick", n, 1, r.kickDecay, (e) => {
				let t = w(e, [], "sine", r.kickTune), i = t.frequency;
				return i.setValueAtTime(r.kickTune * 5, n), i.exponentialRampToValueAtTime(r.kickTune * 1.3, n + .03), i.exponentialRampToValueAtTime(r.kickTune, n + .16), [t];
			}, i), b(a.gain, n, .7 * r.kickClick, .012);
			else if (e === "snare") {
				let e = mn(r.snareTune);
				C("snare", n, .5 * c, .11 / .18 * r.snareDecay, (t, r) => [180, 330].map((i, a) => {
					let o = w(t, r, "triangle", i * e, a ? .6 : 1);
					return T(o, n, i * e, 1.15, .02), o;
				})), u(o.frequency, 3e3 + 7e3 * r.snareTone, n), b(s.gain, n, .75 * r.snappy * c, r.snareDecay);
			} else if (e === "clap") {
				l.tune(H(r.clapTone, 3), n);
				for (let e of [
					0,
					.011,
					.022
				]) b(l.gain, n + e, 1.5 * c, .018, 4e-4);
				b(l.gain, n + .033, 1.5 * c, r.clapDecay);
			} else e === "hat" ? (x(y.gain, n), h.tune(H(r.hatTone, 2), n), b(h.gain, n, .9 * c, r.hatDecay)) : e === "open" && (y.tune(H(r.openTone, 2), n), b(y.gain, n, .75 * c, r.openDecay));
		};
	} else if (t === "orbit") {
		let e = p("bandpass", 6500, 1.2), t = c(0, f("sand")), n = p("highpass", 4500), r = c(0, f("shaker"));
		m(g(), e, p("highpass", 3e3), t), m(g(), n, r), E = (i, a, o) => {
			let s = mn(o.pitch + o[`${i}Tune`]), c = o[`${i}Decay`], l = o[`${i}Level`], d = o[`${i}Tone`];
			i === "skin" || i === "tom" ? C(i, a, (i === "skin" ? .8 : .95) * l, c, (e, t) => {
				let n = (i === "skin" ? 196 : 98) * s, r = w(e, t, "sine", n), o = w(e, t, "sine", n * (i === "skin" ? 311 / 196 : 1.5), d * .5);
				return T(r, a, n, i === "skin" ? 1.4 : 2.2, .035), T(o, a, n * (i === "skin" ? 311 / 196 : 1.5), 1.4, .035), [r, o];
			}) : i === "wood" ? C("wood", a, .6 * l, c, (e, t) => {
				let n = w(e, t, "sine", 1450 * s), r = w(e, t, "sine", 3915 * s, d * .6);
				return T(n, a, 1450 * s, 1.05, .005), [n, r];
			}) : i === "sand" ? (u(e.frequency, Math.min(18e3, 6500 * s * (.5 + d)), a), b(t.gain, a, .9 * l, c, .004)) : i === "shaker" ? (u(n.frequency, Math.min(16e3, (1500 + d * 6e3) * s), a), b(r.gain, a, .65 * l, c, .008)) : i === "metal" && C("metal", a, .3 * l, c, (e, t) => [
				440,
				623,
				1067,
				1573
			].map((n, r) => w(e, t, r ? "sine" : "triangle", n * s, r ? .15 + d * .7 : 1)));
		};
	}
	return {
		trigger(e, t, n, r) {
			u(f(e).pan, n[`${e}Pan`] ?? 0, t), E(e, t, n, r);
		},
		cancelScheduled(e) {
			for (let t of [...o]) if (t.start >= e) {
				for (let n of t.sources) n.stop(e);
				S(t);
			}
			s.clear();
			for (let t of o) {
				if (t.chokeAt !== void 0 && t.chokeAt >= e) {
					fn(t.vca.gain, e), t.vca.gain.setTargetAtTime(0, e, t.decay / 4.6), t.end = t.naturalEnd, t.chokeAt = void 0;
					for (let e of t.sources) e.stop(t.end);
				}
				(!s.has(t.voice) || s.get(t.voice).start < t.start) && s.set(t.voice, t);
			}
			for (let t of l) t.cancelScheduledValues(e);
			for (let [t, n] of y) {
				let r = n.filter((t) => t.time < e).at(-1);
				fn(t, e), r ? t.setTargetAtTime(0, Math.max(e, r.time + r.rise * 5), r.decay / 4.6) : t.setValueAtTime(0, e), y.set(t, r ? [r] : []);
			}
		},
		dispose() {
			for (let e of o) for (let t of e.sources) t.stop();
			for (let e of [...o]) S(e);
			s.clear();
		}
	};
}
//#endregion
//#region src/audio/strike.ts
var gn = 28e3, _n = /* @__PURE__ */ new Map();
function Z(e) {
	let t = _n.get(e);
	if (t) return t;
	let n = ye.findIndex((t) => t.id === e);
	if (n < 0) throw Error(`Unknown STRIKE voice: ${e}`);
	let r = [
		"crash",
		"ride",
		"open"
	].includes(e), i = Math.ceil(gn * (r ? 3 : 1.5)), a = new Float32Array(i), o = 7103 + n * 197, s = 0, c = 0, l = 0, u = (e, t) => Math.sin(2 * Math.PI * e * t), d = {
		lowTom: 100,
		midTom: 142,
		highTom: 195,
		lowConga: 210,
		highConga: 310
	};
	for (let t = 0; t < i; t++) {
		o ^= o << 13, o ^= o >>> 17, o ^= o << 5;
		let n = (o >>> 0) / 2 ** 31 - 1, r = t / gn;
		s = .65 * s + .35 * n;
		let f = n - c;
		c = n;
		let p = 0;
		if (e === "kick") l += 2 * Math.PI * (54 + 120 * Math.exp(-r * 80)) / gn, p = Math.sin(l) * Math.exp(-r * 9) + .28 * s * Math.exp(-r * 170) + .1 * u(105, r) * Math.exp(-r * 25);
		else if (e === "snare") p = (.55 * u(185, r) + .28 * u(331, r)) * Math.exp(-r * 25) + .75 * (n - s) * Math.exp(-r * 15);
		else if (e === "rim") p = (u(420, r) + .65 * u(1750, r) + .35 * u(3100, r)) * Math.exp(-r * 85) + n * .25 * Math.exp(-r * 300);
		else if (e === "clap") {
			let e = [
				0,
				.011,
				.024
			].reduce((e, t) => e + (r >= t ? Math.exp(-(r - t) * 230) : 0), 0);
			p = (n - s) * (e + (r > .035 ? .65 * Math.exp(-(r - .035) * 16) : 0));
		} else if (e in d) {
			let t = d[e], n = e.includes("Conga");
			l += 2 * Math.PI * t * (1 + .55 * Math.exp(-r * 55)) / gn, p = (Math.sin(l) + .3 * u(t * (n ? 2.14 : 1.59), r)) * Math.exp(-r * (n ? 14 : 8)) + .22 * s * Math.exp(-r * 95);
		} else if (e === "bell") p = (u(540, r) + .65 * u(800, r) + .22 * u(1620, r)) * Math.exp(-r * 11);
		else {
			let t = [
				3421,
				4517,
				5683,
				7129,
				9181
			].reduce((t, n, i) => t + u(n * (e === "ride" ? .68 : 1), r) / (i + 2), 0), n = e === "hat" ? 34 : e === "open" ? 5 : e === "crash" ? 1.8 : e === "ride" ? 2.3 : e === "cabasa" ? 32 : 16;
			p = ((e === "cabasa" ? 0 : .4) * t + (e === "ride" ? .2 : .65) * f) * Math.exp(-r * n), e === "tambourine" && (p *= .65 + .35 * u(85, r)), e === "crash" && (p *= Math.min(1, r * 180));
		}
		let m = Math.tanh(p), h = Math.sign(m) * Math.log1p(255 * Math.abs(m)) / Math.log(256), g = Math.round(h * 127) / 127;
		a[t] = Math.sign(g) * Math.expm1(Math.abs(g) * Math.log(256)) / 255 * Math.min(1, t / 12) * Math.min(1, (i - 1 - t) / 128);
	}
	return _n.set(e, a), a;
}
var vn = {
	rate: gn,
	sample: Z,
	chokedBy: { open: ["hat"] }
}, yn = (e, t) => bn(e, t, vn);
function bn(e, t, { rate: n, sample: r, chokedBy: i = {}, peak: a = 1.6, tone: o = (e) => 700 * 20 ** e }) {
	let s = /* @__PURE__ */ new Map(), c = /* @__PURE__ */ new Set(), l = (e) => [e, ...i[e] ?? []], u = (e) => {
		if (c.delete(e)) for (let t of [
			e.source,
			e.gain,
			e.filter,
			e.pan
		]) t.disconnect();
	};
	function d(t) {
		let n = e.currentTime, r = /* @__PURE__ */ new Map();
		for (let e of c) {
			let t = r.get(e.voice) ?? [];
			t.push(e), r.set(e.voice, t);
		}
		for (let e of r.values()) e.sort((e, t) => e.start - t.start);
		for (let [e, i] of r) if (!t || l(e).includes(t)) for (let t of i) {
			let i = l(e).flatMap((e) => r.get(e) ?? []).filter((n) => n.start > t.start || n.voice !== e && n.start === t.start).reduce((e, t) => !e || t.start < e.start ? t : e, void 0)?.start ?? Infinity, a = t.gain.gain, o = (e) => t.peak * Math.min(1, Math.max(0, e - t.start) / .001) * Math.exp(-Math.max(0, e - t.start - .001) * 4.6 / t.decay);
			a.cancelScheduledValues(n), n < t.start + .001 ? (a.setValueAtTime(o(n), n), a.setValueAtTime(0, Math.max(n, t.start)), a.linearRampToValueAtTime(t.peak, t.start + .001)) : a.setValueAtTime(i < n ? o(i) * Math.max(0, 1 - (n - i) / .004) : o(n), n), a.setTargetAtTime(0, Math.max(n, t.start + .001), t.decay / 4.6), i >= n && i < t.end && (a.cancelScheduledValues(i), a.setValueAtTime(o(i), i), a.linearRampToValueAtTime(0, i + .004)), t.source.stop(Math.max(n, Math.min(t.end, i + .005)));
		}
	}
	return {
		trigger(i, l, f, p = 1) {
			let m = s.get(i);
			if (!m) {
				let t = r(i);
				m = e.createBuffer(1, t.length, n), m.copyToChannel(new Float32Array(t), 0), s.set(i, m);
			}
			let h = e.createBufferSource(), g = e.createGain(), _ = e.createBiquadFilter(), v = e.createStereoPanner();
			h.buffer = m, h.playbackRate.value = 2 ** (f[`${i}Tune`] / 12), _.type = "lowpass", _.frequency.value = Math.min(2e4, o(f[`${i}Tone`])), _.Q.value = -3.01, v.pan.value = f[`${i}Pan`], g.gain.value = 0, h.connect(_).connect(g).connect(v).connect(t);
			let y = {
				voice: i,
				start: l,
				end: l + Math.min(m.duration / h.playbackRate.value, f[`${i}Decay`] * 2) + .01,
				peak: f[`${i}Level`] * a * p,
				decay: f[`${i}Decay`],
				source: h,
				gain: g,
				filter: _,
				pan: v
			};
			h.onended = () => u(y), c.add(y), h.start(l), d(i);
		},
		cancelScheduled(e) {
			for (let t of [...c]) t.start >= e && (t.source.stop(e), u(t));
			d();
		},
		dispose() {
			for (let e of [...c]) e.source.stop(), u(e);
			s.clear();
		}
	};
}
//#endregion
//#region src/audio/poly.ts
function Q(e, t) {
	let n = !1, r;
	return (i, a) => {
		if (clearTimeout(r), r = void 0, i && !n) e.connect(t), n = !0;
		else if (!i && n) {
			let i = () => {
				r = void 0, n = !1;
				try {
					e.disconnect(t);
				} catch {}
			};
			a ? i() : r = setTimeout(i, 100);
		}
	};
}
var xn = class {
	voices;
	constructor(e = 5) {
		this.voices = Array.from({ length: e }, () => ({
			key: null,
			start: -Infinity,
			releaseAt: -Infinity,
			freeAt: -Infinity
		}));
	}
	allocate(e, t = /* @__PURE__ */ new Set()) {
		let n = this.voices.map((e, t) => ({
			voice: e,
			index: t
		})).filter(({ index: e }) => !t.has(e)), r = (e, t) => e.reduce((e, n) => t(n.voice) < t(e.voice) ? n : e).index, i = n.filter(({ voice: t }) => t.freeAt <= e), a = n.filter(({ voice: t }) => t.releaseAt <= e);
		return i.length ? r(i, (e) => e.freeAt) : a.length ? r(a, (e) => e.releaseAt) : r(n, (e) => e.start);
	}
	start(e, t, n) {
		Object.assign(this.voices[e], {
			key: t,
			start: n,
			releaseAt: Infinity,
			freeAt: Infinity
		});
	}
	release(e, t, n) {
		return this.voices.flatMap((r, i) => {
			if (n !== void 0 && r.key !== n || r.releaseAt <= e) return [];
			let a = r.start > e;
			return Object.assign(r, {
				start: Math.min(r.start, e),
				releaseAt: e,
				freeAt: e + t
			}), [{
				index: i,
				pending: a
			}];
		});
	}
}, Sn = (e, t) => Math.sin(2 * Math.PI * e * t);
function Cn(e, t, n) {
	let r = new Float32Array(Math.ceil(e * t));
	return {
		data: r,
		each(t) {
			let i = n, a = 0;
			for (let n = 0; n < r.length; n++) {
				i ^= i << 13, i ^= i >>> 17, i ^= i << 5;
				let o = (i >>> 0) / 2 ** 31 - 1;
				a = .7 * a + .3 * o, r[n] = t(n / e, {
					noise: o,
					low: a,
					high: o - a,
					sin: Sn
				}) * Math.min(1, n / 8) * Math.min(1, (r.length - 1 - n) / 256);
			}
		}
	};
}
function wn(e, t) {
	let n = 0;
	for (let t of e) n = Math.max(n, Math.abs(t));
	if (n > 0) for (let r = 0; r < e.length; r++) e[r] *= t / n;
}
//#endregion
//#region src/audio/forge.ts
var Tn = 44100, En = /* @__PURE__ */ new Map();
function Dn(e, t, n, r) {
	let i = r, a = () => (i = i * 16807 % 2147483647, i / 2147483647);
	return Array.from({ length: e }, () => ({
		frequency: t * (n / t) ** a(),
		level: .4 + a(),
		decay: .6 + a(),
		phase: a() * 2 * Math.PI
	}));
}
function On(e) {
	let t = En.get(e);
	if (t) return t;
	let n = z.findIndex((t) => t.id === e);
	if (n < 0) throw Error(`Unknown FORGE voice: ${e}`);
	let { data: r, each: i } = Cn(Tn, {
		crash: 4,
		china: 3,
		ride: 4,
		open: 2,
		anvil: 2,
		lowTom: 1.6,
		highTom: 1.3,
		kick: 1.2,
		snare: 1
	}[e] ?? .5, 9241 + n * 173), a = {
		hat: [
			26,
			3e3,
			14e3
		],
		pedal: [
			26,
			3e3,
			14e3
		],
		open: [
			30,
			2600,
			13e3
		],
		crash: [
			44,
			1800,
			12500
		],
		china: [
			40,
			1100,
			9e3
		],
		ride: [
			28,
			2400,
			11e3
		]
	}[e], o = a ? Dn(a[0], a[1], a[2], 77 + n * 31) : [], s = o.map((e) => Math.sin(e.phase)), c = o.map((e) => Math.cos(e.phase)), l, u = (e, t) => {
		l ??= o.map((e) => ({
			cos: Math.cos(2 * Math.PI * e.frequency / Tn),
			sin: Math.sin(2 * Math.PI * e.frequency / Tn),
			fall: Math.exp(-t * e.decay / Tn)
		}));
		let n = 0;
		for (let e = 0; e < o.length; e++) {
			let { cos: t, sin: r, fall: i } = l[e], a = s[e], u = c[e];
			n += o[e].level * a, s[e] = (a * t + u * r) * i, c[e] = (u * t - a * r) * i;
		}
		return n / o.length;
	}, d = 0, f = 0;
	return i((t, { noise: n, high: r, sin: i }) => {
		if (f = .55 * f + .45 * r, e === "kick") {
			d += 2 * Math.PI * (52 + 88 * Math.exp(-t * 35)) / Tn;
			let e = Math.sin(d) * Math.exp(-t * 6.5), n = r * Math.exp(-t * 600) + .5 * i(3200, t) * Math.exp(-t * 300);
			return Math.tanh(2.6 * (e + .55 * n));
		}
		if (e === "snare") {
			let e = i(190, t) * Math.exp(-t * 22) + .6 * i(287, t) * Math.exp(-t * 28) + .35 * i(412, t) * Math.exp(-t * 35), r = f * Math.exp(-t * 10), a = n * Math.exp(-t * 220);
			return Math.tanh(1.9 * (.7 * e + 1.1 * r + .6 * a));
		}
		return e === "lowTom" || e === "highTom" ? (d += 2 * Math.PI * (e === "lowTom" ? 82 : 132) * (1 + .3 * Math.exp(-t * 30)) / Tn, Math.tanh(1.5 * ((Math.sin(d) + .25 * Math.sin(1.52 * d)) * Math.exp(-t * (e === "lowTom" ? 4.5 : 5.5)) + .4 * r * Math.exp(-t * 300)))) : e === "anvil" ? [
			[1, 4],
			[2.76, 6],
			[5.4, 9],
			[8.93, 13]
		].reduce((e, [n, r], a) => e + i(520 * n, t) * Math.exp(-t * r) / (a + 1), 0) + .6 * r * Math.exp(-t * 500) : e === "hat" ? .7 * u(t, 40) + .55 * f * Math.exp(-t * 55) + .5 * r * Math.exp(-t * 900) : e === "pedal" ? (.6 * u(t, 30) + .4 * f * Math.exp(-t * 35)) * Math.min(1, t * 400) : e === "open" ? .7 * u(t, 3.2) + .45 * f * Math.exp(-t * 4.5) + .4 * r * Math.exp(-t * 700) : e === "crash" ? (.8 * u(t, 1.3) + .6 * f * Math.exp(-t * 2.2)) * Math.min(1, t * 250) : e === "china" ? (.8 * u(t, 2.2) * (1 + .6 * i(370, t)) + .6 * f * Math.exp(-t * 3)) * Math.min(1, t * 300) : .55 * u(t, 1.1) + (.5 * i(3150, t) + .35 * i(4270, t)) * Math.exp(-t * 4) + .15 * f * Math.exp(-t * 2) + .4 * r * Math.exp(-t * 800);
	}), wn(r, .9), En.set(e, r), r;
}
function kn(e) {
	let t = e.createBuffer(2, Math.ceil(e.sampleRate * .34), e.sampleRate), n = 31337;
	for (let r = 0; r < 2; r++) {
		let i = t.getChannelData(r);
		for (let t = 0; t < i.length; t++) {
			n ^= n << 13, n ^= n >>> 17, n ^= n << 5;
			let r = t / e.sampleRate;
			i[t] = ((n >>> 0) / 2 ** 31 - 1) * Math.exp(-r * 3) * Math.min(1, (i.length - 1 - t) / 64) * .35;
		}
	}
	return t;
}
var An = {
	rate: Tn,
	sample: On,
	chokedBy: { open: ["hat", "pedal"] },
	peak: 1.4,
	tone: (e) => 1200 * 16 ** e
};
function jn(e, t, n) {
	let r = n(e.createGain()), i = n(e.createGain()), a = n(e.createWaveShaper()), o = n(e.createGain()), s = n(e.createConvolver()), c = n(e.createGain());
	a.curve = Float32Array.from({ length: 2049 }, (e, t) => {
		let n = (t / 1024 - 1) * 6;
		return Math.max(-1, Math.min(1, n > 0 ? Math.tanh(n) : Math.tanh(1.4 * n) * .9));
	}), a.oversample = "2x", r.connect(i).connect(t), a.connect(o).connect(t), s.buffer = kn(e), s.connect(c).connect(t);
	let l = Q(r, a), u = Q(i, s), d = 0, f, p = () => {
		d < z.length && (On(z[d++].id), f = setTimeout(p, 0));
	};
	f = setTimeout(p, 0);
	let m = !1;
	return {
		input: r,
		classic: () => bn(e, r, An),
		dispose() {
			clearTimeout(f);
		},
		apply(t) {
			let n = (t, n) => {
				m ? t.setTargetAtTime(n, e.currentTime, .01) : t.value = n;
			};
			l(t.drive > 0, !m), u(t.room > 0, !m), n(i.gain, 1 - .45 * t.drive), n(o.gain, .75 * t.drive), n(c.gain, t.room * .9), m = !0;
		}
	};
}
//#endregion
//#region src/audio/prism-processor.js?raw
var Mn = "/** Self-contained phase-modulation DSP, imported directly by tests and as inline source by the worklet loader. */\nexport const ALGORITHMS = [\n  {inputs: [[1], [], [3], [], [5], []], carriers: [0, 2, 4]},\n  {inputs: [[1], [2], [], [4], [5], []], carriers: [0, 3]},\n  {inputs: [[1], [2], [3], [4], [5], []], carriers: [0]},\n  {inputs: [[3], [3], [3], [4, 5], [], []], carriers: [0, 1, 2]},\n  {inputs: [[1, 2], [3], [4], [], [5], []], carriers: [0]},\n  {inputs: [[], [], [], [], [], []], carriers: [0, 1, 2, 3, 4, 5]},\n];\nconst TAU = 2 * Math.PI, QUANTUM = 128;\n/** Blocks a voice's ladder keeps running after the voice ends, so its tail rings out (about 23 ms). */\nconst FILTER_TAIL = 8;\n/** The gain that matches the Ladder filter's level to Off at PRISM's default settings. */\nexport const FILTER_LEVEL = 1.02;\n/**\n * `makeFilter`, when given, makes one Rust ladder (a LadderDSP) per voice for the Filter section; without it PRISM plays\n * unfiltered, as it did before the section existed.\n */\nexport class PrismDSP {\n  constructor(rate, makeFilter) {\n    this.rate = rate; this.events = []; this.params = {}; this.level = 0; this.disposed = false;\n    this.makeFilter = makeFilter; this.filters = []; this.wet = 0; this.fade = 1 - Math.exp(-1 / (0.008 * rate));\n    if (makeFilter) {\n      this.voiceOut = Array.from({length: 16}, () => new Float32Array(QUANTUM));\n      this.voiceDetune = Array.from({length: 16}, () => new Float32Array(QUANTUM));\n      this.used = new Uint8Array(16); this.tails = new Uint8Array(16);\n      this.dry = new Float32Array(QUANTUM); this.wets = new Float32Array(QUANTUM); this.levels = new Float32Array(QUANTUM);\n    }\n    this.voices = Array.from({length: 16}, () => ({key: null, start: -Infinity, released: -Infinity, free: -Infinity,\n      phase: new Float64Array(6), env: new Float64Array(6), stage: new Uint8Array(6), attackStep: new Float64Array(6), releaseStep: new Float64Array(6), values: new Float64Array(6), frequency: 0, velocity: 1, feedback: 0, lastFeedback: 0}));\n  }\n  enqueue(event) {\n    if (event.type === 'off') this.events = this.events.filter(e => !(e.time >= event.time && (event.key === undefined || e.key === event.key) && (e.type === 'on' || e.type === 'off')));\n    this.events.push(event); this.events.sort((a, b) => a.time - b.time);\n  }\n  release(time, key) {\n    for (const v of this.voices) if (v.key !== null && (key === undefined || v.key === key) && v.released === Infinity) {\n      v.released = time; v.free = time + Math.max(...this.ops.map(o => o.release));\n      for (let i = 0; i < 6; i++) {v.stage[i] = 3; v.releaseStep[i] = v.env[i] / (this.ops[i].release * this.rate);}\n    }\n  }\n  apply(event) {\n    if (event.type === 'params') {\n      this.params = event.params;\n      this.ops = Array.from({length: 6}, (_, i) => {const id = `op${i + 1}`, p = this.params; return {\n        ratio: p[`${id}Ratio`] * 2 ** (p[`${id}Detune`] / 1200), level: p[`${id}Level`], attack: p[`${id}Attack`],\n        decay: Math.exp(-1 / (p[`${id}Decay`] * this.rate / 4)), sustain: p[`${id}Sustain`], release: p[`${id}Release`],\n      };});\n    } else if (event.type === 'off') this.release(event.time, event.key);\n    else if (event.type === 'on' && this.ops) {\n      this.release(event.time, event.key);\n      const taken = new Set();\n      for (const note of event.notes) {\n        const available = this.voices.filter(v => !taken.has(v));\n        const silent = available.filter(v => v.free <= event.time), released = available.filter(v => v.released <= event.time);\n        const candidates = silent.length ? silent : released.length ? released : available;\n        const field = silent.length ? 'free' : released.length ? 'released' : 'start';\n        const v = candidates.reduce((a, b) => b[field] < a[field] ? b : a);\n        taken.add(v);\n        if (v.free <= event.time) {v.phase.fill(0); v.env.fill(0); v.feedback = 0; v.lastFeedback = 0;}\n        v.key = event.key; v.start = event.time; v.free = Infinity; v.released = Infinity;\n        v.frequency = 440 * 2 ** ((note - 69) / 12); v.cents = (note - 60) * 100; v.velocity = event.velocity;\n        for (let i = 0; i < 6; i++) {v.stage[i] = 0; v.attackStep[i] = (1 - v.env[i]) / (this.ops[i].attack * this.rate);}\n      }\n    }\n  }\n  render(output, startFrame, pitch, brightness) {\n    if (this.disposed) {output.fill(0); return;}\n    // The per-voice filter buffers hold one render quantum, so longer renders (tests) go a quantum at a time.\n    if (this.makeFilter && output.length > QUANTUM) {\n      for (let i = 0; i < output.length; i += QUANTUM) this.render(output.subarray(i, i + QUANTUM), startFrame + i, pitch?.subarray(i, i + QUANTUM), brightness?.subarray(i, i + QUANTUM));\n      return;\n    }\n    // The Filter section crossfades in and out over 8 ms. While it is fully off, the original unfiltered path runs.\n    const filtering = !!this.makeFilter && (this.params.filterModel === 1 || this.wet > 0);\n    if (filtering) for (let i = 0; i < 16; i++) {this.voiceOut[i].fill(0); this.voiceDetune[i].fill(this.voiceDetune[i][QUANTUM - 1]);}\n    for (let n = 0; n < output.length; n++) {\n      const time = (startFrame + n) / this.rate;\n      while (this.events.length && this.events[0].time <= time) this.apply(this.events.shift());\n      if (!this.ops) {output[n] = 0; continue;}\n      const p = this.params, algorithm = ALGORITHMS[p.algorithm];\n      const bend = Math.max(-9600, Math.min(9600, (pitch?.[n] ?? 0) + Math.sin(TAU * p.lfoRate * time) * p.lfoDepth * 100));\n      const tune = 2 ** (bend / 1200);\n      const color = Math.max(0, Math.min(4, p.brightness + (brightness?.[n] ?? 0)));\n      let sum = 0;\n      for (let index = 0; index < this.voices.length; index++) {\n        const v = this.voices[index];\n        if (v.free <= time) continue;\n        const touch = 1 - p.velocity + p.velocity * v.velocity;\n        for (let i = 5; i >= 0; i--) {\n          const op = this.ops[i];\n          if (v.stage[i] === 0) {v.env[i] = Math.min(1, v.env[i] + v.attackStep[i]); if (v.env[i] >= 1) v.stage[i] = 1;}\n          else if (v.stage[i] === 1) v.env[i] = op.sustain + (v.env[i] - op.sustain) * op.decay;\n          else v.env[i] = Math.max(0, v.env[i] - v.releaseStep[i]);\n          const frequency = Math.min(this.rate * 0.45, v.frequency * tune * op.ratio);\n          // The step is under half a turn, so subtracting a turn wraps exactly as the remainder would.\n          v.phase[i] += TAU * frequency / this.rate; if (v.phase[i] >= TAU) v.phase[i] -= TAU;\n          // A released operator at zero contributes nothing, so its sine is skipped.\n          if (v.env[i] === 0) {v.values[i] = 0; continue;}\n          let modulation = i === 5 ? (v.feedback + v.lastFeedback) * 0.5 * p.feedback * 3.5 : 0;\n          const inputs = algorithm.inputs[i];\n          for (let k = 0; k < inputs.length; k++) modulation += v.values[inputs[k]] * 5 * color * touch;\n          v.values[i] = Math.sin(v.phase[i] + modulation) * v.env[i] * op.level;\n        }\n        v.lastFeedback = v.feedback; v.feedback = v.values[5];\n        let voice = 0;\n        for (let k = 0; k < algorithm.carriers.length; k++) voice += v.values[algorithm.carriers[k]];\n        voice = voice / Math.sqrt(algorithm.carriers.length) * v.velocity;\n        sum += voice;\n        if (filtering) {\n          // Each voice's ladder follows its first carrier's envelope and its note, including bends.\n          this.voiceOut[index][n] = voice; this.used[index] = 1;\n          this.voiceDetune[index][n] = p.filterEnv * 4800 * v.env[0] + p.filterTrack * (v.cents + bend);\n        }\n      }\n      this.level += (p.level - this.level) * 0.003;\n      if (!filtering) {output[n] = sum * this.level * 0.18; continue;}\n      this.wet += ((p.filterModel === 1 ? 1 : 0) - this.wet) * this.fade;\n      if (this.wet < 1e-5 && p.filterModel !== 1) this.wet = 0;\n      this.dry[n] = sum; this.wets[n] = this.wet; this.levels[n] = this.level;\n    }\n    if (filtering) this.mixFiltered(output);\n  }\n\n  /** Runs each sounding voice (and each ringing tail) through its ladder and crossfades the result with the dry mix. */\n  mixFiltered(output) {\n    const p = this.params, n = output.length;\n    output.fill(0);\n    for (let i = 0; i < 16; i++) {\n      if (this.used[i]) this.tails[i] = FILTER_TAIL;\n      if (!this.tails[i]) continue;\n      const filter = (this.filters[i] ??= this.makeFilter()), buffer = this.voiceOut[i];\n      filter.render(buffer, buffer, p.filterCutoff, p.filterResonance, p.filterDrive, this.voiceDetune[i], 0);\n      for (let k = 0; k < n; k++) output[k] += buffer[k];\n      if (!this.used[i]) this.tails[i]--;\n      this.used[i] = 0;\n    }\n    for (let k = 0; k < n; k++) output[k] = (this.dry[k] * (1 - this.wets[k]) + output[k] * FILTER_LEVEL * this.wets[k]) * this.levels[k] * 0.18;\n  }\n\n  dispose() {\n    this.disposed = true; this.events = [];\n    for (const filter of this.filters) filter?.dispose();\n    this.filters = [];\n  }\n}\n// The guard lets unit tests import the exact processor DSP without an audio environment.\nif (typeof registerProcessor !== 'undefined') {\n  class PrismProcessor extends AudioWorkletProcessor {\n    constructor(options) {\n      // dsp-processor.js shares its ladder through the global scope; without the Rust DSP, PRISM plays unfiltered.\n      const module = options?.processorOptions?.module, Ladder = globalThis.RacklooseDSP?.LadderDSP;\n      super(); this.dsp = new PrismDSP(sampleRate, module && Ladder ? () => new Ladder(module, sampleRate) : undefined);\n      this.port.onmessage = ({data}) => {\n        if (data.type === 'flush') this.port.postMessage({id: data.id});\n        else if (data.type === 'dispose') this.dsp.dispose();\n        else this.dsp.enqueue(data);\n      };\n    }\n    process(inputs, outputs) {\n      this.dsp.render(outputs[0][0], currentFrame, inputs[0]?.[0], inputs[1]?.[0]);\n      return !this.dsp.disposed;\n    }\n  }\n  registerProcessor('rackloose-prism-v1', PrismProcessor);\n}\n", Nn = "/** Original behavioral models, not measured circuit replicas. See docs/studio-processors.md for calibration and sources. */\nexport const COHERE_ATTACKS = [0.0001, 0.0003, 0.001, 0.003, 0.01, 0.03];\nexport const COHERE_RELEASES = [0.1, 0.3, 0.6, 1.2];\nexport const TALON_RATIOS = [1, 2, 3, 4, 6, 10, 20, 100];\nexport const BRIT_LOW = [35, 60, 110, 220];\nexport const BRIT_MID = [360, 700, 1600, 3200, 4800, 7200];\nexport const BRIT_HP = [0, 50, 80, 160, 300];\nconst db = x => 10 ** (x / 20);\nconst unity = [1, 0, 0, 0, 0];\n\n/** Normalized biquads and one pole filters. A third-order Butterworth HP is a first order plus a Q=1 biquad. */\nexport function coefficients(type, frequency, gain, Q, rate) {\n  if (!frequency) return unity.slice();\n  const w = 2 * Math.PI * Math.min(frequency, rate * 0.45) / rate, c = Math.cos(w), s = Math.sin(w);\n  const A = 10 ** (gain / 40), alpha = s / (2 * Q), shelf = s * Math.sqrt(2 * A);\n  let b0, b1, b2, a0, a1, a2;\n  if (type === 'pole') {\n    const k = Math.tan(w / 2); return [1 / (1 + k), -1 / (1 + k), 0, (k - 1) / (k + 1), 0];\n  } else if (type === 'highpass') {\n    [b0, b1, b2, a0, a1, a2] = [(1 + c) / 2, -(1 + c), (1 + c) / 2, 1 + alpha, -2 * c, 1 - alpha];\n  } else if (type === 'bell') {\n    [b0, b1, b2, a0, a1, a2] = [1 + alpha * A, -2 * c, 1 - alpha * A, 1 + alpha / A, -2 * c, 1 - alpha / A];\n  } else if (type === 'low') {\n    [b0, b1, b2, a0, a1, a2] = [A * (A + 1 - (A - 1) * c + shelf), 2 * A * (A - 1 - (A + 1) * c), A * (A + 1 - (A - 1) * c - shelf), A + 1 + (A - 1) * c + shelf, -2 * (A - 1 + (A + 1) * c), A + 1 + (A - 1) * c - shelf];\n  } else {\n    [b0, b1, b2, a0, a1, a2] = [A * (A + 1 + (A - 1) * c + shelf), -2 * A * (A - 1 + (A + 1) * c), A * (A + 1 + (A - 1) * c - shelf), A + 1 - (A - 1) * c + shelf, 2 * (A - 1 - (A + 1) * c), A + 1 - (A - 1) * c - shelf];\n  }\n  return [b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0];\n}\nexport function britFilters(p, rate) {\n  const hp = BRIT_HP[p.hpf] ?? 0;\n  return [coefficients('pole', hp, 0, 1, rate), coefficients('highpass', hp, 0, 1, rate),\n    coefficients('low', BRIT_LOW[p.lfFreq] ?? 110, p.lfGain, 0.7, rate),\n    coefficients('bell', BRIT_MID[p.midFreq] ?? 1600, p.midGain, 0.75, rate), coefficients('high', 12000, p.hfGain, 0.7, rate)];\n}\nexport function britResponse(p, frequency, rate = 48000) {\n  if (p.active) return 0;\n  const w = 2 * Math.PI * frequency / rate;\n  const magnitude = (a, b, c) => Math.hypot(a + b * Math.cos(w) + c * Math.cos(2 * w), b * Math.sin(w) + c * Math.sin(2 * w));\n  return britFilters(p, rate).reduce((sum, [b0, b1, b2, a1, a2]) => sum + 20 * Math.log10(magnitude(b0, b1, b2) / magnitude(1, a1, a2)), 0);\n}\n\n/** Each TALON mode has its own threshold and knee; Input drives a fixed characteristic instead of moving a threshold. */\nfunction curveSettings(type, p) {\n  let ratio, threshold, knee;\n  if (type === 'cohere') {\n    ratio = [2, 4, 10][p.ratio] ?? 4;\n    threshold = p.threshold + [-3, 0, 2][p.ratio]; knee = [9, 6, 3][p.ratio];\n  } else {\n    ratio = TALON_RATIOS[p.ratio] ?? 6;\n    threshold = [-18, -26, -24, -22, -20, -18, -16, -18][p.ratio];\n    knee = [0, 15, 12, 9, 6, 4, 2, 3][p.ratio];\n    if (p.fierce) {ratio = Math.max(12, ratio * 2); threshold -= 3; knee = 2;}\n  }\n  return [1 - 1 / ratio, threshold, knee];\n}\nfunction curveGain(level, slope, threshold, knee) {\n  if (!slope) return 0;\n  const over = level - threshold;\n  return over <= -knee / 2 ? 0 : over >= knee / 2 ? -over * slope : -slope * (over + knee / 2) ** 2 / (2 * knee);\n}\nexport function compressionCurve(type, level, p) {return curveGain(level, ...curveSettings(type, p));}\n\nclass Filter {\n  constructor(rate) {this.c = unity.slice(); this.target = unity.slice(); this.z1 = 0; this.z2 = 0; this.smooth = 1 - Math.exp(-1 / (rate * 0.008));}\n  set(c, initial) {this.target = c; if (initial) this.c = c.slice();}\n  run(x) {\n    const c = this.c;\n    for (let i = 0; i < 5; i++) c[i] += (this.target[i] - c[i]) * this.smooth;\n    const y = c[0] * x + this.z1;\n    this.z1 = c[1] * x - c[3] * y + this.z2; this.z2 = c[2] * x - c[4] * y;\n    return y;\n  }\n}\n\n// 4x interpolation/decimation of the nonlinear residual only: linear audio keeps its full bandwidth.\n// Two symmetric 49-tap Blackman-windowed sinc FIRs give exactly 12 base-rate samples of delay.\nexport const FIR = Float64Array.from({length: 49}, (_, i) => {\n  const n = i - 24, cutoff = 0.1125;\n  return (n ? Math.sin(2 * Math.PI * cutoff * n) / (Math.PI * n) : 2 * cutoff) * (0.42 - 0.5 * Math.cos(2 * Math.PI * i / 48) + 0.08 * Math.cos(4 * Math.PI * i / 48));\n});\nconst total = FIR.reduce((sum, x) => sum + x, 0); for (let i = 0; i < FIR.length; i++) FIR[i] /= total;\nclass Fir {\n  constructor() {this.buffer = new Float64Array(49); this.index = 0;}\n  /** Stores `x` without computing an output, for decimation steps whose output is discarded. */\n  push(x) {this.buffer[this.index] = x; this.index = (this.index + 1) % 49;}\n  run(x) {\n    this.buffer[this.index] = x; let sum = 0, at = this.index;\n    for (let i = 0; i < 49; i++) {sum += FIR[i] * this.buffer[at]; if (--at < 0) at = 48;}\n    this.index = (this.index + 1) % 49; return sum;\n  }\n}\n/**\n * The FIR over a 4x zero-stuffed signal, computed polyphase: phase `i` reads only the taps that meet a real sample,\n * in the same order, so it matches the full filter exactly at a quarter of the work.\n */\nclass Interpolator {\n  constructor() {this.buffer = new Float64Array(13); this.index = 0;}\n  push(x) {this.index = this.index ? this.index - 1 : 12; this.buffer[this.index] = x;}\n  run(phase) {\n    let sum = 0, at = this.index;\n    for (let k = phase; k < 49; k += 4) {sum += FIR[k] * this.buffer[at]; if (++at > 12) at = 0;}\n    return sum;\n  }\n}\nexport const STUDIO_LATENCY = 12;\nclass Delay {\n  constructor() {this.buffer = new Float64Array(STUDIO_LATENCY); this.index = 0;}\n  run(x) {const y = this.buffer[this.index]; this.buffer[this.index] = x; this.index = (this.index + 1) % this.buffer.length; return y;}\n}\nexport class Color {\n  constructor(rate) {this.up = new Interpolator(); this.down = new Fir(); this.clean = new Delay(); this.previous = 0; this.blocked = 0; this.dc = Math.exp(-2 * Math.PI * 5 / rate);}\n  run(x, amount, bias) {\n    let residual = 0;\n    const offset = Math.tanh(bias), slope = amount * (1 - offset * offset);\n    this.up.push(x * 4);\n    for (let i = 0; i < 4; i++) {\n      const up = this.up.run(i);\n      const shaped = (Math.tanh(amount * up + bias) - offset) / slope;\n      // Only every fourth decimated sample is kept, so the others are stored without being filtered.\n      if (i === 0) residual = this.down.run(shaped - up); else this.down.push(shaped - up);\n    }\n    // AC coupling of the nonlinear residual removes the DC generated by asymmetric coloration.\n    this.blocked = residual - this.previous + this.dc * this.blocked; this.previous = residual;\n    return this.clean.run(x) + this.blocked;\n  }\n}\n\nexport class StudioDSP {\n  constructor(type, rate) {\n    this.type = type; this.rate = rate; this.params = null; this.events = []; this.disposed = false; this.reduction = 0;\n    this.gain = [0, 0]; this.memory = [0, 0]; this.input = 1; this.output = 1; this.wet = 1; this.drive = 0;\n    this.smooth = 1 - Math.exp(-1 / (rate * 0.008));\n    this.channels = Array.from({length: 2}, () => ({filters: Array.from({length: 5}, () => new Filter(rate)),\n      hp: new Filter(rate), emphasis: new Filter(rate), audioPole: new Filter(rate), audioHp: new Filter(rate), color: new Color(rate), dry: new Delay(), clean: new Delay(), amount: 0.15, bias: 0}));\n  }\n  enqueue(event) {this.events.push(event); this.events.sort((a, b) => a.time - b.time);}\n  configure(p) {\n    const initial = !this.params; this.params = {...p};\n    this.inputTarget = db(this.type === 'talon' ? p.input : 0); this.outputTarget = db(p.output);\n    this.wetTarget = p.active ? 0 : 1; this.driveTarget = p.drive ?? 0;\n    if (initial) {this.input = this.inputTarget; this.output = this.outputTarget; this.wet = this.wetTarget; this.drive = this.driveTarget;}\n    if (this.type !== 'brit') {\n      this.curveTarget = curveSettings(this.type, p); this.linkTarget = this.type === 'cohere' ? 1 : p.link;\n      this.attackTarget = this.type === 'cohere' ? COHERE_ATTACKS[p.attack] : p.attack;\n      this.releaseTarget = this.type === 'cohere' ? COHERE_RELEASES[p.release] ?? 0.3 : p.release;\n      if (initial) {this.curve = this.curveTarget.slice(); this.link = this.linkTarget; this.attack = this.attackTarget; this.release = this.releaseTarget;}\n    }\n    for (const channel of this.channels) {\n      if (this.type === 'brit') britFilters(p, this.rate).forEach((c, i) => channel.filters[i].set(c, initial));\n      const hp = this.type === 'cohere' ? [0, 30, 60, 106, 125, 185][p.scHpf] : p.detectorHp ? 80 : 0;\n      channel.hp.set(coefficients('highpass', hp, 0, Math.SQRT1_2, this.rate), initial);\n      channel.emphasis.set(coefficients('bell', 6000, p.detectorBand ? 10 : 0, 1, this.rate), initial);\n      // Third-order Bessel HP, normalized to -3 dB at 65 Hz. Distinct from the detector filter.\n      channel.audioPole.set(coefficients('pole', p.audioHp ? 65 * 0.754 : 0, 0, 1, this.rate), initial);\n      channel.audioHp.set(coefficients('highpass', p.audioHp ? 65 * 0.691 : 0, 0, 0.691, this.rate), initial);\n      if (initial && this.type === 'talon') {channel.amount = [0.15, 0.8, 1.5][p.color]; channel.bias = p.color === 1 ? 0.3 : 0;}\n    }\n  }\n  envelope(level, channel) {\n    const p = this.params, target = curveGain(level, this.curve[0], this.curve[1], this.curve[2]), current = this.gain[channel];\n    // A slow reservoir makes Auto and Opto depend on both the depth and duration of preceding compression.\n    this.memory[channel] += (Math.max(0, -current) - this.memory[channel]) * (1 - Math.exp(-1 / (this.rate * 0.6)));\n    let release = this.release;\n    if (this.type === 'cohere' && p.release === 4) release = 0.1 + Math.min(1.1, this.memory[channel] * 0.09);\n    if (this.type === 'talon') {\n      if (p.ratio === 5) release = Math.min(20, this.release * (1 + this.memory[channel] * 0.9));\n      else if (p.ratio === 7) release *= 0.45 + Math.min(1.5, Math.max(0, -current) / 15);\n      else release *= [1, 1.15, 1.05, 1, 0.9, 1, 0.8, 1][p.ratio];\n      if (p.ratio !== 5) release = Math.min(3.5, release);\n      if (p.fierce) release *= 0.65;\n    }\n    const seconds = target < current ? this.attack : release;\n    this.gain[channel] += (target - current) * (1 - Math.exp(-1 / (seconds * this.rate)));\n    return db(this.gain[channel]);\n  }\n  render(inputs, outputs, startFrame = 0) {\n    if (this.disposed) {outputs.forEach(out => out.fill(0)); return;}\n    const frames = outputs[0].length;\n    for (let n = 0; n < frames; n++) {\n      const time = (startFrame + n) / this.rate;\n      while (this.events.length && this.events[0].time <= time) this.configure(this.events.shift().params);\n      if (!this.params) {outputs.forEach(out => {out[n] = 0;}); continue;}\n      const p = this.params;\n      this.input += (this.inputTarget - this.input) * this.smooth; this.output += (this.outputTarget - this.output) * this.smooth;\n      this.wet += (this.wetTarget - this.wet) * this.smooth; this.drive += (this.driveTarget - this.drive) * this.smooth;\n      const left = inputs[0]?.[n] ?? 0, right = inputs[1]?.[n] ?? left;\n      const l = left * this.input, r = right * this.input;\n      let gainL = 1, gainR = 1;\n      if (this.type !== 'brit') {\n        for (let i = 0; i < 3; i++) this.curve[i] += (this.curveTarget[i] - this.curve[i]) * this.smooth;\n        this.link += (this.linkTarget - this.link) * this.smooth;\n        this.attack += (this.attackTarget - this.attack) * this.smooth; this.release += (this.releaseTarget - this.release) * this.smooth;\n        const a = this.channels[0], b = this.channels[1];\n        const levelL = 20 * Math.log10(Math.max(1e-12, Math.abs(a.emphasis.run(a.hp.run(l)))));\n        const levelR = 20 * Math.log10(Math.max(1e-12, Math.abs(b.emphasis.run(b.hp.run(r)))));\n        const dominant = Math.max(levelL, levelR);\n        this.envelope(levelL + this.link * (dominant - levelL), 0); this.envelope(levelR + this.link * (dominant - levelR), 1);\n        // Converge existing independent histories continuously when linking, never copy one channel's gain instantly.\n        const commonGain = Math.min(this.gain[0], this.gain[1]), commonMemory = Math.max(this.memory[0], this.memory[1]), coupling = this.link * this.smooth;\n        for (let i = 0; i < 2; i++) {this.gain[i] += (commonGain - this.gain[i]) * coupling; this.memory[i] += (commonMemory - this.memory[i]) * coupling;}\n        gainL = db(this.gain[0]); gainR = db(this.gain[1]);\n        this.reduction = Math.min(this.gain[0], this.gain[1]) * this.wet;\n      }\n      for (let i = 0; i < outputs.length; i++) {\n        const channel = this.channels[i], raw = i === 0 ? left : right;\n        let wet = i === 0 ? l : r;\n        if (this.type === 'brit') {\n          for (const filter of channel.filters) wet = filter.run(wet);\n          wet = channel.color.run(wet, 0.22 * db(this.drive), 0.12);\n        } else if (this.type === 'talon') {\n          wet = channel.audioHp.run(channel.audioPole.run(wet * (i === 0 ? gainL : gainR)));\n          const amount = [0.15, 0.8, 1.5][p.color] * (1 + Math.min(2, -this.gain[i] / 20));\n          channel.amount += (amount - channel.amount) * this.smooth; channel.bias += ((p.color === 1 ? 0.3 : 0) - channel.bias) * this.smooth;\n          wet = channel.color.run(wet, channel.amount, channel.bias);\n        } else wet = channel.clean.run(wet * (i === 0 ? gainL : gainR));\n        const dry = channel.dry.run(raw);\n        outputs[i][n] = dry + this.wet * (wet * this.output - dry);\n      }\n    }\n  }\n}\n\nif (typeof registerProcessor !== 'undefined') {\n  class StudioProcessor extends AudioWorkletProcessor {\n    constructor(options) {\n      super(); this.dsp = new StudioDSP(options.processorOptions.type, sampleRate); this.meterFrames = 0;\n      this.port.onmessage = ({data}) => {\n        if (data.type === 'flush') this.port.postMessage({id: data.id});\n        else if (data.type === 'dispose') {this.dsp.disposed = true; this.dsp.events = [];}\n        else this.dsp.enqueue(data);\n      };\n    }\n    process(inputs, outputs) {\n      this.dsp.render(inputs[0] ?? [], outputs[0], currentFrame);\n      this.meterFrames += outputs[0][0].length;\n      if (this.meterFrames >= sampleRate / 25) {this.meterFrames = 0; this.port.postMessage({reduction: this.dsp.reduction});}\n      return !this.dsp.disposed;\n    }\n  }\n  registerProcessor('rackloose-studio-v1', StudioProcessor);\n}\n", Pn = "/**\n * Hosts Rackloose's Rust DSP (crates/rackloose-dsp, compiled to WebAssembly): the zero-delay-feedback ladder filter\n * for MONARCH, ORACLE, AURORA and SIEVE, and the modeled drum engine for BOOM, PUNCH, ORBIT, STRIKE and FORGE. PRISM\n * reaches the ladder through `globalThis.RacklooseDSP`. Imported directly by tests and as inline source by the worklet\n * loader.\n *\n * Audio moves through fixed buffers in Wasm linear memory, so nothing allocates per block. Every processor in a context\n * shares one instance of the module, and every view is rebuilt when an allocation grows that memory.\n */\nconst RENDER_QUANTUM = 128, DRUM_PARAMS = 8;\nlet shared = null;\n\n/**\n * The context's one instance of the module. Every AudioWorkletNode receives its own structured clone of `module`, so the\n * instance belongs to the worklet scope (one per audio context) rather than to a module object: an instance per\n * processor would reserve a Wasm memory each, and enough of them exhaust the browser's Wasm address space. It needs no\n * imports, so instantiating is synchronous.\n */\nexport function wasmFor(module) {\n  shared ??= new WebAssembly.Instance(module, {}).exports;\n  return shared;\n}\n\n/** One ladder: cutoff, resonance and drive are smoothed in Rust; detune (cents) applies sample-exact. */\nexport class LadderDSP {\n  constructor(module, sampleRate) {\n    this.wasm = wasmFor(module);\n    this.ptr = this.wasm.ladder_new(sampleRate);\n    this.last = {cutoff: NaN, resonance: NaN, drive: NaN, mode: NaN};\n    this.fresh = true;\n    this.buffer = null;\n  }\n\n  views() {\n    const {memory, ladder_input_ptr, ladder_detune_ptr, ladder_output_ptr} = this.wasm;\n    this.buffer = memory.buffer;\n    this.input = new Float32Array(this.buffer, ladder_input_ptr(this.ptr), RENDER_QUANTUM);\n    this.detune = new Float32Array(this.buffer, ladder_detune_ptr(this.ptr), RENDER_QUANTUM);\n    this.output = new Float32Array(this.buffer, ladder_output_ptr(this.ptr), RENDER_QUANTUM);\n  }\n\n  /**\n   * Filters `input` (missing means silence) into `output`. `detune` holds one value for the block or one per sample;\n   * `mode` is 0 24 dB low-pass, 1 12 dB low-pass, 2 band-pass, 3 high-pass.\n   */\n  render(input, output, cutoff, resonance, drive, detune, mode = 0) {\n    if (!this.ptr) {output.fill(0); return;}\n    if (this.wasm.memory.buffer !== this.buffer) this.views();\n    const n = Math.min(output.length, RENDER_QUANTUM);\n    if (input) this.input.set(input.length > n ? input.subarray(0, n) : input); else this.input.fill(0, 0, n);\n    if (detune.length === 1) this.detune.fill(detune[0], 0, n); else this.detune.set(detune.length > n ? detune.subarray(0, n) : detune);\n    const {last, wasm, ptr} = this;\n    if (cutoff !== last.cutoff) wasm.ladder_set_cutoff(ptr, (last.cutoff = cutoff));\n    if (resonance !== last.resonance) wasm.ladder_set_resonance(ptr, (last.resonance = resonance));\n    if (drive !== last.drive) wasm.ladder_set_drive(ptr, (last.drive = drive));\n    if (mode !== last.mode) wasm.ladder_set_mode(ptr, (last.mode = mode));\n    // The first block starts on its settings instead of gliding from Rust's defaults.\n    if (this.fresh) {wasm.ladder_reset(ptr); this.fresh = false;}\n    wasm.ladder_process(ptr, n);\n    output.set(n === RENDER_QUANTUM ? this.output : this.output.subarray(0, n));\n  }\n\n  dispose() {\n    if (!this.ptr) return;\n    this.wasm.ladder_free(this.ptr);\n    this.ptr = 0;\n    this.input = this.detune = this.output = null;\n  }\n}\n\n/**\n * One drum machine. Hits arrive ahead of time as {time, voice, velocity, params} and start sample-accurately inside\n * the block that contains them; a late hit starts at the next block. `chokes` lists [voice, by] pairs.\n */\nexport class DrumsDSP {\n  constructor(module, sampleRate, kit, chokes = []) {\n    this.wasm = wasmFor(module);\n    this.rate = sampleRate;\n    this.ptr = this.wasm.drums_new(sampleRate, kit);\n    for (const [voice, by] of chokes) this.wasm.drums_choke(this.ptr, voice, by);\n    this.events = [];\n    this.buffer = null;\n  }\n\n  views() {\n    const {memory, drums_params_ptr, drums_output_ptr} = this.wasm;\n    this.buffer = memory.buffer;\n    this.params = new Float32Array(this.buffer, drums_params_ptr(this.ptr), DRUM_PARAMS);\n    this.left = new Float32Array(this.buffer, drums_output_ptr(this.ptr, 0), RENDER_QUANTUM);\n    this.right = new Float32Array(this.buffer, drums_output_ptr(this.ptr, 1), RENDER_QUANTUM);\n  }\n\n  /** Copies a sampled kit's one-shot for `voice` into Wasm memory. */\n  load(voice, pcm) {\n    if (!this.ptr) return;\n    const at = this.wasm.drums_load_sample(this.ptr, voice, pcm.length);\n    if (at) new Float32Array(this.wasm.memory.buffer, at, pcm.length).set(pcm);\n  }\n\n  enqueue(event) {\n    let i = this.events.length;\n    while (i > 0 && this.events[i - 1].time > event.time) i--;\n    this.events.splice(i, 0, event);\n  }\n\n  /** Drops hits scheduled at or after `time`. Hits already sounding keep their natural tails. */\n  cancel(time) {this.events = this.events.filter(event => event.time < time);}\n\n  render(left, right, startFrame) {\n    if (!this.ptr) {left.fill(0); right?.fill(0); return;}\n    if (this.wasm.memory.buffer !== this.buffer) this.views();\n    const n = Math.min(left.length, RENDER_QUANTUM), end = startFrame + n;\n    while (this.events.length && this.events[0].time * this.rate < end) {\n      const event = this.events.shift(), offset = Math.max(0, Math.floor(event.time * this.rate) - startFrame);\n      this.params.fill(0); this.params.set(event.params.slice(0, DRUM_PARAMS));\n      this.wasm.drums_trigger(this.ptr, event.voice, Math.min(offset, n - 1), event.velocity);\n    }\n    this.wasm.drums_process(this.ptr, n);\n    if (this.wasm.memory.buffer !== this.buffer) this.views();\n    left.set(n === RENDER_QUANTUM ? this.left : this.left.subarray(0, n));\n    right?.set(n === RENDER_QUANTUM ? this.right : this.right.subarray(0, n));\n  }\n\n  dispose() {\n    if (!this.ptr) return;\n    this.wasm.drums_free(this.ptr);\n    this.ptr = 0;\n    this.events = [];\n  }\n}\n\n// The guard lets unit tests import the exact processor DSP without an audio environment.\nif (typeof registerProcessor !== 'undefined') {\n  globalThis.RacklooseDSP = {LadderDSP, wasmFor};\n\n  class LadderProcessor extends AudioWorkletProcessor {\n    static get parameterDescriptors() {\n      return [\n        {name: 'cutoff', defaultValue: 1000, minValue: 20, maxValue: 20000, automationRate: 'k-rate'},\n        {name: 'resonance', defaultValue: 0, minValue: 0, maxValue: 1, automationRate: 'k-rate'},\n        {name: 'drive', defaultValue: 0, minValue: 0, maxValue: 1, automationRate: 'k-rate'},\n        {name: 'mode', defaultValue: 0, minValue: 0, maxValue: 3, automationRate: 'k-rate'},\n        // Cents, like BiquadFilterNode.detune, with its unbounded range. Rust clamps the resulting cutoff.\n        {name: 'detune', defaultValue: 0, automationRate: 'a-rate'},\n      ];\n    }\n    constructor({processorOptions}) {\n      super(); this.dsp = new LadderDSP(processorOptions.module, sampleRate);\n      this.port.onmessage = ({data}) => {\n        if (data.type === 'flush') this.port.postMessage({id: data.id});\n        else if (data.type === 'dispose') this.dsp.dispose();\n      };\n    }\n    process(inputs, outputs, parameters) {\n      if (!this.dsp.ptr) return false;\n      const {cutoff, resonance, drive, mode, detune} = parameters;\n      this.dsp.render(inputs[0]?.[0], outputs[0][0], cutoff[0], resonance[0], drive[0], detune, Math.round(mode[0]));\n      return true;\n    }\n  }\n  registerProcessor('rackloose-ladder-v1', LadderProcessor);\n\n  class DrumsProcessor extends AudioWorkletProcessor {\n    constructor({processorOptions: {module, kit, chokes}}) {\n      super(); this.dsp = new DrumsDSP(module, sampleRate, kit, chokes);\n      this.port.onmessage = ({data}) => {\n        if (data.type === 'hit') this.dsp.enqueue(data);\n        else if (data.type === 'sample') this.dsp.load(data.voice, data.pcm);\n        else if (data.type === 'cancel') this.dsp.cancel(data.time);\n        else if (data.type === 'flush') this.port.postMessage({id: data.id});\n        else if (data.type === 'dispose') this.dsp.dispose();\n      };\n    }\n    process(inputs, outputs) {\n      if (!this.dsp.ptr) return false;\n      const [left, right] = outputs[0];\n      this.dsp.render(left, right, currentFrame);\n      return true;\n    }\n  }\n  registerProcessor('rackloose-drums-v1', DrumsProcessor);\n}\n", Fn = "data:application/wasm;base64,AGFzbQEAAAABmwEXYAJ/fwF/YAN/f38Bf2ACf38AYAF/AGADf39/AGABfwF/YAR/f39/AGAEf39/fwF/YAAAYAJ9fwF/YAR/f399AGABfQF/YAJ/fQBgBX9/f39/AX9gBn9/f39/fwBgCX9/f39/f35+fgBgA399fwF/YAR/fX9/AX9gAX0BfWAGf39/f39/AX9gBX9+fn5+AGACfX8BfWACfX0BfQNoZwMABAUDBgIHBQMCBAYDBAQDAQgJAgAFAgMKBQMFCwUCAwwMAgwCAgICAAADBw0NAAIAAQAIAw4ADwQEAAEQEBEGCAICAgMDAwACAgQGAwIBAAEAAgICAgISEhMSEhQSEhISEhIVFhYEBQFwARUVBQMBABEGCQF/AUGAgMAACwffAhUGbWVtb3J5AgALZHJ1bXNfY2hva2UADwpkcnVtc19mcmVlABARZHJ1bXNfbG9hZF9zYW1wbGUAEQlkcnVtc19uZXcAExBkcnVtc19vdXRwdXRfcHRyABUQZHJ1bXNfcGFyYW1zX3B0cgAWDWRydW1zX3Byb2Nlc3MAFwtkcnVtc19yZXNldAAYDWRydW1zX3RyaWdnZXIAGRFsYWRkZXJfZGV0dW5lX3B0cgAaC2xhZGRlcl9mcmVlABsQbGFkZGVyX2lucHV0X3B0cgAcCmxhZGRlcl9uZXcAHRFsYWRkZXJfb3V0cHV0X3B0cgAeDmxhZGRlcl9wcm9jZXNzAB8MbGFkZGVyX3Jlc2V0ACARbGFkZGVyX3NldF9jdXRvZmYAIRBsYWRkZXJfc2V0X2RyaXZlACIPbGFkZGVyX3NldF9tb2RlACMUbGFkZGVyX3NldF9yZXNvbmFuY2UAJAkaAQBBAQsUAS8pKjFNT1BRUlNUVUdISUpCQ04K6voFZ9cDBAF/AX0BfgJ9I4CAgIAAQSBrIgEkgICAgAACQCAAKgLcDiICQwAAoEFgDQAgAUGAgICNBDYCCCABIAI4AgwgAUGBgICAAK1CIIYiAyABQQxqrYQ3AxggASADIAFBCGqthDcDEEHPgcCAACABQRBqQcSIwIAAEIKAgIAAAAsgAEMAAIA/IAJDAACgQSAAKgKwDSAAKgKoDUOaaxc6lJIQ2YCAgAAiBCAEQwAAoEFdGyIEIAQgAl4bQ9sPSUCUIAAqAtgOlRDjgICAACICQwAAgD+SlSIEOAKADyAAIAIgBJQiAjgC8A4gACACIAKUIgQ4AvQOIAAgBCAElCIFOAL8DiAAIAIgBJQ4AvgOIABDAACAP0MAAAAAIAAqArwNIgIgAkMAAAAAXRsiAiACQwAAgD9eG0MAAIBAlCICOAKEDyAAQwAAgD9DAAAAACAAKgLIDSIEIARDAAAAAF0bIgQgBEMAAIA/XhtDAABAQJQQ4YCAgAAiBDgCkA8gAEMAAIA/IASVOAKUDyAAQwAAgD8gBSAClEMAAIA/kpU4AowPIAAgAkMAAAA/lEMAAIA/kkMAAIA/IAAtAJwPQQJJGzgCiA8gACAEkYs4ApgPIAFBIGokgICAgAALgQECAn8CfSABKAIIIgJBgICAAXEhAyAAKgIAIQQCQCACQYCAgIABcQ0AAkAgBIsiBUPKGw5aYA0AIARDAAAAAFwgBUMXt9E4XXENACABIAQgA0EARxC9gICAAA8LIAEgBCADQQBHEL6AgIAADwsgASAEIANBAEcgAS8BDhC/gICAAAtHAQF/I4CAgIAAQSBrIgMkgICAgAAgAyABNgIQIAMgADYCDCADQQE7ARwgAyACNgIYIAMgA0EMajYCFCADQRRqEKuAgIAAAAuRBAEBf0EAIQECQCAAKAIAQQF0Qf///3dLDQAgACgCBEEBdEH///93Sw0AIAAoAghBAXRB////d0sNACAAKAIMQQF0Qf///3dLDQAgACgCEEEBdEH///93Sw0AIAAoAhRBAXRB////d0sNACAAKAIYQQF0Qf///3dLDQAgACgCHEEBdEH///93Sw0AIAAoAiBBAXRB////d0sNACAAKAIkQQF0Qf///3dLDQAgACgCKEEBdEH///93Sw0AIAAoAixBAXRB////d0sNACAAKAIwQQF0Qf///3dLDQAgACgCNEEBdEH///93Sw0AIAAoAjhBAXRB////d0sNACAAKAI8QQF0Qf///3dLDQAgACgCQEEBdEH///93Sw0AIAAoAkRBAXRB////d0sNACAAKAJIQQF0Qf///3dLDQAgACgCTEEBdEH///93Sw0AIAAoAlBBAXRB////d0sNACAAKAJUQQF0Qf///3dLDQAgACgCWEEBdEH///93Sw0AIAAoAlxBAXRB////d0sNACAAKAJgQQF0Qf///3dLDQAgACgCZEEBdEH///93Sw0AIAAoAmhBAXRB////d0sNACAAKAJsQQF0Qf///3dLDQAgACgCcEEBdEH///93Sw0AIAAoAnRBAXRB////d0sNACAAKAJ4QQF0Qf///3dLDQAgACgCfEEBdEH///93Sw0AQQEhAQsgAQt7AQN/I4CAgIAAQRBrIgEkgICAgAAgAUEEaiAAKAIAIgIgACgCBCACQQF0IgJBBCACQQRLGyICEIWAgIAAAkAgASgCBEEBRw0AIAEoAgggASgCDBCGgICAAAALIAEoAgghAyAAIAI2AgAgACADNgIEIAFBEGokgICAgAALkwEBAX9BASEEAkACQCADQa70ohdNDQBBACEDQQQhAQwBCyADQSxsIQMCQAJAAkACQCABRQ0AIAIgAUEsbEEEIAMQh4CAgAAhAQwBCwJAIAMNAEEEIQEMAgsgAxCIgICAACEBCyABDQAgAEEENgIEDAELIAAgATYCBEEAIQQLQQghAQsgACABaiADNgIAIAAgBDYCAAscAAJAIABFDQAgACABEJSAgIAAAAsQkoCAgAAAC68GAQd/AkACQAJAAkACQAJAIABBfGoiBCgCACIFQXhxIgZBBEEIIAVBA3EiBxsgAWpJDQACQCAHRQ0AIAYgAUEnaksNAgtBACEBQVBBACgCnKzAgAAiCGtBd3FBfWogA00NBUEQIANBC2pBeHEgA0ELSRshCSAAQXhqIQoCQAJAAkACQAJAIAdFDQAgCiAGaiEHIAYgCU8NAyAHQQAoAoSswIAARg0EIAdBACgCgKzAgABGDQIgBygCBCIFQQJxDQkgBUF4cSIFIAZqIgYgCUkNCSAHIAUQpYCAgAAgBiAJayIHQRBJDQEgBCAJIAQoAgBBAXFyQQJyNgIAIAogCWoiBSAHQQNyNgIEIAogBmoiBiAGKAIEQQFyNgIEIAUgBxCmgICAAAwICyAJQYACSQ0IIAYgCU0NCCAKRQ0IIAYgCWsgCEEBdEsNCCAADwsgBCAGIAQoAgBBAXFyQQJyNgIAIAogBmoiBiAGKAIEQQFyNgIEDAYLQQAoAvirwIAAIAZqIgYgCUkNBgJAAkAgBiAJayIHQQ9LDQAgBCAFQQFxIAZyQQJyNgIAIAogBmoiBiAGKAIEQQFyNgIEQQAhB0EAIQUMAQsgBCAJIAVBAXFyQQJyNgIAIAogCWoiBSAHQQFyNgIEIAogBmoiBiAHNgIAIAYgBigCBEF+cTYCBAtBACAFNgKArMCAAEEAIAc2AvirwIAADAULIAYgCWsiBkEPTQ0EIAQgCSAFQQFxckECcjYCACAKIAlqIgUgBkEDcjYCBCAHIAcoAgRBAXI2AgQgBSAGEKaAgIAADAQLQQAoAvyrwIAAIAZqIgYgCUsNAgwEC0HgosCAAEEuQZCjwIAAEI6AgIAAAAtBoKPAgABBLkHQo8CAABCOgICAAAALIAQgCSAFQQFxckECcjYCACAKIAlqIgcgBiAJayIGQQFyNgIEQQAgBjYC/KvAgABBACAHNgKErMCAAAsgCkUNACAADwsgAxCIgICAACIGRQ0AAkAgA0F8QXggBCgCACIBQQNxGyABQXhxaiIBIAMgAUkbIgNFDQAgBiAAIAP8CgAACyAAEI2AgIAAIAYhAQsgAQvKKAIIfwF+AkACQAJAAkAgAEH1AUkNAEEAIQFBUEEAKAKcrMCAAGtBd3FBfWogAE0NAyAAQQtqIgFBeHEhAkEAKAL0q8CAACIDRQ0CQR8hBCAAQfX//wdPDQEgAkEmIAFBCHZnIgBrdkEBcSAAQQF0ckE+cyEEDAELAkACQAJAAkACQAJAQQAoAvCrwIAAIgVBECAAQQtqQfgDcSAAQQtJGyICQQN2IgF2IgBBA3FFDQAgAEF/c0EBcSABaiIGQQN0IgBB6KnAgABqIgIgAEHwqcCAAGooAgAiASgCCCIHRg0BIAcgAjYCDCACIAc2AggMAgsgAkEAKAL4q8CAAE0NBgJAIAANAEEAKAL0q8CAACIARQ0HIABoQQJ0QdiowIAAaigCACIHKAIEQXhxIAJrIQEgByEFAkADQAJAIAcoAhAiAA0AIAcoAhQiAEUNAgsgACgCBEF4cSACayIHIAEgByABSSIHGyEBIAAgBSAHGyEFIAAhBwwACwsgBSgCGCEEAkACQAJAIAUoAgwiACAFRw0AIAVBFEEQIAUoAhQiABtqKAIAIgcNAUEAIQAMAgsgBSgCCCIHIAA2AgwgACAHNgIIDAELIAVBFGogBUEQaiAAGyEGA0AgBiEIIAciAEEUaiAAQRBqIAAoAhQiBxshBiAAQRRBECAHG2ooAgAiBw0ACyAIQQA2AgALIARFDQUCQAJAIAUgBSgCHEECdEHYqMCAAGoiBygCAEYNAAJAIAQoAhAgBUYNACAEIAA2AhQgAA0CDAgLIAQgADYCECAADQEMBwsgByAANgIAIABFDQULIAAgBDYCGAJAIAUoAhAiB0UNACAAIAc2AhAgByAANgIYCyAFKAIUIgdFDQUgACAHNgIUIAcgADYCGAwFCwJAAkAgACABdEECIAF0IgBBACAAa3JxaCIIQQN0IgFB6KnAgABqIgcgAUHwqcCAAGooAgAiACgCCCIGRg0AIAYgBzYCDCAHIAY2AggMAQtBACAFQX4gCHdxNgLwq8CAAAsgACACQQNyNgIEIAAgAWogASACayIHNgIAIAAgAmoiBSAHQQFyNgIEQQAoAvirwIAAIgJFDQJBACgCgKzAgAAhAQJAAkBBACgC8KvAgAAiBkEBIAJBA3Z0IghxDQBBACAGIAhyNgLwq8CAACACQXhxQeipwIAAaiICIQYMAQsgAkF4cSICQeipwIAAaiEGIAJB8KnAgABqKAIAIQILIAYgATYCCCACIAE2AgwgASAGNgIMIAEgAjYCCAwCC0EAIAVBfiAGd3E2AvCrwIAACyABIABBA3I2AgQgASAAaiIAIAAoAgRBAXI2AgQgAUEIag8LQQAgBTYCgKzAgABBACAHNgL4q8CAACAAQQhqDwtBAEEAKAL0q8CAAEF+IAUoAhx3cTYC9KvAgAALAkACQAJAIAFBEEkNACAFIAJBA3I2AgQgBSACaiIHIAFBAXI2AgQgByABaiABNgIAQQAoAvirwIAAIgZFDQFBACgCgKzAgAAhAAJAAkBBACgC8KvAgAAiCEEBIAZBA3Z0IgRxDQBBACAIIARyNgLwq8CAACAGQXhxQeipwIAAaiIGIQgMAQsgBkF4cSIGQeipwIAAaiEIIAZB8KnAgABqKAIAIQYLIAggADYCCCAGIAA2AgwgACAINgIMIAAgBjYCCAwBCyAFIAEgAmoiAEEDcjYCBCAFIABqIgAgACgCBEEBcjYCBAwBC0EAIAc2AoCswIAAQQAgATYC+KvAgAALIAVBCGoiAUUNAQwCC0EAIAJrIQECQAJAAkACQCAEQQJ0QdiowIAAaigCACIFDQBBACEHQQAhAAwBC0EAIQcgAkEAQRkgBEEBdmsgBEEfRht0IQZBACEAA0ACQCAFIgUoAgRBeHEiCCACSQ0AIAggAmsiCCABTw0AIAUhByAIIQEgCA0AQQAhASAFIQAgBSEHDAMLIAUoAhQiCCAAIAggBSAGQR12QQRxaigCECIFRxsgACAIGyEAIAZBAXQhBiAFDQALCwJAIAAgB3INAEEAIQdBAiAEdCIAQQAgAGtyIANxIgBFDQMgAGhBAnRB2KjAgABqKAIAIQALIABFDQELA0AgACgCBEF4cSIGIAJrIgUgASAFIAFJGyEIIAYgAkkhBiAHIAAgBSABTxshBAJAIAAoAhAiBQ0AIAAoAhQhBQsgASAIIAYbIQEgByAEIAYbIQcgBSEAIAUNAAsLIAdFDQACQEEAKAL4q8CAACIAIAJJDQAgASAAIAJrTw0BCyAHKAIYIQQCQAJAAkAgBygCDCIAIAdHDQAgB0EUQRAgBygCFCIAG2ooAgAiBQ0BQQAhAAwCCyAHKAIIIgUgADYCDCAAIAU2AggMAQsgB0EUaiAHQRBqIAAbIQYDQCAGIQggBSIAQRRqIABBEGogACgCFCIFGyEGIABBFEEQIAUbaigCACIFDQALIAhBADYCAAsCQCAERQ0AAkACQAJAIAcgBygCHEECdEHYqMCAAGoiBSgCAEYNAAJAIAQoAhAgB0YNACAEIAA2AhQgAA0CDAQLIAQgADYCECAADQEMAwsgBSAANgIAIABFDQELIAAgBDYCGAJAIAcoAhAiBUUNACAAIAU2AhAgBSAANgIYCyAHKAIUIgVFDQEgACAFNgIUIAUgADYCGAwBC0EAQQAoAvSrwIAAQX4gBygCHHdxNgL0q8CAAAsCQAJAIAFBEEkNACAHIAJBA3I2AgQgByACaiIAIAFBAXI2AgQgACABaiABNgIAAkAgAUGAAkkNACAAIAEQ1oCAgAAMAgsCQAJAQQAoAvCrwIAAIgVBASABQQN2dCIGcQ0AQQAgBSAGcjYC8KvAgAAgAUH4AXFB6KnAgABqIgEhBQwBCyABQfgBcSIBQeipwIAAaiEFIAFB8KnAgABqKAIAIQELIAUgADYCCCABIAA2AgwgACAFNgIMIAAgATYCCAwBCyAHIAEgAmoiAEEDcjYCBCAHIABqIgAgACgCBEEBcjYCBAsgB0EIaiIBDQELAkACQAJAQQAoAvirwIAAIgAgAk8NAAJAQQAoAvyrwIAAIgAgAksNAEEAIQEgAkEAKAKcrMCAACIAakEvakEAIABrcSIARQ0CQQAtAKSswIAAIQdBAEEBOgCkrMCAAEHArMCAACEFQYCAxIAAQcCswIAATQ0CIABBgIDEgABBwKzAgABrSw0CIAdB/wFxDQJBgIDEgABBwKzAgABrIQgMAwtBACAAIAJrIgE2AvyrwIAAQQBBACgChKzAgAAiACACaiIHNgKErMCAACAHIAFBAXI2AgQgACACQQNyNgIEIABBCGohAQwDC0EAKAKArMCAACEBAkACQCAAIAJrIgdBD0sNAEEAQQA2AoCswIAAQQBBADYC+KvAgAAgASAAQQNyNgIEIAEgAGoiACAAKAIEQQFyNgIEDAELQQAgBzYC+KvAgABBACABIAJqIgU2AoCswIAAIAUgB0EBcjYCBCABIABqIAc2AgAgASACQQNyNgIECyABQQhqDwsgAEEQdiAAQf//A3FBAEdqIgdAACIAQX9GDQFBACEBIABBEHQiBUUNASAHQRB0IgBBcGogACAFQQAgAGtGGyEIC0EAQQAoAoiswIAAIAhqIgA2AoiswIAAQQAgAEEAKAKMrMCAACIBIAAgAUsbNgKMrMCAAAJAAkACQAJAAkACQAJAAkACQAJAQQAoAoSswIAAIgFFDQBB2KnAgAAhAANAIAUgACgCACIHIAAoAgQiBmpGDQIgACgCCCIADQAMAwsLQQAoApSswIAAIgBFDQUgBSAASQ0FDAcLIAEgBU8NACAHIAFLDQAgACgCDEUNAQtBAEEAKAKUrMCAACIAIAUgACAFSRs2ApSswIAAIAUgCGohB0HYqcCAACEAAkACQAJAAkADQCAAKAIAIgYgB0YNASAAKAIIIgANAAwCCwsgACgCDEUNAQtB2KnAgAAhAANAAkAgACgCACIHIAFLDQAgASAHIAAoAgRqIgdJDQMLIAAoAgghAAwACwsgACAFNgIAIAAgACgCBCAIajYCBCAFQQ9qQXhxQXhqIgUgAkEDcjYCBCAGQQ9qQXhxQXhqIgcgBSACaiIAayEBIAdBACgChKzAgABGDQIgB0EAKAKArMCAAEYNAwJAIAcoAgQiAkEDcUEBRw0AIAcgAkF4cSICEKWAgIAAIAIgAWohASAHIAJqIgcoAgQhAgsgByACQX5xNgIEIAAgAUEBcjYCBCAAIAFqIAE2AgACQCABQYACSQ0AIAAgARDWgICAAAwGCwJAAkBBACgC8KvAgAAiAkEBIAFBA3Z0IgdxDQBBACACIAdyNgLwq8CAACABQfgBcUHoqcCAAGoiASECDAELIAFB+AFxIgFB6KnAgABqIQIgAUHwqcCAAGooAgAhAQsgAiAANgIIIAEgADYCDCAAIAI2AgwgACABNgIIDAULQQAgBUEPakF4cSIAQXhqIgY2AoSswIAAQQAgBSAAayAIQVhqIgBqQQhqIgQ2AvyrwIAAIAYgBEEBcjYCBCAFIABqQSg2AgRBAEGAgIABNgKQrMCAACABIAdBYGpBeHFBeGoiACAAIAFBEGpJGyIGQRs2AgRBACkC2KnAgAAhCSAGQRBqQQApAuCpwIAANwIAIAZBCGoiACAJNwIAQQAgCDYC3KnAgABBACAFNgLYqcCAAEEAIAA2AuCpwIAAQQBBADYC5KnAgAAgBkEcaiEAA0AgAEEHNgIAIABBBGoiACAHSQ0ACyAGIAFGDQYgBiAGKAIEQX5xNgIEIAEgBiABayIAQQFyNgIEIAYgADYCAAJAIABBgAJJDQAgASAAENaAgIAADAcLAkACQEEAKALwq8CAACIHQQEgAEEDdnQiBXENAEEAIAcgBXI2AvCrwIAAIABB+AFxQeipwIAAaiIAIQcMAQsgAEH4AXEiAEHoqcCAAGohByAAQfCpwIAAaigCACEACyAHIAE2AgggACABNgIMIAEgBzYCDCABIAA2AggMBgsgACAGIAhqNgIEQQBBACgChKzAgAAiAEEPakF4cSIBQXhqIgc2AoSswIAAQQAgACABa0EAKAL8q8CAACAIaiIBakEIaiIFNgL8q8CAACAHIAVBAXI2AgQgACABakEoNgIEQQBBgICAATYCkKzAgAAMBQtBACAANgKErMCAAEEAQQAoAvyrwIAAIAFqIgE2AvyrwIAAIAAgAUEBcjYCBAwCC0EAIAA2AoCswIAAQQBBACgC+KvAgAAgAWoiATYC+KvAgAAgACABQQFyNgIEIAAgAWogATYCAAwBC0EAIAU2ApSswIAADAELIAVBCGoPC0EAIAg2AtypwIAAQQAgBTYC2KnAgABBAEHoqcCAADYC9KnAgABBAEHwqcCAADYC/KnAgABBAEHoqcCAADYC8KnAgABBAEH4qcCAADYChKrAgABBAEHwqcCAADYC+KnAgABBAEGAqsCAADYCjKrAgABBAEH4qcCAADYCgKrAgABBAEGIqsCAADYClKrAgABBAEGAqsCAADYCiKrAgABBAEGQqsCAADYCnKrAgABBAEGIqsCAADYCkKrAgABBAEGYqsCAADYCpKrAgABBAEGQqsCAADYCmKrAgABBAEGgqsCAADYCrKrAgABBAEGYqsCAADYCoKrAgABBAEEAKAKgrMCAACIAQX8gABs2ApiswIAAQQBBADYC5KnAgABBAEGoqsCAADYCtKrAgABBAEGgqsCAADYCqKrAgABBAEGoqsCAADYCsKrAgABBAEGwqsCAADYCvKrAgABBAEGwqsCAADYCuKrAgABBAEG4qsCAADYCxKrAgABBAEG4qsCAADYCwKrAgABBAEHAqsCAADYCzKrAgABBAEHAqsCAADYCyKrAgABBAEHIqsCAADYC1KrAgABBAEHIqsCAADYC0KrAgABBAEHQqsCAADYC3KrAgABBAEHQqsCAADYC2KrAgABBAEHYqsCAADYC5KrAgABBAEHgqsCAADYC7KrAgABBAEHYqsCAADYC4KrAgABBAEHgqsCAADYC6KrAgABBAEHoqsCAADYC9KrAgABBAEHwqsCAADYC/KrAgABBAEHoqsCAADYC8KrAgABBAEHwqsCAADYC+KrAgABBAEH4qsCAADYChKvAgABBAEH4qsCAADYCgKvAgABBAEGAq8CAADYCjKvAgABBAEGAq8CAADYCiKvAgABBAEGIq8CAADYClKvAgABBAEGIq8CAADYCkKvAgABBAEGQq8CAADYCnKvAgABBAEGQq8CAADYCmKvAgABBAEGYq8CAADYCpKvAgABBAEGYq8CAADYCoKvAgABBAEGgq8CAADYCrKvAgABBAEGgq8CAADYCqKvAgABBAEGoq8CAADYCtKvAgABBAEGoq8CAADYCsKvAgABBAEGwq8CAADYCvKvAgABBAEG4q8CAADYCxKvAgABBAEGwq8CAADYCuKvAgABBAEHAq8CAADYCzKvAgABBAEG4q8CAADYCwKvAgABBAEHIq8CAADYC1KvAgABBAEHAq8CAADYCyKvAgABBAEHQq8CAADYC3KvAgABBAEHIq8CAADYC0KvAgABBAEHYq8CAADYC5KvAgABBAEHQq8CAADYC2KvAgABBAEHgq8CAADYC7KvAgABBAEHYq8CAADYC4KvAgABBACAFQQ9qQXhxIgBBeGoiATYChKzAgABBAEHgq8CAADYC6KvAgABBACAFIABrIAhBWGoiAGpBCGoiBzYC/KvAgAAgASAHQQFyNgIEIAUgAGpBKDYCBEEAQYCAgAE2ApCswIAAC0EAIQFBACgC/KvAgAAiACACTQ0AQQAgACACayIBNgL8q8CAAEEAQQAoAoSswIAAIgAgAmoiBzYChKzAgAAgByABQQFyNgIEIAAgAkEDcjYCBCAAQQhqDwsgAQvKGQEdfyOAgICAAEHwDGsiASSAgICAAAJAIAAoAggiAkUNACAAKAIEIgMgAkHQEmxqIQQgAUGgDGpBPGohAiABQaAMakEoaiEFIAFBoAxqQRRqIQYgAUHQC2pBPGohByABQdALakEoaiEIIAFB0AtqQRRqIQkgAUGAC2pBPGohCiABQYALakEoaiELIAFBgAtqQRRqIQwgAUGwCmpBPGohDSABQbAKakEoaiEOIAFBsApqQRRqIQ8gAUHgCWpBPGohECABQeAJakEoaiERIAFB4AlqQRRqIRIgAUHQCGpB7ABqIRMgAUHQCGpByABqIRQgAUHQCGpBJGohFSABQdAIakE8aiEWIAFB0AhqQShqIRcgAUHQCGpBFGohGCABQcgFakHsAGohGSABQcgFakHIAGohGiABQcgFakEkaiEbIAFByAVqQQNqIRwgAUGlAWpBA2ohHQNAIBtCADcCACAbQgA3AgggG0IANwIQIBtCADcCGCAbQQA7ASAgGkIANwIAIBpCADcCCCAaQgA3AhAgGkIANwIYIBpBADsBICAZQgA3AgAgGUIANwIIIBlCADcCECAZQgA3AhggGUEAOwEgIAFBADsB6AUgAUIANwPgBSABQgA3A9gFIAFCADcD0AUgAUIANwPIBSAPQgA3AgAgD0IANwIIIA9BADoAECAOQgA3AgAgDkIANwIIIA5BADoAECANQgA3AgAgDUIANwIIIA1BADoAECAMQgA3AgAgDEIANwIIIAxBADoAECABQQA6AMAKIAFCADcDuAogAUIANwOwCiABQgA3A4ALIAFCADcDiAsgAUEAOgCQCyALQQA6ABAgC0IANwIIIAtCADcCACAKQQA6ABAgCkIANwIIIApCADcCACAJQQA6ABAgCUIANwIIIAlCADcCACAIQQA6ABAgCEIANwIIIAhCADcCACAHQgA3AgAgB0IANwIIIAdBADoAECABQQA6AOALIAFCADcD2AsgAUIANwPQCyABQQA6ALAMIAFCADcDqAwgAUIANwOgDCAGQQA6ABAgBkIANwIIIAZCADcCACAFQQA6ABAgBUIANwIIIAVCADcCACACQQA6ABAgAkIANwIIIAJCADcCACABQQA6AOAIIAFCADcD2AggAUIANwPQCCAYQQA6ABAgGEIANwIIIBhCADcCACAXQQA6ABAgF0IANwIIIBdCADcCACAWQQA6ABAgFkIANwIIIBZCADcCACAdIAFByAVqQZAB/AoAACABIAFBsApqQdAA/AoAACABQYgDaiABQYALakHQAPwKAAAgAUG4AmogAUHQC2pB0AD8CgAAIAFB0ABqIAFBoAxqQdAA/AoAACABQdgDaiABQdAIakHQAPwKAAAgFUIANwIAIBVCADcCCCAVQgA3AhAgFUIANwIYIBVBADsBICAUQgA3AgAgFEIANwIIIBRCADcCECAUQgA3AhggFEEAOwEgIBNCADcCACATQgA3AgggE0IANwIQIBNCADcCGCATQQA7ASAgAUEAOwHwCCABQgA3A+gIIAFCADcD4AggAUIANwPYCCABQgA3A9AIIBJCADcCACASQgA3AgggEkEAOgAQIBFCADcCACARQgA3AgggEUEAOgAQIBBCADcCACAQQgA3AgggEEEAOgAQIA9CADcCACAPQgA3AgggD0EAOgAQIAFBADoA8AkgAUIANwPoCSABQgA3A+AJIAFCADcDsAogAUIANwO4CiABQQA6AMAKIA5BADoAECAOQgA3AgggDkIANwIAIA1BADoAECANQgA3AgggDUIANwIAIAxBADoAECAMQgA3AgggDEIANwIAIAtBADoAECALQgA3AgggC0IANwIAIApCADcCACAKQgA3AgggCkEAOgAQIAFBADoAkAsgAUIANwOICyABQgA3A4ALIAFBADoA4AsgAUIANwPYCyABQgA3A9ALIAlBADoAECAJQgA3AgggCUIANwIAIAhBADoAECAIQgA3AgggCEIANwIAIAdBADoAECAHQgA3AgggB0IANwIAIAFBADoAsAwgAUIANwOoDCABQgA3A6AMIAZBADoAECAGQgA3AgggBkIANwIAIAVBADoAECAFQgA3AgggBUIANwIAIAJBADoAECACQgA3AgggAkIANwIAIBwgAUHQCGpBkAH8CgAAIAFBqARqIAFB4AlqQdAA/AoAACABQbAHaiABQbAKakHQAPwKAAAgAUHgBmogAUGAC2pB0AD8CgAAIAFB+ARqIAFB0AtqQdAA/AoAACABQYAIaiABQaAMakHQAPwKAAAgA0IANwMYIANCADcDECADQgA3AwggA0IANwMAIANB6ABqQgA3AAAgA0HkAGpB/wE6AAAgA0HwAGpCADcAACADQfgAakIANwAAIANBgAFqQgA3AAAgA0GIAWogAUHYA2pB0AD8CgAAIANB3AFqQQA6AAAgA0HYAWpBADsBACADQeABakEAQc0A/AsAIANB1AJqQgA3AAAgA0HQAmpB/wE6AAAgA0HcAmpCADcAACADQeQCakIANwAAIANB7AJqQgA3AAAgA0H0AmpBADoAACADQfgCakIANwAAIANBgANqQgA3AAAgA0GIA2pCADcAACADQZADakEANgAAIANBlANqIAFBiANqQdAA/AoAACADQZAEakIANwAAIANBjARqQf8BOgAAIANB6ANqQQA6AAAgA0HkA2pBADsBACADQZgEakIANwAAIANBoARqQgA3AAAgA0GoBGpCADcAACADQbAEakEAOgAAIANBtARqQgA3AAAgA0G8BGpCADcAACADQcQEakIANwAAIANBzARqQQA2AAAgA0HQBGogAUG4AmpB0AD8CgAAIANBpAVqQQA6AAAgA0GgBWpBADsBACADQaUFaiABQaUBakGTAfwKAAAgA0HwBmpBADYCACADQegGakIANwMAIANB4AZqQgA3AwAgA0HYBmpCADcDACADQdAGakIANwMAIANByAZqQgA3AwAgA0HABmpCADcDACADQbgGakIANwMAIANBvAdqQgA3AAAgA0G4B2pB/wE6AAAgA0GUB2pB/wE6AAAgA0HEB2pCADcAACADQcwHakIANwAAIANB1AdqQQA2AAAgA0HYB2ogAUHQAGpB0AD8CgAAIANBsAhqQgA3AAAgA0GsCGpBADoAACADQagIakEAOwEAIANBuAhqQgA3AAAgA0HACGpCADcAACADQcgIakEANgAAIANBzAhqIAFB0AD8CgAAIANBqAlqQgA3AwAgA0GgCWpBADoAACADQZwJakEAOwEAIANBsAlqQgA3AwAgA0G4CWpCADcDACADQcAJakIANwMAIANBkApqQgA3AAAgA0GMCmpB/wE6AAAgA0GYCmpCADcAACADQaAKakIANwAAIANBqApqQgA3AAAgA0GwCmogAUGACGpB0AD8CgAAIANBhAtqQQA6AAAgA0GAC2pBADsBACADQYgLakEAQc0A/AsAIANB/AtqQgA3AAAgA0H4C2pB/wE6AAAgA0GEDGpCADcAACADQYwMakIANwAAIANBlAxqQgA3AAAgA0GcDGpBADoAACADQaAMakIANwAAIANBqAxqQgA3AAAgA0GwDGpCADcAACADQbgMakEANgAAIANBvAxqIAFBsAdqQdAA/AoAACADQbgNakIANwAAIANBtA1qQf8BOgAAIANBkA1qQQA6AAAgA0GMDWpBADsBACADQcANakIANwAAIANByA1qQgA3AAAgA0HQDWpCADcAACADQdgNakEAOgAAIANB3A1qQgA3AAAgA0HkDWpCADcAACADQewNakIANwAAIANB9A1qQQA2AAAgA0H4DWogAUHgBmpB0AD8CgAAIANBzA5qQQA6AAAgA0HIDmpBADsBACADQc0OaiABQcgFakGTAfwKAAAgA0GYEGpBADYCACADQZAQakIANwMAIANBiBBqQgA3AwAgA0GAEGpCADcDACADQfgPakIANwMAIANB8A9qQgA3AwAgA0HoD2pCADcDACADQeAPakIANwMAIANB5BBqQgA3AAAgA0HgEGpB/wE6AAAgA0G8EGpB/wE6AAAgA0HsEGpCADcAACADQfQQakIANwAAIANB/BBqQQA2AAAgA0GAEWogAUH4BGpB0AD8CgAAIANB2BFqQgA3AAAgA0HUEWpBADoAACADQdARakEAOwEAIANB4BFqQgA3AAAgA0HoEWpCADcAACADQfARakEANgAAIANB9BFqIAFBqARqQdAA/AoAACADQcgSakEAOgAAIANBxBJqQQA7AQAgA0HQEmoiAyAERw0ACwsgAEEANgI4IABB4AhqQQBB0AL8CwAgAEF/NgKwIyABQfAMaiSAgICAAAupggIqCX8BfgF/BH4mfwl9AX8CfQV/En0CfAF/BX0BfwF9AX8GfQF/A30BfwJ9An8CfQF/An0CfwR9An8EfQF/BH0DfwN9AX8CfQF/AX0Cfwp9AX8CfQF8I4CAgIAAQeAKayICJICAgIAAIAAoAjghA0EAIQQgAEEANgI4IAAoAjQhBSAAKAIwIQYgAEKAgICAwAA3AjAgAUGAAUkhBwJAIANBAkkNAEEBIQgDQCAIQQFqIQggBCEJAkADQCAFIAlqIgpBJGooAgAgCkHQAGooAgBNDQEgCikCACELIAogCkEsaiIMKQIANwIAIAopAgghDSAKIAwpAgg3AgggCikCECEOIAogDCkCEDcCECAKKQIYIQ8gCiAMKQIYNwIYIAopAiAhECAKIAwpAiA3AiAgCigCKCERIAogDCgCKDYCKCACIBE2AugDIAIgEDcD4AMgAiAPNwPYAyACIA43A9ADIAIgDTcDyAMgAiALNwPAAyAMIAIpA8ADNwIAIAwgAigC6AM2AiggDCACKQPgAzcCICAMIAIpA9gDNwIYIAwgAikD0AM3AhAgDCACKQPIAzcCCCAJQVRqIglBVEcNAAsLIARBLGohBCAIIANHDQALCyABQYABIAcbIRICQAJAAkACQAJAAkACQAJAAkACQCABRQ0AIABBsBtqIRMgAEGwE2ohFCAAQbALaiEVIAJBowlqQStqIRYgAkGjCWpBF2ohFyACQaMJakEDaiEYIAJBwANqQStqIRkgAkHAA2pBF2ohGiACQcADakEDaiEbIAJBoQpqQStqIRwgAkGhCmpBF2ohHSACQaEKakEDaiEeIAJB4glqQStqIR8gAkHiCWpBF2ohICACQeIJakEDaiEhIAJBK2ohIiACQRdqISMgAkEDaiEkIAJB8ABqQStqISUgAkHwAGpBF2ohJiACQfAAakEDaiEnIAJB5AhqQStqISggAkHkCGpBF2ohKSACQeQIakEDaiEqIAJBjQdqQQNqISsgAkGsB2pBA2ohLCACQfwDaiEtIAJB6ANqIS4gAkHAA2pBFGohLyACQeAEaiEwIAJB5AJqITEgAkEcaiEyQQAhM0EAITRBACE1A0AgEiE2AkAgNCADTw0AAkADQAJAIAUgNEEsbGoiCigCJCIMIDNNDQAgDCASIAwgEkkbITYMAwsCQCAKKgIAIje8QQF0Qf///3dLDQAgCioCBCI4vEEBdEH///93Sw0AIAoqAggiObxBAXRB////d0sNACAKKgIMIjq8QQF0Qf///3dLDQAgCioCECI7vEEBdEH///93Sw0AIAooAhRBAXRB////d0sNACAKKAIYQQF0Qf///3dLDQAgCioCHCI8vEEBdEH///93Sw0AIAoqAighPSAKKAIgIQQgACoCPCI+ID6SIT8CQCAAKAIgIgpFDQAgCkECdCERIAAoAhwhCUEBIAR0IQggACgCBEHIEmohDCAAKAIIIQdBACEKQwAAgL8gP0Omm0Q7lJUQ2YCAgAAhPgNAAkAgBCAKRg0AIAkoAgAgCHFFDQACQAJAIAogB08NACAMQdh2ai0AAEUNASAMQbhvaiJAID4gQCoCACJBIEEgQVwbIkEgQSA+ID4gPlwbIkIgQSBCXRs4AgAMAQsgCiAHQcSJwIAAEIuAgIAAAAsgDC0AAEEBRw0AIAxB4HhqIkAgPiBAKgIAIkEgQSBBXBsiQSBBID4gPiA+XBsiQiBBIEJdGzgCAAsgCUEEaiEJIApBAWohCiAMQdASaiEMIBFBfGoiEQ0ACwsCQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkAgBCAAKAIUIgpPDQAgBCAAKAIIIgpPDQEgACgCECAEQQJ0aiIMKAIAIgpBAk8NAgJAIAAoAgQgBEHQEmwiQ2ogCkGoCWxqIgktAKAJRQ0AIAkqAoACIT4gCUMAAIC/ID9DbxIDO5SVENmAgIAAIkEgPiA+ID5cGyI+ID4gQSBBIEFcGyJBID4gQV0bOAKAAgsgDCAKQQFzIkQ2AgAgACAAKAK0IyIKQQ10IApzIgpBEXYgCnMiCkEFdCAKcyIKQQ10IApzIgxBEXYgDHMiDEEFdCAMcyIMQQ10IAxzIglBEXYgCXMiCUEFdCAJcyIJQQ10IAlzIhFBEXYgEXMiEUEFdCARcyIRQQ10IBFzIghBEXYgCHMiCEEFdCAIcyIIQQ10IAhzIgdBEXYgB3MiB0EFdCAHcyIHQQ10IAdzIkBBEXYgQHMiQEEFdCBAcyJFNgK0IyAALQC4IyJALQC8pMCAACJGQX9qIkcgBCBHIARJGyJHIEZPDSAgRbNDAACAL5QiPiA+kkMAAIC/kkMAAAA/lEMAAAA/kiFIIAezQwAAgC+UIj4gPpJDAACAv5JDAAAAP5RDAAAAP5IhSSAIs0MAAIAvlCI+ID6SQwAAgL+SQwAAAD+UQwAAAD+SIUogEbNDAACAL5QiPiA+kkMAAIC/kkMAAAA/lEMAAAA/kiFLIAmzQwAAgC+UIj4gPpJDAACAv5JDAAAAP5RDAAAAP5IhTCAMs0MAAIAvlCI+ID6SQwAAgL+SQwAAAD+UQwAAAD+SIU0gCrNDAACAL5QiPiA+kkMAAIC/kkOmm0Q7lEMAAIA/kiE+IEBBAnQoAsSkwIAAIEdBAnRqKgIAIUEgHkEAOgAQIB5CADcACCAeQgA3AAAgHUIANwAAIB1CADcACCAdQQA6ABAgHEIANwAAIBxCADcACCAcQQA6ABAgL0IANwIAIC9CADcCCCAvQQA6ABAgLkIANwIAIC5CADcCCCAuQQA6ABAgAkIANwPAAyACQgA3A8gDIAJBADoA0AMgLUEAOgAQIC1CADcCCCAtQgA3AgAgJEIANwAAICRCADcACCAkQQA6ABAgI0IANwAAICNCADcACCAjQQA6ABAgIkIANwAAICJCADcACCAiQQA6ABAgJ0IANwAAICdCADcACCAnQQA6ABAgJkIANwAAICZCADcACCAmQQA6ABAgJUEAOgAQICVCADcACCAlQgA3AAAgAkIANwOIBiACQgA3A4AGIAJCADcD+AUgAiACKQDYCjcA7wUgAiACKQDRCjcD6AUgAiACKQDJCjcD4AUgAiACKQDBCjcD2AUgAiACKQC5CjcD0AUgAiACKQCxCjcDyAUgAiACKQCpCjcDwAUgAiACKQChCjcDuAUgAkGAAmogAkHAA2pB0AD8CgAAIAIgAikANzcAxwYgAiACKQAwNwPABiACIAIpACg3A7gGIAIgAikAIDcDsAYgAiACKQAYNwOoBiACIAIpABA3A6AGIAIgAikACDcDmAYgAiACKQAANwOQBiACIAIpAHA3A4gIIAIgAikAeDcDkAggAiACKQCAATcDmAggAiACKQCIATcDoAggAiACKQCQATcDqAggAiACKQCYATcDsAggAiACKQCgATcDuAggAiACKQCnATcAvwggLEIANwAAICxCADcACCAsQgA3ABAgLEIANwAYICxBADoAICArQgA3AAAgK0IANwAIICtCADcAECArQQA2ABggAkIANwPQByACQgA3A9gHIAJCADcD4AcgAkIANwPQBiACQgA3A9gGIAJCADcD4AYgAkIANwPYCCACQgA3A9AIIAJCADcDyAggAkIANwOACCACQgA3A/gHQwAAIEEgQUMAAKDBlRDmgICAACFOIEAOBQMEBQYGAwsgBCAKQdSJwIAAEIuAgIAAAAsgBCAKQeSJwIAAEIuAgIAAAAsgCkECQfSJwIAAEIuAgIAAAAtDAACgPyFPIAQOCgQFBgcMCwgICQoDC0NmZmY/IU8gBA4EDg8QEhELIDcgPpQhPiAEDgYTFhcSGBQSCyA/QwAAAD+UIkFDZmbmPpQiUEMAAKBBYEUNGiBQQwAAekQgUEMAAHpEXRtD2w9JQJQgQSBBkiJRlRDjgICAABpBACFGIFBDAACgQSA5IDlDAACgQV0bIkEgQSBQXhtD2w9JQJQgUZUQ44CAgAAhQSAqQQA6ABBCACELICpCADcACCAqQgA3AAAgKUIANwAAIClCADcACCApQQA6ABAgKEIANwAAIChCADcACCAoQQA6ABAgAkIANwPAAyACQgA3A8gDIAJCADcDyAggAkIANwPQCCACQgA3A9gIIAIgAikA5Ag3A4gIIAIgAikA7Ag3A5AIIAIgAikA9Ag3A5gIIAIgAikA/Ag3A6AIIAIgAikAhAk3A6gIIAIgAikAjAk3A7AIIAIgAikAlAk3A7gIIAIgAikAmwk3AL8IIEFDAACAPyBBQwAAgD+SlSJSlCJTIFMgU5QiVJQhVUMAAIA/ID9DbxKDOpQiQSBBIEFcGyJBQwAAgD8gQUMAAIA/XhshVkMAAIA/IFQgVJQiV0PNzEw+lEMAAIA/kpUhWEMAAAAAIVkgO0MAAAAAlyA3ID6UIj6UuyFaID67ID+7oyFbID9DAAAAAJT8ASFcQQEhCEH/ASFHQzMzk8BDbxKDOiA4IDggOFwbIj5DbxKDOiA+Q28SgzpeGyA/lJUQ2YCAgAAhXUMAAAAAIV5DAAAAACFfQwAAAAAhYEMAAAAAIWFBACFiQwAAAAAhY0EAIWRDAAAAACFNQwAAAAAhTEMAAAAAIUtDAAAAACFKQwAAAAAhSUMAAAAAIUhDAAAAACFlQwAAAAAhZkMAAAAAIWdDAAAAACFoQwAAAAAhaUMAAAAAIWpBACFrQwAAAAAhbEMAAAAAIW1DAAAAACFuQwAAAAAhO0EAIUBBACFvQQAhCUMAAAAAIXBDAAAAACFxQwAAAAAhT0EAIXJB/wEhc0MAAAAAIXRDAAAAACF1QQAhdkEAIRFDAAAAACE5QwAAAAAhd0MAAAAAIXhBACF5QQAhekMAAAAAIXtDAAAAACF8QwAAAAAhfUIAIQ1DAAAAACF+QQAhf0EAIYABQwAAAAAhgQFDAAAAACGCAUMAAAAAIYMBQwAAAAAhhAFBACE2Qf8BIYUBQwAAAAAhhgFDAAAAACGHAUEAIQdBACEMQwAAAAAhiAFDAAAAACGJAUMAAAAAIUFBACGKAUMAAAAAIUJDAAAAACE3QQAhiwFBACGMAUMAAAAAIY0BQwAAAAAhjgFDAAAAACGPAUEAIZABQwAAAAAhkQFDAAAAACGSAUMAAAAAIT5BACGTAUMAAAAAIZQBQQEhlQEgBCGWAQw0CyAYQQA6ABAgGEIANwAIIBhCADcAACAXQgA3AAAgF0IANwAIIBdBADoAECAWQgA3AAAgFkIANwAIIBZBADoAECACQgA3A9AGIAJCADcD2AYgAkIANwPgBiACIAIpAKMJNwOQBiACIAIpAKsJNwOYBiACIAIpALMJNwOgBiACIAIpALsJNwOoBiACIAIpAMMJNwOwBiACIAIpAMsJNwO4BiACIAIpANMJNwPABiACIAIpANoJNwDHBiA/Q0jh+j6UIkFDAAAgQWBFDRpCACELIEFDAAAlRSBBQwAAJUVdG0PbD0lAlCA/lRDjgICAACFBIAJCADcDgAcgAkIANwP4BkMAAIA/ID9DbxIDOpQiQiBCIEJcGyJCQwAAgD8gQkMAAIA/XhshcUNu2zY/IZcBIEEgQUMAAIA/IEEgQUNu2zY/kpRDAACAP5KVIpgBlCKZAZQhmgEgNyA+lCI+QwAAB0SUID+VIWUgPkMAAEhElCA/lSFmQwAAAAAhWSA/QwAAAACU/AEhckQAAAAAAAAAACFaQ2Zmpj8hPkECIXZDAAAAPyF1Qf8BIUdDZmZmPyFPQQEha0EAIUZDMzOTwENvEoM6IDggOCA4XBsiQUNvEoM6IEFDbxKDOl4bID+UlRDZgICAACFwQwAAAAAhXkMAAAAAIV9DAAAAACFgQwAAAAAhYUEAIWJDAAAAACFjQQAhZEMAAAAAIWdDAAAAACFoQwAAAAAhaUMAAAAAIWpDAAAAACFsQwAAAAAhbUMAAAAAIW5DAAAAACE7QQAhQEEAIW9BASEJQQEhc0MAAAAAIXQMLQsgG0EAOgAQIBtCADcACCAbQgA3AAAgGkIANwAAIBpCADcACCAaQQA6ABAgGUIANwAAIBlCADcACCAZQQA6ABAgAkIANwP4BSACQgA3A4AGIAJCADcDiAYgAiACKQDAAzcDuAUgAiACKQDIAzcDwAUgAiACKQDQAzcDyAUgAiACKQDYAzcD0AUgAiACKQDgAzcD2AUgAiACKQDoAzcD4AUgAiACKQDwAzcD6AUgAiACKQD3AzcA7wUgP0NI4fo+lCJBQwAAIEFgRQ0aQgAhCyBBQwDAWkUgQUMAwFpFXRtD2w9JQJQgP5UQ44CAgAAhQSACQgA3A4AIIAJCADcD+AdDAACAPyE7QwAAgD8gP0Omm8Q6lCJCIEIgQlwbIkJDAACAPyBCQwAAgD9eGyFuQ27btj8hkgEgQSBBQwAAgD8gQSBBQ27btj+SlEMAAIA/kpUikQGUIocBlCGGASA3ID6UID+VIYMBID9DF7fROZT8ASGTAUMAAAAAIVkgP0MAAAAAlPwBIUBDAABAwCA/Q83MzDyUlRDZgICAALwhZEQAAAAAAAAAACFaQwAAgD4hlAFDzczMPyE+QYCAgPwDITZDj8J1PSGBAUEBIW9B/wEhR0EAIUZDMzOTwENvEoM6IDggOCA4XBsiQUNvEoM6IEFDbxKDOl4bID+UlRDZgICAACFtQwAAAAAhXkMAAAAAIV9DAAAAACFgQwAAAAAhYUEAIWJDAAAAACFjQwAAAAAhTUMAAAAAIUxDAAAAACFLQwAAAAAhSkMAAAAAIUlDAAAAACFIQwAAAAAhZUMAAAAAIWZDAAAAACFnQwAAAAAhaEMAAAAAIWlDAAAAACFqQQAha0MAAAAAIWxBACEJQwAAAAAhcEMAAAAAIXFDAAAAACFPQQAhckH/ASFzQwAAAAAhdEMAAAAAIXVBACF2QQAhEUMAAAAAITlDAAAAACF3QwAAAAAheEEAIXlBACF6QwAAAAAhe0MAAAAAIXxDAAAAACF9QgAhDUMAAAAAIX5BACF/QQEhgAFDAACAPyGCAUMAAAAAIYQBQf8BIYUBQQAhB0EAIQxDAAAAACGIAUMAAAAAIYkBQwAAAAAhQUEAIYoBQwAAAAAhQkMAAAAAITdBACGLAUEAIYwBQwAAAAAhjQFDAAAAACGOAUMAAAAAIY8BQQAhkAEMMQsgG0EAOgAQIBtCADcACCAbQgA3AAAgGkIANwAAIBpCADcACCAaQQA6ABAgGUIANwAAIBlCADcACCAZQQA6ABAgAkIANwP4BSACQgA3A4AGIAJCADcDiAYgAiACKQDAAzcDuAUgAiACKQDIAzcDwAUgAiACKQDQAzcDyAUgAiACKQDYAzcD0AUgAiACKQDgAzcD2AUgAiACKQDoAzcD4AUgAiACKQDwAzcD6AUgAiACKQD3AzcA7wUgP0NI4fo+lCJBQwAAIEFgRQ0aQgAhCyBBQwAA4UQgQUMAAOFEXRtD2w9JQJQgP5UQ44CAgAAhQSACQgA3A+AHIAJCADcD2AcgAkIANwPQB0MAAIA/ID9DbxIDOpQiQiBCIEJcGyJCQwAAgD8gQkMAAIA/XhshjgFDAACAPyA/Q6abxDqUIkIgQiBCXBsiQkMAAIA/IEJDAACAP14bIW5Dq6qqPyFsIEEgQUMAAIA/IEEgQUOrqqo/kpRDAACAP5KVIlmUIl6UIV8gOEOamRk/lCGPAUMAAIA/IDdDmpkZP5STIYIBIDdDZmYmP5RDMzOzPpIhfCA5ID6UIj5DAAA5Q5QgP5UhgwEgPkMAAKVDlCA/lSF9QwAAAAAhYCA/QwAAAACU/AEhQEMAAEDAID9DCtcjPJSVENmAgIAAvCJkrSENRAAAAAAAAAAAIVpDZmamPyE+QZCuj+0DITZDENejPSF+QwrXozwhe0EBIWJB/wEhR0EAIWtDzcwMPyE7QQIhRkMzM5PAIDpDbxKDOpcgP5SVENmAgIAAIY0BQzMzk8AgOkNmZiY/lENvEoM6lyA/lJUQ2YCAgAAhbUMAAAAAIWFDAAAAACFjQwAAAAAhTUMAAAAAIUxDAAAAACFLQwAAAAAhSkMAAAAAIUlDAAAAACFIQwAAAAAhZUMAAAAAIWZDAAAAACFnQwAAAAAhaEMAAAAAIWlDAAAAACFqQQEhb0EAIQlDAAAAACFwQwAAAAAhcUMAAAAAIU9BACFyQf8BIXNDAAAAACF0QwAAAAAhdUEAIXZBACERQwAAAAAhOUMAAAAAIXdDAAAAACF4QQAheUEBIXpBACF/QQEhgAFDCtejPCGBAQwoCyAbQQA6ABAgG0IANwAIIBtCADcAACAaQgA3AAAgGkIANwAIIBpBADoAECAZQgA3AAAgGUIANwAIIBlBADoAECACQgA3A/gFIAJCADcDgAYgAkIANwOIBiACIAIpAMADNwO4BSACIAIpAMgDNwPABSACIAIpANADNwPIBSACIAIpANgDNwPQBSACIAIpAOADNwPYBSACIAIpAOgDNwPgBSACIAIpAPADNwPoBSACIAIpAPcDNwDvBSA/Q0jh+j6UIkFDAAAgQWBFDRpCACELIEFDAECcRSBBQwBAnEVdG0PbD0lAlCA/lRDjgICAACFBIAJCADcD4AcgAkIANwPYByACQgA3A9AHQwAAgD8hfEMAAIA/ID9DbxIDOpQiQiBCIEJcGyJCQwAAgD8gQkMAAIA/XhshjgFDAACAPyA/Q6abxDqUIkIgQiBCXBsiQkMAAIA/IEJDAACAP14bIW5Dq6qqPyFsIEEgQUMAAIA/IEEgQUOrqqo/kpRDAACAP5KVIlmUIl6UIV8gNyA+lCI+QwCA40OUID+VIYMBID5DAGDQRJQgP5UhfUMAAAAAIWAgP0MAAAAAlPwBIUBDAABAwCA/Q28SgzqUlRDZgICAALwiZK0hDUQAAAAAAAAAACFaQwAAAEAhPkMAAAA/IY8BQ5qZGT8hggFBASFiQf8BIUdBACFrQzMzMz8hO0ECIUZDMzOTwENvEoM6IDggOCA4XBsiQUNvEoM6IEFDbxKDOl4bID+UlRDZgICAACFtQzMzk8BDbxKDOiA4Q4mIiD6UIkEgQSBBXBsiQUNvEoM6IEFDbxKDOl4bID+UlRDZgICAACGNAUMAAAAAIWFDAAAAACFjQwAAAAAhTUMAAAAAIUxDAAAAACFLQwAAAAAhSkMAAAAAIUlDAAAAACFIQwAAAAAhZUMAAAAAIWZDAAAAACFnQwAAAAAhaEMAAAAAIWlDAAAAACFqQQEhb0EAIQlDAAAAACFwQwAAAAAhcUMAAAAAIU9BACFyQf8BIXNDAAAAACF0QwAAAAAhdUEAIXZBACERQwAAAAAhOUMAAAAAIXdDAAAAACF4QQEheUEBIXpDAAAAACF7QwAAAAAhfkEBIX9BASGAAUMAAAAAIYEBQwAAAAAhhAFBACE2DCgLID9DSOH6PpQiPkMAACBBYEUNGkIAIQsgPkMAACBBIDdDAAB6RJQiQSBBQwAAIEFdGyJBIEEgPl4bQ9sPSUCUID+VEOOAgIAAIT4gAkIANwPgByACQgA3A9gHIAJCADcD0AdDbts2PyFsID4gPkMAAIA/ID4gPkNu2zY/kpRDAACAP5KVIlmUIl6UIV9DAACAPyA/Q28SAzqUIj4gPiA+XBsiPkMAAIA/ID5DAACAP14bIYkBID9DbxIDPZT8ASGKASA/QzEIrDyU/AEhiwEgP0MK1yM8lPwBIYwBQwAAAAAhYyA/QwAAAACU/AEhkAFEAAAAAAAAAAAhWkOamZk/IT5DMzOzPyFBQf8BIUdBACFkQQQhYkEBIUZDq6oqPyFhQwAAwD8hYEMzM5PAID9DbxKDPJSVENmAgIAAIUJDMzOTwENvEoM6IDggOCA4XBsiOENvEoM6IDhDbxKDOl4bID+UlRDZgICAACGIAUMAAAAAIU1DAAAAACFMQwAAAAAhS0MAAAAAIUpDAAAAACFJQwAAAAAhSEMAAAAAIWVDAAAAACFmQwAAAAAhZ0MAAAAAIWhDAAAAACFpQwAAAAAhakEAIWtDAAAAACFtQwAAAAAhbkMAAAAAITtBACFAQQAhb0EAIQlDAAAAACFwQwAAAAAhcUMAAAAAIU9BACFyQf8BIXNDAAAAACF0QwAAAAAhdUEAIXZBACERQwAAAAAhOUMAAAAAIXdDAAAAACF4QQAheUEAIXpDAAAAACF7QwAAAAAhfEMAAAAAIX1CACENQwAAAAAhfkEAIX9BACGAAUMAAAAAIYEBQwAAAAAhggFDAAAAACGDAUMAAAAAIYQBQQAhNkH/ASGFAUMAAAAAIYYBQwAAAAAhhwFBASEHQQEhDCBCIY0BQwAAgD8gP0MXt9E5lCI4IDggOFwbIjhDAACAPyA4QwAAgD9eGyI3IY4BQzMzsz8hjwEMLQsgG0EAOgAQIBtCADcACCAbQgA3AAAgGkIANwAAIBpCADcACCAaQQA6ABAgGUIANwAAIBlCADcACCAZQQA6ABAgAkIANwP4BSACQgA3A4AGIAJCADcDiAYgAiACKQDAAzcDuAUgAiACKQDIAzcDwAUgAiACKQDQAzcDyAUgAiACKQDYAzcD0AUgAiACKQDgAzcD2AUgAiACKQDoAzcD4AUgAiACKQDwAzcD6AUgAiACKQD3AzcA7wUgP0NI4fo+lCJBQwAAIEFgRQ0aQgAhCyBBQwCAO0UgQUMAgDtFXRtD2w9JQJQgP5UQ44CAgAAhQSACQgA3A+AHIAJCADcD2AcgAkIANwPQB0MAAIA/IYIBQwAAgD8gP0NSSZ05lCJCIEIgQlwbIkJDAACAPyBCQwAAgD9eGyGOAUMAAIA/ID9DppvEOpQiQiBCIEJcGyJCQwAAgD8gQkMAAIA/XhshbkOrqqo/IWwgQSBBQwAAgD8gQSBBQ6uqqj+SlEMAAIA/kpUiWZQiXpQhXyA3ID6UIj4gP5UhgwEgPkMAAMA/lCA/lSF9QwAAAAAhYEMAAEDAID9Dj8J1PZSVENmAgIAAvCJkrSENRAAAAAAAAAAAIVpDZmamPyE+QZqz5vgDITZDzcxMPSGBAUOamRk/IX5DmpkZPiF8QQEhYkH/ASFHQQAha0NmZmY/ITtBAiFGQzMzk8AgP0MK1yM8lJUQ2YCAgAAhjQFDMzOTwENvEoM6IDggOCA4XBsiQUNvEoM6IEFDbxKDOl4bID+UlRDZgICAACFtQwAAAAAhYUMAAAAAIWNDAAAAACFNQwAAAAAhTEMAAAAAIUtDAAAAACFKQwAAAAAhSUMAAAAAIUhDAAAAACFlQwAAAAAhZkMAAAAAIWdDAAAAACFoQwAAAAAhaUMAAAAAIWpBASFvQQAhCUMAAAAAIXBDAAAAACFxQwAAAAAhT0EAIXJB/wEhc0MAAAAAIXRDAAAAACF1QQAhdkEAIRFDAAAAACE5QwAAAAAhd0MAAAAAIXhBASF5QQEhekMAAAAAIXtBACF/QQEhgAFDAAAAACGEAUH/ASGFAUMAAAAAIYYBQwAAAAAhhwFBASEHQQAhDEMAAAAAIYgBQwAAAAAhiQFDAAAAACFBQQAhigFDAAAAACFCQwAAAAAhN0EAIYsBQQAhjAFDmpkZPiGPASA/QwAAAACU/AEiQCGQAQwsCyAhQQA6ABAgIUIANwAIICFCADcAACAgQgA3AAAgIEIANwAIICBBADoAECAfQgA3AAAgH0IANwAIIB9BADoAECACQgA3A9AGIAJCADcD2AYgAkIANwPgBiACIAIpAOIJNwOQBiACIAIpAOoJNwOYBiACIAIpAPIJNwOgBiACIAIpAPoJNwOoBiACIAIpAIIKNwOwBiACIAIpAIoKNwO4BiACIAIpAJIKNwPABiACIAIpAJkKNwDHBiA/Q0jh+j6UIkFDAAAgQWBFDRpCACELIEFDAAAgQSA4QwDA2kWUIkIgQkMAACBBXRsiQiBCIEFeG0PbD0lAlCA/lRDjgICAACFCIAJCADcDgAcgAkIANwP4BiBBQwAAIEEgOEMAQJxFlCI4IDhDAAAgQV0bIjggOCBBXhtD2w9JQJQgP5UQ44CAgAAhQSACQgA3A/AGIAJCADcD6AZDAAAAQCGXASBCIEJDAACAPyBCIEJDAAAAQJKUQwAAgD+SlSKYAZQimQGUIZoBIEEgQUMAAIA/IEEgQUOrqqo/kpRDAACAP5KVIpsBlCKcAZQhnQFDAACAPyA/Q28SAzuUIkEgQSBBXBsiQUMAAIA/IEFDAACAP14bIXEgPkPNTE1DlCA/lSFlID5DMzOYQ5QgP5UhZiA+Q83MuEOUID+VIWcgPkPNrAJElCA/lSFoID5DAAAHRJQgP5UhaSA+QwAASESUID+VIWpDAAAAACFZID9DAAAAAJT8ASFyRAAAAAAAAAAAIVpDmpmZPyE+Qf8BIYUBQQYhdkMAAAA/IXVDMzOzPiF0QQIhR0MAAEA/IU9BASFrQQAhRkMzM5PAQ28SgzogNyA3IDdcGyJBQ28SgzogQUNvEoM6XhsgP5SVENmAgIAAIXBDAAAAACFeQwAAAAAhX0MAAAAAIWBDAAAAACFhQQAhYkMAAAAAIWNBACFkQwAAAAAhbEMAAAAAIW1DAAAAACFuQwAAAAAhO0EAIUBBACFvQQEhCUEBIXMMBAsgHkEAOgAQIB5CADcACCAeQgA3AAAgHUIANwAAIB1CADcACCAdQQA6ABAgHEIANwAAIBxCADcACCAcQQA6ABAgAkIANwPQBiACQgA3A9gGIAJCADcD4AYgAiACKQChCjcDkAYgAiACKQCpCjcDmAYgAiACKQCxCjcDoAYgAiACKQC5CjcDqAYgAiACKQDBCjcDsAYgAiACKQDJCjcDuAYgAiACKQDRCjcDwAYgAiACKQDYCjcAxwYgP0NI4fo+lCJBQwAAIEFgRQ0aQgAhCyBBQwAAIEEgOEMAAJZFlCJCIEJDAAAgQV0bIkIgQiBBXhtD2w9JQJQgP5UQ44CAgAAhQiACQgA3A4AHIAJCADcD+AYgQUMAACBBIDhDAIA7RZQiOCA4QwAAIEFdGyI4IDggQV4bQ9sPSUCUID+VEOOAgIAAIUEgAkIANwPwBiACQgA3A+gGQ83MzD4hlwEgQiBCQwAAgD8gQiBCQ83MzD6SlEMAAIA/kpUimAGUIpkBlCGaASBBIEFDAACAPyBBIEFDq6qqP5KUQwAAgD+SlSKbAZQinAGUIZ0BQwAAgD8gP0NvEoM6lCJBIEEgQVwbIkFDAACAPyBBQwAAgD9eGyFxID5D16OQP5QiPkPNTE1DlCA/lSFlID5DMzOYQ5QgP5UhZiA+Q83MuEOUID+VIWcgPkPNrAJElCA/lSFoID5DAAAHRJQgP5UhaSA+QwAASESUID+VIWpDAAAAACFZID9DAAAAAJT8ASFyRAAAAAAAAAAAIVpDmpmZPyE+Qf8BIYUBQQYhdkMAAAA/IXVBAiFHQ83MTD8hT0EBIWtBACFGQzMzk8BDbxKDOiA3IDcgN1wbIkFDbxKDOiBBQ28SgzpeGyA/lJUQ2YCAgAAhcAwCC0MAAIA/IU8LICRBADoAECAkQgA3AAggJEIANwAAICNCADcAACAjQgA3AAggI0EAOgAQICJCADcAACAiQgA3AAggIkEAOgAQIAJCADcD0AYgAkIANwPYBiACQgA3A+AGIAIgAikAADcDkAYgAiACKQAINwOYBiACIAIpABA3A6AGIAIgAikAGDcDqAYgAiACKQAgNwOwBiACIAIpACg3A7gGIAIgAikAMDcDwAYgAiACKQA3NwDHBiA/Q0jh+j6UIkFDAAAgQWBFDRlCACELIEFDAAAgQSA4QwBAHEaUIkIgQkMAACBBXRsiQiBCIEFeG0PbD0lAlCA/lRDjgICAACFCIAJCADcDgAcgAkIANwP4BiBBQwAAIEEgOEMAwNpFlCI4IDhDAAAgQV0bIjggOCBBXhtD2w9JQJQgP5UQ44CAgAAhQSACQgA3A/AGIAJCADcD6AZDAACAPyGXASBCIEJDAACAPyBCIEJDAACAP5KUQwAAgD+SlSKYAZQimQGUIZoBIEEgQUMAAIA/IEEgQUOrqqo/kpRDAACAP5KVIpsBlCKcAZQhnQFDAACAPyA/Q28SAzqUIkEgQSBBXBsiQUMAAIA/IEFDAACAP14bIXEgPkPNTE1DlCA/lSFlID5DMzOYQ5QgP5UhZiA+Q83MuEOUID+VIWcgPkPNrAJElCA/lSFoID5DAAAHRJQgP5UhaSA+QwAASESUID+VIWpDAAAAACFZID9DAAAAAJT8ASFyRAAAAAAAAAAAIVpDmpmZPyE+Qf8BIYUBQQYhdkMAAAA/IXVBAiFHQQEha0EAIUZDMzOTwENvEoM6IDcgNyA3XBsiQUNvEoM6IEFDbxKDOl4bID+UlRDZgICAACFwC0MAAAAAIV5DAAAAACFfQwAAAAAhYEMAAAAAIWFBACFiQwAAAAAhY0EAIWRDAAAAACFsQwAAAAAhbUMAAAAAIW5DAAAAACE7QQAhQEEAIW9BASEJQQEhc0MAAAAAIXQLQQAhEUMAAAAAITlDAAAAACF3QwAAAAAheEEAIXlBACF6QwAAAAAhe0MAAAAAIXxDAAAAACF9QgAhDUMAAAAAIX5BACF/QQAhgAFDAAAAACGBAUMAAAAAIYIBQwAAAAAhgwFDAAAAACGEAUEAITYMJQsgG0EAOgAQIBtCADcACCAbQgA3AAAgGkIANwAAIBpCADcACCAaQQA6ABAgGUIANwAAIBlCADcACCAZQQA6ABAgAkIANwP4BSACQgA3A4AGIAJCADcDiAYgAiACKQDAAzcDuAUgAiACKQDIAzcDwAUgAiACKQDQAzcDyAUgAiACKQDYAzcD0AUgAiACKQDgAzcD2AUgAiACKQDoAzcD4AUgAiACKQDwAzcD6AUgAiACKQD3AzcA7wUgP0NI4fo+lCJBQwAAIEFgRQ0XQgAhCyBBQwAAekUgQUMAAHpFXRtD2w9JQJQgP5UQ44CAgAAhQSACQgA3A+AHIAJCADcD2AcgAkIANwPQB0MAAIA/ITtDAACAPyA/Q28SAzqUIkIgQiBCXBsiQkMAAIA/IEJDAACAP14bIY4BQwAAgD8gP0Omm8Q6lCJCIEIgQlwbIkJDAACAPyBCQwAAgD9eGyFuQ6uqqj8hbCBBIEFDAACAPyBBIEFDq6qqP5KUQwAAgD+SlSJZlCJelCFfIDlDMzMzP5QhjwEgNyA+lCA/lSGDAUMAAAAAIWAgP0MAAAAAlPwBIUBDAABAwCA/QzEIrDyUlRDZgICAALwhZEQAAAAAAAAAACFaQ83MDEAhPkGAgICEBCE2Q5qZmT4hhAFDj8L1PCGBAUEBIWJB/wEhR0EAIUZDMzOTwCA/Q6abRDyUlRDZgICAACGNAUMAAIC/ID9DzcxMPZSVENmAgIAAIWNDMzOTwENvEoM6IDggOCA4XBsiQUNvEoM6IEFDbxKDOl4bID+UlRDZgICAACFtQwAAAAAhYUMAAAAAIU1DAAAAACFMQwAAAAAhS0MAAAAAIUpDAAAAACFJQwAAAAAhSEMAAAAAIWVDAAAAACFmQwAAAAAhZ0MAAAAAIWhDAAAAACFpQwAAAAAhakEAIWtBASFvQQAhCUMAAAAAIXBDAAAAACFxQwAAAAAhT0EAIXJB/wEhc0MAAAAAIXRDAAAAACF1QQAhdkEAIRFDAAAAACE5QwAAAAAhd0MAAAAAIXhBACF5QQAhekMAAAAAIXtDAAAAACF8QwAAAAAhfUIAIQ1DAAAAACF+QQAhf0EBIYABQwAAgD8hggEMHwsgG0EAOgAQIBtCADcACCAbQgA3AAAgGkIANwAAIBpCADcACCAaQQA6ABAgGUIANwAAIBlCADcACCAZQQA6ABAgAkIANwP4BSACQgA3A4AGIAJCADcDiAYgAiACKQDAAzcDuAUgAiACKQDIAzcDwAUgAiACKQDQAzcDyAUgAiACKQDYAzcD0AUgAiACKQDgAzcD2AUgAiACKQDoAzcD4AUgAiACKQDwAzcD6AUgAiACKQD3AzcA7wUgP0NI4fo+lCJBQwAAIEFgRQ0XQgAhCyBBQwAAlkQgQUMAAJZEXRtD2w9JQJQgP5UQ44CAgAAhQiBBQwAAIEEgN0MAwNpFlEMAgDtFkiI3IDdDAAAgQV0bIjcgNyBBXhtD2w9JQJQgP5UQ44CAgAAhQSACQgA3A/AHIAJCADcD6AcgAkIANwPQByACQgA3A9gHIAJCADcD4AdDq6qqPyFsQwAAgD8hggEgQSBBQwAAgD8gQSBBQ6uqqj+SlEMAAIA/kpUingGUIp8BlCGgAUMAAIA/ID9DbxIDOpQiQSBBIEFcGyJBQwAAgD8gQUMAAIA/XhshjgFDAACAPyA/Q6abxDqUIkEgQSBBXBsiQUMAAIA/IEFDAACAP14bIW4gQiBCQwAAgD8gQiBCQ6uqqj+SlEMAAIA/kpUiWZQiXpQhXyA4QwAAQD+UIY8BIDkgPpQiPkMAADRDlCA/lSGDASA+QwAApUOUID+VIX1DAAAAACFgID9DAAAAAJT8ASFAQwrXozwhe0MAAEDAID9DCtejPJSVENmAgIAAvCJkrSENRAAAAAAAAAAAIVpDZmamPyE+QZiz5vADITZDmJkZPiF+Q5qZGT8hfEEBIWJB/wEhR0EAIWtDAAAAPyE7QQIhRkMzM5PAIDpDbxKDOpcgP5SVENmAgIAAIY0BQzMzk8AgOkPHcRw/lENvEoM6lyA/lJUQ2YCAgAAhbUMAAAAAIWFDAAAAACFjQwAAAAAhTUMAAAAAIUxDAAAAACFLQwAAAAAhSkMAAAAAIUlDAAAAACFIQwAAAAAhZUMAAAAAIWZDAAAAACFnQwAAAAAhaEMAAAAAIWlDAAAAACFqQQEhb0EAIQlDAAAAACFwQwAAAAAhcUMAAAAAIU9BACFyQf8BIXNDAAAAACF0QwAAAAAhdUEAIXZBACERQwAAAAAhOUMAAAAAIXdDAAAAACF4QQEheUEBIXpBASF/QQEhgAFDCtejPCGBAUMAAAAAIYQBQQAhhQEMHwsgP0NI4fo+lCI+QwAAIEFgRQ0XQgAhCyA+QwAAIEEgN0MAgIlElCJBIEFDAAAgQV0bIkEgQSA+XhtD2w9JQJQgP5UQ44CAgAAhPiACQgA3A+AHIAJCADcD2AcgAkIANwPQB0MAACA/IWwgPiA+QwAAgD8gPiA+QwAAID+SlEMAAIA/kpUiWZQiXpQhX0MAAIA/ID9DbxIDOpQiPiA+ID5cGyI+QwAAgD8gPkMAAIA/XhshiQEgP0MCKwc9lPwBIYoBID9DWDm0PJT8ASGLASA/Q1g5NDyU/AEhjAFDAAAAACFjID9DAAAAAJT8ASGQAUQAAAAAAAAAACFaQ5qZmT8hPkH/ASFHQQAhZEEEIWJBASFGQ6uqKj8hYUMAAMA/IWBDMzOTwCA/Q7x0kzyUlRDZgICAACFCQzMzk8BDbxKDOiA4IDggOFwbIkFDbxKDOiBBQ28SgzpeGyA/lJUQ2YCAgAAhiAFDAAAAACFNQwAAAAAhTEMAAAAAIUtDAAAAACFKQwAAAAAhSUMAAAAAIUhDAAAAACFlQwAAAAAhZkMAAAAAIWdDAAAAACFoQwAAAAAhaUMAAAAAIWpBACFrQwAAAAAhbUMAAAAAIW5DAAAAACE7QQAhQEEAIW9BACEJQwAAAAAhcEMAAAAAIXFDAAAAACFPQQAhckH/ASFzQwAAAAAhdEMAAAAAIXVBACF2QQAhEUMAAAAAITlDAAAAACF3QwAAAAAheEEAIXlBACF6QwAAAAAhe0MAAAAAIXxDAAAAACF9QgAhDUMAAAAAIX5BACF/QQAhgAFDAAAAACGBAUMAAAAAIYIBQwAAAAAhgwFDAAAAACGEAUEAITZB/wEhhQFDAAAAACGGAUMAAAAAIYcBQQEhB0EBIQxDAADAPyFBIEIhjQFDAACAPyA/Qxe30TmUIjggOCA4XBsiOEMAAIA/IDhDAACAP14bIjchjgFDAADAPyGPAQwjC0MAAEA/IU8LICdBADoAECAnQgA3AAggJ0IANwAAICZCADcAACAmQgA3AAggJkEAOgAQICVCADcAACAlQgA3AAggJUEAOgAQIAJCADcD0AYgAkIANwPYBiACQgA3A+AGIAIgAikAcDcDkAYgAiACKQB4NwOYBiACIAIpAIABNwOgBiACIAIpAIgBNwOoBiACIAIpAJABNwOwBiACIAIpAJgBNwO4BiACIAIpAKABNwPABiACIAIpAKcBNwDHBiA/Q0jh+j6UIkFDAAAgQWBFDRZCACELIEFDAAAgQSA4QwBg6kWUIkIgQkMAACBBXRsiQiBCIEFeG0PbD0lAlCA/lRDjgICAACFBIAJCADcD8AYgAkIANwPoBiBBIEFDAACAPyBBIEFDq6qqP5KUQwAAgD+SlSKbAZQinAGUIZ0BQwAAgD8gP0NvEgM6lCJBIEEgQVwbIkFDAACAPyBBQwAAgD9eGyFxID5DmvmZQ5QgP5UhZSA+Q8xM5EOUID+VIWYgPkOamQpElCA/lSFnID5DNANERJQgP5UhaCA+QwCASkSUID+VIWkgPkMAAJZElCA/lSFqQwAAAAAhWSA/QwAAAACU/AEhckQAAAAAAAAAACFaQ5qZmT8hPkEGIXZDAAAAPyF1QzMzsz4hdEH/ASFzQQIhR0EBIWtBACFGQzMzk8BDbxKDOiA3IDcgN1wbIkFDbxKDOiBBQ28SgzpeGyA/lJUQ2YCAgAAhcEMAAAAAIV5DAAAAACFfQwAAAAAhYEMAAAAAIWFBACFiQwAAAAAhY0EAIWRDAAAAACFsQwAAAAAhbUMAAAAAIW5DAAAAACE7QQAhQEEAIW9BASEJDB0LQQAhRiAbQQA6ABAgG0IANwAIIBtCADcAACAaQgA3AAAgGkIANwAIIBpBADoAECAZQgA3AAAgGUIANwAIIBlBADoAECACQgA3A/gFIAJCADcDgAYgAkIANwOIBiACIAIpAMADNwO4BSACIAIpAMgDNwPABSACIAIpANADNwPIBSACIAIpANgDNwPQBSACIAIpAOADNwPYBSACIAIpAOgDNwPgBSACIAIpAPADNwPoBSACIAIpAPcDNwDvBUMAAIA/IYIBQwAAgD8gP0Omm8Q6lCJBIEEgQVwbIkFDAACAPyBBQwAAgD9eGyFuIDlDmpmZPpQhOyA+QwCgxESUID+VIXcgPkMAYIVElCA/lSF4ID5DAMAbRJQgP5UhfSA+QwAA3EOUID+VIYMBQwAAAAAhWSA/QwAAAACU/AEhQEMAAEDAID9DbxKDOpSVENmAgIAAIUFEAAAAAAAAAAAhWkPNzIw/IT5BASFvQf8BIUdDMzOTwENvEoM6IDggOCA4XBsiQkNvEoM6IEJDbxKDOl4bID+UlRDZgICAACFtQwAAAAAhXkMAAAAAIV9DAAAAACFgQwAAAAAhYUEAIWJDAAAAACFjQwAAAAAhTUMAAAAAIUxDAAAAACFLQwAAAAAhSkMAAAAAIUlDAAAAACFIQwAAAAAhZUMAAAAAIWZDAAAAACFnQwAAAAAhaEMAAAAAIWlDAAAAACFqQQAha0MAAAAAIWxBACEJQwAAAAAhcEMAAAAAIXFDAAAAACFPQQAhckH/ASFzQwAAAAAhdEMAAAAAIXVBACF2QQEhEUEAIXlBASF6QwAAAAAheyA6QzMzMz+UQ5qZGT6SIjkhfCBBvCJkrSILIQ1DAAAAACF+QQEhf0EBIYABQwAAAAAhgQEMHQtBACFGIBtBADoAEEIAIQsgG0IANwAIIBtCADcAACAaQgA3AAAgGkIANwAIIBpBADoAECAZQgA3AAAgGUIANwAIIBlBADoAECACQgA3A/gFIAJCADcDgAYgAkIANwOIBiACIAIpAMADNwO4BSACIAIpAMgDNwPABSACIAIpANADNwPIBSACIAIpANgDNwPQBSACIAIpAOADNwPYBSACIAIpAOgDNwPgBSACIAIpAPADNwPoBSACIAIpAPcDNwDvBUMAAIA/IYIBQwAAgD8gP0Omm8Q6lCJBIEEgQVwbIkFDAACAPyBBQwAAgD9eGyFuIDlDzcxMP5QhOyA6QwAAAD+UIXwgPkMAAERDlCI+ID+VIYMBID5DAICbQ5RDAABEQ5UgP5UhfUMAAAAAIVkgP0MAAAAAlPwBIUBDAABAwCA/QylcDz2UlRDZgICAALwiZK0hDUQAAAAAAAAAACFaQ5qZmT8hPkHMmbP2AyE2QwrXIz0hgQFDzMzMPiF+QQEhb0H/ASFHQzMzk8BDbxKDOiA4IDggOFwbIkFDbxKDOiBBQ28SgzpeGyA/lJUQ2YCAgAAhbQwBC0EAIUYgG0EAOgAQQgAhCyAbQgA3AAggG0IANwAAIBpCADcAACAaQgA3AAggGkEAOgAQIBlCADcAACAZQgA3AAggGUEAOgAQIAJCADcD+AUgAkIANwOABiACQgA3A4gGIAIgAikAwAM3A7gFIAIgAikAyAM3A8AFIAIgAikA0AM3A8gFIAIgAikA2AM3A9AFIAIgAikA4AM3A9gFIAIgAikA6AM3A+AFIAIgAikA8AM3A+gFIAIgAikA9wM3AO8FQwAAgD8hggFDAACAPyA/Q6abxDqUIkEgQSBBXBsiQUMAAIA/IEFDAACAP14bIW4gOUMzM3M/lCE7IDpDAAAAP5QhfCA+QwAAxEKUIj4gP5UhgwEgPkMAAMA/lCA/lSF9QwAAAAAhWSA/QwAAAACU/AEhQEMAAEDAID9DKVwPPZSVENmAgIAAvCJkrSENRAAAAAAAAAAAIVpDZmamPyE+QZqz5vwDITZDzcxMPSGBAUPMzMw+IX5BASFvQf8BIUdDMzOTwENvEoM6IDggOCA4XBsiQUNvEoM6IEFDbxKDOl4bID+UlRDZgICAACFtC0MAAAAAIV5DAAAAACFfQwAAAAAhYEMAAAAAIWFBACFiQwAAAAAhY0MAAAAAIU1DAAAAACFMQwAAAAAhS0MAAAAAIUpDAAAAACFJQwAAAAAhSEMAAAAAIWVDAAAAACFmQwAAAAAhZ0MAAAAAIWhDAAAAACFpQwAAAAAhakEAIWtDAAAAACFsQQAhCUMAAAAAIXBDAAAAACFxQwAAAAAhT0EAIXJB/wEhc0MAAAAAIXRDAAAAACF1QQAhdkEAIRFDAAAAACE5QwAAAAAhd0MAAAAAIXhBACF5QQEhekMAAAAAIXtBACF/QQEhgAFDAAAAACGEAQwbCyAbQQA6ABAgG0IANwAIIBtCADcAACAaQgA3AAAgGkIANwAIIBpBADoAECAZQgA3AAAgGUIANwAIIBlBADoAECACQgA3A/gFIAJCADcDgAYgAkIANwOIBiACIAIpAMADNwO4BSACIAIpAMgDNwPABSACIAIpANADNwPIBSACIAIpANgDNwPQBSACIAIpAOADNwPYBSACIAIpAOgDNwPgBSACIAIpAPADNwPoBSACIAIpAPcDNwDvBSA/Q0jh+j6UIkFDAAAgQWBFDRJCACELIEFDAAB6RSBBQwAAekVdG0PbD0lAlCA/lRDjgICAACFBIAJCADcD4AcgAkIANwPYByACQgA3A9AHQwAAgD8hggFDAACAPyA/Qxe3UTmUIkIgQiBCXBsiQkMAAIA/IEJDAACAP14bIY4BQwAAgD8gP0Omm8Q6lCJCIEIgQlwbIkJDAACAPyBCQwAAgD9eGyFuQ6uqqj8hbCBBIEFDAACAPyBBIEFDq6qqP5KUQwAAgD+SlSJZlCJelCFfIDlDzczMPZQhjwEgOkOamRk/lCF8IDlDmpkZP5QhOyA+QwBAtUSUID+VIYMBID5DALB0RZQgP5UhfUMAAAAAIWAgP0MAAAAAlPwBIUBDAABAwCA/QwrXozuUlRDZgICAALwhZEMAAEDAID9DbxKDOpSVENmAgIAAvK0hDUQAAAAAAAAAACFaQzMzsz8hPkHAmbPqAyE2QQEhYkH/ASFHQQAha0ECIUZDMzOTwCA/Q28SgzuUlRDZgICAACGNAUMzM5PAQ28SgzogOCA4IDhcGyJBQ28SgzogQUNvEoM6XhsgP5SVENmAgIAAIW1DAAAAACFhQwAAAAAhY0MAAAAAIU1DAAAAACFMQwAAAAAhS0MAAAAAIUpDAAAAACFJQwAAAAAhSEMAAAAAIWVDAAAAACFmQwAAAAAhZ0MAAAAAIWhDAAAAACFpQwAAAAAhakEBIW9BACEJQwAAAAAhcEMAAAAAIXFDAAAAACFPQQAhckH/ASFzQwAAAAAhdEMAAAAAIXVBACF2QQAhEUMAAAAAITlDAAAAACF3QwAAAAAheEEAIXlBASF6QwAAAAAhe0MAAAAAIX5BACF/QQEhgAFDAAAAACGBAQwVCyA/Q0jh+j6UIkFDAAAgQWBFDRJCACELIEFDAAAgQUMAoIxGIDpDAAAAP5IgPkMAIMtFlJQiPiA+ID5cGyI+QwCgjEYgPkMAoIxGXRsiPiA+QwAAIEFdGyI+ID4gQV4bQ9sPSUCUID+VEOOAgIAAIT4gQUMAgDtFIEFDAIA7RV0bQ9sPSUCUID+VEOOAgIAAIUEgAkIANwPwByACQgA3A+gHIAJCADcD0AcgAkIANwPYByACQgA3A+AHQ1VVVT8hbCA+ID5DAACAPyA+ID5DVVVVP5KUQwAAgD+SlSJZlCJelCFfQwAAgD8gP0NvEoM7lCI+ID4gPlwbIj5DAACAPyA+QwAAgD9eGyGOASBBIEFDAACAPyBBIEFDq6qqP5KUQwAAgD+SlSKeAZQinwGUIaABIDlDZmZmP5QhjwFDAAAAACFgID9DAAAAAJT8ASGQAUQAAAAAAAAAACFaQ5qZmT8hPkECIYUBQf8BIUdBACFkQQEhRkMzM5PAQ28SgzogOCA4IDhcGyJBQ28SgzogQUNvEoM6XhsgP5SVENmAgIAAIY0BQwAAAAAhYUEBIWJDAAAAACFjQwAAAAAhTUMAAAAAIUxDAAAAACFLQwAAAAAhSkMAAAAAIUlDAAAAACFIQwAAAAAhZUMAAAAAIWZDAAAAACFnQwAAAAAhaEMAAAAAIWlDAAAAACFqQQAha0MAAAAAIW1DAAAAACFuQwAAAAAhO0EAIUBBACFvQQAhCUMAAAAAIXBDAAAAACFxQwAAAAAhT0EAIXJB/wEhc0MAAAAAIXRDAAAAACF1QQAhdkEAIRFDAAAAACE5QwAAAAAhd0MAAAAAIXhBACF5QQAhekMAAAAAIXtDAAAAACF8QwAAAAAhfUIAIQ1DAAAAACF+QQAhf0EAIYABQwAAAAAhgQFDAAAAACGCAUMAAAAAIYMBQwAAAAAhhAFBACE2QwAAAAAhhgFDAAAAACGHAUEBIQcMAQsgP0NI4fo+lCJBQwAAIEFgRQ0SQgAhCyBBQwAAIEFDAAB6RiA6QwCAu0WUQwCAu0SSID6UIj4gPiA+XBsiPkMAAHpGID5DAAB6Rl0bIj4gPkMAACBBXRsiPiA+IEFeG0PbD0lAlCA/lRDjgICAACE+IAJCADcD4AcgAkIANwPYByACQgA3A9AHQ6uqqj8hbCA+ID5DAACAPyA+ID5Dq6qqP5KUQwAAgD+SlSJZlCJelCFfQwAAgD8gP0NvEgM8lCI+ID4gPlwbIj5DAACAPyA+QwAAgD9eGyGOASA5Q2ZmJj+UIY8BQwAAAAAhOSA/QwAAAACU/AEhkAFEAAAAAAAAAAAhWkOamZk/IT5BASEHQf8BIUdBACFAQQIhRkMzM5PAQ28SgzogOCA4IDhcGyJBQ28SgzogQUNvEoM6XhsgP5SVENmAgIAAIY0BQwAAAAAhYEMAAAAAIWFBASFiQwAAAAAhY0EAIWRDAAAAACFNQwAAAAAhTEMAAAAAIUtDAAAAACFKQwAAAAAhSUMAAAAAIUhDAAAAACFlQwAAAAAhZkMAAAAAIWdDAAAAACFoQwAAAAAhaUMAAAAAIWpBACFrQwAAAAAhbUMAAAAAIW5DAAAAACE7QQAhb0EAIQlDAAAAACFwQwAAAAAhcUMAAAAAIU9BACFyQf8BIXNDAAAAACF0QwAAAAAhdUEAIXZBACERQwAAAAAhd0MAAAAAIXhBACF5QQAhekMAAAAAIXtDAAAAACF8QwAAAAAhfUIAIQ1DAAAAACF+QQAhf0EAIYABQwAAAAAhgQFDAAAAACGCAUMAAAAAIYMBQwAAAAAhhAFBACE2Qf8BIYUBQwAAAAAhhgFDAAAAACGHAQtBACEMQwAAAAAhiAFDAAAAACGJAUMAAAAAIUFBACGKAUMAAAAAIUJDAAAAACE3QQAhiwFBACGMAQwZCyBHIEZBlIvAgAAQi4CAgAAACyACQYCAgI0ENgL4BiACIFA4AugHIAJBgYCAgACtQiCGIgsgAkHoB2qthDcDyAMgAiALIAJB+AZqrYQ3A8ADQc+BwIAAIAJBwANqQcSIwIAAEIKAgIAAAAsgAkGAgICJBDYC+AYgAiBBOALoByACQYGAgIAArUIghiILIAJB6AdqrYQ3A8gDIAIgCyACQfgGaq2ENwPAA0HPgcCAACACQcADakHEiMCAABCCgICAAAALIAJBgICAiQQ2AvgGIAIgQTgC6AcgAkGBgICAAK1CIIYiCyACQegHaq2ENwPIAyACIAsgAkH4BmqthDcDwANBz4HAgAAgAkHAA2pBxIjAgAAQgoCAgAAACyACQYCAgIkENgL4BiACIEE4AugHIAJBgYCAgACtQiCGIgsgAkHoB2qthDcDyAMgAiALIAJB+AZqrYQ3A8ADQc+BwIAAIAJBwANqQcSIwIAAEIKAgIAAAAsgAkGAgICJBDYC+AYgAiBBOALoByACQYGAgIAArUIghiILIAJB6AdqrYQ3A8gDIAIgCyACQfgGaq2ENwPAA0HPgcCAACACQcADakHEiMCAABCCgICAAAALIAJBgICAiQQ2AvgGIAIgPjgC6AcgAkGBgICAAK1CIIYiCyACQegHaq2ENwPIAyACIAsgAkH4BmqthDcDwANBz4HAgAAgAkHAA2pBxIjAgAAQgoCAgAAACyACQYCAgIkENgL4BiACIEE4AugHIAJBgYCAgACtQiCGIgsgAkHoB2qthDcDyAMgAiALIAJB+AZqrYQ3A8ADQc+BwIAAIAJBwANqQcSIwIAAEIKAgIAAAAsgAkGAgICJBDYC+AYgAiBBOALoByACQYGAgIAArUIghiILIAJB6AdqrYQ3A8gDIAIgCyACQfgGaq2ENwPAA0HPgcCAACACQcADakHEiMCAABCCgICAAAALIAJBgICAiQQ2AvgGIAIgQTgC6AcgAkGBgICAAK1CIIYiCyACQegHaq2ENwPIAyACIAsgAkH4BmqthDcDwANBz4HAgAAgAkHAA2pBxIjAgAAQgoCAgAAACyACQYCAgIkENgL4BiACIEE4AugHIAJBgYCAgACtQiCGIgsgAkHoB2qthDcDyAMgAiALIAJB+AZqrYQ3A8ADQc+BwIAAIAJBwANqQcSIwIAAEIKAgIAAAAsgAkGAgICJBDYC+AYgAiBBOALoByACQYGAgIAArUIghiILIAJB6AdqrYQ3A8gDIAIgCyACQfgGaq2ENwPAA0HPgcCAACACQcADakHEiMCAABCCgICAAAALIAJBgICAiQQ2AvgGIAIgQTgC6AcgAkGBgICAAK1CIIYiCyACQegHaq2ENwPIAyACIAsgAkH4BmqthDcDwANBz4HAgAAgAkHAA2pBxIjAgAAQgoCAgAAACyACQYCAgIkENgL4BiACID44AugHIAJBgYCAgACtQiCGIgsgAkHoB2qthDcDyAMgAiALIAJB+AZqrYQ3A8ADQc+BwIAAIAJBwANqQcSIwIAAEIKAgIAAAAsgAkGAgICJBDYC+AYgAiBBOALoByACQYGAgIAArUIghiILIAJB6AdqrYQ3A8gDIAIgCyACQfgGaq2ENwPAA0HPgcCAACACQcADakHEiMCAABCCgICAAAALIAJBgICAiQQ2AvgGIAIgQTgC6AcgAkGBgICAAK1CIIYiCyACQegHaq2ENwPIAyACIAsgAkH4BmqthDcDwANBz4HAgAAgAkHAA2pBxIjAgAAQgoCAgAAACyACQYCAgIkENgL4BiACIEE4AugHIAJBgYCAgACtQiCGIgsgAkHoB2qthDcDyAMgAiALIAJB+AZqrYQ3A8ADQc+BwIAAIAJBwANqQcSIwIAAEIKAgIAAAAsgAkGAgICJBDYC+AYgAiBBOALoByACQYGAgIAArUIghiILIAJB6AdqrYQ3A8gDIAIgCyACQfgGaq2ENwPAA0HPgcCAACACQcADakHEiMCAABCCgICAAAALQwAAAAAhhAELQf8BIYUBC0MAAAAAIYYBQwAAAAAhhwFBASEHQQAhDEMAAAAAIYgBQwAAAAAhiQFDAAAAACFBQQAhigFDAAAAACFCQwAAAAAhN0EAIYsBQQAhjAEgQCGQAQwEC0EAIRFDAAAAACE5QwAAAAAhd0MAAAAAIXhBACF5QQAhekMAAAAAIXtDAAAAACF8QwAAAAAhfUIAIQ1DAAAAACF+QQAhf0EAIYABQwAAAAAhgQFDAAAAACGCAUMAAAAAIYMBC0MAAAAAIYQBQQAhNgtB/wEhhQELQwAAAAAhhgFDAAAAACGHAUEAIQdBACEMQwAAAAAhiAFDAAAAACGJAUMAAAAAIUFBACGKAUMAAAAAIUJDAAAAACE3QQAhiwFBACGMAUMAAAAAIY0BQwAAAAAhjgFDAAAAACGPAUEAIZABC0MAAAAAIZEBQwAAAAAhkgFBACGTAUMAAAAAIZQBC0EAIQhDAAAAACFdQwAAAAAhVkMAAAAAITpBACFcQf8BIZUBQQAhlgFEAAAAAAAAAAAhWwsgAC0AuCMhoQFDAACAP0MAAIC/IDwgPEMAAIC/XRsiOCA4QwAAgD9eG0MAAIA/kkPbD0lAlEMAAIA+lCI4EOCAgIAAITwgOBDcgICAACGiAUMAAIA/ITgCQCA+QwAAAABeRQ0AQwAAgD9DAACAP0MAAIC/ID4gPiA+lCI4IDggOEMAAL1DkpRDAFqHRpKUQ8D3A0iSlCA4IDggOEMAAOBBlEMA4ERFkpRDAKJzR5KUQ8D3A0iSlSI4IDhDAACAv10bIjggOEMAAIA/XhuVITgLIAQgACgCCCIKTw0CIAAoAgQgQ2ogREGoCWxqIgogUDgCJCAKIFE4AiAgCiBaOQMYIAogWzkDECAKQgA3AwggCiA8QwAAgD9D8wS1PyChAUECSxsiowGUOAIEIAogogEgowGUOAIAIAogAikDwAM3AyggCiACKQPIAzcDMCAKIAg2AmwgCiCWATYCaCAKIJUBOgBkIApB/rTW/AM2AmAgCkLotLv9k+XZnT83A1ggCiBYOAJUIApCzZmz8tOZs8Y/NwJMIAogUjgCSCAKIFc4AkQgCiBVOAJAIAogVDgCPCAKIFM4AjggCiBcNgKIASAKIDo4AowBIAogVjgCkAEgCiBdOAKUASAKQQA6AJgBIAogAikD2Ag3A4ABIAogAikD0Ag3A3ggCiACKQPICDcDcCAKIAIpA4gINwCZASAKIAIpA5AINwChASAKIAIpA5gINwCpASAKIAIpA6AINwCxASAKIAIpA6gINwC5ASAKIAIpA7AINwDBASAKIAIpA7gINwDJASAKIAIpAL8INwDQASAKIIYBOAKYAiAKIIcBOAKUAiAKIJEBOAKQAiAKIJIBOAKMAiAKID84AogCIAogRUEBckG178nkAmw2AoQCIApCgICA/IOAgMA/NwL8ASAKQwAAgEBDAAAAACA9ID1DAAAAAF0bIj8gP0MAAIBAXhsgTpQ4AvgBIAogODgC9AEgCiA+OALwASAKIJMBNgLsASAKIJQBOALoASAKIDs4AuQBIApBADYC4AEgCiAIOgDcASAKQQA7AdgBIAogAikD+Ac3ApwCIAogAikDgAg3AqQCIAogoAE4ArwCIAognwE4ArgCIAogngE4ArQCIApBq9Wq/QM2ArACIApBADoArAIgCiACKQPwBzcDyAIgCiACKQPoBzcDwAIgCiBiNgL4AiAKIEY6APQCIApCADcC7AIgCiBhOALoAiAKIGA4AuQCIAogXzgC4AIgCiBeOALcAiAKIFk4AtgCIAogbDgC1AIgCiCFAToA0AIgCiACKQPgBzcCjAMgCiACKQPYBzcChAMgCiACKQPQBzcC/AIgCkH/AToAjAQgCiAHOgDoAyAKQQA7AeQDIAogDDoA4AMgCiCIATgC3AMgCiCJATgC2AMgCiBBOALUAyAKIIoBNgLQAyAKIAw6AMwDIAogQjgCyAMgCiA3OALEAyAKIEE4AsADIAogiwE2ArwDIAogDDoAuAMgCiBCOAK0AyAKIDc4ArADIAogQTgCrAMgCiCMATYCqAMgCiAHOgCkAyAKII0BOAKgAyAKII4BOAKcAyAKII8BOAKYAyAKIJABNgKUAyAKIAIoAMwHNgCtBCAKIAIpAMQHNwClBCAKIAIpALwHNwCdBCAKIAIpALQHNwCVBCAKIAIpAKwHNwCNBCAKIAIpAI0HNwCxBCAKIAIpAJUHNwC5BCAKIAIpAJ0HNwDBBCAKIAIpAKQHNwDIBCAKQdAEaiACQYACakHQAPwKAAAgCiCaATgCgAcgCiCZATgC/AYgCiCYATgC+AYgCiCXATgC9AYgCiB0OALwBiAKIHU4AuwGIAogdjYC6AYgCiBqOALkBiAKIGk4AuAGIAogaDgC3AYgCiBnOALYBiAKIGY4AtQGIAogZTgC0AYgCiBIOALMBiAKIEk4AsgGIAogSjgCxAYgCiBLOALABiAKIEw4ArwGIAogTTgCuAYgCkEAOgC1BiAKIBE6ALQGIApBADYCsAYgCiA5OAKsBiAKIHc4AqgGIApBADYCpAYgCiALNwKcBiAKQgA3ApQGIApBADoAkQYgCiAROgCQBiAKQQA2AowGIAogOTgCiAYgCiB4OAKEBiAKQQA2AoAGIAogCzcD+AUgCkIANwPwBSAKIHk6AO0FIAogejoA7AUgCiB7OALoBSAKIHw4AuQFIAogfTgC4AUgCkEANgLcBSAKIA03AtQFIApBADYC0AUgCiB+OALMBSAKIH86AMkFIAoggAE6AMgFIAoggQE4AsQFIAogggE4AsAFIAoggwE4ArwFIApBADYCuAUgCiBjOAK0BSAKIGQ2ArAFIAoghAE4AqwFIAogNjYCqAUgCkEAOgCkBSAKQQA7AaAFIAogmwE4ApwHIAognAE4AqAHIAognQE4AqQHIApBq9Wq/QM2ApgHIAogczoAlAcgCiBrNgK8ByAKIEc6ALgHIAogAikDgAc3AowHIAogAikD+AY3AoQHIAogAikD6AY3A6gHIAogAikD8AY3A7AHIAogAikD0AY3A8AHIAogAikD2AY3A8gHIAogAikD4AY3A9AHIAogCToA6AcgCiBwOALkByAKIHE4AuAHIAogTzgC3AcgCiByNgLYByAKIAIpA5AGNwDpByAKIAIpA5gGNwDxByAKIAIpA6AGNwD5ByAKIAIpA6gGNwCBCCAKIAIpA7AGNwCJCCAKIAIpA7gGNwCRCCAKIAIpA8AGNwCZCCAKIAIpAMcGNwCgCCAKIG82ArAIIAogCToArAggCkEAOwGoCCAKIAIpA4gGNwLECCAKIAIpA4AGNwK8CCAKIAIpA/gFNwK0CCAKQQA6ANwIIAogbTgC2AggCiBuOALUCCAKIDs4AtAIIAogQDYCzAggCiACKQDvBTcAlAkgCiACKQPoBTcAjQkgCiACKQPgBTcAhQkgCiACKQPYBTcA/QggCiACKQPQBTcA9QggCiACKQPIBTcA7QggCiACKQPABTcA5QggCiACKQO4BTcA3QggCkEBOgCgCSAKQQA7AZwJCyA0QQFqIjQgA0cNAAsgAyE0IBIhNgwBCyAEIApBhIrAgAAQi4CAgAAACwJAAkACQAJAIDZBAXQiCiAzQQF0IgxJDQAgCiAMayKAAUECdCF5IDNBA3QhcgJAIAogDEYibw0AIAAgcmohCgJAIHlFIgwNACAKQbALakEAIHn8CwALIAwNACAKQbATakEAIHn8CwALIBMgeWoheiAAKAIEImQgACgCCEHQEmxqIXNBACF/QQANAgwBCyAMIApBgAJBlIrAgAAQjICAgAAAC0EBIQoMAQtBACEKCwJAA0ACQAJAAkACQAJAAkAgCg4CAAEBCyB/IGRGDQQgf0GgCWohCiB/QagJaiIMIX8gCi0AAA0BDAMLIGQhQwJAA0AgQyBzRg0HIENB0BJqIWQgQ0GgCWotAAANASBDQcgSaiEKIGQhQyAKLQAAQQFHDQALIGRBsG1qQagJaiFDIGQhfwwCCyBDQagJaiF/DAELIAxB2HZqIUMgDCF/CyAAKAIsIYUBIAAoAighkAECQCBvDQAgeUUNACATQQAgefwLAAsgQygC4AEhdgJAIEMtAMgFRQ0AIENBqAVqIUYgAiBDQbAIaiJHQfAA/AoAAAJAAkAgQy0A7AVBAUYNAEEkIQoMAQsCQCBDLQCQBkEBRg0AQcgAIQoMAQtBkAFB7AAgQy0AtAYbIQoLIEMqAuQBIT4gAkHwAGogRkGQAfwKAAACQCBvDQBDAACAPyA+lUMAAAAAID5DAAAAAF4bITkgAkHwAGogCmohCUEAIQggAi0AbCEHIAItAG0hQCACKAIUITMgAioCDCE8IAIqAgghOiACKgIYIT0gAioCECE3IAIoAgQhBCACKAIAIUUgEyERA0ACQAJAAkACQAJAAkACQAJAIAQgRU8NACAEQQRPDQEgCCB2aiAyIARBFGxqIgooAgBPDQILIAcgQHFBAXFFDQIgMyEKDAQLIARBBEGkisCAABCLgICAAAALIAIgCi0AECIMOgBtIAJBAToAbCAEQQFqIQQgCioCDCE9IAoqAgghPiAKKgIEITcgDA0BIDcgOpMgPpUhPEEAIUAMAwsgB0EBcQ0CQwAAAAAgOiA9lCI+ID6LQwjlPB5dGyE6QQAhBwwDC0MAAIA/QwAAgL8gPpUQ2YCAgACTITwgPkMAAKBAlPwBIQoLIAogCkEAR2shMyA6IDcgOpMgPJSSITpBASFAAkAgCkECSQ0AQQEhBwwCC0EAIQcgAkEAOgBsDAELIDogPJIhOgJAAkAgPEMAAAAAYEUNACA6IDdgDQELQQEhByA8QwAAAABdRQ0BIDogN19FDQELQQAhByACQQA6AGwgNyE6CyA5IDqUITggAkHwAGohCkMAAAAAIT8DQCAKQwAAAAAgCioCACI+IApBCGoqAgCUIkEgQYtDCOU8Hl0bOAIAIApBBGoiDEMAAAAAIAwqAgAiQSAKQQxqKgIAlCJCIEKLQwjlPB5dGzgCACAKQRBqIgwgDCoCAENmZuY+IEEgPkMAAIA/kpIgOCAKQRxqKgIAlEMAAIA/kpQgCkEUaioCAJQiPiA+ID5cGyI+Q2Zm5j4gPkNmZuY+XRuSIj5DAACAv5IgPiA+QwAAgD9gGyI+OAIAIApBGGoqAgAhQQJAAkAgCkEhai0AAA0AAkACQCA+Q9sPyUCUIj5D2w/JwJIgPiA+Q9sPSUBeGyI+Q9sPyT9eDQAgPkPbD8m/XUUNAUPbD0nAID6TIT4MAQtD2w9JQCA+kyE+CyA+QwAAgD8gPiA+lCJCQ6uqKj4gQiBCQwCAncWVQ4mICDySlJOUk5QhPgwBCyA+QwAAAL+Si0MAAIDAlEMAAIA/kiE+CyA/IEEgPpSSIT8gCkEkaiIKIAlHDQALIBEgOiA/lCARKgIAkjgCACAIQQFqIQggEUEEaiIRIHpHDQALIAIgPTgCGCACIDc4AhAgAiAzNgIUIAIgPDgCDCACIDo4AgggAiAENgIECyBHIAJB8AD8CgAAIEYgAkHwAGpBkAH8CgAACyBDQbACaiFrIEMoAoQCIQxBACEKQQEhRANAAkAgayAKQbwBbGoiYi0AuAFFDQAgAkGAAmogYkG8AfwKAAACQCBvDQAgAi0AtAMhBCACLQC1AyFFIAIoAtwCIUcgAioC1AIhSCACKgLQAiE/IAIqAuACIWUgAioC2AIhSiACKALMAiEJIAIqApgCITkgAioCnAIhPSACKgK8AiFBIAIqAsACIUIgAigCyAIhMyACKgKAAiFmIAIqAowCIWAgAioClAIhZyACKgKQAiFOIAIqAogCIUsgAioChAIhYSACLQCgAiFAIAIqAqQCIV8gAi0AxAIhRiACKgKwAiFNIAIqArgCIWMgAioCtAIhSSACKgKsAiE7IAIqAqgCIU8gdiERIHkhByATIQgDQCAIIQogTyBBlCA7IAxBDXQgDHMiDEERdiAMcyIMQQV0IAxzIgyzQwAAgC+UIj4gPpJDAACAv5IiOiBCkyI4lJIhPgJAIElDAAAAAF5FDQAgY0MAAIA/QwAAgL9DAACgQEMAAKDAIEkgPpQiPiA+QwAAoMBdGyI+ID5DAACgQF4bIj4gPiA+lCI+ID4gPkMAAL1DkpRDAFqHRpKUQ8D3A0iSlCA+ID4gPkMAAOBBlEMA4ERFkpRDAKJzR5KUQ8D3A0iSlSI+ID5DAACAv10bIj4gPkMAAIA/XhuUIT4LIEIgOyBBlJIgTSA4lJIiOCE3AkACQAJAIEYOAwIAAQILIF8gPpQhNwwBCyA6IF8gPpSTIDiTITcLAkACQCBAQf8BRw0AIDchOgwBCyBhIDmUIEsgNyA9kyJMlJIhPAJAIE5DAAAAAF5FDQAgZ0MAAIA/QwAAgL9DAACgQEMAAKDAIE4gPJQiOiA6QwAAoMBdGyI6IDpDAACgQF4bIjogOiA6lCI6IDogOkMAAL1DkpRDAFqHRpKUQ8D3A0iSlCA6IDogOkMAAOBBlEMA4ERFkpRDAKJzR5KUQ8D3A0iSlSI6IDpDAACAv10bIjogOkMAAIA/XhuUITwLQwAAAAAgPSBLIDmUkiBgIEyUkiI6IDqSID2TIj0gPYtDCOU8Hl0bIT1DAAAAACA8IDySIDmTIjkgOYtDCOU8Hl0bITkCQAJAIEAOAwIAAQILIGYgPJQhOgwBCyA3IGYgPJSTIDqTIToLAkACQAJAAkACQAJAAkACQCAJIDNPDQAgCUEETw0BIBEgMSAJQRRsaiIIKAIATw0CCyAEIEVxQQFxRQ0CIEchBAwECyAJQQRBpIrAgAAQi4CAgAAACyACIAgtABAiBDoAtQMgAkEBOgC0AyAJQQFqIQkgCCoCDCFlIAgqAgghPCAIKgIEIUogBA0BIEogP5MgPJUhSEEAIUUMAwsgBEEBcQ0CQwAAAAAgPyBllCI/ID+LQwjlPB5dGyE/QQAhBAwDC0MAAIA/QwAAgL8gPJUQ2YCAgACTIUggPEMAAKBAlPwBIQQLIAQgBEEAR2shRyA/IEogP5MgSJSSIT9BASFFAkAgBEECSQ0AQQEhBAwCC0EAIQQgAkEAOgC0AwwBCyA/IEiSIT8CQAJAIEhDAAAAAGBFDQAgPyBKYA0BC0EBIQQgSEMAAAAAXUUNASA/IEpfRQ0BC0EAIQQgAkEAOgC0AyBKIT8LIApBBGohCEMAAAAAIDggOJIgQpMiQiBCi0MI5TweXRshQkMAAAAAID4gPpIgQZMiPiA+i0MI5TweXRshQSAKIAoqAgAgOiA/lJI4AgAgEUEBaiERIAdBfGoiBw0ACyACIEE4ArwCIAIgQjgCwAIgAiA9OAKcAiACIGU4AuACIAIgSjgC2AIgAiAJNgLMAiACIDk4ApgCIAIgRzYC3AIgAiBIOALUAiACID84AtACCyBiIAJBgAJqQbwB/AoAAAtBASEKIERBAXEhCUEAIUQgCQ0ACwJAIEMtAKwIRQ0AIAJBwANqIENBuAZqImJB+AH8CgAAAkAgbw0AQwAAgD8gAioC7AMigQGTIY8BQwAAgD8gAioC6AMie5MhgwFDAACAPyACKgLkAyJxkyGCAUMAAIA/IAIqAuADImWTIX1DAACAPyACKgLcAyJLkyF0QwAAgD8gAioC2AMiOJMhZiACLQCwBSEIIAItALEFIUYgAigC2AQhRCACKgLQBCFJIAIqAswEIT4gAioC3AQhbSACKgLUBCFKIAIoAsgEIQkgAigCxAQhRyACKgKgBCFuIAIqAqwEIWcgAioCtAQhdSACKgKwBCFhIAIqAqgEIUwgAioCpAQhaCACLQDABCFFIAIqAvgDIV8gAioC/AMhcCACKgKIBCFpIAIqApAEIXcgAioCjAQhYyACKgKEBCFNIAIqAoAEIWogAi0AnAQhMyACKgL0AyFgIAIqArgEITogAioCvAQhPCACKgKUBCE3IAIqApgEITkgAioC1AMhfiACKgLQAyF4IAIqAswDIWwgAioCyAMhTiACKgLEAyE7IAIqAsADIT8gAigC8AMiBEEGRiFrIHkhQCB2IREgEyEHA0AgByEKAkACQCAEDQBDAAAAACFBDAELID9DAAAAP0MAAAC/ID9DAAAAP10iBxuSIUECQAJAID8gOF0NAEMAAAAAIUIgPyBmXkUNASA/QwAAgL+SIDiVIkIgQiBCIEKUkpJDAACAP5IhQgwBCyA/IDiVIkIgQpIgQiBClJNDAACAv5IhQgsCQAJAIEEgOF0NAEMAAAAAIT0gQSBmXkUNASBBQwAAgL+SIDiVIkEgQSBBIEGUkpJDAACAP5IhPQwBCyBBIDiVIkEgQZIgQSBBlJNDAACAv5IhPQsgOCA/kiI/QwAAgL+SID8gP0MAAIA/YBshP0MAAIA/QwAAgL8gBxsgQpIgPZMhQSAEQQFGDQAgO0MAAAA/QwAAAL8gO0MAAAA/XSIHG5IhQgJAAkAgOyBLXQ0AQwAAAAAhPSA7IHReRQ0BIDtDAACAv5IgS5UiPSA9ID0gPZSSkkMAAIA/kiE9DAELIDsgS5UiPSA9kiA9ID2Uk0MAAIC/kiE9CwJAAkAgQiBLXQ0AQwAAAAAhSCBCIHReRQ0BIEJDAACAv5IgS5UiQiBCIEIgQpSSkkMAAIA/kiFIDAELIEIgS5UiQiBCkiBCIEKUk0MAAIC/kiFICyBLIDuSIkJDAACAv5IgQiBCQwAAgD9gGyE7IEFDAACAP0MAAIC/IAcbID2SIEiTkiFBIARBAkYNACBOQwAAAD9DAAAAvyBOQwAAAD9dIgcbkiFCAkACQCBOIGVdDQBDAAAAACE9IE4gfV5FDQEgTkMAAIC/kiBllSI9ID0gPSA9lJKSQwAAgD+SIT0MAQsgTiBllSI9ID2SID0gPZSTQwAAgL+SIT0LAkACQCBCIGVdDQBDAAAAACFIIEIgfV5FDQEgQkMAAIC/kiBllSJCIEIgQiBClJKSQwAAgD+SIUgMAQsgQiBllSJCIEKSIEIgQpSTQwAAgL+SIUgLIGUgTpIiQkMAAIC/kiBCIEJDAACAP2AbIU4gQUMAAIA/QwAAgL8gBxsgPZIgSJOSIUEgBEEDRg0AIGxDAAAAP0MAAAC/IGxDAAAAP10iBxuSIUICQAJAIGwgcV0NAEMAAAAAIT0gbCCCAV5FDQEgbEMAAIC/kiBxlSI9ID0gPSA9lJKSQwAAgD+SIT0MAQsgbCBxlSI9ID2SID0gPZSTQwAAgL+SIT0LAkACQCBCIHFdDQBDAAAAACFIIEIgggFeRQ0BIEJDAACAv5IgcZUiQiBCIEIgQpSSkkMAAIA/kiFIDAELIEIgcZUiQiBCkiBCIEKUk0MAAIC/kiFICyBxIGySIkJDAACAv5IgQiBCQwAAgD9gGyFsIEFDAACAP0MAAIC/IAcbID2SIEiTkiFBIARBBEYNACB4QwAAAD9DAAAAvyB4QwAAAD9dIgcbkiFCAkACQCB4IHtdDQBDAAAAACE9IHgggwFeRQ0BIHhDAACAv5Ige5UiPSA9ID0gPZSSkkMAAIA/kiE9DAELIHgge5UiPSA9kiA9ID2Uk0MAAIC/kiE9CwJAAkAgQiB7XQ0AQwAAAAAhSCBCIIMBXkUNASBCQwAAgL+SIHuVIkIgQiBCIEKUkpJDAACAP5IhSAwBCyBCIHuVIkIgQpIgQiBClJNDAACAv5IhSAsgeyB4kiJCQwAAgL+SIEIgQkMAAIA/YBsheCBBQwAAgD9DAACAvyAHGyA9kiBIk5IhQSAEQQVGDQAgfkMAAAA/QwAAAL8gfkMAAAA/XSIHG5IhQgJAAkAgfiCBAV0NAEMAAAAAIT0gfiCPAV5FDQEgfkMAAIC/kiCBAZUiPSA9ID0gPZSSkkMAAIA/kiE9DAELIH4ggQGVIj0gPZIgPSA9lJNDAACAv5IhPQsCQAJAIEIggQFdDQBDAAAAACFIIEIgjwFeRQ0BIEJDAACAv5IggQGVIkIgQiBCIEKUkpJDAACAP5IhSAwBCyBCIIEBlSJCIEKSIEIgQpSTQwAAgL+SIUgLIIEBIH6SIkJDAACAv5IgQiBCQwAAgD9gGyF+AkAga0UNACBBQwAAgD9DAACAvyAHGyA9kiBIk5IhQQwBCyACIG04AtwEIAIgSjgC1AQgAiAJNgLIBCACIEQ2AtgEIAIgSTgC0AQgAiA+OALMBCACIDk4ApgEIAIgfjgC1AMgAiB4OALQAyACIGw4AswDIAIgTjgCyAMgAiA7OALEAyACID84AsADIAIgPDgCvAQgAiA3OAKUBCACIDo4ArgEQQZBBkGUicCAABCLgICAAAALIAxBDXQgDHMiDEERdiAMcyIMQQV0IAxzIgyzQwAAgC+UIkIgQpJDAACAv5IhSCBgIEGUIT0CQAJAIDNB/wFHDQAgPSFBDAELIGogN5QgTSA9IDmTIk+UkiFCAkAgY0MAAAAAXkUNACB3QwAAgD9DAACAv0MAAKBAQwAAoMAgYyBClCJBIEFDAACgwF0bIkEgQUMAAKBAXhsiQSBBIEGUIkEgQSBBQwAAvUOSlEMAWodGkpRDwPcDSJKUIEEgQSBBQwAA4EGUQwDgREWSlEMAonNHkpRDwPcDSJKVIkEgQUMAAIC/XRsiQSBBQwAAgD9eG5QhQgtDAAAAACA5IE0gN5SSIGkgT5SSIkEgQZIgOZMiOSA5i0MI5TweXRshOUMAAAAAIEIgQpIgN5MiNyA3i0MI5TweXRshNwJAAkAgMw4DAgABAgsgcCBClCFBDAELID0gcCBClJMgQZMhQQsgXyBIlCBBkiE9AkACQCBFQf8BRw0AID0hQQwBCyBoIDqUIEwgPSA8kyJIlJIhQgJAIGFDAAAAAF5FDQAgdUMAAIA/QwAAgL9DAACgQEMAAKDAIGEgQpQiQSBBQwAAoMBdGyJBIEFDAACgQF4bIkEgQSBBlCJBIEEgQUMAAL1DkpRDAFqHRpKUQ8D3A0iSlCBBIEEgQUMAAOBBlEMA4ERFkpRDAKJzR5KUQ8D3A0iSlSJBIEFDAACAv10bIkEgQUMAAIA/XhuUIUILQwAAAAAgPCBMIDqUkiBnIEiUkiJBIEGSIDyTIjwgPItDCOU8Hl0bITxDAAAAACBCIEKSIDqTIjogOotDCOU8Hl0bIToCQAJAIEUOAwIBAAILID0gbiBClJMgQZMhQQwBCyBuIEKUIUELAkACQAJAAkACQAJAAkACQCAJIEdPDQAgCUEETw0BIBEgMCAJQRRsaiIHKAIATw0CCyAIIEZxQQFxRQ0CIEQhCAwECyACIG04AtwEIAIgSjgC1AQgAiAJNgLIBCACIEQ2AtgEIAIgSTgC0AQgAiA+OALMBCACIDk4ApgEIAIgfjgC1AMgAiB4OALQAyACIGw4AswDIAIgTjgCyAMgAiA7OALEAyACID84AsADIAIgPDgCvAQgAiA3OAKUBCACIDo4ArgEIAlBBEGkisCAABCLgICAAAALIAIgBy0AECIIOgCxBSACQQE6ALAFIAlBAWohCSAHKgIMIW0gByoCCCFCIAcqAgQhSiAIDQEgSiA+kyBClSFJQQAhRgwDCyAIQQFxDQJDAAAAACA+IG2UIj4gPotDCOU8Hl0bIT5BACEIDAMLQwAAgD9DAACAvyBClRDZgICAAJMhSSBCQwAAoECU/AEhCAsgCCAIQQBHayFEID4gSiA+kyBJlJIhPkEBIUYCQCAIQQJJDQBBASEIDAILQQAhCCACQQA6ALAFDAELID4gSZIhPgJAAkAgSUMAAAAAYEUNACA+IEpgDQELQQEhCCBJQwAAAABdRQ0BID4gSl9FDQELQQAhCCACQQA6ALAFIEohPgsgCkEEaiEHIAogCioCACBBID6UkjgCACARQQFqIREgQEF8aiJADQALIAIgbTgC3AQgAiBKOALUBCACIAk2AsgEIAIgRDYC2AQgAiBJOALQBCACID44AswEIAIgOTgCmAQgAiB+OALUAyACIHg4AtADIAIgbDgCzAMgAiBOOALIAyACIDs4AsQDIAIgPzgCwAMgAiA8OAK8BCACIDc4ApQEIAIgOjgCuAQLIGIgAkHAA2pB+AH8CgAACyBDIAw2AoQCAkAgQyoC6AEiN0MAAAAAWw0AIEMoAuwBIQcgQyoCqAIhPyBDKgKkAiFBAkAgbw0AIEMtAKwCIUAgQyoCoAIhSCBDKgKcAiE6IEMqApgCITkgQyoClAIhOCBDKgKQAiE9IEMqAowCITsgeSEJIHYhDCATIREDQCARIQogPSBBlCA4IDdDAAAAACAMIAdJGyI8ID+TIkKUkiE+AkAgOkMAAAAAXkUNACBIQwAAgD9DAACAv0MAAKBAQwAAoMAgOiA+lCI+ID5DAACgwF0bIj4gPkMAAKBAXhsiPiA+ID6UIj4gPiA+QwAAvUOSlEMAWodGkpRDwPcDSJKUID4gPiA+QwAA4EGUQwDgREWSlEMAonNHkpRDwPcDSJKVIj4gPkMAAIC/XRsiPiA+QwAAgD9eG5QhPgsgPyA4IEGUkiA5IEKUkiJCIEKSID+TIj+LQwjlPB5dIQQgPiA+kiBBkyJBi0MI5TweXSEIAkACQAJAIEAOAwIAAQILIDsgPpQhQgwBCyA8IDsgPpSTIEKTIUILIApBBGohEUMAAAAAID8gBBshP0MAAAAAIEEgCBshQSAKIEIgCioCAJI4AgAgDEEBaiEMIAlBfGoiCQ0ACwsgQyA/OAKoAiBDIEE4AqQCIHYggAFqIEMqAogCQ28SAzuU/AEgB2pNDQAgQ0EANgLoAQsCQCBDLQDcAUUNAAJAIEMoAmgiCiCFAU8NACBvDQEgQ0GIAWohRyCQASAKQQxsaiIMKAIIIhFBf2ohCiAMKAIEIQcgQysDGCGkASBDKwMIIVogeSEIIHYhBCATIQwDQAJAAkACQAJAAkACQAJAIBFBBEkNACBaIKQBZg0AQQAgWvwDIglBf2oiQCAKIEAgCkkbIEBBAEgbIkUgEU8NAUEAIAkgCiAJIApJGyAJQQBIGyIzIBFPDQJBACAJQQFqIkAgCiBAIApJGyBAQQBIGyJGIBFPDQNBACAJQQJqIkAgCiBAIApJGyBAQQBIGyJAIBFPDQQgWiAJuKEhWyAHIEVBAnRqKgIAIT4gByAzQQJ0aioCACE/IEMgWiBDKwMQoCJaOQMIID8gW7YiQUMAAAA/lCAHIEZBAnRqKgIAIkIgPpMgPiA+kiA/QwAAoMCUkiBCQwAAgECUkiAHIEBBAnRqKgIAIjiTIDggPyBCk0MAAEBAlJIgPpMgQZSSIEGUkpSSIT4CQCBDLQBkIglB/wFGDQAgQ0MAAAAAIEMqAjgiPyBDKgJcQwAAgD9DAACAv0MAAKBAQwAAoMAgQyoCWCBDKgJUID4gQyoCUJQgQyoCTCBDKgJIIEMqAjQiQSBDKgIoIkIgQyoCQJQgQyoCLCI4IEMqAjyUkiA/IEMqAjAiOpSSkpSUk5SUIj4gPkMAAKDAXRsiPiA+QwAAoEBeGyI+ID4gPpQiPiA+ID5DAAC9Q5KUQwBah0aSlEPA9wNIkpQgPiA+ID5DAADgQZRDAOBERZKUQwCic0eSlEPA9wNIkpUiPiA+QwAAgL9dGyI+ID5DAACAP14blCI3IEKTlCI+IEIgPpIiPJIiPiA+i0MI5TweXRs4AiggQ0MAAAAAID8gPCA4k5QiPiA4ID6SIkKSIj4gPotDCOU8Hl0bOAIsIENDAAAAACA/IEIgOpOUIj4gOiA+kiI4kiI+ID6LQwjlPB5dGzgCMCBDQwAAAAAgPyA4IEGTlCI+IEEgPpIiPpIiPyA/i0MI5TweXRs4AjQCQAJAAkACQCAJDgQDAAECAwsgQiE+DAILIEIgOCA4kpMgPpJDAACAQJQhPgwBCyA3IDxDAACAQJSTIEJDAADAQJSSIDhDAACAQJSTID6SIT4LID4gQyoCYJQhPgsgQygCcCIJIEMoAmxPDQUCQAJAIAlBBE8NACAEIEcgCUEUbGoiQCgCAE8NAQwHCyAJQQRBpIrAgAAQi4CAgAAACyBDQQE6ANgBIEMgQC0AECJFOgDZASBDIEAqAgw4AoQBIEMgQCoCBCJBOAJ8IEMgCUEBajYCcCBAKgIIIT8CQCBFDQAgQyBBIEMqAnSTID+VOAJ4DAYLIEMgP0MAAKBAlPwBNgKAASBDQwAAgD9DAACAvyA/lRDZgICAAJM4AngMBQsgQ0EAOgDcAUMAAAAAIT4MBQsgRSARQaSJwIAAEIuAgIAAAAsgMyARQaSJwIAAEIuAgIAAAAsgRiARQaSJwIAAEIuAgIAAAAsgQCARQaSJwIAAEIuAgIAAAAsCQAJAAkACQCBDLQDYASIJQQFHDQAgQy0A2QFBAXENAQsgCQ0BIENDAAAAACBDKgJ0IEMqAoQBlCI/ID+LQwjlPB5dGyI/OAJ0DAILIEMgQyoCdCI/IEMqAnwgP5MgQyoCeJSSIj84AnQgQyBDKAKAASIJIAlBAEdrNgKAASAJQQJPDQEgQ0EAOgDYAQwBCyBDIEMqAngiQiBDKgJ0kiI/OAJ0IEMqAnwhQQJAAkAgQkMAAAAAYEUNACA/IEFgDQELIEJDAAAAAF1FDQEgPyBBX0UNAQsgQ0EAOgDYASBDIEE4AnQgQSE/CyA+ID+UIT4LIAwgPiAMKgIAkjgCACAEQQFqIQQgDEEEaiEMIAhBfGoiCEUNAgwACwsgCiCFAUG0icCAABCLgICAAAALIEMqAvwBIT4CQCBvDQAgQyoCgAIhQiBDKgIEITggQyoCACE6IEMqAvgBITwgQyoC9AEhNyBDKgLwASFBIIABIREgEyEKA0AgCiByaiIJQYB4aiEMIAlBgHBqIQkgCioCACE/AkAgQUMAAAAAXkUNACA3QwAAgD9DAACAv0MAAKBAQwAAoMAgQSA/lCI/ID9DAACgwF0bIj8gP0MAAKBAXhsiPyA/ID+UIj8gPyA/QwAAvUOSlEMAWodGkpRDwPcDSJKUID8gPyA/QwAA4EGUQwDgREWSlEMAonNHkpRDwPcDSJKVIj8gP0MAAIC/XRsiPyA/QwAAgD9eG5QhPwsgCSAJKgIAIDogPCA+lCA/lCI/lJI4AgAgDCA4ID+UIAwqAgCSOAIAIApBBGohCiBCID6UIT4gEUF/aiIRDQALCyBDID44AvwBIEMgdiCAAWo2AuABAkACQCA+Q6zFJzddDQBBASEKAkAgQy0AyAVBAUcNAEEAIQogQygCtAggQygCsAhJDQAgQy0AnAlBAXENACBDKgK4CItDrMUnN10hCgsCQAJAIEMtAOgDQQFHDQBBACEJIEMoAvwCIEMoAvgCSQ0BIEMtAOQDQQFxDQEgQyoCgAOLQ6zFJzddRQ0BCwJAIEMtAKQFQQFHDQBBACEJIEMoArgEIEMoArQESQ0BIEMtAKAFQQFxDQEgQyoCvASLQ6zFJzddRQ0BC0EBIQkLQQEhDAJAIEMtAKwIRQ0AQQAhDCBDKALAByBDKAK8B0kNACBDLQCoCEEBcQ0AIEMqAsQHi0OsxSc3XSEMCwJAAkAgQy0A3AENACAKIAlxIAxxDQEMAwsgQygCcCBDKAJsSQ0CIEMtANgBQQFxDQIgDCAJIAogQyoCdItDrMUnN11xcXFBAUcNAgsgQyoC6AFDAAAAAFwNAQsgQ0EAOgCgCQtBASE1IH9FDQELQQAhCgwBC0EBIQoMAAsLIDYhMyA2IBJJDQALAkACQCA1QQFxRQ0AIABBADYCsCMMAQsgAEF/IAAoArAjIgogEmoiDCAMIApJGyIKNgKwIyAKQT9JDQACQCASQQJ0IgpFIgwNACAAQeAAakEAIAr8CwALIAwNASAAQeAEakEAIAr8CwAMAQsgAEGACWohDCAAQeAIaiEHIABB4ABqIQkgEkECdCIIIREDQCAVQQRqKgIAIT8gFSoCACE+IAAgACgCgAoiCkF/aiIEQQ8gChsiCjYCgAogCkEfSw0HIAwgCkECdGogPjgCACAAKAKACkEQaiIKQSBPDQogDCAKQQJ0aiA+OAIAIAAoAoQKIgpBB0sNAiAHIApBAnRqIgoqAgAhPiAKID84AgAgACAAKAKECkEBakEHcTYChAogACgCgAoiCkERTw0DIAkgPkMAAAA/lCAMIApBAnRqIgoqAgAgCioCPJJD2fCluJRDAAAAAJIgCioCBCAKKgI4kkMDtFg6lJIgCioCCCAKKgI0kkNXdlK7lJIgCioCDCAKKgIwkkPGRRE8lJIgCioCECAKKgIskkPO56a8lJIgCioCFCAKKgIokkM9Ey89lJIgCioCGCAKKgIkkkNYuLy9lJIgCioCHCAKKgIgkkPvcqA+lJKSOAIAIBVBCGohFSAJQQRqIQkgEUF8aiIRDQALIABBqApqIQwgAEGICmohESAAQeAEaiEJA0AgFEEEaioCACE/IBQqAgAhPiAAIAAoAqgLIgpBf2oiBEEPIAobIgo2AqgLIApBH0sNByAMIApBAnRqID44AgAgACgCqAtBEGoiCkEfSw0KIAwgCkECdGogPjgCACAAKAKsCyIKQQdLDQIgESAKQQJ0aiIKKgIAIT4gCiA/OAIAIAAgACgCrAtBAWpBB3E2AqwLIAAoAqgLIgpBEEsNAyAJID5DAAAAP5QgDCAKQQJ0aiIKKgIAIAoqAjySQ9nwpbiUQwAAAACSIAoqAgQgCioCOJJDA7RYOpSSIAoqAgggCioCNJJDV3ZSu5SSIAoqAgwgCioCMJJDxkURPJSSIAoqAhAgCioCLJJDzuemvJSSIAoqAhQgCioCKJJDPRMvPZSSIAoqAhggCioCJJJDWLi8vZSSIAoqAhwgCioCIJJD73KgPpSSkjgCACAUQQhqIRQgCUEEaiEJIAhBfGoiCA0ACwsCQCAAKAIwIgpFDQAgACgCNCIJQXxqKAIAIgxBeHEiEUEEQQggDEEDcSIMGyAKQSxsIgpqSQ0DAkAgDEUNACARIApBJ2pLDQULIAkQjYCAgAALQQAhDCAAQQA2AjggACAFNgI0IAAgBjYCMCAAQeAEaiEJIABB4ABqIREDQCAAIAxqIgpB4ABqKAIAQQF0QYCAgHhPDQcgCkHkAGooAgBBAXRB////d0sNByAKQegAaigCAEEBdEH///93Sw0HIApB7ABqKAIAQQF0Qf///3dLDQcgDEEQaiIMQYAERw0AC0EAIQwMBAsgCkEIQYSJwIAAEIuAgIAAAAsgCiAKQRBqQSBB9IjAgAAQjICAgAAAC0HgosCAAEEuQZCjwIAAEI6AgIAAAAtBoKPAgABBLkHQo8CAABCOgICAAAALA0AgACAMaiIKQeAEaigCAEEBdEH///93Sw0CIApB5ARqKAIAQQF0Qf///3dLDQIgCkHoBGooAgBBAXRB////d0sNAiAKQewEaigCAEEBdEH///93Sw0CIAxBEGoiDEGABEcNAAwDCwsgBEEgQdSIwIAAEIuAgIAAAAsgABCJgICAACABRQ0AAkAgEkECdCIKRSIMDQAgEUEAIAr8CwALIAwNACAJQQAgCvwLAAsgAkHgCmokgICAgAAPCyAKQSBB5IjAgAAQi4CAgAAAC18CAX8BfiOAgICAAEEgayIDJICAgIAAIAMgATYCDCADIAA2AgggA0GCgICAAK1CIIYiBCADQQhqrYQ3AxggAyAEIANBDGqthDcDEEGogMCAACADQRBqIAIQgoCAgAAAC80CAgF/AX4jgICAgABBIGsiBCSAgICAAAJAAkACQCAAIAJLDQAgASACSw0BQYKAgIAArUIghiEFIAAgAU0NAiAEIAA2AgggBCABNgIMIAQgBSAEQQxqrYQ3AxggBCAFIARBCGqthDcDEEGAgMCAACAEQRBqIAMQgoCAgAAACyAEIAA2AgggBCACNgIMIARBgoCAgACtQiCGIgUgBEEMaq2ENwMYIAQgBSAEQQhqrYQ3AxBB34DAgAAgBEEQaiADEIKAgIAAAAsgBCABNgIIIAQgAjYCDCAEQYKAgIAArUIghiIFIARBDGqthDcDGCAEIAUgBEEIaq2ENwMQQZiBwIAAIARBEGogAxCCgICAAAALIAQgATYCCCAEIAI2AgwgBCAFIARBDGqthDcDGCAEIAUgBEEIaq2ENwMQQZiBwIAAIARBEGogAxCCgICAAAAL3QkBBX8gAEF4aiIBIABBfGooAgAiAkF4cSIAaiEDAkACQAJAIAJBAXENACACQQJxRQ0BIAEoAgAiAiAAaiEAAkAgASACayIBQQAoAoCswIAARw0AIAMoAgRBA3FBA0cNAUEAIAA2AvirwIAAIAMgAygCBEF+cTYCBCABIABBAXI2AgQgAyAANgIADwsgASACEKWAgIAACwJAAkACQAJAAkACQAJAAkACQCADKAIEIgJBAnENACADQQAoAoSswIAARg0CIANBACgCgKzAgABGDQUgAyACQXhxIgIQpYCAgAAgASACIABqIgBBAXI2AgQgASAAaiAANgIAIAFBACgCgKzAgABHDQFBACAANgL4q8CAAA8LIAMgAkF+cTYCBCABIABBAXI2AgQgASAAaiAANgIACyAAQYACSQ0CQR8hAyAAQYCAgAhJDQEMBgtBACABNgKErMCAAEEAQQAoAvyrwIAAIABqIgA2AvyrwIAAIAEgAEEBcjYCBAJAIAFBACgCgKzAgABHDQBBAEEANgL4q8CAAEEAQQA2AoCswIAACyAAQQAoApCswIAAIgJNDQZBUEEAKAKcrMCAACIBa0F3cUEDRg0GQQAoAoSswIAAIgBFDQZBACgC/KvAgAAiBEEpSQ0EIAFFDQNB2KnAgAAhAQNAAkAgASgCACIDIABLDQAgACADIAEoAgRqSQ0GCyABKAIIIQEMAAsLIABBJiAAQQh2ZyIDa3ZBAXEgA0EBdHJBPnMhAwwECwJAAkBBACgC8KvAgAAiA0EBIABBA3Z0IgJxDQBBACADIAJyNgLwq8CAACAAQfgBcUHoqcCAAGoiACEDDAELIABB+AFxIgBB6KnAgABqIQMgAEHwqcCAAGooAgAhAAsgAyABNgIIIAAgATYCDCABIAM2AgwgASAANgIIDwtBACABNgKArMCAAEEAQQAoAvirwIAAIABqIgA2AvirwIAAIAEgAEEBcjYCBCABIABqIAA2AgAPC0Hgo8CAABC1gICAAAALQQAhAQJAQQAoAuCpwIAAIgBFDQBBACEBA0AgAUEBaiEBIAAoAggiAA0ACwtBAEEAKAKgrMCAACIAIAEgACABSxtBfyAAGzYCmKzAgAAgBCACTQ0BQQBBfzYCkKzAgAAPCyABQgA3AhAgASADNgIcIANBAnRB2KjAgABqIQICQAJAQQAoAvSrwIAAQQEgA3QiBHENACACIAE2AgAgASACNgIYIAEgATYCDCABIAE2AghBAEEAKAL0q8CAACAEcjYC9KvAgAAMAQsCQAJAAkAgAigCACIEKAIEQXhxIABHDQAgBCEDDAELIABBAEEZIANBAXZrIANBH0YbdCECA0AgBCACQR12QQRxaiIFKAIQIgNFDQIgAkEBdCECIAMhBCADKAIEQXhxIABHDQALCyADKAIIIgAgATYCDCADIAE2AgggAUEANgIYIAEgAzYCDCABIAA2AggMAQsgBUEQaiABNgIAIAEgBDYCGCABIAE2AgwgASABNgIIC0EAIQFBAEEAKAKYrMCAAEF/aiIANgKYrMCAACAARQ0BCw8LAkBBACgC4KnAgAAiAEUNAEEAIQEDQCABQQFqIQEgACgCCCIADQALC0EAQQAoAqCswIAAIgAgASAAIAFLG0F/IAAbNgKYrMCAAAsVACAAIAFBAXRBAXIgAhCCgICAAAALOgEBfwJAIABFDQAgASAAKAIgIgNPDQAgAiADTw0AIAAoAhwgAUECdGoiACAAKAIAQQEgAnRyNgIACwurBwEHfwJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQCAARQ0AAkAgACgCACIBRQ0AIAAoAgQiAkF8aigCACIDQXhxIgRBBEEIIANBA3EiAxsgAUHQEmwiAXJJDQICQCADRQ0AIAQgAUEnaksNBAsgAhCNgICAAAsCQCAAKAIMIgFFDQAgACgCECICQXxqKAIAIgNBeHEiBEEEQQggA0EDcSIDGyABQQJ0IgFqSQ0EAkAgA0UNACAEIAFBJ2pLDQYLIAIQjYCAgAALAkAgACgCGCIBRQ0AIAAoAhwiAkF8aigCACIDQXhxIgRBBEEIIANBA3EiAxsgAUECdCIBakkNBgJAIANFDQAgBCABQSdqSw0ICyACEI2AgIAACyAAKAIoIQUCQCAAKAIsIgNFDQAgBSEBA0ACQCABKAIAIgJFDQAgAUEEaigCACIGQXxqKAIAIgRBeHEiB0EEQQggBEEDcSIEGyACQQJ0IgJqSQ0KAkAgBEUNACAHIAJBJ2pLDQwLIAYQjYCAgAALIAFBDGohASADQX9qIgMNAAsLAkAgACgCJCIBRQ0AIAVBfGooAgAiA0F4cSICQQRBCCADQQNxIgMbIAFBDGwiAWpJDQoCQCADRQ0AIAIgAUEnaksNDAsgBRCNgICAAAsCQCAAKAIwIgFFDQAgACgCNCICQXxqKAIAIgNBeHEiBEEEQQggA0EDcSIDGyABQSxsIgFqSQ0MAkAgA0UNACAEIAFBJ2pLDQ4LIAIQjYCAgAALIABBfGooAgAiAUF4cSIDQcAjQcQjIAFBA3EiARtJDQ0CQCABRQ0AIANB5CNPDQ8LIAAQjYCAgAALDwtB4KLAgABBLkGQo8CAABCOgICAAAALQaCjwIAAQS5B0KPAgAAQjoCAgAAAC0HgosCAAEEuQZCjwIAAEI6AgIAAAAtBoKPAgABBLkHQo8CAABCOgICAAAALQeCiwIAAQS5BkKPAgAAQjoCAgAAAC0Ggo8CAAEEuQdCjwIAAEI6AgIAAAAtB4KLAgABBLkGQo8CAABCOgICAAAALQaCjwIAAQS5B0KPAgAAQjoCAgAAAC0HgosCAAEEuQZCjwIAAEI6AgIAAAAtBoKPAgABBLkHQo8CAABCOgICAAAALQeCiwIAAQS5BkKPAgAAQjoCAgAAAC0Ggo8CAAEEuQdCjwIAAEI6AgIAAAAtB4KLAgABBLkGQo8CAABCOgICAAAALQaCjwIAAQS5B0KPAgAAQjoCAgAAAC8ECAQV/QQAhAwJAAkACQAJAAkAgAEUNACAALQC4I0EDSQ0AIAEgACgCLE8NACACQf////8DSw0BIAJBAnQiBEH9////B08NAQJAAkAgBA0AQQQhA0EAIQQMAQsgBBCIgICAACIDRQ0DAkAgA0F8ai0AAEEDcUUNACAERQ0AIANBACAE/AsACyACIQQLAkAgACgCKCABQQxsaiIAKAIAIgFFDQAgACgCBCIFQXxqKAIAIgZBeHEiB0EEQQggBkEDcSIGGyABQQJ0IgFqSQ0EAkAgBkUNACAHIAFBJ2pLDQYLIAUQjYCAgAALIAAgAjYCCCAAIAM2AgQgACAENgIACyADDwsQkoCAgAAAC0EEIAQQhoCAgAAAC0HgosCAAEEuQZCjwIAAEI6AgIAAAAtBoKPAgABBLkHQo8CAABCOgICAAAALFwBBqYvAgABBI0G8i8CAABCCgICAAAALnDICCn8EfiOAgICAAEGgIGsiAiSAgICAAEEAIQMCQAJAAkACQAJAAkACQCABQQRLDQAgAkIANwO4CCACQgA3A7AIIAJCADcDqAggAkIANwOgCCACQcAIakEAQYAI/AsAIAJBADsBICACQgA3AxggAkIANwMQIAJCADcDCCACQgA3AwAgAkIANwIkIAJCADcCLCACQgA3AjQgAkIANwI8IAJBADsBRCACQgA3A0ggAkIANwNQIAJCADcDWCACQgA3A2AgAkEAOwFoIAJCADcCbCACQgA3AnQgAkIANwJ8IAJCADcChAEgAkEAOwGMASACQQA6AIAZIAJCADcD+BggAkIANwPwGCACQgA3AoQZIAJCADcCjBkgAkEAOgCUGSACQgA3A5gZIAJCADcDoBkgAkEAOgCoGSACQgA3AqwZIAJCADcCtBkgAkEAOgC8GSACQgA3A7AdIAJCADcDuB0gAkEAOgDAHSACQgA3AsQdIAJCADcCzB0gAkEAOgDUHSACQQA6AOgdIAJCADcD4B0gAkIANwPYHSACQQA6APwdIAJCADcC9B0gAkIANwLsHSACQQA6AKgcIAJCADcDoBwgAkIANwOYHCACQQA6ALwcIAJCADcCtBwgAkIANwKsHCACQQA6ANAcIAJCADcDyBwgAkIANwPAHCACQgA3AtQcIAJCADcC3BwgAkEAOgDkHCACQQA6APAZIAJCADcD6BkgAkIANwPgGSACQQA6AIQaIAJCADcC/BkgAkIANwL0GSACQQA6AJgaIAJCADcDkBogAkIANwOIGiACQQA6AKwaIAJCADcCpBogAkIANwKcGiACQQA6AKAfIAJCADcDmB8gAkIANwOQHyACQQA6ALQfIAJCADcCrB8gAkIANwKkHyACQQA6AMgfIAJCADcDwB8gAkIANwO4HyACQQA6ANwfIAJCADcC1B8gAkIANwLMHyACQYUbakEDaiACQZAB/AoAACACQgA3A/gaIAJCADcD8BogAkIANwPoGiACQgA3A+AaIAJCADcD2BogAkIANwPQGiACQgA3A4ggIAJCADcDkCAgAkIANwOYICACQcgeakEAQcUA/AsAIAJBADsBICACQgA3AxggAkIANwMQIAJCADcDCCACQgA3AwAgAkIANwIkIAJCADcCLCACQgA3AjQgAkIANwI8IAJBADsBRCACQgA3A0ggAkIANwNQIAJCADcDWCACQgA3A2AgAkEAOwFoIAJCADcCbCACQgA3AnQgAkIANwJ8IAJCADcChAEgAkEAOwGMASACQQA6APARIAJCADcD6BEgAkIANwPgESACQgA3AvQRIAJCADcC/BEgAkEAOgCEEiACQgA3A4gSIAJCADcDkBIgAkEAOgCYEiACQgA3ApwSIAJCADcCpBIgAkEAOgCsEiACQgA3A4AWIAJCADcDiBYgAkEAOgCQFiACQgA3ApQWIAJCADcCnBYgAkEAOgCkFiACQQA6ALgWIAJCADcDsBYgAkIANwOoFiACQQA6AMwWIAJCADcCxBYgAkIANwK8FiACQQA6APgUIAJCADcD8BQgAkIANwPoFCACQQA6AIwVIAJCADcChBUgAkIANwL8FCACQQA6AKAVIAJCADcDmBUgAkIANwOQFSACQgA3AqQVIAJCADcCrBUgAkEAOgC0FSACQQA6AMASIAJCADcDuBIgAkIANwOwEiACQQA6ANQSIAJCADcCzBIgAkIANwLEEiACQQA6AOgSIAJCADcD4BIgAkIANwPYEiACQQA6APwSIAJCADcC9BIgAkIANwLsEiACQQA6APAXIAJCADcD6BcgAkIANwPgFyACQQA6AIQYIAJCADcC/BcgAkIANwL0FyACQQA6AJgYIAJCADcDkBggAkIANwOIGCACQQA6AKwYIAJCADcCpBggAkIANwKcGCACQdUTakEDaiACQZAB/AoAACACQgA3A8gTIAJCADcDwBMgAkIANwO4EyACQgA3A7ATIAJCADcDqBMgAkIANwOgEyACQgA3A9gYIAJCADcD4BggAkIANwPoGCACQZgXakEAQcUA/AsAIAJCADcA6B8gAkIANwDwHyACQgA3APgfIAJCADcAgCAgAkIANwCnHiACQgA3AK8eIAJCADcAtx4gAkIANwC/HiACQQA6AMceIAJCADcAiB4gAkIANwCQHiACQgA3AJgeIAJBADYAoB4gAkIANwCPHSACQgA3AJcdIAJCADcAnx0gAkIANwCnHSACQQA6AK8dIAJBADYAiB0gAkIANwCAHSACQgA3APgcIAJCADcA8BwgAkIANwC0GiACQgA3ALwaIAJCADcAxBogAkEANgDMGiACQgA3AMQZIAJCADcAzBkgAkIANwDUGSACQQA2ANwZIAJCADcAuBggAkIANwDAGCACQgA3AMgYIAJCADcA0BggAkEAOgCXFyACQgA3AI8XIAJCADcAhxcgAkIANwD/FiACQgA3APcWIAJBADYA8BYgAkIANwDoFiACQgA3AOAWIAJCADcA2BYgAkEAOgD/FSACQgA3APcVIAJCADcA7xUgAkIANwDnFSACQgA3AN8VIAJBADYA2BUgAkIANwDQFSACQgA3AMgVIAJCADcAwBUgAkEANgCcEyACQgA3AJQTIAJCADcAjBMgAkIANwCEEyACQQA2ABsgAkIANwATIAJCADcACyACQgA3AAMgAS0ApIvAgAAiBC0A2KTAgAAiBUHQEmwiAxCIgICAACIGRQ0BIAVBf2ohB0EAIQEDQCAGIAFqIgNCADcDACADQQhqIAIpA4ggNwMAIANBEGogAikDkCA3AwAgA0EYaiACKQOYIDcDACADQeQAakH/AToAACADQeUAaiACKQDlHzcAACADQe0AaiACKQDtHzcAACADQfUAaiACKQD1HzcAACADQf0AaiACKQD9HzcAACADQYQBaiACKACEIDYAACADQYgBaiACQZAfakHQAPwKAAAgA0HgAWpCADcDACADQdwBakEAOgAAIANB2AFqQQA7AQAgA0HoAWogAkHIHmpBxQD8CgAAIANB0AJqQf8BOgAAIANB0QJqIAIpAKQeNwAAIANB2QJqIAIpAKweNwAAIANB4QJqIAIpALQeNwAAIANB6QJqIAIpALweNwAAIANB8QJqIAIoAMQeNgAAIANB9QJqIAIpAIUeNwAAIANB/QJqIAIpAI0eNwAAIANBhQNqIAIpAJUeNwAAIANBjANqIAIpAJweNwAAIANBlANqIAJBsB1qQdAA/AoAACADQYwEakH/AToAACADQegDakEAOgAAIANB5ANqQQA7AQAgA0GNBGogAikAjB03AAAgA0GVBGogAikAlB03AAAgA0GdBGogAikAnB03AAAgA0GlBGogAikApB03AAAgA0GtBGogAigArB02AAAgA0GxBGogAikA7Rw3AAAgA0G5BGogAikA9Rw3AAAgA0HBBGogAikA/Rw3AAAgA0HIBGogAikAhB03AAAgA0HQBGogAkGYHGpB0AD8CgAAIANBpAVqQQA6AAAgA0GgBWpBADsBACADQaUFaiACQYUbakGTAfwKAAAgA0G4B2pB/wE6AAAgA0GUB2pB/wE6AAAgA0HsBmpCADcCACADQegGakEANgIAIANB4AZqIAIpA/gaNwMAIANB2AZqIAIpA/AaNwMAIANB0AZqIAIpA+gaNwMAIANByAZqIAIpA+AaNwMAIANBwAZqIAIpA9gaNwMAIANBuAZqIAIpA9AaNwMAIANBuQdqIAIpALEaNwAAIANBwQdqIAIpALkaNwAAIANByQdqIAIpAMEaNwAAIANB0AdqIAIpAMgaNwAAIANB2AdqIAJB4BlqQdAA/AoAACADQawIakEAOgAAIANBqAhqQQA7AQAgA0GtCGogAikAwRk3AAAgA0G1CGogAikAyRk3AAAgA0G9CGogAikA0Rk3AAAgA0HECGogAikA2Bk3AAAgA0HMCGogAkHwGGpB0AD8CgAAIANBqAlqQgA3AwAgA0GgCWpBADoAACADQZwJakEAOwEAIANBjApqQf8BOgAAIANBsAlqIAIpA9gYNwMAIANBuAlqIAIpA+AYNwMAIANBwAlqIAIpA+gYNwMAIANBjQpqIAIpALUYNwAAIANBlQpqIAIpAL0YNwAAIANBnQpqIAIpAMUYNwAAIANBpQpqIAIpAM0YNwAAIANBrApqIAIoANQYNgAAIANBsApqIAJB4BdqQdAA/AoAACADQYgLakIANwMAIANBhAtqQQA6AAAgA0GAC2pBADsBACADQZALaiACQZgXakHFAPwKAAAgA0H4C2pB/wE6AAAgA0H5C2ogAikA9BY3AAAgA0GBDGogAikA/BY3AAAgA0GJDGogAikAhBc3AAAgA0GRDGogAikAjBc3AAAgA0GZDGogAigAlBc2AAAgA0GdDGogAikA1RY3AAAgA0GlDGogAikA3RY3AAAgA0GtDGogAikA5RY3AAAgA0G0DGogAikA7BY3AAAgA0G8DGogAkGAFmpB0AD8CgAAIANBtA1qQf8BOgAAIANBkA1qQQA6AAAgA0GMDWpBADsBACADQbUNaiACKQDcFTcAACADQb0NaiACKQDkFTcAACADQcUNaiACKQDsFTcAACADQc0NaiACKQD0FTcAACADQdUNaiACKAD8FTYAACADQdkNaiACKQC9FTcAACADQeENaiACKQDFFTcAACADQekNaiACKQDNFTcAACADQfANaiACKQDUFTcAACADQfgNaiACQegUakHQAPwKAAAgA0HMDmpBADoAACADQcgOakEAOwEAIANBzQ5qIAJB1RNqQZMB/AoAACADQeAQakH/AToAACADQbwQakH/AToAACADQZQQakIANwIAIANBkBBqQQA2AgAgA0GIEGogAikDyBM3AwAgA0GAEGogAikDwBM3AwAgA0H4D2ogAikDuBM3AwAgA0HwD2ogAikDsBM3AwAgA0HoD2ogAikDqBM3AwAgA0HgD2ogAikDoBM3AwAgA0HhEGogAikAgRM3AAAgA0HpEGogAikAiRM3AAAgA0HxEGogAikAkRM3AAAgA0H4EGogAikAmBM3AAAgA0GAEWogAkGwEmpB0AD8CgAAIANB1BFqQQA6AAAgA0HQEWpBADsBACADQdURaiACKQAANwAAIANB3RFqIAIpAAg3AAAgA0HlEWogAikAEDcAACADQewRaiACKQAXNwAAIANB9BFqIAJB4BFqQdAA/AoAACADQcgSakEAOgAAIANBxBJqQQA7AQAgAUHQEmohASAHQX9qIgcNAAsgBiABaiIBQbBtaiIDQQA2AtQSIAFBADYCACADIAIpA4ggNwPYEiADIAIpA5AgNwPgEiADIAIpA5ggNwPoEiADQf8BOgC0EyADIAIpAOUfNwC1EyADIAIpAO0fNwC9EyADIAIpAPUfNwDFEyADIAIpAP0fNwDNEyADIAIoAIQgNgDUEyADQdgTaiACQZAfakHQAPwKAAAgA0IANwOwFCADQQA6AKwUIANBADsBqBQgA0G4FGogAkHIHmpBxQD8CgAAIANB/wE6AKAVIAMgAikApB43AKEVIAMgAikArB43AKkVIAMgAikAtB43ALEVIAMgAikAvB43ALkVIAMgAigAxB42AMEVIAMgAikAhR43AMUVIAMgAikAjR43AM0VIAMgAikAlR43ANUVIAMgAikAnB43ANwVIANB5BVqIAJBsB1qQdAA/AoAACADQf8BOgDcFiADQQA6ALgWIANBADsBtBYgAyACKQCMHTcA3RYgAyACKQCUHTcA5RYgAyACKQCcHTcA7RYgAyACKQCkHTcA9RYgAyACKACsHTYA/RYgAyACKQDtHDcAgRcgAyACKQD1HDcAiRcgAyACKQD9HDcAkRcgAyACKQCEHTcAmBcgA0GgF2ogAkGYHGpB0AD8CgAAIANBADoA9BcgA0EAOwHwFyADQfUXaiACQYUbakGTAfwKAAAgA0H/AToAiBogA0H/AToA5BkgA0IANwK8GSADQQA2ArgZIAMgAikD+Bo3A7AZIAMgAikD8Bo3A6gZIAMgAikD6Bo3A6AZIAMgAikD4Bo3A5gZIAMgAikD2Bo3A5AZIAMgAikD0Bo3A4gZIAMgAikAsRo3AIkaIAMgAikAuRo3AJEaIAMgAikAwRo3AJkaIAMgAikAyBo3AKAaIANBqBpqIAJB4BlqQdAA/AoAACADQQA6APwaIANBADsB+BogAyACKQDBGTcA/RogAyACKQDJGTcAhRsgAyACKQDRGTcAjRsgAyACKQDYGTcAlBsgA0GcG2ogAkHwGGpB0AD8CgAAIANCADcD+BsgA0EAOgDwGyADQQA7AewbIANB/wE6ANwcIAMgAikD2Bg3A4AcIAMgAikD4Bg3A4gcIAMgAikD6Bg3A5AcIAMgAikAtRg3AN0cIAMgAikAvRg3AOUcIAMgAikAxRg3AO0cIAMgAikAzRg3APUcIAMgAigA1Bg2APwcIANBgB1qIAJB4BdqQdAA/AoAACADQgA3A9gdIANBADoA1B0gA0EAOwHQHSADQeAdaiACQZgXakHFAPwKAAAgA0H/AToAyB4gAyACKQD0FjcAyR4gAyACKQD8FjcA0R4gAyACKQCEFzcA2R4gAyACKQCMFzcA4R4gAyACKACUFzYA6R4gAyACKQDVFjcA7R4gAyACKQDdFjcA9R4gAyACKQDlFjcA/R4gAyACKQDsFjcAhB8gA0GMH2ogAkGAFmpB0AD8CgAAIANB/wE6AIQgIANBADoA4B8gA0EAOwHcHyADIAIpANwVNwCFICADIAIpAOQVNwCNICADIAIpAOwVNwCVICADIAIpAPQVNwCdICADIAIoAPwVNgClICADIAIpAL0VNwCpICADIAIpAMUVNwCxICADIAIpAM0VNwC5ICADIAIpANQVNwDAICADQcggaiACQegUakHQAPwKAAAgA0EAOgCcISADQQA7AZghIANBnSFqIAJB1RNqQZMB/AoAACADQf8BOgCwIyADQf8BOgCMIyADQgA3AuQiIANBADYC4CIgAyACKQPIEzcD2CIgAyACKQPAEzcD0CIgAyACKQO4EzcDyCIgAyACKQOwEzcDwCIgAyACKQOoEzcDuCIgAyACKQOgEzcDsCIgAyACKQCBEzcAsSMgAyACKQCJEzcAuSMgAyACKQCREzcAwSMgAyACKQCYEzcAyCMgA0HQI2ogAkGwEmpB0AD8CgAAIANBADoApCQgA0EAOwGgJCADIAIpAAA3AKUkIAMgAikACDcArSQgAyACKQAQNwC1JCADIAIpABc3ALwkIANBxCRqIAJB4BFqQdAA/AoAACADQQA6AJglIANBADsBlCUgBUECdCIDEIiAgIAAIghFDQICQCAIQXxqLQAAQQNxRQ0AIANFDQAgCEEAIAP8CwALIAMQiICAgAAiCUUNAwJAIAlBfGotAABBA3FFDQAgA0UNACAJQQAgA/wLAAsgBUEMbCIDEIiAgIAAIgpFDQQgBUF/aiILQQNxIQEgCiEDAkACQCAFQX5qQf8BcUEDSQ0AIApBUGohByALQXxxIQsDQCAHIgNB2ABqQgQ3AgAgA0HQAGpCADcCACADQcgAakKAgICAwAA3AgAgA0HAAGpCBDcCACADQThqQgA3AgAgA0EwaiIHQoCAgIDAADcCACALQXxqIgsNAAsgA0HgAGohAyABDQAgB0EkaiEBDAELA0AgA0KAgICAwAA3AgAgA0EIakEANgIAIANBDGohAyABQX9qIgENAAsgA0F0aiEBCyADQQA2AgAgAUIENwIQQYAWEIiAgIAAIgFFDQUgAkHgEGpBAEGAAfwLACACIAIpA7gIIgw3A9gQIAIgAikDsAgiDTcD0BAgAiACKQOoCCIONwPIECACIAIpA6AIIg83A8AQIAIgDzcDgAggAiAONwOICCACIA03A5AIIAIgDDcDmAggAiACQcAIakGACPwKAABBvCMQiICAgAAiA0UNBiADQQA2AjggAyABNgI0IANBwAA2AjAgAyAFNgIsIAMgCjYCKCADIAU2AiQgAyAFNgIgIAMgCTYCHCADIAU2AhggAyAFNgIUIAMgCDYCECADIAU2AgwgAyAFNgIIIAMgBjYCBCADIAU2AgAgAyACKQOACDcCQCADIAIpA4gINwJIIAMgAikDkAg3AlAgAyACKQOYCDcCWCADIABDAIA7RyAAIAC8IgFBAEgbQwCAO0cgAUH/////B3FBgICAfGpBgICA+AdJGyABQX9qQf///wNJGzgCPCADQeAAaiACQYAI/AoAACADQeAIaiACQcAQakGgAfwKAAAgA0IANwKACiADQYgKaiACQcAQakGgAfwKAAAgA0GoC2pBAEGIGPwLACADIAQ6ALgjIAMgBEG5893xeWxBkemXqgJzNgK0IyADQX82ArAjCyACQaAgaiSAgICAACADDwtBCCADEIaAgIAAAAtBBCADEIaAgIAAAAtBBCADEIaAgIAAAAtBBCADEIaAgIAAAAtBBEGAFhCGgICAAAALQQRBvCMQlICAgAAACw0AIAEgABCngICAAAALFgAgACABQQBHQQl0akHgAGpBACAAGwsNACAAQcAAakEAIAAbCxQAAkAgAEUNACAAIAEQioCAgAALCxIAAkAgAEUNACAAEImAgIAACwvsAQECfyOAgICAAEEgayIEJICAgIAAAkAgAEUNACABIAAoAghPDQAgA7xBAXRB////d0sNACAAKAI4IgVBP0sNACAEIAApAlg3AxggBCAAKQJQNwMQIAQgACkCSDcDCCAEIAApAkA3AwAgAkH/ACACQf8ASRshAgJAIAUgACgCMEcNACAAQTBqEISAgIAACyAAIAVBAWo2AjggACgCNCAFQSxsaiIAIAQpAwA3AgAgACAEKQMINwIIIAAgBCkDEDcCECAAIAQpAxg3AhggACADOAIoIAAgAjYCJCAAIAE2AiALIARBIGokgICAgAALDQAgAEGABGpBACAAGwtzAQJ/AkACQAJAIABFDQAgAEF8aigCACIBQXhxQaQPQagPIAFBA3EiAhtJDQECQCACRQ0AIAFByA9PDQMLIAAQjYCAgAALDwtB4KLAgABBLkGQo8CAABCOgICAAAALQaCjwIAAQS5B0KPAgAAQjoCAgAAACwQAIAAL+QQDAn8DfQF+I4CAgIAAQcAPayIBJICAgIAAAkACQCAAQwCAO0cgACAAvCICQQBIG0MAgDtHIAJB/////wdxQYCAgHxqQYCAgPgHSRsgAkF/akH///8DSRsiA0NmZuY+lCIAQwAAoEFgRQ0AIABDAAB6RCAAQwAAekRdG0PbD0lAlCADIAOSIgSVEOOAgIAAIQUgAUIANwLwDiABQgA3AugOIAFBADYCsA0gAUEIakEAQYAM/AsAIAFDAACAP0MAAIC/IANDCtcjPJSVENmAgIAAkyIDOALYDSABQs2Zs/LTmbOmPjcC0A0gASADOALMDSABQgA3AsQNIAEgAzgCwA0gAULVmPSG1IrD7sAANwK4DSABIAA4ArQNIAFB3A1qQQBBhAH8CwAgAUEIakGADGpBAEGoAfwLACABQQA6AKQPIAFBgICA/AM2AqAPIAFCgICA/IOAgMA/NwKYDyABQoCAgICAgIDAPzcCjA8gASAAOALkDiABIAQ4AuAOIAFDAACAPyAFQwAAgD+SlSIAOAKIDyABIAUgAJQiADgC+A4gASAAIACUIgM4AvwOIAEgACADlDgCgA8gASADIAOUIgA4AoQPIAFDAACAPyAAQwAAAACUQwAAgD+SlTgClA8gAUEIahCAgICAAEGgDxCIgICAACICRQ0BIAIgAUEIakGgD/wKAAAgAUHAD2okgICAgAAgAg8LIAFBgICAjQQ2AqgPIAEgADgCrA8gAUGBgICAAK1CIIYiBiABQawPaq2ENwO4DyABIAYgAUGoD2qthDcDsA9Bz4HAgAAgAUGwD2pBxIjAgAAQgoCAgAAAC0EEQaAPEJSAgIAAAAsNACAAQYAIakEAIAAbC/oWBQd/BH0BfgF/D30jgICAgABBsAFrIgIkgICAgAACQCAARQ0AIAFBgAEgAUGAAUkbIQMCQCABRQ0AIABBoAxqIQQgAEGADGohBSAAQdQNaiEGIAMhByAAIQgCQAJAAkACQAJAAkADQCAIQYAEaioCACIJQwAAAAAgCbxBAXRBgICAeEkbIQoCQAJAAkAgACoCsA0iCSAAKgK0DSILXA0AIAogACoCqA1cDQEMAgsCQCAJIAsgCZMgACoCuA2UkiIMIAlcDQAgACALIgk4ArANDAELIAwhCQJAIAsgDJOLQ703hjVdDQAgACAJOAKwDQwBCyAAIAsiCTgCsA0LIAAgCjgCqA0CQCAAKgLcDiILQwAAoEFgRQ0AIABDAACAPyALQwAAoEEgCkOaaxc6lCAJkhDZgICAACIJIAlDAACgQV0bIgkgCSALXhtD2w9JQJQgACoC2A6VEOOAgIAAIglDAACAP5KVIgo4AoAPIAAgCSAKlCIJOALwDiAAIAkgCZQiCjgC9A4gACAKIAqUIgs4AvwOIAAgCSAKlDgC+A4gAEMAAIA/IAsgACoChA+UQwAAgD+SlTgCjA8MAQsgAkGAgICNBDYCqAEgAiALOAKsASACQYGAgIAArUIghiINIAJBrAFqrYQ3AxAgAiANIAJBqAFqrYQ3AwhBz4HAgAAgAkEIakHEiMCAABCCgICAAAALAkAgACoCvA0iCiAAKgLADSILWw0AAkACQCAKIAsgCpMgACoCxA2UkiIJIApcDQAgCyEJDAELIAsgCZOLQ703hjVdRQ0AIAshCQsgACAJOAK8DSAAQwAAgD9DAAAAACAJIAlDAAAAAF0bIgkgCUMAAIA/XhtDAACAQJQiCTgChA8gACAJQwAAAD+UQwAAgD+SQwAAgD8gAC0AnA9BAkkbOAKIDyAAQwAAgD8gCSAAKgL8DpRDAACAP5KVOAKMDwsCQCAAKgLIDSIKIAAqAswNIgtbDQACQAJAIAogCyAKkyAAKgLQDZSSIgkgClwNACALIQkMAQsgCyAJk4tDvTeGNV1FDQAgCyEJCyAAIAk4AsgNIABDAACAP0MAAAAAIAkgCUMAAAAAXRsiCSAJQwAAgD9eG0MAAEBAlBDhgICAACIJOAKQDyAAQwAAgD8gCZU4ApQPIAAgCZGLOAKYDwsgCCoCACEJIAAgACgC1A4iDkF/akEPIA4bIg42AtQOAkAgDkEfSw0AIAYgDkECdGpDAAAAACAJIAmLQwjlPB5dGyIJOAIAIAAoAtQOQRBqIg5BIE8NAiAGIA5BAnRqIAk4AgAgACgC1A4iDkERTw0DQwAAAAAgACoC8A4iCSAAKgKUDyIPQwAAgD9DAACAv0MAAKBAQwAAoMAgACoCkA8iECAAKgKMDyIRIAAqAogPIhIgBiAOQQJ0aiIOKgIAIA4qAjySQ9nwpbiUQwAAAACSIA4qAgQgDioCOJJDA7RYOpSSIA4qAgggDioCNJJDV3ZSu5SSIA4qAgwgDioCMJJDxkURPJSSIA4qAhAgDioCLJJDzuemvJSSIA4qAhQgDioCKJJDPRMvPZSSIA4qAhggDioCJJJDWLi8vZSSIA4qAhwiEyAOKgIgkkPvcqA+lJIiCiAKkpQgACoChA8iFCAAKgKADyIVIAAqAuwOIhYgACoC+A4iFyAAKgLgDiILlCAAKgL0DiIYIAAqAuQOIgyUkiAJIAAqAugOIhmUkpKUlJOUlCIKIApDAACgwF0bIgogCkMAAKBAXhsiCiAKIAqUIgogCiAKQwAAvUOSlEMAWodGkpRDwPcDSJKUIAogCiAKQwAA4EGUQwDgREWSlEMAonNHkpRDwPcDSJKVIgogCkMAAIC/XRsiCiAKQwAAgD9eG5QiGiALk5QiCiALIAqSIhuSIgogCotDCOU8Hl0bIQtDAAAAACAJIBsgDJOUIgogDCAKkiIKkiIMIAyLQwjlPB5dGyEMQwAAAAAgCSAKIBmTlCIcIBkgHJIiHZIiGSAZi0MI5TweXRshGUMAAAAAIAkgHSAWk5QiHCAWIBySIhySIhYgFotDCOU8Hl0bIRYCQAJAAkACQCAALQCcDyIODgQDAAECAwsgCiEcDAILIAogHSAdkpMgHJJDAACAQJQhHAwBCyAaIBtDAACAQJSTIApDAADAQJSSIB1DAACAQJSTIBySIRwLQwAAAAAgCSAPQwAAgD9DAACAv0MAAKBAQwAAoMAgECARIBMgEpQgFCAVIBcgC5QgGCAMlJIgCSAZlJIgFpKUlJOUlCIKIApDAACgwF0bIgogCkMAAKBAXhsiCiAKIAqUIgogCiAKQwAAvUOSlEMAWodGkpRDwPcDSJKUIAogCiAKQwAA4EGUQwDgREWSlEMAonNHkpRDwPcDSJKVIgogCkMAAIC/XRsiCiAKQwAAgD9eG5QiDyALk5QiCiALIAqSIh2SIgogCotDCOU8Hl0bIRtDAAAAACAJIB0gDJOUIgogDCAKkiIKkiILIAuLQwjlPB5dGyEMQwAAAAAgCSAKIBmTlCILIBkgC5IiC5IiGSAZi0MI5TweXRshGUMAAAAAIAkgCyAWk5QiCSAWIAmSIgmSIhYgFotDCOU8Hl0bIRYCQAJAAkACQCAODgQDAgEAAwsgDyAdQwAAgECUkyAKQwAAwECUkiALQwAAgECUkyAJkiEJDAILIAogCyALkpMgCZJDAACAQJQhCQwBCyAKIQkLIAAqApgPIQogACAWOALsDiAAIBk4AugOIAAgDDgC5A4gACAbOALgDiAAIAAoAqANIg5Bf2pBDyAOGyIONgKgDSAOQR9LDQQgBCAOQQJ0aiAKIByUIgs4AgAgACgCoA1BEGoiDkEgTw0FIAQgDkECdGogCzgCACAAKAKkDSIOQQdLDQYgBSAOQQJ0aiIOKgIAIQsgDiAKIAmUOAIAIAAgACgCpA1BAWpBB3E2AqQNIAAoAqANIg5BEU8NByAIQYAIaiALQwAAAD+UIAQgDkECdGoiDioCACAOKgI8kkPZ8KW4lEMAAAAAkiAOKgIEIA4qAjiSQwO0WDqUkiAOKgIIIA4qAjSSQ1d2UruUkiAOKgIMIA4qAjCSQ8ZFETyUkiAOKgIQIA4qAiySQ87npryUkiAOKgIUIA4qAiiSQz0TLz2UkiAOKgIYIA4qAiSSQ1i4vL2UkiAOKgIcIA4qAiCSQ+9yoD6UkpI4AgAgCEEEaiEIIAdBf2oiBw0BDAgLCyAOQSBB1IjAgAAQi4CAgAAACyAOQSBB5IjAgAAQi4CAgAAACyAOIA5BEGpBIEH0iMCAABCMgICAAAALIA5BIEHUiMCAABCLgICAAAALIA5BIEHkiMCAABCLgICAAAALIA5BCEGEicCAABCLgICAAAALIA4gDkEQakEgQfSIwIAAEIyAgIAAAAsCQCAAKALgDkEBdEH///93Sw0AIAAoAuQOQQF0Qf///3dLDQAgACgC6A5BAXRB////d0sNACAAKALsDkEBdEH///93Sw0AIABB1A1qEIOAgIAARQ0AIABBoAxqEIOAgIAARQ0AIAAoAoAMQQF0Qf///3dLDQAgACgChAxBAXRB////d0sNACAAKAKIDEEBdEH///93Sw0AIAAoAowMQQF0Qf///3dLDQAgACgCkAxBAXRB////d0sNACAAKAKUDEEBdEH///93Sw0AIAAoApgMQQF0Qf///3dLDQAgACgCnAxBAXRB////d00NAQsgAEHgDmoiDkIANwIIIA5CADcCACACQShqQQBBgAH8CwAgAEHUDWpBAEGEAfwLACACQgA3AyAgAkIANwMYIAJCADcDECACQgA3AwggAEGADGogAkEIakGgAfwKAAAgAEIANwKgDSABRQ0AIANBAnQiDkUNACAAQYAIakEAIA78CwALIAJBsAFqJICAgIAAC7QBAQF/I4CAgIAAQaABayIBJICAgIAAAkAgAEUNACAAIAAqArQNOAKwDSAAIAAqAsANOAK8DSAAIAAqAswNOALIDSAAEICAgIAAIABCADcC6A4gAEIANwLgDiABQSBqQQBBgAH8CwAgAEHUDWpBAEGEAfwLACABQgA3AxggAUIANwMQIAFCADcDCCABQgA3AwAgAEGADGogAUGgAfwKAAAgAEIANwKgDQsgAUGgAWokgICAgAALxQEDAX8BfQF+I4CAgIAAQSBrIgIkgICAgAACQAJAIABFDQAgAbxBAXRB////d0sNACAAKgKsDSIDQwAAoEFgRQ0BIAAgA0MAAKBBIAEgAUMAAKBBXRsiASABIANeGxDegICAADgCtA0LIAJBIGokgICAgAAPCyACQYCAgI0ENgIIIAIgAzgCDCACQYGAgIAArUIghiIEIAJBDGqthDcDGCACIAQgAkEIaq2ENwMQQc+BwIAAIAJBEGpBxIjAgAAQgoCAgAAACz4AAkAgAEUNACABvEEBdEH///93Sw0AIABDAACAP0MAAAAAIAEgAUMAAAAAXRsiASABQwAAgD9eGzgCzA0LC20CAn8BfQJAIABFDQBBAiECQQAhAwJAAkACQAJAAkAgAUF/ag4DAgEAAwtBAyECCyAAIAI6AJwPQwAAgD8hBAwCC0EBIQMLIAAgAzoAnA8gACoChA9DAAAAP5RDAACAP5IhBAsgACAEOAKIDwsLPgACQCAARQ0AIAG8QQF0Qf///3dLDQAgAEMAAIA/QwAAAAAgASABQwAAAABdGyIBIAFDAACAP14bOALADQsLkgMBBH8gACgCDCECAkACQAJAAkAgAUGAAkkNACAAKAIYIQMCQAJAAkAgAiAARw0AIABBFEEQIAAoAhQiAhtqKAIAIgENAUEAIQIMAgsgACgCCCIBIAI2AgwgAiABNgIIDAELIABBFGogAEEQaiACGyEEA0AgBCEFIAEiAkEUaiACQRBqIAIoAhQiARshBCACQRRBECABG2ooAgAiAQ0ACyAFQQA2AgALIANFDQICQAJAIAAgACgCHEECdEHYqMCAAGoiASgCAEYNACADKAIQIABGDQEgAyACNgIUIAINAwwECyABIAI2AgAgAkUNBAwCCyADIAI2AhAgAg0BDAILAkAgAiAAKAIIIgRGDQAgBCACNgIMIAIgBDYCCA8LQQBBACgC8KvAgABBfiABQQN2d3E2AvCrwIAADwsgAiADNgIYAkAgACgCECIBRQ0AIAIgATYCECABIAI2AhgLIAAoAhQiAUUNACACIAE2AhQgASACNgIYDwsPC0EAQQAoAvSrwIAAQX4gACgCHHdxNgL0q8CAAAvuBgEEfyAAIAFqIQICQAJAAkACQAJAIAAoAgQiA0EBcQ0AIANBAnFFDQEgACgCACIDIAFqIQECQCAAIANrIgBBACgCgKzAgABHDQAgAigCBEEDcUEDRw0BQQAgATYC+KvAgAAgAiACKAIEQX5xNgIEIAAgAUEBcjYCBCACIAE2AgAPCyAAIAMQpYCAgAALAkACQAJAIAIoAgQiA0ECcQ0AIAJBACgChKzAgABGDQIgAkEAKAKArMCAAEYNBCACIANBeHEiAxClgICAACAAIAMgAWoiAUEBcjYCBCAAIAFqIAE2AgAgAEEAKAKArMCAAEcNAUEAIAE2AvirwIAADwsgAiADQX5xNgIEIAAgAUEBcjYCBCAAIAFqIAE2AgALAkAgAUGAAkkNAEEfIQIgAUGAgIAISQ0EDAULAkACQEEAKALwq8CAACICQQEgAUEDdnQiA3ENAEEAIAIgA3I2AvCrwIAAIAFB+AFxQeipwIAAaiIBIQIMAQsgAUH4AXEiAUHoqcCAAGohAiABQfCpwIAAaigCACEBCyACIAA2AgggASAANgIMIAAgAjYCDCAAIAE2AggPC0EAIAA2AoSswIAAQQBBACgC/KvAgAAgAWoiATYC/KvAgAAgACABQQFyNgIEIABBACgCgKzAgABHDQBBAEEANgL4q8CAAEEAQQA2AoCswIAACw8LQQAgADYCgKzAgABBAEEAKAL4q8CAACABaiIBNgL4q8CAACAAIAFBAXI2AgQgACABaiABNgIADwsgAUEmIAFBCHZnIgJrdkEBcSACQQF0ckE+cyECCyAAQgA3AhAgACACNgIcIAJBAnRB2KjAgABqIQMCQEEAKAL0q8CAAEEBIAJ0IgRxDQAgAyAANgIAIAAgAzYCGCAAIAA2AgwgACAANgIIQQBBACgC9KvAgAAgBHI2AvSrwIAADwsCQAJAAkAgAygCACIEKAIEQXhxIAFHDQAgBCECDAELIAFBAEEZIAJBAXZrIAJBH0YbdCEDA0AgBCADQR12QQRxaiIFKAIQIgJFDQIgA0EBdCEDIAIhBCACKAIEQXhxIAFHDQALCyACKAIIIgEgADYCDCACIAA2AgggAEEANgIYIAAgAjYCDCAAIAE2AggPCyAFQRBqIAA2AgAgACAENgIYIAAgADYCDCAAIAA2AggLDQAgASAAENeAgIAAAAueAQIBfwF+I4CAgIAAQTBrIgIkgICAgAAgAkHci8CAADYCBCACIAA2AgAgAkHci8CAADYCDCACIAE2AgggAkECNgIUIAJB5Y3AgAA2AhAgAkGDgICAAK1CIIYiAyACQQhqrYQ3AyggAiADIAKthDcDICACQYSAgIAArUIghiACQRBqrYQ3AxhBgILAgAAgAkEYakGwjMCAABCCgICAAAALHAAgACgCACABIAAoAgQoAgwRgICAgACAgICAAAvBCgEMfyAAKAIEIQIgACgCACEDAkACQCABKAIIIgRBgICAwAFxRQ0AAkACQCAEQYCAgIABcQ0AAkAgAkEQSQ0AIAIgAyADQQNqQXxxIgVrIgZqIgdBA3EhCEEAIQlBACEAAkAgAyAFRg0AQQAhCkEAIQACQCAGQXxLDQBBACEKQQAhAANAIAAgAyAKaiILLAAAQb9/SmogC0EBaiwAAEG/f0pqIAtBAmosAABBv39KaiALQQNqLAAAQb9/SmohACAKQQRqIgoNAAsLIAMgCmohCwNAIAAgCywAAEG/f0pqIQAgC0EBaiELIAZBAWoiBg0ACwsCQCAIRQ0AIAUgB0H8////B3FqIgssAABBv39KIQkgCEEBRg0AIAkgCywAAUG/f0pqIQkgCEECRg0AIAkgCywAAkG/f0pqIQkLIAdBAnYhCCAJIABqIQoDQCAFIQkgCEUNAyAIQcABIAhBwAFJGyIHQQNxIQwCQAJAIAdBAnQiDUHwB3EiAA0AQQAhCwwBCyAJIABqIQZBACELIAkhAANAIABBDGooAgAiBUF/c0EHdiAFQQZ2ckGBgoQIcSAAQQhqKAIAIgVBf3NBB3YgBUEGdnJBgYKECHEgAEEEaigCACIFQX9zQQd2IAVBBnZyQYGChAhxIAAoAgAiBUF/c0EHdiAFQQZ2ckGBgoQIcSALampqaiELIABBEGoiACAGRw0ACwsgCCAHayEIIAkgDWohBSALQQh2Qf+B/AdxIAtB/4H8B3FqQYGABGxBEHYgCmohCiAMRQ0ACyAJIAdB/AFxQQJ0aiILKAIAIgBBf3NBB3YgAEEGdnJBgYKECHEhAAJAIAxBAUYNACALKAIEIgVBf3NBB3YgBUEGdnJBgYKECHEgAGohACAMQQJGDQAgCygCCCILQX9zQQd2IAtBBnZyQYGChAhxIABqIQALIABBCHZB/4EccSAAQf+B/AdxakGBgARsQRB2IApqIQoMAgsCQCACDQBBACEKDAILIAJBA3EhC0EAIQVBACEKAkAgAkEESQ0AIAJBDHEhBkEAIQpBACEFA0AgCiADIAVqIgAsAABBv39KaiAAQQFqLAAAQb9/SmogAEECaiwAAEG/f0pqIABBA2osAABBv39KaiEKIAYgBUEEaiIFRw0ACyALRQ0CCyADIAVqIQADQCAKIAAsAABBv39KaiEKIABBAWohACALQX9qIgsNAAwCCwsCQAJAAkAgAS8BDiIKDQBBACECDAELIAMgAmohBkEAIQIgAyELIAohBQNAIAsiACAGRg0CAkACQCAALAAAIgtBf0wNACAAQQFqIQsMAQsCQCALQWBPDQAgAEECaiELDAELIABBBEEDIAtBb0sbaiELCyALIABrIAJqIQIgBUF/aiIFDQALC0EAIQULIAogBWshCgsgCiABLwEMIgBJDQELIAEoAgAgAyACIAEoAgQoAgwRgYCAgACAgICAAA8LIAAgCmshCUEAIQBBACEIAkACQAJAIARBHXZBA3EOBAIAAQICCyAJIQgMAQsgCUH+/wNxQQF2IQgLIARB////AHEhCiABKAIEIQsgASgCACEFAkACQANAIABB//8DcSAIQf//A3FPDQFBASEGIABBAWohACAFIAogCygCEBGAgICAAICAgIAARQ0ADAILC0EBIQYgBSADIAIgCygCDBGBgICAAICAgIAADQAgCSAIa0H//wNxIQhBACEAA0ACQCAAQf//A3EgCEkNAEEADwtBASEGIABBAWohACAFIAogCygCEBGAgICAAICAgIAARQ0ACwsgBgs4AgF/AX4jgICAgABBEGsiASSAgICAACAAKQIAIQIgASAANgIMIAEgAjcCBCABQQRqEMWAgIAAAAv0BAEIfyOAgICAAEEQayIEJICAgIAAAkACQAJAIANBAXENACACLQAAIgUNAUEAIQUMAgsgACACIANBAXYgASgCDBGBgICAAICAgIAAIQUMAQsgASgCDCEGQQAhBwNAIAJBAWohCAJAAkACQAJAAkAgBcBBf0oNACAFQf8BcSIJQYABRg0BIAlBwAFHDQMgBCABNgIEIAQgADYCACAEQqCAgIAGNwIIIAMgB0EDdGoiBSgCACAEIAUoAgQRgICAgACAgICAAEUNAkEBIQUMBgsCQCAAIAggBUH/AXEiBSAGEYGAgIAAgICAgAANACAIIAVqIQIMBAtBASEFDAULAkAgACACQQNqIgUgAi8AASICIAYRgYCAgACAgICAAA0AIAUgAmohAgwDC0EBIQUMBAsgB0EBaiEHIAghAgwBC0GggICABiEKAkAgBUEBcUUNACACQQVqIQggAigAASEKC0EAIQkCQAJAIAVBAnENAEEAIQsgCCECDAELIAhBAmohAiAILwAAIQsLAkACQCAFQQRxDQAgAiEIDAELIAJBAmohCCACLwAAIQkLAkACQCAFQQhxDQAgCCECDAELIAhBAmohAiAILwAAIQcLAkAgBUEQcUUNACADIAtB//8DcUEDdGovAQQhCwsCQCAFQSBxRQ0AIAMgCUH//wNxQQN0ai8BBCEJCyAEIAk7AQ4gBCALOwEMIAQgCjYCCCAEIAE2AgQgBCAANgIAAkAgAyAHQQN0aiIFKAIAIAQgBSgCBBGAgICAAICAgIAARQ0AQQEhBQwDCyAHQQFqIQcLIAItAAAiBQ0AC0EAIQULIARBEGokgICAgAAgBQv2BAIHfwF+IAAoAggiBUGAgIABcSIGQRV2IARqIQcCQAJAIAVBgICABHENAEEAIQEMAQsCQAJAIAINAEEAIQgMAQsgASwAAEG/f0ohCCACQQFGDQAgCCABLAABQb9/SmohCAsgCCAHaiEHC0ErQX8gBhshCQJAAkAgByAALwEMIgpPDQACQAJAAkAgBUGAgIAIcQ0AIAogB2shCkEAIQZBACELAkACQAJAIAVBHXZBA3EOBAIAAQACCyAKIQsMAQsgCkH+/wNxQQF2IQsLIAVB////AHEhCCAAKAIEIQcgACgCACEAA0AgBkH//wNxIAtB//8DcU8NAkEBIQUgBkEBaiEGIAAgCCAHKAIQEYCAgIAAgICAgABFDQAMBQsLIAAgACkCCCIMp0GAgID/eXFBsICAgAJyNgIIQQEhBSAAKAIAIgggACgCBCILIAkgASACEK6AgIAADQNBACEGIAogB2tB//8DcSEHA0AgBkH//wNxIAdPDQJBASEFIAZBAWohBiAIQTAgCygCEBGAgICAAICAgIAARQ0ADAQLC0EBIQUgACAHIAkgASACEK6AgIAADQIgACADIAQgBygCDBGBgICAAICAgIAADQIgCiALa0H//wNxIQtBACEGA0ACQCAGQf//A3EgC0kNAEEADwtBASEFIAZBAWohBiAAIAggBygCEBGAgICAAICAgIAARQ0ADAMLC0EBIQUgCCADIAQgCygCDBGBgICAAICAgIAADQEgACAMNwIIQQAPC0EBIQUgACgCACIGIAAoAgQiACAJIAEgAhCugICAAA0AIAYgAyAEIAAoAgwRgYCAgACAgICAACEFCyAFC0YAAkAgAkF/Rg0AIAAgAiABKAIQEYCAgIAAgICAgABFDQBBAQ8LAkAgAw0AQQAPCyAAIAMgBCABKAIMEYGAgIAAgICAgAALvQIBB38jgICAgABBEGsiAiSAgICAAEEKIQMgACgCACIEIQUCQCAEQegHSQ0AQQohAyAEIQUDQCACQQZqIANqIgZBfGogBSIAIABBkM4AbiIFQZDOAGxrIgdB//8DcUHkAG4iCEEBdC8A543AgAA7AAAgBkF+aiAHIAhB5ABsa0H//wNxQQF0LwDnjcCAADsAACADQXxqIQMgAEH/rOIESw0ACwsCQAJAIAVBCUsNACAFIQAMAQsgAkEGaiADQX5qIgNqIAUgBUH//wNxQeQAbiIAQeQAbGtB//8DcUEBdC8A543AgAA7AAALAkACQCAERQ0AIABFDQELIAJBBmogA0F/aiIDaiAAQQF0LQDojcCAADoAAAsgAUEBQQAgAkEGaiADakEKIANrEK2AgIAAIQMgAkEQaiSAgICAACADCzQBAX8jgICAgABBEGsiAiSAgICAACACIAE2AgwgAiAANgIIIAJBCGogAkEMahCogICAAAALqwQDAn8DfgJ/I4CAgIAAQSBrIgIkgICAgAAgACgCACEDAkACQAJAIAEoAggiAEGAgIAQcQ0AIABBgICAIHENAUEUIQAgAykDACIEIQUCQCAEQugHVA0AQRQhACAEIQUDQCACQQxqIABqIgNBfGogBSIGIAZCkM4AgCIFQpDOAH59pyIHQf//A3FB5ABuIghBAXQvAOeNwIAAOwAAIANBfmogByAIQeQAbGtB//8DcUEBdC8A543AgAA7AAAgAEF8aiEAIAZC/6ziBFYNAAsLAkAgBUIJWA0AIAJBDGogAEF+aiIAaiAFpyIDIANB//8DcUHkAG4iA0HkAGxrQf//A3FBAXQvAOeNwIAAOwAAIAOtIQULAkACQCAEUA0AIAVQDQELIAJBDGogAEF/aiIAaiAFp0EBdC0A6I3AgAA6AAALIAFBAUEAIAJBDGogAGpBFCAAaxCtgICAACEADAILIAMpAwAhBkERIQADQCACQQxqIABqQX5qIAanQQ9xLQDMi8CAADoAACAAQX9qIQAgBkIEiCIGQgBSDQALIAFB3KHAgABBAiACQQxqIABqQX9qQREgAGsQrYCAgAAhAAwBCyADKQMAIQZBESEAA0AgAkEMaiAAakF+aiAGp0EPcS0A3qHAgAA6AAAgAEF/aiEAIAZCBIgiBkIAUg0ACyABQdyhwIAAQQIgAkEMaiAAakF/akERIABrEK2AgIAAIQALIAJBIGokgICAgAAgAAvGBQIMfwJ+I4CAgIAAQaABayIDJICAgIAAQQAhBCADQQBBoAH8CwACQAJAAkAgACgCoAEiBSACSQ0AIAVBKU8NAiAFQQFqIQYgBUECdCEHIAEgAkECdGohCEEAIQlBACEKAkADQCADIAlBAnRqIQsDQCAJIQQgCyEMIAEgCEYNBCAMQQRqIQsgBEEBaiEJIAEoAgAhDSABQQRqIg4hASANRQ0ACyANrSEPQgAhECAHIQ0gBCEBIAAhCwNAIAFBKE8NAiAMIBAgDDUCAHwgCzUCACAPfnwiED4CACAQQiCIIRAgDEEEaiEMIAFBAWohASALQQRqIQsgDUF8aiINDQALIAUhDAJAAkAgEFANACAEIAVqIgxBKE8NASADIAxBAnRqIBCnNgIAIAYhDAsgCiAMIARqIgwgCiAMSxshCiAOIQEMAQsLIAxBKEH4jMCAABCLgICAAAALIAFBKEH4jMCAABCLgICAAAALIAJBAWohBiACQQJ0IQcgACAFQQJ0aiEOIAAhC0EAIQoCQANAIAMgBEECdGohCQNAIAQhDSAJIQwgCyAORg0DIAxBBGohCSANQQFqIQQgCygCACEIIAtBBGoiBSELIAhFDQALIAitIQ9CACEQIAchCCANIQsgASEJA0AgC0EoTw0CIAwgECAMNQIAfCAJNQIAIA9+fCIQPgIAIBBCIIghECAMQQRqIQwgC0EBaiELIAlBBGohCSAIQXxqIggNAAsgAiEMAkACQCAQUA0AIA0gAmoiDEEoTw0BIAMgDEECdGogEKc2AgAgBiEMCyAKIAwgDWoiDCAKIAxLGyEKIAUhCwwBCwsgDEEoQfiMwIAAEIuAgIAAAAsgC0EoQfiMwIAAEIuAgIAAAAsgACADQaAB/AoAACAAIAo2AqABIANBoAFqJICAgIAAIAAPC0EAIAVBKEH4jMCAABCMgICAAAALwgQBCX8CQAJAAkAgAUGACk8NACABQQV2IQICQAJAAkAgACgCoAEiA0UNACADQX9qIQQgA0ECdCAAakF8aiEFIAMgAmpBAnQgAGpBfGohBiADQSlJIQMDQCADRQ0CIAIgBGoiB0EoTw0DIAYgBSgCADYCACAGQXxqIQYgBUF8aiEFIARBf2oiBEF/Rw0ACwsgAUEfcSEFAkAgAkUNACACQQJ0IgRFDQAgAEEAIAT8CwALIAAoAqABIgcgAmohBAJAIAUNACAAIAQ2AqABIAAPCyAEQX9qIgZBJ0sNAyAEIQggACAGQQJ0aigCAEEgIAVrIgZ2IgNFDQQCQCAEQSdLDQAgACAEQQJ0aiADNgIAIARBAWohCAwFCyAEQShB+IzAgAAQi4CAgAAACyAEQShB+IzAgAAQi4CAgAAACyAHQShB+IzAgAAQi4CAgAAAC0GIjcCAAEEdQfiMwIAAEI6AgIAAAAsgBkEoQfiMwIAAEIuAgIAAAAsCQCACQQFqIgkgBE8NAAJAAkAgB0EBcUUNACAEIQMMAQsgACAEQX9qIgNBAnRqIgEgACAEQQJ0akF4aigCACAGdiABKAIAIAV0cjYCAAsgB0ECRg0AIANBAnQgAGpBdGohBANAIARBCGoiByAEQQRqIgEoAgAiCiAGdiAHKAIAIAV0cjYCACABIAQoAgAgBnYgCiAFdHI2AgAgBEF4aiEEIAkgA0F+aiIDSQ0ACwsgACACQQJ0aiIEIAQoAgAgBXQ2AgAgACAINgKgASAAC1IBAX8jgICAgABBEGsiACSAgICAACAAQRw2AgQgAEHwo8CAADYCACAAQYSAgIAArUIghiAArYQ3AwhBtYLAgAAgAEEIakGMpMCAABCCgICAAAALEwBBsI/AgABBMyAAEIKAgIAAAAuEAwEBfwJAAkAgAkUNACABLQAAQTBNDQEgBUECOwEAAkACQAJAAkACQCADwSIGQQFIDQAgBSABNgIEIAIgA0H//wNxIgNLDQIgBUEAOwEMIAUgAjYCCCAFIAMgAms2AhAgBA0BQQIhAQwECyAFIAI2AiAgBSABNgIcIAVBAjsBGCAFQQA7AQwgBUECNgIIIAVB9YvAgAA2AgQgBUEAIAZrIgM2AhBBAyEBIAQgAk0NAyAEIAJrIgIgA00NAyACIAZqIQQMAgsgBUEBNgIgIAVBr4/AgAA2AhwgBUECOwEYDAELIAVBAjsBGCAFQQE2AhQgBUGvj8CAADYCECAFQQI7AQwgBSADNgIIIAUgAiADayICNgIgIAUgASADajYCHAJAIAQgAksNAEEDIQEMAgsgBCACayEECyAFIAQ2AiggBUEAOwEkQQQhAQsgACABNgIEIAAgBTYCAA8LQcmPwIAAQSFB7I/AgAAQjoCAgAAAC0H8j8CAAEEfQZyQwIAAEI6AgIAAAAudCgIGfwJ+AkACQAJAAkACQAJAIAFBCEkNACABQQdxIgJFDQUgACgCoAEiA0EoSw0BAkAgAw0AIABBADYCoAEMBgsgA0ECdCIEQXxqIgVBAnZBAWoiBkEDcSEHIAJBAnQoAuifwIAAIAJ2rSEIQgAhCSAAIQICQAJAIAVBDEkNACAGQfz///8HcSEFQgAhCSAAIQIDQCACIAI1AgAgCH4gCXwiCT4CACACQQRqIgYgBjUCACAIfiAJQiCIfCIJPgIAIAJBCGoiBiAGNQIAIAh+IAlCIIh8Igk+AgAgAkEMaiIGIAY1AgAgCH4gCUIgiHwiCT4CACAJQiCIIQkgAkEQaiECIAVBfGoiBQ0ACyAHRQ0BCyAHQQJ0IQUDQCACIAI1AgAgCH4gCXwiCT4CACACQQRqIQIgCUIgiCEJIAVBfGoiBQ0ACwsCQCAJUA0AIANBKEYNAyAAIARqIAmnNgIAIANBAWohAwsgACADNgKgAQwFCyAAKAKgASIGQShLDQICQCAGDQAgAEEANgKgASAADwsgAUECdDUC6J/AgAAhCCAGQQJ0IgdBfGoiBUECdkEBaiIBQQNxIQNCACEJIAAhAgJAAkAgBUEMSQ0AIAFB/P///wdxIQVCACEJIAAhAgNAIAIgAjUCACAIfiAJfCIJPgIAIAJBBGoiASABNQIAIAh+IAlCIIh8Igk+AgAgAkEIaiIBIAE1AgAgCH4gCUIgiHwiCT4CACACQQxqIgEgATUCACAIfiAJQiCIfCIJPgIAIAlCIIghCSACQRBqIQIgBUF8aiIFDQALIANFDQELIANBAnQhBQNAIAIgAjUCACAIfiAJfCIJPgIAIAJBBGohAiAJQiCIIQkgBUF8aiIFDQALCwJAIAlQDQAgBkEoRg0EIAAgB2ogCac2AgAgBkEBaiEGCyAAIAY2AqABIAAPC0EAIANBKEH4jMCAABCMgICAAAALQShBKEH4jMCAABCLgICAAAALQQAgBkEoQfiMwIAAEIyAgIAAAAtBKEEoQfiMwIAAEIuAgIAAAAsCQAJAAkAgAUEIcUUNACAAKAKgASIDQShLDQECQAJAIAMNAEEAIQMMAQsgA0ECdCIEQXxqIgVBAnZBAWoiBkEDcSEHQgAhCCAAIQICQAJAIAVBDEkNACAGQfz///8HcSEFQgAhCCAAIQIDQCACIAI1AgBC4esXfiAIfCIIPgIAIAJBBGoiBiAGNQIAQuHrF34gCEIgiHwiCD4CACACQQhqIgYgBjUCAELh6xd+IAhCIIh8Igg+AgAgAkEMaiIGIAY1AgBC4esXfiAIQiCIfCIIPgIAIAhCIIghCCACQRBqIQIgBUF8aiIFDQALIAdFDQELIAdBAnQhBQNAIAIgAjUCAELh6xd+IAh8Igg+AgAgAkEEaiECIAhCIIghCCAFQXxqIgUNAAsLIAhQDQAgA0EoRg0DIAAgBGogCKc2AgAgA0EBaiEDCyAAIAM2AqABCwJAIAFBEHFFDQAgAEGQoMCAAEECELKAgIAAGgsCQCABQSBxRQ0AIABBmKDAgABBAxCygICAABoLAkAgAUHAAHFFDQAgAEGkoMCAAEEFELKAgIAAGgsCQCABQYABcUUNACAAQbigwIAAQQoQsoCAgAAaCwJAIAFBgAJxRQ0AIABB4KDAgABBExCygICAABoLIAAgARCzgICAABogAA8LQQAgA0EoQfiMwIAAEIyAgIAAAAtBKEEoQfiMwIAAEIuAgIAAAAv9AgEEfwJAAkACQAJAAkACQAJAAkAgByAIWA0AIAcgCH0gCFgNBAJAIAcgBn0gBlgNACAHIAZCAYZ9IAhCAYZaDQQLIAYgCFgNByAHIAYgCH0iCH0gCFYNByADIAJLDQUgASADaiEJIAMhCgNAIAoiC0UNAiALQX9qIgogAWoiDC0AAEE5Rg0ACyAMIAwtAABBAWo6AAAgAyALayIKRQ0CIAEgC2pBMCAK/AsADAILIABBADYCAA8LAkACQCADDQBBMSEKDAELIAFBMToAAEEwIQogA0F/aiILRQ0AIAFBAWpBMCAL/AsACyAEQQFqwSIEIAXBTA0AIAMgAk8NACAJIAo6AAAgA0EBaiEDCyADIAJNDQNBACADIAJBrKHAgAAQjICAgAAACyADIAJNDQJBACADIAJBzKHAgAAQjICAgAAACyAAQQA2AgAPC0EAIAMgAkG8ocCAABCMgICAAAALIAAgBDsBCCAAIAM2AgQgACABNgIADwsgAEEANgIAC5gNCgF/Bn4BfwR+AX8FfgJ/AX4EfwJ+I4CAgIAAQdAAayIDJICAgIAAAkACQAJAAkACQAJAAkACQAJAAkACQCABKQMAIgRCAFENACABKQMIIgVCAFENASABKQMQIgZCAFENAiAGIAR8IgcgBlQNAyAEIAVUDQQgB0KAgICAgICAgCBaDQUgAyABLwEYIgE7AUAgAyAEIAV9IgU3AzggAyAFIAd5IgaGIgggBogiCTcDSCAJIAVSDQYgAyABOwFAIAMgBDcDOCADIAQgBoYiCSAGiCIFNwNIIAUgBFINB0GgfyABIAanayIKa8FB0ABsQbCnBWpBzhBtIgFB0ABLDQkgA0EgaiABQQR0IgEpA9CQwIAAIgRCACAHIAaGQgAQ3YCAgAAgA0EQaiAEQgAgCEIAEN2AgIAAIAMgBEIAIAlCABDdgICAAEIBQQAgCiABLwHYkMCAAGprIgqtIgSGIghCf3whCyADKQMQQj+HIQwgAykDAEI/iCENIAMpAwghDiABLwHakMCAACEBIApBP3EhDyADKQMYIRACQCADKQMoIhEgAykDIEI/iCISfCITQgF8IhQgBIinIhVBkM4ASQ0AIBVBwIQ9SQ0JAkAgFUGAwtcvSQ0AQQhBCSAVQYCU69wDSSIKGyEWQYDC1y9BgJTr3AMgChshCgwMC0EGQQcgFUGAreIESSIKGyEWQcCEPUGAreIEIAobIQoMCwsCQCAVQeQASQ0AQQJBAyAVQegHSSIKGyEWQeQAQegHIAobIQoMCwtBCkEBIBVBCUsiFhshCgwKC0HgmsCAAEEcQbybwIAAEI6AgIAAAAtBzJvAgABBHUHsm8CAABCOgICAAAALQfybwIAAQRxBmJzAgAAQjoCAgAAAC0HQncCAAEE2QYiewIAAEI6AgIAAAAtBiJ3AgABBN0HAncCAABCOgICAAAALQaicwIAAQS1B2JzAgAAQjoCAgAAACyADQcgAaiADQThqELCAgIAAAAsgA0HIAGogA0E4ahCwgICAAAALQQRBBSAVQaCNBkkiChshFkGQzgBBoI0GIAobIQoMAQsgAUHRAEGMm8CAABCLgICAAAALIBQgC4MhBCANIA58IRcgD60hBiAWIAFrQQFqIRggDCAQfSAUfEIBfCIJIAuDIQVBACEBAkACQAJAAkACQAJAAkACQAJAA0AgAiABaiIZIBUgCm4iD0EwaiIaOgAAIAFBAWohGyAJIBUgDyAKbGsiFa0gBoYiHCAEfCIHVg0CAkAgFiABRw0AQgEhBwNAIAchCSABIgpBEEYNBSACIApqQQFqIARCCn4iBCAGiKdBMGoiFToAACAJQgp+IQcgCkEBaiEBIAVCCn4iBSAEIAuDIgRYDQALIAUgBH0iHCAIVCEPIAcgFCAXfX4iBiAHfCENIAQgBiAHfSILWg0HIBwgCFoNAgwHCyAKQQpJIQ8gCkEKbiEKIBshASAPRQ0AC0HonMCAABC1gICAAAALIAIgAWohASAFIAh9IRQgCCALfSEMQgAgBH0hBgNAAkAgBCAIfCIHIAtUDQAgCyAGfCAMIAR8Wg0AQQAhDwwGCyABIBVBf2oiFToAACAUIAZ8IhwgCFQhDyAHIAtaDQYgBiAIfSEGIAchBCAcIAhUDQYMAAsLIAkgB30iCCAKrSAGhiIGVCEBIBQgF30iBUIBfCEdIAcgBUJ/fCILWg0BIAggBlQNASATIAx8IBB9IAQgBnwiBCAcfH1CAnwhFCATIBd9IAd9IQwgBCANfCAOfCASfSARfSAcfCEIQgAhBANAAkAgByAGfCIFIAtUDQAgDCAEfCAIWg0AQQAhAQwDCyAZIBpBf2oiGjoAACAUIAR8IhwgBlQhASAFIAtaDQMgCCAGfCEIIAQgBn0hBCAFIQcgHCAGVA0DDAALC0ERQRFB+JzAgAAQi4CAgAAACyAHIQULAkAgHSAFWA0AIAENAAJAIAUgBnwiBCAdVA0AIB0gBX0gBCAdfVQNAQsgAEEANgIADAQLAkACQCAFQgJUDQAgBSAJQnx8WA0BCyAAQQA2AgAMBAsgACAYOwEIIAAgGzYCBAwCCyAEIQcLAkAgDSAHWA0AIA8NAAJAIAcgCHwiBCANVA0AIA0gB30gBCANfVQNAQsgAEEANgIADAILAkACQCAJQhR+IAdWDQAgByAFIAlCWH58WA0BCyAAQQA2AgAMAgsgACAYOwEIIAAgCkECajYCBAsgACACNgIACyADQdAAaiSAgICAAAvYLwMBfwR+Hn8jgICAgABBsAprIgMkgICAgAACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkAgASkDACIEQgBRDQAgASkDCCIFQgBRDQEgASkDECIGQgBRDQIgBiAEfCIHIAZUDQMgBCAFVA0EIAEsABohCCABLgEYIQEgAyAENwMIIANBAUECIARCgICAgBBUGzYCqAEgA0EIakEIakEAQZgB/AsAIAMgBTcDsAEgA0EBQQIgBUKAgICAEFQbNgLQAiADQbABakEIakEAQZgB/AsAIAMgBjcD2AIgA0EBQQIgBkKAgICAEFQbNgL4AyADQdgCakEIakEAQZgB/AsAIANBgARqQQBBnAH8CwAgA0EBNgL8AyADQQE2ApwFIAGsIAdCf3x5fULCmsHoBH5CgKHNoLQCfEIgiKciCcEhCgJAAkAgAUEASA0AIANBCGogARCzgICAABogA0GwAWogARCzgICAABogA0HYAmogARCzgICAABoMAQsgA0H8A2pBACABa8EQs4CAgAAaCwJAAkAgCkF/Sg0AIANBCGpBACAKa0H//wNxIgEQt4CAgAAaIANBsAFqIAEQt4CAgAAaIANB2AJqIAEQt4CAgAAaDAELIANB/ANqIAlB//8BcRC3gICAABoLIANBjAlqIANBCGpBpAH8CgAAIAMoAvgDIgsgAygCrAoiASALIAFLGyIMQShLDQUCQAJAIAwNAEEAIQwMAQtBACENQQAhDgJAAkACQCAMQQFGDQAgDEEBcSEPIAxBPnEhEEEAIQ0gA0GMCWohASADQdgCaiEJQQAhDgNAIAEgCSgCACIRIAEoAgBqIhIgDUEBcWoiEzYCACABQQRqIg0gCUEEaigCACIUIA0oAgBqIg0gEiARSSATIBJJcmoiEjYCACANIBRJIBIgDUlyIQ0gCUEIaiEJIAFBCGohASAQIA5BAmoiDkcNAAsgD0UNAQsgA0GMCWogDkECdCIBaiIJIANB2AJqIAFqKAIAIhIgCSgCAGoiASANaiIJNgIAIAEgEkkNASAJIAFJDQEMAgsgDUUNAQsgDEEoRg0HIANBjAlqIAxBAnRqQQE2AgAgDEEBaiEMCyADIAw2AqwKIAwgAygCnAUiFSAMIBVLGyIBQSlPDQcgAUECdCEBIANBjAlqQXxqIRICQANAAkAgAQ0AQQAhAQwCCyASIAFqIQkgAUF8aiIBIANB/ANqaigCACINIAkoAgAiCUYNAAsgDSAJSyANIAlJayEBCwJAAkAgASAISA0AAkACQAJAAkACQCADKAKoASINQShLDQACQCANDQBBACENDAULIA1BAnQiEUF8aiIBQQJ2QQFqIglBA3EhDiABQQxPDQFCACEEIANBCGohAQwCC0EAIA1BKEH4jMCAABCMgICAAAALIAlB/P///wdxIQlCACEEIANBCGohAQNAIAEgATUCAEIKfiAEfCIEPgIAIAFBBGoiEiASNQIAQgp+IARCIIh8IgQ+AgAgAUEIaiISIBI1AgBCCn4gBEIgiHwiBD4CACABQQxqIhIgEjUCAEIKfiAEQiCIfCIEPgIAIARCIIghBCABQRBqIQEgCUF8aiIJDQALIA5FDQELIA5BAnQhCQNAIAEgATUCAEIKfiAEfCIEPgIAIAFBBGohASAEQiCIIQQgCUF8aiIJDQALCyAEUA0AIA1BKEYNCyADQQhqIBFqIASnNgIAIA1BAWohDQsgAyANNgKoAQJAAkACQAJAAkAgAygC0AIiDkEoSw0AQQAhFkEAIQEgDkUNBCAOQQJ0IhNBfGoiAUECdkEBaiIJQQNxIREgAUEMTw0BQgAhBCADQbABaiEBDAILQQAgDkEoQfiMwIAAEIyAgIAAAAsgCUH8////B3EhCUIAIQQgA0GwAWohAQNAIAEgATUCAEIKfiAEfCIEPgIAIAFBBGoiEiASNQIAQgp+IARCIIh8IgQ+AgAgAUEIaiISIBI1AgBCCn4gBEIgiHwiBD4CACABQQxqIhIgEjUCAEIKfiAEQiCIfCIEPgIAIARCIIghBCABQRBqIQEgCUF8aiIJDQALIBFFDQELIBFBAnQhCQNAIAEgATUCAEIKfiAEfCIEPgIAIAFBBGohASAEQiCIIQQgCUF8aiIJDQALCwJAIARQRQ0AIA4hAQwBCyAOQShGDQwgA0GwAWogE2ogBKc2AgAgDkEBaiEBCyADIAE2AtACAkAgC0UNACALQQJ0IhFBfGoiAUECdkEBaiIJQQNxIQ4CQAJAAkAgAUEMTw0AQgAhBCADQdgCaiEBDAELIAlB/P///wdxIQlCACEEIANB2AJqIQEDQCABIAE1AgBCCn4gBHwiBD4CACABQQRqIhIgEjUCAEIKfiAEQiCIfCIEPgIAIAFBCGoiEiASNQIAQgp+IARCIIh8IgQ+AgAgAUEMaiISIBI1AgBCCn4gBEIgiHwiBD4CACAEQiCIIQQgAUEQaiEBIAlBfGoiCQ0ACyAORQ0BCyAOQQJ0IQkDQCABIAE1AgBCCn4gBHwiBD4CACABQQRqIQEgBEIgiCEEIAlBfGoiCQ0ACwsCQCAEUEUNACADIAsiFjYC+AMMAwsgC0EoRg0NIANB2AJqIBFqIASnNgIAIAtBAWohFgsgAyAWNgL4AwwBCyAKQQFqIQogAygCqAEhDSALIRYLIANBoAVqIANB/ANqQaQB/AoAACADQaAFakEBELOAgIAAIRcgA0HEBmogA0H8A2pBpAH8CgAAIANBxAZqQQIQs4CAgAAhGCADQegHaiADQfwDakGkAfwKAAACQAJAAkAgA0HoB2pBAxCzgICAACIZKAKgASIaIA0gGiANSxsiG0EoSw0AIANB/ANqQXxqIQ8gA0GMCWpBfGohHCADQaAFakF8aiELIANBxAZqQXxqIQwgA0HoB2pBfGohECAXKAKgASEdIBgoAqABIR5BACEfA0AgHyEgIBtBAnQhAQJAAkADQCABRQ0BIBAgAWohCSABQXxqIgEgA0EIamooAgAiEiAJKAIAIglGDQALQQAhISASIAlJDQELAkAgG0UNAEEBIQ1BACEOAkACQCAbQQFGDQAgG0EBcSEiIBtBPnEhI0EAIQ5BASENIANBCGohASADQegHaiEJA0AgASABKAIAIhEgCSgCAEF/c2oiEiANQQFxaiITNgIAIAFBBGoiDSANKAIAIhQgCUEEaigCAEF/c2oiDSASIBFJIBMgEklyaiISNgIAIA0gFEkgEiANSXIhDSAJQQhqIQkgAUEIaiEBICMgDkECaiIORw0ACyAiRQ0BCyADQQhqIA5BAnQiAWoiCSAJKAIAIgkgGSABaigCAEF/c2oiASANaiISNgIAIAEgCUkNASASIAFJDQEMJAsgDUUNIwsgAyAbNgKoAUEIISEgGyENCyAeIA0gHiANSxsiG0EpTw0PIBtBAnQhAQJAAkADQCABRQ0BIAwgAWohCSABQXxqIgEgA0EIamooAgAiEiAJKAIAIglGDQALIBIgCU8NACANIRsMAQsCQCAbRQ0AQQEhDUEAIQ4CQAJAIBtBAUYNACAbQQFxISIgG0E+cSEjQQAhDkEBIQ0gA0EIaiEBIANBxAZqIQkDQCABIAEoAgAiESAJKAIAQX9zaiISIA1BAXFqIhM2AgAgAUEEaiINIA0oAgAiFCAJQQRqKAIAQX9zaiINIBIgEUkgEyASSXJqIhI2AgAgDSAUSSASIA1JciENIAlBCGohCSABQQhqIQEgIyAOQQJqIg5HDQALICJFDQELIANBCGogDkECdCIBaiIJIAkoAgAiCSAYIAFqKAIAQX9zaiIBIA1qIhI2AgAgASAJSQ0BIBIgAUkNAQwjCyANRQ0iCyADIBs2AqgBICFBBHIhIQsgHSAbIB0gG0sbIiJBKU8NECAiQQJ0IQECQAJAA0AgAUUNASALIAFqIQkgAUF8aiIBIANBCGpqKAIAIhIgCSgCACIJRg0ACyASIAlPDQAgGyEiDAELAkAgIkUNAEEBIQ1BACEOAkACQCAiQQFGDQAgIkEBcSEbICJBPnEhI0EAIQ5BASENIANBCGohASADQaAFaiEJA0AgASABKAIAIhEgCSgCAEF/c2oiEiANQQFxaiITNgIAIAFBBGoiDSANKAIAIhQgCUEEaigCAEF/c2oiDSASIBFJIBMgEklyaiISNgIAIA0gFEkgEiANSXIhDSAJQQhqIQkgAUEIaiEBICMgDkECaiIORw0ACyAbRQ0BCyADQQhqIA5BAnQiAWoiCSAJKAIAIgkgFyABaigCAEF/c2oiASANaiISNgIAIAEgCUkNASASIAFJDQEMIgsgDUUNIQsgAyAiNgKoASAhQQJqISELIBUgIiAVICJLGyIbQSlPDREgG0ECdCEBAkACQANAIAFFDQEgAUF8aiIBIANBCGpqKAIAIgkgASADQfwDamooAgAiEkYNAAsgCSASTw0AICIhGwwBCwJAIBtFDQBBASENQQAhDgJAAkAgG0EBRg0AIBtBAXEhIiAbQT5xISNBACEOQQEhDSADQQhqIQEgA0H8A2ohCQNAIAEgASgCACIRIAkoAgBBf3NqIhIgDUEBcWoiEzYCACABQQRqIg0gDSgCACIUIAlBBGooAgBBf3NqIg0gEiARSSATIBJJcmoiEjYCACANIBRJIBIgDUlyIQ0gCUEIaiEJIAFBCGohASAjIA5BAmoiDkcNAAsgIkUNAQsgA0EIaiAOQQJ0IgFqIgkgCSgCACIJIANB/ANqIAFqKAIAQX9zaiIBIA1qIhI2AgAgASAJSQ0BIBIgAUkNAQwhCyANRQ0gCyADIBs2AqgBICFBAWohIQsgIEERRg0WIAIgIGogIUEwajoAACADKALQAiIhIBsgISAbSxsiAUEpTw0SICBBAWohHyABQQJ0IQECQANAAkAgAQ0AQQAhJAwCCyABQXxqIgEgA0EIamooAgAiCSABIANBsAFqaigCACISRg0ACyAJIBJLIAkgEklrISQLIANBjAlqIANBCGpBpAH8CgAAIBYgAygCrAoiASAWIAFLGyIiQShLDRMCQAJAICINAEEAISIMAQtBACENQQAhDgJAAkACQCAiQQFGDQAgIkEBcSElICJBPnEhI0EAIQ0gA0GMCWohASADQdgCaiEJQQAhDgNAIAEgCSgCACIRIAEoAgBqIhIgDUEBcWoiEzYCACABQQRqIg0gCUEEaigCACIUIA0oAgBqIg0gEiARSSATIBJJcmoiEjYCACANIBRJIBIgDUlyIQ0gCUEIaiEJIAFBCGohASAjIA5BAmoiDkcNAAsgJUUNAQsgA0GMCWogDkECdCIBaiIJIANB2AJqIAFqKAIAIhIgCSgCAGoiASANaiIJNgIAIAEgEkkNASAJIAFJDQEMAgsgDUUNAQsgIkEoRg0VIANBjAlqICJBAnRqQQE2AgAgIkEBaiEiCyADICI2AqwKICIgFSAiIBVLGyIBQSlPDRUgAUECdCEBAkADQAJAIAENAEEAIQEMAgsgHCABaiEJIA8gAWohEiABQXxqIQEgEigCACISIAkoAgAiCUYNAAsgEiAJSyASIAlJayEBCyAkIAhIDQIgASAISA0DQQAhDkEAIQ0CQCAbRQ0AIBtBAnQiEUF8aiIBQQJ2QQFqIglBA3EhDQJAAkACQCABQQxPDQBCACEEIANBCGohAQwBCyAJQfz///8HcSEJQgAhBCADQQhqIQEDQCABIAE1AgBCCn4gBHwiBD4CACABQQRqIhIgEjUCAEIKfiAEQiCIfCIEPgIAIAFBCGoiEiASNQIAQgp+IARCIIh8IgQ+AgAgAUEMaiISIBI1AgBCCn4gBEIgiHwiBD4CACAEQiCIIQQgAUEQaiEBIAlBfGoiCQ0ACyANRQ0BCyANQQJ0IQkDQCABIAE1AgBCCn4gBHwiBD4CACABQQRqIQEgBEIgiCEEIAlBfGoiCQ0ACwsCQCAEUEUNACAbIQ0MAQsgG0EoRg0YIANBCGogEWogBKc2AgAgG0EBaiENCyADIA02AqgBAkAgIUUNACAhQQJ0IhFBfGoiAUECdkEBaiIJQQNxIQ4CQAJAAkAgAUEMTw0AQgAhBCADQbABaiEBDAELIAlB/P///wdxIQlCACEEIANBsAFqIQEDQCABIAE1AgBCCn4gBHwiBD4CACABQQRqIhIgEjUCAEIKfiAEQiCIfCIEPgIAIAFBCGoiEiASNQIAQgp+IARCIIh8IgQ+AgAgAUEMaiISIBI1AgBCCn4gBEIgiHwiBD4CACAEQiCIIQQgAUEQaiEBIAlBfGoiCQ0ACyAORQ0BCyAOQQJ0IQkDQCABIAE1AgBCCn4gBHwiBD4CACABQQRqIQEgBEIgiCEEIAlBfGoiCQ0ACwsCQCAEUEUNACAhIQ4MAQsgIUEoRg0ZIANBsAFqIBFqIASnNgIAICFBAWohDgsgAyAONgLQAgJAAkAgFg0AQQAhFgwBCyAWQQJ0IhFBfGoiAUECdkEBaiIJQQNxIQ4CQAJAAkAgAUEMTw0AQgAhBCADQdgCaiEBDAELIAlB/P///wdxIQlCACEEIANB2AJqIQEDQCABIAE1AgBCCn4gBHwiBD4CACABQQRqIhIgEjUCAEIKfiAEQiCIfCIEPgIAIAFBCGoiEiASNQIAQgp+IARCIIh8IgQ+AgAgAUEMaiISIBI1AgBCCn4gBEIgiHwiBD4CACAEQiCIIQQgAUEQaiEBIAlBfGoiCQ0ACyAORQ0BCyAOQQJ0IQkDQCABIAE1AgBCCn4gBHwiBD4CACABQQRqIQEgBEIgiCEEIAlBfGoiCQ0ACwsgBFANACAWQShGDRogA0HYAmogEWogBKc2AgAgFkEBaiEWCyADIBY2AvgDIBogDSAaIA1LGyIbQSlJDQALC0EAIBtBKEH4jMCAABCMgICAAAALIAEgCE4NGSADQQhqQQEQs4CAgAAaIBUgAygCqAEiASAVIAFLGyIBQSlPDRcgAUECdCEBIANBCGpBfGohDSADQfwDakF8aiEOA0AgAUUNASAOIAFqIQkgDSABaiESIAFBfGohASASKAIAIhIgCSgCACIJRg0ACyASIAlJDRkLIAIgH2ohDSAfIQECQANAIAEiCUUNASAJQX9qIgEgAmoiEi0AAEE5Rg0ACyASIBItAABBAWo6AAAgHyAJayIBRQ0ZIAIgCWpBMCAB/AsADBkLIAJBMToAAAJAICBFDQAgAkEBakEwICD8CwALICBBD0sNFyANQTA6AAAgCkEBaiEKICBBAmohHwwZC0HgmsCAAEEcQeiewIAAEI6AgIAAAAtBzJvAgABBHUH4nsCAABCOgICAAAALQfybwIAAQRxBiJ/AgAAQjoCAgAAAC0HQncCAAEE2QdifwIAAEI6AgIAAAAtBiJ3AgABBN0HIn8CAABCOgICAAAALQQAgDEEoQfiMwIAAEIyAgIAAAAtBKEEoQfiMwIAAEIuAgIAAAAtBACABQShB+IzAgAAQjICAgAAAC0EoQShB+IzAgAAQi4CAgAAAC0EoQShB+IzAgAAQi4CAgAAAC0EoQShB+IzAgAAQi4CAgAAAC0EAIBtBKEH4jMCAABCMgICAAAALQQAgIkEoQfiMwIAAEIyAgIAAAAtBACAbQShB+IzAgAAQjICAgAAAC0EAIAFBKEH4jMCAABCMgICAAAALQQAgIkEoQfiMwIAAEIyAgIAAAAtBKEEoQfiMwIAAEIuAgIAAAAtBACABQShB+IzAgAAQjICAgAAAC0ERQRFBmJ/AgAAQi4CAgAAAC0EoQShB+IzAgAAQi4CAgAAAC0EoQShB+IzAgAAQi4CAgAAAC0EoQShB+IzAgAAQi4CAgAAAC0EAIAFBKEH4jMCAABCMgICAAAALIB9BEUGon8CAABCLgICAAAALICBBEE0NAEEAIB9BEUG4n8CAABCMgICAAAALIAAgCjsBCCAAIB82AgQgACACNgIAIANBsApqJICAgIAADwtB24zAgABBGkH4jMCAABCOgICAAAALQduMwIAAQRpB+IzAgAAQjoCAgAAAC0HbjMCAAEEaQfiMwIAAEI6AgIAAAAtB24zAgABBGkH4jMCAABCOgICAAAALmgUDBX8BfgJ/I4CAgIAAQRBrIgIkgICAgAACQAJAIAAvAQwiAw0AIAAoAgAgACgCBCABELyAgIAAIQQMAQsgAiABKAIMIgU2AgwgAiABKAIIIgQ2AgggAiABKAIEIgY2AgQgAiABKAIAIgE2AgACQAJAIAApAggiB6ciCEGAgIAIcUUNACAAKAIAIAEgBiAAKAIEKAIMEYGAgIAAgICAgAANASAAIAhBgICA/3lxQbCAgIACciIINgIIIAJCATcCACAGQf//A3EhAUEAIQZBACADIAFrIgEgASADSxshAwsCQCAFRQ0AA0ACQAJAAkACQAJAIAQvAQAOAwABAgALIARBBGooAgAhAQwDCyAEQQJqLwEAIgENAUEBIQEMAgsgBEEIaigCACEBDAELIAFB9v8XaiABQZz/H2pxIAFBmPg3aiABQfCxH2pxc0ERdkEBaiEBC0F/IAYgAWoiASABIAZJGyEGIARBDGohBCAFQX9qIgUNAAsLAkACQCAGIANB//8DcUkNACAAKAIAIAAoAgQgAhC8gICAACEEDAELIAMgBmshCUEAIQRBACEDAkACQAJAIAhBHXZBA3EOBAIAAQACCyAJIQMMAQsgCUH+/wNxQQF2IQMLIAhB////AHEhASAAKAIEIQYgACgCACEFAkADQCAEQf//A3EgA0H//wNxTw0BIARBAWohBCAFIAEgBigCEBGAgICAAICAgIAARQ0ADAMLCyAFIAYgAhC8gICAAA0BIAkgA2tB//8DcSEIQQAhAwNAAkAgA0H//wNxIAhJDQBBACEEDAILQQEhBCADQQFqIQMgBSABIAYoAhARgICAgACAgICAAEUNAAsLIAAgBzcCCAwBC0EBIQQLIAJBEGokgICAgAAgBAvCBAEHfyOAgICAAEEQayIDJICAgIAAAkACQCACKAIEIgRFDQAgACACKAIAIAQgASgCDBGBgICAAICAgIAARQ0AQQEhAgwBCwJAIAIoAgwiBUUNACACKAIIIgQgBUEMbGohBgNAAkACQAJAAkAgBC8BAA4DAAIBAAsCQAJAIAQoAgQiAkHBAEkNACABQQxqKAIAIQUDQAJAIABBpY3AgABBwAAgBRGBgICAAICAgIAARQ0AQQEhAgwJCyACQUBqIgJBwABLDQAMAgsLIAJFDQMgAUEMaigCACEFCyAAQaWNwIAAIAIgBRGBgICAAICAgIAARQ0CQQEhAgwFCyAAIAQoAgQgBCgCCCABQQxqKAIAEYGAgIAAgICAgABFDQFBASECDAQLIAQvAQIhAiADQQA6AAwgA0EANgIIAkACQCACDQAgAyACQTByOgAIQQEhBQwBCyADQQhqIAJB9v8XaiACQZz/H2pxIAJBmPg3aiACQfCxH2pxc0ERdiIHaiIIIAIgAkEKbiIJQQpsa0EwcjoAACAHQQFqIQUgB0UNACAIQX9qIAlBCnBBMHI6AAAgBUECRg0AIAhBfmogAkHkAG5BCnBBMHI6AAAgBUEDRg0AIAhBfWogAkHoB25BCnBBMHI6AAAgBUEERg0AIAhBfGogAkGQzgBuQTByOgAACyAAIANBCGogBSABQQxqKAIAEYGAgIAAgICAgABFDQBBASECDAMLIARBDGoiBCAGRw0ACwtBACECCyADQRBqJICAgIAAIAIL2AUEBX8CfgJ/AX4jgICAgABBgAFrIgMkgICAgAAgAbwiBEH///8DcSIFQYCAgARyIARBAXRB/v//B3EgBEEXdkH/AXEiBhsiB60iCEIBgyEJQQIhCgJAAkACQAJAAkAgBUVBBEEDQQIgBRsgBEGAgID8B3EiBRsgBUGAgID8B0YbDgUEAAECAwQLQQMhCgwDC0EEIQoMAgsgBkHqfmohCyAJp0EBcyEKQgEhDAwBC0KAgIAQIAhCAYYgB0GAgIAERiIFGyEIQgJCASAFGyEMIAmnQQFzIQpB6H5B6X4gBRsgBmohCwsgAyALOwF4IAMgDDcDcCADQgE3A2ggAyAINwNgIAMgCjoAegJAAkACQAJAAkACQCAKQf8BcUEBSw0AQeyLwIAAQQEgBEEASCIKGyEFQeyLwIAAQe2LwIAAIAobIQogBEEfdiEEIANBIGogA0HgAGogA0EPahC5gICAACADKAIgRQ0BIAMgAygCKDYCWCADIAMpAiA3A1AMAgsgCkF+akH/AXEiC0UNAkEBIQpB7IvAgABB7YvAgAAgBEEASCIFG0Hsi8CAAEEBIAUbIAIbIQVBASAEQR92IAIbIQQgA0ECOwEgIAtBAkYNAyADQQM2AiggA0Hxi8CAADYCJCADQSBqIQsMBAsgA0HQAGogA0HgAGogA0EPahC6gICAAAsgCiAFIAIbIQVBASAEIAIbIQQgAyADKAJQIAMoAlQgAy8BWEEBIANBIGoQtoCAgAAgAygCBCEKIAMoAgAhCwwCCyADQQM2AiggA0Hui8CAADYCJCADQQI7ASBBASEFIANBIGohC0EAIQRBASEKDAELIANBATYCMCADQQA7ASwgA0ECNgIoIANB9YvAgAA2AiQgA0EgaiELQQIhCgsgAyAKNgJcIAMgCzYCWCADIAQ2AlQgAyAFNgJQIAAgA0HQAGoQu4CAgAAhBCADQYABaiSAgICAACAEC5wHBQV/An4CfwF+AX8jgICAgABBoAFrIgMkgICAgAAgAbwiBEH///8DcSIFQYCAgARyIARBAXRB/v//B3EgBEEXdkH/AXEiBhsiB60iCEIBgyEJQQIhCgJAAkACQAJAAkAgBUVBBEEDQQIgBRsgBEGAgID8B3EiBRsgBUGAgID8B0YbDgUEAAECAwQLQQMhCgwDC0EEIQoMAgsgBkHqfmohCyAJp0EBcyEKQgEhDAwBC0KAgIAQIAhCAYYgB0GAgIAERiIFGyEIQgJCASAFGyEMIAmnQQFzIQpB6H5B6X4gBRsgBmohCwsgAyALOwGIASADIAw3A4ABIANCATcDeCADIAg3A3AgAyAKOgCKAQJAAkACQAJAAkACQAJAAkACQCAKQf8BcUEBSw0AIANB4ABqIANB8ABqIANBB2oQuYCAgAAgAygCYEUNASADIAMoAmg2ApgBIAMgAykCYDcDkAEMAgsgCkF+akH/AXEiBkUNAkEBIQpB7IvAgABB7YvAgAAgBEEASCIFG0Hsi8CAAEEBIAUbIAIbIQVBASAEQR92IAIbIQsgA0ECOwEYIAZBAkYNAyADQQM2AiAgA0Hxi8CAADYCHAwHCyADQZABaiADQfAAaiADQQdqELqAgIAACyADKAKUASIFRQ0CIAMoApABIgotAABBME0NA0Hsi8CAAEEBIARBAEgiCxshB0Hsi8CAAEHti8CAACALGyELIARBH3YhDSADLgGYASEGIANBATYCICADIAo2AhwgA0ECOwEYAkAgBUF/aiIFDQAgA0EkaiEEQQMhCgwFCyADQTxqIQQgAyAFNgI4IANBAjsBMCADQa+PwIAANgIoIANBAjsBJCADQQE2AiwgAyAKQQFqNgI0QQUhCgwECyADQQM2AiAgA0Hui8CAADYCHCADQQI7ARhBASEFQQAhC0EBIQoMBAsgA0EDNgIgIANB94vAgAA2AhwMAwtByY/AgABBIUGskMCAABCOgICAAAALQfyPwIAAQR9BvJDAgAAQjoCAgAAACyALIAcgAhshBUEBIA0gAhshCyAEQQE7AQwgBEECOwEAIARBAkEBIAZBAUgiAhs2AgggBEHNkMCAAEHMkMCAACACGzYCBCAEIAZBf2oiAiACQR91IgJzIAJrOwEOCyADIAo2AmwgAyALNgJkIAMgBTYCYCADIANBGGo2AmggACADQeAAahC7gICAACEEIANBoAFqJICAgIAAIAQLgTMHBX8CfgZ/BH4FfwF+En8jgICAgABB8A5rIgQkgICAgAAgAbwiBUH///8DcSIGQYCAgARyIAVBAXRB/v//B3EgBUEXdkH/AXEiBxsiCK0iCUIBgyEKQQIhCyADQf//A3EhDAJAAkACQAJAAkACQAJAAkACQCAGRUEEQQNBAiAGGyAFQYCAgPwHcSIGGyAGQYCAgPwHRhsOBQMCAAQBAwtBBCELDAILQoCAgBAgCUIBhiAIQYCAgARGIgsbIQkgCqdBAXMhBkHofkHpfiALGyAHaiENDAMLQQMhCwsgC0F+aiEGIAVBH3YhCwwCCyAHQep+aiENIAqnQQFzIQYLIAZB/wFxQQFNDQEgBUEfdiELIAZBfmohBgsCQAJAAkAgBkH/AXEiCEUNAEEBIQZB7IvAgABB7YvAgAAgCxtB7IvAgABBASALGyACGyELQQEgBUEfdiACGyEHIAhBAkcNASAEQQI7AcwNIANB//8DcQ0CQQEhBiAEQQE2AtQNIARB9IvAgAA2AtANIARBzA1qIQgMBAsgBEEDNgLUDSAEQe6LwIAANgLQDSAEQQI7AcwNQQEhCyAEQcwNaiEIQQAhB0EBIQYMAwsgBEEDNgLUDSAEQfGLwIAANgLQDSAEQQI7AcwNIARBzA1qIQgMAgsgBCAMNgLcDSAEQQA7AdgNQQIhBiAEQQI2AtQNIARB9YvAgAA2AtANIARBzA1qIQgMAQsCQAJAAkACQAJAAkACQAJAAkACQAJAAkBBdEEFIA1BAEgbIA1sIgZBwP0ATw0AIAlCAFENAUGgfyANIAl5IgqnayIHa0HQAGxBsKcFakHOEG0iC0HQAEsNAiAGQQR2Ig5BFWohD0EAIANrQYCAfiADwUF/ShvBIRAgBEEQaiALQQR0IgYpA9CQwIAAQgAgCSAKhkIAEN2AgIAAQgFBQCAHIAYvAdiQwIAAamsiC60iEYYiEkJ/fCITIAQpAxBCP4ggBCkDGHwiCoMiFFANBSAGLwHakMCAACEIIAtBP3EhFQJAIAogEYinIgdBkM4ASQ0AIAdBwIQ9SQ0EAkAgB0GAwtcvSQ0AQQhBCSAHQYCU69wDSSIGGyEWQYDC1y9BgJTr3AMgBhshBgwGC0EGQQcgB0GAreIESSIGGyEWQcCEPUGAreIEIAYbIQYMBQsCQCAHQeQASQ0AQQJBAyAHQegHSSIGGyEWQeQAQegHIAYbIQYMBQtBCkEBIAdBCUsiFhshBgwEC0H6i8CAAEElQaCMwIAAEI6AgIAAAAtB4JrAgABBHEH8msCAABCOgICAAAALIAtB0QBBjJvAgAAQi4CAgAAAC0EEQQUgB0GgjQZJIgYbIRZBkM4AQaCNBiAGGyEGCyAVrSERIBYgCGtBAWrBIhcgEEwNAyALQf//A3EhGCAXIBBrIgvBIA8gCyAPSRsiGUF/aiEVQQAhCwJAA0AgBEEsaiALaiAHIAZuIghBMGo6AAAgByAIIAZsayEHIBUgC0YNAyAWIAtGDQEgC0EBaiELIAZBCkkhCCAGQQpuIQYgCEUNAAtBnJvAgAAQtYCAgAAACyALQQFqIQZBbCAOayELIBhBf2pBP3GtIRpCASEKA0AgCiAaiEIAUg0BIAsgBmpBAUYNAyAEQSxqIAZqIBRCCn4iFCARiKdBMGo6AAAgCkIKfiEKIBQgE4MhFCAZIAZBAWoiBkcNAAsgBEGsCGogBEEsaiAPIBkgFyAQIBQgEiAKELiAgIAADAQLIARBADYCrAgMBAsgBEGsCGogBEEsaiAPIBkgFyAQIAetIBGGIBR8IAatIBGGIBIQuICAgAAMAgsgBiAPQaybwIAAEIuAgIAAAAsgBEGsCGogBEEsaiAPQQAgFyAQIApCCoAgBq0gEYYgEhC4gICAAAsgBCgCrAgiCEUNACAELwG0CCEYIAQoArAIIRcMAQsgBEEBNgLYCSAEIAk3A7gIIARBwAhqQQBBmAH8CwAgBEHkCWpBAEGcAfwLACAEQQE2AuAJIARBATYCgAsgDawgCUJ/fHl9QsKawegEfkKAoc2gtAJ8QiCIpyIGwSEYAkACQCANQQBIDQAgBEG4CGogDRCzgICAABoMAQsgBEHgCWpBACANa0H//wNxELOAgIAAGgsCQAJAIBhBf0oNACAEQbgIakEAIBhrQf//A3EQt4CAgAAaDAELIARB4AlqIAZB//8BcRC3gICAABoLIARBzA1qIARB4AlqQaQB/AoAACAEQcwNakF4aiEWIA8hCANAAkACQAJAAkAgBCgC7A4iBkEoSw0AIAZFDQMgBkECdCIGQXxqIg0NASAEQcwNaiAGaiEGQgAhCQwCC0EAIAZBKEH4jMCAABCMgICAAAALIBYgBmohCyANQQJ2QQFqQf7///8HcSEHQgAhCQNAIAsiBkEEaiILIAlCIIYgCzUCAIQiCUKAlOvcA4AiCj4CACAGIAkgCkKAlOvcA359QiCGIAY1AgCEIglCgJTr3AOAIgo+AgAgCSAKQoCU69wDfn0hCSAGQXhqIQsgB0F+aiIHDQALIA1BBHENAQsgBkF8aiIGIAlCIIYgBjUCAIRCgJTr3AOAPgIACyAIQXdqIghBCUsNAAsCQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkAgCEECdCgC6J/AgABBAXQiC0UNAAJAAkACQAJAAkAgBCgC7A4iBkEoSw0AAkAgBg0AQQAhBgwFCyALrSEJIAZBAnQiBkF8aiIIDQEgBEHMDWogBmohBkIAIQoMAgtBACAGQShB+IzAgAAQjICAgAAACyAIQQJ2QQFqQf7///8HcSELIAYgBEHMDWpqQXhqIQdCACEKA0AgByIGQQRqIgcgCkIghiAHNQIAhCIKIAmAIhQ+AgAgBiAKIBQgCX59QiCGIAY1AgCEIgogCYAiFD4CACAKIBQgCX59IQogBkF4aiEHIAtBfmoiCw0ACyAIQQRxDQELIAZBfGoiBiAKQiCGIAY1AgCEIAmAPgIACyAEKALsDiEGCyAEKALYCSIOIAYgDiAGSxsiG0EoSw0BAkACQCAbDQBBACEbDAELQQAhCEEAIQ0CQAJAAkAgG0EBRg0AIBtBAXEhHCAbQT5xIRdBACEIIARBzA1qIQYgBEG4CGohC0EAIQ0DQCAGIAsoAgAiFiAGKAIAaiIHIAhBAXFqIhU2AgAgBkEEaiIIIAtBBGooAgAiGSAIKAIAaiIIIAcgFkkgFSAHSXJqIgc2AgAgCCAZSSAHIAhJciEIIAtBCGohCyAGQQhqIQYgFyANQQJqIg1HDQALIBxFDQELIARBzA1qIA1BAnQiBmoiCyAEQbgIaiAGaigCACIHIAsoAgBqIgYgCGoiCzYCACAGIAdJDQEgCyAGSQ0BDAILIAhFDQELIBtBKEYNAyAEQcwNaiAbQQJ0akEBNgIAIBtBAWohGwsgBCAbNgLsDiAEKAKACyIdIBsgHSAbSxsiBkEpTw0DIAZBAnQhBiAEQcwNakF8aiELAkACQANAIAZFDQEgCyAGaigCACIHIAZBfGoiBiAEQeAJamooAgAiCEYNAAsgByAITw0AAkAgDg0AQQAhDiAEQQA2AtgJDAILIA5BAnQiDUF8aiIGQQJ2QQFqIgtBA3EhCAJAAkACQCAGQQxPDQBCACEJIARBuAhqIQYMAQsgC0H8////B3EhC0IAIQkgBEG4CGohBgNAIAYgBjUCAEIKfiAJfCIJPgIAIAZBBGoiByAHNQIAQgp+IAlCIIh8Igk+AgAgBkEIaiIHIAc1AgBCCn4gCUIgiHwiCT4CACAGQQxqIgcgBzUCAEIKfiAJQiCIfCIJPgIAIAlCIIghCSAGQRBqIQYgC0F8aiILDQALIAhFDQELIAhBAnQhCwNAIAYgBjUCAEIKfiAJfCIJPgIAIAZBBGohBiAJQiCIIQkgC0F8aiILDQALCwJAIAlQDQAgDkEoRg0HIARBuAhqIA1qIAmnNgIAIA5BAWohDgsgBCAONgLYCQwBCyAYQQFqIRgLQQAhHkEBIRYCQAJAIBjBIgYgEEgiHw0AIBggEGvBIA8gBiAQayAPSRsiFw0BC0EAIRcMEQsgBEGEC2ogBEHgCWpBpAH8CgAAIARBhAtqQQEQs4CAgAAhICAEQagMaiAEQeAJakGkAfwKAAAgBEGoDGpBAhCzgICAACEhIARBzA1qIARB4AlqQaQB/AoAACAEQeAJakF8aiEiIARBhAtqQXxqISMgBEGoDGpBfGohHCAEQcwNakF8aiEbIARBzA1qQQMQs4CAgAAhJCAgKAKgASElICEoAqABISYgJCgCoAEhJ0EAISgCQAJAA0AgKCEpIA5BKU8NCCApQQFqISggDkECdCEHQQAhBgNAIAcgBkYNAyAEQbgIaiAGaiELIAZBBGohBiALKAIARQ0ACyAnIA4gJyAOSxsiKkEpTw0JICpBAnQhBgJAAkADQCAGRQ0BIBsgBmohCyAGQXxqIgYgBEG4CGpqKAIAIgcgCygCACILRg0AC0EAISsgByALSQ0BC0EBIQhBACENAkACQAJAICpBAUYNACAqQQFxISwgKkE+cSEOQQAhDUEBIQggBEG4CGohBiAEQcwNaiELA0AgBiAGKAIAIhYgCygCAEF/c2oiByAIQQFxaiIVNgIAIAZBBGoiCCAIKAIAIhkgC0EEaigCAEF/c2oiCCAHIBZJIBUgB0lyaiIHNgIAIAggGUkgByAISXIhCCALQQhqIQsgBkEIaiEGIA4gDUECaiINRw0ACyAsRQ0BCyAEQbgIaiANQQJ0IgZqIgsgCygCACILICQgBmooAgBBf3NqIgYgCGoiBzYCACAGIAtJDQEgByAGSQ0BDBULIAhFDRQLIAQgKjYC2AlBCCErICohDgsgJiAOICYgDksbIipBKU8NCiAqQQJ0IQYCQAJAA0AgBkUNASAcIAZqIQsgBkF8aiIGIARBuAhqaigCACIHIAsoAgAiC0YNAAsgByALTw0AIA4hKgwBCwJAICpFDQBBASEIQQAhDQJAAkAgKkEBRg0AICpBAXEhLCAqQT5xIQ5BACENQQEhCCAEQbgIaiEGIARBqAxqIQsDQCAGIAYoAgAiFiALKAIAQX9zaiIHIAhBAXFqIhU2AgAgBkEEaiIIIAgoAgAiGSALQQRqKAIAQX9zaiIIIAcgFkkgFSAHSXJqIgc2AgAgCCAZSSAHIAhJciEIIAtBCGohCyAGQQhqIQYgDiANQQJqIg1HDQALICxFDQELIARBuAhqIA1BAnQiBmoiCyALKAIAIgsgISAGaigCAEF/c2oiBiAIaiIHNgIAIAYgC0kNASAHIAZJDQEMFAsgCEUNEwsgBCAqNgLYCSArQQRyISsLICUgKiAlICpLGyIsQSlPDQsgLEECdCEGAkACQANAIAZFDQEgIyAGaiELIAZBfGoiBiAEQbgIamooAgAiByALKAIAIgtGDQALIAcgC08NACAqISwMAQsCQCAsRQ0AQQEhCEEAIQ0CQAJAICxBAUYNACAsQQFxISogLEE+cSEOQQAhDUEBIQggBEG4CGohBiAEQYQLaiELA0AgBiAGKAIAIhYgCygCAEF/c2oiByAIQQFxaiIVNgIAIAZBBGoiCCAIKAIAIhkgC0EEaigCAEF/c2oiCCAHIBZJIBUgB0lyaiIHNgIAIAggGUkgByAISXIhCCALQQhqIQsgBkEIaiEGIA4gDUECaiINRw0ACyAqRQ0BCyAEQbgIaiANQQJ0IgZqIgsgCygCACILICAgBmooAgBBf3NqIgYgCGoiBzYCACAGIAtJDQEgByAGSQ0BDBMLIAhFDRILIAQgLDYC2AkgK0ECaiErCyAdICwgHSAsSxsiDkEpTw0MIA5BAnQhBgJAAkADQCAGRQ0BICIgBmohCyAGQXxqIgYgBEG4CGpqKAIAIgcgCygCACILRg0ACyAHIAtPDQAgLCEODAELAkAgDkUNAEEBIQhBACENAkACQCAOQQFGDQAgDkEBcSEsIA5BPnEhKkEAIQ1BASEIIARBuAhqIQYgBEHgCWohCwNAIAYgBigCACIWIAsoAgBBf3NqIgcgCEEBcWoiFTYCACAGQQRqIgggCCgCACIZIAtBBGooAgBBf3NqIgggByAWSSAVIAdJcmoiBzYCACAIIBlJIAcgCElyIQggC0EIaiELIAZBCGohBiAqIA1BAmoiDUcNAAsgLEUNAQsgBEG4CGogDUECdCIGaiILIAsoAgAiCyAEQeAJaiAGaigCAEF/c2oiBiAIaiIHNgIAIAYgC0kNASAHIAZJDQEMEgsgCEUNEQsgBCAONgLYCSArQQFqISsLICkgD0YNASAEQSxqIClqICtBMGo6AAACQAJAIA4NAEEAIQ4MAQsgDkECdCINQXxqIgZBAnZBAWoiC0EDcSEIAkACQAJAIAZBDE8NAEIAIQkgBEG4CGohBgwBCyALQfz///8HcSELQgAhCSAEQbgIaiEGA0AgBiAGNQIAQgp+IAl8Igk+AgAgBkEEaiIHIAc1AgBCCn4gCUIgiHwiCT4CACAGQQhqIgcgBzUCAEIKfiAJQiCIfCIJPgIAIAZBDGoiByAHNQIAQgp+IAlCIIh8Igk+AgAgCUIgiCEJIAZBEGohBiALQXxqIgsNAAsgCEUNAQsgCEECdCELA0AgBiAGNQIAQgp+IAl8Igk+AgAgBkEEaiEGIAlCIIghCSALQXxqIgsNAAsLIAlQDQAgDkEoRg0OIARBuAhqIA1qIAmnNgIAIA5BAWohDgsgBCAONgLYCSAoIBdHDQALQQAhFgwSCyAPIA9ByJ7AgAAQi4CAgAAACyAXIA9LDQsgFyApRg0RIBcgKWsiBkUNESAEQSxqIClqQTAgBvwLAAwRC0HAjMCAAEEbQfiMwIAAEI6AgIAAAAtBACAbQShB+IzAgAAQjICAgAAAC0EoQShB+IzAgAAQi4CAgAAAC0EAIAZBKEH4jMCAABCMgICAAAALQShBKEH4jMCAABCLgICAAAALQQAgDkEoQfiMwIAAEIyAgIAAAAtBACAqQShB+IzAgAAQjICAgAAAC0EAICpBKEH4jMCAABCMgICAAAALQQAgLEEoQfiMwIAAEIyAgIAAAAtBACAOQShB+IzAgAAQjICAgAAAC0EoQShB+IzAgAAQi4CAgAAACyApIBcgD0HYnsCAABCMgICAAAALQduMwIAAQRpB+IzAgAAQjoCAgAAAC0HbjMCAAEEaQfiMwIAAEI6AgIAAAAtB24zAgABBGkH4jMCAABCOgICAAAALQduMwIAAQRpB+IzAgAAQjoCAgAAACwJAAkACQAJAAkACQCAdRQ0AIB1BAnQiDUF8aiIGQQJ2QQFqIgtBA3EhCAJAAkACQCAGQQxPDQBCACEJIARB4AlqIQYMAQsgC0H8////B3EhC0IAIQkgBEHgCWohBgNAIAYgBjUCAEIFfiAJfCIJPgIAIAZBBGoiByAHNQIAQgV+IAlCIIh8Igk+AgAgBkEIaiIHIAc1AgBCBX4gCUIgiHwiCT4CACAGQQxqIgcgBzUCAEIFfiAJQiCIfCIJPgIAIAlCIIghCSAGQRBqIQYgC0F8aiILDQALIAhFDQELIAhBAnQhCwNAIAYgBjUCAEIFfiAJfCIJPgIAIAZBBGohBiAJQiCIIQkgC0F8aiILDQALCwJAIAlQRQ0AIB0hHgwBCyAdQShGDQEgBEHgCWogDWogCac2AgAgHUEBaiEeCyAEIB42AoALIB4gDiAeIA5LGyIGQSlPDQEgBkECdCEGIARBuAhqQXxqIQggBEHgCWpBfGohDQJAAkADQCAGRQ0BIA0gBmohCyAIIAZqIQcgBkF8aiEGIAcoAgAiByALKAIAIgtGDQALIAcgC0sgByALSWtB/wFxDgIAAQYLAkAgFkUNAEEAIRcMBwsgF0F/aiIGIA9PDQMgBEEsaiAGai0AAEEBcUUNBQsgFyAPSw0DIARBLGogF2ohByAXIQYCQANAIAYiC0UNASALQX9qIgYgBEEsamotAABBOUYNAAsgBEEsaiAGaiIGIAYtAABBAWo6AAAgFyALayIGRQ0FIARBLGogC2pBMCAG/AsADAULQTEhBgJAIBYNACAEQTE6ACxBMCEGIBdBf2oiC0UNACAEQS1qQTAgC/wLAAsgGEEBaiEYIB8NBCAXIA9PDQQgByAGOgAAIBdBAWohFwwEC0EoQShB+IzAgAAQi4CAgAAAC0EAIAZBKEH4jMCAABCMgICAAAALIAYgD0GYnsCAABCLgICAAAALQQAgFyAPQaiewIAAEIyAgIAAAAsgFyAPTQ0AQQAgFyAPQbiewIAAEIyAgIAAAAsgBEEsaiEIC0Hsi8CAAEHti8CAACAFQQBIIgYbQeyLwIAAQQEgBhsgAhshC0EBIAVBH3YgAhshBwJAIBjBIBBMDQAgBEEIaiAIIBcgGCAMIARBzA1qELaAgIAAIAQoAgwhBiAEKAIIIQgMAQtBAiEGIARBAjsBzA0CQCADQf//A3ENAEEBIQYgBEEBNgLUDSAEQfSLwIAANgLQDSAEQcwNaiEIDAELIAQgDDYC3A0gBEEAOwHYDSAEQQI2AtQNIARB9YvAgAA2AtANIARBzA1qIQgLIAQgBjYCtAwgBCAINgKwDCAEIAc2AqwMIAQgCzYCqAwgACAEQagMahC7gICAACEGIARB8A5qJICAgIAAIAYLyQEBAn8jgICAgABBEGsiBCSAgICAAEEAQQAoArSswIAAIgVBAWo2ArSswIAAAkAgBUEASA0AAkACQEEALQCsrMCAAA0AQQBBAToArKzAgABBAEEAKAKorMCAAEEBajYCqKzAgABBACgCsKzAgAAiBUF/TA0CIAVBAWoiASAFTg0BELSAgIAAAAsgBEEIaiAAIAEoAhgRgoCAgACAgICAAAwBC0EAIAFBf2o2ArCswIAAQQBBADoArKzAgAAgAkUNABDBgICAAAALAAsDAAALCQAgAEEANgIACx4AIABBACkCyKLAgAA3AgggAEEAKQLAosCAADcCAAsOAEEAQQE6ALiswIAAAAsLACAAEMaAgIAAAAuMAQEDfyOAgICAAEEQayIBJICAgIAAAkAgACgCACICKAIEIgNBAXFFDQAgAigCACECIAEgA0EBdjYCBCABIAI2AgAgAUGIosCAACAAKAIIIgAtAAggAC0ACRDAgICAAAALIAFBfzYCACABIAA2AgwgAUGkosCAACAAKAIIIgAtAAggAC0ACRDAgICAAAALhAEBA38CQAJAAkAgACgCACIBQQFIDQAgACgCBCICQXxqKAIAIgBBeHEiA0EEQQggAEEDcSIAGyABakkNAQJAIABFDQAgAyABQSdqSw0DCyACEI2AgIAACw8LQeCiwIAAQS5BkKPAgAAQjoCAgAAAC0Ggo8CAAEEuQdCjwIAAEI6AgIAAAAtUAAJAIAAoAgBBf0YNACABKAIAIAAoAgQgACgCCCABKAIEKAIMEYGAgIAAgICAgAAPCyABKAIAIAEoAgQgACgCDCgCACIAKAIAIAAoAgQQrICAgAAL/QECAn8BfiOAgICAAEEgayICJICAgIAAAkAgASgCAEF/Rw0AIAEoAgwhAyACQQA2AhggAkKAgICAEDcCECACQRBqQfChwIAAIAMoAgAiAygCACADKAIEEKyAgIAAGiACIAIoAhgiAzYCCCACIAIpAhAiBDcDACABIAM2AgggASAENwIACyABKAIIIQMgAUEANgIIIAEpAgAhBCABQoCAgIAQNwIAIAIgAzYCGCACIAQ3AxACQEEMEIiAgIAAIgENAEEEQQwQlICAgAAACyABIAIoAhg2AgggASACKQMQNwIAIABBrKTAgAA2AgQgACABNgIAIAJBIGokgICAgAALoQECAn8BfiOAgICAAEEgayICJICAgIAAAkAgASgCAEF/Rw0AIAEoAgwhAyACQQA2AhwgAkKAgICAEDcCFCACQRRqQfChwIAAIAMoAgAiAygCACADKAIEEKyAgIAAGiACIAIoAhwiAzYCECACIAIpAhQiBDcDCCABIAM2AgggASAENwIACyAAQaykwIAANgIEIAAgATYCACACQSBqJICAgIAAC58BAQF/I4CAgIAAQRBrIgMkgICAgAACQCACIAFqIgEgAk8NAEEAQQAQhoCAgAAACyADQQRqIAAoAgAiAiAAKAIEIAEgAkEBdCICIAEgAksbIgJBCCACQQhLGyICEMyAgIAAAkAgAygCBEEBRw0AIAMoAgggAygCDBCGgICAAAALIAMoAgghASAAIAI2AgAgACABNgIEIANBEGokgICAgAALgQEBAX9BACEEAkACQCADQQBODQBBASEBQQQhAgwBCwJAAkAgAUUNACACIAFBASADEIeAgIAAIQQMAQsgAxCIgICAACEECwJAAkAgBA0AQQEhASAAQQE2AgQMAQsgACAENgIEQQAhAQtBCCECIAMhBAsgACACaiAENgIAIAAgATYCAAuCAQEDfwJAAkACQCAAKAIAIgFFDQAgACgCBCICQXxqKAIAIgBBeHEiA0EEQQggAEEDcSIAGyABakkNAQJAIABFDQAgAyABQSdqSw0DCyACEI2AgIAACw8LQeCiwIAAQS5BkKPAgAAQjoCAgAAAC0Ggo8CAAEEuQdCjwIAAEI6AgIAAAAseACAAQQApAtiiwIAANwIIIABBACkC0KLAgAA3AgALWgEBfwJAAkACQCACIAAoAgAgACgCCCIDa00NACAAIAMgAhDLgICAACAAKAIIIQMMAQsgAkUNAQsgAkUNACAAKAIEIANqIAEgAvwKAAALIAAgAyACajYCCEEAC5oCAQZ/IAAoAgghAgJAAkAgAUGAAU8NAEEBIQMMAQsCQCABQYAQTw0AQQIhAwwBC0EDQQQgAUGAgARJGyEDCwJAIAMgACgCACACa00NACAAIAIgAxDLgICAAAsgACgCBCACaiEEAkACQCABQYABSQ0AIAFBP3FBgH9yIQUgAUEGdiEGAkAgAUGAEE8NACAEIAU6AAEgBCAGQcABcjoAAAwCCyABQQx2IQcgBkE/cUGAf3IhBgJAIAFB//8DSw0AIAQgBToAAiAEIAY6AAEgBCAHQeABcjoAAAwCCyAEIAU6AAMgBCAGOgACIAQgB0E/cUGAf3I6AAEgBCABQRJ2QXByOgAADAELIAQgAToAAAsgACADIAJqNgIIQQALFAAgAEHwocCAACABIAIQrICAgAALJAAgASgCACAAKAIAIAAoAgQgASgCBCgCDBGBgICAAICAgIAAC0wBAn8gASgCBCECIAEoAgAhAwJAQQgQiICAgAAiAQ0AQQRBCBCUgICAAAALIAEgAjYCBCABIAM2AgAgAEGcpMCAADYCBCAAIAE2AgALFAAgAEGcpMCAADYCBCAAIAE2AgALDAAgACABKQIANwMAC8MCAQR/QR8hAgJAIAFBgICACE8NACABQSYgAUEIdmciAmt2QQFxIAJBAXRyQT5zIQILIABCADcCECAAIAI2AhwgAkECdEHYqMCAAGohAwJAQQAoAvSrwIAAQQEgAnQiBHENACADIAA2AgAgACADNgIYIAAgADYCDCAAIAA2AghBAEEAKAL0q8CAACAEcjYC9KvAgAAPCwJAAkACQCADKAIAIgQoAgRBeHEgAUcNACAEIQIMAQsgAUEAQRkgAkEBdmsgAkEfRht0IQMDQCAEIANBHXZBBHFqIgUoAhAiAkUNAiADQQF0IQMgAiEEIAIoAgRBeHEgAUcNAAsLIAIoAggiAyAANgIMIAIgADYCCCAAQQA2AhggACACNgIMIAAgAzYCCA8LIAVBEGogADYCACAAIAQ2AhggACAANgIMIAAgADYCCAsNACAAIAEQxICAgAAAC68EAgR/A30jgICAgABBEGshASAAvCICQR92IQMCQAJAAkACQAJAAkACQCACQf////8HcSIEQdDYupUESQ0AAkAgBEGAgID8B00NACAADwsCQCAEQZfkxZUESw0AIAJBf0oNAiABQwAAgIAgAJU4AgggASoCCBoMAgsCQCACQX9KDQAgAUMAAICAIACVOAIIIAEqAggaQwAAAAAhBSAEQbTjv5YETQ0CDAcLIABDAAAAf5QPCwJAIARBmOTF9QNLDQAgBEGAgIDIA00NAkEAIQRDAAAAACEGIAAhBQwFCyAEQZKrlPwDTQ0CCyAAQzuquD+UIANBAnQqAuCkwIAAkvwAIQQMAgsgASAAQwAAAH+SOAIMIAEqAgwaIABDAACAP5IPCyADQQFzIANrIQQLIAAgBLIiBUMAcjG/lJIiACAFQ46+vzWUIgaTIQULIAAgBSAFIAUgBZQiByAHQxVSNbuUQ4+qKj6SlJMiB5RDAAAAQCAHk5UgBpOSQwAAgD+SIQUgBEUNAAJAAkACQAJAIARB/wBKDQAgBEGCf04NAyAFQwAAgAyUIQUgBEGbfk0NASAEQeYAaiEEDAMLIAVDAAAAf5QhBSAEQf4BSw0BIARBgX9qIQQMAgsgBUMAAIAMlCEFIARBtn0gBEG2fUsbQcwBaiEEDAELIAVDAAAAf5QhBSAEQf0CIARB/QJJG0GCfmohBAsgBSAEQRd0QYCAgPwDakGAgID8B3G+lCEFCyAFCwoAIAAQ2ICAgAALryIICX8BfAp/AXwIfwF8BH8DfCOAgICAAEGwBGsiBiSAgICAACAGQgA3A5gBIAZCADcDkAEgBkIANwOIASAGQgA3A4ABIAZCADcDeCAGQgA3A3AgBkIANwNoIAZCADcDYCAGQgA3A1ggBkIANwNQIAZCADcDSCAGQgA3A0AgBkIANwM4IAZCADcDMCAGQgA3AyggBkIANwMgIAZCADcDGCAGQgA3AxAgBkIANwMIIAZCADcDACAGQgA3A7gCIAZCADcDsAIgBkIANwOoAiAGQgA3A6ACIAZCADcDmAIgBkIANwOQAiAGQgA3A4gCIAZCADcDgAIgBkIANwP4ASAGQgA3A/ABIAZCADcD6AEgBkIANwPgASAGQgA3A9gBIAZCADcD0AEgBkIANwPIASAGQgA3A8ABIAZCADcDuAEgBkIANwOwASAGQgA3A6gBIAZCADcDoAEgBkIANwPYAyAGQgA3A9ADIAZCADcDyAMgBkIANwPAAyAGQgA3A7gDIAZCADcDsAMgBkIANwOoAyAGQgA3A6ADIAZCADcDmAMgBkIANwOQAyAGQgA3A4gDIAZCADcDgAMgBkIANwP4AiAGQgA3A/ACIAZCADcD6AIgBkIANwPgAiAGQgA3A9gCIAZCADcD0AIgBkIANwPIAiAGQgA3A8ACIAZB4ANqQQBB0AD8CwAgBUECdCgC6KTAgAAiByABQX9qIghqIQkgBEF9akEYbSIKQQAgCkEAShsiCyAIayEMIAtBAnQgAUECdGtB/KTAgABqIQ0gBiEKQQAhDgNAAkACQCAMIA5qQQBODQBEAAAAAAAAAAAhDwwBCyANKAIAtyEPCyAKIA85AwAgCkEIaiEKIA1BBGohDSAOQQFqIg4gCU0NAAsgAUEBcSEQQQAgAUF+cWshCSABQQN0IAZqQXBqIRFBACEMA0BEAAAAAAAAAAAhDwJAAkACQCAIDQBBACEKDAELQQAhDSARIQogACEOA0AgDyAOKwMAIApBCGorAwCioCAOQQhqKwMAIAorAwCioCEPIApBcGohCiAOQRBqIQ4gCSANQX5qIg1HDQALIBBFDQFBACANayEKCyAPIAAgCkEDdGorAwAgBiAMIAhqIAprQQN0aisDAKKgIQ8LIAZBwAJqIAxBA3RqIA85AwAgEUEIaiERIAxBAWoiDCAHTQ0AC0QAAAAAAADwf0QAAAAAAADgfyAEIAtBaGxqIhJBaGoiE0H+D0siFBtEAAAAAAAAAABEAAAAAAAAYAMgE0G5cEkiFRtEAAAAAAAA8D8gE0GCeEgiFhsgE0H/B0oiFxsgE0H9FyATQf0XSRtBgnBqIBJB6XdqIBQbIhggE0HwaCATQfBoSxtBkg9qIBJBsQdqIBUbIhkgEyAWGyAXG0H/B2qtQjSGv6IhGiABQQFxIRtBACABQX5xayEJIAZB4ANqQXxqIhwgB0ECdGohHUEvIBJrQR9xIR5BMCASa0EfcSEfIAZBeGohICAGQcACakF4aiEhIBNBf2ohIiAHIQwCQANAIAZBwAJqIAwiEEEDdCIKaisDACEPAkAgEEUNACAGQeADaiEOA0AgDiAPIA9EAAAAAAAAcD6i/AK3IiNEAAAAAAAAcMGioPwCNgIAICEgCmorAwAgI6AhDyAOQQRqIQ4gCkF4aiIKDQALCwJAAkACQCAXDQAgFg0BIBMhCgwCCyAPRAAAAAAAAOB/oiIPRAAAAAAAAOB/oiAPIBQbIQ8gGCEKDAELIA9EAAAAAAAAYAOiIg9EAAAAAAAAYAOiIA8gFRshDyAZIQoLIA8gCkH/B2qtQjSGv6IiDyAPRAAAAAAAAMA/opxEAAAAAAAAIMCioCIPIA/8AiIkt6EhDwJAAkACQAJAAkACQCATQQBKIiUNAAJAIBMNACAGQeADaiAQQQJ0akF8aigCAEEXdSEmDAILQQIhJkEAIScgD0QAAAAAAADgP2ZFDQUMAgsgBkHgA2ogEEECdGpBfGoiCiAKKAIAIgogCiAfdSIKIB90ayIONgIAIA4gHnUhJiAKICRqISQLICZBAUgNAQtBASEOAkAgEEUNAEEAIQ1BACEMAkAgEEEBRg0AIBBBAXEhJyAQQR5xIQRBACENIAZB4ANqIQpBACEMA0AgCigCACEOAkACQAJAAkAgDEUNAEH///8HIQwMAQsgDkUNAUGAgIAIIQwLIAogDCAOazYCAEEAIQwMAQtBASEMCyAKQQRqIhEoAgAhDgJAAkACQAJAIAwNAEH///8HIQwMAQsgDkUNAUGAgIAIIQwLIBEgDCAOazYCAEEBIQxBACEODAELQQAhDEEBIQ4LIApBCGohCiAEIA1BAmoiDUcNAAsgJ0UNAQsgBkHgA2ogDUECdGoiDSgCACEKAkACQCAMRQ0AQf///wchDgwBC0EBIQ4gCkUNAUGAgIAIIQ4LIA0gDiAKazYCAEEAIQ4LAkAgJUUNAEH///8DIQoCQAJAICIOAgEAAgtB////ASEKCyAGQeADaiAQQQJ0akF8aiINIA0oAgAgCnE2AgALICRBAWohJCAmQQJGDQELICYhJwwBC0QAAAAAAADwPyAPoSIPIA8gGqEgDhshD0ECIScLAkAgD0QAAAAAAAAAAGINACAdIQogECEMAkAgByAQQX9qIg5LDQAgHCAQQQJ0aiEKQQAhDQJAA0AgCigCACANciENIA5FDQEgCkF8aiEKIAcgDkF/aiIOTQ0ACwsgHSEKIBAhDCANRQ0AIAZB4ANqIBBBAnRqQXxqIQoDQCAQQX9qIRAgE0FoaiETIAooAgAhDiAKQXxqIQogDkUNAAwECwsDQCAMQQFqIQwgCigCACEOIApBfGohCiAORQ0ACyAQIAxPDQEgEEEBaiEKICAgASAQakEDdGohBANAIAYgECABaiIQQQN0aiAKIhEgC2pBAnQoAvikwIAAtzkDAAJAAkACQCAIDQBBACEKRAAAAAAAAAAAIQ8MAQtEAAAAAAAAAAAhD0EAIQ0gBCEKIAAhDgNAIA8gDisDACAKQQhqKwMAoqAgDkEIaisDACAKKwMAoqAhDyAKQXBqIQogDkEQaiEOIAkgDUF+aiINRw0ACyAbRQ0BQQAgDWshCgsgDyAAIApBA3RqKwMAIAYgECAKa0EDdGorAwCioCEPCyAGQcACaiARQQN0aiAPOQMAIARBCGohBCARIRAgEUEBaiIKIAxNDQAMAgsLCwJAAkACQAJAQQAgE2siCkH/B0oNACAKQYJ4Tg0DIA9EAAAAAAAAYAOiIQ8gCkG4cE0NAUHJByATayEKDAMLIA9EAAAAAAAA4H+iIQ8gCkH+D0sNAUGBeCATayEKDAILIA9EAAAAAAAAYAOiIQ8gCkHwaCAKQfBoSxtBkg9qIQoMAQsgD0QAAAAAAADgf6IhDyAKQf0XIApB/RdJG0GCcGohCgsCQCAPIApB/wdqrUI0hr+iIg9EAAAAAAAAcEFmDQAgBkHgA2ogEEECdGogD/wCNgIADAELIAZB4ANqIBBBAWoiCkECdGogD0QAAAAAAABwPqL8AiIONgIAIAZB4ANqIBBBAnRqIA8gDrdEAAAAAAAAcMGioPwCNgIAIAohECASIRMLAkACQAJAAkAgE0H/B0oNACATQYJ4SA0BRAAAAAAAAPA/IQ8MAwsgE0H+D0sNASATQYF4aiETRAAAAAAAAOB/IQ8MAgsCQCATQbhwTQ0AIBNByQdqIRNEAAAAAAAAYAMhDwwCCyATQfBoIBNB8GhLG0GSD2ohE0QAAAAAAAAAACEPDAELIBNB/RcgE0H9F0kbQYJwaiETRAAAAAAAAPB/IQ8LIA8gE0H/B2qtQjSGv6IhDwJAAkAgEEEBcUUNACAQIQ0MAQsgBkHAAmogEEEDdGogDyAGQeADaiAQQQJ0aigCALeiOQMAIA9EAAAAAAAAcD6iIQ8gEEF/aiENCwJAIBBFDQAgDUECdCAGQeADampBfGohCiANQQN0IAZBwAJqakF4aiEOA0AgDiAPRAAAAAAAAHA+oiIjIAooAgC3ojkDACAOQQhqIA8gCkEEaigCALeiOQMAIApBeGohCiAOQXBqIQ4gI0QAAAAAAABwPqIhDyANQX5qIg1Bf0cNAAsLIBBBAWohISAGQcACaiAQQQN0aiEJIBAhCgNAAkACQAJAIAcgECAKIhFrIgQgByAESRsiAA0ARAAAAAAAAAAAIQ9BACEODAELIABBAWpBfnEhDEQAAAAAAAAAACEPQQAhCkEAIQ4DQCAPIApBgKfAgABqKwMAIAkgCmoiDSsDAKKgIApBiKfAgABqKwMAIA1BCGorAwCioCEPIApBEGohCiAMIA5BAmoiDkcNAAsgAEEBcQ0BCyAPIA5BA3QrA4CnwIAAIAZBwAJqIA4gEWpBA3RqKwMAoqAhDwsgBkGgAWogBEEDdGogDzkDACAJQXhqIQkgEUF/aiEKIBENAAsCQAJAAkACQCAFDgQBAgIAAQtEAAAAAAAAAAAhKAJAIBBFDQAgECEOAkAgEEEBcUUNACAGQaABaiAQQQN0aiIKQXhqIg4gDisDACIPIAorAwAiI6AiGjkDACAKICMgDyAaoaA5AwAgEEF/aiEOCyAQQQFGDQAgDkEDdCAGQaABampBcGohCgNAIAogCisDACIjIApBCGoiDSsDACIaIApBEGoiCSsDACIpoCIPoCIqOQMAIAkgKSAaIA+hoDkDACANIA8gIyAqoaA5AwAgCkFwaiEKIA5BfmoiDg0ACyAQQQFGDQAgEEEDdCAGQaABampBeGohCiAQIQ4DQCAKIAorAwAiDyAKQQhqIg0rAwAiI6AiGjkDACANICMgDyAaoaA5AwAgCkF4aiEKIA5BAkshDSAOQX9qIQ4gDQ0ACyAGQaABaiAQQQN0aiEKRAAAAAAAAAAAISgDQCAoIAorAwCgISggEEECSyEOIApBeGohCiAQQX9qIRAgDg0ACwsgBisDoAEhDwJAICcNACACIA85AwAgAiAoOQMQIAIgBisDqAE5AwgMAwsgAiAPmjkDACACICiaOQMQIAIgBisDqAGaOQMIDAILAkACQCAhQQNxIg0NAEQAAAAAAAAAACEPIBAhDgwBCyAGQaABaiAQQQN0aiEKRAAAAAAAAAAAIQ8gECEOA0AgDkF/aiEOIA8gCisDAKAhDyAKQXhqIQogDUF/aiINDQALCwJAIBBBA0kNACAOQQN0IAZBoAFqakFoaiEKA0AgDyAKQRhqKwMAoCAKQRBqKwMAoCAKQQhqKwMAoCAKKwMAoCEPIApBYGohCiAOQXxqIg5Bf0cNAAsLIAIgD5ogDyAnGzkDAAwBCwJAAkAgIUEDcSINDQBEAAAAAAAAAAAhDyAQIQ4MAQsgBkGgAWogEEEDdGohCkQAAAAAAAAAACEPIBAhDgNAIA5Bf2ohDiAPIAorAwCgIQ8gCkF4aiEKIA1Bf2oiDQ0ACwsCQCAQQQNJDQAgDkEDdCAGQaABampBaGohCgNAIA8gCkEYaisDAKAgCkEQaisDAKAgCkEIaisDAKAgCisDAKAhDyAKQWBqIQogDkF8aiIOQX9HDQALCyACIA+aIA8gJxs5AwAgBisDoAEgD6EhDwJAIBBFDQAgEEEDcSEOQQEhCgJAIBBBf2pBA0kNACAQQXxxIQkgBkGgAWpBIGohCkEAIQ0DQCAPIApBaGorAwCgIApBcGorAwCgIApBeGorAwCgIAorAwCgIQ8gCkEgaiEKIAkgDUEEaiINRw0ACyAORQ0BIA1BAWohCgsgBkGgAWogCkEDdGohCgNAIA8gCisDAKAhDyAKQQhqIQogDkF/aiIODQALCyACIA+aIA8gJxs5AwgLIAZBsARqJICAgIAAICRBB3EL1goGAX8BfAJ/AXwBfwF8I4CAgIAAQRBrIgEkgICAgAAgALshAgJAAkACQAJAIAC8IgNB/////wdxIgRB25+k+gNJDQACQCAEQdKn7YMESQ0AAkAgBEHW44iHBEkNAAJAAkACQAJAAkAgBEH////7B0sNACABQgA3AwgCQAJAIARB2p+k7gRLDQAgAiACRIPIyW0wX+Q/okQAAAAAAAA4Q6BEAAAAAAAAOMOgIgVEAAAAUPsh+b+ioCAFRGNiGmG0EFG+oqAhAiAF/AIhBAwBCyABIAQgBEEXdkHqfmoiBkEXdGu+uzkDACABQQEgAUEIakEBIAZBABDagICAACEEAkAgA0EASA0AIAErAwghAgwBC0EAIARrIQQgASsDCJohAgsgBEEDcQ4EAgMEAQILIAAgAJMhAAwJCyACIAIgAqIiBaIiByAFIAWioiAFRKdGO4yHzcY+okR058ri+QAqv6CiIAIgByAFRLL7bokQEYE/okR3rMtUVVXFv6CioKC2IQAMCAsgAiACoiICRIFeDP3//9+/okQAAAAAAADwP6AgAiACoiIFREI6BeFTVaU/oqAgAiAFoiACRGlQ7uBCk/k+okQnHg/oh8BWv6CioLYhAAwHCyACIAKiIgUgApqiIgcgBSAFoqIgBUSnRjuMh83GPqJEdOfK4vkAKr+goiAHIAVEsvtuiRARgT+iRHesy1RVVcW/oKIgAqGgtiEADAYLIAIgAqIiAkSBXgz9///fv6JEAAAAAAAA8D+gIAIgAqIiBURCOgXhU1WlP6KgIAIgBaIgAkRpUO7gQpP5PqJEJx4P6IfAVr+goqC2jCEADAULIARB39u/hQRLDQICQCADQX9MDQAgAkTSITN/fNkSwKAiBSAFIAWiIgKiIgcgAiACoqIgAkSnRjuMh83GPqJEdOfK4vkAKr+goiAFIAcgAkSy+26JEBGBP6JEd6zLVFVVxb+goqCgtiEADAULRNIhM3982RLAIAKhIgUgBSAFoiICoiIHIAIgAqKiIAJEp0Y7jIfNxj6iRHTnyuL5ACq/oKIgBSAHIAJEsvtuiRARgT+iRHesy1RVVcW/oKKgoLYhAAwECyAEQeOX24AESw0CAkAgA0F/TA0ARBgtRFT7Ifk/IAKhIgUgBSAFoiICoiIHIAIgAqKiIAJEp0Y7jIfNxj6iRHTnyuL5ACq/oKIgBSAHIAJEsvtuiRARgT+iRHesy1RVVcW/oKKgoLYhAAwECyACRBgtRFT7Ifk/oCIFIAUgBaIiAqIiByACIAKioiACRKdGO4yHzcY+okR058ri+QAqv6CiIAUgByACRLL7bokQEYE/okR3rMtUVVXFv6CioKC2IQAMAwsCQCAEQYCAgMwDSQ0AIAIgAqIiAkSBXgz9///fv6JEAAAAAAAA8D+gIAIgAqIiBURCOgXhU1WlP6KgIAIgBaIgAkRpUO7gQpP5PqJEJx4P6IfAVr+goqC2IQAMAwsgASAAQwAAgHuSOAIIIAEqAggaQwAAgD8hAAwCC0QYLURU+yEZwEQYLURU+yEZQCADQX9KGyACoCICIAKiIgJEgV4M/f//37+iRAAAAAAAAPA/oCACIAKiIgVEQjoF4VNVpT+ioCACIAWiIAJEaVDu4EKT+T6iRCceD+iHwFa/oKKgtiEADAELRBgtRFT7IQnARBgtRFT7IQlAIANBf0obIAKgIgIgAqIiAkSBXgz9///fv6JEAAAAAAAA8D+gIAIgAqIiBURCOgXhU1WlP6KgIAIgBaIgAkRpUO7gQpP5PqJEJx4P6IfAVr+goqC2jCEACyABQRBqJICAgIAAIAALCgAgABDbgICAAAtuAQZ+IAAgA0L/////D4MiBSABQv////8PgyIGfiIHIANCIIgiCCAGfiIGIAUgAUIgiCIJfnwiBUIghnwiCjcDACAAIAggCX4gBSAGVK1CIIYgBUIgiIR8IAogB1StfCAEIAF+IAMgAn58fDcDCAuCAgICfwJ9AkACQAJAAkAgALwiAUGAgIAESA0AIAFB////+wdLDQNBgX8hAiABQYCAgPwDRw0BQwAAAAAPCwJAIABDAAAAAFwNAEMAAID/DwsgAUEASA0BIABDAAAATJS8IQFB6H4hAgsgAUGN9qsCaiIBQRd2IAJqsiIDQ4BxMT+UIAFB////A3FB84nU+QNqvkMAAIC/kiIAIAND0fcXN5QgACAAQwAAAECSlSIDIAAgAEMAAAA/lJQiBCADIAOUIgAgACAAlCIAQ+7pkT6UQ6qqKj+SlCAAIABDJp54PpRDE87MPpKUkpKUkiAEk5KSDwsgACAAk0MAAAAAlSEACyAAC+YKBgF/AXwCfwF8AX8BfCOAgICAAEEQayIBJICAgIAAIAC7IQICQAJAIAC8IgNB/////wdxIgRB25+k+gNJDQACQCAEQdKn7YMESQ0AAkAgBEHW44iHBEkNAAJAAkACQAJAAkAgBEH////7B0sNACABQgA3AwgCQAJAIARB2p+k7gRLDQAgAiACRIPIyW0wX+Q/okQAAAAAAAA4Q6BEAAAAAAAAOMOgIgVEAAAAUPsh+b+ioCAFRGNiGmG0EFG+oqAhAiAF/AIhBAwBCyABIAQgBEEXdkHqfmoiBkEXdGu+uzkDACABQQEgAUEIakEBIAZBABDagICAACEEAkAgA0EASA0AIAErAwghAgwBC0EAIARrIQQgASsDCJohAgsgBEEDcQ4EAgMEAQILIAAgAJMhAAwHCyACIAKiIgJEgV4M/f//37+iRAAAAAAAAPA/oCACIAKiIgVEQjoF4VNVpT+ioCACIAWiIAJEaVDu4EKT+T6iRCceD+iHwFa/oKKgtowhAAwGCyACIAIgAqIiBaIiByAFIAWioiAFRKdGO4yHzcY+okR058ri+QAqv6CiIAIgByAFRLL7bokQEYE/okR3rMtUVVXFv6CioKC2IQAMBQsgAiACoiICRIFeDP3//9+/okQAAAAAAADwP6AgAiACoiIFREI6BeFTVaU/oqAgAiAFoiACRGlQ7uBCk/k+okQnHg/oh8BWv6CioLYhAAwECyACIAKiIgUgApqiIgcgBSAFoqIgBUSnRjuMh83GPqJEdOfK4vkAKr+goiAHIAVEsvtuiRARgT+iRHesy1RVVcW/oKIgAqGgtiEADAMLAkAgBEHg27+FBEkNAEQYLURU+yEZwEQYLURU+yEZQCADQX9KGyACoCIFIAUgBaIiAqIiByACIAKioiACRKdGO4yHzcY+okR058ri+QAqv6CiIAUgByACRLL7bokQEYE/okR3rMtUVVXFv6CioKC2IQAMAwsCQCADQQBIDQAgAkTSITN/fNkSwKAiAiACoiICRIFeDP3//9+/okQAAAAAAADwP6AgAiACoiIFREI6BeFTVaU/oqAgAiAFoiACRGlQ7uBCk/k+okQnHg/oh8BWv6CioLaMIQAMAwsgAkTSITN/fNkSQKAiAiACoiICRIFeDP3//9+/okQAAAAAAADwP6AgAiACoiIFREI6BeFTVaU/oqAgAiAFoiACRGlQ7uBCk/k+okQnHg/oh8BWv6CioLYhAAwCCwJAIARB5JfbgARJDQBEGC1EVPshCcBEGC1EVPshCUAgA0F/ShsgAqAiBSAFoiICIAWaoiIHIAIgAqKiIAJEp0Y7jIfNxj6iRHTnyuL5ACq/oKIgByACRLL7bokQEYE/okR3rMtUVVXFv6CiIAWhoLYhAAwCCwJAIANBAEgNACACRBgtRFT7Ifm/oCICIAKiIgJEgV4M/f//37+iRAAAAAAAAPA/oCACIAKiIgVEQjoF4VNVpT+ioCACIAWiIAJEaVDu4EKT+T6iRCceD+iHwFa/oKKgtiEADAILIAJEGC1EVPsh+T+gIgIgAqIiAkSBXgz9///fv6JEAAAAAAAA8D+gIAIgAqIiBURCOgXhU1WlP6KgIAIgBaIgAkRpUO7gQpP5PqJEJx4P6IfAVr+goqC2jCEADAELAkAgBEGAgIDMA0kNACACIAKiIgUgAqIiByAFIAWioiAFRKdGO4yHzcY+okR058ri+QAqv6CiIAcgBUSy+26JEBGBP6JEd6zLVFVVxb+goiACoKC2IQAMAQsgASAAQwAAgAOUIABDAACAe5IgBEGAgIAESRs4AgggASoCCBoLIAFBEGokgICAgAAgAAsKACAAEN+AgIAAC7QCAwN/AX0CfCOAgICAAEEQayEBAkACQCAAvCICQf////8HcSIDQYCA8JcESw0AIANBgYCAmANPDQEgAEMAAIA/kg8LAkACQCADQYCAgPwHSw0AAkAgAkH///+XBEoNACACQQBODQMgAkH//9eYfEsNAiACQf//A3FFDQMgAUMBAACAIACVOAIMIAEqAgwaDAMLIABDAAAAf5QhAAsgAA8LIAFDAQAAgCAAlTgCDCABKgIMGkMAAAAADwsgAEMAAEBJkiIEvEEIaiIDQQ9xQQN0KwPAp8CAACIFIAAgBEMAAEDJkpO7IgZEAAAAAL6/zj+iRAAAAABDLuY/oCAFIAaiIgWioCAGRAAAAMDJsoM/okQAAACANGusP6AgBiAGoiAFoqKgIANBBHZB/wdqrUI0hr+itgv6CAUBfwF8An8CfAF/I4CAgIAAQRBrIgEkgICAgAAgALshAgJAAkAgALwiA0H/////B3EiBEHbn6T6A0kNAAJAIARB0qftgwRJDQACQCAEQdbjiIcESQ0AAkAgBEH////7B0sNACABQgA3AwgCQAJAIARB2p+k7gRLDQAgAiACRIPIyW0wX+Q/okQAAAAAAAA4Q6BEAAAAAAAAOMOgIgVEAAAAUPsh+b+ioCAFRGNiGmG0EFG+oqAhBiAF/AIhBAwBCyABIAQgBEEXdkHqfmoiB0EXdGu+uzkDACABQQEgAUEIakEBIAdBABDagICAACEEAkAgA0EASA0AIAErAwghBgwBC0EAIARrIQQgASsDCJohBgtEAAAAAAAA8L8gBiAGIAYgBqIiAqIiBSACRHKfmTj9EsE/okSfyRg0TVXVP6CioCAFIAIgAqIiBqIgAkTOM4yQ8x2ZP6JE/lqGHclUqz+gIAYgAkTNG5e/uWKDP6JETvTs/K1daD+goqCioCICoyACIARBAXEbtiEADAQLIAAgAJMhAAwDCwJAIARB4Nu/hQRJDQBEGC1EVPshGcBEGC1EVPshGUAgA0F/ShsgAqAiBiAGIAYgBqIiAqIiBiACRHKfmTj9EsE/okSfyRg0TVXVP6CioCAGIAIgAqIiBaIgAkTOM4yQ8x2ZP6JE/lqGHclUqz+gIAUgAkTNG5e/uWKDP6JETvTs/K1daD+goqCioLYhAAwDC0QAAAAAAADwv0TSITN/fNkSwETSITN/fNkSQCADQX9KGyACoCIGIAYgBiAGoiICoiIGIAJEcp+ZOP0SwT+iRJ/JGDRNVdU/oKKgIAYgAiACoiIFoiACRM4zjJDzHZk/okT+WoYdyVSrP6AgBSACRM0bl7+5YoM/okRO9Oz8rV1oP6CioKKgo7YhAAwCCwJAIARB5JfbgARJDQBEGC1EVPshCcBEGC1EVPshCUAgA0F/ShsgAqAiBiAGIAYgBqIiAqIiBiACRHKfmTj9EsE/okSfyRg0TVXVP6CioCAGIAIgAqIiBaIgAkTOM4yQ8x2ZP6JE/lqGHclUqz+gIAUgAkTNG5e/uWKDP6JETvTs/K1daD+goqCioLYhAAwCC0QAAAAAAADwv0QYLURU+yH5v0QYLURU+yH5PyADQX9KGyACoCIGIAYgBiAGoiICoiIGIAJEcp+ZOP0SwT+iRJ/JGDRNVdU/oKKgIAYgAiACoiIFoiACRM4zjJDzHZk/okT+WoYdyVSrP6AgBSACRM0bl7+5YoM/okRO9Oz8rV1oP6CioKKgo7YhAAwBCwJAIARBgICAzANJDQAgAiACoiIGIAKiIgUgBkRyn5k4/RLBP6JEn8kYNE1V1T+goiACoCAFIAYgBqIiAqIgBkTOM4yQ8x2ZP6JE/lqGHclUqz+gIAIgBkTNG5e/uWKDP6JETvTs/K1daD+goqCioLYhAAwBCyABIABDAACAA5QgAEMAAIB7kiAEQYCAgARJGzgCCCABKgIIGgsgAUEQaiSAgICAACAACwoAIAAQ4oCAgAALpwEAAkACQAJAAkAgAUH/AEoNACABQYJ/Tg0DIABDAACADJQhACABQZt+TQ0BIAFB5gBqIQEMAwsgAEMAAAB/lCEAIAFB/gFLDQEgAUGBf2ohAQwCCyAAQwAAgAyUIQAgAUG2fSABQbZ9SxtBzAFqIQEMAQsgAEMAAAB/lCEAIAFB/QIgAUH9AkkbQYJ+aiEBCyAAIAFBF3RBgICA/ANqQYCAgPwHcb6UC8IMBQF9A38BfQR/A31DAACAPyECAkACQAJAIAC8IgNBgICA/ANGDQAgAbwiBEH/////B3EiBUUNAAJAAkACQCAAiyIGvCIHQYCAgPwHSw0AIAVBgICA/AdLDQAgA0EATg0BQQIhCCAFQf///9sESw0CIAVBgICA/ANJDQFBACEIIAVBlgEgBUEXdmsiCXYiCiAJdCAFRw0CQQIgCkEBcWshCAwCCyAAIAGSDwtBACEICwJAAkACQAJAAkAgBUGAgID8A0YNACAFQYCAgPwHRw0BAkACQCAHQYCAgPwDSiAHQYCAgPwDSGtB/wFxDgIHAQALQwAAAAAgAYwgBEF/ShsPCyABQwAAAAAgBEF/ShsPCyAEQX9MDQEgAA8LAkACQCAEQYCAgPgDRg0AIARBgICAgARHDQEgACAAlA8LIANBf0oNAgsCQAJAAkACQAJAAkAgB0UNACAHQf////8DcUGAgID8A0cNAQtDAACAPyAGlSAGIARBAEgbIQIgA0EATg0IIAcgCGpBgICA/ANHDQEgAiACkyIAIACVDwtDAACAPyELIANBAE4NAyAIDgIBAgMLIAKMIAIgCEEBRhsPCyAAIACTIgAgAJUPC0MAAIC/IQsLAkAgBUGAgIDoBEsNACAGQwAAgEuUvCAHIAdBgICABEkiAxsiCEH///8DcSIHQYCAgPwDciEFIAhBF3VB6X5BgX8gAxtqIQhBACEDAkAgB0HyiPMASQ0AAkAgB0HX5/YCTw0AQQEhAwwBCyAHQYCAgPgDciEFIAhBAWohCAsgA0ECdCIHKgLIqMCAAEMAAIA/IAcqAsCowIAAIgAgBb4iDJKVIgIgDCAAkyIGIAVBAXZBgOD//wFxIANBFXRqQYCAgIICar4iDSAGIAKUIga8QYBgcb4iApSTIAAgDZMgDJIgApSTlCIAIAIgApQiDEMAAEBAkiAAIAYgApKUIAYgBpQiACAAlCAAIAAgACAAIABDQvFTPpRDVTJsPpKUQwWjiz6SlEOrqqo+kpRDt23bPpKUQ5qZGT+SlJIiDZK8QYBgcb4iAJQgBiANIABDAABAwJIgDJOTlJIiBiAGIAIgAJQiApK8QYBgcb4iACACk5NDTzh2P5QgAEPGI/a4lJKSIgIgByoC0KjAgAAiBiACIABDAEB2P5QiDJKSIAiyIgKSvEGAYHG+IgAgApMgBpMgDJOTIQIMAwsCQCAHQfj///sDSQ0AAkAgB0GHgID8A0sNACAGQwAAgL+SIgBDcKXsNpQgACAAlEMAAAA/IAAgAEMAAIC+lEOrqqo+kpSTlEM7qri/lJIiAiACIABDAKq4P5QiBpK8QYBgcb4iACAGk5MhAgwECwJAIARBAEoNACALQ2BCog2UQ2BCog2UDwsgC0PK8klxlEPK8klxlA8LAkAgBEEASA0AIAtDYEKiDZRDYEKiDZQPCyALQ8rySXGUQ8rySXGUDwtDAACAPyAAlQ8LIACRDwsCQAJAAkAgACAEQYBgcb4iBpQiDCABIAaTIACUIAEgApSSIgGSIgC8IgVBgICAmARKDQAgBUGAgICYBEYNASAAvEH/////B3EiA0GAgNiYBEsNBSAFQYCA2Jh8Rw0CIAEgACAMk19FDQIgC0NgQqINlENgQqINlA8LIAtDyvJJcZRDyvJJcZQPCyABQzyqODOSIAAgDJNeDQIgALxB/////wdxIQMLQQAhBAJAIANBgICA+ANNDQBBAEGAgIAEIANBF3ZBAmp2IAVqIgNB////A3FBgICABHJBFiADQRd2IgdrdiIEayAEIAVBAEgbIQQgASAMQYCAgHwgB0EBanUgA3G+kyIMkrwhBQsCQAJAIARBF3QgBUGAgH5xviIAQwByMT+UIgIgAEOMvr81lCABIAAgDJOTQxhyMT+UkiIGkiIAIAAgACAAIACUIgEgASABIAEgAUNMuzEzlEMO6t21kpRDVbOKOJKUQ2ELNruSlEOrqio+kpSTIgGUIAFDAAAAwJKVIAYgACACk5MiASAAIAGUkpOTQwAAgD+SIgC8aiIFQYCAgARIDQAgBb4hAAwBCyAAIAQQ5ICAgAAhAAsgCyAAlCECCyACDwsgC0PK8klxlEPK8klxlA8LIAtDYEKiDZRDYEKiDZQLDAAgACABEOWAgIAACwu3LAIAQYCAwAAL2CgWc2xpY2UgaW5kZXggc3RhcnRzIGF0IMANIGJ1dCBlbmRzIGF0IMAAIGluZGV4IG91dCBvZiBib3VuZHM6IHRoZSBsZW4gaXMgwBIgYnV0IHRoZSBpbmRleCBpcyDAABJyYW5nZSBzdGFydCBpbmRleCDAIiBvdXQgb2YgcmFuZ2UgZm9yIHNsaWNlIG9mIGxlbmd0aCDAABByYW5nZSBlbmQgaW5kZXggwCIgb3V0IG9mIHJhbmdlIGZvciBzbGljZSBvZiBsZW5ndGggwAAkbWluID4gbWF4LCBvciBlaXRoZXIgd2FzIE5hTi4gbWluID0gwAgsIG1heCA9IMAAEGFzc2VydGlvbiBgbGVmdCDAFyByaWdodGAgZmFpbGVkCiAgbGVmdDogwAkKIHJpZ2h0OiDAAC9ydXN0Yy81OGNmOGY5YzM1YjM1NTE5OTcyNzYyN2QwN2FlMzRhNGUyODQ2ZDY3L2xpYnJhcnkvY29yZS9zcmMvbnVtL2ltcC9mbHQyZGVjL3N0cmF0ZWd5L2dyaXN1LnJzAC9ydXN0Yy81OGNmOGY5YzM1YjM1NTE5OTcyNzYyN2QwN2FlMzRhNGUyODQ2ZDY3L2xpYnJhcnkvY29yZS9zcmMvbnVtL2ltcC9kaXlfZmxvYXQucnMAc3JjL2RydW1zLnJzAC9ydXN0Yy81OGNmOGY5YzM1YjM1NTE5OTcyNzYyN2QwN2FlMzRhNGUyODQ2ZDY3L2xpYnJhcnkvc3RkL3NyYy9zeXMvc3luYy9yd2xvY2svbm9fdGhyZWFkcy5ycwAvcnVzdGMvNThjZjhmOWMzNWIzNTUxOTk3Mjc2MjdkMDdhZTM0YTRlMjg0NmQ2Ny9saWJyYXJ5L2NvcmUvc3JjL251bS9pbXAvZmx0MmRlYy9zdHJhdGVneS9kcmFnb24ucnMAL3J1c3RjLzU4Y2Y4ZjljMzViMzU1MTk5NzI3NjI3ZDA3YWUzNGE0ZTI4NDZkNjcvbGlicmFyeS9jb3JlL3NyYy9udW0vaW1wL2JpZ251bS5ycwBzcmMvb3ZlcnNhbXBsZS5ycwAvcnVzdGMvNThjZjhmOWMzNWIzNTUxOTk3Mjc2MjdkMDdhZTM0YTRlMjg0NmQ2Ny9saWJyYXJ5L2FsbG9jL3NyYy9yYXdfdmVjL21vZC5ycwAvcnVzdGMvNThjZjhmOWMzNWIzNTUxOTk3Mjc2MjdkMDdhZTM0YTRlMjg0NmQ2Ny9saWJyYXJ5L2NvcmUvc3JjL251bS9pbXAvZmx0MmRlYy9tb2QucnMAL3J1c3QvZGVwcy9kbG1hbGxvYy0wLjIuMTQvc3JjL2RsbWFsbG9jLnJzAC9ydXN0Yy81OGNmOGY5YzM1YjM1NTE5OTcyNzYyN2QwN2FlMzRhNGUyODQ2ZDY3L2xpYnJhcnkvY29yZS9zcmMvbnVtL2YzMi5ycwD4AxAASwAAAEUGAAAJAAAAEgMQABEAAABtAAAACQAAABIDEAARAAAAbgAAAAkAAAASAxAAEQAAAHQAAAASAAAAEgMQABEAAADJAAAAFgAAAPABEAAMAAAAewEAABsAAADwARAADAAAAKIBAAAdAAAA8AEQAAwAAAAbAgAAGQAAAPABEAAMAAAA2gMAACoAAADwARAADAAAAN8DAAAeAAAA8AEQAAwAAADgAwAAEgAAAPABEAAMAAAA4AMAAAkAAADwARAADAAAAAUEAAASAAAA8AEQAAwAAABLBAAAFAAAAPABEAAMAAAAzAAAACsAAAAAAEBAZmbmP2ZmZkDNzCzAZmYmQM3MLEAAACBAAAAgQM3MjD/NzCxAZmaWQM3MzL3NzMw/MzNTwM3MjD/NzIw/MzMTQM3MTECamRk/ZmYmQDMz87/NzAxAzczMvpqZmb7wARAADAAAAFkAAAARAAAAAAECAwRjYXBhY2l0eSBvdmVyZmxvdwAAJAMQAFAAAAAcAAAABQAAADAxMjM0NTY3ODlhYmNkZWYAAAAABAAAAAQAAAAFAAAALStOYU5pbmYwMC4wZTBhc3NlcnRpb24gZmFpbGVkOiBidWYubGVuKCkgPj0gbWF4bGVuAHUDEABXAAAAiwIAAA0AAACaARAAVQAAAC4AAAAJAAAAYXNzZXJ0aW9uIGZhaWxlZDogb3RoZXIgPiAwYXNzZXJ0aW9uIGZhaWxlZDogbm9ib3Jyb3cAAAC/AhAAUgAAAIQBAAABAAAAYXNzZXJ0aW9uIGZhaWxlZDogZGlnaXRzIDwgNDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwPT0wMDAxMDIwMzA0MDUwNjA3MDgwOTEwMTExMjEzMTQxNTE2MTcxODE5MjAyMTIyMjMyNDI1MjYyNzI4MjkzMDMxMzIzMzM0MzUzNjM3MzgzOTQwNDE0MjQzNDQ0NTQ2NDc0ODQ5NTA1MTUyNTM1NDU1NTY1NzU4NTk2MDYxNjI2MzY0NjU2NjY3Njg2OTcwNzE3MjczNzQ3NTc2Nzc3ODc5ODA4MTgyODM4NDg1ODY4Nzg4ODk5MDkxOTI5Mzk0OTU5Njk3OTg5OS5hdHRlbXB0IHRvIGRpdmlkZSBieSB6ZXJvYXNzZXJ0aW9uIGZhaWxlZDogIWJ1Zi5pc19lbXB0eSgpAAB1AxAAVwAAALcAAAAFAAAAYXNzZXJ0aW9uIGZhaWxlZDogYnVmWzBdID4gYicwJwB1AxAAVwAAALgAAAAFAAAAdQMQAFcAAAAJAQAABQAAAHUDEABXAAAACgEAAAUAAABlZS0A30UaPQPPGubB+8z+AAAAAMrGmscX/nCr3PvU/gAAAABP3Ly+/LF3//b73P4AAAAADNZrQe+RVr4R/OT+AAAAADz8f5CtH9CNLPzs/gAAAACDmlUxKFxR00b89P4AAAAAtcmmrY+scZ1h/Pz+AAAAAMuL7iN3Ipzqe/wE/wAAAABtU3hAkUnMrpb8DP8AAAAAV862XXkSPIKx/BT/AAAAADdW+002lBDCy/wc/wAAAABPmEg4b+qWkOb8JP8AAAAAxzqCJcuFdNcA/Sz/AAAAAPSXv5fNz4agG/00/wAAAADlrCoXmAo07zX9PP8AAAAAjrI1KvtnOLJQ/UT/AAAAADs/xtLf1MiEa/1M/wAAAAC6zdMaJ0TdxYX9VP8AAAAAlsklu86fa5Og/Vz/AAAAAISlYn0kbKzbuv1k/wAAAAD22l8NWGaro9X9bP8AAAAAJvHD3pP44vPv/XT/AAAAALiA/6qorbW1Cv58/wAAAACLSnxsBV9ihyX+hP8AAAAAUzDBNGD/vMk//oz/AAAAAFUmupGMhU6WWv6U/wAAAAC9filwJHf533T+nP8AAAAAj7jluJ+936aP/qT/AAAAAJR9dIjPX6n4qf6s/wAAAADPm6iPk3BEucT+tP8AAAAAaxUPv/jwCIrf/rz/AAAAALYxMWVVJbDN+f7E/wAAAACsf3vQxuI/mRT/zP8AAAAABjsrKsQQXOQu/9T/AAAAANOSc2mZJCSqSf/c/wAAAAAOygCD8rWH/WP/5P8AAAAA6xoRkmQI5bx+/+z/AAAAAMyIUG8JzLyMmf/0/wAAAAAsZRniWBe30bP//P8AAAAAAAAAAAAAQJzO/wQAAAAAAAAAAAAQpdTo6P8MAAAAAAAAAGKsxet4rQMAFAAAAAAAhAmU+Hg5P4EeABwAAAAAALMVB8l7zpfAOAAkAAAAAABwXOp7zjJ+j1MALAAAAAAAaIDpq6Q40tVtADQAAAAAAEUimhcmJ0+fiAA8AAAAAAAn+8TUMaJj7aIARAAAAAAAqK3IjDhl3rC9AEwAAAAAANtlqxqOCMeD2ABUAAAAAACaHXFC+R1dxPIAXAAAAAAAWOcbpixpTZINAWQAAAAAAOqNcBpk7gHaJwFsAAAAAABKd++amaNtokIBdAAAAAAAhWt9tHt4CfJcAXwAAAAAAHcY3Xmh5FS0dwGEAAAAAADCxZtbkoZbhpIBjAAAAAAAPV2WyMVTNcisAZQAAAAAALOgl/pctCqVxwGcAAAAAADjX6CZvZ9G3uEBpAAAAAAAJYw52zTCm6X8AawAAAAAAFyfmKNymsb2FgK0AAAAAADOvulUU7/ctzECvAAAAAAA4kEi8hfz/IhMAsQAAAAAAKV4XNObziDMZgLMAAAAAADfUyF781oWmIEC1AAAAAAAOjAfl9y1oOKbAtwAAAAAAJaz41xT0dmotgLkAAAAAAA8RKek2Xyb+9AC7AAAAAAAEESkp0xMdrvrAvQAAAAAABqcQLbvjquLBgP8AAAAAAAshFemEO8f0CADBAEAAAAAKTGR6eWkEJs7AwwBAAAAAJ0MnKH7mxDnVQMUAQAAAAAp9Dti2SAorHADHAEAAAAAhc+nel5LRICLAyQBAAAAAC3drANA5CG/pQMsAQAAAACP/0ReL5xnjsADNAEAAAAAQbiMnJ0XM9TaAzwBAAAAAKkb47SS2xme9QNEAQAAAADZd9+6br+W6w8ETAEAAAAAYXNzZXJ0aW9uIGZhaWxlZDogZC5tYW50ID4gMDcBEABiAAAA3gEAAAUAAAA3ARAAYgAAAH8AAAAVAAAANwEQAGIAAAA1AgAAEQAAADcBEABiAAAAbgIAAAkAAAA3ARAAYgAAAKsAAAAFAAAAYXNzZXJ0aW9uIGZhaWxlZDogZC5taW51cyA+IDAAAAA3ARAAYgAAAKwAAAAFAAAAYXNzZXJ0aW9uIGZhaWxlZDogZC5wbHVzID4gMDcBEABiAAAArQAAAAUAAABhc3NlcnRpb24gZmFpbGVkOiBkLm1hbnQgKyBkLnBsdXMgPCAoMSA8PCA2MSkAAAA3ARAAYgAAALEAAAAFAAAANwEQAGIAAAAMAQAAEQAAADcBEABiAAAAQgEAAAkAAABhc3NlcnRpb24gZmFpbGVkOiBkLm1hbnQuY2hlY2tlZF9zdWIoZC5taW51cykuaXNfc29tZSgpADcBEABiAAAArwAAAAUAAABhc3NlcnRpb24gZmFpbGVkOiBkLm1hbnQuY2hlY2tlZF9hZGQoZC5wbHVzKS5pc19zb21lKCkAADcBEABiAAAArgAAAAUAAABbAhAAYwAAAHQBAAAkAAAAWwIQAGMAAAB5AQAALwAAAFsCEABjAAAAhgEAABIAAABbAhAAYwAAAGgBAAANAAAAWwIQAGMAAABOAQAAIgAAAFsCEABjAAAAeAAAAAUAAABbAhAAYwAAAHkAAAAFAAAAWwIQAGMAAAB6AAAABQAAAFsCEABjAAAAxAAAAAkAAABbAhAAYwAAAP0AAAANAAAAWwIQAGMAAAAEAQAAEgAAAFsCEABjAAAAfAAAAAUAAABbAhAAYwAAAHsAAAAFAAAAAQAAAAoAAABkAAAA6AMAABAnAACghgEAQEIPAICWmAAA4fUFAMqaO8Fv8oYjAAAAge+shVtBbS3uBAAAAR9qv2TtOG7tl6fa9Pk/6QNPGAABPpUuCZnfA/04FQ8v5HQj7PXP0wjcBMTasM28GX8zpgMmH+lOAgAAAXwumFuH075yn9nYhy8VEsZQ3mtwbkrPD9iV1W5xsiawZsatJDYVHVrTQjwOVP9jwHNVzBfv+WXyKLxV98fcgNztbvTO79xf91MFADcBEABiAAAA8QIAACYAAAA3ARAAYgAAAOUCAAAmAAAANwEQAGIAAADOAgAAJgAAADB4MDEyMzQ1Njc4OUFCQ0RFRgAABgAAAAwAAAAEAAAABwAAAAgAAAAJAAAAAAAAAAgAAAAEAAAACgAAAAsAAAAMAAAADQAAAA4AAAAQAAAABAAAAA8AAAAQAAAAEQAAABIAAABc9ulf3AL2ufHBcGzyYcEkOzdNSoIQRQnDpWHRPyA6j2Fzc2VydGlvbiBmYWlsZWQ6IHBzaXplID49IHNpemUgKyBtaW5fb3ZlcmhlYWQAAM0DEAAqAAAA6QQAAAkAAABhc3NlcnRpb24gZmFpbGVkOiBwc2l6ZSA8PSBzaXplICsgbWF4X292ZXJoZWFkAADNAxAAKgAAAO8EAAANAAAAzQMQACoAAABNBQAAHgAAAHJ3bG9jayBvdmVyZmxvd2VkIHJlYWQgbG9ja3P9ARAAXQAAABgAAAAsAAAAAAAAAAgAAAAEAAAAEwAAAAYAAAAMAAAABAAAABQAAAALBQYBAQAAADQFEABgBRAAdAUQAIwFEACQBRAACwUGEAsAAAAAAAA/AAAAvwMAAAAEAAAABAAAAAYAAACD+aIARE5uAPwpFQDRVycA3TT1AGLbwAA8mZUAQZBDAGNR/gC73qsAt2HFADpuJADSTUIASQbgAAnqLgAcktEA6x3+ACmxHADoPqcA9TWCAES7LgCc6YQAtCZwAEF+XwDWkTkAU4M5AJz0OQCLX4QAKPm9APgfOwDe/5cAD5gFABEv7wAKWosAbR9tAM9+NgAJyycARk+3AJ5mPwAt6l8Auid1AOXrxwA9e/EA9zkHAJJSigD7a+oAH7FfAAhdjQAwA1YAe/xGAPCrawAgvM8ANvSaAOOpHQBeYZEACBvmAIWZZQCgFF8AjUBoAIDY/wAnc00ABgYxAMpWFQDJqHMAe+JgAGuMwAAAAABA+yH5PwAAAAAtRHQ+AAAAgJhG+DwAAABgUcx4OwAAAICDG/A5AAAAQCAlejgAAACAIoLjNgAAAAAd82k1zTt/Zp6g5j+HAetzFKHnP9ugKkLlrOg/kPCjgpHE6T+t01qZn+jqP5xShd2bGew/h6T73BhY7T/akKSir6TuPwAAAAAAAPA/D4n5bFi18D97UX08uHLxPzhidW56OPI/FbcxCv4G8z8iNBJMpt7zPycqNtXav/Q/KVRI3Qer9T8AAIA/AADAPwAAAADcz9E1AAAAAADAFT8AQdiowAALzAMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQD/DwAA", In, Ln, Rn = !1;
function zn() {
	return Ln ??= (async () => {
		let e = Uint8Array.from(atob(Fn.slice(Fn.indexOf(",") + 1)), (e) => e.charCodeAt(0));
		In = await WebAssembly.compile(e);
	})().catch((e) => {
		Ln = void 0, Rn || (Rn = !0, console.warn("Rackloose DSP unavailable, so Ladder filters and Analog drums play Digital:", e));
	}), Ln;
}
var Bn = () => In, Vn = [
	Mn,
	Nn,
	Pn
].map((e) => ({
	source: e,
	contexts: /* @__PURE__ */ new WeakMap()
}));
async function Hn(e) {
	await Promise.all([zn(), ...Vn.map(({ source: t, contexts: n }) => {
		let r = n.get(e);
		if (!r) {
			let i = URL.createObjectURL(new Blob([t], { type: "text/javascript" }));
			r = e.audioWorklet.addModule(i).finally(() => URL.revokeObjectURL(i)), n.set(e, r), r.catch(() => n.delete(e));
		}
		return r;
	})]);
}
function Un(e, t, n, r) {
	let i = 0, a = !1, o, s = /* @__PURE__ */ new Map(), c = (e) => {
		for (let t of s.values()) clearTimeout(t.timer), e ? t.reject(e) : t.resolve();
		s.clear();
	};
	return e.port.onmessage = ({ data: e }) => {
		if (a) return;
		typeof e.reduction == "number" && Number.isFinite(e.reduction) && n?.(e.reduction);
		let t = e.id === void 0 ? void 0 : s.get(e.id);
		t && (clearTimeout(t.timer), t.resolve(), s.delete(e.id));
	}, e.onprocessorerror = () => {
		a || (o = /* @__PURE__ */ Error(`${t} audio processor failed. Reload the patch to retry.`), c(o), r?.(o));
	}, {
		flush() {
			return o ? Promise.reject(o) : a ? Promise.resolve() : new Promise((n, r) => {
				let a = ++i, o = setTimeout(() => {
					s.delete(a), r(/* @__PURE__ */ Error(`${t} did not finish preparing audio. Try again.`));
				}, 5e3);
				s.set(a, {
					resolve: n,
					reject: r,
					timer: o
				}), e.port.postMessage({
					type: "flush",
					id: a
				});
			});
		},
		dispose() {
			a || (a = !0, e.port.postMessage({ type: "dispose" }), c(), e.port.onmessage = null, e.onprocessorerror = null, e.port.close());
		}
	};
}
//#endregion
//#region src/audio/drumEngine.ts
var Wn = {
	boom: 0,
	punch: 1,
	orbit: 2,
	strike: 3,
	forge: 4
}, Gn = {
	boom: [["open", "hat"]],
	punch: [["open", "hat"]],
	strike: [["open", "hat"]],
	forge: [["open", "hat"], ["open", "pedal"]]
}, Kn = (e) => 2 ** (e / 12), qn = 8;
function Jn(e, t, n, r) {
	let i = Yn(e, t, n, r);
	return Array.from({ length: qn }, (e, r) => r === 7 ? n[`${t}Pan`] ?? 0 : i[r] ?? 0);
}
function Yn(e, t, n, r) {
	if (e === "orbit") return [
		Kn(n.pitch + n[`${t}Tune`]),
		n[`${t}Decay`],
		Math.min(1, n[`${t}Level`]),
		n[`${t}Tone`]
	];
	if (r) {
		let e = Kn(n[`${t}Tune`]), i = r.sample(t).length / (r.rate * e), a = Math.min(2e4, (r.tone ?? ((e) => 700 * 20 ** e))(n[`${t}Tone`]));
		return [
			r.rate * e,
			n[`${t}Decay`],
			a,
			n[`${t}Level`] * (r.peak ?? 1.6),
			Math.min(i, n[`${t}Decay`] * 2) + .01
		];
	}
	return t === "kick" ? e === "punch" ? [
		n.kickTune,
		n.kickDecay,
		n.kickClick
	] : [n.kickTune, n.kickDecay] : t === "snare" ? [
		n.snareTone,
		n.snappy,
		Kn(n.snareTune),
		n.snareDecay
	] : t === "rim" ? [Kn(n.rimTune), n.rimDecay] : t === "clap" ? [H(n.clapTone, 3), n.clapDecay] : t === "lowTom" ? [95 * Kn(n.tomTune), n.tomDecay] : t === "highTom" ? [145 * Kn(n.highTomTune), n.highTomDecay * .85] : t === "bell" ? [Kn(n.bellTune), n.bellDecay] : [n[`${t}Decay`], H(n[`${t}Tone`], 2)];
}
function Xn(e, t, n) {
	let r = n[`${t}Level`] ?? 1;
	return e === "boom" || e === "punch" ? r : e === "orbit" ? Math.max(1, r) : 1;
}
function Zn(e, t, n, { keep: r, onError: i }) {
	let a = Bn();
	if (!a) return null;
	let o = U[t].drum.voices.map((e) => e.id), s = t === "strike" ? vn : t === "forge" ? An : void 0, c = (Gn[t] ?? []).map(([e, t]) => [o.indexOf(e), o.indexOf(t)]), l;
	try {
		l = r(new AudioWorkletNode(e, "rackloose-drums-v1", {
			numberOfInputs: 0,
			numberOfOutputs: 1,
			outputChannelCount: [2],
			processorOptions: {
				module: a,
				kit: Wn[t],
				chokes: c
			}
		}));
	} catch (e) {
		return console.warn(`${U[t].name} Analog engine unavailable, so it plays Digital:`, e), null;
	}
	l.connect(n);
	let u = Un(l, U[t].name, void 0, i), d = /* @__PURE__ */ new Set();
	return {
		trigger(e, n, r, i = 1) {
			let a = o.indexOf(e);
			a < 0 || (s && !d.has(e) && (d.add(e), l.port.postMessage({
				type: "sample",
				voice: a,
				pcm: s.sample(e)
			})), l.port.postMessage({
				type: "hit",
				time: n,
				voice: a,
				velocity: i * Xn(t, e, r),
				params: Jn(t, e, r, s)
			}));
		},
		cancelScheduled(e) {
			l.port.postMessage({
				type: "cancel",
				time: e
			});
		},
		dispose: u.dispose,
		flush: u.flush
	};
}
function Qn(e, t, n, r, i) {
	let a, o, s = i?.input ?? n, c = () => a ??= i ? i.classic() : t === "strike" ? yn(e, s) : hn(e, t, s, r), l = () => o === void 0 ? o = Zn(e, t, s, r) : o;
	return {
		trigger(e, t, n, r) {
			(n.engine === 1 ? l() ?? c() : c()).trigger(e, t, n, r);
		},
		cancelScheduled(e) {
			a?.cancelScheduled(e), o?.cancelScheduled(e);
		},
		dispose() {
			a?.dispose(), o?.dispose(), i?.dispose();
		},
		flush: () => o?.flush() ?? Promise.resolve()
	};
}
//#endregion
//#region src/audio/envelope.ts
function $n(e) {
	let t = [], n = (e) => {
		let n = t.findIndex(([t]) => t > e);
		if (n === 0 || !t.length) return 0;
		if (n < 0) return t[t.length - 1][1];
		let [r, i] = t[n - 1], [a, o] = t[n];
		return i + (o - i) * (e - r) / (a - r);
	}, r = (r, ...i) => {
		let a = n(r);
		fn(e, r), e.setValueAtTime(a, r);
		for (let [t, n] of i) e.linearRampToValueAtTime(n, t);
		t = [
			...t.filter(([e]) => e < r).slice(-16),
			[r, a],
			...i
		];
	};
	return {
		on(e, t, n, i, a) {
			r(e, [e + n, t], [e + n + i, t * a]);
		},
		off(e, t) {
			r(e, [e + t, 0]);
		}
	};
}
//#endregion
//#region src/audio/ladder.ts
function er(e, { keep: t, onError: n, name: r }, i, a, o = []) {
	let s = t(e.createGain());
	s.gain.value = 0, s.connect(a);
	let c, l, u = !1, d = () => {
		let a = Bn();
		if (c || u || !a) return !!c;
		try {
			c = t(new AudioWorkletNode(e, "rackloose-ladder-v1", {
				numberOfInputs: 1,
				numberOfOutputs: 1,
				outputChannelCount: [1],
				processorOptions: { module: a }
			}));
		} catch (e) {
			return u = !0, console.warn(`${r} Ladder filter unavailable, so it plays Digital:`, e), !1;
		}
		for (let e of o) e.connect(c.parameters.get("detune"));
		return i.connect(c).connect(s), l = Un(c, r, void 0, n), !0;
	};
	return {
		apply(t, n, r) {
			let i = t && d();
			if (r(s.gain, i ? n.level : 0), c) {
				let t = (e) => c.parameters.get(e);
				r(t("cutoff"), n.cutoff), r(t("resonance"), n.resonance), r(t("drive"), n.drive), r(t("detune"), n.detune ?? 0);
				let i = t("mode"), a = e.currentTime;
				i.cancelScheduledValues(a), i.setValueAtTime(n.mode ?? 0, a);
			}
			return i;
		},
		flush: () => l?.flush() ?? Promise.resolve(),
		dispose: () => l?.dispose()
	};
}
//#endregion
//#region src/audio/monarch.ts
var tr = [
	"sine",
	"triangle",
	"sawtooth",
	"square"
], nr = 1.4, rr = (e) => {
	let t = 1 + e * 5;
	return t / Math.tanh(t) / Math.sqrt(8 ** e);
};
function ir(e, t, { keep: n, source: r, onError: i }) {
	let a = (t = 1) => {
		let r = n(e.createGain());
		return r.gain.value = t, r;
	}, o = a(), s = a(), c = a(), l = n(e.createWaveShaper()), u = n(e.createBiquadFilter());
	u.type = "lowpass", u.Q.value = .5, o.connect(u);
	let d = [n(e.createBiquadFilter()), n(e.createBiquadFilter())], f = a(0), p = a(), m = a(.5), h = a(), g = a();
	c.connect(l).connect(d[0]).connect(d[1]).connect(g).connect(f).connect(p);
	let _ = er(e, {
		keep: n,
		onError: i,
		name: "MONARCH"
	}, c, f, [
		s,
		h,
		m
	]), v = r(e.createConstantSource()), y = r(e.createConstantSource());
	v.offset.value = 0, y.offset.value = 0, v.connect(f.gain), y.connect(h), u.connect(m);
	for (let e of d) e.type = "lowpass", s.connect(e.detune), h.connect(e.detune), m.connect(e.detune);
	let b = [
		1,
		2,
		3
	].map(() => {
		let t = r(e.createOscillator()), n = a();
		return t.frequency.value = 261.625565, t.connect(n).connect(c), u.connect(t.detune), {
			osc: t,
			level: n
		};
	}), x = r(e.createBufferSource()), S = a(0);
	x.buffer = t, x.loop = !0, x.connect(S).connect(c);
	let C = {}, w = !1, T = -1, E = (t, n) => {
		w ? t.setTargetAtTime(n, e.currentTime, .008) : t.value = n;
	}, D = [[$n(v.offset), "amp"], [$n(y.offset), "filter"]];
	return {
		pitch: o,
		cv: s,
		output: p,
		apply(t) {
			C = t, b.forEach(({ osc: e, level: n }, r) => {
				let i = `osc${r + 1}`;
				e.type = tr[t[`${i}Wave`]], E(e.detune, t[`${i}Octave`] * 1200 + t[`${i}Detune`]), E(n.gain, t[`${i}Level`] * .23);
			}), E(S.gain, t.noise * .15), E(p.gain, t.level), E(u.frequency, t.glide ? Math.min(e.sampleRate * .45, 1 / (2 * Math.PI * t.glide)) : e.sampleRate * .45), E(m.gain, t.tracking), E(h.gain, t.envAmount * 4800), d.forEach((e, n) => {
				E(e.frequency, t.cutoff), E(e.Q, n === 0 ? .707 + t.resonance * 5 : .707);
			});
			let n = _.apply(t.filterModel === 1, {
				cutoff: t.cutoff,
				resonance: t.resonance,
				drive: t.drive,
				level: nr * rr(t.drive)
			}, E);
			if (E(g.gain, +!n), T !== t.drive) {
				T = t.drive;
				let e = 1 + t.drive * 5;
				l.curve = Float32Array.from({ length: 2049 }, (t, n) => Math.tanh(e * (n / 1024 - 1)) / Math.tanh(e)), l.oversample = "2x";
			}
			w = !0;
		},
		noteOn(e, t) {
			for (let [n, r] of D) n.on(t, e, C[`${r}Attack`], C[`${r}Decay`], C[`${r}Sustain`]);
		},
		noteOff(e) {
			for (let [t, n] of D) t.off(e, C[`${n}Release`]);
		},
		flush: _.flush,
		dispose: _.dispose
	};
}
//#endregion
//#region src/audio/oracle.ts
var ar = .25, or = .98, sr = [
	[
		4,
		-3,
		70
	],
	[
		-5,
		2,
		-40
	],
	[
		1,
		6,
		110
	],
	[
		-2,
		-6,
		-90
	],
	[
		6,
		1,
		20
	]
], cr = 261.625565;
function lr(e, t, { keep: n, source: r, onError: i }) {
	let a = (t = 1) => {
		let r = n(e.createGain());
		return r.gain.value = t, r;
	}, o = (t = 0) => {
		let n = r(e.createConstantSource());
		return n.offset.value = t, n;
	}, s = (e) => Float32Array.from({ length: 1025 }, (t, n) => Math.tanh(e * (n / 512 - 1)) / Math.tanh(e)), c = (t, r, i) => {
		let a = n(e.createWaveShaper());
		return a.curve = s(24), a.oversample = "4x", t.connect(a), r.connect(a), Q(a, i);
	}, l = a(), u = a(), d = a(.5), f = a(), p = n(e.createBiquadFilter());
	p.type = "highpass", p.frequency.value = 20, p.Q.value = -3.01, d.connect(p).connect(f);
	let m = r(e.createBufferSource()), h = a(0);
	m.buffer = t, m.loop = !0, m.connect(h);
	let g = r(e.createOscillator()), _ = a(0), v = a(0), y = a(0);
	g.connect(_), g.connect(v), g.connect(y);
	let b = sr.map((t) => {
		let s = o(), f = o(), p = o(), m = o(), g = o(), b = r(e.createOscillator()), x = r(e.createOscillator());
		b.type = "sawtooth", b.frequency.value = cr, x.frequency.value = cr;
		let S = a(), C = a(0), w = a(), T = a(), E = a(), D = a(0), O = a(), ee = a();
		b.connect(S).connect(w), C.connect(w);
		let te = c(b, m, C);
		x.connect(E).connect(O), D.connect(O);
		let ne = c(x, g, D), re = a(), ie = a(0), ae = a(), oe = [n(e.createBiquadFilter()), n(e.createBiquadFilter())];
		w.connect(T).connect(re), O.connect(ee).connect(re), h.connect(re), re.connect(oe[0]).connect(oe[1]).connect(ae).connect(ie).connect(d), f.connect(ie.gain);
		let se = a(), k = a(), ce = a(0), le = a(0), A = a(), j = a(0), M = a(0);
		p.connect(k), p.connect(ce).connect(A), O.connect(le).connect(A), A.connect(j).connect(b.detune), A.connect(M);
		for (let e of [b.detune, x.detune]) s.connect(e), l.connect(e), _.connect(e);
		s.connect(se), l.connect(se), v.connect(m.offset), v.connect(g.offset);
		let N = [
			se,
			k,
			M,
			u,
			y
		];
		for (let e of oe) {
			e.type = "lowpass";
			for (let t of N) t.connect(e.detune);
		}
		return {
			drift: t,
			note: s,
			amp: f,
			filterEnv: p,
			a: b,
			b: x,
			aWidth: m,
			bWidth: g,
			aComparator: te,
			bComparator: ne,
			aSaw: S,
			aPulse: C,
			aLevel: T,
			bWave: E,
			bPulse: D,
			bLevel: ee,
			filters: oe,
			classic: ae,
			ladder: er(e, {
				keep: n,
				onError: i,
				name: "ORACLE"
			}, re, ie, N),
			tracking: se,
			envDepth: k,
			polyEnv: ce,
			polyB: le,
			polyA: j,
			polyFilter: M,
			pitched: !1
		};
	}), x = new xn(b.length), S = {}, C = !1, w = (t, n) => {
		C ? t.setTargetAtTime(n, e.currentTime, .008) : t.value = n;
	}, T = (e, t, n, r) => {
		let i = Math.max(.001, S[`${t}Attack`]);
		fn(e, r), e.linearRampToValueAtTime(n, r + i), e.setTargetAtTime(n * S[`${t}Sustain`], r + i, Math.max(.001, S[`${t}Decay`]) / 3);
	}, E = (e, t, n) => {
		fn(e, n), e.setTargetAtTime(0, n, Math.max(.001, S[`${t}Release`]) / 4);
	}, D = (e, t) => {
		for (let { index: n, pending: r } of x.release(e, S.ampRelease, t)) {
			let t = b[n];
			r && fn(t.note.offset, e), E(t.amp.offset, "amp", e), E(t.filterEnv.offset, "filter", e);
		}
	};
	return {
		pitch: l,
		cv: u,
		output: f,
		apply(e) {
			S = e;
			let t = e.vintage, n = e.aShape, r = e.bShape, i = e.polyDest, a = e.lfoDest;
			for (let a of b) {
				w(a.a.detune, e.aOctave * 1200 + a.drift[0] * t), w(a.b.detune, e.bOctave * 1200 + e.bFine + a.drift[1] * t), a.b.type = r === 1 ? "triangle" : "sawtooth", w(a.aSaw.gain, n === 1 ? 0 : n === 2 ? .7 : 1), w(a.aPulse.gain, n === 0 ? 0 : n === 2 ? .7 : 1), w(a.bWave.gain, r === 2 ? 0 : 1), w(a.bPulse.gain, +(r === 2)), a.aComparator(n !== 0, !C), a.bComparator(r === 2, !C), w(a.aWidth.offset, 2 * e.aWidth - 1), w(a.bWidth.offset, 2 * e.bWidth - 1), w(a.aLevel.gain, e.aLevel * .25), w(a.bLevel.gain, e.bLevel * .25), w(a.polyEnv.gain, e.polyEnv * 3600), w(a.polyB.gain, e.polyOscB * 2400), w(a.polyA.gain, i === 1 ? 0 : 1), w(a.polyFilter.gain, i === 0 ? 0 : 1), w(a.tracking.gain, e.tracking), w(a.envDepth.gain, e.envAmount * 6e3), a.filters.forEach((n, r) => {
					w(n.frequency, e.cutoff), w(n.detune, a.drift[2] * t), w(n.Q, r === 0 ? -3.01 + e.resonance * 20 : -3.01);
				});
				let o = a.ladder.apply(e.filterModel === 1, {
					cutoff: e.cutoff,
					resonance: e.resonance,
					drive: ar,
					level: or,
					detune: a.drift[2] * t
				}, w);
				w(a.classic.gain, +!o);
			}
			g.type = [
				"triangle",
				"sawtooth",
				"square"
			][e.lfoShape], w(g.frequency, e.lfoRate), w(_.gain, a === 0 ? e.lfoAmount * 300 : 0), w(v.gain, a === 1 ? e.lfoAmount * .9 : 0), w(y.gain, a === 2 ? e.lfoAmount * 2400 : 0), w(h.gain, e.noise * .2), w(f.gain, e.level), C = !0;
		},
		noteOn(e, t, n, r) {
			D(n, r);
			let i = /* @__PURE__ */ new Set();
			for (let a of (ve[S.chord]?.[1] ?? [0]).slice(0, b.length)) {
				let o = x.allocate(n, i), s = b[o], c = (e + a - 60) * 100;
				i.add(o), x.start(o, r, n), fn(s.note.offset, n), S.glide > 0 && s.pitched ? s.note.offset.setTargetAtTime(c, n, S.glide / 3) : s.note.offset.setValueAtTime(c, n), s.pitched = !0, T(s.amp.offset, "amp", t, n), T(s.filterEnv.offset, "filter", t, n);
			}
		},
		noteOff: D,
		flush: () => Promise.all(b.map((e) => e.ladder.flush())).then(() => void 0),
		dispose: () => {
			for (let e of b) e.ladder.dispose();
		}
	};
}
//#endregion
//#region src/audio/aurora.ts
var ur = .25, dr = 1.22;
function fr(e, { keep: t, source: n, onError: r }) {
	let i = (n = 1) => {
		let r = t(e.createGain());
		return r.gain.value = n, r;
	}, a = () => {
		let t = n(e.createConstantSource());
		return t.offset.value = 0, t;
	}, o = i(), s = i(), c = i(), l = i(.22);
	l.connect(c);
	let u = n(e.createOscillator()), d = i(0), f = i(0), p = i(0);
	u.connect(d), u.connect(f), u.connect(p);
	let m = Float32Array.from({ length: 2049 }, (e, t) => Math.tanh(24 * (t / 1024 - 1))), h = Array.from({ length: 8 }, (c, u) => {
		let h = a(), g = a(), _ = a(), v = i(), y = i(0), b = i(), x = i(), S = i(0), C = [0, 1].map(() => {
			let r = n(e.createOscillator()), s = a(), c = i(), l = i(0), u = i(), p = i();
			r.frequency.value = 261.625565;
			let g = t(e.createWaveShaper());
			return g.curve = m, g.oversample = "4x", r.connect(c).connect(p), r.connect(g), s.connect(g), l.connect(p), p.connect(u).connect(v), h.connect(r.detune), o.connect(r.detune), d.connect(r.detune), f.connect(s.offset), {
				osc: r,
				width: s,
				raw: c,
				pulse: l,
				level: u,
				out: p,
				pulsed: Q(g, l)
			};
		});
		C[1].out.connect(S).connect(C[0].osc.detune);
		let w = t(e.createBiquadFilter()), T = [t(e.createBiquadFilter()), t(e.createBiquadFilter())];
		w.type = "highpass", w.Q.value = -3.01;
		let E = i(0), D = i(1);
		v.connect(w).connect(T[0]), T[0].connect(E).connect(y), T[0].connect(T[1]).connect(D).connect(y), g.connect(y.gain), y.connect(l), h.connect(b), o.connect(b), _.connect(x);
		for (let e of T) e.type = "lowpass", b.connect(e.detune), x.connect(e.detune), s.connect(e.detune), p.connect(e.detune);
		return {
			note: h,
			oscillators: C,
			hpf: w,
			filters: T,
			twoPole: E,
			fourPole: D,
			ladder: er(e, {
				keep: t,
				onError: r,
				name: "AURORA"
			}, w, y, [
				b,
				x,
				s,
				p
			]),
			tracking: b,
			amount: x,
			cross: S,
			amp: $n(g.offset),
			env: $n(_.offset),
			pitched: !1,
			drift: [
				3,
				-4,
				1,
				5,
				-2,
				4,
				-5,
				2
			][u]
		};
	}), g = new xn(8), _ = {}, v = !1, y = (t, n) => {
		v ? t.setTargetAtTime(n, e.currentTime, .008) : t.value = n;
	}, b = (e, t) => {
		for (let { index: n, pending: r } of g.release(e, _.ampRelease, t)) {
			let t = h[n];
			r && fn(t.note.offset, e), t.amp.off(e, _.ampRelease), t.env.off(e, _.filterRelease);
		}
	};
	return {
		pitch: o,
		cv: s,
		output: c,
		apply(e) {
			_ = e;
			for (let t of h) {
				t.oscillators.forEach((n, r) => {
					let i = `osc${r + 1}`, a = e[`${i}Wave`];
					n.osc.type = [
						"sawtooth",
						"sawtooth",
						"triangle",
						"sine"
					][a], y(n.osc.detune, e[`${i}Octave`] * 1200 + e[`${i}Detune`] + t.drift * e.vintage * (r ? -.7 : 1)), y(n.width.offset, 2 * e[`${i}Width`] - 1), y(n.raw.gain, a === 1 ? 0 : 1), y(n.pulse.gain, +(a === 1)), n.pulsed(a === 1, !v), y(n.level.gain, r ? e.blend : 1 - e.blend);
				}), y(t.cross.gain, e.crossMod * 1800), y(t.hpf.frequency, e.hpf);
				let n = t.ladder.apply(e.filterModel === 1, {
					cutoff: e.cutoff,
					resonance: e.resonance,
					drive: ur,
					level: dr,
					mode: +(e.slope === 0),
					detune: t.drift * e.vintage * 9
				}, y);
				y(t.twoPole.gain, +(!n && e.slope === 0)), y(t.fourPole.gain, +(!n && e.slope === 1)), t.filters.forEach((n, r) => {
					y(n.frequency, e.cutoff), y(n.Q, r ? -3.01 : -3.01 + e.resonance * 17), y(n.detune, t.drift * e.vintage * 9);
				}), y(t.tracking.gain, e.tracking), y(t.amount.gain, e.envAmount * 6e3);
			}
			u.type = [
				"triangle",
				"sine",
				"square"
			][e.lfoShape], y(u.frequency, e.lfoRate), y(d.gain, e.lfoPitch * 100), y(f.gain, e.lfoWidth * .8), y(p.gain, e.lfoFilter * 2400), y(c.gain, e.level), v = !0;
		},
		noteOn(e, t, n, r) {
			b(n, r);
			let i = /* @__PURE__ */ new Set();
			for (let a of ve[_.chord]?.[1] ?? [0]) {
				let o = g.allocate(n, i), s = h[o], c = (e + a - 60) * 100;
				i.add(o), g.start(o, r, n), fn(s.note.offset, n), _.glide && s.pitched ? s.note.offset.setTargetAtTime(c, n, _.glide / 3) : s.note.offset.setValueAtTime(c, n), s.pitched = !0, s.amp.on(n, t, _.ampAttack, _.ampDecay, _.ampSustain), s.env.on(n, 1, _.filterAttack, _.filterDecay, _.filterSustain);
			}
		},
		noteOff: b,
		flush: () => Promise.all(h.map((e) => e.ladder.flush())).then(() => void 0),
		dispose: () => {
			for (let e of h) e.ladder.dispose();
		}
	};
}
//#endregion
//#region src/audio/prism.ts
function pr(e, { keep: t, onError: n }) {
	let r = t(new AudioWorkletNode(e, "rackloose-prism-v1", {
		numberOfInputs: 2,
		numberOfOutputs: 1,
		outputChannelCount: [1],
		processorOptions: { module: Bn() }
	})), i = t(e.createGain()), a = t(e.createGain());
	i.connect(r, 0, 0), a.connect(r, 0, 1);
	let o = {};
	return {
		pitch: i,
		cv: a,
		output: r,
		...Un(r, "PRISM", void 0, n),
		apply(t) {
			o = t, r.port.postMessage({
				type: "params",
				time: e.currentTime,
				params: t
			});
		},
		noteOn(e, t, n, i) {
			r.port.postMessage({
				type: "on",
				time: n,
				key: i,
				velocity: t,
				notes: (ve[o.chord]?.[1] ?? [0]).map((t) => e + t)
			});
		},
		noteOff(e, t) {
			r.port.postMessage({
				type: "off",
				time: e,
				key: t
			});
		}
	};
}
//#endregion
//#region src/audio/studio.ts
function mr(e, t, n, r) {
	let i = n(new AudioWorkletNode(e, "rackloose-studio-v1", {
		numberOfInputs: 1,
		numberOfOutputs: 1,
		outputChannelCount: [2],
		channelCount: 2,
		channelCountMode: "explicit",
		processorOptions: { type: t }
	})), a = 0;
	return {
		input: i,
		output: i,
		...Un(i, U[t].name, (e) => {
			a = e;
		}, r),
		get reduction() {
			return a;
		},
		apply(t) {
			i.port.postMessage({
				type: "params",
				time: e.currentTime,
				params: t
			});
		}
	};
}
//#endregion
//#region src/audio/sieve.ts
var hr = [
	"lowpass",
	"highpass",
	"bandpass"
], gr = [
	0,
	3,
	2
], _r = .2, vr = [
	.1,
	1,
	2.5,
	4,
	6,
	9,
	12
], yr = [
	[
		.8,
		.1,
		-.8,
		-1.3,
		-1.9,
		-2.3,
		-2
	],
	[
		-4.1,
		-4.6,
		-5.3,
		-6,
		-6.7,
		-6.9,
		-4.7
	],
	[
		-6.9,
		2,
		6.4,
		9.1,
		12.1,
		16.8,
		22.8
	]
];
function br(e, t) {
	let n = yr[e], r = 0;
	for (; r < vr.length - 2 && t > vr[r + 1];) r++;
	let i = Math.min(1, Math.max(0, (t - vr[r]) / (vr[r + 1] - vr[r])));
	return 10 ** (-(n[r] + i * (n[r + 1] - n[r])) / 20);
}
var xr = (e) => Math.min(1, Math.max(0, (e - .1) / 11.9));
function Sr(e, { keep: t, onError: n }) {
	let r = () => t(e.createGain()), i = r(), a = r(), o = r(), s = r(), c = t(e.createBiquadFilter());
	i.connect(c).connect(s).connect(o), a.connect(c.detune);
	let l = er(e, {
		keep: t,
		onError: n,
		name: "SIEVE"
	}, i, o, [a]), u = !1, d = (t, n) => {
		u ? t.setTargetAtTime(n, e.currentTime, .008) : t.value = n;
	};
	return {
		input: i,
		cv: a,
		output: o,
		apply(e) {
			c.type = hr[e.mode], d(c.frequency, e.cutoff), d(c.Q, e.resonance);
			let t = l.apply(e.filterModel === 1, {
				cutoff: e.cutoff,
				resonance: xr(e.resonance),
				drive: _r,
				level: br(e.mode, e.resonance),
				mode: gr[e.mode]
			}, d);
			d(s.gain, +!t), u = !0;
		},
		flush: l.flush,
		dispose: l.dispose
	};
}
//#endregion
//#region src/audio/rust.ts
var Cr = 4097;
function wr(e, t, n, r, i) {
	let a = 1 + 60 * t ** 2, o = .6 * n, s = .25 * i;
	return Float32Array.from({ length: Cr }, (t, n) => {
		let i = n / 4096 * 2 - 1, c = Math.sign(i) * Math.max(0, Math.abs(i) - s) / (1 - s), l = a * c + o * Math.min(1, a * Math.abs(c) * 4);
		switch (Te[e]) {
			case "Rectify": return Math.abs(Math.tanh(1.5 * l));
			case "Fold": return Math.sin(Math.PI / 2 * l);
			case "Crush": {
				let e = 2 ** (r - 1);
				return Math.round(Math.tanh(l) * e) / e;
			}
			case "Broken": return l > 0 ? Math.tanh(3 * l) : Math.max(-.3, l * 1.5);
			default: return Math.max(-1, Math.min(1, l));
		}
	});
}
function Tr(e, t) {
	let n = t(e.createGain()), r = t(e.createGain()), i = t(e.createBiquadFilter()), a = t(e.createWaveShaper()), o = t(e.createBiquadFilter()), s = t(e.createBiquadFilter()), c = t(e.createGain()), l = t(e.createGain()), u = t(e.createGain());
	i.type = "peaking", i.Q.value = 1.1, i.gain.value = 9, o.type = "highpass", o.frequency.value = 30, s.type = "lowpass", s.Q.value = .5, n.connect(c).connect(u), n.connect(r).connect(i).connect(a).connect(o).connect(s).connect(l).connect(u);
	let d = "", f = !1;
	return {
		input: n,
		cv: r.gain,
		output: u,
		apply(t) {
			let n = (t, n) => {
				f ? t.setTargetAtTime(n, e.currentTime, .01) : t.value = n;
			}, r = [
				t.mode,
				t.drive,
				t.bias,
				t.crush,
				t.starve
			].join();
			r !== d && (a.curve = wr(t.mode, t.drive, t.bias, t.crush, t.starve), a.oversample = Te[t.mode] === "Crush" ? "none" : "2x", d = r), n(i.frequency, t.body), n(s.frequency, 1500 * 12 ** t.tone), n(c.gain, 1 - t.mix), n(l.gain, t.mix * (.7 - .25 * t.drive)), n(u.gain, t.level * 1.4), f = !0;
		}
	};
}
//#endregion
//#region src/audio/processors.ts
var Er = (e) => 10 ** (e / 20), Dr = (e, t, n, r) => {
	r ? e.value = t : e.setTargetAtTime(t, n, .008);
}, Or = [
	[2e-4, .3],
	[2e-4, .45],
	[4e-4, .6],
	[4e-4, .75],
	[4e-4, .9],
	[2e-4, 1]
], kr = 24, Ar = 6;
function jr(e, t, n) {
	let r = Er(e), i = e + t, a = Er(i), o = (e) => 20 * Math.log10(e), s = (e, t) => e < r ? e : r + (1 - Math.exp(-t * (e - r))) / t, c = (e, t) => e < r ? 1 : (o(s(e * 1.001, t)) - o(s(e, t))) / (o(e * 1.001) - o(e)), l = .1, u = 1e4, d = 5;
	for (let e = 0; e < 15; e++) c(a, d) < 1 / n ? u = d : l = d, d = Math.sqrt(l * u);
	return (1 / (1 < a ? s(1, d) : Er(o(s(a, d)) + (0 - i) / n))) ** .6;
}
function Mr(e, { keep: t }) {
	let n = (n = 1) => {
		let r = t(e.createGain());
		return r.gain.value = n, r;
	}, r = (n, r, i = 0) => {
		let a = t(e.createBiquadFilter());
		return a.type = n, a.frequency.value = r, a.gain.value = i, a.Q.value = -3.01, a;
	}, i = n(), a = n(), o = t(e.createWaveShaper()), s = n(), c = .2, l = .5 * (1 - Math.tanh(c) ** 2);
	o.curve = Float32Array.from({ length: 2049 }, (e, t) => (Math.tanh(2 * (t / 1024 - 1) + c) - Math.tanh(c)) / l), o.oversample = "2x";
	let u = t(e.createDynamicsCompressor());
	u.knee.value = kr, u.ratio.value = Ar, i.connect(a).connect(o).connect(r("highpass", 12)).connect(r("lowshelf", 90, 1)).connect(r("highshelf", 9e3, -1)).connect(u).connect(s);
	let d = !0, f = NaN, p = 1;
	return {
		input: i,
		output: s,
		compressor: u,
		apply(t) {
			let n = e.currentTime, [r, i] = Or[t.time] ?? Or[1];
			f !== t.threshold && (f = t.threshold, p = jr(t.threshold, kr, Ar)), Dr(a.gain, Er(t.input) / 4, n, d), Dr(u.threshold, t.threshold, n, d), u.attack.value = r, u.release.value = i, Dr(s.gain, Er(t.output) / p, n, d), d = !1;
		}
	};
}
function Nr(e, t) {
	return [
		{
			type: "highpass",
			frequency: e.hpf <= 16 ? 0 : e.hpf,
			Q: -3.01,
			gain: 0
		},
		{
			type: e.lfBell ? "peaking" : "lowshelf",
			frequency: e.lfFreq,
			Q: .7,
			gain: e.lfGain
		},
		{
			type: "peaking",
			frequency: e.lmfFreq,
			Q: e.lmfQ,
			gain: e.lmfGain
		},
		{
			type: "peaking",
			frequency: e.hmfFreq,
			Q: e.hmfQ,
			gain: e.hmfGain
		},
		{
			type: e.hfBell ? "peaking" : "highshelf",
			frequency: e.hfFreq,
			Q: .7,
			gain: e.hfGain
		},
		{
			type: "lowpass",
			frequency: e.lpf >= 22e3 ? t : Math.min(e.lpf, t),
			Q: -3.01,
			gain: 0
		}
	];
}
function Pr({ type: e, frequency: t, Q: n, gain: r }, i, a) {
	let o = a / 2;
	if (e === "highpass" && t <= 0 || e === "lowpass" && t >= o) return 0;
	let s = 10 ** (r / 40), c = 2 * Math.PI * t / a, l = Math.cos(c), u = Math.sin(c), d = u / (2 * 10 ** (n / 20)), f = u / (2 * n), p = u / 2 * Math.SQRT2 * 2 * Math.sqrt(s), [m, h, g, _, v, y] = {
		lowpass: [
			(1 - l) / 2,
			1 - l,
			(1 - l) / 2,
			1 + d,
			-2 * l,
			1 - d
		],
		highpass: [
			(1 + l) / 2,
			-(1 + l),
			(1 + l) / 2,
			1 + d,
			-2 * l,
			1 - d
		],
		peaking: [
			1 + f * s,
			-2 * l,
			1 - f * s,
			1 + f / s,
			-2 * l,
			1 - f / s
		],
		lowshelf: [
			s * (s + 1 - (s - 1) * l + p),
			2 * s * (s - 1 - (s + 1) * l),
			s * (s + 1 - (s - 1) * l - p),
			s + 1 + (s - 1) * l + p,
			-2 * (s - 1 + (s + 1) * l),
			s + 1 + (s - 1) * l - p
		],
		highshelf: [
			s * (s + 1 + (s - 1) * l + p),
			-2 * s * (s - 1 + (s + 1) * l),
			s * (s + 1 + (s - 1) * l - p),
			s + 1 - (s - 1) * l + p,
			2 * (s - 1 - (s + 1) * l),
			s + 1 - (s - 1) * l - p
		]
	}[e] ?? [
		1,
		0,
		0,
		1,
		0,
		0
	], b = 2 * Math.PI * i / a, x = Math.cos(b), S = Math.sin(b), C = Math.cos(2 * b), w = Math.sin(2 * b), T = (e, t, n) => Math.hypot(e + t * x + n * C, t * S + n * w);
	return 20 * Math.log10(T(m, h, g) / T(_, v, y));
}
function Fr(e, { keep: t }) {
	let n = (n = 1) => {
		let r = t(e.createGain());
		return r.gain.value = n, r;
	}, r = n(), i = n(), a = n(0), o = n(), s = e.sampleRate / 2, c = Array.from({ length: 6 }, () => t(e.createBiquadFilter()));
	c.reduce((e, t) => e.connect(t), r).connect(i).connect(o), r.connect(a).connect(o);
	let l = !0;
	return {
		input: r,
		output: o,
		apply(t) {
			let n = e.currentTime;
			Nr(t, s).forEach((e, t) => {
				let r = c[t];
				r.type !== e.type && (r.type = e.type), e.frequency <= 0 || e.frequency >= s ? (r.frequency.cancelScheduledValues(n), r.frequency.setValueAtTime(e.frequency, n)) : Dr(r.frequency, e.frequency, n, l), Dr(r.Q, e.Q, n, l), Dr(r.gain, e.gain, n, l);
			}), Dr(i.gain, +!t.active, n, l), Dr(a.gain, +!!t.active, n, l), Dr(o.gain, Er(t.output), n, l), l = !1;
		}
	};
}
//#endregion
//#region src/audio/session.ts
function Ir() {
	let e = typeof navigator > "u" ? void 0 : navigator.audioSession;
	if (!e || e.type === "playback") return () => {};
	let t = e.type;
	return e.type = "playback", () => {
		e.type === "playback" && (e.type = t);
	};
}
//#endregion
//#region src/audio/engine.ts
var Lr = [
	"sine",
	"triangle",
	"sawtooth",
	"square"
], Rr = (e, t) => `${e}:${t}`, zr = (e, t, n) => {
	e.setTargetAtTime(t, n, .008);
}, Br = .5, Vr = .09;
function Hr({ analyser: e, data: t }) {
	e.getFloatTimeDomainData(t);
	let n = 0;
	for (let e of t) n = Math.max(n, Math.abs(e));
	return n > 0 ? Math.max(-60, 20 * Math.log10(n)) : -60;
}
function Ur(e, t = 0, n = 2, r = !1, i = 0) {
	let a = e.createBuffer(r ? 2 : 1, Math.ceil(e.sampleRate * n), e.sampleRate), o = 90210;
	for (let n = 0; n < a.numberOfChannels; n++) {
		let r = a.getChannelData(n), s = 0;
		for (let n = 0; n < r.length; n++) {
			o ^= o << 13, o ^= o >>> 17, o ^= o << 5;
			let a = (o >>> 0) / 2 ** 31 - 1;
			s = t === 1 ? .93 * s + .2 * a : t === 2 ? (s + .035 * a) / 1.035 : a, r[n] = s * (i ? Math.exp(-n / e.sampleRate / i * 5) : 1);
		}
	}
	return a;
}
var Wr = "seq", Gr = "manual", Kr = class {
	context;
	onError;
	master;
	nodes = [];
	sources = [];
	started = !1;
	runtime = /* @__PURE__ */ new Map();
	outputs = /* @__PURE__ */ new Map();
	inputs = /* @__PURE__ */ new Map();
	cvAmounts = /* @__PURE__ */ new Map();
	notes = /* @__PURE__ */ new Map();
	white = null;
	mix = dt;
	open = {};
	muted = !1;
	manualTarget = null;
	manualOwned = /* @__PURE__ */ new Set();
	targets = /* @__PURE__ */ new Map();
	pulses = /* @__PURE__ */ new Map();
	patch;
	constructor(e, t, n = e.destination, r = dt, i) {
		this.context = e, this.onError = i, this.patch = t, this.master = this.keep(e.createGain());
		let a = this.keep(e.createDynamicsCompressor());
		a.threshold.value = -12, a.knee.value = 12, a.ratio.value = 8, a.attack.value = .003, a.release.value = .15, this.master.connect(a).connect(n);
		for (let e of t.modules) this.buildModule(e);
		for (let e of t.modules) e.type === "performance" && this.targets.set(e.id, gt(t, e.id));
		for (let n of t.cables) {
			let r = this.outputs.get(Rr(n.from.moduleId, n.from.portId)), i = this.inputs.get(Rr(n.to.moduleId, n.to.portId));
			if (!r || !i || this.isNoteCable(n)) continue;
			let a = U[t.modules.find((e) => e.id === n.to.moduleId).type].ports.find((e) => e.id === n.to.portId);
			if (a.kind === "cv") {
				let t = this.keep(e.createGain());
				t.gain.value = n.amount * (a.scale ?? 1), r.connect(t), "setValueAtTime" in i, t.connect(i), this.cvAmounts.set(n.id, t);
			} else "setValueAtTime" in i, r.connect(i);
		}
		this.applyPatch(t, !0), this.setMix(r, !0);
		for (let e of this.sources) e.start(0);
		this.started = !0;
	}
	keep(e) {
		return this.nodes.push(e), e;
	}
	isNoteCable(e) {
		return e.to.portId === "pitch" && ot(this.patch.modules.find((t) => t.id === e.to.moduleId).type) && this.patch.modules.find((t) => t.id === e.from.moduleId)?.type === "performance";
	}
	polyNote(e, t, n, r) {
		let i = this.patch.cables.find((t) => t.to.moduleId === e && this.isNoteCable(t));
		return i ? 60 + ((i.from.moduleId === t ? n : this.noteAt(i.from.moduleId, r)) - 60) * i.amount : 60;
	}
	noteAt(e, t) {
		let n = this.notes.get(e) ?? [];
		for (let e = n.length - 1; e >= 0; e--) if (n[e].time <= t) return n[e].note;
		return 48;
	}
	get main() {
		return this.patch.modules[0].id;
	}
	gain(e = 1) {
		let t = this.keep(this.context.createGain());
		return t.gain.value = e, t;
	}
	source(e) {
		return "offset" in e && dn(e.offset, this.context), this.started && e.start(this.context.currentTime), this.keep(e), this.sources.push(e), e;
	}
	buildModule(e) {
		let { context: t } = this, n = (t) => Rr(e.id, t), r = (e, t) => this.inputs.set(n(e), t), i = this.gain(), a = (e, t, r = !0) => this.outputs.set(n(e), r ? t.connect(i) : t), o = !1, s = (e, n) => {
			o ? zr(e, n, t.currentTime) : e.value = n;
		}, c = () => {}, l, u, d, f, p, m, h, g, _, v, y, b = (e) => {
			p = this.source(t.createConstantSource()), p.offset.value = 0;
			let n = this.gain(1200);
			p.connect(n), "setValueAtTime" in e, n.connect(e);
		};
		switch (e.type) {
			case "performance":
				l = this.source(t.createConstantSource()), l.offset.value = -1, a("pitch", l, !1);
				break;
			case "oscillator": {
				let e = this.source(t.createOscillator()), n = this.gain();
				e.frequency.value = 261.625565, e.connect(n), r("pitch", e.detune), b(e.detune), r("fm", e.detune), a("out", n), c = (t) => {
					e.type = Lr[t.wave], s(e.detune, t.octave * 1200 + t.tune * 100 + t.fine), s(n.gain, t.level * .35);
				};
				break;
			}
			case "monarch":
				this.white ??= Ur(t, 0, 1), f = ir(t, this.white, {
					onError: this.onError,
					keep: (e) => this.keep(e),
					source: (e) => this.source(e)
				}), r("pitch", f.pitch), b(f.pitch), r("cv", f.cv), a("out", f.output), c = f.apply;
				break;
			case "oracle":
			case "aurora":
			case "prism": {
				this.white ??= Ur(t, 0, 1);
				let n = {
					onError: this.onError,
					keep: (e) => this.keep(e),
					source: (e) => this.source(e)
				};
				g = e.type === "oracle" ? lr(t, this.white, n) : e.type === "aurora" ? fr(t, n) : pr(t, n), r("pitch", g.pitch), r("cv", g.cv), a("out", g.output), c = g.apply;
				break;
			}
			case "compressor":
				_ = Mr(t, { keep: (e) => this.keep(e) }), r("in", _.input), a("out", _.output), c = _.apply;
				break;
			case "cohere":
			case "talon":
			case "brit":
				m = mr(t, e.type, (e) => this.keep(e), this.onError), r("in", m.input), a("out", m.output), c = m.apply;
				break;
			case "equalizer": {
				let e = Fr(t, { keep: (e) => this.keep(e) });
				r("in", e.input), a("out", e.output), c = e.apply;
				break;
			}
			case "noise": {
				let n = this.source(t.createBufferSource()), r = this.gain();
				n.buffer = Ur(t, e.params.color), n.loop = !0, n.connect(r), a("out", r), c = (e) => s(r.gain, e.level * .3);
				break;
			}
			case "mixer": {
				let e = () => {
					let e = this.keep(t.createAnalyser());
					return e.fftSize = 512, {
						analyser: e,
						data: new Float32Array(e.fftSize)
					};
				}, n = this.gain(), i = this.gain(), o = this.keep(t.createChannelSplitter(2));
				y = {
					channels: [],
					bus: [e(), e()]
				}, n.connect(i).connect(o), y.bus.forEach(({ analyser: e }, t) => o.connect(e, t));
				let l = xe.map((i, a) => {
					let o = this.gain(), s = this.gain(), c = e(), l = [this.gain(), this.gain()], u = this.gain(), d = this.keep(t.createChannelSplitter(2)), f = this.keep(t.createChannelMerger(2));
					return u.channelCount = 2, u.channelCountMode = "explicit", u.channelInterpretation = "speakers", o.connect(s).connect(u).connect(d), s.connect(c.analyser), l.forEach((e, t) => d.connect(e, t).connect(f, 0, t)), f.connect(n), r(i, o), y.channels.push(c), {
						id: xe[a],
						level: o,
						gate: s,
						sides: l
					};
				});
				v = Object.fromEntries(l.map(({ id: e, gate: t }) => [e, t])), a("out", i), c = (e) => {
					for (let { id: t, level: n, sides: [r, i] } of l) {
						let a = e[Se(t)];
						s(n.gain, e[t]), s(r.gain, a > 0 ? Math.cos(a * Math.PI / 2) : 1), s(i.gain, a < 0 ? Math.cos(-a * Math.PI / 2) : 1);
					}
					s(i.gain, e.master);
				};
				break;
			}
			case "filter":
				h = Sr(t, {
					keep: (e) => this.keep(e),
					onError: this.onError
				}), r("in", h.input), r("cv", h.cv), a("out", h.output), c = h.apply;
				break;
			case "amplifier": {
				let t = this.gain(), n = this.gain();
				t.connect(n), t.gain.value = +!this.patch.cables.some((t) => t.to.moduleId === e.id && t.to.portId === "cv"), r("in", t), r("cv", t.gain), a("out", n), c = (e) => s(n.gain, e.level);
				break;
			}
			case "envelope": {
				let e = this.source(t.createConstantSource());
				e.offset.value = 0, a("out", e), u = $n(e.offset);
				break;
			}
			case "lfo": {
				let e = this.source(t.createOscillator());
				r("cv", e.frequency), a("out", e), c = (t) => {
					e.type = Lr[t.wave], s(e.frequency, t.rate);
				};
				break;
			}
			case "delay": {
				let e = this.gain(), n = this.gain(), i = this.gain(), o = this.gain(), l = this.keep(t.createDelay(1)), u = this.gain();
				e.connect(i).connect(n), e.connect(l).connect(o).connect(n), l.connect(u).connect(l), r("in", e), a("out", n), c = (e) => {
					s(l.delayTime, e.time), s(u.gain, e.feedback), s(i.gain, 1 - e.mix), s(o.gain, e.mix);
				};
				break;
			}
			case "reverb": {
				let e = this.gain(), n = this.gain(), i = this.gain(), o = this.gain(), l = this.keep(t.createConvolver());
				e.connect(i).connect(n), e.connect(l).connect(o).connect(n), r("in", e), a("out", n);
				let u = -1;
				c = (e) => {
					u !== e.decay && (l.buffer = Ur(t, 0, e.decay, !0, e.decay), u = e.decay), s(i.gain, 1 - e.mix), s(o.gain, e.mix);
				};
				break;
			}
			case "boom":
			case "punch":
			case "orbit":
			case "strike":
			case "forge": {
				let n = this.gain(), o = this.gain(), l = this.gain(), u = this.gain();
				n.connect(o).connect(i).connect(u), l.connect(u), r("chain", l), a("out", u, !1), this.white ??= Ur(t, 0, 1);
				let f = e.type === "forge" ? jn(t, n, (e) => this.keep(e)) : void 0;
				d = Qn(t, e.type, n, {
					keep: (e) => this.keep(e),
					start: (e) => this.source(e),
					noise: this.white,
					onError: this.onError
				}, f), c = (e) => {
					f?.apply(e), s(o.gain, e.level * Br);
				};
				break;
			}
			case "rust": {
				let e = Tr(t, (e) => this.keep(e));
				r("in", e.input), r("cv", e.cv), a("out", e.output), c = e.apply;
				break;
			}
			case "output": r("in", this.master), c = (e) => s(this.master.gain, this.muted ? 0 : e.volume * .8);
		}
		for (let t of U[e.type].ports) {
			let e = t.copyOf && this.outputs.get(n(t.copyOf));
			e && this.outputs.set(n(t.id), e);
		}
		this.runtime.set(e.id, {
			module: e,
			apply: (e) => {
				c(e), o = !0;
			},
			gate: i,
			channels: v,
			meters: y,
			pitch: l,
			envelope: u,
			drums: d,
			monarch: f,
			sieve: h,
			poly: g,
			valve: _,
			studio: m,
			manualPitch: p
		});
	}
	applyPatch(e, t = !1) {
		for (let n of e.modules) {
			let e = this.runtime.get(n.id);
			e && (t || JSON.stringify(e.module.params) !== JSON.stringify(n.params)) && (e.apply(n.params), e.module = n);
		}
		for (let n of e.cables) {
			let r = this.cvAmounts.get(n.id);
			if (r && (t || this.patch.cables.find((e) => e.id === n.id)?.amount !== n.amount)) {
				let t = e.modules.find((e) => e.id === n.to.moduleId), i = U[t.type].ports.find((e) => e.id === n.to.portId)?.scale ?? 1;
				zr(r.gain, this.manualTarget === n.to.moduleId && n.to.portId === "pitch" && !ot(t.type) ? 0 : n.amount * i, this.context.currentTime);
			}
		}
		this.patch = e;
	}
	gatedBy(e) {
		let t = new Set(this.patch.cables.filter((t) => t.from.moduleId === e && G(this.patch, t.from)?.kind === "gate").map((e) => e.to.moduleId));
		return [...this.runtime.values()].filter((e) => (e.envelope || e.monarch || e.poly) && t.has(e.module.id));
	}
	setMix(e, t = !1) {
		this.mix = e, this.open = _t(this.patch, e);
		let n = (e, n) => {
			t ? e.gain.value = +!!n : zr(e.gain, +!!n, this.context.currentTime);
		};
		for (let { module: t, gate: r, channels: i } of this.runtime.values()) {
			n(r, this.open[t.id] !== !1);
			for (let [r, a] of Object.entries(i ?? {})) n(a, Y(t, r, e));
		}
	}
	openEnvelope(e, t, n, r, i, a) {
		if (e.monarch) {
			e.monarch.noteOn(t, n);
			return;
		}
		if (e.poly) {
			e.poly.noteOn(this.polyNote(e.module.id, a, r, n), t, n, i);
			return;
		}
		let o = e.module.params;
		e.envelope?.on(n, t, o.attack, o.decay, o.sustain);
	}
	closeEnvelope(e, t, n) {
		e.monarch && e.monarch.noteOff(t), e.poly?.noteOff(t, n), e.envelope?.off(t, e.module.params.release);
	}
	setNote(e, t, n) {
		let r = this.runtime.get(e)?.pitch;
		r && (r.offset.cancelScheduledValues(n), r.offset.setValueAtTime((t - 60) / 12, n), this.notes.set(e, [...(this.notes.get(e) ?? []).filter((e) => e.time < n).slice(-63), {
			time: n,
			note: t
		}]));
	}
	gateOn(e, t, n, r) {
		if (this.open[e] !== !1) for (let i of this.gatedBy(e)) this.manualOwned.has(i.module.id) || this.openEnvelope(i, n, r, t, Wr, e);
	}
	noteOn(e, t = 1, n = this.context.currentTime, r = this.main) {
		this.manualTarget !== r && (this.setNote(r, e, n), this.gateOn(r, e, t, n));
	}
	noteOff(e = this.context.currentTime, t = this.main) {
		for (let n of this.gatedBy(t)) this.manualOwned.has(n.module.id) || this.closeEnvelope(n, e, Wr);
	}
	sequence(e, t, n, r) {
		let i = t % 16, a = e.filter((e) => e !== this.manualTarget).flatMap((e) => {
			let t = Ve(this.patch, e)[i], a = this.runtime.get(e)?.module.params.lag;
			return t?.enabled && yt(e, i, this.mix) ? [{
				id: e,
				step: t,
				at: this.lagged(n, a),
				end: this.lagged(n + r * t.gate, a)
			}] : [];
		});
		for (let { id: e, step: t, at: n } of a) this.setNote(e, t.note, n);
		for (let { id: e, step: t, at: n, end: r } of a) if (this.gateOn(e, t.note, t.velocity, n), this.noteOff(r, e), this.open[e] !== !1) for (let t of this.targets.get(e) ?? []) this.pulse(t, n, e);
	}
	lagged(e, t = 0) {
		return Math.max(this.context.currentTime, e + t / 1e3);
	}
	pulse(e, t, n) {
		this.pulses.set(e, [...(this.pulses.get(e) ?? []).slice(-63), {
			time: t,
			sequencer: n
		}]);
	}
	lastPulse(e, t) {
		let n = this.pulses.get(e);
		if (!n) return -1;
		let r = n.length - 1;
		for (; r >= 0 && n[r].time > t;) r--;
		return r > 0 && n.splice(0, r), r < 0 ? -1 : n[0].time;
	}
	mixerLevels(e) {
		let t = this.runtime.get(e)?.meters;
		return t ? {
			channels: t.channels.map(Hr),
			bus: t.bus.map(Hr)
		} : null;
	}
	manualOn(e, t, n = Gr) {
		this.manualTarget !== e && this.manualOff();
		let r = this.runtime.get(e), i = this.context.currentTime;
		if (r) {
			if (this.manualTarget = e, r.poly) {
				this.manualOwned = /* @__PURE__ */ new Set([e]), r.poly.noteOff(i, Wr), r.poly.noteOn(t, 1, i, n);
				return;
			}
			if (r.module.type === "performance") {
				if (this.manualOwned = new Set(this.gatedBy(e).map((e) => e.module.id)), this.setNote(e, t, i), this.open[e] === !1) return;
			} else {
				let n = ct(this.patch, e);
				this.manualOwned = new Set(r.monarch ? [e] : this.patch.cables.filter((e) => n.has(e.to.moduleId) && this.runtime.get(e.from.moduleId)?.envelope).map((e) => e.from.moduleId));
				for (let t of this.patch.cables) t.to.moduleId === e && t.to.portId === "pitch" && this.cvAmounts.get(t.id)?.gain.setValueAtTime(0, i);
				r.manualPitch?.offset.setValueAtTime((t - 60) / 12, i);
			}
			for (let n of this.manualOwned) {
				let r = this.runtime.get(n);
				r.poly?.noteOff(i, Wr), this.openEnvelope(r, 1, i, t, Gr, e);
			}
		}
	}
	manualRelease(e) {
		this.runtime.get(this.manualTarget ?? "")?.poly?.noteOff(this.context.currentTime, e);
	}
	manualOff() {
		let e = this.context.currentTime, t = this.manualTarget;
		for (let t of this.manualOwned) {
			let n = this.runtime.get(t);
			n && this.closeEnvelope(n, e);
		}
		this.runtime.get(t ?? "")?.manualPitch?.offset.setValueAtTime(0, e);
		for (let n of this.patch.cables) n.to.moduleId === t && n.to.portId === "pitch" && this.cvAmounts.get(n.id)?.gain.setValueAtTime(n.amount * 1200, e);
		this.manualOwned.clear(), this.manualTarget = null;
	}
	reduction(e) {
		return this.runtime.get(e)?.studio?.reduction ?? this.runtime.get(e)?.valve?.compressor.reduction ?? 0;
	}
	drumStep(e, t, n) {
		for (let { module: r, drums: i } of this.runtime.values()) {
			let a = r.type === "skitter";
			if (!(i || a) || n && r.id !== n || a && this.open[r.id] === !1) continue;
			let o = tt(r, e).filter(([e]) => Y(r, e, this.mix)), s = Gt(this.patch.sequencer.bpm, this.patch.sequencer.swing, e % 16), c = (e) => e > 2 ? r.params.rollFade ?? 0 : 0;
			for (let [e, n] of o) for (let o = 0; o < n; o++) {
				let l = t + o * s / n, u = 1 - c(n) * o / n;
				a ? this.skitterHit(r, e, l, u, s / n) : i.trigger(e, this.lagged(l, r.params[`${e}Lag`]), r.params, u);
			}
			o.length && this.pulse(r.id, t, r.id);
		}
	}
	skitterTargets(e, t) {
		return this.patch.cables.filter((n) => n.from.moduleId === e && (G(this.patch, n.from)?.copyOf ?? n.from.portId) === t).map((e) => this.runtime.get(e.to.moduleId)).filter((e) => !!e);
	}
	skitterHit(e, t, n, r, i) {
		if (t === "synth") for (let t of this.skitterTargets(e.id, "gate")) !this.manualOwned.has(t.module.id) && (t.envelope || t.monarch || t.poly) && (this.openEnvelope(t, r, n, 60, Wr, e.id), this.closeEnvelope(t, n + i * (e.params.gate ?? .5), Wr), this.pulse(t.module.id, n, e.id));
		else for (let i of this.skitterTargets(e.id, "trig")) {
			let a = R[i.module.type]?.[t];
			a && i.drums && Y(i.module, a, this.mix) && (i.drums.trigger(a, this.lagged(n, i.module.params[`${a}Lag`]), i.module.params, r), this.pulse(i.module.id, n, e.id));
		}
	}
	skitterKits(e) {
		return this.patch.modules.some((t) => t.id === e && t.type === "skitter") ? this.skitterTargets(e, "trig").filter((e) => e.drums).map((e) => e.module.id) : [];
	}
	hit(e, t, n = this.context.currentTime) {
		let r = this.runtime.get(e);
		r && Y(r.module, t, this.mix) && (r.module.type === "skitter" ? this.open[e] !== !1 && this.skitterHit(r.module, t, n, 1, .12) : r.drums?.trigger(t, n, r.module.params));
	}
	cancelModule(e, t = this.context.currentTime) {
		let n = this.runtime.get(e);
		for (let [n, r] of this.pulses) this.pulses.set(n, r.filter((n) => n.sequencer !== e || n.time <= t));
		if (n?.drums && n.drums.cancelScheduled(t), n?.module.type === "skitter") {
			for (let n of this.skitterKits(e)) this.runtime.get(n).drums.cancelScheduled(t);
			for (let n of this.gatedBy(e)) this.manualOwned.has(n.module.id) || this.closeEnvelope(n, t, Wr);
		}
		n?.pitch && (this.noteOff(t, e), this.manualTarget !== e && (fn(n.pitch.offset, t), this.notes.set(e, (this.notes.get(e) ?? []).filter((e) => e.time <= t))));
	}
	cancelScheduled(e = this.context.currentTime) {
		for (let t of this.patch.modules) st(t.type) && this.cancelModule(t.id, e);
	}
	setMute(e) {
		this.muted = e, zr(this.master.gain, e ? 0 : this.patch.modules.find((e) => e.type === "output").params.volume * .8, this.context.currentTime);
	}
	async flush() {
		await Promise.all([...this.runtime.values()].map((e) => Promise.all([
			e.poly?.flush?.(),
			e.studio?.flush(),
			e.monarch?.flush(),
			e.sieve?.flush(),
			e.drums?.flush?.()
		])));
	}
	dispose() {
		for (let { poly: e, studio: t, monarch: n, sieve: r } of this.runtime.values()) e?.dispose?.(), t?.dispose(), n?.dispose(), r?.dispose();
		this.master.gain.cancelScheduledValues(this.context.currentTime), this.master.gain.value = 0;
		for (let { drums: e } of this.runtime.values()) e?.dispose();
		for (let e of this.sources) e.stop();
		for (let e of this.nodes) e.disconnect();
		this.sources = [], this.nodes = [];
	}
}, qr = (e) => JSON.stringify({
	modules: e.modules.map((e) => [
		e.id,
		e.type,
		e.type === "noise" ? e.params.color : null
	]).sort(),
	cables: e.cables.map((e) => [
		e.id,
		e.from,
		e.to
	]).sort()
}), Jr = class {
	patch;
	onError;
	context = null;
	graph = null;
	analyser = null;
	timer = null;
	notes = new Wt();
	target = null;
	running = /* @__PURE__ */ new Map();
	nextTime = 0;
	count = 0;
	timeline = [];
	frozen = -1;
	remaining = .04;
	muted = !1;
	mix = dt;
	suspended = !1;
	disposed = !1;
	revision = 0;
	manualRevision = 0;
	transportRevision = 0;
	moduleRevisions = /* @__PURE__ */ new Map();
	releaseSession = null;
	inputs = /* @__PURE__ */ new Map();
	held = /* @__PURE__ */ new Map();
	playing = !1;
	constructor(e, t) {
		this.patch = e, this.onError = t;
	}
	get activeNote() {
		return this.notes.current;
	}
	get activeNotes() {
		return this.poly ? this.notes.entries.map(([, e]) => e) : this.notes.current === null ? [] : [this.notes.current];
	}
	get poly() {
		let e = this.patch.modules.find((e) => e.id === this.target)?.type;
		return !!e && ot(e);
	}
	reduction(e) {
		return this.ready ? this.graph.reduction(e) : 0;
	}
	get sampleRate() {
		return this.context?.sampleRate ?? 48e3;
	}
	get ready() {
		return !!this.graph && this.context?.state === "running";
	}
	get sounding() {
		let e = this.context?.currentTime ?? 0;
		for (; this.timeline.length > 1 && this.timeline[1].time <= e;) this.timeline.shift();
		return this.playing && this.timeline[0]?.time <= e ? this.timeline[0] : null;
	}
	get clock() {
		return this.sounding?.count ?? this.frozen;
	}
	get step() {
		return this.clock < 0 ? -1 : this.clock % 16;
	}
	modulePlaying(e) {
		return this.playing && this.running.has(e);
	}
	moduleClock(e) {
		let t = this.clock;
		return this.running.has(e) && t >= this.running.get(e) ? t : -1;
	}
	pulsing(e) {
		if (!this.graph || !this.context || !this.ready) return !1;
		let t = this.context.currentTime - (this.context.outputLatency || 0), n = this.graph.lastPulse(e, t);
		return n >= 0 && t - n < Vr;
	}
	mixerLevels(e) {
		let t = {
			channels: xe.map(() => -60),
			bus: [-60, -60]
		}, n = this.graph && this.ready ? this.graph.mixerLevels(e) : null;
		if (!n || !this.context) return this.held.delete(e), t;
		let r = this.context.currentTime, i = this.held.get(e), a = i ? (r - i.time) * 24 : 0, o = (e, t, n) => Math.max(e, n ? n[t] - a : -60), s = {
			channels: n.channels.map((e, t) => o(e, t, i?.levels.channels)),
			bus: n.bus.map((e, t) => o(e, t, i?.levels.bus))
		};
		return this.held.set(e, {
			time: r,
			levels: s
		}), s;
	}
	get meter() {
		if (!this.analyser || !this.ready) return 0;
		let e = new Float32Array(this.analyser.fftSize);
		return this.analyser.getFloatTimeDomainData(e), Math.min(1, Math.sqrt(e.reduce((e, t) => e + t * t, 0) / e.length) * 6);
	}
	async unlock() {
		if (this.suspended || this.disposed) return !1;
		let e = this.revision;
		if (!this.context) {
			if (typeof AudioContext > "u") throw Error("Web Audio is unavailable in this browser. Try a current Chrome or Safari.");
			this.releaseSession = Ir(), this.context = new AudioContext({ latencyHint: "interactive" }), this.analyser = this.context.createAnalyser(), this.analyser.fftSize = 256, this.analyser.connect(this.context.destination);
		}
		let t = this.context;
		if (await t.resume(), this.disposed || this.suspended || e !== this.revision) return !1;
		try {
			await Hn(t);
		} catch (t) {
			if (this.disposed || this.suspended || e !== this.revision) return !1;
			throw t;
		}
		return this.disposed || this.suspended || e !== this.revision ? !1 : (this.graph || (this.graph = new Kr(this.context, this.patch, this.analyser, this.mix, (e) => {
			this.panic(), this.onError?.(e);
		}), this.graph.setMute(this.muted)), !0);
	}
	unlockForInput(e, t = !1) {
		return e === void 0 ? this.unlock() : (this.inputs.get(e)?.cancel(), new Promise((n, r) => {
			let i = () => {
				this.inputs.get(e) === a && this.inputs.delete(e);
			}, a = {
				started: !1,
				cancel: () => {
					i(), n(!1);
				},
				start: (e) => {
					a.started = !0, e.then((e) => {
						i(), n(e);
					}, (e) => {
						i(), r(e);
					});
				}
			};
			this.inputs.set(e, a), (!t || this.ready) && a.start(this.unlock());
		}));
	}
	lifted(e) {
		if (e !== void 0 && !this.inputs.has(e)) return;
		let t = [...this.inputs.values()].filter((e) => !e.started);
		if (!t.length) return;
		let n = this.unlock();
		for (let e of t) e.start(n);
	}
	update(e) {
		let t = qr(e) !== qr(this.patch);
		this.patch = e;
		for (let t of this.running.keys()) e.modules.some((e) => e.id === t && st(e.type)) || this.running.delete(t);
		if (this.target && !e.modules.some((e) => e.id === this.target) && this.releaseManual(), this.playing && !this.running.size && this.pause(), this.graph && this.context) {
			if (t) {
				if (this.graph.dispose(), this.graph = new Kr(this.context, e, this.analyser, this.mix, (e) => {
					this.panic(), this.onError?.(e);
				}), this.graph.setMute(this.muted), this.target && this.poly) for (let [e, t] of this.notes.entries) this.graph.manualOn(this.target, t, e);
				else this.notes.current !== null && this.target && this.graph.manualOn(this.target, this.notes.current);
				for (let e of this.timeline) e.time >= this.context.currentTime && this.schedule([...this.running.keys()], e);
			} else this.graph.applyPatch(e);
		}
	}
	async press(e, t, n = this.patch.modules[0].id, r = !1) {
		if (this.suspended || this.disposed) return;
		n !== this.target && this.releaseManual(), this.target = n, this.notes.press(e, t);
		let i = this.manualRevision, a = !this.ready;
		await this.unlockForInput(e, r) && i === this.manualRevision && this.target === n && (this.poly ? this.notes.has(e) ? this.graph.manualOn(n, t, e) : a && this.tap(n, t, e) : this.notes.current === null ? a && this.tap(n, t) : this.graph.manualOn(n, this.notes.current));
	}
	tap(e, t, n) {
		let r = this.manualRevision;
		this.graph.manualOn(e, t, n), setTimeout(() => {
			r === this.manualRevision && this.target === e && this.graph && (n === void 0 ? this.notes.current === null && this.graph.manualOff() : this.notes.has(n) || this.graph.manualRelease(n));
		}, 150);
	}
	release(e) {
		if (this.poly) {
			if (!this.notes.has(e)) return;
			this.notes.release(e) === null ? this.graph?.manualOff() : this.graph?.manualRelease(e);
			return;
		}
		let t = this.notes.current, n = this.notes.release(e);
		t !== n && (n !== null && this.target ? this.graph?.manualOn(this.target, n) : this.graph?.manualOff());
	}
	async hit(e, t, n, r = !1) {
		if (this.suspended || this.disposed) return;
		let i = this.manualRevision;
		await this.unlockForInput(n, r) && i === this.manualRevision && this.graph.hit(e, t);
	}
	cancel(e) {
		this.inputs.get(e)?.cancel(), this.release(e);
	}
	releaseManual() {
		this.manualRevision++, this.notes.clear(), this.graph?.manualOff(), this.target = null;
		for (let e of this.inputs.values()) e.cancel();
	}
	schedule(e, t) {
		if (!this.graph) return;
		let n = e.filter((e) => this.patch.modules.some((t) => t.id === e && t.type === "performance"));
		this.graph.sequence(n, t.count, t.time, t.duration);
		for (let r of e) n.includes(r) || this.graph.drumStep(t.count, t.time, r);
	}
	startClock() {
		this.playing = !0, this.nextTime = this.context.currentTime + Math.max(.01, this.remaining), this.timeline = [], this.tick(), this.timer = setInterval(() => this.tick(), 25);
	}
	async play(e) {
		let t = this.transportRevision, n = this.patch.modules.filter((t) => st(t.type) && (!e || t.id === e)).map((e) => ({
			id: e.id,
			revision: this.moduleRevisions.get(e.id)
		}));
		if (!await this.unlock() || t !== this.transportRevision) return;
		let r = n.filter((e) => e.revision === this.moduleRevisions.get(e.id) && this.patch.modules.some((t) => t.id === e.id)).map((e) => e.id);
		if (r.length) {
			if (this.playing) {
				let e = this.timeline.filter((e) => e.time > this.context.currentTime);
				for (let t of r) if (!this.running.has(t)) {
					this.running.set(t, e[0]?.count ?? this.count);
					for (let n of e) this.schedule([t], n);
				}
			} else {
				this.running.clear();
				for (let e of r) this.running.set(e, this.count);
				this.startClock();
			}
		}
	}
	stopModule(e) {
		let t = this.graph?.skitterKits(e) ?? [];
		if (this.moduleRevisions.set(e, (this.moduleRevisions.get(e) ?? 0) + 1), this.running.delete(e), this.graph?.cancelModule(e), t.length && this.graph && this.context) {
			let e = [...this.running.keys()].filter((e) => t.includes(e) || this.graph.skitterKits(e).some((e) => t.includes(e)));
			for (let t of this.timeline) t.time >= this.context.currentTime && this.schedule(e, t);
		}
		this.running.size || this.pause();
	}
	tick() {
		if (this.context && this.graph && this.playing) for (; this.nextTime < this.context.currentTime + .1 + 50 / 1e3;) {
			let e = Gt(this.patch.sequencer.bpm, this.patch.sequencer.swing, this.count % 16), t = {
				count: this.count,
				time: this.nextTime,
				duration: e
			};
			this.timeline.push(t), this.schedule([...this.running.keys()], t), this.nextTime += e, this.count++;
		}
	}
	pause() {
		if (this.transportRevision++, !this.playing) return;
		let e = this.context.currentTime;
		this.frozen = this.sounding?.count ?? this.frozen;
		let t = this.timeline.find((t) => t.time > e);
		this.count = t?.count ?? this.count, this.remaining = Math.max(0, (t?.time ?? this.nextTime) - e), this.playing = !1, this.timer && clearInterval(this.timer), this.timer = null, this.timeline = [], this.graph?.cancelScheduled();
	}
	reset() {
		this.pause(), this.running.clear(), this.frozen = -1, this.count = 0, this.remaining = .04;
	}
	stop() {
		this.reset();
	}
	setMute(e) {
		this.muted = e, this.graph?.setMute(e);
	}
	setMix(e) {
		this.mix = e, this.graph?.setMix(e);
	}
	panic() {
		this.revision++, this.reset(), this.releaseManual(), this.graph?.dispose(), this.graph = null;
	}
	setSuspended(e) {
		this.suspended = e, e && this.panic();
	}
	dispose() {
		this.disposed = !0, this.panic(), this.analyser?.disconnect(), this.context && this.context.close().catch(() => {}), this.context = null, this.releaseSession?.(), this.releaseSession = null;
	}
};
async function Yr(e, t = 4, n = dt) {
	let r = 44100, i = Kt(e, t, .04), a = new OfflineAudioContext(2, Math.ceil((i.duration + 2.04) * r), r);
	e.modules.some((e) => [
		"prism",
		"cohere",
		"talon",
		"brit"
	].includes(e.type) || e.params.filterModel === 1 || e.params.engine === 1) && await Hn(a);
	let o = new Kr(a, e, a.destination, n), s = e.modules.filter((e) => e.type === "performance").map((e) => e.id);
	i.events.forEach(({ time: e, duration: t }, n) => {
		o.sequence(s, n, e, t), o.drumStep(n, e);
	});
	try {
		return await o.flush(), await a.startRendering();
	} finally {
		o.dispose();
	}
}
function Xr(e) {
	let t = e.numberOfChannels, n = e.length * t * 2, r = new ArrayBuffer(44 + n), i = new DataView(r), a = (e, t) => {
		for (let n = 0; n < t.length; n++) i.setUint8(e + n, t.charCodeAt(n));
	};
	a(0, "RIFF"), i.setUint32(4, 36 + n, !0), a(8, "WAVE"), a(12, "fmt "), i.setUint32(16, 16, !0), i.setUint16(20, 1, !0), i.setUint16(22, t, !0), i.setUint32(24, e.sampleRate, !0), i.setUint32(28, e.sampleRate * t * 2, !0), i.setUint16(32, t * 2, !0), i.setUint16(34, 16, !0), a(36, "data"), i.setUint32(40, n, !0);
	let o = Array.from({ length: t }, (t, n) => e.getChannelData(n));
	for (let n = 0; n < e.length; n++) for (let e = 0; e < t; e++) {
		let r = Math.max(-1, Math.min(1, o[e][n]));
		i.setInt16(44 + (n * t + e) * 2, Math.round(r * (r < 0 ? 32768 : 32767)), !0);
	}
	return r;
}
var $ = {
	app: "_app_3zogu_1",
	toolbar: "_toolbar_3zogu_21",
	brand: "_brand_3zogu_22",
	brandMark: "_brandMark_3zogu_26",
	toolbarActions: "_toolbarActions_3zogu_27",
	audioButton: "_audioButton_3zogu_29",
	statusLed: "_statusLed_3zogu_30",
	rackLight: "_rackLight_3zogu_30",
	deviceLed: "_deviceLed_3zogu_30",
	patchBar: "_patchBar_3zogu_32",
	patchName: "_patchName_3zogu_33",
	nameField: "_nameField_3zogu_36",
	dirtyMark: "_dirtyMark_3zogu_39",
	saveStatus: "_saveStatus_3zogu_40",
	saveText: "_saveText_3zogu_41",
	saveLed: "_saveLed_3zogu_42",
	exportControls: "_exportControls_3zogu_44",
	visuallyHidden: "_visuallyHidden_3zogu_45",
	historyActions: "_historyActions_3zogu_46",
	icon: "_icon_3zogu_48",
	patchFile: "_patchFile_3zogu_50",
	rackActions: "_rackActions_3zogu_50",
	addButton: "_addButton_3zogu_52",
	presetsButton: "_presetsButton_3zogu_53",
	flipButton: "_flipButton_3zogu_56",
	rackHeading: "_rackHeading_3zogu_57",
	rack: "_rack_3zogu_30",
	module: "_module_3zogu_60",
	revealFlash: "_revealFlash_3zogu_1",
	moduleHeader: "_moduleHeader_3zogu_76",
	moduleIdentity: "_moduleIdentity_3zogu_77",
	moduleName: "_moduleName_3zogu_78",
	moduleSubtitle: "_moduleSubtitle_3zogu_79",
	moduleTools: "_moduleTools_3zogu_80",
	moduleNumber: "_moduleNumber_3zogu_81",
	screw: "_screw_3zogu_83",
	screwTL: "_screwTL_3zogu_85",
	screwTR: "_screwTR_3zogu_85",
	screwBL: "_screwBL_3zogu_85",
	screwBR: "_screwBR_3zogu_85",
	moduleBody: "_moduleBody_3zogu_86",
	controls: "_controls_3zogu_87",
	knobControl: "_knobControl_3zogu_88",
	controlLabel: "_controlLabel_3zogu_89",
	dial: "_dial_3zogu_90",
	dialTicks: "_dialTicks_3zogu_91",
	dialCap: "_dialCap_3zogu_92",
	knobValue: "_knobValue_3zogu_95",
	selectControl: "_selectControl_3zogu_96",
	choiceGlyph: "_choiceGlyph_3zogu_98",
	moduleDecoration: "_moduleDecoration_3zogu_99",
	deviceLabel: "_deviceLabel_3zogu_101",
	envelopeGraphic: "_envelopeGraphic_3zogu_103",
	drumPads: "_drumPads_3zogu_105",
	drumLane: "_drumLane_3zogu_107",
	laneLevel: "_laneLevel_3zogu_108",
	voiceButton: "_voiceButton_3zogu_111",
	pads: "_pads_3zogu_112",
	padGroup: "_padGroup_3zogu_113",
	pad: "_pad_3zogu_112",
	euclid: "_euclid_3zogu_120",
	euclidHeading: "_euclidHeading_3zogu_122",
	euclidCell: "_euclidCell_3zogu_123",
	orbitRings: "_orbitRings_3zogu_124",
	orbitPath: "_orbitPath_3zogu_126",
	mixButtons: "_mixButtons_3zogu_128",
	muteToggle: "_muteToggle_3zogu_130",
	soloToggle: "_soloToggle_3zogu_131",
	clearToggle: "_clearToggle_3zogu_132",
	sequenceBody: "_sequenceBody_3zogu_134",
	step: "_step_3zogu_134",
	stepCell: "_stepCell_3zogu_136",
	sequenceTop: "_sequenceTop_3zogu_138",
	lcd: "_lcd_3zogu_139",
	lcdDots: "_lcdDots_3zogu_142",
	numberField: "_numberField_3zogu_143",
	tempoSlider: "_tempoSlider_3zogu_146",
	swingField: "_swingField_3zogu_151",
	transport: "_transport_3zogu_153",
	playButton: "_playButton_3zogu_154",
	transportCaption: "_transportCaption_3zogu_156",
	steps: "_steps_3zogu_157",
	stepLed: "_stepLed_3zogu_159",
	stepNumber: "_stepNumber_3zogu_163",
	sequenceHint: "_sequenceHint_3zogu_164",
	stepEditor: "_stepEditor_3zogu_165",
	meters: "_meters_3zogu_167",
	meterRow: "_meterRow_3zogu_168",
	muteButton: "_muteButton_3zogu_169",
	rackBottom: "_rackBottom_3zogu_170",
	aboutButton: "_aboutButton_3zogu_171",
	keyboardPanel: "_keyboardPanel_3zogu_172",
	keyboardTop: "_keyboardTop_3zogu_173",
	keyHint: "_keyHint_3zogu_173",
	octaveControls: "_octaveControls_3zogu_174",
	keysToggle: "_keysToggle_3zogu_174",
	piano: "_piano_3zogu_175",
	whiteKey: "_whiteKey_3zogu_177",
	blackKey: "_blackKey_3zogu_179",
	toastAnchor: "_toastAnchor_3zogu_182",
	toast: "_toast_3zogu_182",
	library: "_library_3zogu_185",
	libraryHeading: "_libraryHeading_3zogu_186",
	libraryGrid: "_libraryGrid_3zogu_187",
	presetBrowser: "_presetBrowser_3zogu_189",
	presetActions: "_presetActions_3zogu_190",
	sectionLabel: "_sectionLabel_3zogu_191",
	presetList: "_presetList_3zogu_192",
	presetRow: "_presetRow_3zogu_193",
	presetLoad: "_presetLoad_3zogu_195",
	presetConfirm: "_presetConfirm_3zogu_198",
	dangerButton: "_dangerButton_3zogu_199",
	presetEmpty: "_presetEmpty_3zogu_200",
	factoryGrid: "_factoryGrid_3zogu_202",
	saveDialog: "_saveDialog_3zogu_203",
	saveTitle: "_saveTitle_3zogu_204",
	saveWarning: "_saveWarning_3zogu_206",
	saveNote: "_saveNote_3zogu_207",
	saveButtons: "_saveButtons_3zogu_208",
	saveButton: "_saveButton_3zogu_208",
	miniDevice: "_miniDevice_3zogu_209",
	routingBar: "_routingBar_3zogu_210",
	legend: "_legend_3zogu_211",
	portGroups: "_portGroups_3zogu_213",
	portGroup: "_portGroup_3zogu_213",
	portHeading: "_portHeading_3zogu_213",
	portRow: "_portRow_3zogu_213",
	socketControl: "_socketControl_3zogu_213",
	jacks: "_jacks_3zogu_215",
	socket: "_socket_3zogu_213",
	trim: "_trim_3zogu_218",
	cables: "_cables_3zogu_221",
	cableHits: "_cableHits_3zogu_221",
	cable: "_cable_3zogu_221",
	cableLine: "_cableLine_3zogu_225",
	cableShadow: "_cableShadow_3zogu_225",
	cableHit: "_cableHit_3zogu_221",
	loosePlug: "_loosePlug_3zogu_227",
	helpBackdrop: "_helpBackdrop_3zogu_229",
	help: "_help_3zogu_229",
	helpHeading: "_helpHeading_3zogu_229",
	about: "_about_3zogu_171",
	aboutFacts: "_aboutFacts_3zogu_231",
	aboutTagline: "_aboutTagline_3zogu_231",
	aboutCopyright: "_aboutCopyright_3zogu_231",
	hitLed: "_hitLed_3zogu_238",
	globalControls: "_globalControls_3zogu_260",
	globalTransport: "_globalTransport_3zogu_261",
	resetButton: "_resetButton_3zogu_265",
	clearAllButton: "_clearAllButton_3zogu_266",
	globalPosition: "_globalPosition_3zogu_270",
	keyboardTarget: "_keyboardTarget_3zogu_271",
	routingHint: "_routingHint_3zogu_272",
	moduleNameButton: "_moduleNameButton_3zogu_274",
	moduleTransport: "_moduleTransport_3zogu_275",
	performancePads: "_performancePads_3zogu_278",
	orbitEditor: "_orbitEditor_3zogu_284",
	orbitVoiceEditor: "_orbitVoiceEditor_3zogu_285",
	orbitEditorHeading: "_orbitEditorHeading_3zogu_286",
	orbitSteps: "_orbitSteps_3zogu_290",
	groupControls: "_groupControls_3zogu_298",
	grMeter: "_grMeter_3zogu_315",
	grUnit: "_grUnit_3zogu_318",
	grNeedle: "_grNeedle_3zogu_319",
	eqGraphic: "_eqGraphic_3zogu_334",
	soundEditor: "_soundEditor_3zogu_377",
	editorHeading: "_editorHeading_3zogu_378",
	fmDisplay: "_fmDisplay_3zogu_381",
	operatorTabs: "_operatorTabs_3zogu_383",
	console: "_console_3zogu_421",
	channelStrip: "_channelStrip_3zogu_422",
	mixBus: "_mixBus_3zogu_422",
	scribble: "_scribble_3zogu_424",
	channelSource: "_channelSource_3zogu_426",
	faderValue: "_faderValue_3zogu_429",
	faderBay: "_faderBay_3zogu_432",
	faderScale: "_faderScale_3zogu_433",
	faderSlot: "_faderSlot_3zogu_435",
	faderCap: "_faderCap_3zogu_437",
	levelMeter: "_levelMeter_3zogu_440",
	processorHint: "_processorHint_3zogu_458",
	britPanel: "_britPanel_3zogu_475",
	britSection: "_britSection_3zogu_476",
	britWell: "_britWell_3zogu_478",
	panelLegend: "_panelLegend_3zogu_479",
	marconi: "_marconi_3zogu_483",
	marconiRing: "_marconiRing_3zogu_483",
	marconiSkirt: "_marconiSkirt_3zogu_488",
	marconiFlutes: "_marconiFlutes_3zogu_489",
	marconiDome: "_marconiDome_3zogu_491",
	marconiPointer: "_marconiPointer_3zogu_493",
	ringPointer: "_ringPointer_3zogu_498",
	britCurve: "_britCurve_3zogu_501",
	britSwitch: "_britSwitch_3zogu_503",
	britLamp: "_britLamp_3zogu_505",
	talonPanel: "_talonPanel_3zogu_509",
	talonSection: "_talonSection_3zogu_510",
	talonWell: "_talonWell_3zogu_512",
	talonKnob: "_talonKnob_3zogu_513",
	talonGrip: "_talonGrip_3zogu_516",
	talonCap: "_talonCap_3zogu_517",
	talonIndex: "_talonIndex_3zogu_518",
	talonLamps: "_talonLamps_3zogu_521",
	talonLed: "_talonLed_3zogu_526",
	talonLatches: "_talonLatches_3zogu_528",
	talonPush: "_talonPush_3zogu_529",
	talonMeter: "_talonMeter_3zogu_531",
	talonSwitch: "_talonSwitch_3zogu_538",
	talonLamp: "_talonLamp_3zogu_521",
	talonOutput: "_talonOutput_3zogu_542",
	rollBrush: "_rollBrush_3zogu_557",
	engineSwitch: "_engineSwitch_3zogu_570",
	engineCaption: "_engineCaption_3zogu_572",
	togglePlate: "_togglePlate_3zogu_574",
	toggleLegend: "_toggleLegend_3zogu_576",
	toggle: "_toggle_3zogu_574",
	toggleSlot: "_toggleSlot_3zogu_586",
	toggleKnob: "_toggleKnob_3zogu_589",
	toggleBrim: "_toggleBrim_3zogu_592",
	toggleRib: "_toggleRib_3zogu_594",
	toggleCap: "_toggleCap_3zogu_596"
};
//#endregion
//#region src/components/Knob.tsx
function Zr(e, t) {
	return e.choices ? e.choices[t] ?? "" : e.unit === "ms" ? t ? `${t > 0 ? "+" : "−"}${Math.abs(t)}ms` : "On beat" : e.unit === "Hz" && t >= 1e3 ? `${(t / 1e3).toFixed(1)}k` : e.unit === "s" && t < .001 ? `${Math.round(t * 1e6)}μs` : e.unit === "s" && t < 1 ? `${e.step < .001 ? Number((t * 1e3).toFixed(2)) : Math.round(t * 1e3)}ms` : `${Number(t.toFixed(2))}${e.unit ?? ""}`;
}
function Qr({ param: e, value: t, onChange: n, prefix: r = "", format: i, disabled: a = !1, travel: o = 130 }) {
	let s = l(null), c = Vt(e, t), u = Math.max(4, Math.ceil(-Math.log10(e.step)));
	function d(t) {
		let r = Math.max(0, Math.min(1, t)), i = e.logarithmic ? e.min * (e.max / e.min) ** r : e.min + r * (e.max - e.min);
		n(Math.max(e.min, Math.min(e.max, Number((Math.round(i / e.step) * e.step).toFixed(u)))));
	}
	function f(e) {
		e.isPrimary && e.button === 0 && (s.current = {
			y: e.clientY,
			fraction: c
		}, e.currentTarget.setPointerCapture(e.pointerId), e.preventDefault());
	}
	let p = i ? i(t) : Zr(e, t);
	return {
		props: {
			role: "slider",
			tabIndex: a ? -1 : 0,
			"aria-disabled": a || void 0,
			"aria-label": `${r} ${e.label}`.trim(),
			"aria-valuemin": e.min,
			"aria-valuemax": e.max,
			"aria-valuenow": t,
			"aria-valuetext": p,
			onPointerDown: a ? void 0 : f,
			onPointerMove: (e) => {
				s.current && d(s.current.fraction + (s.current.y - e.clientY) / o);
			},
			onPointerUp: () => {
				s.current = null;
			},
			onPointerCancel: () => {
				s.current = null;
			},
			onDoubleClick: a ? void 0 : () => n(e.initial),
			onKeyDown: (r) => {
				!a && [
					"ArrowUp",
					"ArrowRight",
					"ArrowDown",
					"ArrowLeft",
					"Home",
					"End"
				].includes(r.key) && (r.preventDefault(), r.key === "Home" ? n(e.min) : r.key === "End" ? n(e.max) : e.logarithmic ? d(c + (["ArrowUp", "ArrowRight"].includes(r.key) ? .025 : -.025)) : n(Math.max(e.min, Math.min(e.max, Number((t + (["ArrowUp", "ArrowRight"].includes(r.key) ? e.step : -e.step)).toFixed(u))))));
			}
		},
		fraction: c,
		display: p
	};
}
function $r({ param: e, value: t, onChange: n, prefix: r = "", format: i, trim: a = !1, disabled: o = !1, caption: s }) {
	let { props: c, fraction: l, display: u } = Qr({
		param: e,
		value: t,
		onChange: n,
		prefix: r,
		format: i,
		disabled: o
	}), d = /* @__PURE__ */ m("div", {
		className: a ? `${$.dial} ${$.trim}` : $.dial,
		...c,
		title: a ? `${e.label} ${u}` : void 0,
		children: [/* @__PURE__ */ p("span", { className: $.dialTicks }), /* @__PURE__ */ p("span", {
			className: $.dialCap,
			style: { transform: `rotate(${-135 + l * 270}deg)` },
			children: /* @__PURE__ */ p("span", {})
		})]
	});
	return a ? d : /* @__PURE__ */ m("div", {
		className: $.knobControl,
		children: [
			/* @__PURE__ */ p("span", {
				className: $.controlLabel,
				children: s ?? e.label
			}),
			d,
			/* @__PURE__ */ p("span", {
				className: $.knobValue,
				children: u
			})
		]
	});
}
//#endregion
//#region src/components/CableLayer.tsx
var ei = (e) => `${e.moduleId}:${e.portId}`, ti = (e, t) => {
	let n = Math.min(140, Math.abs(e.y - t.y) * .2 + Math.abs(e.x - t.x) * .25 + 40);
	return `M${e.x},${e.y} C${e.x + 12},${e.y + n} ${t.x - 12},${t.y + n} ${t.x},${t.y}`;
};
function ni({ patch: e, rackRef: t, selected: n, onSelect: r, drag: i }) {
	let [a, s] = u({}), [c, l] = u(null);
	o(() => {
		let e = t.current;
		if (!e) return;
		function n() {
			let t = e.getBoundingClientRect(), n = {};
			e.querySelectorAll("[data-port-key]").forEach((r) => {
				let i = r.getBoundingClientRect();
				n[r.dataset.portKey] = {
					x: i.x - t.x + i.width / 2 + e.scrollLeft,
					y: i.y - t.y + i.height / 2 + e.scrollTop
				};
			}), s(n);
		}
		n();
		let r = new ResizeObserver(n);
		return r.observe(e), e.querySelectorAll("article").forEach((e) => r.observe(e)), window.addEventListener("resize", n), () => {
			r.disconnect(), window.removeEventListener("resize", n);
		};
	}, [e.modules, t]);
	let d = (t) => {
		let n = e.modules.find((e) => e.id === t.moduleId), r = U[n.type].ports, i = G(e, t), a = Ue(r, i), o = n.type === "mixer" && i.direction === "in" ? `Channel ${i.id.toUpperCase()}: ${St(e, n.id, i.id).source}` : i.label;
		return `${U[n.type].name} ${o}${a && a > 1 ? ` ${a}` : ""}`;
	}, h = i && G(e, i.anchor), g = i && a[ei(i.anchor)], _ = i && (i.target ? a[ei(i.target)] : i.point), v = h && g && _ ? h.direction === "out" ? ti(g, _) : ti(_, g) : null, y = e.cables.flatMap((t) => {
		let n = a[ei(t.from)], r = a[ei(t.to)];
		return n && r && t.id !== i?.cableId ? [{
			cable: t,
			path: ti(n, r),
			kind: G(e, t.from).kind
		}] : [];
	});
	return /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("svg", {
		className: $.cableHits,
		"aria-label": "Patch cables",
		children: y.map(({ cable: e, path: t }) => /* @__PURE__ */ p("path", {
			className: $.cableHit,
			d: t,
			role: "button",
			tabIndex: 0,
			"aria-label": `Cable from ${d(e.from)} to ${d(e.to)}`,
			onClick: () => r(e.id),
			onPointerEnter: () => l(e.id),
			onPointerLeave: () => l((t) => t === e.id ? null : t),
			onKeyDown: (t) => {
				(t.key === "Enter" || t.key === " ") && (t.preventDefault(), r(e.id));
			}
		}, e.id))
	}), /* @__PURE__ */ m("svg", {
		className: $.cables,
		"aria-hidden": "true",
		children: [y.map(({ cable: e, path: t, kind: r }) => /* @__PURE__ */ m("g", {
			className: $.cable,
			"data-kind": r,
			"data-selected": n === e.id,
			"data-hovered": c === e.id,
			children: [/* @__PURE__ */ p("path", {
				className: $.cableShadow,
				d: t
			}), /* @__PURE__ */ p("path", {
				className: $.cableLine,
				d: t
			})]
		}, e.id)), v && /* @__PURE__ */ m("g", {
			className: $.cable,
			"data-kind": h.kind,
			"data-held": "true",
			"data-snapped": !!i.target,
			"data-invalid": !!i.error,
			children: [
				/* @__PURE__ */ p("path", {
					className: $.cableShadow,
					d: v
				}),
				/* @__PURE__ */ p("path", {
					className: $.cableLine,
					d: v
				}),
				!i.target && /* @__PURE__ */ p("circle", {
					className: $.loosePlug,
					cx: _.x,
					cy: _.y,
					r: 8
				})
			]
		})]
	})] });
}
//#endregion
//#region src/audio/studio-processor.js
var ri = [
	1e-4,
	3e-4,
	.001,
	.003,
	.01,
	.03
], ii = [
	.1,
	.3,
	.6,
	1.2
], ai = [
	1,
	2,
	3,
	4,
	6,
	10,
	20,
	100
], oi = [
	35,
	60,
	110,
	220
], si = [
	360,
	700,
	1600,
	3200,
	4800,
	7200
], ci = [
	0,
	50,
	80,
	160,
	300
], li = (e) => 10 ** (e / 20), ui = [
	1,
	0,
	0,
	0,
	0
];
function di(e, t, n, r, i) {
	if (!t) return ui.slice();
	let a = 2 * Math.PI * Math.min(t, i * .45) / i, o = Math.cos(a), s = Math.sin(a), c = 10 ** (n / 40), l = s / (2 * r), u = s * Math.sqrt(2 * c), d, f, p, m, h, g;
	if (e === "pole") {
		let e = Math.tan(a / 2);
		return [
			1 / (1 + e),
			-1 / (1 + e),
			0,
			(e - 1) / (e + 1),
			0
		];
	}
	return e === "highpass" ? [d, f, p, m, h, g] = [
		(1 + o) / 2,
		-(1 + o),
		(1 + o) / 2,
		1 + l,
		-2 * o,
		1 - l
	] : e === "bell" ? [d, f, p, m, h, g] = [
		1 + l * c,
		-2 * o,
		1 - l * c,
		1 + l / c,
		-2 * o,
		1 - l / c
	] : e === "low" ? [d, f, p, m, h, g] = [
		c * (c + 1 - (c - 1) * o + u),
		2 * c * (c - 1 - (c + 1) * o),
		c * (c + 1 - (c - 1) * o - u),
		c + 1 + (c - 1) * o + u,
		-2 * (c - 1 + (c + 1) * o),
		c + 1 + (c - 1) * o - u
	] : [d, f, p, m, h, g] = [
		c * (c + 1 + (c - 1) * o + u),
		-2 * c * (c - 1 + (c + 1) * o),
		c * (c + 1 + (c - 1) * o - u),
		c + 1 - (c - 1) * o + u,
		2 * (c - 1 - (c + 1) * o),
		c + 1 - (c - 1) * o - u
	], [
		d / m,
		f / m,
		p / m,
		h / m,
		g / m
	];
}
function fi(e, t) {
	let n = ci[e.hpf] ?? 0;
	return [
		di("pole", n, 0, 1, t),
		di("highpass", n, 0, 1, t),
		di("low", oi[e.lfFreq] ?? 110, e.lfGain, .7, t),
		di("bell", si[e.midFreq] ?? 1600, e.midGain, .75, t),
		di("high", 12e3, e.hfGain, .7, t)
	];
}
function pi(e, t, n = 48e3) {
	if (e.active) return 0;
	let r = 2 * Math.PI * t / n, i = (e, t, n) => Math.hypot(e + t * Math.cos(r) + n * Math.cos(2 * r), t * Math.sin(r) + n * Math.sin(2 * r));
	return fi(e, n).reduce((e, [t, n, r, a, o]) => e + 20 * Math.log10(i(t, n, r) / i(1, a, o)), 0);
}
function mi(e, t) {
	let n, r, i;
	return e === "cohere" ? (n = [
		2,
		4,
		10
	][t.ratio] ?? 4, r = t.threshold + [
		-3,
		0,
		2
	][t.ratio], i = [
		9,
		6,
		3
	][t.ratio]) : (n = ai[t.ratio] ?? 6, r = [
		-18,
		-26,
		-24,
		-22,
		-20,
		-18,
		-16,
		-18
	][t.ratio], i = [
		0,
		15,
		12,
		9,
		6,
		4,
		2,
		3
	][t.ratio], t.fierce && (n = Math.max(12, n * 2), r -= 3, i = 2)), [
		1 - 1 / n,
		r,
		i
	];
}
function hi(e, t, n, r) {
	if (!t) return 0;
	let i = e - n;
	return i <= -r / 2 ? 0 : i >= r / 2 ? -i * t : -t * (i + r / 2) ** 2 / (2 * r);
}
var gi = class {
	constructor(e) {
		this.c = ui.slice(), this.target = ui.slice(), this.z1 = 0, this.z2 = 0, this.smooth = 1 - Math.exp(-1 / (e * .008));
	}
	set(e, t) {
		this.target = e, t && (this.c = e.slice());
	}
	run(e) {
		let t = this.c;
		for (let e = 0; e < 5; e++) t[e] += (this.target[e] - t[e]) * this.smooth;
		let n = t[0] * e + this.z1;
		return this.z1 = t[1] * e - t[3] * n + this.z2, this.z2 = t[2] * e - t[4] * n, n;
	}
}, _i = Float64Array.from({ length: 49 }, (e, t) => {
	let n = t - 24, r = .1125;
	return (n ? Math.sin(2 * Math.PI * r * n) / (Math.PI * n) : 2 * r) * (.42 - .5 * Math.cos(2 * Math.PI * t / 48) + .08 * Math.cos(4 * Math.PI * t / 48));
}), vi = _i.reduce((e, t) => e + t, 0);
for (let e = 0; e < _i.length; e++) _i[e] /= vi;
var yi = class {
	constructor() {
		this.buffer = /* @__PURE__ */ new Float64Array(49), this.index = 0;
	}
	push(e) {
		this.buffer[this.index] = e, this.index = (this.index + 1) % 49;
	}
	run(e) {
		this.buffer[this.index] = e;
		let t = 0, n = this.index;
		for (let e = 0; e < 49; e++) t += _i[e] * this.buffer[n], --n < 0 && (n = 48);
		return this.index = (this.index + 1) % 49, t;
	}
}, bi = class {
	constructor() {
		this.buffer = /* @__PURE__ */ new Float64Array(13), this.index = 0;
	}
	push(e) {
		this.index = this.index ? this.index - 1 : 12, this.buffer[this.index] = e;
	}
	run(e) {
		let t = 0, n = this.index;
		for (let r = e; r < 49; r += 4) t += _i[r] * this.buffer[n], ++n > 12 && (n = 0);
		return t;
	}
}, xi = class {
	constructor() {
		this.buffer = /* @__PURE__ */ new Float64Array(12), this.index = 0;
	}
	run(e) {
		let t = this.buffer[this.index];
		return this.buffer[this.index] = e, this.index = (this.index + 1) % this.buffer.length, t;
	}
}, Si = class {
	constructor(e) {
		this.up = new bi(), this.down = new yi(), this.clean = new xi(), this.previous = 0, this.blocked = 0, this.dc = Math.exp(-2 * Math.PI * 5 / e);
	}
	run(e, t, n) {
		let r = 0, i = Math.tanh(n), a = t * (1 - i * i);
		this.up.push(e * 4);
		for (let e = 0; e < 4; e++) {
			let o = this.up.run(e), s = (Math.tanh(t * o + n) - i) / a;
			e === 0 ? r = this.down.run(s - o) : this.down.push(s - o);
		}
		return this.blocked = r - this.previous + this.dc * this.blocked, this.previous = r, this.clean.run(e) + this.blocked;
	}
}, Ci = class {
	constructor(e, t) {
		this.type = e, this.rate = t, this.params = null, this.events = [], this.disposed = !1, this.reduction = 0, this.gain = [0, 0], this.memory = [0, 0], this.input = 1, this.output = 1, this.wet = 1, this.drive = 0, this.smooth = 1 - Math.exp(-1 / (t * .008)), this.channels = Array.from({ length: 2 }, () => ({
			filters: Array.from({ length: 5 }, () => new gi(t)),
			hp: new gi(t),
			emphasis: new gi(t),
			audioPole: new gi(t),
			audioHp: new gi(t),
			color: new Si(t),
			dry: new xi(),
			clean: new xi(),
			amount: .15,
			bias: 0
		}));
	}
	enqueue(e) {
		this.events.push(e), this.events.sort((e, t) => e.time - t.time);
	}
	configure(e) {
		let t = !this.params;
		this.params = { ...e }, this.inputTarget = li(this.type === "talon" ? e.input : 0), this.outputTarget = li(e.output), this.wetTarget = +!e.active, this.driveTarget = e.drive ?? 0, t && (this.input = this.inputTarget, this.output = this.outputTarget, this.wet = this.wetTarget, this.drive = this.driveTarget), this.type !== "brit" && (this.curveTarget = mi(this.type, e), this.linkTarget = this.type === "cohere" ? 1 : e.link, this.attackTarget = this.type === "cohere" ? ri[e.attack] : e.attack, this.releaseTarget = this.type === "cohere" ? ii[e.release] ?? .3 : e.release, t && (this.curve = this.curveTarget.slice(), this.link = this.linkTarget, this.attack = this.attackTarget, this.release = this.releaseTarget));
		for (let n of this.channels) {
			this.type === "brit" && fi(e, this.rate).forEach((e, r) => n.filters[r].set(e, t));
			let r = this.type === "cohere" ? [
				0,
				30,
				60,
				106,
				125,
				185
			][e.scHpf] : e.detectorHp ? 80 : 0;
			n.hp.set(di("highpass", r, 0, Math.SQRT1_2, this.rate), t), n.emphasis.set(di("bell", 6e3, e.detectorBand ? 10 : 0, 1, this.rate), t), n.audioPole.set(di("pole", e.audioHp ? 49.01 : 0, 0, 1, this.rate), t), n.audioHp.set(di("highpass", e.audioHp ? 44.915 : 0, 0, .691, this.rate), t), t && this.type === "talon" && (n.amount = [
				.15,
				.8,
				1.5
			][e.color], n.bias = e.color === 1 ? .3 : 0);
		}
	}
	envelope(e, t) {
		let n = this.params, r = hi(e, this.curve[0], this.curve[1], this.curve[2]), i = this.gain[t];
		this.memory[t] += (Math.max(0, -i) - this.memory[t]) * (1 - Math.exp(-1 / (this.rate * .6)));
		let a = this.release;
		this.type === "cohere" && n.release === 4 && (a = .1 + Math.min(1.1, this.memory[t] * .09)), this.type === "talon" && (n.ratio === 5 ? a = Math.min(20, this.release * (1 + this.memory[t] * .9)) : n.ratio === 7 ? a *= .45 + Math.min(1.5, Math.max(0, -i) / 15) : a *= [
			1,
			1.15,
			1.05,
			1,
			.9,
			1,
			.8,
			1
		][n.ratio], n.ratio !== 5 && (a = Math.min(3.5, a)), n.fierce && (a *= .65));
		let o = r < i ? this.attack : a;
		return this.gain[t] += (r - i) * (1 - Math.exp(-1 / (o * this.rate))), li(this.gain[t]);
	}
	render(e, t, n = 0) {
		if (this.disposed) {
			t.forEach((e) => e.fill(0));
			return;
		}
		let r = t[0].length;
		for (let i = 0; i < r; i++) {
			let r = (n + i) / this.rate;
			for (; this.events.length && this.events[0].time <= r;) this.configure(this.events.shift().params);
			if (!this.params) {
				t.forEach((e) => {
					e[i] = 0;
				});
				continue;
			}
			let a = this.params;
			this.input += (this.inputTarget - this.input) * this.smooth, this.output += (this.outputTarget - this.output) * this.smooth, this.wet += (this.wetTarget - this.wet) * this.smooth, this.drive += (this.driveTarget - this.drive) * this.smooth;
			let o = e[0]?.[i] ?? 0, s = e[1]?.[i] ?? o, c = o * this.input, l = s * this.input, u = 1, d = 1;
			if (this.type !== "brit") {
				for (let e = 0; e < 3; e++) this.curve[e] += (this.curveTarget[e] - this.curve[e]) * this.smooth;
				this.link += (this.linkTarget - this.link) * this.smooth, this.attack += (this.attackTarget - this.attack) * this.smooth, this.release += (this.releaseTarget - this.release) * this.smooth;
				let e = this.channels[0], t = this.channels[1], n = 20 * Math.log10(Math.max(1e-12, Math.abs(e.emphasis.run(e.hp.run(c))))), r = 20 * Math.log10(Math.max(1e-12, Math.abs(t.emphasis.run(t.hp.run(l))))), i = Math.max(n, r);
				this.envelope(n + this.link * (i - n), 0), this.envelope(r + this.link * (i - r), 1);
				let a = Math.min(this.gain[0], this.gain[1]), o = Math.max(this.memory[0], this.memory[1]), s = this.link * this.smooth;
				for (let e = 0; e < 2; e++) this.gain[e] += (a - this.gain[e]) * s, this.memory[e] += (o - this.memory[e]) * s;
				u = li(this.gain[0]), d = li(this.gain[1]), this.reduction = Math.min(this.gain[0], this.gain[1]) * this.wet;
			}
			for (let e = 0; e < t.length; e++) {
				let n = this.channels[e], r = e === 0 ? o : s, f = e === 0 ? c : l;
				if (this.type === "brit") {
					for (let e of n.filters) f = e.run(f);
					f = n.color.run(f, .22 * li(this.drive), .12);
				} else if (this.type === "talon") {
					f = n.audioHp.run(n.audioPole.run(f * (e === 0 ? u : d)));
					let t = [
						.15,
						.8,
						1.5
					][a.color] * (1 + Math.min(2, -this.gain[e] / 20));
					n.amount += (t - n.amount) * this.smooth, n.bias += ((a.color === 1 ? .3 : 0) - n.bias) * this.smooth, f = n.color.run(f, n.amount, n.bias);
				} else f = n.clean.run(f * (e === 0 ? u : d));
				let p = n.dry.run(r);
				t[e][i] = p + this.wet * (f * this.output - p);
			}
		}
	}
};
if (typeof registerProcessor < "u") {
	class e extends AudioWorkletProcessor {
		constructor(e) {
			super(), this.dsp = new Ci(e.processorOptions.type, sampleRate), this.meterFrames = 0, this.port.onmessage = ({ data: e }) => {
				e.type === "flush" ? this.port.postMessage({ id: e.id }) : e.type === "dispose" ? (this.dsp.disposed = !0, this.dsp.events = []) : this.dsp.enqueue(e);
			};
		}
		process(e, t) {
			return this.dsp.render(e[0] ?? [], t[0], currentFrame), this.meterFrames += t[0][0].length, this.meterFrames >= sampleRate / 25 && (this.meterFrames = 0, this.port.postMessage({ reduction: this.dsp.reduction })), !this.dsp.disposed;
		}
	}
	registerProcessor("rackloose-studio-v1", e);
}
//#endregion
//#region src/components/Glyphs.tsx
var wi = (e) => e.map((t, n) => `${n ? "L" : "M"}${(2 + n * 44 / (e.length - 1)).toFixed(1)} ${(17 - t * 14).toFixed(1)}`).join(" ");
function Ti(e, t) {
	let n = t, r = .5, i = Array.from({ length: 25 }, () => (n = n * 16807 % 2147483647, r += (n / 2147483647 - r) * e, r)), a = Math.min(...i), o = Math.max(...i);
	return wi(i.map((e) => .1 + (e - a) / (o - a) * .8));
}
var Ei = {
	Sine: wi(Array.from({ length: 33 }, (e, t) => .5 + .5 * Math.sin(t / 32 * Math.PI * 4))),
	Triangle: wi([
		0,
		1,
		0,
		1,
		0
	]),
	Saw: "M2 17L24 3V17L46 3V17",
	Square: "M2 17V3H13V17H24V3H35V17H46V3",
	Pulse: "M2 17V3H8V17H24V3H30V17H46",
	"Saw + Pulse": "M2 17L13 13.5V6.5L24 3V17L35 13.5V6.5L46 3V17",
	"Low-pass": "M2 7H24C30 7 31 3 33 6C35 10 38 17 46 18",
	"High-pass": "M2 18C10 17 13 10 15 6C17 3 18 7 24 7H46",
	"Band-pass": "M2 18C14 17 18 4 24 4C30 4 34 17 46 18",
	White: Ti(1, 7),
	Pink: Ti(.45, 11),
	Brown: Ti(.16, 23),
	Bell: "M2 14C14 14 18 4 24 4C30 4 34 14 46 14",
	"Low shelf": "M2 6H14C20 6 22 14 30 14H46",
	"High shelf": "M2 14H18C26 14 28 6 34 6H46"
};
function Di({ param: e, value: t }) {
	let n = e.choices?.[t] ?? "", r = Ei[n === "Shelf" ? e.id === "hfBell" ? "High shelf" : "Low shelf" : n];
	return r ? /* @__PURE__ */ p("svg", {
		className: $.choiceGlyph,
		viewBox: "0 0 48 20",
		"aria-hidden": "true",
		children: /* @__PURE__ */ p("path", { d: r })
	}) : null;
}
function Oi({ params: e, brit: t = !1, rate: n = 48e3 }) {
	let r = Nr(e, 24e3), i = (e) => 25 - Math.max(-18, Math.min(18, e)) * 22 / 18, a = Array.from({ length: 72 }, (a, o) => {
		let s = 20 * 1e3 ** (o / 71);
		return `${o ? "L" : "M"}${(3 + o * 114 / 71).toFixed(1)} ${i(t ? pi(e, s, n) : r.reduce((e, t) => e + Pr(t, s, 48e3), 0)).toFixed(1)}`;
	}).join("");
	return /* @__PURE__ */ m("svg", {
		className: $.eqGraphic,
		viewBox: "0 0 120 50",
		role: t ? "img" : void 0,
		"aria-label": t ? `BRIT filter response, 20 Hz to 20 kHz, at ${n / 1e3} kHz` : void 0,
		"aria-hidden": !t || void 0,
		"data-bypassed": e.active === 1,
		children: [
			[
				100,
				1e3,
				1e4
			].map((e) => /* @__PURE__ */ p("line", {
				x1: 3 + Math.log10(e / 20) / 3 * 114,
				x2: 3 + Math.log10(e / 20) / 3 * 114,
				y1: "3",
				y2: "47"
			}, e)),
			/* @__PURE__ */ p("line", {
				x1: "3",
				x2: "117",
				y1: "25",
				y2: "25"
			}),
			/* @__PURE__ */ p("path", { d: a })
		]
	});
}
function ki({ reduction: e, label: t, max: n = 20 }) {
	let r = Math.min(n, Math.max(0, -e)), i = (e) => 45 - e / n * 90, a = (e, t) => {
		let n = (i(e) - 90) * Math.PI / 180;
		return [60 + Math.cos(n) * t, 60 + Math.sin(n) * t].map((e) => Number(e.toFixed(1)));
	};
	return /* @__PURE__ */ p("div", {
		className: $.grMeter,
		role: "meter",
		"aria-label": t,
		"aria-valuemin": 0,
		"aria-valuemax": n,
		"aria-valuenow": r,
		"aria-valuetext": `${r} dB gain reduction`,
		children: /* @__PURE__ */ m("svg", {
			viewBox: "0 0 120 50",
			"aria-hidden": "true",
			children: [
				/* @__PURE__ */ p("path", { d: `M${a(0, 48).join(" ")}A48 48 0 0 0 ${a(n, 48).join(" ")}` }),
				[
					0,
					n / 4,
					n / 2,
					n * 3 / 4,
					n
				].map((e) => {
					let [t, n] = a(e, 48), [r, i] = a(e, 53), [o, s] = a(e, 40);
					return /* @__PURE__ */ m("g", { children: [/* @__PURE__ */ p("line", {
						x1: t,
						y1: n,
						x2: r,
						y2: i
					}), /* @__PURE__ */ p("text", {
						x: o,
						y: s,
						textAnchor: "middle",
						dominantBaseline: "middle",
						children: e
					})] }, e);
				}),
				/* @__PURE__ */ p("text", {
					className: $.grUnit,
					x: "8",
					y: "45",
					children: "GR dB"
				}),
				/* @__PURE__ */ p("line", {
					className: $.grNeedle,
					x1: "60",
					y1: "60",
					x2: "60",
					y2: "8",
					style: { transform: `rotate(${i(r)}deg)` }
				})
			]
		})
	});
}
var [Ai, ji, , Mi] = U.envelope.params;
function Ni({ params: e }) {
	let t = (t) => 9 + Vt(t, e[t.id]) * 24, n = 3 + t(Ai), r = n + t(ji), i = 117 - t(Mi), a = 40 - e.sustain * 35, o = [
		["A", (3 + n) / 2],
		["D", (n + r) / 2],
		["S", (r + i) / 2],
		["R", (i + 117) / 2]
	];
	return /* @__PURE__ */ m("svg", {
		className: $.envelopeGraphic,
		viewBox: "0 0 120 50",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ p("path", { d: `M3 40L${n.toFixed(1)} 5L${r.toFixed(1)} ${a.toFixed(1)}L${i.toFixed(1)} ${a.toFixed(1)}L117 40` }), o.map(([e, t]) => /* @__PURE__ */ p("text", {
			x: t.toFixed(1),
			y: "48",
			textAnchor: "middle",
			children: e
		}, e))]
	});
}
var Pi = {
	play: /* @__PURE__ */ p("path", { d: "M3.5 2.2v9.6L11.6 7z" }),
	pause: /* @__PURE__ */ p("path", { d: "M3 2.2h2.9v9.6H3zM8.1 2.2H11v9.6H8.1z" }),
	stop: /* @__PURE__ */ p("path", { d: "M2.8 2.8h8.4v8.4H2.8z" }),
	reset: /* @__PURE__ */ p("path", { d: "M2.4 2.2h2v9.6h-2zM11.8 2.2v9.6L4.9 7z" }),
	undo: /* @__PURE__ */ p("path", {
		d: "M5.2 2.4 1.6 5.8l3.6 3.4V7.1h3.2a2.6 2.6 0 0 1 0 5.2H6.6v1.5h1.8a4.1 4.1 0 0 0 0-8.2H5.2z",
		transform: "translate(0 -1.2)"
	}),
	redo: /* @__PURE__ */ p("path", {
		d: "M8.8 2.4l3.6 3.4-3.6 3.4V7.1H5.6a2.6 2.6 0 0 0 0 5.2h1.8v1.5H5.6a4.1 4.1 0 0 1 0-8.2h3.2z",
		transform: "translate(0 -1.2)"
	})
};
function Fi({ name: e }) {
	return /* @__PURE__ */ p("svg", {
		className: $.icon,
		viewBox: "0 0 14 14",
		"aria-hidden": "true",
		focusable: "false",
		children: Pi[e]
	});
}
//#endregion
//#region src/components/MixButtons.tsx
function Ii({ mixKey: e, label: t, mix: n, onToggle: r, solo: i = !0, onClear: a, clearable: o }) {
	return /* @__PURE__ */ m("span", {
		className: $.mixButtons,
		children: [
			/* @__PURE__ */ p("button", {
				className: $.muteToggle,
				"aria-label": `Mute ${t}`,
				"aria-pressed": n.muted.has(e),
				title: `Mute ${t}`,
				onClick: () => r(e, "muted"),
				children: "M"
			}),
			i && /* @__PURE__ */ p("button", {
				className: $.soloToggle,
				"aria-label": `Solo ${t}`,
				"aria-pressed": n.soloed.has(e),
				title: `Solo ${t}`,
				onClick: () => r(e, "soloed"),
				children: "S"
			}),
			a && /* @__PURE__ */ p("button", {
				className: $.clearToggle,
				"aria-label": `Clear ${t} mutes and solos`,
				title: `Clear ${t} mutes and solos`,
				disabled: !o,
				onClick: a,
				children: "CLR"
			})
		]
	});
}
//#endregion
//#region src/components/Drums.tsx
var Li = [
	[1, "1/16"],
	[2, "1/32"],
	[3, "×3 · 1/32T"],
	[4, "×4 · 1/64"],
	[6, "×6 · 1/64T"]
], Ri = {
	2: "1/32",
	3: "1/32 triplet",
	4: "1/64",
	6: "1/64 triplet"
}, zi = (e) => (t) => {
	if (t <= 0) return "-∞ dB";
	let n = 20 * Math.log10(t / e.initial);
	return Math.abs(n) < .05 ? "0 dB" : `${n > 0 ? "+" : ""}${n.toFixed(1)} dB`;
};
function Bi({ module: e, voice: t, onParams: n, labelled: r }) {
	let i = U[e.type], a = i.params.find((e) => e.id === `${t}Level`);
	if (!a) return null;
	let o = /* @__PURE__ */ p($r, {
		trim: !0,
		param: a,
		prefix: i.name,
		format: zi(a),
		value: e.params[a.id],
		onChange: (e) => n({ [a.id]: e })
	});
	return r ? /* @__PURE__ */ m("div", {
		className: $.laneLevel,
		children: [o, /* @__PURE__ */ p("span", {
			"aria-hidden": "true",
			children: "LEVEL"
		})]
	}) : o;
}
function Vi(e, t, n, r) {
	let i = e.params, a = 1 << n, o = Qe(i[`${t}Pattern`], n), s = et(e, t, n), c = (e) => Object.fromEntries(B.map((n) => [we(t, n), n === e ? i[we(t, n)] | a : i[we(t, n)] & ~a]));
	return r === 1 ? {
		[`${t}Pattern`]: i[`${t}Pattern`] ^ a,
		...o ? c(0) : {}
	} : {
		[`${t}Pattern`]: i[`${t}Pattern`] | a,
		...c(o && s === r ? 0 : r)
	};
}
function Hi({ module: e, mix: t, onMix: n, step: r, onParams: i, onAudition: a, disabled: o, selected: s, onSelect: c }) {
	let l = U[e.type], d = l.params.some((e) => e.id === we(l.drum.voices[0].id, 2)), [f, h] = u(1);
	return /* @__PURE__ */ m("div", {
		className: $.drumPads,
		children: [d && /* @__PURE__ */ m("div", {
			className: $.rollBrush,
			role: "group",
			"aria-label": `${l.name} pad mode`,
			children: [/* @__PURE__ */ p("span", { children: "NOTE" }), Li.map(([e, t]) => /* @__PURE__ */ p("button", {
				"aria-pressed": f === e,
				onClick: () => h(e),
				children: t
			}, e))]
		}), l.drum.voices.map((u) => {
			let h = `${u.id}Pattern`, g = e.params[h];
			return /* @__PURE__ */ m("div", {
				className: $.drumLane,
				"data-silent": !Y(e, u.id, t),
				children: [
					/* @__PURE__ */ p("button", {
						className: $.voiceButton,
						"aria-label": `Play ${l.name} ${u.label}`,
						"aria-pressed": c ? s === u.id : void 0,
						disabled: o,
						onClick: () => {
							c?.(u.id), a(u.id);
						},
						children: u.label
					}),
					/* @__PURE__ */ p(Ii, {
						mixKey: ft(e.id, u.id),
						label: `${l.name} ${u.label}`,
						mix: t,
						onToggle: n
					}),
					/* @__PURE__ */ p(Bi, {
						labelled: !0,
						module: e,
						voice: u.id,
						onParams: i
					}),
					/* @__PURE__ */ p("div", {
						className: $.pads,
						children: [
							0,
							1,
							2,
							3
						].map((t) => /* @__PURE__ */ p("div", {
							className: $.padGroup,
							"data-group": t,
							children: [
								0,
								1,
								2,
								3
							].map((n) => {
								let a = t * 4 + n, o = Qe(g, a), s = o && d ? et(e, u.id, a) : 1;
								return /* @__PURE__ */ m("button", {
									className: $.pad,
									"data-current": r === a,
									"data-roll": s > 1 ? s : void 0,
									"aria-pressed": o,
									"aria-label": `${l.name} ${u.label} step ${a + 1}${s > 1 ? `, ${Ri[s]}` : ""}`,
									onClick: () => i(d ? Vi(e, u.id, a, f) : { [h]: g ^ 1 << a }),
									children: [/* @__PURE__ */ p("span", {}), s > 1 && /* @__PURE__ */ p("small", { children: s })]
								}, a);
							})
						}, t))
					})
				]
			}, u.id);
		})]
	});
}
var Ui = [
	"Steps",
	"Hits",
	"Shift"
];
function Wi({ module: t, mix: n, onMix: r, onParams: i, onAudition: a, disabled: o, clock: s, selected: c, onSelect: l }) {
	let u = U[t.type], d = u.drum.voices.find((e) => e.id === c), f = J(t, c);
	return /* @__PURE__ */ m("div", {
		className: $.orbitEditor,
		children: [/* @__PURE__ */ m("div", {
			className: $.euclid,
			role: "group",
			"aria-label": `${u.name} rhythm`,
			children: [
				/* @__PURE__ */ p("span", { children: "VOICE / EDIT" }),
				/* @__PURE__ */ p("span", {}),
				[...Ui, "Level"].map((e) => /* @__PURE__ */ p("span", {
					className: $.euclidHeading,
					children: e
				}, e)),
				u.drum.voices.map((s) => /* @__PURE__ */ m(e, { children: [
					/* @__PURE__ */ p("button", {
						className: $.voiceButton,
						"aria-label": `Play ${u.name} ${s.label}`,
						"aria-pressed": c === s.id,
						disabled: o,
						"data-silent": !Y(t, s.id, n),
						onClick: () => {
							l(s.id), a(s.id);
						},
						children: s.label
					}),
					/* @__PURE__ */ p(Ii, {
						mixKey: ft(t.id, s.id),
						label: `${u.name} ${s.label}`,
						mix: n,
						onToggle: r
					}),
					Ui.map((e) => {
						let n = u.params.find((t) => t.id === `${s.id}${e}`);
						return /* @__PURE__ */ m("div", {
							className: $.euclidCell,
							children: [/* @__PURE__ */ p($r, {
								trim: !0,
								param: n,
								prefix: u.name,
								disabled: e !== "Steps" && !!t.params[`${s.id}Custom`],
								value: t.params[n.id],
								onChange: (e) => i({ [n.id]: e })
							}), /* @__PURE__ */ p("output", { children: t.params[n.id] })]
						}, e);
					}),
					/* @__PURE__ */ p(Bi, {
						module: t,
						voice: s.id,
						onParams: i
					})
				] }, s.id))
			]
		}), /* @__PURE__ */ m("div", {
			className: $.orbitVoiceEditor,
			role: "group",
			"aria-label": `Edit ORBIT ${d.label}`,
			children: [
				/* @__PURE__ */ m("div", {
					className: $.orbitEditorHeading,
					children: [
						/* @__PURE__ */ m("label", { children: ["EDIT VOICE ", /* @__PURE__ */ p("select", {
							"aria-label": "Orbit edit voice",
							value: c,
							onChange: (e) => l(e.target.value),
							children: u.drum.voices.map((e) => /* @__PURE__ */ p("option", {
								value: e.id,
								children: e.label
							}, e.id))
						})] }),
						/* @__PURE__ */ p("span", { children: t.params[`${c}Custom`] ? "CUSTOM" : "EUCLIDEAN" }),
						/* @__PURE__ */ p("button", {
							disabled: !it(t, c),
							onClick: () => i(rt(t, c)),
							"aria-label": `Generate ORBIT ${d.label} rhythm`,
							title: it(t, c) ? "Spread this lane’s hits evenly" : "Already Euclidean: turn Steps, Hits or Shift",
							children: "Generate"
						})
					]
				}),
				/* @__PURE__ */ p("div", {
					className: $.controls,
					children: [
						"Tune",
						"Decay",
						"Tone",
						"Pan",
						"Lag"
					].map((e) => {
						let n = u.params.find((t) => t.id === `${c}${e}`);
						return /* @__PURE__ */ p($r, {
							param: {
								...n,
								label: e
							},
							prefix: `ORBIT ${d.label}`,
							value: t.params[n.id],
							onChange: (e) => i({ [n.id]: e })
						}, n.id);
					})
				}),
				/* @__PURE__ */ p("div", {
					className: $.orbitSteps,
					children: f.map((e, n) => /* @__PURE__ */ m("button", {
						className: $.pad,
						"aria-pressed": e,
						"data-current": s >= 0 && s % f.length === n,
						"aria-label": `ORBIT ${d.label} step ${n + 1}`,
						onClick: () => {
							let e = nt(t, c, n);
							i({
								[`${c}Pattern`]: e[`${c}Pattern`],
								[`${c}Custom`]: 1
							});
						},
						children: [/* @__PURE__ */ p("span", {}), n + 1]
					}, n))
				}),
				/* @__PURE__ */ p("small", { children: "Tap a step to customize. Generate makes it Euclidean again." })
			]
		})]
	});
}
var Gi = [
	70,
	59,
	48,
	37,
	26,
	15
];
function Ki({ module: e, clock: t }) {
	return /* @__PURE__ */ p("svg", {
		className: $.orbitRings,
		viewBox: "0 0 160 160",
		"aria-hidden": "true",
		children: U[e.type].drum.voices.map(({ id: n }, r) => {
			let i = J(e, n), a = Gi[r], o = t < 0 ? -1 : t % i.length;
			return /* @__PURE__ */ m("g", {
				"data-voice": n,
				children: [/* @__PURE__ */ p("circle", {
					className: $.orbitPath,
					cx: "80",
					cy: "80",
					r: a
				}), i.map((e, t) => {
					let n = t / i.length * 2 * Math.PI - Math.PI / 2;
					return /* @__PURE__ */ p("circle", {
						cx: (80 + a * Math.cos(n)).toFixed(2),
						cy: (80 + a * Math.sin(n)).toFixed(2),
						r: t === o ? 3.8 : e ? 3 : 1.4,
						"data-hit": e,
						"data-current": t === o
					}, t);
				})]
			}, n);
		})
	});
}
//#endregion
//#region src/components/SoundEditors.tsx
var qi = {
	boom: "ANALOG KIT · 11 VOICES",
	punch: "DANCE FLOOR KIT · 5 VOICES",
	strike: "ORIGINAL DIGITAL KIT · 16 VOICES",
	forge: "INDUSTRIAL KIT · 11 VOICES"
};
function Ji({ module: e, onParams: t, onAudition: n, disabled: r, selected: i, onSelect: a }) {
	let o = U[e.type], s = o.drum.voices.find((e) => e.id === i);
	return /* @__PURE__ */ m("div", {
		className: $.soundEditor,
		role: "group",
		"aria-label": `${o.name} voice editor`,
		children: [/* @__PURE__ */ m("div", {
			className: $.editorHeading,
			children: [
				/* @__PURE__ */ m("label", { children: ["EDIT VOICE ", /* @__PURE__ */ p("select", {
					"aria-label": `${o.name} edit voice`,
					value: i,
					onChange: (e) => a(e.target.value),
					children: o.drum.voices.map((e) => /* @__PURE__ */ p("option", {
						value: e.id,
						children: e.label
					}, e.id))
				})] }),
				/* @__PURE__ */ m("button", {
					disabled: r,
					onClick: () => n(i),
					children: ["Audition ", s.label]
				}),
				/* @__PURE__ */ p("small", { children: qi[e.type] })
			]
		}), /* @__PURE__ */ p("div", {
			className: $.controls,
			children: o.params.filter((e) => e.voice === i && !e.pattern && e.id !== `${i}Level`).map((n) => /* @__PURE__ */ p($r, {
				param: {
					...n,
					label: n.label.slice(s.label.length + 1)
				},
				prefix: `${o.name} ${s.label}`,
				value: e.params[n.id],
				onChange: (e) => t({ [n.id]: e })
			}, n.id))
		})]
	});
}
var Yi = [
	"2→1 + 4→3 + 6→5",
	"3→2→1 + 6→5→4",
	"6→5→4→3→2→1",
	"5+6→4→1+2+3",
	"4→2→1 + 6→5→3→1",
	"1 + 2 + 3 + 4 + 5 + 6"
];
function Xi({ module: e, onParams: t }) {
	let [n, r] = u(1);
	return /* @__PURE__ */ m("div", {
		className: $.soundEditor,
		role: "group",
		"aria-label": "PRISM operator editor",
		children: [
			/* @__PURE__ */ m("div", {
				className: $.fmDisplay,
				children: [
					/* @__PURE__ */ p("span", { children: be[e.params.algorithm] }),
					/* @__PURE__ */ p("strong", { children: Yi[e.params.algorithm] }),
					/* @__PURE__ */ p("small", { children: "16 VOICES · SIX OPERATORS · PHASE MODULATION" })
				]
			}),
			/* @__PURE__ */ p("div", {
				className: $.operatorTabs,
				role: "group",
				"aria-label": "Select PRISM operator",
				children: [
					1,
					2,
					3,
					4,
					5,
					6
				].map((e) => /* @__PURE__ */ m("button", {
					"aria-pressed": n === e,
					"aria-label": `Edit PRISM operator ${e}`,
					onClick: () => r(e),
					children: ["OP ", e]
				}, e))
			}),
			/* @__PURE__ */ p("div", {
				className: $.controls,
				children: U.prism.params.filter((e) => e.voice === `op${n}`).map((r) => /* @__PURE__ */ p($r, {
					param: r,
					prefix: `PRISM Operator ${n}`,
					value: e.params[r.id],
					onChange: (e) => t({ [r.id]: e })
				}, r.id))
			})
		]
	});
}
//#endregion
//#region src/components/PanelLegend.tsx
function Zi({ size: e, height: t, inner: n, marks: r }) {
	let i = (n, r) => [e / 2 + n * Math.sin(r * Math.PI / 180), t / 2 - n * Math.cos(r * Math.PI / 180)], a = (e, t) => n + 10 + (e.length - 1) * 2.2 * Math.abs(Math.sin(t * Math.PI / 180));
	return /* @__PURE__ */ p("svg", {
		className: $.panelLegend,
		width: e,
		height: t,
		viewBox: `0 0 ${e} ${t}`,
		"aria-hidden": "true",
		children: r.map(({ angle: e, text: t, lit: r }, o) => {
			let [s, c] = i(n, e), [l, u] = i(n + (t ? 4 : 2.5), e), [d, f] = i(a(t ?? "", e), e);
			return /* @__PURE__ */ m("g", {
				"data-lit": r || void 0,
				children: [/* @__PURE__ */ p("line", {
					x1: s,
					y1: c,
					x2: l,
					y2: u
				}), t && /* @__PURE__ */ p("text", {
					x: d,
					y: f,
					textAnchor: "middle",
					dominantBaseline: "central",
					children: t
				})]
			}, o);
		})
	});
}
//#endregion
//#region src/components/Brit.tsx
var Qi = (e) => U.brit.params.find((t) => t.id === e), $i = (e, t) => {
	let n = Math.min(270, (t - 1) * 45);
	return -n / 2 + e * n / (t - 1);
}, ea = (e, t) => e.choices ? $i(t, e.choices.length) : -135 + Vt(e, t) * 270, ta = 104, na = (e) => ({
	"--size": `${e}px`,
	"--height": `${ta}px`
});
function ra({ angle: e, skirt: t }) {
	return /* @__PURE__ */ m(f, { children: [
		t && /* @__PURE__ */ p("span", { className: $.marconiSkirt }),
		/* @__PURE__ */ p("span", { className: $.marconiFlutes }),
		/* @__PURE__ */ p("span", { className: $.marconiDome }),
		/* @__PURE__ */ p("span", {
			className: $.marconiPointer,
			style: { transform: `rotate(${e}deg)` }
		})
	] });
}
var ia = (e, t) => [...Array.from({ length: 11 }, (e, t) => ({ angle: -135 + t * 27 })), ...t.map(([t, n]) => ({
	angle: ea(e, t),
	text: n
}))], aa = (e, t) => e.map((n, r) => ({
	angle: $i(r, e.length),
	text: n,
	lit: r === t
}));
function oa({ module: e, prefix: t, onParams: n, id: r, color: i, size: a, knob: o, skirt: s, title: c, labels: l, marks: u }) {
	let d = Qi(r), f = e.params[r], { props: h, display: g } = Qr({
		param: d,
		value: f,
		prefix: t,
		onChange: (e) => n({ [r]: e })
	});
	return /* @__PURE__ */ m("div", {
		className: $.britSection,
		children: [
			/* @__PURE__ */ p("strong", { children: c }),
			/* @__PURE__ */ m("div", {
				className: $.britWell,
				style: na(a),
				children: [/* @__PURE__ */ p(Zi, {
					size: a,
					height: ta,
					inner: o / 2 + 3,
					marks: l ? aa(l, f) : ia(d, u ?? [])
				}), /* @__PURE__ */ p("div", {
					className: $.marconi,
					"data-color": i,
					"data-skirt": s || void 0,
					style: { "--knob": `${o}px` },
					...h,
					children: /* @__PURE__ */ p(ra, {
						angle: ea(d, f),
						skirt: s
					})
				})]
			}),
			!l && /* @__PURE__ */ p("span", {
				className: $.knobValue,
				children: g
			})
		]
	});
}
function sa({ module: e, prefix: t, onParams: n, frequency: r, gain: i, color: a, title: o, labels: s }) {
	let c = Qi(r), l = Qi(i), u = Qr({
		param: c,
		value: e.params[r],
		prefix: t,
		onChange: (e) => n({ [r]: e })
	}), d = Qr({
		param: l,
		value: e.params[i],
		prefix: t,
		onChange: (e) => n({ [i]: e })
	});
	return /* @__PURE__ */ m("div", {
		className: $.britSection,
		children: [
			/* @__PURE__ */ p("strong", { children: o }),
			/* @__PURE__ */ m("div", {
				className: $.britWell,
				style: na(112),
				children: [
					/* @__PURE__ */ p(Zi, {
						size: 112,
						height: ta,
						inner: 36,
						marks: aa(s, e.params[r])
					}),
					/* @__PURE__ */ p("div", {
						className: $.marconiRing,
						style: { "--ring": "66px" },
						...u.props,
						children: /* @__PURE__ */ p("span", {
							className: $.ringPointer,
							style: { transform: `rotate(${ea(c, e.params[r])}deg)` }
						})
					}),
					/* @__PURE__ */ p("div", {
						className: $.marconi,
						"data-color": a,
						style: { "--knob": "38px" },
						...d.props,
						children: /* @__PURE__ */ p(ra, { angle: ea(l, e.params[i]) })
					})
				]
			}),
			/* @__PURE__ */ p("span", {
				className: $.knobValue,
				children: d.display
			})
		]
	});
}
function ca({ module: e, onParams: t, rate: n }) {
	let r = U.brit.name, i = e.params.active === 0, a = (n) => ({
		module: e,
		onParams: t,
		prefix: `${r} ${n}`
	});
	return /* @__PURE__ */ m("div", {
		className: $.britPanel,
		"data-bypassed": !i,
		children: [
			/* @__PURE__ */ p(oa, {
				...a("Signal"),
				id: "hpf",
				color: "blue",
				size: 96,
				knob: 46,
				title: "High pass",
				labels: [
					"OFF",
					"50",
					"80",
					"160",
					"300"
				]
			}),
			/* @__PURE__ */ p(sa, {
				...a("Low shelf"),
				frequency: "lfFreq",
				gain: "lfGain",
				color: "grey",
				title: "Low · Hz",
				labels: [
					"35",
					"60",
					"110",
					"220"
				]
			}),
			/* @__PURE__ */ p(sa, {
				...a("Mid bell"),
				frequency: "midFreq",
				gain: "midGain",
				color: "blue",
				title: "Mid · kHz",
				labels: [
					".36",
					".7",
					"1.6",
					"3.2",
					"4.8",
					"7.2"
				]
			}),
			/* @__PURE__ */ p(oa, {
				...a("High shelf · 12 kHz"),
				id: "hfGain",
				color: "grey",
				size: 88,
				knob: 44,
				title: "High · 12k",
				marks: [
					[-16, "−16"],
					[0, "0"],
					[16, "+16"]
				]
			}),
			/* @__PURE__ */ p(oa, {
				...a("Signal"),
				id: "drive",
				color: "red",
				size: 100,
				knob: 64,
				skirt: !0,
				title: "Drive",
				marks: [
					[0, "0"],
					[12, "12"],
					[24, "24"]
				]
			}),
			/* @__PURE__ */ p(oa, {
				...a("Signal"),
				id: "output",
				color: "grey",
				size: 80,
				knob: 36,
				title: "Output",
				marks: [
					[-18, "−18"],
					[0, "0"],
					[18, "+18"]
				]
			}),
			/* @__PURE__ */ m("div", {
				className: $.britSection,
				children: [/* @__PURE__ */ p("strong", { children: "EQ" }), /* @__PURE__ */ m("button", {
					className: $.britSwitch,
					"aria-pressed": i,
					"aria-label": `${r} EQ in`,
					title: i ? "EQ in. Press to bypass." : "Bypassed. Press to switch the EQ in.",
					onClick: () => t({ active: +!!i }),
					children: [/* @__PURE__ */ p("span", { className: $.britLamp }), "IN"]
				})]
			}),
			/* @__PURE__ */ m("div", {
				className: `${$.britSection} ${$.britCurve}`,
				children: [/* @__PURE__ */ p("strong", { children: "Response" }), /* @__PURE__ */ p(Oi, {
					params: e.params,
					brit: !0,
					rate: n
				})]
			})
		]
	});
}
//#endregion
//#region src/components/Talon.tsx
var la = U.talon.name, ua = (e) => U.talon.params.find((t) => t.id === e), da = (e) => `${la} ${e.group} ${e.label}`, fa = (e, t) => -135 + Vt(e, t) * 270, pa = 108, ma = [
	1,
	2,
	3,
	4,
	6,
	8,
	10,
	14,
	20,
	30
];
function ha({ module: e, onParams: t, id: n, size: r, knob: i, title: a, marks: o }) {
	let s = ua(n), c = e.params[n], { props: l, display: u } = Qr({
		param: s,
		value: c,
		prefix: `${la} ${s.group}`,
		onChange: (e) => t({ [n]: e })
	}), d = [...Array.from({ length: 11 }, (e, t) => ({ angle: -135 + t * 27 })), ...o.map(([e, t]) => ({
		angle: fa(s, e),
		text: t
	}))];
	return /* @__PURE__ */ m("div", {
		className: $.talonSection,
		children: [
			/* @__PURE__ */ p("strong", { children: a }),
			/* @__PURE__ */ m("div", {
				className: $.talonWell,
				style: {
					"--size": `${r}px`,
					"--height": `${pa}px`
				},
				children: [/* @__PURE__ */ p(Zi, {
					size: r,
					height: pa,
					inner: i / 2 + 4,
					marks: d
				}), /* @__PURE__ */ m("div", {
					className: $.talonKnob,
					style: { "--knob": `${i}px` },
					...l,
					children: [
						/* @__PURE__ */ p("span", { className: $.talonGrip }),
						/* @__PURE__ */ p("span", { className: $.talonCap }),
						/* @__PURE__ */ p("span", {
							className: $.talonIndex,
							style: { transform: `rotate(${fa(s, c)}deg)` }
						})
					]
				})]
			}),
			/* @__PURE__ */ p("span", {
				className: $.knobValue,
				children: u
			})
		]
	});
}
function ga({ module: e, onParams: t, id: n, title: r, button: i, captions: a = [] }) {
	let o = ua(n), s = e.params[n], c = o.choices.length;
	function l(e) {
		let r = {
			ArrowDown: s + 1,
			ArrowRight: s + 1,
			ArrowUp: s - 1,
			ArrowLeft: s - 1,
			Home: 0,
			End: c - 1
		}[e.key];
		if (r === void 0) return;
		e.preventDefault();
		let i = Math.max(0, Math.min(c - 1, r));
		t({ [n]: i }), e.currentTarget.querySelectorAll("[role=\"radio\"]")[i].focus();
	}
	return /* @__PURE__ */ m("div", {
		className: $.talonSection,
		children: [
			/* @__PURE__ */ p("strong", { children: r }),
			/* @__PURE__ */ p("div", {
				className: $.talonLamps,
				role: "radiogroup",
				"aria-label": da(o),
				onKeyDown: l,
				children: o.choices.map((e, r) => /* @__PURE__ */ m("button", {
					type: "button",
					role: "radio",
					"aria-checked": r === s,
					tabIndex: r === s ? 0 : -1,
					onClick: () => t({ [n]: r }),
					children: [
						/* @__PURE__ */ p("span", { className: $.talonLed }),
						e,
						a[r] && /* @__PURE__ */ p("small", {
							"aria-hidden": "true",
							children: a[r]
						})
					]
				}, e))
			}),
			/* @__PURE__ */ p("button", {
				type: "button",
				className: $.talonPush,
				"aria-label": `${da(o)}: next`,
				title: `Step to the next ${o.label.toLowerCase()} mode`,
				onClick: () => t({ [n]: (s + 1) % c }),
				children: i
			})
		]
	});
}
function _a({ module: e, onParams: t, id: n, text: r }) {
	let i = ua(n), a = e.params[n] === 1;
	return /* @__PURE__ */ m("button", {
		type: "button",
		className: $.talonPush,
		"aria-pressed": a,
		"aria-label": da(i),
		title: `${i.label}: ${i.choices[e.params[n]]}`,
		onClick: () => t({ [n]: +!a }),
		children: [/* @__PURE__ */ p("span", { className: $.talonLed }), r]
	});
}
function va({ reduction: e, label: t }) {
	let n = Math.min(40, Math.max(0, -e));
	return /* @__PURE__ */ m("div", {
		className: $.talonSection,
		children: [/* @__PURE__ */ p("strong", { children: "GR" }), /* @__PURE__ */ p("div", {
			className: $.talonMeter,
			role: "meter",
			"aria-label": t,
			"aria-valuemin": 0,
			"aria-valuemax": 40,
			"aria-valuenow": n,
			"aria-valuetext": `${n} dB gain reduction`,
			children: ma.map((e) => /* @__PURE__ */ m("span", {
				"data-lit": n >= e,
				"data-hot": e > 10 || void 0,
				children: [/* @__PURE__ */ p("i", {}), e]
			}, e))
		})]
	});
}
function ya({ module: e, onParams: t, reduction: n, label: r }) {
	let i = {
		module: e,
		onParams: t
	}, a = e.params.active === 0;
	return /* @__PURE__ */ m("div", {
		className: $.talonPanel,
		"data-bypassed": !a,
		children: [
			/* @__PURE__ */ p(ha, {
				...i,
				id: "input",
				size: 100,
				knob: 60,
				title: "Input",
				marks: [
					[-12, "−12"],
					[0, "0"],
					[12, "12"],
					[30, "30"]
				]
			}),
			/* @__PURE__ */ p(ha, {
				...i,
				id: "attack",
				size: 84,
				knob: 46,
				title: "Attack · ms",
				marks: [
					[5e-5, ".05"],
					[.001, "1"],
					[.01, "10"],
					[.03, "30"]
				]
			}),
			/* @__PURE__ */ p(ha, {
				...i,
				id: "release",
				size: 84,
				knob: 46,
				title: "Release · s",
				marks: [
					[.05, ".05"],
					[.3, ".3"],
					[1, "1"],
					[3.5, "3.5"]
				]
			}),
			/* @__PURE__ */ p(ga, {
				...i,
				id: "ratio",
				title: "Ratio",
				button: "Ratio"
			}),
			/* @__PURE__ */ m("div", {
				className: $.talonSection,
				children: [/* @__PURE__ */ p(ga, {
					...i,
					id: "color",
					title: "Harmonics",
					button: "Dist",
					captions: [
						"",
						"2nd",
						"3rd"
					]
				}), /* @__PURE__ */ m("div", {
					className: $.talonLatches,
					children: [/* @__PURE__ */ p(_a, {
						...i,
						id: "audioHp",
						text: "HP 65"
					}), /* @__PURE__ */ p(_a, {
						...i,
						id: "fierce",
						text: "Fierce"
					})]
				})]
			}),
			/* @__PURE__ */ m("div", {
				className: $.talonSection,
				children: [/* @__PURE__ */ p("strong", { children: "Detector" }), /* @__PURE__ */ m("div", {
					className: $.talonLatches,
					children: [
						/* @__PURE__ */ p(_a, {
							...i,
							id: "detectorHp",
							text: "HP 80"
						}),
						/* @__PURE__ */ p(_a, {
							...i,
							id: "detectorBand",
							text: "Band 6k"
						}),
						/* @__PURE__ */ p(_a, {
							...i,
							id: "link",
							text: "Link"
						})
					]
				})]
			}),
			/* @__PURE__ */ m("div", {
				className: $.talonOutput,
				children: [
					/* @__PURE__ */ p(va, {
						reduction: n,
						label: r
					}),
					/* @__PURE__ */ p(ha, {
						...i,
						id: "output",
						size: 100,
						knob: 60,
						title: "Output",
						marks: [
							[-30, "−30"],
							[-12, "−12"],
							[0, "0"],
							[12, "+12"]
						]
					}),
					/* @__PURE__ */ m("div", {
						className: $.talonSection,
						children: [/* @__PURE__ */ p("strong", { children: "Comp" }), /* @__PURE__ */ m("button", {
							type: "button",
							className: $.talonSwitch,
							"aria-pressed": a,
							"aria-label": `${la} in`,
							title: a ? "In. Press to bypass." : "Bypassed. Press to switch TALON in.",
							onClick: () => t({ active: +!!a }),
							children: [/* @__PURE__ */ p("span", { className: $.talonLamp }), "IN"]
						})]
					})
				]
			}),
			e.params.ratio === 5 && /* @__PURE__ */ p("p", {
				className: $.processorHint,
				children: "Opto recovery lengthens with sustained reduction, up to 20 s."
			})
		]
	});
}
//#endregion
//#region src/components/EngineSwitch.tsx
var ba = [
	0,
	.14,
	.28,
	.42,
	.56,
	.7,
	.84
];
function xa({ module: e, param: t, name: n, onParams: r }) {
	let i = e.params[t.id] === 1, [a, o] = t.choices;
	return /* @__PURE__ */ m("button", {
		type: "button",
		role: "switch",
		className: $.engineSwitch,
		"aria-checked": i,
		"aria-label": `${n} ${t.label}`,
		"data-modeled": i,
		title: `${t.label}: ${i ? o : a}. Slide to ${i ? a : o}.`,
		onClick: () => r({ [t.id]: +!i }),
		children: [/* @__PURE__ */ p("span", {
			className: $.engineCaption,
			children: t.label
		}), /* @__PURE__ */ m("span", {
			className: $.togglePlate,
			"aria-hidden": "true",
			children: [
				/* @__PURE__ */ p("span", {
					className: $.toggleLegend,
					"data-lit": !i,
					children: a
				}),
				/* @__PURE__ */ m("span", {
					className: $.toggle,
					children: [/* @__PURE__ */ p("span", { className: $.toggleSlot }), /* @__PURE__ */ m("span", {
						className: $.toggleKnob,
						children: [
							/* @__PURE__ */ p("span", { className: $.toggleBrim }),
							ba.map((e) => /* @__PURE__ */ p("span", {
								className: $.toggleRib,
								style: { "--f": e }
							}, e)),
							/* @__PURE__ */ p("span", { className: $.toggleCap })
						]
					})]
				}),
				/* @__PURE__ */ p("span", {
					className: $.toggleLegend,
					"data-lit": i,
					children: o
				})
			]
		})]
	});
}
//#endregion
//#region src/components/Mixer.tsx
var Sa = 112, Ca = [
	[1, "0"],
	[10 ** (-3 / 20), "3"],
	[.5, "6"],
	[10 ** (-10 / 20), "10"],
	[.1, "20"],
	[0, "∞"]
], wa = [
	-48,
	-42,
	-36,
	-30,
	-24,
	-18,
	-12,
	-9,
	-6,
	-3,
	0
], Ta = (e) => U.mixer.params.find((t) => t.id === e), Ea = (e) => e <= 0 ? "−∞" : `${(20 * Math.log10(e)).toFixed(1).replace("-", "−")} dB`, Da = (e) => Math.abs(e) < .005 ? "C" : `${e < 0 ? "L" : "R"}${Math.round(Math.abs(e) * 100)}`;
function Oa({ level: e, label: t }) {
	let n = Math.round(e);
	return /* @__PURE__ */ p("div", {
		className: $.levelMeter,
		role: "meter",
		"aria-label": t,
		"aria-valuemin": wa[0],
		"aria-valuemax": 0,
		"aria-valuenow": Math.max(wa[0], Math.min(0, n)),
		"aria-valuetext": e < wa[0] ? "Silent" : `${n} dB`,
		children: wa.map((t) => /* @__PURE__ */ p("i", {
			"data-lit": e >= t,
			"data-zone": t >= -3 ? "hot" : t >= -9 ? "warm" : void 0
		}, t))
	});
}
function ka({ param: e, value: t, prefix: n, onChange: r, children: i }) {
	let { props: a, fraction: o, display: s } = Qr({
		param: e,
		value: t,
		prefix: n,
		onChange: r,
		format: Ea,
		travel: Sa
	});
	return /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ m("div", {
		className: $.faderBay,
		style: { "--travel": `${Sa}px` },
		children: [
			/* @__PURE__ */ p("span", {
				className: $.faderScale,
				"aria-hidden": "true",
				children: Ca.map(([e, t]) => /* @__PURE__ */ p("span", {
					style: { "--at": e },
					children: t
				}, t))
			}),
			/* @__PURE__ */ p("div", {
				className: $.faderSlot,
				...a,
				children: /* @__PURE__ */ p("span", {
					className: $.faderCap,
					style: { "--at": o }
				})
			}),
			i
		]
	}), /* @__PURE__ */ p("span", {
		className: $.faderValue,
		children: s
	})] });
}
function Aa({ module: e, patch: t, mix: n, levels: r, onParams: i, onToggle: a }) {
	let o = U[e.type].name;
	return /* @__PURE__ */ m("div", {
		className: $.console,
		children: [xe.map((s, c) => {
			let { source: l, tooltip: u, connected: d } = St(t, e.id, s), f = s.toUpperCase(), h = Se(s);
			return /* @__PURE__ */ m("div", {
				className: $.channelStrip,
				role: "group",
				"aria-label": `${o} channel ${f}: ${l}`,
				"data-plugged": d,
				"data-silent": !Y(e, s, n),
				children: [
					/* @__PURE__ */ m("div", {
						className: $.scribble,
						title: u || void 0,
						children: [/* @__PURE__ */ p("span", {
							className: $.channelSource,
							"data-source-name": !0,
							children: l
						}), /* @__PURE__ */ p("b", { children: f })]
					}),
					/* @__PURE__ */ p($r, {
						param: Ta(h),
						prefix: o,
						value: e.params[h],
						format: Da,
						caption: "PAN",
						onChange: (e) => i({ [h]: e })
					}),
					/* @__PURE__ */ p(Ii, {
						mixKey: ft(e.id, s),
						label: `${o} channel ${f}`,
						mix: n,
						onToggle: a
					}),
					/* @__PURE__ */ p(ka, {
						param: Ta(s),
						prefix: o,
						value: e.params[s],
						onChange: (e) => i({ [s]: e }),
						children: /* @__PURE__ */ p(Oa, {
							level: r.channels[c],
							label: `${o} channel ${f} level`
						})
					})
				]
			}, s);
		}), /* @__PURE__ */ m("div", {
			className: $.mixBus,
			role: "group",
			"aria-label": `${o} mix bus`,
			children: [/* @__PURE__ */ m("div", {
				className: $.scribble,
				children: [/* @__PURE__ */ p("span", {
					className: $.channelSource,
					children: "MIX BUS"
				}), /* @__PURE__ */ p("b", { children: "L · R" })]
			}), /* @__PURE__ */ m(ka, {
				param: Ta("master"),
				prefix: o,
				value: e.params.master,
				onChange: (e) => i({ master: e }),
				children: [/* @__PURE__ */ p(Oa, {
					level: r.bus[0],
					label: `${o} mix bus left level`
				}), /* @__PURE__ */ p(Oa, {
					level: r.bus[1],
					label: `${o} mix bus right level`
				})]
			})]
		})]
	});
}
//#endregion
//#region src/components/TempoInput.tsx
var ja = 40, Ma = 240;
function Na({ bpm: e, onChange: t }) {
	let [n, r] = u(String(e)), o = a();
	return i(() => {
		r(String(e));
	}, [e]), /* @__PURE__ */ m("div", {
		className: $.numberField,
		children: [
			/* @__PURE__ */ p("label", {
				htmlFor: o,
				children: "BPM"
			}),
			/* @__PURE__ */ p("input", {
				id: o,
				"aria-label": "Tempo",
				type: "number",
				min: ja,
				max: Ma,
				step: 1,
				value: n,
				onChange: (e) => {
					r(e.target.value);
					let n = Number(e.target.value);
					n >= ja && n <= Ma && t(n);
				},
				onBlur: () => {
					let i = n === "" ? e : Math.max(ja, Math.min(Ma, Number(n)));
					r(String(i)), t(i);
				}
			}),
			/* @__PURE__ */ p("input", {
				className: $.tempoSlider,
				type: "range",
				min: ja,
				max: Ma,
				step: 1,
				value: e,
				"aria-label": "Tempo slider",
				"aria-valuetext": `${e} BPM`,
				onChange: (e) => t(Number(e.target.value))
			})
		]
	});
}
//#endregion
//#region src/components/Presets.tsx
var Pa = (e) => new Date(e).toLocaleString(void 0, {
	dateStyle: "medium",
	timeStyle: "short"
});
function Fa({ presets: e, openId: t, dirty: n, onLoad: r, onLoadFactory: a, onExport: o, onDelete: s, onSaveAs: c, onImport: d, onExportCurrent: h, onClose: g }) {
	let [_, v] = u(null), y = l(null), b = l(null);
	return i(() => {
		_ && y.current?.focus();
	}, [_]), /* @__PURE__ */ m("div", {
		ref: b,
		tabIndex: -1,
		className: `${$.library} ${$.presetBrowser}`,
		role: "region",
		"aria-label": "Presets",
		children: [
			/* @__PURE__ */ m("div", {
				className: $.libraryHeading,
				children: [/* @__PURE__ */ p("strong", { children: "PRESETS" }), /* @__PURE__ */ m("span", {
					className: $.presetActions,
					children: [
						/* @__PURE__ */ p("button", {
							onClick: (e) => c(e.currentTarget),
							title: "Save a copy under a new name (⇧⌘S / Ctrl+Shift+S)",
							children: "Save as…"
						}),
						/* @__PURE__ */ p("button", {
							onClick: d,
							title: "Add a .json patch file to My Presets",
							children: "↑ Import file…"
						}),
						/* @__PURE__ */ p("button", {
							onClick: h,
							title: "Download the rack as a .json patch file",
							children: "↓ Export file"
						}),
						/* @__PURE__ */ p("button", {
							"aria-label": "Close presets",
							onClick: g,
							children: "×"
						})
					]
				})]
			}),
			/* @__PURE__ */ p("strong", {
				className: $.sectionLabel,
				children: "MY PRESETS · SAVED IN THIS BROWSER"
			}),
			e.length ? /* @__PURE__ */ p("ul", {
				className: $.presetList,
				"aria-label": "My presets",
				children: e.map((e) => {
					let { id: i, patch: { name: a } } = e, c = i === t;
					return /* @__PURE__ */ p("li", {
						className: $.presetRow,
						"data-open": c,
						children: _ === i ? /* @__PURE__ */ m(f, { children: [
							/* @__PURE__ */ m("span", {
								className: $.presetConfirm,
								children: [
									"Delete “",
									a,
									"”? This can’t be undone."
								]
							}),
							/* @__PURE__ */ p("button", {
								className: $.dangerButton,
								"aria-label": `Confirm delete ${a}`,
								onClick: () => {
									v(null), s(e), b.current?.focus();
								},
								children: "Delete"
							}),
							/* @__PURE__ */ p("button", {
								ref: y,
								"aria-label": `Keep ${a}`,
								onClick: () => v(null),
								children: "Keep"
							})
						] }) : /* @__PURE__ */ m(f, { children: [
							/* @__PURE__ */ m("button", {
								className: $.presetLoad,
								"aria-label": `Load ${a}`,
								"aria-current": c || void 0,
								onClick: () => r(e),
								children: [/* @__PURE__ */ p("strong", { children: a }), /* @__PURE__ */ p("small", { children: c ? n ? "OPEN · UNSAVED CHANGES" : "OPEN" : `Saved ${Pa(e.savedAt)}` })]
							}),
							/* @__PURE__ */ p("button", {
								"aria-label": `Export ${a}`,
								title: `Download ${a} as a .json patch file`,
								onClick: () => o(e.patch),
								children: "↓ Export"
							}),
							/* @__PURE__ */ p("button", {
								"aria-label": `Delete ${a}`,
								title: `Delete ${a} from this browser`,
								onClick: () => v(i),
								children: "Delete"
							})
						] })
					}, i);
				})
			}) : /* @__PURE__ */ p("p", {
				className: $.presetEmpty,
				children: "Nothing saved yet. Save keeps your rack here under its name; Import file adds a patch you exported."
			}),
			/* @__PURE__ */ p("strong", {
				className: $.sectionLabel,
				children: "FACTORY"
			}),
			/* @__PURE__ */ p("div", {
				className: $.factoryGrid,
				role: "group",
				"aria-label": "Factory presets",
				children: Pt.map((e) => /* @__PURE__ */ p("button", {
					title: e,
					onClick: () => a(e),
					children: e
				}, e))
			})
		]
	});
}
function Ia({ initialName: e, presets: t, onSave: n, onCancel: r }) {
	let [o, s] = u(e), c = l(null), d = a(), f = a(), h = an(t, o), g = !o.trim();
	i(() => {
		c.current?.select();
	}, []);
	function _(e) {
		if (e.key === "Escape") {
			e.preventDefault(), r();
			return;
		}
		if (e.key !== "Tab") return;
		let t = [...e.currentTarget.querySelectorAll("input, button:not(:disabled)")], n = t[0], i = t.at(-1);
		e.shiftKey && document.activeElement === n ? (e.preventDefault(), i?.focus()) : !e.shiftKey && document.activeElement === i && (e.preventDefault(), n?.focus());
	}
	return /* @__PURE__ */ p("div", {
		className: $.helpBackdrop,
		children: /* @__PURE__ */ p("div", {
			className: $.saveDialog,
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": d,
			"aria-describedby": f,
			onKeyDown: _,
			children: /* @__PURE__ */ m("form", {
				onSubmit: (e) => {
					e.preventDefault(), g || n(o);
				},
				children: [
					/* @__PURE__ */ p("strong", {
						id: d,
						className: $.saveTitle,
						children: "Save preset"
					}),
					/* @__PURE__ */ m("label", { children: ["Name", /* @__PURE__ */ p("input", {
						ref: c,
						autoFocus: !0,
						"aria-label": "Preset name",
						maxLength: 100,
						value: o,
						onChange: (e) => s(e.target.value)
					})] }),
					h && /* @__PURE__ */ m("p", {
						className: $.saveWarning,
						role: "status",
						children: [
							"“",
							h.patch.name,
							"” is already in My Presets. Saving replaces it."
						]
					}),
					/* @__PURE__ */ p("p", {
						id: f,
						className: $.saveNote,
						children: "Saved in this browser. Export a file to back it up or move it to another browser."
					}),
					/* @__PURE__ */ m("div", {
						className: $.saveButtons,
						children: [/* @__PURE__ */ p("button", {
							type: "button",
							onClick: r,
							children: "Cancel"
						}), /* @__PURE__ */ p("button", {
							type: "submit",
							className: $.saveButton,
							disabled: g,
							children: h ? "Replace" : "Save"
						})]
					})
				]
			})
		})
	});
}
//#endregion
//#region src/components/Live.tsx
function La() {
	let e = {
		pulsing: /* @__PURE__ */ new Set(),
		meter: 0,
		reductions: {},
		mixerLevels: {}
	}, t = /* @__PURE__ */ new Set();
	return {
		get: () => e,
		set(n) {
			if (!Object.keys(n).every((t) => n[t] === e[t])) {
				e = {
					...e,
					...n
				};
				for (let e of t) e();
			}
		},
		subscribe(e) {
			return t.add(e), () => {
				t.delete(e);
			};
		}
	};
}
var Ra = t(null);
function za({ select: e, children: t }) {
	let n = r(Ra), i = () => e(n.get());
	return /* @__PURE__ */ p(f, { children: t(d(n.subscribe, i, i)) });
}
//#endregion
//#region ../../../../../rackloose.svg?inline
var Ba = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2064%2064'%3e%3crect%20x='5'%20y='6'%20width='54'%20height='52'%20rx='3'%20fill='%23303337'%20stroke='%23101214'%20stroke-width='2'/%3e%3cpath%20d='M10%2010v44M54%2010v44'%20stroke='%23777'%20stroke-width='3'/%3e%3crect%20x='14'%20y='12'%20width='36'%20height='17'%20fill='%23b9503a'%20stroke='%23111'/%3e%3crect%20x='14'%20y='31'%20width='36'%20height='20'%20fill='%23a0ac9b'%20stroke='%23111'/%3e%3cg%20fill='%23232626'%20stroke='%23dfdfca'%3e%3ccircle%20cx='23'%20cy='21'%20r='5'/%3e%3ccircle%20cx='41'%20cy='21'%20r='5'/%3e%3c/g%3e%3cpath%20d='M23%2021v-4m18%204%203-3'%20stroke='%23fff'%20stroke-width='2'/%3e%3cg%20fill='%231b2221'%20stroke='%23555'%3e%3ccircle%20cx='22'%20cy='39'%20r='3'/%3e%3ccircle%20cx='42'%20cy='44'%20r='3'/%3e%3c/g%3e%3cpath%20d='M22%2039c-6%2020%2027%2020%2020%205'%20fill='none'%20stroke='%23f4bb50'%20stroke-width='3'/%3e%3cpath%20d='M7%208h50'%20stroke='%23a9abad'/%3e%3c/svg%3e", Va = {
	channels: Array(8).fill(-60),
	bus: [-60, -60]
}, Ha = [
	"a",
	"w",
	"s",
	"e",
	"d",
	"f",
	"t",
	"g",
	"y",
	"h",
	"u",
	"j",
	"k"
], Ua = [
	"a",
	"s",
	"d",
	"f",
	"g",
	"h",
	"j",
	"k",
	"l",
	";",
	"'",
	"z",
	"x",
	"c",
	"v",
	"b"
], Wa = /* @__PURE__ */ new Set([
	1,
	3,
	6,
	8,
	10
]), Ga = "input:not([type]), input[type=\"text\"], input[type=\"search\"], textarea, [contenteditable=\"true\"]", Ka = 30, qa = 40, Ja = {
	id: "depth",
	label: "Depth",
	min: -1,
	max: 1,
	step: .01,
	initial: 1
}, Ya = (e) => `${Math.round(e * 100)}%`, Xa = [
	"boom",
	"punch",
	"strike",
	"forge"
], Za = {
	oscillator: "1V / OCT",
	filter: "CV CONTROL",
	delay: "WARM REPEATS",
	boom: "LONG LOW END",
	punch: "FOUR ON THE FLOOR",
	skitter: "NO SOUND · ALL BOUNCE",
	forge: "HIT IT HARDER",
	rust: "NOTHING CLEAN"
};
function Qa(e, t, n) {
	let r = URL.createObjectURL(new Blob([e], { type: t })), i = document.createElement("a");
	i.href = r, i.download = n, i.click(), setTimeout(() => URL.revokeObjectURL(r), 1e3);
}
var $a = (e) => {
	let [t, n] = e.dataset.portKey.split(":");
	return {
		moduleId: t,
		portId: n
	};
}, eo = (e, t) => e === t || !!e && !!t && K(e, t), to = (e, t) => e.error === t.error && e.inside === t.inside && e.cableId === t.cableId && K(e.anchor, t.anchor) && e.point.x === t.point.x && e.point.y === t.point.y && eo(e.target, t.target), no = (e, t) => K(e.from, t) ? e.to : e.from, ro = (e, t) => ({
	...e,
	cables: e.cables.filter((e) => e.id !== t)
});
function io(e) {
	try {
		let t = localStorage.getItem(`${e}:baselinePatch`);
		if (t) {
			let e = Rt(t);
			return {
				signature: Lt(e),
				patch: e
			};
		}
	} catch {}
	return null;
}
function ao(e, { signature: t, patch: n }) {
	localStorage.setItem(`${e}:baseline`, t), localStorage.setItem(`${e}:baselinePatch`, It(n));
}
function oo({ key: e, patch: t, open: n }) {
	let r = Bt(localStorage, e, t);
	return r || (n ? localStorage.setItem(`${e}:open`, n) : localStorage.removeItem(`${e}:open`)), r;
}
function so({ keysEnabled: e = !0, suspended: t = !1, storageKey: r = "rackloose.patch.v1", linkBrand: o = !0 }) {
	let [d, h] = u(() => Ft()), g = l(d), _ = l(null), v = l(null), y = l(null), b = l(null), x = l(null), S = l(null), C = l(null), [w, T] = u(!1), [E, D] = u(!1), [O, ee] = u(null), [te, ne] = u(!1), [re, ie] = u(null), [ae, oe] = u("Loading patch…"), [se, k] = c((e, t) => ({
		text: t,
		serial: e.serial + 1
	}), {
		text: "Ready when you are. Enable audio, then play a key or start the pattern.",
		serial: 0
	}), ce = se.text, [le, A] = u(!0), [j, M] = u(!1), [N, P] = u(!1), [F, ue] = u(!1), [fe, I] = u(-1), [pe, me] = u([]), [he, ge] = u(48e3), [_e] = u(La), [L, ve] = u(3), [ye, be] = u(null), [xe, Se] = u(!0), [Ce, R] = u(null), [z, B] = u(null), [we, Te] = u(null), [Ee, De] = u(null), [Oe, ke] = u(null), [Ae, je] = u(4), [V, Me] = u(!1), [H, Ne] = u(dt), [Pe, Ie] = u("performance"), W = l("performance"), [Ge, Ke] = u(/* @__PURE__ */ new Set()), qe = l(/* @__PURE__ */ new Map()), [Ye, Qe] = u({}), $e = l(/* @__PURE__ */ new Set()), [et, tt] = u({}), [q, J] = u(null), [nt, rt] = u({}), [it, ot] = u({
		undo: 0,
		redo: 0
	}), ct = l(dt), ft = l(!1), mt = l(3), gt = l(qt()), vt = l(null), [Y, bt] = u([]), [wt, Dt] = u({}), [Ot, kt] = u(""), At = l(""), [jt, Mt] = u(null), Nt = l(null), Pt = l(null), X = l(null), Bt = l(0), Vt = l(!1), Ht = l(null), Wt = l(0), Gt = a(), Kt = a(), Qt = a(), $t = a(), en = `${r}:presets`, cn = Y.find((e) => e.id === wt[Ot]) ?? null, ln = cn?.id ?? null, un = nt[Ot] ?? null, dn = s(() => Lt(d), [d]), fn = s(() => cn ? Lt(cn.patch) : un?.signature ?? null, [cn, un]), pn = fn !== null && dn !== fn, mn = cn?.patch ?? un?.patch ?? null;
	i(() => {
		g.current = d, _.current?.update(d);
	}, [d]), i(() => {
		let e = new Jr(g.current, (e) => k(e.message));
		_.current = e;
		let n = 0, r = 0;
		function i(t) {
			let a = _e.get(), o = g.current.modules.filter((t) => ht(t.type) && e.pulsing(t.id)).map((e) => e.id);
			if (_e.set({ pulsing: o.length === a.pulsing.size && o.every((e) => a.pulsing.has(e)) ? a.pulsing : new Set(o) }), t - r > 40) {
				ge(e.sampleRate), I(e.clock), M(e.playing), P(e.ready), me((t) => {
					let n = e.activeNotes;
					return n.length === t.length && n.every((e, n) => e === t[n]) ? t : n;
				}), tt((t) => {
					let n = Object.fromEntries(g.current.modules.filter((e) => st(e.type)).map((t) => [t.id, {
						playing: e.modulePlaying(t.id),
						clock: e.moduleClock(t.id)
					}]));
					return JSON.stringify(n) === JSON.stringify(t) ? t : n;
				});
				let n = Object.fromEntries(g.current.modules.filter((e) => [
					"compressor",
					"cohere",
					"talon"
				].includes(e.type)).map((t) => [t.id, Math.round(e.reduction(t.id) * 2) / 2])), i = Object.fromEntries(g.current.modules.filter((e) => e.type === "mixer").map((t) => {
					let { channels: n, bus: r } = e.mixerLevels(t.id), i = {
						channels: n.map(Math.round),
						bus: r.map(Math.round)
					}, o = a.mixerLevels[t.id];
					return [t.id, o && JSON.stringify(o) === JSON.stringify(i) ? o : i];
				}));
				_e.set({
					meter: e.meter,
					reductions: JSON.stringify(n) === JSON.stringify(a.reductions) ? a.reductions : n,
					mixerLevels: Object.keys(i).length === Object.keys(a.mixerLevels).length && Object.entries(i).every(([e, t]) => a.mixerLevels[e] === t) ? a.mixerLevels : i
				}), r = t;
			}
			n = requestAnimationFrame(i);
		}
		n = requestAnimationFrame(i);
		let a = () => {
			document.hidden ? e.setSuspended(!0) : e.setSuspended(t);
		};
		document.addEventListener("visibilitychange", a);
		let o = v.current, s = (t) => e.lifted(`pointer-${t.pointerId}`), c = () => e.lifted();
		return o?.addEventListener("pointerup", s, !0), o?.addEventListener("touchend", c, !0), () => {
			cancelAnimationFrame(n), document.removeEventListener("visibilitychange", a), o?.removeEventListener("pointerup", s, !0), o?.removeEventListener("touchend", c, !0), e.dispose(), _.current = null;
		};
	}, [t, _e]), i(() => {
		_.current?.setSuspended(t);
	}, [t]), i(() => {
		A(!0);
		let e = setTimeout(() => A(!1), Math.min(9e3, 3500 + se.text.length * 40));
		return () => clearTimeout(e);
	}, [se]), i(() => {
		_.current?.setMute(F);
	}, [F, t]), i(() => {
		_.current?.setMix(H);
	}, [H, t]);
	let hn = n((e) => {
		g.current = e.patch, ct.current = e.mix, ft.current = e.mainMuted, mt.current = e.octave, At.current = e.session, h(e.patch), Ne(e.mix), ue(e.mainMuted), ve(e.octave), kt(e.session);
	}, []), gn = n(() => {
		gt.current = qt(), ot({
			undo: 0,
			redo: 0
		});
	}, []), _n = n((e, t = null) => {
		let n = {
			patch: g.current,
			mix: ct.current,
			mainMuted: ft.current,
			octave: mt.current,
			session: At.current
		}, r = {
			...n,
			...typeof e == "function" ? e(n) : e
		};
		(r.patch !== n.patch || r.mix !== n.mix || r.mainMuted !== n.mainMuted || r.octave !== n.octave || r.session !== n.session) && (gt.current = Jt(gt.current, n, t, Date.now()), ot({
			undo: gt.current.past.length,
			redo: 0
		}), hn(r));
	}, [hn]), Z = n((e, t = null) => _n((t) => ({ patch: e(t.patch) }), t), [_n]), vn = n((e, t) => {
		let n = g.current.modules.find((t) => t.id === e), r = Object.keys(t);
		if (!n || r.every((e) => n.params[e] === t[e])) return;
		let i = r.length === 1 ? U[n.type].params.find((e) => e.id === r[0]) : void 0;
		Z((n) => ({
			...n,
			modules: n.modules.map((n) => n.id === e ? {
				...n,
				params: {
					...n.params,
					...t
				}
			} : n)
		}), i && !i.choices && !i.pattern ? `param:${e}:${i.id}` : null);
	}, [Z]), yn = n((e, t) => _n((n) => ({ mix: Ct(n.mix, e, t) })), [_n]), bn = n((e) => {
		let t = At.current;
		rt((n) => ({
			...n,
			[t]: {
				signature: Lt(e),
				patch: e
			}
		}));
	}, []);
	i(() => {
		let e, t = {
			presets: [],
			error: null
		}, n = null;
		try {
			vt.current && vt.current.key !== r && oo(vt.current), e = zt(localStorage, r), t = tn(localStorage, `${r}:presets`), n = localStorage.getItem(`${r}:open`);
		} catch {
			e = {
				patch: null,
				error: "Local save unavailable. Export a patch file to keep your work."
			};
		}
		(e.error ?? t.error) && k(e.error ?? t.error);
		let i = e.patch ?? Ft(), a = e.patch ? io(r) : null;
		_.current?.panic(), W.current = i.modules[0].id, Ie(W.current);
		let o = Le("session");
		bt(t.presets), Dt(n && t.presets.some((e) => e.id === n) ? { [o]: n } : {}), Mt(null), hn({
			patch: i,
			mix: dt,
			mainMuted: !1,
			octave: mt.current,
			session: o
		}), gn(), rt({ [o]: a ?? {
			signature: Lt(i),
			patch: i
		} }), oe(e.error ?? (e.patch ? "Patch restored" : "Saved locally")), ie(r);
	}, [
		r,
		hn,
		gn
	]), i(() => {
		if (re !== r) return;
		let e = vt.current = {
			key: r,
			patch: d,
			open: ln
		}, t = setTimeout(() => {
			try {
				oe(oo(e) ?? "Saved locally");
			} catch {
				oe("Local save unavailable. Export a patch file to keep your work.");
			}
		}, 400);
		return () => clearTimeout(t);
	}, [
		d,
		ln,
		re,
		r
	]), i(() => {
		if (re === r && un) try {
			ao(r, un);
		} catch {}
	}, [
		un,
		re,
		r
	]), i(() => {
		let e = (e) => {
			if (e.key === en || e.key === null) try {
				bt(tn(localStorage, en).presets);
			} catch {}
		};
		return window.addEventListener("storage", e), () => window.removeEventListener("storage", e);
	}, [en]), i(() => {
		let e = () => {
			if (vt.current) try {
				oo(vt.current);
			} catch {}
		};
		return window.addEventListener("pagehide", e), () => {
			window.removeEventListener("pagehide", e), e();
		};
	}, []), i(() => () => {
		cancelAnimationFrame(Bt.current), cancelAnimationFrame(Wt.current);
	}, []);
	let Q = n((e) => k(e instanceof Error ? e.message : "Audio could not start. Try enabling it again."), []), xn = n((e, t = !1) => {
		(!t || $e.current.has(e)) && ($e.current.delete(e), t ? _.current?.cancel(e) : _.current?.release(e), qe.current.delete(e) && Ke(new Set(qe.current.values())));
	}, []), Sn = n(() => {
		_.current?.releaseManual(), $e.current.clear(), qe.current.clear(), Ke(/* @__PURE__ */ new Set());
	}, []), Cn = n((e, n, r = !1) => {
		if (t) return;
		let i = g.current, a = i.modules.find((e) => e.id === W.current) ?? i.modules[0], o = U[a.type];
		if (lt(i, a.id) || k(`${o.name} has no audio path to MAIN. Flip the rack to connect it.`), o.drum) {
			let t = o.drum.voices[n];
			if (!t || qe.current.has(e)) return;
			qe.current.set(e, t.id), Ke(new Set(qe.current.values())), _.current?.hit(a.id, t.id, e, r).catch(Q);
		} else a.type === "noise" && (qe.current.set(e, "noise"), Ke(new Set(qe.current.values()))), _.current?.press(e, a.type === "noise" ? 60 : (L + 1) * 12 + n, a.id, r).catch(Q);
	}, [
		Q,
		t,
		L
	]), wn = n((e, t) => Qe((n) => n[e] === t ? n : {
		...n,
		[e]: t
	}), []), Tn = n((e, n) => {
		t || _.current?.hit(e, n).catch(Q);
	}, [Q, t]), En = n(() => {
		_.current?.playing ? _.current.pause() : _.current?.play().catch(Q);
	}, [Q]), Dn = n((e) => {
		at(e.type) && W.current !== e.id && (Sn(), W.current = e.id, Ie(e.id));
	}, [Sn]);
	i(() => {
		if (!e || t || O || jt !== null) {
			Sn();
			return;
		}
		function n(e) {
			if (e.defaultPrevented || e.metaKey || e.ctrlKey || e.altKey || e.target instanceof Element && e.target.closest("input, select, textarea, [contenteditable=\"true\"]")) return;
			let t = g.current.modules.find((e) => e.id === W.current), n = t && (U[t.type].drum?.voices.length ?? +(t.type === "noise")), r = (n ? Ua.slice(0, n) : Ha).indexOf(e.key.toLowerCase());
			r >= 0 && (e.preventDefault(), e.repeat || Cn(`key-${e.code}`, r));
		}
		let r = (e) => xn(`key-${e.code}`);
		return window.addEventListener("keydown", n), window.addEventListener("keyup", r), window.addEventListener("blur", Sn), () => {
			window.removeEventListener("keydown", n), window.removeEventListener("keyup", r), window.removeEventListener("blur", Sn), Sn();
		};
	}, [
		e,
		t,
		Cn,
		xn,
		En,
		O,
		jt,
		Sn
	]), i(() => {
		if (!e || t || O || jt !== null) return;
		let n = (e) => {
			if (e.code !== "Space" || e.metaKey || e.ctrlKey || e.altKey) return;
			let t = e.target instanceof Element ? e.target : null;
			t?.closest(Ga) || (v.current?.contains(t) || !e.defaultPrevented && !t?.closest("button, [role=\"button\"], [role=\"slider\"], input, select, [contenteditable=\"true\"]")) && (e.preventDefault(), e.stopPropagation(), e.type === "keydown" && !e.repeat && En());
		};
		return window.addEventListener("keydown", n, !0), window.addEventListener("keyup", n, !0), () => {
			window.removeEventListener("keydown", n, !0), window.removeEventListener("keyup", n, !0);
		};
	}, [
		e,
		t,
		O,
		jt,
		En
	]), i(() => {
		if (!Oe) return;
		let e = y.current, t = e?.querySelector(`[data-module-id="${Oe}"]`);
		if (e && t) {
			let n = t.offsetTop - 6, r = t.offsetTop + t.offsetHeight + 6, i = matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth";
			n < e.scrollTop || r - n > e.clientHeight ? e.scrollTo({
				top: n,
				behavior: i
			}) : r > e.scrollTop + e.clientHeight && e.scrollTo({
				top: r - e.clientHeight,
				behavior: i
			});
		}
		let n = setTimeout(() => ke(null), 1400);
		return () => clearTimeout(n);
	}, [Oe]);
	let On = n(() => {
		X.current = null, cancelAnimationFrame(Bt.current), Bt.current = 0, Te(null);
	}, []), kn = n(() => {
		let e = X.current;
		return !e?.moved || e.cancelled ? !1 : (e.cancelled = !0, cancelAnimationFrame(Bt.current), Bt.current = 0, Te(null), !0);
	}, []), An = n((e) => {
		let t = (e === "undo" ? Yt : Xt)(gt.current, {
			patch: g.current,
			mix: ct.current,
			mainMuted: ft.current,
			octave: mt.current,
			session: At.current
		});
		if (!t) return;
		gt.current = t.history, ot({
			undo: t.history.past.length,
			redo: t.history.future.length
		}), X.current && (Vt.current = !0), On(), B(null), J(null), R((e) => e && t.state.patch.cables.some((t) => t.id === e) ? e : null), t.state.patch.modules.some((e) => e.id === W.current) || (Sn(), W.current = t.state.patch.modules[0].id, Ie(W.current)), hn(t.state);
		let n = e === "undo" ? t.history.past.length : t.history.future.length;
		k(`${e === "undo" ? "Undone" : "Redone"}. ${n} more ${n === 1 ? "step" : "steps"} to ${e}.`);
	}, [
		hn,
		Sn,
		On
	]);
	i(() => {
		let t = (t) => {
			if (!(t.key !== "Escape" || t.defaultPrevented)) {
				if (kn()) {
					t.preventDefault(), k("Drag cancelled. Your cables are unchanged.");
					return;
				}
				(z || q || Ce) && (e || v.current?.contains(t.target)) && (t.preventDefault(), B(null), J(null), R(null), k(q ? "Plug back in its jack." : "Patching cancelled."));
			}
		}, n = () => kn();
		return window.addEventListener("keydown", t, !0), window.addEventListener("blur", n), () => {
			window.removeEventListener("keydown", t, !0), window.removeEventListener("blur", n);
		};
	}, [
		z,
		q,
		Ce,
		e,
		kn
	]), i(() => {
		if (!Ce) return;
		let t = (t) => {
			if (t.key !== "Delete" && t.key !== "Backspace" || t.defaultPrevented || t.metaKey || t.ctrlKey || t.altKey) return;
			let n = t.target instanceof Element ? t.target : null;
			n?.closest("input, select, textarea, [contenteditable=\"true\"]") || !e && !v.current?.contains(n) || (t.preventDefault(), Z((e) => ro(e, Ce)), R(null), B(null), J(null), k("Cable removed. Undo puts it back."));
		};
		return window.addEventListener("keydown", t, !0), () => window.removeEventListener("keydown", t, !0);
	}, [
		Ce,
		e,
		Z
	]), i(() => {
		let n = (n) => {
			if (n.defaultPrevented || n.altKey || !(n.metaKey || n.ctrlKey) || O || jt !== null) return;
			let r = n.key.toLowerCase(), i = r === "z" && !n.shiftKey, a = r === "z" && n.shiftKey || r === "y" && n.ctrlKey && !n.shiftKey;
			if (!i && !a) return;
			let o = n.target instanceof Element ? n.target : null;
			(v.current?.contains(o) || e && !t && !o?.closest("input, select, textarea, [contenteditable=\"true\"]")) && (n.preventDefault(), An(i ? "undo" : "redo"));
		};
		return window.addEventListener("keydown", n, !0), () => window.removeEventListener("keydown", n, !0);
	}, [
		e,
		t,
		O,
		jt,
		An
	]);
	let jn = n((e) => {
		try {
			let t = e(tn(localStorage, en).presets);
			if (t.length > 200) return "My Presets holds up to 200 presets. Delete or export some first.";
			let n = nn(localStorage, en, t);
			return n || bt(t), n;
		} catch {
			return Zt;
		}
	}, [en]), Mn = n((e, t) => {
		let n = jn((n) => rn(n, {
			id: e,
			savedAt: Date.now(),
			patch: t
		}));
		if (n) {
			k(n);
			return;
		}
		let r = At.current;
		Dt((t) => ({
			...t,
			[r]: e
		})), bn(t), k(`Saved “${t.name}” in this browser.`);
	}, [jn, bn]), Nn = n((e) => {
		Pt.current = e ?? (document.activeElement instanceof HTMLElement ? document.activeElement : null), Mt(g.current.name);
	}, []), Pn = n((e) => {
		let t = g.current;
		!cn || !t.name.trim() || an(Y, t.name, cn.id) ? Nn(e) : Mn(cn.id, t);
	}, [
		cn,
		Y,
		Nn,
		Mn
	]);
	i(() => {
		let n = (n) => {
			if (n.defaultPrevented || n.altKey || !(n.metaKey || n.ctrlKey) || n.key.toLowerCase() !== "s") return;
			let r = n.target instanceof Element ? n.target : null, i = !!v.current?.contains(r);
			if (O || jt !== null) {
				i && n.preventDefault();
				return;
			}
			(i || e && !t && !r?.closest("input, select, textarea, [contenteditable=\"true\"]")) && (n.preventDefault(), n.shiftKey ? Nn() : Pn());
		};
		return window.addEventListener("keydown", n, !0), () => window.removeEventListener("keydown", n, !0);
	}, [
		e,
		t,
		O,
		jt,
		Pn,
		Nn
	]);
	function Fn(e, t, n, r = null) {
		Z((r) => {
			let i = Ve(r, e), a = i[t];
			return !a || Object.keys(n).every((e) => a[e] === n[e]) ? r : He(r, e, i.map((e, r) => r === t ? {
				...e,
				...n
			} : e));
		}, r && `${r}:${e}`);
	}
	function In(e, t) {
		Z((n) => n.sequencer[e] === t ? n : {
			...n,
			sequencer: {
				...n.sequencer,
				[e]: t
			}
		}, e);
	}
	function Ln(e, t) {
		Z((n) => n.cables.some((n) => n.id === e && n.amount !== t) ? {
			...n,
			cables: n.cables.map((n) => n.id === e ? {
				...n,
				amount: t
			} : n)
		} : n, `depth:${e}`);
	}
	function Rn(e, t, n = null) {
		On(), J(null), _.current?.panic(), Sn();
		let r = Le("session");
		n && Dt((e) => ({
			...e,
			[r]: n
		})), _n({
			patch: e,
			mix: dt,
			mainMuted: !1,
			session: r
		}), bn(e), ne(!1), W.current = e.modules[0].id, Ie(W.current), be(null), R(null), B(null), k(pn ? `${t} Undo brings back your unsaved changes.` : t);
	}
	function zn() {
		mn && pn && (X.current && (Vt.current = !0), On(), B(null), J(null), be(null), R((e) => e && mn.cables.some((t) => t.id === e) ? e : null), mn.modules.some((e) => e.id === W.current) || (Sn(), W.current = mn.modules[0].id, Ie(W.current)), _n({ patch: mn }), k(`Reverted to “${mn.name}” as ${cn ? "last saved" : "loaded"}. Undo brings back your changes.`));
	}
	function Bn() {
		Mt(null);
		let e = Pt.current;
		Pt.current = null, e?.isConnected && e.focus();
	}
	function Vn(e) {
		e !== g.current.name && Z((t) => ({
			...t,
			name: e
		})), Mn(an(Y, e)?.id ?? Le("preset"), g.current), Bn();
	}
	function Hn(e) {
		let t = jn((t) => t.filter((t) => t.id !== e.id));
		k(t ?? `Deleted “${e.patch.name}” from this browser.${e.id === ln ? " The rack still has it; Save adds it back." : ""}`);
	}
	function Un(e) {
		let t = `${sn(e.name)}.rackloose.json`;
		Qa(It(e), "application/json", t), k(`Exported ${t}. Import it in any browser to add it to My Presets.`);
	}
	function Wn(e) {
		let t = ze(e);
		Z((e) => ({
			...e,
			modules: [
				...e.modules.slice(0, -1),
				t,
				e.modules.at(-1)
			]
		})), Dn(t), D(!1), ke(t.id), k(`${U[e].name} added. Flip the rack to connect it.`);
	}
	function Gn(e) {
		let t = {
			...e,
			id: Le(),
			params: { ...e.params }
		};
		Z((n) => {
			let r = [...n.modules];
			return r.splice(r.findIndex((t) => t.id === e.id) + 1, 0, t), {
				...n,
				modules: r
			};
		}), Dn(t), ke(t.id), k(`${U[e.type].name} duplicated without its cables.`);
	}
	function Kn(e) {
		if (e.key === "Tab") {
			let t = e.currentTarget.querySelectorAll("button");
			t.length === 1 && (e.preventDefault(), t[0].focus());
		}
	}
	function qn() {
		ee(null), (O === "about" ? S : x).current?.focus();
	}
	function Jn(e, t, n = null) {
		try {
			let r = ut(g.current, e, t, n);
			if (B(null), J(null), r === g.current) {
				k("Plug back in its jack.");
				return;
			}
			_n({ patch: r }), k(n ? "Cable moved." : "Connected. Flip to the front to hear your patch.");
		} catch (e) {
			Q(e);
		}
	}
	function Yn(e) {
		Z((t) => ro(t, e)), R(null), J(null), k("Cable unplugged. Undo puts it back.");
	}
	function Xn(e) {
		if (Vt.current) {
			Vt.current = !1;
			return;
		}
		let t = We(g.current, e);
		if (q) {
			t?.id === q.cableId && !K(e, q.anchor) ? (J(null), k("Plug back in its jack.")) : Jn(q.anchor, e, q.cableId);
			return;
		}
		if (z && K(z, e)) {
			B(null), k("Patching cancelled.");
			return;
		}
		if (z) {
			Jn(z, e);
			return;
		}
		if (t) {
			J({
				cableId: t.id,
				anchor: no(t, e)
			}), R(t.id), k("Plug lifted. Choose a free jack, or tap empty rack space to unplug. Tap the jack again or press Escape to put it back.");
			return;
		}
		let n = G(g.current, e);
		n && (B(e), R(null), k(`Choose a free ${n.kind.toUpperCase()} ${n.direction === "out" ? "input" : "output"}. Escape cancels.`));
	}
	function Zn(e) {
		w && !e.target.closest("button, [role=\"button\"], [role=\"slider\"], input, select, label, a") && (q ? Yn(q.cableId) : z ? (B(null), k("Patching cancelled.")) : R(null));
	}
	function Qn(e) {
		let t = y.current;
		if (!t) return null;
		let n = t.getBoundingClientRect(), r = e.clientX >= n.left && e.clientX <= n.right && e.clientY >= n.top && e.clientY <= n.bottom, i = null, a = Ka;
		r && t.querySelectorAll("[data-port-key]").forEach((t) => {
			let r = t.getBoundingClientRect(), o = r.left + r.width / 2, s = r.top + r.height / 2, c = e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom ? -1 : Math.hypot(o - e.clientX, s - e.clientY);
			c >= a || s < n.top || s > n.bottom || (i = $a(t), a = c);
		});
		let o = !!i && K(i, e.anchor), s = i && !o ? Je(g.current, e.anchor, i, e.cableId) : null;
		return {
			anchor: e.anchor,
			cableId: e.cableId,
			target: s || o ? null : i,
			candidate: i,
			error: s,
			inside: r,
			point: {
				x: e.clientX - n.left + t.scrollLeft,
				y: e.clientY - n.top + t.scrollTop
			}
		};
	}
	function $n() {
		let e = X.current, t = y.current;
		if (!e?.moved || e.cancelled || !t) {
			Bt.current = 0;
			return;
		}
		let n = t.getBoundingClientRect(), r = n.top + qa - e.clientY, i = e.clientY - (n.bottom - qa);
		r > 0 ? t.scrollTop -= Math.ceil(Math.min(r, qa) / 3) : i > 0 && (t.scrollTop += Math.ceil(Math.min(i, qa) / 3));
		let a = Qn(e);
		Te((e) => e && a && to(e, a) ? e : a), Bt.current = requestAnimationFrame($n);
	}
	function er(e, t) {
		if (!e.isPrimary || e.button !== 0) return;
		e.stopPropagation(), Vt.current = !1;
		let n = We(g.current, t);
		X.current = {
			pointerId: e.pointerId,
			anchor: n ? no(n, t) : t,
			cableId: n?.id ?? null,
			x: e.clientX,
			y: e.clientY,
			clientX: e.clientX,
			clientY: e.clientY,
			moved: !1,
			cancelled: !1
		}, e.currentTarget.setPointerCapture(e.pointerId);
	}
	function tr(e) {
		let t = X.current;
		if (t && t.pointerId === e.pointerId && !t.cancelled) {
			if (t.clientX = e.clientX, t.clientY = e.clientY, !t.moved) {
				if (Math.hypot(e.clientX - t.x, e.clientY - t.y) <= 5) return;
				t.moved = !0, B(null), J(null), R(t.cableId), k(t.cableId ? "Plug pulled out. Drop it on a free jack, or on empty rack space to unplug. Escape puts it back." : "Drop the plug on a free highlighted jack. Escape cancels.");
			}
			Bt.current ||= requestAnimationFrame($n);
		}
	}
	function nr(e) {
		let t = X.current;
		if (!t || t.pointerId !== e.pointerId) return;
		t.clientX = e.clientX, t.clientY = e.clientY, t.moved ||= Math.hypot(t.clientX - t.x, t.clientY - t.y) > 5;
		let n = Qn(t);
		On(), (t.moved || t.cancelled) && (Vt.current = !0), t.moved && !t.cancelled && (n?.error ? k(`${n.error}${t.cableId ? " The plug went back in its jack." : ""}`) : n?.target ? (Jn(t.anchor, n.target, t.cableId), t.cableId && R(t.cableId)) : t.cableId && n?.inside && !n.candidate ? Yn(t.cableId) : k(t.cableId ? "Plug back in its jack." : "Connection cancelled. Your cables are unchanged."));
	}
	function rr() {
		X.current && (Vt.current = !0, On());
	}
	function ir(e) {
		let t = q?.anchor ?? z;
		t && !X.current && e.pointerType === "mouse" && (Ht.current = {
			anchor: t,
			cableId: q?.cableId ?? null,
			clientX: e.clientX,
			clientY: e.clientY
		}, Wt.current ||= requestAnimationFrame(() => {
			Wt.current = 0;
			let e = Ht.current && Qn(Ht.current);
			De((t) => t && e && to(t, e) ? t : e);
		}));
	}
	async function ar(e) {
		if (e) {
			try {
				if (e.size > 1e6) throw Error("Patch files must be smaller than 1 MB.");
				let t = await e.text(), n = Rt(t), r = n.cables.length;
				try {
					let e = JSON.parse(t);
					Array.isArray(e.cables) && (r = e.cables.length);
				} catch {}
				let i = r - n.cables.length, a = i > 0 ? ` ${i} ${i === 1 ? "cable shared a jack" : "cables shared jacks"} with no spare left, so ${i === 1 ? "it was" : "they were"} left out.` : "", o = n.name.trim() ? n.name : "Imported patch", s = an(Y, o);
				if (s && Lt(s.patch) === Lt({
					...n,
					name: s.patch.name
				})) Rn(s.patch, `“${s.patch.name}” is already in My Presets, so it opened.${a}`, s.id);
				else {
					let e = {
						id: Le("preset"),
						savedAt: Date.now(),
						patch: {
							...n,
							name: s ? on(Y, o) : o
						}
					}, t = jn((t) => rn(t, e));
					Rn(e.patch, t ? `Opened “${e.patch.name}”. ${t}${a}` : `Imported “${e.patch.name}” into My Presets.${s ? ` You already had a different “${s.patch.name}”.` : ""}${a}`, t ? null : e.id);
				}
			} catch (e) {
				Q(e);
			}
			b.current && (b.current.value = "");
		}
	}
	async function or() {
		Me(!0), k("Rendering your patch…");
		try {
			Qa(Xr(await Yr(d, Ae, H)), "audio/wav", `${sn(d.name)}.wav`), k("WAV exported. Your loop includes a two-second effects tail.");
		} catch (e) {
			Q(e);
		} finally {
			Me(!1);
		}
	}
	let sr = d.cables.find((e) => e.id === Ce), cr = q?.anchor ?? z, lr = q?.cableId ?? null, ur = we ?? (w && cr && Ee && K(Ee.anchor, cr) && Ee.cableId === lr ? Ee : null), dr = we?.anchor ?? cr, fr = we ? we.cableId : lr, pr = ur?.cableId ?? null;
	function mr(e, t, n) {
		let r = U[e.type], i = {
			moduleId: e.id,
			portId: t.id
		}, a = !!dr && K(dr, i), o = We(d, i), s = !!o && (o.id !== pr || a), c = t.direction === "in" ? "input" : "output", l = e.type === "mixer" && t.direction === "in" ? St(d, e.id, t.id) : null, u = l ? `Channel ${t.id.toUpperCase()}: ${l.source}` : t.label;
		return /* @__PURE__ */ p("button", {
			className: $.socket,
			"data-port-key": `${e.id}:${t.id}`,
			"data-kind": t.kind,
			"data-jack": n ?? void 0,
			"data-connected": s,
			"data-compatible": !!dr && !a && !Je(d, dr, i, fr),
			"data-pending": a,
			"data-lifted": !!q && o?.id === q.cableId && !a,
			"data-target": !!ur?.target && K(ur.target, i),
			"data-selected-end": !!sr && sr.id !== pr && (K(sr.from, i) || K(sr.to, i)),
			"aria-label": `${r.name} ${u} ${c}${n && n > 1 ? ` ${n}` : ""}`,
			"aria-description": `${t.kind.toUpperCase()} ${c}${l?.tooltip ? ` · ${l.tooltip}` : ""}`,
			title: `${u}${l?.tooltip ? ` · ${l.tooltip}` : ""}${n ? ` · jack ${n}` : ""} · ${t.kind.toUpperCase()}${o ? " · plugged" : ""}`,
			onClick: () => Xn(i),
			onPointerDown: (e) => er(e, i),
			onPointerMove: tr,
			onPointerUp: nr,
			onPointerCancel: rr,
			onLostPointerCapture: rr,
			children: /* @__PURE__ */ p("span", {})
		}, t.id);
	}
	function hr(e) {
		let t = U[e.type];
		return /* @__PURE__ */ p("div", {
			className: $.portGroups,
			children: ["in", "out"].filter((e) => t.ports.some((t) => t.direction === e)).map((n) => {
				let r = t.ports.filter((e) => e.direction === n);
				return /* @__PURE__ */ m("div", {
					className: $.portGroup,
					"data-direction": n,
					children: [/* @__PURE__ */ p("span", {
						className: $.portHeading,
						children: n === "in" ? "INPUTS" : "OUTPUTS"
					}), /* @__PURE__ */ p("div", {
						className: $.portRow,
						children: r.filter((e) => !e.copyOf).map((i) => {
							let a = r.filter((e) => e === i || e.copyOf === i.id), o = n === "in" && i.kind === "cv", s = o ? d.cables.find((t) => K(t.to, {
								moduleId: e.id,
								portId: i.id
							})) : void 0, c = e.type === "mixer" && n === "in" ? St(d, e.id, i.id) : null;
							return /* @__PURE__ */ m("div", {
								className: $.socketControl,
								"data-source": !!c,
								"data-trim": o,
								"data-jacks": a.length,
								children: [
									a.length > 1 ? /* @__PURE__ */ p("div", {
										className: $.jacks,
										children: a.map((n) => mr(e, n, Ue(t.ports, n)))
									}) : mr(e, i, null),
									o && /* @__PURE__ */ p($r, {
										trim: !0,
										param: Ja,
										value: s?.amount ?? Ja.initial,
										format: Ya,
										prefix: `${t.name} ${i.label}`,
										disabled: !s,
										onChange: (e) => {
											s && Ln(s.id, e);
										}
									}),
									/* @__PURE__ */ p("span", {
										title: c?.tooltip || void 0,
										children: c?.source ?? i.label
									}),
									(n !== "in" || i.kind !== "audio") && /* @__PURE__ */ m("small", { children: [i.kind.toUpperCase(), s && ` · ${Ya(s.amount)}`] })
								]
							}, i.id);
						})
					})]
				}, n);
			})
		});
	}
	function gr(e) {
		let t = Ye[e.id];
		return U[e.type].drum?.voices.some((e) => e.id === t) ? t : void 0;
	}
	function _r(e, t, n) {
		return t.choices ? /* @__PURE__ */ m("label", {
			className: $.selectControl,
			children: [
				/* @__PURE__ */ p("span", {
					className: $.controlLabel,
					children: t.label
				}),
				/* @__PURE__ */ p("select", {
					"aria-label": `${n} ${t.label}`,
					value: e.params[t.id],
					onChange: (n) => vn(e.id, { [t.id]: Number(n.target.value) }),
					children: t.choices.map((e, t) => /* @__PURE__ */ p("option", {
						value: t,
						children: e
					}, e))
				}),
				/* @__PURE__ */ p(Di, {
					param: t,
					value: e.params[t.id]
				})
			]
		}, t.id) : /* @__PURE__ */ p($r, {
			param: t,
			prefix: n,
			value: e.params[t.id],
			onChange: (n) => vn(e.id, { [t.id]: n })
		}, t.id);
	}
	function vr(e) {
		let t = U[e.type], n = [...new Set(t.params.filter((e) => e.group && !e.voice).map((e) => e.group))];
		return n.length ? /* @__PURE__ */ p("div", {
			className: $.groupControls,
			"data-type": e.type,
			children: n.map((n) => /* @__PURE__ */ m("fieldset", {
				"data-group": n,
				children: [/* @__PURE__ */ p("legend", { children: n }), /* @__PURE__ */ p("div", {
					className: $.controls,
					children: t.params.filter((e) => e.group === n && !de.includes(e.id)).map((r) => _r(e, r, `${t.name} ${n}`))
				})]
			}, n))
		}) : null;
	}
	function yr(e) {
		return xt(d, e);
	}
	function br(e) {
		let n = !!et[e.id]?.playing;
		return /* @__PURE__ */ m("button", {
			className: $.playButton,
			disabled: t,
			"aria-label": `${n ? "Stop" : "Play"} ${yr(e)} sequencer`,
			"data-playing": n,
			onClick: () => {
				_.current?.modulePlaying(e.id) ? _.current.stopModule(e.id) : _.current?.play(e.id).catch(Q);
			},
			children: [/* @__PURE__ */ p(Fi, { name: n ? "stop" : "play" }), /* @__PURE__ */ p("span", { children: n ? "STOP" : "PLAY" })]
		});
	}
	let xr = d.modules.find((e) => e.id === Pe) ?? d.modules[0], Sr = U[xr.type], Cr = Sr.drum?.voices ?? (xr.type === "noise" ? [{
		id: "noise",
		label: "Noise"
	}] : null), wr = (e) => {
		Sr.drum && !t && wn(xr.id, e);
	}, Tr = Cr && Cr.length > 6 ? Math.ceil(Cr.length / 2) : 6, Er = lt(d, xr.id) ? null : `${Sr.name} needs an audio path to MAIN. Flip the rack to connect it.`;
	function Dr(e) {
		let t = Ve(d, e.id), n = et[e.id]?.clock ?? -1, r = n < 0 ? -1 : n % 16, i = yr(e), a = i !== U[e.type].name, o = ye?.moduleId === e.id ? ye.index : null, s = o === null ? null : t[o];
		return /* @__PURE__ */ m("div", {
			className: $.sequenceBody,
			children: [
				/* @__PURE__ */ m("div", {
					className: $.sequenceTop,
					children: [
						/* @__PURE__ */ m("div", {
							className: $.lcd,
							children: [
								/* @__PURE__ */ p("small", { children: "SEQUENCER" }),
								/* @__PURE__ */ m("strong", { children: [r >= 0 ? String(r + 1).padStart(2, "0") : "16", /* @__PURE__ */ p("span", { children: "STEPS" })] }),
								/* @__PURE__ */ p("span", {
									className: $.lcdDots,
									"aria-hidden": "true"
								})
							]
						}),
						U.performance.params.map((t) => _r(e, t, i)),
						/* @__PURE__ */ m("div", {
							className: $.transport,
							children: [br(e), /* @__PURE__ */ p("span", {
								className: $.transportCaption,
								children: "16TH NOTE / MONO"
							})]
						})
					]
				}),
				/* @__PURE__ */ p("div", {
					className: $.steps,
					role: "group",
					"aria-label": `${i} steps`,
					children: t.map((t, n) => /* @__PURE__ */ m("div", {
						className: $.stepCell,
						children: [/* @__PURE__ */ m("button", {
							className: $.step,
							"data-enabled": t.enabled,
							"data-silent": !yt(e.id, n, H),
							"data-current": r === n,
							"data-editing": o === n,
							"aria-label": `Step ${n + 1}: ${t.enabled ? Ut(t.note) : "rest"}`,
							"aria-pressed": o === n,
							onClick: () => be(o === n ? null : {
								moduleId: e.id,
								index: n
							}),
							children: [
								/* @__PURE__ */ p("span", { className: $.stepLed }),
								/* @__PURE__ */ p("span", {
									className: $.stepNumber,
									children: String(n + 1).padStart(2, "0")
								}),
								/* @__PURE__ */ p("strong", { children: t.enabled ? Ut(t.note) : "—" })
							]
						}), /* @__PURE__ */ p(Ii, {
							mixKey: pt(e.id, n),
							label: a ? `${i} step ${n + 1}` : `step ${n + 1}`,
							mix: H,
							onToggle: yn
						})]
					}, n))
				}),
				o !== null && s && /* @__PURE__ */ m("div", {
					className: $.stepEditor,
					children: [
						/* @__PURE__ */ m("strong", { children: ["STEP ", String(o + 1).padStart(2, "0")] }),
						/* @__PURE__ */ m("label", { children: [/* @__PURE__ */ p("input", {
							type: "checkbox",
							checked: s.enabled,
							onChange: (t) => Fn(e.id, o, { enabled: t.target.checked })
						}), "Note on"] }),
						/* @__PURE__ */ m("label", { children: ["Note", /* @__PURE__ */ p("select", {
							"aria-label": "Step note",
							value: s.note,
							onChange: (t) => Fn(e.id, o, { note: Number(t.target.value) }),
							children: Array.from({ length: 73 }, (e, t) => t + 24).map((e) => /* @__PURE__ */ p("option", {
								value: e,
								children: Ut(e)
							}, e))
						})] }),
						/* @__PURE__ */ m("label", { children: [
							"Velocity",
							/* @__PURE__ */ p("input", {
								"aria-label": "Step velocity",
								type: "range",
								min: 0,
								max: 1,
								step: .01,
								value: s.velocity,
								onChange: (t) => Fn(e.id, o, { velocity: Number(t.target.value) }, `step:${o}:velocity`)
							}),
							/* @__PURE__ */ m("output", { children: [Math.round(s.velocity * 100), "%"] })
						] }),
						/* @__PURE__ */ m("label", { children: [
							"Gate",
							/* @__PURE__ */ p("input", {
								"aria-label": "Step gate",
								type: "range",
								min: .1,
								max: .95,
								step: .01,
								value: s.gate,
								onChange: (t) => Fn(e.id, o, { gate: Number(t.target.value) }, `step:${o}:gate`)
							}),
							/* @__PURE__ */ m("output", { children: [Math.round(s.gate * 100), "%"] })
						] }),
						/* @__PURE__ */ p("button", {
							onClick: () => be(null),
							"aria-label": "Close step editor",
							children: "×"
						})
					]
				}),
				/* @__PURE__ */ m("div", {
					className: $.sequenceHint,
					children: ["Click a step to edit its note, velocity & gate.", /* @__PURE__ */ p("span", { children: "PATCHABLE PITCH + GATE" })]
				})
			]
		});
	}
	let Or = _t(d, H), kr = ![
		"Saved locally",
		"Patch restored",
		"Loading patch…"
	].includes(ae), Ar = /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("img", {
		className: $.brandMark,
		src: Ba,
		width: "48",
		height: "48",
		alt: ""
	}), /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("strong", { children: "Rackloose" }), /* @__PURE__ */ p("small", { children: "MODULAR SYNTHESIZER" })] })] }), jr = ur || z || q ? fr ? "Drop the plug on a free highlighted jack, or on empty rack space to unplug. Escape puts it back." : "Choose a free highlighted jack. Escape cancels." : sr ? "Drag either plug to move it. Delete unplugs this cable." : "One cable per jack. Drag from a jack to patch; drag a plug to move or unplug it.";
	return /* @__PURE__ */ p(Ra.Provider, {
		value: _e,
		children: /* @__PURE__ */ m("section", {
			ref: v,
			className: $.app,
			"aria-label": "Rackloose modular synthesizer",
			onKeyDown: (e) => {
				e.key !== "Escape" || e.defaultPrevented || (O ? qn() : jt === null ? te ? (ne(!1), Nt.current?.focus()) : E ? (D(!1), C.current?.focus()) : (z || Ce || q) && (B(null), R(null), J(null), k(q ? "Plug back in its jack." : "Patching cancelled.")) : Bn());
			},
			children: [
				/* @__PURE__ */ m("header", {
					className: $.toolbar,
					children: [o ? /* @__PURE__ */ p("a", {
						className: $.brand,
						href: "https://rackloose.michaelzick.com/",
						target: "_blank",
						rel: "noopener noreferrer",
						title: "Open Rackloose in a new tab",
						children: Ar
					}) : /* @__PURE__ */ p("div", {
						className: $.brand,
						children: Ar
					}), /* @__PURE__ */ m("div", {
						className: $.toolbarActions,
						children: [
							/* @__PURE__ */ m("button", {
								className: $.audioButton,
								"data-ready": N,
								disabled: t,
								onClick: () => {
									N ? (_.current?.panic(), k("Audio stopped.")) : _.current?.unlock().then(() => k("Audio enabled. Play A–K, tap a key, or start the pattern.")).catch(Q);
								},
								children: [/* @__PURE__ */ p("span", { className: $.statusLed }), N ? "Audio on" : "Enable audio"]
							}),
							/* @__PURE__ */ p("button", {
								onClick: () => {
									_.current?.panic(), k("Panic: all sound and pending notes cleared.");
								},
								title: "Immediately silence all sound",
								children: "Panic"
							}),
							/* @__PURE__ */ p("button", {
								ref: x,
								onClick: () => ee("guide"),
								"aria-label": "Open user guide",
								title: "User guide",
								children: "?"
							})
						]
					})]
				}),
				/* @__PURE__ */ m("div", {
					className: $.patchBar,
					children: [/* @__PURE__ */ m("div", {
						className: $.patchFile,
						children: [
							/* @__PURE__ */ m("label", {
								className: $.patchName,
								children: [/* @__PURE__ */ p("span", { children: "PATCH" }), /* @__PURE__ */ m("span", {
									className: $.nameField,
									"data-value": d.name,
									children: [/* @__PURE__ */ p("input", {
										"aria-label": "Patch name",
										"aria-describedby": pn ? $t : void 0,
										maxLength: 100,
										size: 1,
										value: d.name,
										onChange: (e) => {
											let t = e.target.value;
											Z((e) => e.name === t ? e : {
												...e,
												name: t
											}, "name");
										}
									}), pn && /* @__PURE__ */ m("span", {
										id: $t,
										className: $.dirtyMark,
										title: "Unsaved changes",
										children: [/* @__PURE__ */ p("span", {
											"aria-hidden": "true",
											children: "*"
										}), /* @__PURE__ */ p("span", {
											className: $.visuallyHidden,
											children: "Unsaved changes"
										})]
									})]
								})]
							}),
							/* @__PURE__ */ m("span", {
								className: $.saveStatus,
								"data-save-status": !0,
								"data-error": kr,
								"aria-live": "polite",
								title: ae,
								children: [
									/* @__PURE__ */ p("span", {
										className: $.saveLed,
										"aria-hidden": "true"
									}),
									/* @__PURE__ */ p("span", {
										className: $.saveText,
										children: kr ? "Not saved" : ae
									}),
									kr && /* @__PURE__ */ p("span", {
										className: $.visuallyHidden,
										children: ae
									})
								]
							}),
							/* @__PURE__ */ p("button", {
								"aria-label": "Save to My Presets",
								title: "Save to My Presets in this browser (⌘S / Ctrl+S)",
								onClick: (e) => Pn(e.currentTarget),
								children: "Save"
							}),
							/* @__PURE__ */ p("button", {
								ref: Nt,
								className: $.presetsButton,
								"aria-expanded": te,
								onClick: () => {
									ne(!te), D(!1);
								},
								children: "Presets"
							}),
							/* @__PURE__ */ m("span", {
								className: $.exportControls,
								children: [/* @__PURE__ */ p("select", {
									"aria-label": "Export loop count",
									title: "Loops to render",
									value: Ae,
									onChange: (e) => je(Number(e.target.value)),
									children: [
										1,
										2,
										4,
										8
									].map((e) => /* @__PURE__ */ m("option", {
										value: e,
										children: [
											e,
											" ",
											e === 1 ? "loop" : "loops"
										]
									}, e))
								}), /* @__PURE__ */ p("button", {
									disabled: V,
									"aria-busy": V,
									title: "Render every sequencer to a WAV file",
									onClick: () => void or(),
									children: V ? "Rendering…" : "↓ Export WAV"
								})]
							}),
							/* @__PURE__ */ p("input", {
								ref: b,
								type: "file",
								accept: ".json,application/json",
								hidden: !0,
								"aria-label": "Import patch file",
								onChange: (e) => void ar(e.target.files?.[0])
							})
						]
					}), /* @__PURE__ */ m("div", {
						className: $.rackActions,
						children: [
							/* @__PURE__ */ m("span", {
								className: $.historyActions,
								children: [
									/* @__PURE__ */ p("button", {
										"aria-label": "Undo",
										title: "Undo (⌘Z / Ctrl+Z)",
										disabled: !it.undo,
										onClick: () => An("undo"),
										children: /* @__PURE__ */ p(Fi, { name: "undo" })
									}),
									/* @__PURE__ */ p("button", {
										"aria-label": "Redo",
										title: "Redo (⇧⌘Z / Ctrl+Y)",
										disabled: !it.redo,
										onClick: () => An("redo"),
										children: /* @__PURE__ */ p(Fi, { name: "redo" })
									}),
									/* @__PURE__ */ p("button", {
										title: `Revert to the patch as ${cn ? "last saved" : "loaded"}`,
										disabled: !pn || !mn,
										onClick: zn,
										children: "Revert"
									})
								]
							}),
							/* @__PURE__ */ p("button", {
								ref: C,
								className: $.addButton,
								"aria-expanded": E,
								onClick: () => {
									D(!E), ne(!1);
								},
								children: "＋ Add device"
							}),
							/* @__PURE__ */ m("button", {
								className: $.flipButton,
								"aria-label": w ? "Show front" : "Flip rack",
								"aria-pressed": w,
								onClick: () => {
									On(), T(!w), B(null), R(null), J(null), k(w ? "Front panel. Turn a knob and make it yours." : "Rear panel. Drag from one jack to another, or tap one then the other.");
								},
								children: ["⇄ ", w ? "Show front" : "Flip rack"]
							})
						]
					})]
				}),
				te && /* @__PURE__ */ p(Fa, {
					presets: Y,
					openId: ln,
					dirty: pn,
					onSaveAs: Nn,
					onImport: () => b.current?.click(),
					onExportCurrent: () => Un(d),
					onExport: Un,
					onDelete: Hn,
					onLoad: (e) => Rn(e.patch, `Loaded “${e.patch.name}” from My Presets.`, e.id),
					onLoadFactory: (e) => Rn(Ft(e), `${e} loaded. Your rack is patched and ready to play.`),
					onClose: () => {
						ne(!1), Nt.current?.focus();
					}
				}),
				E && /* @__PURE__ */ m("div", {
					className: $.library,
					role: "region",
					"aria-label": "Device library",
					children: [/* @__PURE__ */ m("div", {
						className: $.libraryHeading,
						children: [/* @__PURE__ */ p("strong", { children: "MAKE ROOM FOR SOMETHING NEW." }), /* @__PURE__ */ p("button", {
							"aria-label": "Close device library",
							onClick: () => D(!1),
							children: "×"
						})]
					}), /* @__PURE__ */ p("div", {
						className: $.libraryGrid,
						children: Fe.map((e) => /* @__PURE__ */ m("button", {
							"data-device": U[e].color,
							disabled: d.modules.length >= 32,
							onClick: () => Wn(e),
							children: [
								/* @__PURE__ */ m("span", {
									className: $.miniDevice,
									children: ["◉ ◉ ", /* @__PURE__ */ p("span", { children: "▰" })]
								}),
								/* @__PURE__ */ p("strong", { children: U[e].name }),
								/* @__PURE__ */ p("small", { children: U[e].subtitle })
							]
						}, e))
					})]
				}),
				/* @__PURE__ */ m("div", {
					className: $.rackHeading,
					children: [/* @__PURE__ */ m("span", { children: [/* @__PURE__ */ p("span", { className: $.rackLight }), w ? "REAR PANEL / SIGNAL ROUTING" : "YOUR RACK / FRONT PANEL"] }), /* @__PURE__ */ m("span", { children: [
						d.modules.length,
						" DEVICES · ",
						d.cables.length,
						" CONNECTIONS"
					] })]
				}),
				w && /* @__PURE__ */ m("div", {
					className: $.routingBar,
					children: [/* @__PURE__ */ p("span", { children: jr }), /* @__PURE__ */ m("span", {
						className: $.legend,
						children: [
							/* @__PURE__ */ p("i", { "data-kind": "audio" }),
							" AUDIO ",
							/* @__PURE__ */ p("i", { "data-kind": "cv" }),
							" CV ",
							/* @__PURE__ */ p("i", { "data-kind": "gate" }),
							" GATE"
						]
					})]
				}),
				/* @__PURE__ */ m("div", {
					className: $.rack,
					ref: y,
					"data-holding": !!ur,
					onClick: Zn,
					onPointerMove: ir,
					onPointerLeave: () => De(null),
					children: [
						w && /* @__PURE__ */ p(ni, {
							patch: d,
							rackRef: y,
							selected: Ce,
							onSelect: (e) => {
								R(e), B(null), J(null);
							},
							drag: ur
						}),
						d.modules.map((e, n) => {
							let r = U[e.type], i = Re(e.type), a = Xa.includes(e.type), o = (t) => wn(e.id, t);
							return /* @__PURE__ */ m("article", {
								className: $.module,
								"data-module-id": e.id,
								"data-device": r.color,
								"data-rear": w,
								"data-revealed": Oe === e.id,
								"data-silent": Or[e.id] === !1,
								"data-keyboard-target": xr.id === e.id,
								onPointerDown: () => {
									w || Dn(e);
								},
								onFocus: () => {
									w || Dn(e);
								},
								"aria-label": `${r.name} ${r.subtitle}`,
								children: [
									/* @__PURE__ */ p("span", { className: `${$.screw} ${$.screwTL}` }),
									/* @__PURE__ */ p("span", { className: `${$.screw} ${$.screwTR}` }),
									/* @__PURE__ */ p("span", { className: `${$.screw} ${$.screwBL}` }),
									/* @__PURE__ */ p("span", { className: `${$.screw} ${$.screwBR}` }),
									/* @__PURE__ */ m("div", {
										className: $.moduleHeader,
										children: [
											/* @__PURE__ */ m("div", {
												className: $.moduleIdentity,
												children: [
													ht(e.type) && /* @__PURE__ */ p(za, {
														select: (t) => t.pulsing.has(e.id),
														children: (e) => /* @__PURE__ */ p("span", {
															className: $.hitLed,
															"data-lit": e,
															title: "Flashes on each sequencer hit",
															"aria-hidden": "true"
														})
													}),
													at(e.type) ? /* @__PURE__ */ p("button", {
														className: $.moduleNameButton,
														"aria-label": `Select ${r.name} ${n + 1} for keyboard`,
														"aria-pressed": xr.id === e.id,
														onClick: () => {
															w || Dn(e);
														},
														children: r.name
													}) : /* @__PURE__ */ p("span", {
														className: $.moduleName,
														children: r.name
													}),
													/* @__PURE__ */ p("span", {
														className: $.moduleSubtitle,
														children: r.subtitle
													})
												]
											}),
											!w && i && /* @__PURE__ */ p(xa, {
												module: e,
												param: i,
												name: r.name,
												onParams: (t) => vn(e.id, t)
											}),
											/* @__PURE__ */ m("div", {
												className: $.moduleTools,
												children: [
													e.type !== "output" && /* @__PURE__ */ p(Ii, {
														mixKey: e.id,
														label: r.name,
														mix: H,
														onToggle: yn,
														clearable: Tt(e, H),
														onClear: () => _n((t) => ({ mix: Et(t.mix, e) }))
													}),
													/* @__PURE__ */ p("span", {
														className: $.moduleNumber,
														children: String(n + 1).padStart(2, "0")
													}),
													!Be(d, e.id) && /* @__PURE__ */ m(f, { children: [
														/* @__PURE__ */ p("button", {
															"aria-label": `Move ${r.name} up`,
															disabled: n === 1,
															onClick: () => Z((t) => Ze(t, e.id, -1)),
															children: "↑"
														}),
														/* @__PURE__ */ p("button", {
															"aria-label": `Move ${r.name} down`,
															disabled: n === d.modules.length - 2,
															onClick: () => Z((t) => Ze(t, e.id, 1)),
															children: "↓"
														}),
														/* @__PURE__ */ p("button", {
															"aria-label": `Duplicate ${r.name}`,
															disabled: d.modules.length >= 32,
															onClick: () => Gn(e),
															children: "⧉"
														}),
														/* @__PURE__ */ p("button", {
															"aria-label": `Remove ${r.name}`,
															onClick: () => {
																On(), J(null), W.current === e.id && Dn(d.modules[0]), Z((t) => Xe(t, e.id)), R(null), B(null), k(`${r.name} removed. Undo brings it back with its cables.`);
															},
															children: "×"
														})
													] })
												]
											})
										]
									}),
									w ? hr(e) : e.type === "performance" ? Dr(e) : /* @__PURE__ */ m(f, { children: [
										r.drum && /* @__PURE__ */ m("div", {
											className: $.moduleTransport,
											children: [br(e), /* @__PURE__ */ m("span", { children: [
												"SHARED TEMPO · ",
												d.sequencer.bpm,
												" BPM"
											] })]
										}),
										/* @__PURE__ */ m("div", {
											className: $.moduleBody,
											children: [e.type === "mixer" ? /* @__PURE__ */ p(za, {
												select: (t) => t.mixerLevels[e.id] ?? Va,
												children: (t) => /* @__PURE__ */ p(Aa, {
													module: e,
													patch: d,
													mix: H,
													levels: t,
													onParams: (t) => vn(e.id, t),
													onToggle: yn
												})
											}) : /* @__PURE__ */ p("div", {
												className: $.controls,
												children: r.params.filter((e) => !e.voice && !e.group && !de.includes(e.id)).map((t) => _r(e, t, r.name))
											}), e.type !== "mixer" && /* @__PURE__ */ p("div", {
												className: $.moduleDecoration,
												children: e.type === "output" ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(za, {
													select: (e) => e.meter,
													children: (e) => /* @__PURE__ */ p("div", {
														className: $.meters,
														"aria-label": "Output level",
														role: "meter",
														"aria-valuemin": 0,
														"aria-valuemax": 1,
														"aria-valuenow": Number(e.toFixed(3)),
														children: [0, 1].map((t) => /* @__PURE__ */ m("div", {
															className: $.meterRow,
															children: [/* @__PURE__ */ p("span", { children: t === 0 ? "L" : "R" }), Array.from({ length: 18 }, (t, n) => /* @__PURE__ */ p("i", {
																"data-lit": n / 18 < e,
																"data-hot": n > 14
															}, n))]
														}, t))
													})
												}), /* @__PURE__ */ p("button", {
													"aria-pressed": F,
													onClick: () => _n((e) => ({ mainMuted: !e.mainMuted })),
													className: $.muteButton,
													children: F ? "UNMUTE" : "MUTE"
												})] }) : e.type === "envelope" ? /* @__PURE__ */ p(Ni, { params: e.params }) : ["compressor", "cohere"].includes(e.type) ? /* @__PURE__ */ p(za, {
													select: (t) => t.reductions[e.id] ?? 0,
													children: (e) => /* @__PURE__ */ p(ki, {
														reduction: e,
														label: `${r.name} ${n + 1} gain reduction`
													})
												}) : e.type === "equalizer" ? /* @__PURE__ */ p(Oi, { params: e.params }) : r.drum?.mode === "euclid" ? /* @__PURE__ */ p(Ki, {
													module: e,
													clock: et[e.id]?.clock ?? -1
												}) : /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("span", { className: $.deviceLed }), /* @__PURE__ */ m("span", {
													className: $.deviceLabel,
													children: [
														Za[e.type] ?? "RACKLOOSE",
														/* @__PURE__ */ p("br", {}),
														/* @__PURE__ */ p("small", { children: "PATCH. PLAY. REPEAT." })
													]
												})] })
											})]
										}),
										e.type === "brit" ? /* @__PURE__ */ p(ca, {
											module: e,
											rate: he,
											onParams: (t) => vn(e.id, t)
										}) : e.type === "talon" ? /* @__PURE__ */ p(za, {
											select: (t) => t.reductions[e.id] ?? 0,
											children: (t) => /* @__PURE__ */ p(ya, {
												module: e,
												reduction: t,
												label: `${r.name} ${n + 1} gain reduction`,
												onParams: (t) => vn(e.id, t)
											})
										}) : vr(e),
										e.type === "prism" && /* @__PURE__ */ p(Xi, {
											module: e,
											onParams: (t) => vn(e.id, t)
										}),
										a && /* @__PURE__ */ p(Ji, {
											module: e,
											selected: gr(e) ?? r.drum.voices[0].id,
											onSelect: o,
											onParams: (t) => vn(e.id, t),
											onAudition: (t) => Tn(e.id, t),
											disabled: t
										}),
										r.drum?.mode === "euclid" && /* @__PURE__ */ p(Wi, {
											module: e,
											selected: gr(e) ?? r.drum.voices[0].id,
											onSelect: o,
											clock: et[e.id]?.clock ?? -1,
											mix: H,
											onMix: yn,
											disabled: t,
											onParams: (t) => vn(e.id, t),
											onAudition: (t) => Tn(e.id, t)
										}),
										r.drum?.mode === "steps" && /* @__PURE__ */ p(Hi, {
											module: e,
											...a ? {
												selected: gr(e) ?? r.drum.voices[0].id,
												onSelect: o
											} : {},
											mix: H,
											onMix: yn,
											step: (et[e.id]?.clock ?? -1) < 0 ? -1 : et[e.id].clock % 16,
											disabled: t,
											onParams: (t) => vn(e.id, t),
											onAudition: (t) => Tn(e.id, t)
										})
									] })
								]
							}, e.id);
						}),
						/* @__PURE__ */ m("div", {
							className: $.rackBottom,
							children: [/* @__PURE__ */ p("button", {
								ref: S,
								className: $.aboutButton,
								"aria-label": "About Rackloose",
								title: "About Rackloose",
								onClick: () => ee("about"),
								children: "RACKLOOSE / BY MICHAEL ZICK © 2026"
							}), /* @__PURE__ */ p("span", { children: "NO RULES. JUST SIGNAL." })]
						})
					]
				}),
				/* @__PURE__ */ p("div", {
					className: $.toastAnchor,
					children: /* @__PURE__ */ p("div", {
						className: $.toast,
						role: "status",
						"data-shown": le,
						children: ce
					})
				}),
				/* @__PURE__ */ m("div", {
					className: $.keyboardPanel,
					children: [
						/* @__PURE__ */ m("div", {
							className: $.globalControls,
							role: "group",
							"aria-label": "Global controls",
							children: [
								/* @__PURE__ */ m("div", {
									className: $.globalTransport,
									children: [
										/* @__PURE__ */ m("button", {
											className: $.playButton,
											disabled: t,
											onClick: En,
											"data-playing": j,
											"aria-label": j ? "Pause all sequencers" : "Play all sequencers",
											children: [/* @__PURE__ */ p(Fi, { name: j ? "pause" : "play" }), /* @__PURE__ */ p("span", { children: j ? "PAUSE ALL" : "PLAY ALL" })]
										}),
										/* @__PURE__ */ m("button", {
											className: $.resetButton,
											onClick: () => _.current?.reset(),
											"aria-label": "Reset all sequencers",
											children: [/* @__PURE__ */ p(Fi, { name: "reset" }), /* @__PURE__ */ p("span", { children: "RESET" })]
										}),
										/* @__PURE__ */ p("button", {
											className: $.clearAllButton,
											disabled: !H.muted.size && !H.soloed.size && !F,
											onClick: () => {
												_n({
													mix: dt,
													mainMuted: !1
												}), k("All mutes and solos cleared.");
											},
											"aria-label": "Clear all mutes and solos",
											children: /* @__PURE__ */ p("span", { children: "CLR ALL" })
										})
									]
								}),
								/* @__PURE__ */ p(Na, {
									bpm: d.sequencer.bpm,
									onChange: (e) => In("bpm", e)
								}),
								/* @__PURE__ */ m("label", {
									className: $.swingField,
									children: [
										"SWING",
										/* @__PURE__ */ p("input", {
											type: "range",
											min: 0,
											max: .6,
											step: .01,
											value: d.sequencer.swing,
											"aria-label": "Swing",
											onChange: (e) => In("swing", Number(e.target.value))
										}),
										/* @__PURE__ */ m("span", { children: [Math.round(d.sequencer.swing * 100), "%"] })
									]
								}),
								/* @__PURE__ */ m("span", {
									className: $.globalPosition,
									"aria-label": "Global position",
									children: [fe < 0 ? "01" : String(fe % 16 + 1).padStart(2, "0"), " / 16"]
								})
							]
						}),
						/* @__PURE__ */ m("div", {
							className: $.keyboardTop,
							children: [
								/* @__PURE__ */ m("strong", {
									className: $.keyboardTarget,
									children: ["KEYBOARD → ", yr(xr)]
								}),
								Er ? /* @__PURE__ */ p("span", {
									className: $.routingHint,
									title: Er,
									children: Er
								}) : e && /* @__PURE__ */ p("span", {
									className: $.keyHint,
									children: Cr ? Cr.length > 11 ? "Home row + Z X C V B" : "Home row · pads" : "A–K · notes"
								}),
								!Cr && /* @__PURE__ */ m("div", {
									className: $.octaveControls,
									children: [
										/* @__PURE__ */ p("button", {
											"aria-label": "Lower keyboard octave",
											disabled: L === 1,
											onClick: () => _n((e) => ({ octave: Math.max(1, e.octave - 1) }), "octave"),
											children: "−"
										}),
										/* @__PURE__ */ m("span", { children: ["OCT ", L] }),
										/* @__PURE__ */ p("button", {
											"aria-label": "Raise keyboard octave",
											disabled: L === 6,
											onClick: () => _n((e) => ({ octave: Math.min(6, e.octave + 1) }), "octave"),
											children: "＋"
										})
									]
								}),
								/* @__PURE__ */ p("button", {
									className: $.keysToggle,
									"aria-expanded": xe,
									"aria-controls": Gt,
									onClick: () => Se(!xe),
									children: xe ? "Hide keys" : "Show keys"
								})
							]
						}),
						/* @__PURE__ */ p("div", {
							id: Gt,
							hidden: !xe,
							children: Cr ? /* @__PURE__ */ p("div", {
								className: $.performancePads,
								"data-voices": Cr.length,
								"data-rows": Cr.length > 6 ? 2 : 1,
								style: { "--pad-columns": Tr },
								"aria-label": `${Sr.name} performance pads`,
								children: Cr.map((n, r) => /* @__PURE__ */ m("button", {
									"data-playing": Ge.has(n.id),
									"aria-label": `Keyboard ${Sr.name} ${n.label}`,
									disabled: t,
									onPointerDown: (e) => {
										e.button === 0 && (e.preventDefault(), e.currentTarget.setPointerCapture(e.pointerId), $e.current.add(`pointer-${e.pointerId}`), Cn(`pointer-${e.pointerId}`, r, e.pointerType !== "mouse"), wr(n.id));
									},
									onPointerUp: (e) => xn(`pointer-${e.pointerId}`),
									onPointerCancel: (e) => xn(`pointer-${e.pointerId}`, !0),
									onLostPointerCapture: (e) => xn(`pointer-${e.pointerId}`, !0),
									onKeyDown: (e) => {
										(e.key === "Enter" || e.key === " ") && !e.repeat && (e.preventDefault(), e.stopPropagation(), Cn(`pad-${n.id}`, r), wr(n.id));
									},
									onKeyUp: (e) => {
										(e.key === "Enter" || e.key === " ") && (e.preventDefault(), xn(`pad-${n.id}`));
									},
									onBlur: () => xn(`pad-${n.id}`),
									children: [/* @__PURE__ */ p("span", { children: n.label }), e && /* @__PURE__ */ p("small", { children: Ua[r].toUpperCase() })]
								}, n.id))
							}) : /* @__PURE__ */ p("div", {
								className: $.piano,
								"aria-label": "Piano keyboard",
								children: Array.from({ length: 13 }, (e, n) => {
									let r = (L + 1) * 12 + n, i = Wa.has(n % 12);
									return /* @__PURE__ */ m("button", {
										className: i ? $.blackKey : $.whiteKey,
										"data-note": r,
										"data-playing": pe.includes(r),
										"aria-label": `Play ${Ut(r)}`,
										disabled: t,
										onPointerDown: (e) => {
											e.button === 0 && (e.preventDefault(), e.currentTarget.setPointerCapture(e.pointerId), $e.current.add(`pointer-${e.pointerId}`), Cn(`pointer-${e.pointerId}`, n, e.pointerType !== "mouse"));
										},
										onPointerUp: (e) => xn(`pointer-${e.pointerId}`),
										onPointerCancel: (e) => xn(`pointer-${e.pointerId}`, !0),
										onLostPointerCapture: (e) => xn(`pointer-${e.pointerId}`, !0),
										onKeyDown: (e) => {
											(e.key === "Enter" || e.key === " ") && !e.repeat && (e.preventDefault(), e.stopPropagation(), Cn(`piano-${r}`, n));
										},
										onKeyUp: (e) => {
											(e.key === "Enter" || e.key === " ") && (e.preventDefault(), xn(`piano-${r}`));
										},
										onBlur: () => xn(`piano-${r}`),
										children: [/* @__PURE__ */ p("span", { children: Ha[n].toUpperCase() }), !i && /* @__PURE__ */ p("small", { children: Ut(r) })]
									}, n);
								})
							})
						})
					]
				}),
				O === "guide" && /* @__PURE__ */ p("div", {
					className: $.helpBackdrop,
					children: /* @__PURE__ */ m("div", {
						className: $.help,
						role: "dialog",
						"aria-modal": "true",
						"aria-labelledby": Kt,
						onKeyDown: Kn,
						children: [
							/* @__PURE__ */ m("div", {
								className: $.helpHeading,
								children: [
									/* @__PURE__ */ p("img", {
										src: "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2064%2064'%3e%3crect%20x='5'%20y='6'%20width='54'%20height='52'%20rx='3'%20fill='%23303337'%20stroke='%23101214'%20stroke-width='2'/%3e%3cpath%20d='M10%2010v44M54%2010v44'%20stroke='%23777'%20stroke-width='3'/%3e%3crect%20x='14'%20y='12'%20width='36'%20height='17'%20fill='%23b9503a'%20stroke='%23111'/%3e%3crect%20x='14'%20y='31'%20width='36'%20height='20'%20fill='%23a0ac9b'%20stroke='%23111'/%3e%3cg%20fill='%23232626'%20stroke='%23dfdfca'%3e%3ccircle%20cx='23'%20cy='21'%20r='5'/%3e%3ccircle%20cx='41'%20cy='21'%20r='5'/%3e%3c/g%3e%3cpath%20d='M23%2021v-4m18%204%203-3'%20stroke='%23fff'%20stroke-width='2'/%3e%3cg%20fill='%231b2221'%20stroke='%23555'%3e%3ccircle%20cx='22'%20cy='39'%20r='3'/%3e%3ccircle%20cx='42'%20cy='44'%20r='3'/%3e%3c/g%3e%3cpath%20d='M22%2039c-6%2020%2027%2020%2020%205'%20fill='none'%20stroke='%23f4bb50'%20stroke-width='3'/%3e%3cpath%20d='M7%208h50'%20stroke='%23a9abad'/%3e%3c/svg%3e",
										width: "34",
										height: "34",
										alt: ""
									}),
									/* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("small", { children: "RACKLOOSE · MODULAR SYNTHESIZER" }), /* @__PURE__ */ p("h2", {
										id: Kt,
										children: "User Guide"
									})] }),
									/* @__PURE__ */ p("button", {
										autoFocus: !0,
										onClick: qn,
										"aria-label": "Close user guide",
										children: "×"
									})
								]
							}),
							/* @__PURE__ */ p("h3", { children: "Transport" }),
							/* @__PURE__ */ p("p", { children: "Play All starts every sequencer and turns into Pause All while anything plays. Reset stops and rewinds. Type a tempo or drag the small slider under it; the change is heard right away. Space always plays and pauses, whichever control has focus, except while typing in a text field. Each STEP–16 and drum machine also has its own Play/Stop, locked to the shared tempo, swing and position." }),
							/* @__PURE__ */ p("h3", { children: "Playing" }),
							/* @__PURE__ */ m("p", { children: [
								"Click a device to aim the keyboard at it. MONARCH, ORACLE, AURORA, PRISM and SOLID play on ",
								/* @__PURE__ */ p("strong", { children: "A W S E D F T G Y H U J K" }),
								", and OCT shifts the range. MONARCH plays one note at a time; ORACLE plays up to five, AURORA eight and PRISM sixteen. Their Chord setting turns every note, from the keys or STEP–16, into a chord. The chrome Engine switch in a device’s header slides between Digital, its black tab on the left, and Analog, its red tab on the right. On MONARCH, ORACLE, AURORA and SIEVE, Analog is a Moog-style ladder filter that self-oscillates near full Resonance; on PRISM it adds a ladder to every voice, set in its Filter section. Drum machines get pads on the home row, ",
								/* @__PURE__ */ p("strong", { children: "A S D F G H J K L ; '" }),
								", plus ",
								/* @__PURE__ */ p("strong", { children: "Z X C V B" }),
								" for STRIKE’s remaining five voices. STATIC holds noise on A. STEP–16 plays whatever its Pitch and Gate cables reach, and effects keep the last instrument. The light beside each instrument and drum machine flashes every time a sequencer plays it. Hide keys keeps every global control."
							] }),
							/* @__PURE__ */ p("h3", { children: "Knobs and steps" }),
							/* @__PURE__ */ p("p", { children: "Drag a knob up or down, or use the arrow keys; double-click restores its default. Click a STEP–16 step to set its note, velocity and gate. A STEP–16’s Lag moves all its notes up to 50 ms ahead of the beat (turn it left) or behind it (right); centred is On beat. Add device adds more STEP–16s: each has its own 16 steps, Play/Stop and step mutes, and plays whatever its own Pitch and Gate cables reach, so separate parts can drive separate instruments. Typing in a field never plays notes." }),
							/* @__PURE__ */ p("h3", { children: "Patching cables" }),
							/* @__PURE__ */ p("p", { children: "Flip the rack to patch. Each jack holds one cable. Drag from an empty jack to a free one; jacks that can take it light up. Drag a plugged jack to pull its plug out: drop it on a free jack to move it, or on empty rack space to unplug it. You can also tap a plugged jack to lift its plug, then tap a free jack. Escape or a bad drop puts the plug back, and Delete unplugs a selected cable. Every output has a spare jack, and STEP–16 has three Pitch and three Gate jacks, so one signal can feed several places. Amber is audio, blue is CV and coral is gate; types must match. The trim beside a CV input sets its depth. SUM mixes eight channels and names each one after the instrument feeding it, through any effects; hover the name to see the chain." }),
							/* @__PURE__ */ p("h3", { children: "Mixing on SUM" }),
							/* @__PURE__ */ p("p", { children: "SUM is laid out like a console. Each channel strip has Pan, M and S, a fader and a level meter: green, amber from −9 dB and red from −3 dB. Drag a fader or pan knob, or use the arrow keys; double-click returns it to its default. The MIX BUS fader on the right sets the level of the whole mix, with its own left and right meters." }),
							/* @__PURE__ */ p("h3", { children: "Drums" }),
							/* @__PURE__ */ p("p", { children: "AURORA is an eight-voice Jupiter-8-inspired polysynth: blend two oscillators, shape them with high-pass and 12/24 dB low-pass filters, and animate pulse width with the LFO. PRISM is a focused DX7-inspired FM synth: choose one of six algorithms, then select an operator to edit its ratio, level and envelope. Brightness controls modulation depth; Velocity makes quieter sequenced notes softer in tone. Both use their own envelopes and work with STEP–16 Pitch and Gate, or directly from the keyboard." }),
							/* @__PURE__ */ p("p", { children: "STRIKE has sixteen vintage digital drum lanes, original generated one-shots inspired by LinnDrum. BOOM has eleven voices: kick, snare, rim, clap, closed and open hat, low and high tom, crash, ride and bell. A closed hat cuts off a ringing open hat. On BOOM, PUNCH, STRIKE and FORGE, click a voice’s name, tap its performance pad or pick it under Edit voice to hear it and shape it in the voice editor, with its own knobs, such as Tune, Decay and Tone, its Pan and its Lag. Lag moves just that voice up to 50 ms ahead of the beat (turn it left) or behind it (right), like hats pushed ahead or a snare laid back. ORBIT shows the same knobs for the lane you pick. Every drum machine’s Engine toggle picks Digital or Analog, which builds each voice from modeled analog circuits (or, on STRIKE and FORGE, plays its one-shots through a ladder tone filter) at the same level. Every device starts Analog, presets and older patches included. The knob marked LEVEL on each drum lane, in ORBIT’s Level column, sets that voice’s level: centred leaves it as it was, down silences it and full adds 6 dB. Hover it to read the change; double-click resets it. Click pads to program a voice’s steps. ORBIT voices each have Steps, Hits and Shift; tap its step pads for a custom rhythm, and Generate turns it back into a Euclidean one, spreading the hits you tapped evenly if the lane had no Hits. A drum machine’s Chain in passes another instrument through. SKITTER is a trap step sequencer that makes no sound: patch Trig out into a drum machine’s Trig in and its lanes play that kit’s kick, snare, clap, hats and perc, or patch Synth gate into MONARCH, CONTOUR or a polysynth. Pick a note under Note, then tap a step to play it as a 1/16, a pair of 1/32s, or a roll of 1/32 triplets, 1/64s or 1/64 triplets. FORGE is an industrial rock kit with its own Drive and gated Room, and RUST distorts anything patched into it, from fuzz to crushed bits." }),
							/* @__PURE__ */ p("h3", { children: "Dynamics and EQ" }),
							/* @__PURE__ */ p("p", { children: "VALVE is a tube limiter: Input drives the tube, Threshold sets where it starts to hold the level back, and Time constant picks how fast it lets go, from 1 (quick) to 6 (slow). The needle shows the gain reduction. CONSOLE is a channel EQ: high- and low-pass filters, LF and HF that switch between shelf and bell, and two sweepable mids with Q. The screen draws the curve you hear, and EQ Out bypasses it. Every factory preset carves at least one instrument with it." }),
							/* @__PURE__ */ p("h3", { children: "Mute and solo" }),
							/* @__PURE__ */ p("p", { children: "M mutes and S solos a device, drum voice, SUM channel or step, and the two are exclusive. CLR clears one device, with its voices, channels or steps; CLR ALL clears everything, MAIN’s mute included. Silenced parts dim. These settings last for this session." }),
							/* @__PURE__ */ p("h3", { children: "Undo and unsaved changes" }),
							/* @__PURE__ */ m("p", { children: [
								"Undo and Redo, or ",
								/* @__PURE__ */ p("strong", { children: "⌘Z" }),
								" and ",
								/* @__PURE__ */ p("strong", { children: "⇧⌘Z" }),
								" (",
								/* @__PURE__ */ p("strong", { children: "Ctrl+Z" }),
								" and ",
								/* @__PURE__ */ p("strong", { children: "Ctrl+Y" }),
								"), step through your last 50 changes: knobs, steps, tempo, cables, devices, presets, mutes, solos and octave. A ",
								/* @__PURE__ */ p("strong", { children: "*" }),
								" after the patch name means it has changed since you last saved it to My Presets or loaded it, and Revert puts it back that way as one more step, so Undo brings your changes back. Revert leaves mutes, solos and the transport alone; the transport’s RESET only sends sequencers back to their first step."
							] }),
							/* @__PURE__ */ p("h3", { children: "Presets and files" }),
							/* @__PURE__ */ m("p", { children: [
								"Your rack keeps itself between visits. Save, or ",
								/* @__PURE__ */ p("strong", { children: "⌘S" }),
								" (",
								/* @__PURE__ */ p("strong", { children: "Ctrl+S" }),
								"), keeps it in My Presets in this browser: the first save asks for a name, and later saves update that preset. Type a new name in PATCH and save to rename it; Save as… (",
								/* @__PURE__ */ p("strong", { children: "⇧⌘S" }),
								") makes a copy. Presets lists My Presets above the factory presets. Export downloads a preset as a .json file, Import file adds one to My Presets, and Delete removes your own presets. Export WAV, beside Presets, renders the number of loops chosen next to it, every sequencer from the start, effects and mutes included, but not MAIN’s Mute. The light beside the patch name shows whether your rack is saved in this browser, and messages appear briefly over the bottom of the rack. Panic silences everything at once."
							] })
						]
					})
				}),
				O === "about" && /* @__PURE__ */ p("div", {
					className: $.helpBackdrop,
					children: /* @__PURE__ */ m("div", {
						className: `${$.help} ${$.about}`,
						role: "dialog",
						"aria-modal": "true",
						"aria-labelledby": Qt,
						onKeyDown: Kn,
						children: [
							/* @__PURE__ */ m("div", {
								className: $.helpHeading,
								children: [
									/* @__PURE__ */ p("img", {
										src: "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2064%2064'%3e%3crect%20x='5'%20y='6'%20width='54'%20height='52'%20rx='3'%20fill='%23303337'%20stroke='%23101214'%20stroke-width='2'/%3e%3cpath%20d='M10%2010v44M54%2010v44'%20stroke='%23777'%20stroke-width='3'/%3e%3crect%20x='14'%20y='12'%20width='36'%20height='17'%20fill='%23b9503a'%20stroke='%23111'/%3e%3crect%20x='14'%20y='31'%20width='36'%20height='20'%20fill='%23a0ac9b'%20stroke='%23111'/%3e%3cg%20fill='%23232626'%20stroke='%23dfdfca'%3e%3ccircle%20cx='23'%20cy='21'%20r='5'/%3e%3ccircle%20cx='41'%20cy='21'%20r='5'/%3e%3c/g%3e%3cpath%20d='M23%2021v-4m18%204%203-3'%20stroke='%23fff'%20stroke-width='2'/%3e%3cg%20fill='%231b2221'%20stroke='%23555'%3e%3ccircle%20cx='22'%20cy='39'%20r='3'/%3e%3ccircle%20cx='42'%20cy='44'%20r='3'/%3e%3c/g%3e%3cpath%20d='M22%2039c-6%2020%2027%2020%2020%205'%20fill='none'%20stroke='%23f4bb50'%20stroke-width='3'/%3e%3cpath%20d='M7%208h50'%20stroke='%23a9abad'/%3e%3c/svg%3e",
										width: "34",
										height: "34",
										alt: ""
									}),
									/* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("small", { children: "RACKLOOSE · MODULAR SYNTHESIZER" }), /* @__PURE__ */ p("h2", {
										id: Qt,
										children: "About Rackloose"
									})] }),
									/* @__PURE__ */ p("button", {
										autoFocus: !0,
										onClick: qn,
										"aria-label": "Close about Rackloose",
										children: "×"
									})
								]
							}),
							/* @__PURE__ */ m("dl", {
								className: $.aboutFacts,
								children: [
									/* @__PURE__ */ p("dt", { children: "Version" }),
									/* @__PURE__ */ p("dd", { children: "2.0.0" }),
									/* @__PURE__ */ p("dt", { children: "By" }),
									/* @__PURE__ */ p("dd", { children: "Michael Zick" })
								]
							}),
							/* @__PURE__ */ p("p", {
								className: $.aboutTagline,
								children: "Small studio. Endless possibilities."
							}),
							/* @__PURE__ */ p("p", {
								className: $.aboutCopyright,
								children: "© 2026 Michael Zick"
							})
						]
					})
				}),
				jt !== null && /* @__PURE__ */ p(Ia, {
					initialName: jt,
					presets: Y,
					onSave: Vn,
					onCancel: Bn
				})
			]
		})
	});
}
//#endregion
export { so as RacklooseApp, Rt as parsePatch, Ft as preset, It as serializePatch };
