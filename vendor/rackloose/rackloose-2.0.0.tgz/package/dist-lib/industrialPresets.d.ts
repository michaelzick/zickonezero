import type { Patch } from './model';
export { INDUSTRIAL_PRESETS } from './model';
type Name = typeof import('./model').INDUSTRIAL_PRESETS[number];
/**
 * Two industrial rock originals, neither with a cymbal crash. FORGE plays the kit, two RUSTs break up the synths, and
 * CONSOLE carves each part the way a desk channel would: a slow, funky, late-90s crawl and a chugging drop-D stomp.
 */
export declare function industrialPreset(name: Name): Patch;
