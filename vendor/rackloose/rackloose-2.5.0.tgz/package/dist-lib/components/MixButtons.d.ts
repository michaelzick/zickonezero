import type { Mix } from '../model';
export type MixToggle = (key: string, kind: 'muted' | 'soloed') => void;
/**
 * Mute and solo toggles for one module, drum voice or step. `solo` is false where soloing means nothing, as on MAIN.
 * `onClear` adds a button that resets every mute and solo inside a module; `clearable` enables it. `onSwap` adds one that
 * turns the module's own mute into a solo or its solo into a mute; `swappable` enables it.
 */
export declare function MixButtons({ mixKey, label, mix, onToggle, solo, onClear, clearable, onSwap, swappable }: {
    mixKey: string;
    label: string;
    mix: Mix;
    onToggle: MixToggle;
    solo?: boolean;
    onClear?: () => void;
    clearable?: boolean;
    onSwap?: () => void;
    swappable?: boolean;
}): import("react").JSX.Element;
