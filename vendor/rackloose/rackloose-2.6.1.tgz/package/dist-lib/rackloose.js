"use client";
import { Fragment as e, createContext as t, useCallback as n, useContext as r, useEffect as i, useId as a, useImperativeHandle as o, useLayoutEffect as s, useMemo as c, useReducer as l, useRef as u, useState as d, useSyncExternalStore as f } from "react";
import { Fragment as p, jsx as m, jsxs as h } from "react/jsx-runtime";
var g = 3840, _ = [
	1,
	2,
	4,
	8,
	16
], v = _.at(-1) * g, y = 2048, b = 8192, x = [
	["1/4", 960],
	["1/8", 480],
	["1/8T", 320],
	["1/16", 240],
	["1/16T", 160],
	["1/32", 120]
], S = {
	1: 1,
	2: 14,
	3: 28,
	4: 42,
	5: 56,
	6: 70,
	7: 84,
	8: 98,
	9: 112,
	0: 127
}, C = (e) => (_[e] ?? _[0]) * g, w = (e) => C(e) / 240, T = (e) => [...e].sort((e, t) => e[0] - t[0] || e[2] - t[2]);
function E(e, t) {
	let n = 0, r = e.length;
	for (; n < r;) {
		let i = n + r >> 1;
		e[i][0] < t ? n = i + 1 : r = i;
	}
	return n;
}
var ee = (e, t, n) => e.slice(E(e, t), E(e, n));
function te(e, t, n = 1, r = v) {
	return (Math.round(e + (Math.round(e / t) * t - e) * n) % r + r) % r;
}
function ne(e, t, n, r) {
	return T(e.map(([e, i, a, o]) => {
		let s = te(e, t, n, r);
		return [
			s,
			Math.max(1, Math.min(i, r - s)),
			a,
			o
		];
	}));
}
function D(e, t, n, r, i) {
	let a = (Math.round(e) % i + i) % i;
	return [
		a,
		Math.max(1, Math.min(Math.round(t), i - a)),
		n,
		Math.max(1, Math.min(127, Math.round(r)))
	];
}
function re(e, t, n) {
	if (t <= e) return [];
	if (t - e >= n) return [[0, n]];
	let r = (e % n + n) % n, i = r + (t - e);
	return i <= n ? [[r, i]] : [[r, n], [0, i - n]];
}
function O(e, t) {
	if (!e.length) return [];
	let n = (Math.floor(Math.max(...e.map((e) => e[0])) / g) + 1) * g;
	return T(e.filter(([e]) => e >= n - t).map(([e, n, r, i]) => D(e, n, r, i, t)));
}
var k = (e, t) => t.some(([t, n]) => e >= t && e < n);
function ie(e, t, n, r) {
	let i = e.filter(([e, , i]) => !(n && k(e, r)) && !t.some((t) => t[0] === e && t[2] === i));
	return T([...i, ...t.slice(0, Math.max(0, y - i.length))]);
}
var A = class {
	held = [];
	on(e, t, n) {
		return this.held = [...this.held.filter((t) => t.id !== e), {
			id: e,
			note: t,
			velocity: n
		}], {
			note: t,
			velocity: n
		};
	}
	off(e) {
		let t = this.held.at(-1);
		if (this.held = this.held.filter((t) => t.id !== e), t?.id !== e) return;
		let n = this.held.at(-1);
		return n && n.note !== t.note ? {
			note: n.note,
			velocity: n.velocity
		} : n ? void 0 : null;
	}
	clear() {
		this.held = [];
	}
	get size() {
		return this.held.length;
	}
};
function ae(e, t) {
	for (let n = e.length - 1; n >= 0; n--) {
		let r = e[n];
		if (!(r.time > t)) return t >= r.time + r.duration && n === e.length - 1 ? null : r.count * 240 + Math.min(1, (t - r.time) / r.duration) * 240;
	}
	let n = e[0];
	return n && n.time - t <= n.duration ? n.count * 240 - (n.time - t) / n.duration * 240 : null;
}
function oe(e, t, n) {
	return t && t.performanceTime > 0 ? t.contextTime + (e - t.performanceTime) / 1e3 : n.currentTime - n.latency - Math.max(0, n.now - e) / 1e3;
}
function se(e, t = 16) {
	let n = (e % t + t) % t;
	return `${Math.floor(n / 16) + 1}.${Math.floor(n % 16 / 4) + 1}.${n % 4 + 1}`;
}
var ce = (e) => `−${Math.ceil(-e / 16)}.${Math.floor((e % 16 + 16) % 16 / 4) + 1}`, le = {
	kick: 36,
	rim: 37,
	snare: 38,
	clap: 39,
	lowTom: 45,
	hat: 42,
	pedal: 44,
	open: 46,
	midTom: 47,
	crash: 49,
	highTom: 50,
	ride: 51,
	china: 52,
	tambourine: 54,
	bell: 56,
	anvil: 56,
	highConga: 63,
	lowConga: 64,
	cabasa: 69,
	skin: 36,
	wood: 37,
	sand: 38,
	shaker: 42,
	metal: 46,
	tom: 45
}, ue = {
	35: 36,
	40: 38,
	39: 38,
	41: 45,
	43: 45,
	44: 42,
	47: 45,
	48: 50,
	52: 49,
	55: 49,
	57: 49,
	53: 51,
	59: 51,
	62: 63,
	70: 69
};
function de(e, t) {
	for (let n = t, r = 0; n !== void 0 && r < 4; n = ue[n], r++) {
		let t = e.find((e) => le[e.id] === n);
		if (t) return t.id;
	}
	return null;
}
// src/presetKit.ts
var fe = (e) => [...e].reduce((e, t, n) => t === "x" ? e | 1 << n : e, 0), j = (e, t, n) => [...e].map((e, r) => ({
	note: t[r],
	enabled: e !== ".",
	velocity: e === "X" ? 1 : e === "o" ? .5 : .74,
	gate: typeof n == "number" ? n : n[r]
})), M = (...e) => e.flatMap(([e, t]) => Array(t).fill(e)), pe = (...e) => T(e.map(([e, t, n, r]) => [
	Math.round(e * 240),
	Math.round((t - .1) * 240),
	n,
	r
])), N = (e) => Number((45 / e).toFixed(3)), P = (...e) => Object.fromEntries(Array.from({ length: 6 }, (t, n) => {
	let [r, i, a, o, s, c, l] = e[n] ?? [
		1,
		0,
		0,
		.005,
		.3,
		0,
		.2
	];
	return Object.entries({
		Ratio: r,
		Detune: i,
		Level: a,
		Attack: o,
		Decay: s,
		Sustain: c,
		Release: l
	}).map(([e, t]) => [`op${n + 1}${e}`, t]);
}).flat()), F = {
	epiano: P([
		1,
		0,
		.85,
		.002,
		1.8,
		.12,
		.7
	], [
		1,
		0,
		.45,
		.002,
		1,
		.05,
		.5
	], [
		1,
		4,
		.45,
		.002,
		1.4,
		.1,
		.6
	], [
		14,
		0,
		.2,
		.002,
		.12,
		0,
		.1
	], [
		1,
		-4,
		.35,
		.002,
		1.6,
		.1,
		.6
	], [
		1,
		0,
		.12,
		.002,
		.6,
		0,
		.3
	]),
	bell: P([
		1,
		0,
		.8,
		.002,
		2.2,
		0,
		1.4
	], [
		3.5,
		0,
		.5,
		.002,
		1.4,
		0,
		1
	], [
		2,
		3,
		.35,
		.002,
		1.5,
		0,
		1
	], [
		7,
		0,
		.3,
		.002,
		.6,
		0,
		.5
	], [
		4,
		0,
		.12,
		.002,
		.9,
		0,
		.6
	], [
		10.5,
		0,
		.15,
		.002,
		.3,
		0,
		.3
	]),
	reed: P([
		1,
		0,
		.8,
		.03,
		.4,
		.8,
		.25
	], [
		2,
		0,
		.5,
		.03,
		.5,
		.6,
		.3
	], [
		1,
		6,
		.3,
		.03,
		.4,
		.8,
		.25
	], [
		2,
		0,
		.3,
		.03,
		.5,
		.5,
		.3
	]),
	kalimba: P([
		1,
		0,
		.85,
		.002,
		.7,
		0,
		.4
	], [
		3,
		0,
		.35,
		.002,
		.08,
		0,
		.08
	], [
		1,
		5,
		.4,
		.002,
		.5,
		0,
		.3
	], [
		7,
		0,
		.18,
		.002,
		.04,
		0,
		.04
	]),
	slap: P([
		1,
		0,
		.9,
		.002,
		.35,
		.25,
		.08
	], [
		1,
		0,
		.65,
		.002,
		.15,
		.05,
		.06
	], [
		1,
		3,
		.5,
		.002,
		.3,
		.2,
		.08
	], [
		3,
		0,
		.35,
		.002,
		.05,
		0,
		.04
	], [
		.5,
		0,
		.35,
		.002,
		.4,
		.3,
		.08
	], [
		.5,
		0,
		.1,
		.002,
		.2,
		0,
		.06
	]),
	bass: P([
		1,
		0,
		.9,
		.002,
		.4,
		.3,
		.1
	], [
		1,
		0,
		.55,
		.002,
		.25,
		.1,
		.08
	], [
		.5,
		0,
		.5,
		.002,
		.5,
		.4,
		.1
	], [
		1,
		0,
		.2,
		.002,
		.15,
		0,
		.08
	]),
	pluck: P([
		1,
		0,
		.8,
		.002,
		.45,
		0,
		.3
	], [
		2,
		0,
		.4,
		.002,
		.15,
		0,
		.1
	], [
		2,
		3,
		.35,
		.002,
		.35,
		0,
		.25
	], [
		5,
		0,
		.2,
		.002,
		.06,
		0,
		.05
	])
};
function I(e, t, n, r, i) {
	let a = {
		version: 1,
		name: e,
		modules: Object.entries(r).map(([e, { type: t, params: n, lanes: r, euclid: i, steps: a, notes: o }], s) => {
			let c = lt(t, e), l = Y[t].drum?.voices ?? [];
			if (r) for (let e of l) c.params[`${e.id}Pattern`] = fe(r[e.id] ?? "");
			if (i) for (let e of l) {
				let [t, n, r = 0] = i[e.id] ?? [0, c.params[`${e.id}Steps`]];
				Object.assign(c.params, {
					[`${e.id}Hits`]: t,
					[`${e.id}Steps`]: n,
					[`${e.id}Shift`]: r
				});
			}
			return Object.assign(c.params, n), a && s > 0 ? {
				...c,
				steps: a
			} : o ? {
				...c,
				notes: o
			} : c;
		}),
		cables: [],
		sequencer: {
			bpm: t,
			swing: n,
			steps: Object.values(r)[0].steps ?? dt("performance").steps
		}
	};
	for (let [e, t, n, r, o] of i) a = kt(a, {
		moduleId: e,
		portId: t
	}, {
		moduleId: n,
		portId: r
	}, o);
	return a;
}
var L = (e, t, n = "") => [[
	e,
	`pitch${n}`,
	t,
	"pitch"
], [
	e,
	`gate${n}`,
	t,
	"gate"
]], me = (...e) => e.slice(1).map((t, n) => [
	e[n],
	"out",
	t,
	"in"
]), he = (e, t, ...n) => [...e.flatMap((e, n) => [...me(...e), [
	e.at(-1),
	"out",
	t,
	"abcdefgh"[n]
]]), ...me(t, ...n)], R = (e, ...t) => he(e, "mixer", ...t, "output");
function ge(e) {
	return e === "Vintage Bass" ? I(e, 94, .1, {
		performance: {
			type: "performance",
			steps: j("X..o.xx.X..x.xx.", [
				43,
				43,
				43,
				43,
				43,
				46,
				48,
				48,
				36,
				36,
				36,
				48,
				48,
				46,
				41,
				41
			], [
				.9,
				.5,
				.5,
				.5,
				.5,
				.6,
				.9,
				.5,
				.9,
				.5,
				.5,
				.45,
				.5,
				.6,
				.9,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Wave: 3,
				osc2Detune: 4,
				osc2Level: .4,
				osc3Wave: 1,
				osc3Level: .55,
				cutoff: 480,
				resonance: .3,
				drive: .3,
				envAmount: .45,
				filterAttack: .004,
				filterDecay: .25,
				filterSustain: .25,
				filterRelease: .15,
				ampAttack: .004,
				ampDecay: .4,
				ampSustain: .8,
				ampRelease: .08,
				glide: .04,
				level: .75
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 2,
				midFreq: 1,
				midGain: 3,
				drive: 6
			}
		},
		melody: {
			type: "performance",
			steps: j("x".repeat(16), M([86, 6], [84, 1], [82, 1], [79, 6], [77, 1], [79, 1]), .95)
		},
		whistle: {
			type: "monarch",
			params: {
				osc1Wave: 0,
				osc1Level: .9,
				osc2Level: 0,
				osc3Level: 0,
				cutoff: 6e3,
				resonance: 0,
				drive: 0,
				envAmount: 0,
				tracking: 0,
				ampAttack: .03,
				ampDecay: .3,
				ampSustain: 1,
				ampRelease: .3,
				glide: .12,
				level: .5
			}
		},
		echo: {
			type: "delay",
			params: {
				time: N(94),
				feedback: .35,
				mix: .25
			}
		},
		chords: {
			type: "performance",
			steps: j("x.......x.......", M([55, 8], [60, 8]), .95)
		},
		keys: {
			type: "aurora",
			params: {
				osc1Wave: 2,
				osc2Wave: 1,
				osc2Detune: 8,
				blend: .45,
				cutoff: 1600,
				resonance: .1,
				envAmount: .2,
				filterAttack: .05,
				filterDecay: .8,
				filterSustain: .4,
				ampAttack: .04,
				ampDecay: .9,
				ampSustain: .7,
				ampRelease: 1.6,
				lfoWidth: .3,
				chord: 4,
				vintage: .4,
				level: .6
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 150,
				lmfGain: -3,
				lmfFreq: 400,
				lmfQ: 1.2,
				hmfGain: 2,
				hmfFreq: 2500,
				hmfQ: .8,
				hfGain: 2,
				hfFreq: 1e4
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 1.8,
				mix: .25
			}
		},
		drums: {
			type: "strike",
			params: {
				level: 1,
				kickDecay: .4,
				snareTune: -2,
				snareDecay: .3,
				clapLevel: .55,
				hatDecay: .06,
				hatLevel: .45,
				hatPan: .2,
				openLevel: .4,
				openPan: .2,
				tambourineLevel: .3,
				tambourinePan: -.3
			},
			lanes: {
				kick: "x......xx.x.....",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "x.xxx.x.x.xxx.x.",
				open: ".....x.......x..",
				tambourine: "....x.......x..."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .01,
				release: .15,
				color: 1,
				detectorHp: 1,
				output: 7
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: .6,
				c: .7,
				d: .7
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 0,
				attack: 4,
				release: 4,
				output: 2
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...L("performance", "monarch"),
		...L("melody", "whistle"),
		...L("chords", "keys"),
		...R([
			["drums", "talon"],
			["monarch", "brit"],
			[
				"keys",
				"console",
				"space"
			],
			["whistle", "echo"]
		], "cohere")
	]) : e === "Vintage Lead" ? I(e, 120, 0, {
		performance: {
			type: "performance",
			steps: j("X.xx.xx.X.xxX.xx", [
				76,
				76,
				76,
				74,
				74,
				72,
				74,
				74,
				72,
				72,
				69,
				72,
				71,
				71,
				67,
				71
			], .7)
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 3,
				osc1Level: .7,
				osc2Detune: 9,
				osc2Level: .5,
				osc3Wave: 3,
				osc3Octave: 1,
				osc3Level: .2,
				cutoff: 2600,
				resonance: .25,
				drive: .2,
				envAmount: .35,
				tracking: .6,
				filterDecay: .2,
				filterSustain: .4,
				ampAttack: .004,
				ampDecay: .25,
				ampSustain: .7,
				ampRelease: .15,
				glide: .025,
				level: .6
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 200,
				lmfGain: -2,
				lmfFreq: 500,
				hmfGain: 3,
				hmfFreq: 3e3,
				hfGain: 2,
				hfFreq: 12e3
			}
		},
		echo: {
			type: "delay",
			params: {
				time: N(120),
				feedback: .3,
				mix: .22
			}
		},
		octaves: {
			type: "performance",
			steps: j("XxXxXxXxXxXxXxXx", [
				33,
				45,
				33,
				45,
				33,
				45,
				33,
				45,
				29,
				41,
				29,
				41,
				31,
				43,
				31,
				43
			], .5)
		},
		bass: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Detune: 6,
				osc2Level: .4,
				osc3Level: .3,
				cutoff: 600,
				resonance: .3,
				envAmount: .5,
				filterDecay: .12,
				filterSustain: .3,
				ampAttack: .002,
				ampDecay: .15,
				ampSustain: .5,
				ampRelease: .05,
				level: .7
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 1,
				lfGain: 2,
				midFreq: 3,
				midGain: 2,
				drive: 6
			}
		},
		chords: {
			type: "performance",
			steps: j("x.......x...x...", M([57, 8], [50, 4], [52, 4]), .95)
		},
		strings: {
			type: "aurora",
			params: {
				osc2Wave: 0,
				osc2Detune: 12,
				hpf: 200,
				cutoff: 3e3,
				envAmount: .15,
				filterAttack: .1,
				filterDecay: .8,
				filterSustain: .6,
				ampAttack: .08,
				ampDecay: .6,
				ampSustain: .8,
				ampRelease: 1.2,
				lfoRate: .5,
				lfoWidth: .2,
				chord: 2,
				vintage: .4,
				level: .7
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2,
				mix: .3
			}
		},
		drums: {
			type: "boom",
			params: {
				kickTune: 52,
				kickDecay: .5,
				snareTone: .55,
				snappy: .7,
				hatDecay: .04,
				openDecay: .25,
				level: .85
			},
			lanes: {
				kick: "x...x...x...x...",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "xx.xxx.xxx.xxx.x",
				open: "..x...x...x...x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .003,
				release: .1,
				color: 1,
				detectorHp: 1,
				output: 5
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: .75,
				c: 1,
				d: .45
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 1,
				attack: 4,
				release: 1,
				output: 2
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...L("performance", "monarch"),
		...L("octaves", "bass"),
		...L("chords", "strings"),
		...R([
			["drums", "talon"],
			["bass", "brit"],
			["strings", "space"],
			[
				"monarch",
				"console",
				"echo"
			]
		], "cohere")
	]) : e === "Boom Bap" ? I(e, 84, .18, {
		performance: {
			type: "performance",
			steps: j("X.....x.X..x..x.", M([50, 8], [55, 6], [50, 2]), [
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.4,
				.5,
				.95,
				.5,
				.5,
				.4,
				.5,
				.5,
				.6,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 1,
				osc1Octave: -1,
				osc1Level: .8,
				osc2Wave: 0,
				osc2Octave: -1,
				osc2Detune: 0,
				osc2Level: .3,
				osc3Wave: 0,
				osc3Octave: -2,
				osc3Level: .55,
				cutoff: 420,
				resonance: .1,
				drive: .3,
				envAmount: .25,
				tracking: .4,
				filterDecay: .3,
				filterSustain: .3,
				ampAttack: .006,
				ampDecay: .5,
				ampSustain: .75,
				ampRelease: .12,
				glide: .03,
				level: .8
			}
		},
		delay: {
			type: "delay",
			params: {
				time: N(84),
				feedback: .3,
				mix: .18
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 50,
				kickDecay: .55,
				snareTone: .4,
				snappy: .45,
				hatDecay: .05,
				level: .85
			},
			lanes: {
				kick: "x.....x...x..x..",
				snare: "....x.......x...",
				hat: "x.x.x.x.x.x.x.xx"
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .8,
				woodTune: 3,
				woodLevel: .4,
				shakerDecay: .08,
				shakerLevel: .5
			},
			euclid: {
				wood: [
					3,
					16,
					3
				],
				shaker: [
					8,
					16,
					1
				]
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 40,
				lfGain: 3,
				lfFreq: 80,
				lfBell: 1,
				lmfGain: -3,
				lmfFreq: 450,
				lmfQ: 1.2,
				hmfGain: 3.5,
				hmfFreq: 3e3,
				hmfQ: 1.2,
				lpf: 12e3
			}
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .1,
				brightness: .8,
				velocity: .75,
				lfoRate: 4.5,
				lfoDepth: .03,
				chord: 4,
				level: .7,
				...F.epiano
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 3,
				midFreq: 1,
				midGain: 2,
				hfGain: -6,
				drive: 10,
				output: 4
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .006,
				release: .15,
				color: 2,
				detectorHp: 1,
				output: 5
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: .5,
				c: .45,
				d: 1
			}
		},
		valve: {
			type: "compressor",
			params: {
				input: 1,
				threshold: -16,
				time: 1,
				output: 1
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...L("performance", "monarch"),
		...L("performance", "prism", 3),
		...R([
			[
				"boom",
				"console",
				"talon"
			],
			[
				"prism",
				"brit",
				"delay"
			],
			["monarch"],
			["orbit"]
		], "valve")
	]) : e === "Late Night Hip-Hop" ? I(e, 72, .24, {
		performance: {
			type: "performance",
			steps: j("X.....o.X....x..", M([41, 8], [39, 5], [46, 3]), [
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.95,
				.5,
				.5,
				.5,
				.5,
				.7,
				.5,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 1,
				osc1Level: .8,
				osc2Wave: 0,
				osc2Detune: 0,
				osc2Level: .3,
				osc3Wave: 0,
				osc3Level: .4,
				cutoff: 520,
				resonance: .1,
				drive: .12,
				envAmount: .3,
				filterDecay: .4,
				ampAttack: .008,
				ampDecay: .6,
				ampSustain: .8,
				ampRelease: .25,
				glide: .05,
				level: .8
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2,
				lfFreq: 80,
				lmfGain: -3,
				lmfFreq: 250,
				hmfGain: 3,
				hmfFreq: 1200,
				lpf: 8e3
			}
		},
		chords: {
			type: "performance",
			steps: j("x.......x.....o.", M([57, 8], [55, 8]), .95)
		},
		keys: {
			type: "aurora",
			params: {
				osc1Wave: 1,
				osc1Width: .3,
				osc2Wave: 2,
				osc2Octave: 1,
				blend: .4,
				cutoff: 1400,
				envAmount: .25,
				filterAttack: .01,
				filterDecay: 1.2,
				ampAttack: .06,
				ampDecay: 1.5,
				ampSustain: .6,
				ampRelease: 2,
				lfoWidth: .35,
				lfoFilter: .05,
				chord: 2,
				vintage: .5,
				level: .6
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 3,
				midFreq: 0,
				midGain: -3,
				hfGain: -5,
				drive: 8,
				output: 3
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2.4,
				mix: .3
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 47,
				kickDecay: .7,
				snareTone: .3,
				snappy: .35,
				hatDecay: .04,
				openDecay: .3,
				level: .85
			},
			lanes: {
				kick: "x......x..x.....",
				snare: "....x.......x...",
				rim: "..............x.",
				hat: "..x...x...x...x."
			}
		},
		orbit: {
			type: "orbit",
			params: {
				pitch: -4,
				level: .8,
				shakerLevel: .5
			},
			euclid: { shaker: [
				6,
				16,
				2
			] }
		},
		talon: {
			type: "talon",
			params: {
				input: 4,
				ratio: 5,
				attack: .01,
				release: .4,
				color: 1,
				output: 9
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: .6,
				c: .55,
				d: 1
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 25,
				lpf: 9e3,
				lfGain: 1.5,
				lfFreq: 120,
				lfBell: 1,
				hfGain: -2,
				hfFreq: 6e3
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -18,
				ratio: 0,
				attack: 4,
				release: 4,
				output: 3
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...L("performance", "monarch"),
		...L("chords", "keys"),
		...R([
			["boom", "talon"],
			["monarch", "bassEq"],
			[
				"keys",
				"brit",
				"space"
			],
			["orbit"]
		], "console", "cohere")
	]) : e === "Roots Reggae" ? I(e, 76, .2, {
		performance: {
			type: "performance",
			steps: j("..X...x.X..x.xx.", [
				33,
				33,
				33,
				33,
				33,
				33,
				36,
				36,
				38,
				38,
				38,
				38,
				38,
				41,
				40,
				40
			], [
				.65,
				.65,
				.85,
				.65,
				.65,
				.65,
				.5,
				.65,
				.85,
				.65,
				.65,
				.45,
				.65,
				.5,
				.85,
				.65
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 1,
				osc1Level: .7,
				osc2Wave: 0,
				osc2Octave: 1,
				osc2Detune: 0,
				osc2Level: .15,
				osc3Wave: 0,
				osc3Octave: 0,
				osc3Level: .5,
				cutoff: 520,
				resonance: .05,
				drive: .15,
				envAmount: .15,
				filterDecay: .3,
				ampAttack: .006,
				ampDecay: .35,
				ampSustain: .7,
				ampRelease: .12,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 3,
				midFreq: 0,
				midGain: -3,
				hfGain: -4,
				drive: 4
			}
		},
		bubble: {
			type: "performance",
			steps: j("..xx..xx..xx..xx", M([57, 8], [50, 8]), .6)
		},
		organ: {
			type: "aurora",
			params: {
				osc1Wave: 1,
				osc2Wave: 3,
				osc2Octave: 1,
				osc2Detune: 0,
				blend: .5,
				cutoff: 2600,
				resonance: 0,
				slope: 0,
				envAmount: 0,
				ampAttack: .003,
				ampDecay: .2,
				ampSustain: .85,
				ampRelease: .04,
				lfoRate: 6,
				lfoPitch: .01,
				lfoWidth: 0,
				chord: 2,
				vintage: .2,
				level: .45
			}
		},
		skank: {
			type: "performance",
			steps: j("....X.......X...", M([69, 8], [62, 8]), .35)
		},
		guitar: {
			type: "oracle",
			params: {
				bShape: 2,
				bFine: 5,
				cutoff: 2800,
				resonance: .2,
				envAmount: .3,
				filterDecay: .12,
				filterSustain: 0,
				ampAttack: .002,
				ampDecay: .14,
				ampSustain: 0,
				ampRelease: .08,
				chord: 2,
				level: 1
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 250,
				lmfGain: -3,
				lmfFreq: 500,
				lmfQ: 1.2,
				hmfGain: 3.5,
				hmfFreq: 2200,
				hmfQ: 1.4,
				lpf: 9e3
			}
		},
		echo: {
			type: "delay",
			params: {
				time: N(76),
				feedback: .4,
				mix: .3
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 1.6,
				mix: .22
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 46,
				kickDecay: .6,
				snareTone: .5,
				hatDecay: .05,
				openDecay: .35,
				level: .85
			},
			lanes: {
				kick: "........x.......",
				rim: "........x.......",
				hat: "x.x.x...x.x.x..x",
				open: "......x.......x."
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .8,
				metalDecay: .09,
				metalTone: .7,
				metalLevel: .5,
				sandDecay: .06,
				sandLevel: .55
			},
			euclid: {
				metal: [
					2,
					16,
					4
				],
				sand: [
					2,
					16,
					4
				]
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 1,
				ratio: 2,
				attack: .01,
				release: .25,
				color: 1,
				output: 6
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: 1,
				c: .8,
				d: .7,
				e: .9
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 0,
				attack: 4,
				release: 4,
				output: 2
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...L("performance", "monarch"),
		...L("bubble", "organ"),
		...L("skank", "guitar"),
		...R([
			["boom", "talon"],
			["orbit"],
			["monarch", "brit"],
			["organ"],
			[
				"guitar",
				"console",
				"echo",
				"space"
			]
		], "cohere")
	]) : e === "Dub Session" ? I(e, 70, .18, {
		performance: {
			type: "performance",
			steps: j("X..x..x.X..x..x.", [
				28,
				28,
				28,
				28,
				28,
				28,
				31,
				31,
				33,
				33,
				33,
				31,
				31,
				31,
				26,
				26
			], [
				.85,
				.5,
				.5,
				.4,
				.5,
				.5,
				.6,
				.5,
				.85,
				.5,
				.5,
				.5,
				.5,
				.5,
				.7,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 0,
				osc1Level: .7,
				osc2Wave: 1,
				osc2Octave: 1,
				osc2Detune: 0,
				osc2Level: .12,
				osc3Wave: 0,
				osc3Octave: 0,
				osc3Level: .45,
				cutoff: 300,
				resonance: .1,
				drive: .25,
				envAmount: .1,
				ampAttack: .01,
				ampDecay: .4,
				ampSustain: .8,
				ampRelease: .2,
				glide: .02,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 3,
				midFreq: 0,
				midGain: -3,
				hfGain: -8,
				drive: 6
			}
		},
		skank: {
			type: "performance",
			steps: j("....x.......x...", M([64, 16]), .3)
		},
		guitar: {
			type: "oracle",
			params: {
				bShape: 2,
				bFine: 5,
				cutoff: 2400,
				resonance: .2,
				envAmount: .3,
				filterDecay: .12,
				filterSustain: 0,
				ampAttack: .002,
				ampDecay: .15,
				ampSustain: 0,
				ampRelease: .1,
				chord: 2,
				level: 1
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 220,
				lmfGain: -3,
				lmfFreq: 450,
				hmfGain: 3,
				hmfFreq: 1800,
				lpf: 6e3
			}
		},
		repeats: {
			type: "delay",
			params: {
				time: Number((60 / 70).toFixed(3)),
				feedback: .6,
				mix: .4
			}
		},
		melody: {
			type: "performance",
			steps: j("X.....X.X.X...X.", [
				71,
				71,
				71,
				71,
				71,
				71,
				74,
				74,
				71,
				71,
				69,
				69,
				69,
				69,
				67,
				67
			], .95)
		},
		melodica: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: 0,
				brightness: .9,
				velocity: .5,
				lfoRate: 5,
				lfoDepth: .12,
				level: 1,
				...F.reed
			}
		},
		hall: {
			type: "reverb",
			params: {
				decay: 2.2,
				mix: .3
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 45,
				kickDecay: 1.2,
				snareTone: .35,
				snappy: .5,
				hatDecay: .06,
				openDecay: .5,
				level: .8
			},
			lanes: {
				kick: "x..x......x.....",
				snare: "....x.......x...",
				rim: ".......x........",
				hat: "x.x.x.x.x.x.x...",
				open: "..............x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 3,
				ratio: 2,
				attack: .003,
				release: .2,
				color: 2,
				output: 8
			}
		},
		reverb: {
			type: "reverb",
			params: {
				decay: 1.4,
				mix: .2
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .9,
				skinTune: 5,
				skinDecay: .25,
				skinLevel: 1,
				woodLevel: .5
			},
			euclid: {
				skin: [
					1,
					16,
					12
				],
				wood: [
					2,
					16,
					6
				]
			}
		},
		delay: {
			type: "delay",
			params: {
				time: N(70),
				feedback: .55,
				mix: .45
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: 1,
				c: .7,
				d: 1,
				e: 1
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 0,
				attack: 4,
				release: 4,
				output: 2
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...L("performance", "monarch"),
		...L("skank", "guitar"),
		...L("melody", "melodica"),
		...R([
			[
				"boom",
				"talon",
				"reverb"
			],
			["orbit", "delay"],
			["monarch", "brit"],
			[
				"guitar",
				"console",
				"repeats"
			],
			["melodica", "hall"]
		], "cohere")
	]) : e === "Trap Soul" ? I(e, 68, .06, {
		performance: {
			type: "performance",
			steps: j("X.......X.....x.", M([53, 8], [58, 8]), [
				.95,
				.65,
				.65,
				.65,
				.65,
				.65,
				.65,
				.65,
				.95,
				.65,
				.65,
				.65,
				.65,
				.65,
				.6,
				.65
			])
		},
		oracle: {
			type: "oracle",
			params: {
				aLevel: .7,
				bLevel: .6,
				bFine: 6,
				noise: .03,
				cutoff: 1300,
				resonance: .12,
				envAmount: .3,
				tracking: .4,
				filterAttack: .005,
				filterDecay: .9,
				filterSustain: .25,
				filterRelease: 1.6,
				ampAttack: .01,
				ampDecay: 1.2,
				ampSustain: .6,
				ampRelease: 2.4,
				lfoRate: .35,
				lfoAmount: .12,
				lfoDest: 2,
				vintage: .45,
				chord: 4,
				level: 1
			}
		},
		equalizer: {
			type: "equalizer",
			params: {
				hpf: 140,
				lmfGain: -3,
				lmfFreq: 380,
				lmfQ: 1.2,
				hmfGain: 2,
				hmfFreq: 2800,
				hmfQ: .8,
				hfGain: 3,
				hfFreq: 9e3,
				lpf: 16e3,
				output: 4
			}
		},
		reverb: {
			type: "reverb",
			params: {
				decay: 2.6,
				mix: .3
			}
		},
		performance2: {
			type: "performance",
			steps: j("X.....x.X..x..x.", [
				53,
				53,
				53,
				53,
				53,
				53,
				53,
				53,
				58,
				58,
				58,
				56,
				56,
				56,
				60,
				60
			], [
				.95,
				.65,
				.65,
				.65,
				.65,
				.65,
				.6,
				.65,
				.95,
				.65,
				.65,
				.5,
				.65,
				.65,
				.5,
				.65
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 0,
				osc1Octave: -2,
				osc1Level: .8,
				osc2Wave: 1,
				osc2Octave: -1,
				osc2Detune: 0,
				osc2Level: .12,
				osc3Level: 0,
				cutoff: 700,
				resonance: 0,
				drive: .55,
				envAmount: .1,
				tracking: .3,
				ampAttack: .003,
				ampDecay: .8,
				ampSustain: .75,
				ampRelease: 1.1,
				glide: .07,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 2,
				midFreq: 1,
				midGain: 4,
				drive: 12,
				output: -2
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 52,
				kickDecay: .32,
				snareTone: .65,
				snappy: .8,
				hatDecay: .035,
				openDecay: .3,
				level: .8
			},
			lanes: {
				kick: "x.....x.x.....x.",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "x.x.x.xxx.x.x.xx",
				open: "...........x...."
			}
		},
		compressor: {
			type: "compressor",
			params: {
				input: 3,
				threshold: -26,
				time: 1,
				output: 8
			}
		},
		bells: {
			type: "performance",
			steps: j("..X...X...X..X..", [
				84,
				84,
				84,
				84,
				84,
				84,
				80,
				80,
				80,
				80,
				82,
				82,
				82,
				77,
				77,
				77
			], .5)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .05,
				brightness: 1,
				velocity: .6,
				level: 1,
				...F.bell
			}
		},
		delay: {
			type: "delay",
			params: {
				time: N(68),
				feedback: .4,
				mix: .3
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: .55,
				c: 1,
				d: 1
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -18,
				ratio: 0,
				attack: 4,
				release: 4,
				scHpf: 2,
				output: 2
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...L("performance", "oracle"),
		...L("performance2", "monarch"),
		...L("bells", "prism"),
		...R([
			[
				"oracle",
				"equalizer",
				"reverb"
			],
			["monarch", "brit"],
			["boom", "compressor"],
			["prism", "delay"]
		], "cohere")
	]) : e === "Broken Beat" ? I(e, 108, .1, {
		performance: {
			type: "performance",
			steps: j("X..x..x...x..x.x", [
				36,
				36,
				36,
				48,
				48,
				48,
				34,
				34,
				34,
				34,
				41,
				41,
				41,
				44,
				44,
				43
			], .4)
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Wave: 3,
				osc2Detune: 5,
				osc2Level: .35,
				osc3Wave: 0,
				osc3Level: .45,
				cutoff: 700,
				resonance: .35,
				drive: .3,
				envAmount: .55,
				filterDecay: .14,
				filterSustain: .15,
				ampAttack: .003,
				ampDecay: .2,
				ampSustain: .4,
				ampRelease: .06,
				level: .7
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 2,
				lfGain: 2,
				midFreq: 2,
				midGain: 3,
				drive: 8
			}
		},
		stabs: {
			type: "performance",
			steps: j("X..x...x..x..x..", M([48, 7], [53, 9]), .4)
		},
		keys: {
			type: "oracle",
			params: {
				aShape: 2,
				bFine: 8,
				cutoff: 1800,
				resonance: .15,
				envAmount: .45,
				filterDecay: .25,
				filterSustain: .2,
				ampAttack: .003,
				ampDecay: .35,
				ampSustain: .3,
				ampRelease: .25,
				chord: 4,
				vintage: .4,
				level: .9
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 160,
				lmfGain: -2.5,
				lmfFreq: 350,
				hmfGain: 3,
				hmfFreq: 2800,
				hfGain: 2,
				hfFreq: 9e3
			}
		},
		echo: {
			type: "delay",
			params: {
				time: N(108),
				feedback: .3,
				mix: .2
			}
		},
		punch: {
			type: "punch",
			params: {
				kickTune: 54,
				kickClick: .55,
				kickDecay: .4,
				snareTone: .55,
				snappy: .65,
				hatDecay: .04,
				openDecay: .2,
				level: .85
			},
			lanes: {
				kick: "x.....x..x...x..",
				snare: "....x.......x...",
				clap: "....x..........x",
				hat: "x.xxx.x.x.xxx.x.",
				open: ".....x.......x.."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .004,
				release: .12,
				color: 2,
				detectorHp: 1,
				output: 5
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .5,
				skinTune: 5,
				tomTune: 7,
				sandLevel: .6
			},
			euclid: {
				skin: [3, 8],
				tom: [
					2,
					16,
					3
				],
				sand: [5, 12]
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: .5,
				c: .85,
				d: .8
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 1,
				attack: 4,
				release: 1,
				output: 2
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...L("performance", "monarch"),
		...L("stabs", "keys"),
		...R([
			["punch", "talon"],
			["orbit"],
			["monarch", "brit"],
			[
				"keys",
				"console",
				"echo"
			]
		], "cohere")
	]) : I(e, 96, .08, {
		performance: {
			type: "performance",
			steps: j("X..X..X.X..X..X.", [
				62,
				62,
				62,
				65,
				65,
				65,
				69,
				69,
				67,
				67,
				67,
				72,
				72,
				72,
				69,
				69
			], .5)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: 0,
				brightness: .9,
				velocity: .6,
				level: 1,
				...F.kalimba
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 180,
				lmfGain: -2,
				lmfFreq: 400,
				hmfGain: 2.5,
				hmfFreq: 3500,
				hfGain: 3,
				hfFreq: 1e4
			}
		},
		echo: {
			type: "delay",
			params: {
				time: N(96),
				feedback: .35,
				mix: .25
			}
		},
		bass: {
			type: "performance",
			steps: j("X......o..x.....", M([38, 10], [36, 6]), [
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.6,
				.5,
				.5,
				.95,
				.5,
				.5,
				.5,
				.5,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 0,
				osc1Level: .8,
				osc2Wave: 1,
				osc2Detune: 0,
				osc2Level: .2,
				osc3Level: 0,
				cutoff: 300,
				resonance: 0,
				drive: .2,
				envAmount: .1,
				ampAttack: .006,
				ampDecay: .6,
				ampSustain: .8,
				ampRelease: .2,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 2,
				midFreq: 1,
				midGain: 4,
				drive: 10
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 44,
				kickDecay: .9,
				level: .85
			},
			lanes: { kick: "x.......x......." }
		},
		talon: {
			type: "talon",
			params: {
				input: 3,
				ratio: 4,
				attack: .002,
				release: .2,
				color: 2,
				output: 4
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .65,
				woodLevel: .5,
				metalLevel: .35,
				shakerLevel: .45
			},
			euclid: {
				skin: [
					5,
					16,
					2
				],
				wood: [
					3,
					8,
					2
				],
				sand: [7, 12],
				metal: [2, 15],
				shaker: [
					9,
					16,
					2
				],
				tom: [
					3,
					14,
					1
				]
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .75,
				b: .8,
				c: 1,
				d: .6
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -18,
				ratio: 0,
				attack: 4,
				release: 4,
				output: 2
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...L("performance", "prism"),
		...L("bass", "monarch"),
		...R([
			["boom", "talon"],
			["orbit"],
			[
				"prism",
				"console",
				"echo"
			],
			["monarch", "brit"]
		], "cohere")
	]);
}
// src/retroPresets.ts
var z = (...e) => he(e, "mixer", "cohere", "main"), _e = {
	cohere: {
		type: "cohere",
		params: {
			threshold: -16,
			ratio: 0,
			attack: 4,
			release: 4,
			scHpf: 2,
			output: 2
		}
	},
	main: {
		type: "output",
		params: { volume: .7 }
	}
};
function ve(e) {
	return e === "Neon Skyline" ? I(e, 112, 0, {
		pads: {
			type: "performance",
			steps: j("X.......X.......", M([57, 8], [52, 8]), .95)
		},
		aurora: {
			type: "aurora",
			params: {
				osc2Wave: 0,
				osc2Detune: 12,
				hpf: 150,
				cutoff: 2400,
				envAmount: .2,
				filterAttack: .1,
				filterDecay: 1.5,
				filterSustain: .5,
				ampAttack: .08,
				ampDecay: 1,
				ampSustain: .8,
				ampRelease: 2.2,
				lfoRate: .4,
				lfoWidth: .3,
				chord: 2,
				vintage: .5,
				level: .8
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 180,
				lmfGain: -3,
				lmfFreq: 400,
				lmfQ: 1,
				hmfGain: 2,
				hmfFreq: 3e3,
				hmfQ: .8,
				hfGain: 3,
				hfFreq: 12e3
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2.6,
				mix: .35
			}
		},
		bass: {
			type: "performance",
			steps: j("X.x.X.x.X.x.X.x.", M([41, 8], [36, 8]), .55)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .2,
				brightness: 1,
				velocity: .6,
				level: 1,
				...F.bass
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 2,
				midFreq: 2,
				midGain: 2,
				hfGain: 1,
				drive: 8,
				output: 8
			}
		},
		arp: {
			type: "performance",
			steps: j("XxxxXxxxXxxxXxxx", [
				69,
				72,
				76,
				79,
				81,
				79,
				76,
				72,
				67,
				72,
				76,
				79,
				84,
				79,
				76,
				72
			], .5)
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 3,
				osc1Level: .7,
				osc2Detune: 5,
				osc2Level: .4,
				osc3Level: 0,
				cutoff: 2200,
				resonance: .3,
				envAmount: .4,
				filterDecay: .12,
				filterSustain: .1,
				ampAttack: .002,
				ampDecay: .18,
				ampSustain: .2,
				ampRelease: .12,
				level: .55
			}
		},
		echo: {
			type: "delay",
			params: {
				time: N(112),
				feedback: .35,
				mix: .3
			}
		},
		strike: {
			type: "strike",
			params: {
				level: 1,
				kickDecay: .4,
				snareTune: -2,
				snareDecay: .3,
				clapLevel: .5,
				hatLevel: .4,
				hatPan: .2,
				tambourineLevel: .3,
				tambourinePan: -.3
			},
			lanes: {
				kick: "x...x...x...x...",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "x.x.x.x.x.x.x.x.",
				tambourine: "....x.......x..."
			}
		},
		room: {
			type: "reverb",
			params: {
				decay: 1.2,
				mix: .3
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 0,
				ratio: 7,
				attack: 2e-4,
				release: .08,
				color: 2,
				output: 12
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: .75,
				c: .6,
				d: .45
			}
		},
		..._e
	}, [
		...L("pads", "aurora"),
		...L("bass", "prism"),
		...L("arp", "monarch"),
		...z([
			"strike",
			"room",
			"talon"
		], ["prism", "brit"], [
			"aurora",
			"console",
			"space"
		], ["monarch", "echo"])
	]) : e === "Digital Boogie" ? I(e, 116, .12, {
		bass: {
			type: "performance",
			steps: j("X..x..x.X.xx..x.", [
				40,
				40,
				40,
				52,
				52,
				52,
				40,
				40,
				45,
				45,
				45,
				57,
				57,
				57,
				43,
				43
			], [
				.6,
				.5,
				.5,
				.3,
				.5,
				.5,
				.6,
				.5,
				.6,
				.5,
				.5,
				.3,
				.5,
				.5,
				.6,
				.5
			])
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .3,
				brightness: 1.1,
				velocity: .8,
				level: 1,
				...F.slap
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 2,
				lfGain: 2,
				midFreq: 3,
				midGain: 3,
				drive: 6,
				output: 8
			}
		},
		stabs: {
			type: "performance",
			steps: j("..X..x....X..x..", M([52, 8], [57, 8]), .6)
		},
		aurora: {
			type: "aurora",
			params: {
				osc2Detune: 8,
				cutoff: 2600,
				envAmount: .4,
				filterDecay: .2,
				filterSustain: .2,
				ampAttack: .003,
				ampDecay: .3,
				ampSustain: .2,
				ampRelease: .2,
				lfoWidth: .2,
				chord: 4,
				vintage: .35,
				level: .6
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 150,
				lmfGain: -2.5,
				lmfFreq: 350,
				lmfQ: 1,
				hmfGain: 3,
				hmfFreq: 2500,
				hmfQ: 1,
				hfGain: 2,
				hfFreq: 1e4
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 1.2,
				mix: .2
			}
		},
		strike: {
			type: "strike",
			params: {
				level: 1,
				kickDecay: .35,
				snareDecay: .25,
				clapLevel: .6,
				hatDecay: .05,
				hatLevel: .35,
				hatPan: .2,
				bellLevel: .35,
				bellPan: -.25
			},
			lanes: {
				kick: "x.....x.x.....x.",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "x".repeat(16),
				bell: "......x.......x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .003,
				release: .1,
				color: 1,
				detectorHp: 1,
				output: 9
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: .75,
				c: .75
			}
		},
		..._e
	}, [
		...L("bass", "prism"),
		...L("stabs", "aurora"),
		...z(["strike", "talon"], ["prism", "brit"], [
			"aurora",
			"console",
			"space"
		])
	]) : e === "Midnight Ballad" ? I(e, 76, .04, {
		keys: {
			type: "performance",
			steps: j("X.....x.X.....x.", M([58, 8], [51, 8]), .9)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .08,
				brightness: .75,
				velocity: .75,
				lfoRate: 4.5,
				lfoDepth: .04,
				chord: 3,
				level: .7,
				...F.epiano
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 100,
				lmfGain: -2,
				lmfFreq: 300,
				lmfQ: 1,
				hmfGain: 2.5,
				hmfFreq: 1800,
				hmfQ: 1,
				hfGain: 1.5,
				hfFreq: 1e4
			}
		},
		echo: {
			type: "delay",
			params: {
				time: N(76),
				feedback: .25,
				mix: .15
			}
		},
		strings: {
			type: "performance",
			steps: j("X.......X.......", M([58, 8], [63, 8]), .95)
		},
		aurora: {
			type: "aurora",
			params: {
				osc1Wave: 0,
				osc2Wave: 0,
				osc2Detune: 10,
				hpf: 250,
				cutoff: 2200,
				envAmount: .15,
				filterAttack: .15,
				filterDecay: 1.5,
				filterSustain: .6,
				ampAttack: .12,
				ampDecay: 1.2,
				ampSustain: .8,
				ampRelease: 2.8,
				lfoRate: .3,
				lfoWidth: .3,
				chord: 1,
				vintage: .45,
				level: .8
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2.8,
				mix: .4
			}
		},
		bass: {
			type: "performance",
			steps: j("X.....x.X.....x.", M([34, 6], [41, 2], [39, 6], [46, 2]), [
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.8,
				.5,
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.8,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 1,
				osc1Level: .8,
				osc2Wave: 0,
				osc2Detune: 0,
				osc2Level: .3,
				osc3Wave: 0,
				osc3Level: .3,
				cutoff: 700,
				resonance: .15,
				drive: .15,
				envAmount: .25,
				filterDecay: .5,
				filterSustain: .4,
				ampAttack: .01,
				ampDecay: .8,
				ampSustain: .7,
				ampRelease: .3,
				glide: .08,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 2,
				midFreq: 1,
				midGain: 2,
				hfGain: -3,
				drive: 4
			}
		},
		strike: {
			type: "strike",
			params: {
				level: .9,
				kickDecay: .45,
				snareTune: -3,
				snareDecay: .5,
				hatLevel: .35,
				hatPan: .2,
				rideLevel: .3,
				ridePan: -.2
			},
			lanes: {
				kick: "x.......x..x....",
				snare: "....x.......x...",
				hat: "x...x...x...x...",
				ride: "..x...x...x...x."
			}
		},
		room: {
			type: "reverb",
			params: {
				decay: 1.6,
				mix: .35
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 0,
				ratio: 6,
				attack: 5e-4,
				release: .12,
				color: 1,
				output: 8
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .75,
				b: 1,
				c: .55,
				d: .4
			}
		},
		..._e
	}, [
		...L("keys", "prism"),
		...L("strings", "aurora"),
		...L("bass", "monarch"),
		...z([
			"strike",
			"room",
			"talon"
		], [
			"prism",
			"console",
			"echo"
		], ["aurora", "space"], ["monarch", "brit"])
	]) : e === "New Wave Motion" ? I(e, 132, 0, {
		bass: {
			type: "performance",
			steps: j("X.x.x.x.X.x.x.x.", [
				38,
				38,
				38,
				38,
				38,
				38,
				50,
				50,
				34,
				34,
				34,
				34,
				34,
				34,
				46,
				46
			], .6)
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Detune: 7,
				osc2Level: .5,
				osc3Wave: 3,
				osc3Level: .35,
				cutoff: 900,
				resonance: .3,
				drive: .35,
				envAmount: .45,
				filterDecay: .15,
				filterSustain: .3,
				ampAttack: .002,
				ampDecay: .15,
				ampSustain: .6,
				ampRelease: .05,
				level: .7
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 2,
				lfGain: 2,
				midFreq: 2,
				midGain: 4,
				hfGain: 2,
				drive: 10
			}
		},
		pad: {
			type: "performance",
			steps: j("x.......x.......", M([50, 16]), .95)
		},
		aurora: {
			type: "aurora",
			params: {
				osc1Wave: 1,
				osc1Width: .35,
				osc2Wave: 0,
				osc2Detune: 9,
				hpf: 180,
				cutoff: 2600,
				envAmount: .2,
				filterAttack: .15,
				filterDecay: 1,
				filterSustain: .5,
				ampAttack: .06,
				ampDecay: .8,
				ampSustain: .75,
				ampRelease: 1.6,
				lfoRate: .7,
				lfoWidth: .45,
				chord: 2,
				vintage: .35,
				level: .7
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 1.8,
				mix: .25
			}
		},
		hook: {
			type: "performance",
			steps: j("X..X..X...X..X..", [
				81,
				81,
				81,
				77,
				77,
				77,
				74,
				74,
				74,
				74,
				76,
				76,
				76,
				77,
				77,
				77
			], .6)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .05,
				brightness: 1.1,
				velocity: .6,
				level: 1,
				...F.bell
			}
		},
		echo: {
			type: "delay",
			params: {
				time: N(132),
				feedback: .35,
				mix: .25
			}
		},
		strike: {
			type: "strike",
			params: {
				level: 1,
				kickDecay: .35,
				snareDecay: .3,
				hatDecay: .05,
				hatLevel: .4,
				hatPan: .2,
				midTomPan: .3,
				lowTomPan: -.3
			},
			lanes: {
				kick: "x.......x.x.....",
				snare: "....x.......x...",
				hat: "x.x.x.x.x.x.x...",
				midTom: "..............x.",
				lowTom: "...............x"
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 35,
				lfGain: 3,
				lfFreq: 70,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 380,
				lmfQ: 1.2,
				hmfGain: 3,
				hmfFreq: 4500,
				hmfQ: 1,
				hfGain: 2,
				hfFreq: 1e4
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 4,
				attack: .002,
				release: .1,
				color: 2,
				detectorHp: 1,
				output: 10
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: .65,
				c: .55,
				d: .7
			}
		},
		..._e
	}, [
		...L("bass", "monarch"),
		...L("pad", "aurora"),
		...L("hook", "prism"),
		...z([
			"strike",
			"console",
			"talon"
		], ["monarch", "brit"], ["aurora", "space"], ["prism", "echo"])
	]) : e === "Glass Arcade" ? I(e, 108, 0, {
		arp: {
			type: "performance",
			steps: j("XxxxXxxxXxxxXxxx", [
				72,
				76,
				79,
				83,
				84,
				83,
				79,
				76,
				69,
				72,
				76,
				79,
				81,
				79,
				76,
				72
			], .5)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: 0,
				brightness: 1.2,
				velocity: .6,
				level: 1,
				...F.bell,
				op1Decay: .6,
				op1Release: .4,
				op3Decay: .5,
				op3Release: .3
			}
		},
		echo: {
			type: "delay",
			params: {
				time: N(108),
				feedback: .4,
				mix: .3
			}
		},
		melody: {
			type: "performance",
			steps: j("X.x.x...X.x.xx..", [
				76,
				76,
				79,
				79,
				81,
				81,
				79,
				79,
				76,
				76,
				74,
				74,
				72,
				74,
				74,
				74
			], .75)
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 3,
				osc1Level: .8,
				osc2Wave: 3,
				osc2Detune: 6,
				osc2Level: .35,
				osc3Level: 0,
				cutoff: 3200,
				resonance: .15,
				envAmount: .2,
				filterDecay: .2,
				filterSustain: .6,
				ampAttack: .003,
				ampDecay: .2,
				ampSustain: .75,
				ampRelease: .1,
				glide: .02,
				level: .55
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 2,
				midFreq: 3,
				midGain: 3,
				hfGain: 2,
				drive: 4,
				output: 4
			}
		},
		bass: {
			type: "performance",
			steps: j("X.x.X.x.X.x.X.x.", [
				36,
				36,
				48,
				48,
				36,
				36,
				48,
				48,
				33,
				33,
				45,
				45,
				33,
				33,
				45,
				45
			], .55)
		},
		aurora: {
			type: "aurora",
			params: {
				osc1Wave: 1,
				osc1Width: .25,
				osc2Wave: 1,
				osc2Octave: -1,
				osc2Detune: 0,
				osc2Width: .5,
				blend: .4,
				cutoff: 1400,
				resonance: .2,
				envAmount: .4,
				filterDecay: .15,
				filterSustain: .2,
				ampAttack: .002,
				ampDecay: .2,
				ampSustain: .5,
				ampRelease: .06,
				lfoWidth: 0,
				level: 1
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 35,
				lfGain: 2,
				lfFreq: 90,
				lmfGain: -3,
				lmfFreq: 300,
				lmfQ: 1,
				hmfGain: 2,
				hmfFreq: 1200,
				hmfQ: 1,
				lpf: 8e3
			}
		},
		strike: {
			type: "strike",
			params: {
				level: 1,
				kickDecay: .3,
				snareDecay: .22,
				hatDecay: .04,
				hatLevel: .4,
				hatPan: .2,
				openLevel: .35,
				openPan: .2
			},
			lanes: {
				kick: "x.....x.x.......",
				snare: "....x.......x...",
				hat: "x.x.x.x.x.x.x...",
				open: "..............x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 3,
				ratio: 3,
				attack: 3e-4,
				release: .1,
				color: 0,
				detectorHp: 1,
				output: 10
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: 1,
				c: .3,
				d: .85
			}
		},
		..._e
	}, [
		...L("arp", "prism"),
		...L("melody", "monarch"),
		...L("bass", "aurora"),
		...z(["strike", "talon"], ["prism", "echo"], ["monarch", "brit"], ["aurora", "console"])
	]) : I(e, 96, .06, {
		pads: {
			type: "performance",
			steps: j("X.......X.......", M([50, 8], [55, 8]), .95)
		},
		aurora: {
			type: "aurora",
			params: {
				osc1Wave: 0,
				osc2Wave: 2,
				osc2Octave: 1,
				osc2Detune: 6,
				blend: .4,
				hpf: 120,
				cutoff: 2e3,
				envAmount: .15,
				filterAttack: .12,
				filterDecay: 1.5,
				filterSustain: .6,
				ampAttack: .1,
				ampDecay: 1.2,
				ampSustain: .8,
				ampRelease: 2.4,
				lfoRate: .25,
				lfoWidth: .3,
				lfoFilter: .05,
				chord: 3,
				vintage: .4,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 2,
				midFreq: 0,
				midGain: -2,
				hfGain: 5,
				drive: 3
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2.8,
				mix: .35
			}
		},
		pluck: {
			type: "performance",
			steps: j("X.XX.X.XX.X.XX.X", [
				74,
				74,
				78,
				81,
				81,
				85,
				85,
				81,
				79,
				79,
				83,
				86,
				86,
				83,
				83,
				79
			], .5)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: 0,
				brightness: .9,
				velocity: .6,
				level: 1,
				...F.pluck,
				op1Level: 1
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 200,
				lmfGain: -2,
				lmfFreq: 450,
				lmfQ: 1,
				hmfGain: 2,
				hmfFreq: 3e3,
				hmfQ: .8,
				hfGain: 3,
				hfFreq: 12e3
			}
		},
		echo: {
			type: "delay",
			params: {
				time: N(96),
				feedback: .45,
				mix: .3
			}
		},
		bass: {
			type: "performance",
			steps: j("X.....x.X.....x.", M([38, 8], [43, 8]), [
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 0,
				osc1Level: .8,
				osc2Wave: 1,
				osc2Detune: 0,
				osc2Level: .25,
				osc3Level: 0,
				cutoff: 400,
				resonance: 0,
				drive: .1,
				envAmount: .1,
				ampAttack: .01,
				ampDecay: .6,
				ampSustain: .8,
				ampRelease: .3,
				glide: .04,
				level: .8
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .9,
				woodTune: 5,
				woodLevel: .45,
				sandLevel: .5,
				shakerDecay: .08,
				shakerLevel: .55
			},
			euclid: {
				wood: [3, 8],
				sand: [
					5,
					16,
					2
				],
				shaker: [
					8,
					16,
					1
				]
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .7,
				b: 1,
				c: .53,
				d: 1
			}
		},
		..._e,
		cohere: {
			type: "cohere",
			params: {
				threshold: -14,
				ratio: 0,
				attack: 5,
				release: 4,
				output: 1
			}
		}
	}, [
		...L("pads", "aurora"),
		...L("pluck", "prism"),
		...L("bass", "monarch"),
		...z([
			"aurora",
			"brit",
			"space"
		], [
			"prism",
			"console",
			"echo"
		], ["monarch"], ["orbit"])
	]);
}
// src/studioPresets.ts
var ye = (...e) => he(e, "sum", "cohere", "main");
function be(e) {
	return e === "French Touch" ? I(e, 123, .08, {
		seq: {
			type: "performance",
			steps: j("X.xx.x.xX.x.X.xx", [
				33,
				33,
				45,
				33,
				33,
				43,
				43,
				45,
				38,
				38,
				50,
				38,
				48,
				48,
				45,
				43
			], .5)
		},
		stabs: {
			type: "performance",
			steps: j("..X..x.x..X..x..", M([57, 8], [62, 8]), .55)
		},
		bass: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Wave: 3,
				osc2Detune: 5,
				osc2Level: .45,
				osc3Wave: 3,
				osc3Level: .5,
				cutoff: 520,
				resonance: .35,
				drive: .35,
				envAmount: .55,
				tracking: .6,
				filterAttack: .003,
				filterDecay: .16,
				filterSustain: .12,
				filterRelease: .08,
				ampAttack: .003,
				ampDecay: .3,
				ampSustain: .7,
				ampRelease: .06,
				glide: .015,
				level: .75
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 2,
				lfGain: 2.5,
				midFreq: 1,
				midGain: 3,
				drive: 8,
				output: -2
			}
		},
		keys: {
			type: "aurora",
			params: {
				osc2Wave: 0,
				osc2Detune: 9,
				hpf: 180,
				cutoff: 2200,
				envAmount: .35,
				filterAttack: .002,
				filterDecay: .22,
				filterSustain: .2,
				ampAttack: .004,
				ampDecay: .35,
				ampSustain: .5,
				ampRelease: .22,
				lfoWidth: 0,
				chord: 4,
				vintage: .35,
				level: .75
			}
		},
		sieve: {
			type: "filter",
			params: {
				cutoff: 1100,
				resonance: 4.5
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 150,
				lmfGain: -3,
				lmfFreq: 350,
				lmfQ: 1,
				hmfGain: 3,
				hmfFreq: 2e3,
				hmfQ: 1,
				hfGain: 2,
				hfFreq: 1e4
			}
		},
		sweep: {
			type: "lfo",
			params: {
				wave: 1,
				rate: .12
			}
		},
		echo: {
			type: "delay",
			params: {
				time: N(123),
				feedback: .3,
				mix: .2
			}
		},
		drums: {
			type: "punch",
			params: {
				kickTune: 52,
				kickClick: .45,
				kickDecay: .5,
				snappy: .6,
				hatDecay: .04,
				openDecay: .28,
				level: .85
			},
			lanes: {
				kick: "x...x...x...x...",
				clap: "....x.......x...",
				hat: "...x...x...x...x",
				open: "..x...x...x...x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .008,
				release: .12,
				color: 1,
				detectorHp: 1,
				output: 5
			}
		},
		sum: {
			type: "mixer",
			params: {
				a: .8,
				b: .9,
				c: .55
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 1,
				attack: 4,
				release: 1,
				output: 3
			}
		},
		main: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...L("seq", "bass"),
		...L("stabs", "keys"),
		[
			"sweep",
			"out",
			"sieve",
			"cv",
			.8
		],
		...ye(["drums", "talon"], [
			"keys",
			"sieve",
			"console",
			"echo"
		], ["bass", "brit"])
	]) : e === "Distortion Disco" ? I(e, 116, 0, {
		seq: {
			type: "performance",
			steps: j("Xx.xX.x.Xx.xX.xx", [
				28,
				40,
				40,
				28,
				38,
				38,
				40,
				40,
				31,
				43,
				43,
				31,
				33,
				33,
				35,
				38
			], .6)
		},
		stabs: {
			type: "performance",
			steps: j("..X....x..X..x..", M([64, 8], [57, 8]), .7)
		},
		bass: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Detune: 14,
				osc2Level: .6,
				osc3Wave: 3,
				osc3Octave: 1,
				osc3Level: .3,
				cutoff: 650,
				resonance: .25,
				drive: 1,
				envAmount: .5,
				tracking: .7,
				filterDecay: .2,
				filterSustain: .3,
				ampAttack: .002,
				ampDecay: .2,
				ampSustain: .8,
				ampRelease: .05,
				level: .7
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 2,
				lfGain: 3,
				midFreq: 1,
				midGain: 6,
				hfGain: -4,
				drive: 20,
				output: -2
			}
		},
		prophet: {
			type: "oracle",
			params: {
				bFine: 10,
				aLevel: .8,
				bLevel: .7,
				cutoff: 1400,
				resonance: .2,
				envAmount: .5,
				filterAttack: .005,
				filterDecay: .3,
				filterSustain: .3,
				filterRelease: .2,
				ampAttack: .004,
				ampDecay: .5,
				ampSustain: .55,
				ampRelease: .25,
				chord: 2,
				vintage: .45,
				level: .9
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 120,
				lmfGain: -3,
				lmfFreq: 400,
				lmfQ: 1,
				hmfGain: 3,
				hmfFreq: 2500,
				hmfQ: 1,
				hfGain: 1.5,
				hfFreq: 9e3,
				lpf: 14e3
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 1.4,
				mix: .18
			}
		},
		drums: {
			type: "strike",
			params: {
				level: .85,
				kickDecay: .35,
				kickLevel: 1,
				snareDecay: .25,
				snareLevel: .85,
				clapLevel: .6,
				hatDecay: .06,
				hatLevel: .5,
				hatPan: -.15,
				openLevel: .45,
				tambourineLevel: .4,
				tambourinePan: .25
			},
			lanes: {
				kick: "x...x...x...x...",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "x.x.x.x.x.x.x...",
				open: "..............x.",
				tambourine: "..x...x...x...x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 8,
				ratio: 6,
				attack: .001,
				release: .1,
				color: 2,
				fierce: 1,
				detectorHp: 1,
				output: 5
			}
		},
		sum: {
			type: "mixer",
			params: {
				a: 1,
				b: .9,
				c: .6
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -18,
				ratio: 2,
				attack: 3,
				release: 1,
				output: 4
			}
		},
		main: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...L("seq", "bass"),
		...L("stabs", "prophet"),
		...ye(["drums", "talon"], [
			"prophet",
			"console",
			"space"
		], ["bass", "brit"])
	]) : e === "Electro Pogo" ? I(e, 128, 0, {
		seq: {
			type: "performance",
			steps: j(".xXx.xXx.xXx.xXx", [
				38,
				38,
				50,
				38,
				38,
				38,
				50,
				38,
				34,
				34,
				46,
				34,
				36,
				36,
				48,
				36
			], .6)
		},
		hook: {
			type: "performance",
			steps: j("X.x.xx.x.X.xX.x.", [
				69,
				69,
				74,
				74,
				77,
				76,
				76,
				74,
				74,
				77,
				77,
				74,
				76,
				76,
				79,
				79
			], .7)
		},
		bass: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Detune: 8,
				osc2Level: .5,
				osc3Wave: 3,
				osc3Level: .45,
				cutoff: 500,
				resonance: .4,
				drive: .55,
				envAmount: .6,
				filterDecay: .12,
				filterSustain: .15,
				ampDecay: .18,
				ampSustain: .6,
				ampRelease: .04,
				level: .7
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2,
				lfFreq: 70,
				lfBell: 1,
				lmfGain: -3,
				lmfFreq: 280,
				lmfQ: 1.2,
				hmfGain: 3,
				hmfFreq: 1200,
				hmfQ: 1.2,
				lpf: 9e3
			}
		},
		lead: {
			type: "oracle",
			params: {
				bOctave: 1,
				bFine: 6,
				bLevel: .5,
				cutoff: 2600,
				resonance: .3,
				envAmount: .35,
				filterDecay: .25,
				filterSustain: .4,
				ampAttack: .003,
				ampDecay: .3,
				ampSustain: .65,
				ampRelease: .15,
				glide: .035,
				level: 1
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 2,
				midFreq: 3,
				midGain: 4,
				hfGain: 4,
				drive: 6,
				output: 6
			}
		},
		echo: {
			type: "delay",
			params: {
				time: N(128),
				feedback: .32,
				mix: .22
			}
		},
		drums: {
			type: "punch",
			params: {
				kickTune: 50,
				kickClick: .7,
				kickDecay: .45,
				snareTone: .6,
				snappy: .8,
				hatDecay: .035,
				openDecay: .2,
				level: .85
			},
			lanes: {
				kick: "x...x...x...x...",
				snare: "....x.......x..x",
				clap: "....x.......x...",
				hat: "xx.xxx.xxx.xxx.x",
				open: "..x...x...x...x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .006,
				release: .09,
				color: 1,
				detectorHp: 1,
				output: 5
			}
		},
		sum: {
			type: "mixer",
			params: {
				a: .8,
				b: .8,
				c: .5
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -14,
				ratio: 1,
				attack: 5,
				release: 4,
				scHpf: 2,
				output: 2
			}
		},
		main: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...L("seq", "bass"),
		...L("hook", "lead"),
		...ye(["drums", "talon"], [
			"lead",
			"brit",
			"echo"
		], ["bass", "console"])
	]) : I(e, 126, 0, {
		seq: {
			type: "performance",
			steps: j("XxxxXxxxXxxxXxxx", [
				36,
				48,
				36,
				48,
				36,
				48,
				36,
				48,
				32,
				44,
				32,
				44,
				34,
				46,
				34,
				46
			], .45)
		},
		hook: {
			type: "performance",
			steps: j("..X..x.x..X..x..", [
				75,
				75,
				75,
				75,
				75,
				74,
				74,
				72,
				72,
				72,
				75,
				75,
				75,
				74,
				74,
				74
			], .8)
		},
		bass: {
			type: "monarch",
			params: {
				osc1Wave: 3,
				osc1Level: .8,
				osc2Detune: -7,
				osc2Level: .5,
				osc3Wave: 3,
				osc3Level: .35,
				cutoff: 420,
				resonance: .75,
				drive: .6,
				envAmount: .7,
				tracking: .6,
				filterAttack: .002,
				filterDecay: .11,
				filterSustain: 0,
				filterRelease: .05,
				ampAttack: .002,
				ampDecay: .15,
				ampSustain: .5,
				ampRelease: .04,
				level: .7
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 35,
				lmfGain: -2.5,
				lmfFreq: 300,
				lmfQ: 1,
				hmfGain: 3.5,
				hmfFreq: 1500,
				hmfQ: 1.5,
				lpf: 11e3
			}
		},
		fm: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .35,
				brightness: 1,
				velocity: .7,
				lfoRate: 5.5,
				lfoDepth: .12,
				level: .55,
				...P([
					1,
					0,
					.9,
					.005,
					.8,
					.6,
					.25
				], [
					1,
					0,
					.55,
					.02,
					.4,
					.35,
					.2
				], [
					1,
					9,
					.8,
					.005,
					.8,
					.6,
					.25
				], [
					3,
					0,
					.25,
					.003,
					.25,
					.1,
					.15
				], [
					2,
					-6,
					.35,
					.005,
					.6,
					.4,
					.25
				], [
					1,
					0,
					.35,
					.003,
					.3,
					.15,
					.15
				])
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 2,
				midFreq: 1,
				midGain: 3,
				hfGain: 2,
				drive: 10,
				output: 12
			}
		},
		echo: {
			type: "delay",
			params: {
				time: N(126),
				feedback: .38,
				mix: .28
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2.2,
				mix: .22
			}
		},
		drums: {
			type: "boom",
			params: {
				kickTune: 48,
				kickDecay: .4,
				snareTone: .6,
				snappy: .75,
				hatDecay: .05,
				level: .85
			},
			lanes: {
				kick: "x...x...x...x...",
				snare: "....x.......x...",
				clap: "....x.......x...",
				rim: "...x.....x...x..",
				hat: "x.x.x.x.x.x.x.x.",
				bell: "..x..x....x..x.."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 4,
				attack: .003,
				release: .15,
				color: 2,
				fierce: 1,
				detectorHp: 1,
				output: 8
			}
		},
		sum: {
			type: "mixer",
			params: {
				a: .8,
				b: .8,
				c: .42
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 1,
				attack: 4,
				release: 1,
				scHpf: 2,
				output: 3
			}
		},
		main: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...L("seq", "bass"),
		...L("hook", "fm"),
		...ye(["drums", "talon"], [
			"fm",
			"brit",
			"echo",
			"space"
		], ["bass", "console"])
	]);
}
// src/trapPresets.ts
var xe = (e, t, n) => ({
	performance: {
		type: "performance",
		steps: e
	},
	oscillator: {
		type: "oscillator",
		params: {
			wave: n.wave,
			octave: n.octave,
			level: 1
		}
	},
	filter: {
		type: "filter",
		params: {
			cutoff: n.cutoff,
			resonance: n.resonance
		}
	},
	amplifier: {
		type: "amplifier",
		params: { level: .8 }
	},
	envelope: {
		type: "envelope",
		params: {
			attack: n.attack,
			decay: n.decay,
			sustain: n.sustain,
			release: n.release
		}
	},
	delay: {
		type: "delay",
		params: {
			time: N(t),
			feedback: .38,
			mix: n.echo
		}
	},
	space: {
		type: "reverb",
		params: {
			decay: 2.6,
			mix: n.space
		}
	}
}), Se = [
	[
		"oscillator",
		"out",
		"filter",
		"in"
	],
	[
		"filter",
		"out",
		"amplifier",
		"in"
	],
	[
		"amplifier",
		"out",
		"delay",
		"in"
	],
	[
		"delay",
		"out",
		"space",
		"in"
	],
	[
		"performance",
		"pitch",
		"oscillator",
		"pitch"
	],
	[
		"performance",
		"gate",
		"envelope",
		"gate"
	],
	[
		"envelope",
		"out",
		"amplifier",
		"cv",
		1
	]
], Ce = (e) => ({
	type: "monarch",
	params: {
		osc1Wave: 0,
		osc1Octave: 0,
		osc1Level: .9,
		osc2Wave: 1,
		osc2Octave: 1,
		osc2Detune: 0,
		osc2Level: .08,
		osc3Level: 0,
		cutoff: 700,
		resonance: 0,
		drive: .45,
		envAmount: .1,
		tracking: .3,
		ampAttack: .003,
		ampDecay: 1.2,
		ampSustain: .7,
		ampRelease: .9,
		glide: .06,
		level: .4,
		...e
	}
}), we = (e, t, n = {}) => ({
	type: "skitter",
	lanes: e,
	params: {
		...n,
		...Object.fromEntries(Object.entries(t).flatMap(([e, t]) => Object.entries(t).map(([t, n]) => [`${e}Roll${t}`, fe(n)])))
	}
}), Te = (e, t) => ({
	type: "boom",
	lanes: e,
	params: {
		kickTune: 49,
		kickDecay: .55,
		snareTone: .35,
		snappy: .55,
		hatDecay: .045,
		openDecay: .35,
		level: .85,
		...t
	}
}), Ee = {
	cohere: {
		type: "cohere",
		params: {
			threshold: -18,
			ratio: 1,
			attack: 4,
			release: 4,
			scHpf: 2,
			output: 4
		}
	},
	output: {
		type: "output",
		params: { volume: .7 }
	}
};
function De(e) {
	return e === "High Dive" ? I(e, 76, 0, {
		...xe(j("X.x.x..x..x.x...", [
			76,
			76,
			74,
			74,
			72,
			72,
			72,
			69,
			69,
			69,
			72,
			72,
			76,
			76,
			76,
			76
		], [
			.6,
			.6,
			.6,
			.6,
			.8,
			.8,
			.8,
			.9,
			.9,
			.9,
			.6,
			.6,
			.9,
			.9,
			.9,
			.9
		]), 76, {
			wave: 1,
			octave: 0,
			cutoff: 2600,
			resonance: 2,
			attack: .002,
			decay: .5,
			sustain: .15,
			release: .45,
			echo: .3,
			space: .35
		}),
		chords: {
			type: "performance",
			steps: j("X.......X.......", M([60, 8], [53, 8]), .95)
		},
		aurora: {
			type: "aurora",
			params: {
				osc1Wave: 0,
				osc2Wave: 2,
				osc2Detune: 4,
				blend: .45,
				hpf: 220,
				cutoff: 1800,
				resonance: .1,
				envAmount: .15,
				filterAttack: .2,
				filterDecay: 1.4,
				filterSustain: .5,
				ampAttack: .25,
				ampDecay: 1.2,
				ampSustain: .75,
				ampRelease: 1.8,
				lfoRate: .3,
				lfoPitch: 0,
				lfoWidth: .2,
				chord: 1,
				vintage: .3,
				level: .5
			}
		},
		bass: {
			type: "performance",
			steps: j("X.....x...X.....", M([33, 8], [29, 8]), [
				.95,
				.6,
				.6,
				.6,
				.6,
				.6,
				.7,
				.6,
				.6,
				.6,
				.95,
				.6,
				.6,
				.6,
				.6,
				.6
			])
		},
		monarch: Ce({ level: .32 }),
		skitter: we({
			hat: "x.x.x.x.x.x.xx.x",
			open: "..............x."
		}, { hat: { 2: "............xx.x" } }),
		boom: Te({
			kick: "x.....x...x.....",
			snare: "....x.......x...",
			clap: "....x.......x..."
		}, {
			kickDecay: .45,
			snareTone: .5,
			snappy: .7
		}),
		console: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2.5,
				lfFreq: 60,
				lfBell: 1,
				lmfGain: -3.5,
				lmfFreq: 400,
				lmfQ: 1.4,
				hmfGain: 3,
				hmfFreq: 4e3,
				hfGain: 1.5,
				hfFreq: 1e4
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: .9,
				c: .95,
				d: .8
			}
		},
		valve: {
			type: "compressor",
			params: {
				input: 0,
				threshold: -20,
				time: 2,
				output: 3
			}
		},
		output: Ee.output
	}, [
		...Se,
		...L("chords", "aurora"),
		...L("bass", "monarch"),
		[
			"skitter",
			"trig",
			"boom",
			"trig"
		],
		...he([
			["boom", "console"],
			["monarch"],
			["space"],
			["aurora"]
		], "mixer", "valve", "output")
	]) : e === "Deep End" ? I(e, 64, .04, {
		performance: {
			type: "performance",
			steps: j("..X.......x.x...", M([74, 10], [75, 2], [74, 4]), [
				.9,
				.9,
				.95,
				.9,
				.9,
				.9,
				.9,
				.9,
				.9,
				.9,
				.9,
				.9,
				.95,
				.9,
				.9,
				.9
			])
		},
		lead: {
			type: "monarch",
			params: {
				osc1Wave: 0,
				osc1Octave: 0,
				osc1Level: .8,
				osc2Wave: 1,
				osc2Octave: 0,
				osc2Detune: 7,
				osc2Level: .25,
				osc3Level: 0,
				cutoff: 2800,
				resonance: 0,
				drive: 0,
				envAmount: 0,
				tracking: .5,
				ampAttack: .012,
				ampDecay: 1.2,
				ampSustain: .4,
				ampRelease: 1.4,
				glide: .18,
				level: .75
			}
		},
		delay: {
			type: "delay",
			params: {
				time: N(64),
				feedback: .45,
				mix: .32
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 3,
				mix: .42
			}
		},
		bass: {
			type: "performance",
			steps: j("X.........x...x.", M([31, 10], [27, 4], [30, 2]), [
				.95,
				.6,
				.6,
				.6,
				.6,
				.6,
				.6,
				.6,
				.6,
				.6,
				.95,
				.6,
				.6,
				.6,
				.7,
				.6
			])
		},
		monarch: Ce({
			drive: .55,
			glide: .08,
			ampDecay: 1.6,
			ampRelease: 1.4,
			level: .3
		}),
		skitter: we({
			hat: "x.x.x.x.x.x.x.xx",
			perc: "...........x...."
		}, { hat: {
			2: "...............x",
			3: "......x.........",
			4: "..........x.....",
			6: "..............x."
		} }, { rollFade: .4 }),
		boom: Te({
			kick: "x.........x.....",
			snare: "....x.......x...",
			clap: "....x.......x..."
		}, {
			kickDecay: .6,
			snareTone: .25,
			snappy: .45
		}),
		console: {
			type: "equalizer",
			params: {
				hpf: 35,
				lfGain: 2.5,
				lfFreq: 55,
				lfBell: 1,
				lmfGain: -3.5,
				lmfFreq: 350,
				lmfQ: 1.2,
				hmfGain: 2.5,
				hmfFreq: 3500,
				lpf: 12e3
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: .8,
				c: 1
			}
		},
		valve: {
			type: "compressor",
			params: {
				input: 0,
				threshold: -20,
				time: 2,
				output: 3
			}
		},
		output: Ee.output
	}, [
		...L("performance", "lead"),
		...L("bass", "monarch"),
		[
			"skitter",
			"trig",
			"boom",
			"trig"
		],
		...he([
			["boom", "console"],
			["monarch"],
			[
				"lead",
				"delay",
				"space"
			]
		], "mixer", "valve", "output")
	]) : I(e, 72, .05, {
		...xe(j("X...x.x.X...x...", M([71, 4], [67, 2], [69, 2], [71, 4], [74, 4]), .9), 72, {
			wave: 0,
			octave: 0,
			cutoff: 3200,
			resonance: 1,
			attack: .02,
			decay: .8,
			sustain: .5,
			release: .6,
			echo: .25,
			space: .4
		}),
		chords: {
			type: "performance",
			steps: j("X.....x.X.....x.", M([55, 8], [48, 8]), [
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.7,
				.5,
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.7,
				.5
			])
		},
		oracle: {
			type: "oracle",
			params: {
				aShape: 0,
				aLevel: .6,
				bShape: 1,
				bFine: 4,
				bLevel: .7,
				cutoff: 2600,
				resonance: .1,
				envAmount: .35,
				tracking: .5,
				filterAttack: .002,
				filterDecay: .35,
				filterSustain: .1,
				ampAttack: .003,
				ampDecay: .9,
				ampSustain: .15,
				ampRelease: .8,
				vintage: .35,
				chord: 3,
				level: .75
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 120,
				lmfGain: -3,
				lmfFreq: 300,
				lmfQ: 1.2,
				hmfGain: 2,
				hmfFreq: 2500,
				hmfQ: .8,
				hfGain: 2.5,
				hfFreq: 1e4
			}
		},
		bass: {
			type: "performance",
			steps: j("X.......X.......", M([31, 8], [36, 8]), .5)
		},
		monarch: Ce({
			ampRelease: .6,
			level: .32
		}),
		skitter: we({
			hat: "x.xxx.x.x.xxx.x.",
			open: ".......x........",
			synth: "x......x..x...x."
		}, {
			hat: { 3: "...x.......x...." },
			synth: { 2: "..............x." }
		}, { gate: .7 }),
		boom: Te({
			kick: "x......x..x.....",
			snare: "....x.......x..."
		}, {
			kickDecay: .5,
			snareTone: .3,
			snappy: .5
		}),
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: .9,
				c: .8,
				d: .9
			}
		},
		...Ee
	}, [
		...Se,
		...L("chords", "oracle"),
		[
			"bass",
			"pitch",
			"monarch",
			"pitch"
		],
		[
			"skitter",
			"trig",
			"boom",
			"trig"
		],
		[
			"skitter",
			"gate",
			"monarch",
			"gate"
		],
		...he([
			["boom"],
			["monarch"],
			["space"],
			["oracle", "console"]
		], "mixer", "cohere", "output")
	]);
}
// src/industrialPresets.ts
var Oe = (e, t, n, r, i, a) => ({
	[`riff${e}`]: {
		type: "performance",
		steps: t,
		params: { lag: n }
	},
	[`gtr${e}`]: {
		type: "monarch",
		params: r
	},
	[`fuzz${e}`]: {
		type: "rust",
		params: i
	},
	[`eq${e}`]: {
		type: "equalizer",
		params: a
	}
});
function ke(e) {
	if (e === "Rust Machine") return I(e, 93, .08, {
		seq: {
			type: "performance",
			steps: j("X.xX.xx.X.xX.xxo", [
				29,
				29,
				29,
				41,
				41,
				29,
				32,
				32,
				34,
				34,
				34,
				36,
				36,
				39,
				36,
				32
			], [
				.45,
				.4,
				.35,
				.3,
				.4,
				.35,
				.4,
				.4,
				.45,
				.4,
				.35,
				.4,
				.4,
				.3,
				.35,
				.3
			])
		},
		bass: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Wave: 3,
				osc2Detune: 6,
				osc2Level: .45,
				osc3Wave: 0,
				osc3Octave: -1,
				osc3Level: .4,
				cutoff: 420,
				resonance: .72,
				drive: .4,
				envAmount: .75,
				tracking: .5,
				filterAttack: .002,
				filterDecay: .12,
				filterSustain: .05,
				filterRelease: .06,
				ampAttack: .002,
				ampDecay: .2,
				ampSustain: .6,
				ampRelease: .05,
				level: .7
			}
		},
		fuzz: {
			type: "rust",
			params: {
				mode: 0,
				drive: .35,
				bias: .15,
				body: 160,
				tone: .5,
				mix: .4,
				level: .6
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 32,
				lfGain: 2,
				lfFreq: 80,
				lmfGain: -3,
				lmfFreq: 280,
				lmfQ: 1.2,
				hmfGain: 3,
				hmfFreq: 1400,
				hmfQ: 1.4,
				lpf: 9e3
			}
		},
		chops: {
			type: "performance",
			steps: j("..x..X..x..x.X..", M([53, 8], [58, 8]), .25)
		},
		guitar: {
			type: "oracle",
			params: {
				aShape: 1,
				aWidth: .3,
				bShape: 2,
				bFine: 4,
				bLevel: .5,
				cutoff: 3400,
				resonance: .1,
				envAmount: .3,
				filterDecay: .1,
				filterSustain: 0,
				ampAttack: .002,
				ampDecay: .12,
				ampSustain: 0,
				ampRelease: .06,
				chord: 2,
				vintage: .25,
				level: .9
			}
		},
		guitarEq: {
			type: "equalizer",
			params: {
				hpf: 250,
				lmfGain: -3,
				lmfFreq: 500,
				lmfQ: 1.2,
				hmfGain: 3,
				hmfFreq: 2500,
				hmfQ: 1,
				hfGain: 2,
				hfFreq: 9e3,
				output: 2
			}
		},
		echo: {
			type: "delay",
			params: {
				time: N(93),
				feedback: .25,
				mix: .18
			}
		},
		pad: {
			type: "performance",
			steps: j("X.......X.......", M([53, 8], [46, 8]), .95)
		},
		aurora: {
			type: "aurora",
			params: {
				osc1Wave: 0,
				osc2Wave: 1,
				osc2Detune: 9,
				blend: .45,
				hpf: 150,
				cutoff: 900,
				resonance: .15,
				envAmount: .1,
				filterAttack: .4,
				filterDecay: 1.6,
				filterSustain: .6,
				ampAttack: .6,
				ampDecay: 1.5,
				ampSustain: .8,
				ampRelease: 2.4,
				lfoRate: .2,
				lfoWidth: .25,
				lfoFilter: .05,
				chord: 4,
				vintage: .5,
				level: .65
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2.6,
				mix: .4
			}
		},
		lead: {
			type: "performance",
			steps: j("X.......x...x...", M([53, 8], [51, 4], [48, 4]), .9)
		},
		power: {
			type: "monarch",
			params: {
				osc1Level: .7,
				osc2Detune: 12,
				osc2Level: .6,
				osc3Wave: 3,
				osc3Octave: -1,
				osc3Level: .4,
				cutoff: 1800,
				resonance: .2,
				drive: .6,
				envAmount: .2,
				filterDecay: .4,
				filterSustain: .6,
				ampAttack: .01,
				ampDecay: .4,
				ampSustain: .8,
				ampRelease: .2,
				glide: .03,
				level: .45
			}
		},
		grind: {
			type: "rust",
			params: {
				mode: 1,
				drive: .6,
				bias: .2,
				starve: .2,
				body: 700,
				tone: .5,
				mix: .85,
				level: .4
			}
		},
		forge: {
			type: "forge",
			params: {
				level: .9,
				drive: .25,
				room: .08,
				kickLevel: 1,
				kickDecay: .4,
				snareLevel: .9,
				snareDecay: .3,
				snareTone: .6,
				snareLag: 8,
				hatLevel: .45,
				hatDecay: .05,
				hatPan: .2,
				hatLag: -3,
				openLevel: .4,
				openPan: .2,
				openLag: -3,
				anvilLevel: .3,
				anvilPan: -.4
			},
			lanes: {
				kick: "x.....x...x..x..",
				snare: "....x.......x...",
				hat: "xxxxxxxxxxx.xxxx",
				open: "...........x....",
				anvil: "..............x."
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: .6,
				c: 1,
				d: 1,
				e: .55
			}
		},
		valve: {
			type: "compressor",
			params: {
				input: 1,
				threshold: -18,
				time: 1,
				output: 1
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...L("seq", "bass"),
		...L("chops", "guitar"),
		...L("pad", "aurora"),
		...L("lead", "power"),
		...he([
			["forge"],
			[
				"bass",
				"fuzz",
				"bassEq"
			],
			[
				"guitar",
				"guitarEq",
				"echo"
			],
			["aurora", "space"],
			["power", "grind"]
		], "mixer", "valve", "output")
	]);
	if (e === "Black Mass") {
		let t = j("X.....oxX..xX.x.", [
			37,
			37,
			37,
			37,
			37,
			37,
			37,
			40,
			43,
			43,
			43,
			42,
			38,
			38,
			36,
			36
		], [
			.95,
			.5,
			.5,
			.5,
			.5,
			.5,
			.4,
			.6,
			.95,
			.5,
			.5,
			.6,
			.95,
			.5,
			.8,
			.5
		]), n = {
			osc1Wave: 2,
			osc1Level: .8,
			osc2Wave: 2,
			osc2Level: .6,
			osc3Octave: -1,
			osc3Level: .45,
			cutoff: 1500,
			resonance: .08,
			drive: .7,
			envAmount: .2,
			filterAttack: .003,
			filterDecay: .5,
			filterSustain: .5,
			filterRelease: .6,
			ampAttack: .004,
			ampDecay: .8,
			ampSustain: .7,
			ampRelease: 1.1,
			glide: .04,
			level: .6
		};
		return I(e, 76, .04, {
			...Oe("L", t, 6, {
				...n,
				osc2Detune: -8,
				osc3Wave: 3
			}, {
				mode: 0,
				drive: .8,
				bias: .25,
				starve: .15,
				body: 200,
				tone: .36,
				mix: 1,
				level: .55
			}, {
				hpf: 105,
				lfGain: 1.5,
				lfFreq: 170,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 420,
				lmfQ: 1.2,
				hmfGain: 3.5,
				hmfFreq: 1600,
				hmfQ: 1.1,
				lpf: 6500
			}),
			...Oe("R", t, 14, {
				...n,
				osc1Detune: -4,
				osc2Wave: 3,
				osc2Detune: 11,
				osc3Wave: 2,
				cutoff: 1350,
				drive: .75,
				glide: .05
			}, {
				mode: 0,
				drive: .78,
				bias: .4,
				starve: .12,
				body: 320,
				tone: .33,
				mix: 1,
				level: .55
			}, {
				hpf: 110,
				lfGain: 1.5,
				lfFreq: 150,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 360,
				lmfQ: 1.2,
				hmfGain: 3.5,
				hmfFreq: 2200,
				hmfQ: 1.1,
				lpf: 6e3
			}),
			sub: {
				type: "monarch",
				params: {
					osc1Wave: 0,
					osc1Level: .9,
					osc2Wave: 1,
					osc2Octave: 1,
					osc2Detune: 0,
					osc2Level: .1,
					osc3Level: 0,
					cutoff: 600,
					resonance: 0,
					drive: .5,
					envAmount: .1,
					tracking: .3,
					ampAttack: .004,
					ampDecay: 1.4,
					ampSustain: .75,
					ampRelease: 1,
					glide: .05,
					level: .45
				}
			},
			lead: {
				type: "performance",
				steps: j("....X.......x.x.", M([68, 12], [69, 2], [67, 2]), .95)
			},
			voice: {
				type: "monarch",
				params: {
					osc1Wave: 0,
					osc1Level: .8,
					osc2Wave: 2,
					osc2Detune: 7,
					osc2Level: .15,
					osc3Level: 0,
					cutoff: 1800,
					resonance: 0,
					drive: 0,
					envAmount: 0,
					tracking: .5,
					ampAttack: .03,
					ampDecay: 1.4,
					ampSustain: .45,
					ampRelease: 1.8,
					glide: .22,
					level: 1
				}
			},
			echo: {
				type: "delay",
				params: {
					time: N(76),
					feedback: .5,
					mix: .32
				}
			},
			space: {
				type: "reverb",
				params: {
					decay: 3,
					mix: .45
				}
			},
			echoR: {
				type: "delay",
				params: {
					time: Number((60 / 76).toFixed(3)),
					feedback: .42,
					mix: 1
				}
			},
			boom: {
				type: "boom",
				lanes: {
					kick: "x.......x.x....x",
					snare: "....x.......x...",
					clap: "....x.......x..."
				},
				params: {
					kickTune: 44,
					kickDecay: .7,
					kickLevel: 1.6,
					snareTune: -5,
					snareDecay: .45,
					snareTone: .6,
					snappy: .9,
					snareLevel: 1.6,
					snarePan: .1,
					snareLag: 12,
					clapTone: .55,
					clapDecay: .45,
					clapLevel: 1.4,
					clapPan: -.1,
					clapLag: 17,
					level: 1
				}
			},
			forge: {
				type: "forge",
				params: {
					level: 1,
					drive: .55,
					room: .5,
					kickTune: -1,
					kickDecay: .6,
					kickTone: .7,
					kickLevel: 1.6,
					snareTune: -4,
					snareDecay: .9,
					snareTone: .85,
					snareLevel: 1.6,
					snareLag: 12,
					hatLevel: .35,
					hatDecay: .06,
					hatTone: .4,
					hatPan: .3,
					hatLag: -6,
					lowTomTune: -5,
					lowTomDecay: 1.2,
					lowTomLevel: 1.3,
					lowTomPan: .4,
					lowTomLag: 8,
					anvilTune: -10,
					anvilDecay: 2.5,
					anvilTone: .35,
					anvilLevel: .35,
					anvilPan: -.55,
					anvilLag: 20
				},
				lanes: {
					kick: "x.......x.x....x",
					snare: "....x.......x...",
					hat: "x.xxx.xxx.xxx.xx",
					lowTom: "......x.......x.",
					anvil: "...........x...."
				}
			},
			drumComp: {
				type: "talon",
				params: {
					input: 4,
					ratio: 4,
					attack: .01,
					release: .15,
					color: 2,
					detectorHp: 1,
					output: 7.5
				}
			},
			drumEq: {
				type: "equalizer",
				params: {
					hpf: 30,
					lfGain: 3.5,
					lfFreq: 68,
					lfBell: 1,
					lmfGain: -4.5,
					lmfFreq: 380,
					lmfQ: 1.4,
					hmfGain: 5.5,
					hmfFreq: 3400,
					hmfQ: .9,
					lpf: 13e3
				}
			},
			mixer: {
				type: "mixer",
				params: {
					a: 1,
					b: .72,
					c: .72,
					d: .6,
					e: 1,
					f: .75,
					aPan: 0,
					bPan: -.9,
					cPan: .9,
					dPan: 0,
					ePan: -.15,
					fPan: .75
				}
			},
			valve: {
				type: "compressor",
				params: {
					input: 0,
					threshold: -18,
					time: 2,
					output: -2.5
				}
			},
			output: {
				type: "output",
				params: { volume: .7 }
			}
		}, [
			...L("riffL", "gtrL"),
			...L("riffR", "gtrR"),
			...L("riffL", "sub", 2),
			...L("lead", "voice"),
			[
				"voice",
				"out2",
				"echoR",
				"in"
			],
			[
				"boom",
				"out",
				"forge",
				"chain"
			],
			...he([
				[
					"forge",
					"drumComp",
					"drumEq"
				],
				[
					"gtrL",
					"fuzzL",
					"eqL"
				],
				[
					"gtrR",
					"fuzzR",
					"eqR"
				],
				["sub"],
				[
					"voice",
					"echo",
					"space"
				],
				["echoR"]
			], "mixer", "valve", "output")
		]);
	}
	let t = (e, ...t) => [
		[
			0,
			3,
			120
		],
		[
			3,
			1,
			96
		],
		[
			6,
			1,
			100
		],
		[
			7,
			3,
			116
		],
		[
			10,
			2,
			104
		],
		[
			12,
			2,
			100
		],
		[
			14,
			2,
			108
		]
	].map(([n, r, i], a) => [
		e * 16 + n,
		r,
		t[a],
		i
	]), n = [
		41,
		44,
		48,
		46,
		44,
		43,
		44
	], r = (e, t, ...n) => n.map((n) => [
		e,
		t,
		n,
		100
	]);
	return I(e, 92, .12, {
		tune: {
			type: "dictator",
			params: { length: 2 },
			notes: pe(...t(0, ...n), ...t(1, 37, 49, 48, 44, 41, 39, 41), ...t(2, ...n), ...t(3, 39, 46, 49, 48, 46, 43, 40))
		},
		bass: {
			type: "monarch",
			params: {
				osc1Wave: 2,
				osc1Level: .75,
				osc2Wave: 3,
				osc2Detune: 5,
				osc2Level: .35,
				osc3Wave: 0,
				osc3Octave: -1,
				osc3Level: .35,
				cutoff: 750,
				resonance: .3,
				drive: .35,
				envAmount: .45,
				tracking: .6,
				filterAttack: .002,
				filterDecay: .3,
				filterSustain: .3,
				filterRelease: .12,
				ampAttack: .003,
				ampDecay: .5,
				ampSustain: .8,
				ampRelease: .07,
				glide: .006,
				level: .75
			}
		},
		fuzz: {
			type: "rust",
			params: {
				mode: 0,
				drive: .4,
				bias: .2,
				body: 700,
				tone: .5,
				mix: .35,
				level: .6
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 35,
				lfGain: 1.5,
				lfFreq: 80,
				lfBell: 1,
				lmfGain: -6,
				lmfFreq: 250,
				lmfQ: .8,
				hmfGain: 5,
				hmfFreq: 1300,
				hmfQ: 1.1,
				lpf: 7e3
			}
		},
		chords: {
			type: "dictator",
			params: { length: 2 },
			notes: pe(...r(0, 16, 65, 68, 72), ...r(16, 16, 65, 68, 73), ...r(32, 16, 65, 68, 72), ...r(48, 12, 63, 67, 70), ...r(60, 4, 64, 67, 72))
		},
		pad: {
			type: "aurora",
			params: {
				osc1Wave: 0,
				osc2Wave: 1,
				osc2Width: .35,
				osc2Detune: 9,
				blend: .5,
				hpf: 220,
				cutoff: 2e3,
				resonance: .1,
				slope: 1,
				envAmount: .2,
				filterAttack: .05,
				filterDecay: 1.2,
				filterSustain: .5,
				filterRelease: 1.2,
				ampAttack: .06,
				ampDecay: 1.5,
				ampSustain: .7,
				ampRelease: 1.4,
				lfoRate: .4,
				lfoWidth: .25,
				vintage: .3,
				level: .8
			}
		},
		padEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lmfGain: -3,
				lmfFreq: 450,
				lmfQ: 1,
				hmfGain: 3,
				hmfFreq: 2800,
				hmfQ: 1,
				lpf: 8e3
			}
		},
		hall: {
			type: "reverb",
			params: {
				decay: 2.6,
				mix: .4
			}
		},
		answer: {
			type: "dictator",
			params: {
				length: 2,
				lag: 6
			},
			notes: pe([
				8,
				2,
				72,
				96
			], [
				11,
				4,
				75,
				104
			], [
				24,
				2,
				72,
				96
			], [
				27,
				4,
				77,
				104
			], [
				40,
				2,
				72,
				96
			], [
				43,
				4,
				79,
				108
			], [
				56,
				2,
				70,
				96
			], [
				59,
				4,
				67,
				100
			])
		},
		keys: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .05,
				brightness: 1.1,
				velocity: .5,
				lfoRate: 4.5,
				lfoDepth: .02,
				level: 1,
				...F.epiano
			}
		},
		keysEq: {
			type: "equalizer",
			params: {
				output: 8,
				hpf: 300,
				lmfGain: -2,
				lmfFreq: 500,
				lmfQ: 1,
				hmfGain: 3,
				hmfFreq: 3e3,
				hmfQ: .9,
				lpf: 12e3
			}
		},
		echo: {
			type: "delay",
			params: {
				time: N(92),
				feedback: .42,
				mix: .35
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 3,
				mix: .4
			}
		},
		echoR: {
			type: "delay",
			params: {
				time: Number((60 / 92).toFixed(3)),
				feedback: .38,
				mix: 1
			}
		},
		boom: {
			type: "boom",
			lanes: {
				kick: "x......x..x...x.",
				snare: "....x.......x...",
				clap: "....x.......x...",
				rim: "......x........x"
			},
			params: {
				kickTune: 44,
				kickDecay: .5,
				kickLevel: 1.4,
				snareTune: -2,
				snareDecay: .35,
				snareTone: .65,
				snappy: .9,
				snareLevel: 1.5,
				snarePan: .1,
				snareLag: 14,
				clapTone: .6,
				clapDecay: .35,
				clapLevel: 1.4,
				clapPan: -.12,
				clapLag: 19,
				rimLevel: .5,
				rimPan: -.5,
				rimLag: 10,
				level: 1
			}
		},
		forge: {
			type: "forge",
			params: {
				level: 1,
				drive: .4,
				room: .3,
				kickTune: 0,
				kickDecay: .5,
				kickTone: .7,
				kickLevel: 1.6,
				snareTune: -1,
				snareDecay: .6,
				snareTone: .8,
				snareLevel: 1.6,
				snareLag: 14,
				hatLevel: .45,
				hatDecay: .05,
				hatTone: .5,
				hatPan: .4,
				hatLag: -6
			},
			lanes: {
				kick: "x......x..x...x.",
				snare: "....x.......x...",
				hat: "x.x.x.xxx.x.x.xx"
			}
		},
		drumComp: {
			type: "talon",
			params: {
				input: 4,
				ratio: 3,
				attack: .008,
				release: .12,
				color: 1,
				fierce: 1,
				detectorHp: 1,
				output: 7.5
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2.5,
				lfFreq: 70,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 400,
				lmfQ: 1.4,
				hmfGain: 5,
				hmfFreq: 3800,
				hmfQ: .9,
				lpf: 14e3
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: .85,
				c: .85,
				d: 1,
				e: .8,
				aPan: 0,
				bPan: 0,
				cPan: 0,
				dPan: -.35,
				ePan: .7
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 0,
				attack: 4,
				release: 4,
				scHpf: 2,
				output: 1.5
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...L("tune", "bass"),
		...L("chords", "pad"),
		...L("answer", "keys"),
		[
			"keysEq",
			"out2",
			"echoR",
			"in"
		],
		[
			"boom",
			"out",
			"forge",
			"chain"
		],
		...he([
			[
				"forge",
				"drumComp",
				"drumEq"
			],
			[
				"bass",
				"fuzz",
				"bassEq"
			],
			[
				"pad",
				"padEq",
				"hall"
			],
			[
				"keys",
				"keysEq",
				"echo",
				"space"
			],
			["echoR"]
		], "mixer", "cohere", "output")
	]);
}
// src/model.ts
var B = (e, t, n, r, i, a = .01, o, s = !1) => ({
	id: e,
	label: t,
	min: n,
	max: r,
	initial: i,
	step: a,
	unit: o,
	logarithmic: s
}), V = (e, t, n, r) => ({
	id: e,
	label: t,
	choices: n,
	initial: r,
	min: 0,
	max: n.length - 1,
	step: 1
}), H = (e, t, n = "audio", r) => ({
	id: e,
	label: t,
	kind: n,
	direction: "in",
	scale: r
}), U = (e, t, n = "audio") => ({
	id: e,
	label: t,
	kind: n,
	direction: "out"
}), W = (e, t = 2) => Array.from({ length: t }, (t, n) => n ? {
	...e,
	id: `${e.id}${n + 1}`,
	copyOf: e.id
} : e), G = (e) => ({
	...e,
	legacyDefault: e.initial
}), Ae = (e) => ({
	...G(B(e, "Lag", -50, 50, 0, 1, "ms")),
	hint: "Plays these notes up to 50 ms late, or early when negative, to push or pull the part against the beat. You hear it against the click or the other parts, not on its own. Double-click puts it back on the beat."
}), je = (e, t) => ({
	...e,
	hint: t
}), Me = ["filterModel", "engine"], Ne = (e) => G(V(e, "Engine", ["Digital", "Analog"], 1)), K = (e, t) => ({
	id: `${e}Pattern`,
	label: "Pattern",
	min: 0,
	max: 65535,
	step: 1,
	initial: [...t].reduce((e, t, n) => t === "x" ? e | 1 << n : e, 0),
	pattern: !0,
	voice: e
}), Pe = (e, t, n, r, i) => [
	{
		...B(`${e}Steps`, `${t} steps`, 1, 16, n, 1),
		voice: e
	},
	{
		...B(`${e}Hits`, `${t} hits`, 0, 16, r, 1),
		voice: e
	},
	{
		...B(`${e}Shift`, `${t} shift`, 0, 15, i, 1),
		voice: e
	}
], Fe = [
	"Skin",
	"Wood",
	"Sand",
	"Metal",
	"Shaker",
	"Tom"
].map((e) => ({
	id: e.toLowerCase(),
	label: e
})), Ie = ({ id: e, label: t }, n) => {
	let [r, i, a] = [
		[
			16,
			5,
			2
		],
		[
			8,
			3,
			0
		],
		[
			12,
			8,
			0
		],
		[
			16,
			0,
			0
		],
		[
			16,
			0,
			0
		],
		[
			16,
			0,
			0
		]
	][n], o = (t) => ({
		...G(t),
		voice: e
	});
	return [
		...Pe(e, t, r, i, a).map((e) => n > 2 ? o(e) : e),
		o(B(`${e}Tune`, `${t} tune`, -24, 24, 0, 1, "st")),
		o(B(`${e}Decay`, `${t} decay`, .02, 2, [
			.32,
			.07,
			.07,
			.5,
			.12,
			.4
		][n], .01, "s", !0)),
		o(B(`${e}Tone`, `${t} tone`, 0, 1, .5)),
		o(B(`${e}Level`, `${t} level`, 0, 2, 1)),
		o(B(`${e}Pan`, `${t} pan`, -1, 1, 0)),
		o({
			...Ae(`${e}Lag`),
			label: `${t} lag`
		}),
		o(V(`${e}Custom`, `${t} rhythm`, ["Euclidean", "Custom"], 0)),
		o(K(e, "................"))
	];
}, Le = (e, t) => [
	B(`${e}Attack`, "Attack", .002, 2, .008, .001, "s", !0),
	B(`${e}Decay`, "Decay", .01, 3, .25, .01, "s", !0),
	B(`${e}Sustain`, "Sustain", 0, 1, e === "amp" ? .65 : .2),
	B(`${e}Release`, "Release", .01, 4, .2, .01, "s", !0)
].map((e) => ({
	...e,
	group: t
})), Re = [
	H("chain", "Chain in"),
	H("trig", "Trig in", "gate"),
	...W(U("out", "Drums out"))
], q = (e, t) => t.map((t) => ({
	...t,
	group: e
})), ze = [
	["Off", [0]],
	["Maj 7", [
		0,
		4,
		7,
		11
	]],
	["Min 7", [
		0,
		3,
		7,
		10
	]],
	["Maj 9", [
		0,
		4,
		7,
		11,
		14
	]],
	["Min 9", [
		0,
		3,
		7,
		10,
		14
	]],
	["Min 11", [
		0,
		3,
		10,
		14,
		17
	]],
	["Dom 9", [
		0,
		4,
		7,
		10,
		14
	]]
], Be = [
	["kick", "Kick"],
	["snare", "Snare"],
	["rim", "Sidestick"],
	["clap", "Clap"],
	["hat", "Closed hat"],
	["open", "Open hat"],
	["lowTom", "Low tom"],
	["midTom", "Mid tom"],
	["highTom", "High tom"],
	["lowConga", "Low conga"],
	["highConga", "High conga"],
	["cabasa", "Cabasa"],
	["tambourine", "Tambourine"],
	["bell", "Cowbell"],
	["crash", "Crash"],
	["ride", "Ride"]
].map(([e, t]) => ({
	id: e,
	label: t
})), Ve = [
	"Three pairs",
	"Twin stacks",
	"Serial stack",
	"Shared modulation",
	"Branched",
	"Additive"
], He = [
	"a",
	"b",
	"c",
	"d",
	"e",
	"f",
	"g",
	"h"
], Ue = (e) => `${e}Pan`, We = [
	["kick", "Kick"],
	["snare", "Snare"],
	["clap", "Clap"],
	["hat", "Hat"],
	["open", "Open hat"],
	["perc", "Perc"],
	["synth", "Synth"]
].map(([e, t]) => ({
	id: e,
	label: t
})), Ge = {
	boom: {
		kick: "kick",
		snare: "snare",
		clap: "clap",
		hat: "hat",
		open: "open",
		perc: "rim"
	},
	punch: {
		kick: "kick",
		snare: "snare",
		clap: "clap",
		hat: "hat",
		open: "open"
	},
	strike: {
		kick: "kick",
		snare: "snare",
		clap: "clap",
		hat: "hat",
		open: "open",
		perc: "rim"
	},
	forge: {
		kick: "kick",
		snare: "snare",
		hat: "hat",
		open: "open",
		perc: "anvil"
	},
	orbit: {
		kick: "skin",
		snare: "sand",
		clap: "sand",
		hat: "shaker",
		open: "metal",
		perc: "wood"
	}
}, Ke = [
	["kick", "Kick"],
	["snare", "Snare"],
	["hat", "Closed hat"],
	["pedal", "Pedal hat"],
	["open", "Open hat"],
	["lowTom", "Floor tom"],
	["highTom", "Rack tom"],
	["crash", "Crash"],
	["china", "China"],
	["ride", "Ride"],
	["anvil", "Anvil"]
].map(([e, t]) => ({
	id: e,
	label: t
})), qe = [
	2,
	3,
	4,
	6
], Je = (e, t) => `${e}Roll${t}`, Ye = [
	"Fuzz",
	"Rectify",
	"Fold",
	"Crush",
	"Broken"
], Xe = (e, t) => e.flatMap(({ id: e, label: n }) => [
	B(`${e}Tune`, "Tune", -24, 24, 0, 1, "st"),
	B(`${e}Decay`, "Decay", .03, 4, t(e), .01, "s", !0),
	B(`${e}Tone`, "Tone", 0, 1, .7),
	B(`${e}Level`, "Level", 0, 1.6, .8),
	B(`${e}Pan`, "Pan", -1, 1, 0),
	Ae(`${e}Lag`)
].map((t) => ({
	...t,
	voice: e,
	label: `${n} ${t.label}`
}))), Ze = [
	["kick", "Kick"],
	["snare", "Snare"],
	["rim", "Rim"],
	["clap", "Clap"],
	["hat", "Hat"],
	["open", "Open"],
	["lowTom", "Lo tom"],
	["highTom", "Hi tom"],
	["crash", "Crash"],
	["ride", "Ride"],
	["bell", "Bell"]
].map(([e, t]) => ({
	id: e,
	label: t
})), Qe = [
	["kick", "Kick"],
	["snare", "Snare"],
	["clap", "Clap"],
	["hat", "Hat"],
	["open", "Open"]
].map(([e, t]) => ({
	id: e,
	label: t
})), $e = (e) => e.map(({ id: e, label: t }) => G({
	...B(`${e}Level`, `${t} level`, 0, 2, 1),
	voice: e
})), et = (e, t) => e.flatMap(({ id: e, label: n }) => [
	...t[e],
	G(B(`${e}Pan`, "Pan", -1, 1, 0)),
	Ae(`${e}Lag`)
].map((t) => ({
	...t,
	voice: e,
	label: `${n} ${t.label}`
}))), tt = (e) => G(B(e, "Tune", -12, 12, 0, 1, "st")), nt = (e, t, n, r, i = .01) => B(e, "Decay", t, n, r, i, "s", !0), rt = (e) => G(B(e, "Tone", 0, 1, .5)), J = (e, t) => 2 ** ((e - .5) * t), it = {
	kick: [B("kickTune", "Tune", 30, 90, 49, 1, "Hz"), B("kickDecay", "Decay", .1, 2.5, .8, .01, "s", !0)],
	snare: [
		tt("snareTune"),
		G(nt("snareDecay", .05, 1, .2)),
		B("snareTone", "Tone", 0, 1, .5),
		B("snappy", "Snappy", 0, 1, .6)
	],
	rim: [tt("rimTune"), G(nt("rimDecay", .01, .3, .03, .001))],
	clap: [rt("clapTone"), G(nt("clapDecay", .05, 1.5, .2))],
	hat: [nt("hatDecay", .02, .6, .06), rt("hatTone")],
	open: [G(nt("openDecay", .1, 1.2, .4)), rt("openTone")],
	lowTom: [tt("tomTune"), G(nt("tomDecay", .1, 1.5, .45))],
	highTom: [{
		...tt("highTomTune"),
		legacyFrom: "tomTune"
	}, {
		...G(nt("highTomDecay", .1, 1.5, .45)),
		legacyFrom: "tomDecay"
	}],
	crash: [G(nt("crashDecay", .3, 3, 1.6)), rt("crashTone")],
	ride: [G(nt("rideDecay", .2, 2.5, 1)), rt("rideTone")],
	bell: [B("bellTune", "Tune", -12, 12, 0, 1, "st"), G(nt("bellDecay", .05, 1.5, .32))]
}, at = {
	kick: [
		B("kickTune", "Tune", 40, 90, 55, 1, "Hz"),
		nt("kickDecay", .1, 1.2, .45),
		B("kickClick", "Click", 0, 1, .5)
	],
	snare: [
		tt("snareTune"),
		G(nt("snareDecay", .05, 1, .18)),
		B("snareTone", "Tone", 0, 1, .5),
		B("snappy", "Snappy", 0, 1, .7)
	],
	clap: [rt("clapTone"), G(nt("clapDecay", .05, 1.5, .24))],
	hat: [nt("hatDecay", .02, .3, .05), rt("hatTone")],
	open: [nt("openDecay", .1, 1, .35), rt("openTone")]
}, Y = {
	performance: {
		name: "STEP–16",
		subtitle: "PATTERN & NOTE CONTROLLER",
		color: "performance",
		params: [Ae("lag")],
		ports: [...W(U("pitch", "Pitch · 1V/oct", "cv"), 3), ...W(U("gate", "Note gate", "gate"), 3)]
	},
	dictator: {
		name: "DICTATOR",
		subtitle: "NOTE RECORDER · LOOPING MIDI CLIP",
		color: "dictator",
		params: [
			je(V("length", "Length", _.map((e) => `${e} ${e === 1 ? "bar" : "bars"}`), 2), "How many bars the clip loops. Notes past the end stay in the clip, unheard, until it is long enough to play them again."),
			je(V("quantize", "Quantize", x.map(([e]) => e), 3), "The grid, from quarter notes to 1/32s, that the Quantize button beside it, and AUTO while recording, move note starts onto."),
			je(V("qrec", "Q-Rec", ["Off", "On"], 0), "AUTO quantizes while recording, as Reason’s Q Record does: on, each note you record starts on the Quantize grid; off, it keeps the timing you played, and the Quantize button can tidy it later."),
			je(V("mode", "Record", ["Overdub", "Replace"], 0), "Overdub adds what you play to the clip on every pass round the loop. Replace erases the notes the playhead passes while recording, so a new pass takes the place of the old one."),
			Ae("lag")
		],
		ports: [...W(U("pitch", "Pitch · 1V/oct", "cv"), 3), ...W(U("gate", "Note gate", "gate"), 3)]
	},
	oscillator: {
		name: "SOLID",
		subtitle: "ANALOG OSCILLATOR",
		color: "oscillator",
		params: [
			V("wave", "Waveform", [
				"Sine",
				"Triangle",
				"Saw",
				"Square"
			], 2),
			B("octave", "Octave", -3, 3, 0, 1),
			B("tune", "Tune", -12, 12, 0, 1, "st"),
			B("fine", "Fine", -50, 50, 0, 1, "ct"),
			B("level", "Level", 0, 1, .7)
		],
		ports: [
			H("pitch", "Pitch · 1V/oct", "cv", 1200),
			H("fm", "FM", "cv", 1200),
			...W(U("out", "Audio out"))
		]
	},
	noise: {
		name: "STATIC",
		subtitle: "NOISE GENERATOR",
		color: "noise",
		params: [V("color", "Color", [
			"White",
			"Pink",
			"Brown"
		], 0), B("level", "Level", 0, 1, .4)],
		ports: [...W(U("out", "Audio out"))]
	},
	mixer: {
		name: "SUM",
		subtitle: "EIGHT CHANNEL MIXER",
		color: "mixer",
		params: [
			...He.map((e, t) => {
				let n = B(e, `Channel ${e.toUpperCase()}`, 0, 1, .7);
				return t > 2 ? G(n) : n;
			}),
			...He.map((e) => G(B(Ue(e), `Channel ${e.toUpperCase()} pan`, -1, 1, 0))),
			G(B("master", "Mix bus", 0, 1, 1))
		],
		ports: [...He.map((e) => H(e, `Channel ${e.toUpperCase()}`)), ...W(U("out", "Mix out"))]
	},
	filter: {
		name: "SIEVE",
		subtitle: "MULTIMODE FILTER",
		color: "filter",
		params: [
			V("mode", "Mode", [
				"Low-pass",
				"High-pass",
				"Band-pass"
			], 0),
			B("cutoff", "Cutoff", 40, 18e3, 1400, 1, "Hz", !0),
			B("resonance", "Resonance", .1, 12, 2.5, .1),
			Ne("filterModel")
		],
		ports: [
			H("in", "Audio in"),
			H("cv", "Cutoff CV", "cv", 2400),
			...W(U("out", "Audio out"))
		]
	},
	amplifier: {
		name: "LEVEL",
		subtitle: "VOLTAGE CONTROLLED AMPLIFIER",
		color: "amplifier",
		params: [B("level", "Level", 0, 1, .8)],
		ports: [
			H("in", "Audio in"),
			H("cv", "Amplitude CV", "cv", 1),
			...W(U("out", "Audio out"))
		]
	},
	envelope: {
		name: "CONTOUR",
		subtitle: "ADSR ENVELOPE",
		color: "envelope",
		params: [
			B("attack", "Attack", .002, 2, .01, .001, "s", !0),
			B("decay", "Decay", .01, 3, .2, .01, "s", !0),
			B("sustain", "Sustain", 0, 1, .5),
			B("release", "Release", .01, 4, .18, .01, "s", !0)
		],
		ports: [H("gate", "Note gate", "gate"), ...W(U("out", "Envelope CV", "cv"))]
	},
	lfo: {
		name: "PULSE",
		subtitle: "LOW FREQUENCY OSCILLATOR",
		color: "lfo",
		params: [V("wave", "Waveform", [
			"Sine",
			"Triangle",
			"Saw",
			"Square"
		], 0), B("rate", "Rate", .05, 20, 2, .05, "Hz", !0)],
		ports: [H("cv", "Rate CV", "cv", 5), ...W(U("out", "Modulation CV", "cv"))]
	},
	delay: {
		name: "ECHO",
		subtitle: "FEEDBACK DELAY",
		color: "delay",
		params: [
			B("time", "Time", .02, 1, .28, .01, "s"),
			B("feedback", "Feedback", 0, .85, .32),
			B("mix", "Mix", 0, 1, .22)
		],
		ports: [H("in", "Audio in"), ...W(U("out", "Audio out"))]
	},
	reverb: {
		name: "SPACE",
		subtitle: "STEREO REVERBERATOR",
		color: "reverb",
		params: [B("decay", "Decay", .2, 3, 1.5, .1, "s"), B("mix", "Mix", 0, 1, .25)],
		ports: [H("in", "Audio in"), ...W(U("out", "Audio out"))]
	},
	boom: {
		name: "BOOM",
		subtitle: "ANALOG DRUM MACHINE",
		color: "boom",
		ports: Re,
		drum: {
			mode: "steps",
			voices: Ze
		},
		params: [
			...et(Ze, it),
			B("level", "Level", 0, 1, .8),
			Ne("engine"),
			K("kick", "x......x..x....."),
			K("snare", "....x.......x..."),
			K("hat", "x.x.x.x.x.x.x.x."),
			K("bell", "...........x..x."),
			...[
				"rim",
				"clap",
				"open",
				"lowTom",
				"highTom",
				"crash",
				"ride"
			].map((e) => G(K(e, "................"))),
			...$e(Ze)
		]
	},
	punch: {
		name: "PUNCH",
		subtitle: "DANCE FLOOR DRUM MACHINE",
		color: "punch",
		ports: Re,
		drum: {
			mode: "steps",
			voices: Qe
		},
		params: [
			...et(Qe, at),
			B("level", "Level", 0, 1, .8),
			Ne("engine"),
			K("kick", "x...x...x...x..."),
			K("snare", "............x..x"),
			K("clap", "....x.......x..."),
			K("hat", "xx..xx..xx..xx.."),
			K("open", "..x...x...x...x."),
			...$e(Qe)
		]
	},
	orbit: {
		name: "ORBIT",
		subtitle: "EUCLIDEAN PERCUSSION",
		color: "orbit",
		ports: Re,
		drum: {
			mode: "euclid",
			voices: Fe
		},
		params: [
			B("pitch", "Pitch", -12, 12, 0, 1, "st"),
			B("level", "Level", 0, 1, .7),
			Ne("engine"),
			...Fe.flatMap(Ie)
		]
	},
	monarch: {
		name: "MONARCH",
		subtitle: "VINTAGE MONOSYNTH",
		color: "monarch",
		ports: [
			H("pitch", "Pitch · 1V/oct", "cv", 1200),
			H("gate", "Note gate", "gate"),
			H("cv", "Cutoff CV", "cv", 2400),
			...W(U("out", "Audio out"))
		],
		params: [
			...[
				1,
				2,
				3
			].flatMap((e) => [
				V(`osc${e}Wave`, "Waveform", [
					"Sine",
					"Triangle",
					"Saw",
					"Square"
				], 2),
				B(`osc${e}Octave`, "Octave", -3, 3, e === 3 ? -1 : 0, 1),
				B(`osc${e}Detune`, "Detune", -50, 50, e === 2 ? 7 : 0, 1, "ct"),
				B(`osc${e}Level`, "Level", 0, 1, e === 1 ? .7 : .35)
			].map((t) => ({
				...t,
				group: `Oscillator ${e}`
			}))),
			...[
				Ne("filterModel"),
				B("cutoff", "Cutoff", 40, 18e3, 1100, 1, "Hz", !0),
				B("resonance", "Resonance", 0, 1, .2),
				B("drive", "Drive", 0, 1, .25),
				B("envAmount", "Env amount", -1, 1, .5),
				B("tracking", "Key track", 0, 1, .5)
			].map((e) => ({
				...e,
				group: "Filter"
			})),
			...Le("filter", "Filter envelope"),
			...Le("amp", "Amplifier envelope"),
			...[
				B("noise", "Noise", 0, 1, 0),
				B("glide", "Glide", 0, 1, 0, .01, "s"),
				B("level", "Level", 0, 1, .7)
			].map((e) => ({
				...e,
				group: "Performance"
			}))
		]
	},
	oracle: {
		name: "ORACLE",
		subtitle: "FIVE-VOICE POLYSYNTH",
		color: "oracle",
		ports: [
			H("pitch", "Pitch · 1V/oct", "cv", 1200),
			H("gate", "Note gate", "gate"),
			H("cv", "Cutoff CV", "cv", 2400),
			...W(U("out", "Audio out"))
		],
		params: [
			...q("Poly-Mod", [
				B("polyEnv", "Filt env", 0, 1, 0),
				B("polyOscB", "Osc B", 0, 1, 0),
				V("polyDest", "Dest", [
					"Freq A",
					"Filter",
					"Both"
				], 0)
			]),
			...q("Oscillator A", [
				B("aOctave", "Octave", -2, 2, 0, 1),
				V("aShape", "Shape", [
					"Saw",
					"Pulse",
					"Saw + Pulse"
				], 0),
				B("aWidth", "Width", .05, .95, .5)
			]),
			...q("Oscillator B", [
				B("bOctave", "Octave", -2, 2, 0, 1),
				B("bFine", "Fine", -50, 50, 7, 1, "ct"),
				V("bShape", "Shape", [
					"Saw",
					"Triangle",
					"Pulse"
				], 0),
				B("bWidth", "Width", .05, .95, .5)
			]),
			...q("LFO", [
				B("lfoRate", "Rate", .05, 20, 4, .05, "Hz", !0),
				V("lfoShape", "Shape", [
					"Triangle",
					"Saw",
					"Square"
				], 0),
				B("lfoAmount", "Amount", 0, 1, 0),
				V("lfoDest", "Dest", [
					"Pitch",
					"PW",
					"Filter"
				], 0)
			]),
			...q("Mixer", [
				B("aLevel", "Osc A", 0, 1, .8),
				B("bLevel", "Osc B", 0, 1, .6),
				B("noise", "Noise", 0, 1, 0)
			]),
			...q("Filter", [
				Ne("filterModel"),
				B("cutoff", "Cutoff", 40, 18e3, 1600, 1, "Hz", !0),
				B("resonance", "Resonance", 0, 1, .15),
				B("envAmount", "Env amount", 0, 1, .4),
				B("tracking", "Key track", 0, 1, .5)
			]),
			...Le("filter", "Filter envelope"),
			...Le("amp", "Amplifier envelope"),
			...q("Voices", [
				B("glide", "Glide", 0, 1, 0, .01, "s"),
				B("vintage", "Vintage", 0, 1, .3),
				V("chord", "Chord", ze.map(([e]) => e), 0),
				B("level", "Level", 0, 1, .7)
			])
		]
	},
	aurora: {
		name: "AURORA",
		subtitle: "EIGHT-VOICE ANALOG POLYSYNTH",
		color: "aurora",
		ports: [
			H("pitch", "Pitch · 1V/oct", "cv", 1200),
			H("gate", "Note gate", "gate"),
			H("cv", "Cutoff CV", "cv", 2400),
			...W(U("out", "Audio out"))
		],
		params: [
			...[1, 2].flatMap((e) => q(`Oscillator ${e}`, [
				V(`osc${e}Wave`, "Waveform", [
					"Saw",
					"Pulse",
					"Triangle",
					"Sine"
				], e === 1 ? 0 : 1),
				B(`osc${e}Octave`, "Octave", -2, 2, 0, 1),
				B(`osc${e}Detune`, "Detune", -50, 50, e === 2 ? 6 : 0, 1, "ct"),
				B(`osc${e}Width`, "Width", .05, .95, .5)
			])),
			...q("Source mix", [
				B("blend", "Osc 1 / 2", 0, 1, .5),
				B("crossMod", "Cross mod", 0, 1, 0),
				B("hpf", "High-pass", 20, 3e3, 20, 1, "Hz", !0)
			]),
			...q("Filter", [
				Ne("filterModel"),
				B("cutoff", "Cutoff", 40, 18e3, 2200, 1, "Hz", !0),
				B("resonance", "Resonance", 0, 1, .15),
				V("slope", "Slope", ["12 dB", "24 dB"], 1),
				B("envAmount", "Env amount", -1, 1, .35),
				B("tracking", "Key track", 0, 1, .5)
			]),
			...Le("filter", "Filter envelope"),
			...Le("amp", "Amplifier envelope"),
			...q("LFO", [
				B("lfoRate", "Rate", .05, 20, .6, .05, "Hz", !0),
				V("lfoShape", "Waveform", [
					"Triangle",
					"Sine",
					"Square"
				], 0),
				B("lfoPitch", "Pitch", 0, 1, 0),
				B("lfoWidth", "PWM", 0, 1, .15),
				B("lfoFilter", "Filter", 0, 1, 0)
			]),
			...q("Voices", [
				B("glide", "Glide", 0, 1, 0, .01, "s"),
				B("vintage", "Vintage", 0, 1, .25),
				V("chord", "Chord", ze.map(([e]) => e), 0),
				B("level", "Level", 0, 1, .65)
			])
		]
	},
	strike: {
		name: "STRIKE",
		subtitle: "VINTAGE DIGITAL DRUM MACHINE",
		color: "strike",
		ports: Re,
		drum: {
			mode: "steps",
			voices: Be
		},
		params: [
			B("level", "Level", 0, 1, .8),
			Ne("engine"),
			...Be.flatMap(({ id: e, label: t }) => [K(e, e === "kick" ? "x.......x.x....." : e === "snare" ? "....x.......x..." : e === "hat" ? "x.x.x.x.x.x.x.x." : "................"), ...[
				B(`${e}Tune`, "Tune", -24, 24, 0, 1, "st"),
				B(`${e}Decay`, "Decay", .03, 3, ["crash", "ride"].includes(e) ? 1.8 : e === "open" ? .45 : e === "hat" ? .08 : .35, .01, "s", !0),
				B(`${e}Tone`, "Tone", 0, 1, .7),
				B(`${e}Level`, "Level", 0, 1.6, .8),
				B(`${e}Pan`, "Pan", -1, 1, 0),
				Ae(`${e}Lag`)
			].map((n) => ({
				...n,
				voice: e,
				label: `${t} ${n.label}`
			}))])
		]
	},
	prism: {
		name: "PRISM",
		subtitle: "SIX-OPERATOR FM SYNTH",
		color: "prism",
		ports: [
			H("pitch", "Pitch · 1V/oct", "cv", 1200),
			H("gate", "Note gate", "gate"),
			H("cv", "Brightness CV", "cv", 1),
			...W(U("out", "Audio out"))
		],
		params: [
			...q("Sound", [
				V("algorithm", "Algorithm", Ve, 0),
				B("feedback", "Feedback", 0, 1, .08),
				B("brightness", "Brightness", 0, 2, .8),
				B("velocity", "Velocity", 0, 1, .7)
			]),
			...q("Performance", [
				B("lfoRate", "LFO rate", .05, 20, 5, .05, "Hz", !0),
				B("lfoDepth", "Vibrato", 0, 1, 0),
				V("chord", "Chord", ze.map(([e]) => e), 0),
				B("level", "Level", 0, 1, .65)
			]),
			...q("Filter", [Ne("filterModel"), ...[
				B("filterCutoff", "Cutoff", 40, 18e3, 9e3, 1, "Hz", !0),
				B("filterResonance", "Resonance", 0, 1, .15),
				B("filterDrive", "Drive", 0, 1, .2),
				B("filterEnv", "Env amount", -1, 1, .25),
				B("filterTrack", "Key track", 0, 1, .5)
			].map(G)]),
			...Array.from({ length: 6 }, (e, t) => {
				let n = `op${t + 1}`;
				return [
					B(`${n}Ratio`, "Ratio", .5, 16, t % 2 ? 2 : 1, .5),
					B(`${n}Detune`, "Detune", -50, 50, 0, 1, "ct"),
					B(`${n}Level`, "Level", 0, 1, t < 2 ? .8 : .4),
					B(`${n}Attack`, "Attack", .002, 2, .005, .001, "s", !0),
					B(`${n}Decay`, "Decay", .01, 3, t % 2 ? .35 : 1.2, .01, "s", !0),
					B(`${n}Sustain`, "Sustain", 0, 1, t % 2 ? .05 : .25),
					B(`${n}Release`, "Release", .01, 4, .25, .01, "s", !0)
				].map((e) => ({
					...e,
					voice: n
				}));
			}).flat()
		]
	},
	compressor: {
		name: "VALVE",
		subtitle: "VARIABLE-MU LIMITER",
		color: "compressor",
		ports: [H("in", "Audio in"), ...W(U("out", "Audio out"))],
		params: [
			B("input", "Input", -12, 18, 0, .5, "dB"),
			B("threshold", "Threshold", -40, 0, -18, .5, "dB"),
			V("time", "Time constant", [
				"1",
				"2",
				"3",
				"4",
				"5",
				"6"
			], 1),
			B("output", "Output", -12, 12, 0, .5, "dB")
		]
	},
	equalizer: {
		name: "CONSOLE",
		subtitle: "FOUR-BAND CHANNEL EQ",
		color: "equalizer",
		ports: [H("in", "Audio in"), ...W(U("out", "Audio out"))],
		params: [
			V("active", "EQ", ["In", "Out"], 0),
			B("output", "Output", -12, 12, 0, .5, "dB"),
			...q("Filters", [B("hpf", "High-pass", 16, 350, 16, 1, "Hz", !0), B("lpf", "Low-pass", 3e3, 22e3, 22e3, 10, "Hz", !0)]),
			...q("LF", [
				B("lfGain", "Gain", -15, 15, 0, .5, "dB"),
				B("lfFreq", "Freq", 30, 450, 100, 1, "Hz", !0),
				V("lfBell", "Shape", ["Shelf", "Bell"], 0)
			]),
			...q("LMF", [
				B("lmfGain", "Gain", -15, 15, 0, .5, "dB"),
				B("lmfFreq", "Freq", 200, 2500, 600, 1, "Hz", !0),
				B("lmfQ", "Q", .5, 4, 1, .1)
			]),
			...q("HMF", [
				B("hmfGain", "Gain", -15, 15, 0, .5, "dB"),
				B("hmfFreq", "Freq", 600, 7e3, 2500, 10, "Hz", !0),
				B("hmfQ", "Q", .5, 4, 1, .1)
			]),
			...q("HF", [
				B("hfGain", "Gain", -15, 15, 0, .5, "dB"),
				B("hfFreq", "Freq", 1500, 16e3, 8e3, 10, "Hz", !0),
				V("hfBell", "Shape", ["Shelf", "Bell"], 0)
			])
		]
	},
	cohere: {
		name: "COHERE",
		subtitle: "STEREO BUS COMPRESSOR",
		color: "cohere",
		ports: [H("in", "Audio in"), ...W(U("out", "Audio out"))],
		params: [...q("Dynamics", [
			B("threshold", "Threshold", -40, 10, -18, .5, "dB"),
			V("ratio", "Ratio", [
				"2:1",
				"4:1",
				"10:1"
			], 1),
			V("attack", "Attack", [
				"0.1 ms",
				"0.3 ms",
				"1 ms",
				"3 ms",
				"10 ms",
				"30 ms"
			], 4),
			V("release", "Release", [
				"0.1 s",
				"0.3 s",
				"0.6 s",
				"1.2 s",
				"Auto"
			], 4)
		]), ...q("Bus", [
			V("scHpf", "Detector HP", [
				"Off",
				"30 Hz",
				"60 Hz",
				"106 Hz",
				"125 Hz",
				"185 Hz"
			], 0),
			B("output", "Makeup", -12, 20, 0, .5, "dB"),
			V("active", "Process", ["In", "Bypass"], 0)
		])]
	},
	talon: {
		name: "TALON",
		subtitle: "HARMONIC DYNAMICS PROCESSOR",
		color: "talon",
		ports: [H("in", "Audio in"), ...W(U("out", "Audio out"))],
		params: [
			...q("Dynamics", [
				B("input", "Input", -12, 30, 0, .5, "dB"),
				V("ratio", "Ratio", [
					"1:1",
					"2:1",
					"3:1",
					"4:1",
					"6:1",
					"10:1 Opto",
					"20:1",
					"Crush"
				], 4),
				B("attack", "Attack", 5e-5, .03, .003, 5e-5, "s", !0),
				B("release", "Release", .05, 3.5, .3, .01, "s", !0)
			]),
			...q("Character", [
				V("color", "Harmonics", [
					"Clean",
					"Even",
					"Odd"
				], 0),
				V("audioHp", "Audio HP", ["Off", "65 Hz"], 0),
				V("fierce", "Fierce", ["Off", "On"], 0)
			]),
			...q("Detector", [
				V("detectorHp", "High-pass", ["Off", "80 Hz"], 0),
				V("detectorBand", "Emphasis", ["Off", "6 kHz"], 0),
				V("link", "Stereo link", ["Off", "On"], 1)
			]),
			...q("Output", [B("output", "Output", -30, 12, 0, .5, "dB"), V("active", "Process", ["In", "Bypass"], 0)])
		]
	},
	brit: {
		name: "BRIT",
		subtitle: "THREE-BAND CLASS A EQUALIZER",
		color: "brit",
		ports: [H("in", "Audio in"), ...W(U("out", "Audio out"))],
		params: [
			...q("Low shelf", [V("lfFreq", "Freq", [
				"35 Hz",
				"60 Hz",
				"110 Hz",
				"220 Hz"
			], 2), B("lfGain", "Gain", -16, 16, 0, .5, "dB")]),
			...q("Mid bell", [V("midFreq", "Freq", [
				"360 Hz",
				"700 Hz",
				"1.6 kHz",
				"3.2 kHz",
				"4.8 kHz",
				"7.2 kHz"
			], 2), B("midGain", "Gain", -18, 18, 0, .5, "dB")]),
			...q("High shelf · 12 kHz", [B("hfGain", "Gain", -16, 16, 0, .5, "dB")]),
			...q("Signal", [
				V("hpf", "High-pass", [
					"Off",
					"50 Hz",
					"80 Hz",
					"160 Hz",
					"300 Hz"
				], 0),
				B("drive", "Drive", 0, 24, 0, .5, "dB"),
				B("output", "Output", -18, 18, 0, .5, "dB"),
				V("active", "Process", ["In", "Bypass"], 0)
			])
		]
	},
	skitter: {
		name: "SKITTER",
		subtitle: "TRAP STEP SEQUENCER · 1/16 · 1/32 · ROLLS",
		color: "skitter",
		ports: [...W(U("trig", "Trig out · drums", "gate")), ...W(U("gate", "Synth gate", "gate"))],
		drum: {
			mode: "steps",
			voices: We
		},
		params: [
			B("rollFade", "Roll fade", 0, 1, .35),
			B("gate", "Gate", .1, 1, .5),
			...We.flatMap(({ id: e }) => [K(e, {
				snare: "....x.......x...",
				hat: "x.x.x.x.x.x.x.x."
			}[e] ?? "................"), ...qe.map((t) => ({
				...K(e, "................"),
				id: Je(e, t),
				label: `Roll ×${t}`
			}))])
		]
	},
	forge: {
		name: "FORGE",
		subtitle: "INDUSTRIAL DRUM KIT",
		color: "forge",
		ports: Re,
		drum: {
			mode: "steps",
			voices: Ke
		},
		params: [
			B("level", "Level", 0, 1, .8),
			Ne("engine"),
			B("drive", "Drive", 0, 1, .35),
			B("room", "Room", 0, 1, .2),
			...Ke.map(({ id: e }) => K(e, {
				kick: "x.......x.x.....",
				snare: "....x.......x...",
				hat: "x.x.x.x.x.x.x.x."
			}[e] ?? "................")),
			...Xe(Ke, (e) => ({
				crash: 2.4,
				china: 1.6,
				ride: 2.6,
				open: .7,
				hat: .09,
				pedal: .12,
				lowTom: .7,
				highTom: .55,
				anvil: 1,
				kick: .5,
				snare: .45
			})[e] ?? .4)
		]
	},
	rust: {
		name: "RUST",
		subtitle: "INDUSTRIAL DISTORTION",
		color: "rust",
		ports: [
			H("in", "Audio in"),
			H("cv", "Drive CV", "cv", 4),
			...W(U("out", "Audio out"))
		],
		params: [
			V("mode", "Mode", Ye, 0),
			B("drive", "Drive", 0, 1, .6),
			B("bias", "Bias", 0, 1, .15),
			B("crush", "Bits", 2, 12, 6, 1),
			B("starve", "Starve", 0, 1, 0),
			B("body", "Body", 60, 2e3, 220, 1, "Hz", !0),
			B("tone", "Tone", 0, 1, .55),
			B("mix", "Mix", 0, 1, 1),
			B("level", "Level", 0, 1, .6)
		]
	},
	output: {
		name: "MAIN",
		subtitle: "STEREO MASTER OUTPUT",
		color: "output",
		params: [B("volume", "Master", 0, 1, .65)],
		ports: [H("in", "Audio in")]
	}
}, ot = Object.keys(Y).filter((e) => e !== "output"), st = 0, ct = (e = "module") => `${e}-${Date.now().toString(36)}-${++st}`, lt = (e, t = ct()) => ({
	id: t,
	type: e,
	params: Object.fromEntries(Y[e].params.map((e) => [e.id, e.initial]))
}), ut = (e) => Y[e].params.find((e) => Me.includes(e.id)), dt = (e) => e === "performance" ? {
	...lt(e),
	steps: Array.from({ length: 16 }, (e, t) => ({
		enabled: t % 4 == 0,
		note: 48,
		velocity: .8,
		gate: .5
	}))
} : e === "dictator" ? {
	...lt(e),
	notes: []
} : lt(e), ft = (e, t) => e.modules.find((e) => e.id === t)?.type === "output", pt = (e, t) => e.modules[0].id === t ? e.sequencer.steps : e.modules.find((e) => e.id === t)?.steps ?? e.sequencer.steps;
function mt(e, t, n) {
	return e.modules[0].id === t ? {
		...e,
		sequencer: {
			...e.sequencer,
			steps: n
		}
	} : {
		...e,
		modules: e.modules.map((e) => e.id === t ? {
			...e,
			steps: n
		} : e)
	};
}
function ht(e, t, n = e.cables) {
	let r = (t) => e.modules.some((e) => e.id === t.id) ? pt(e, t.id) : t.steps ?? e.sequencer.steps, i = t[0]?.type === "performance" ? r(t[0]) : e.sequencer.steps;
	return {
		...e,
		cables: n,
		sequencer: i === e.sequencer.steps ? e.sequencer : {
			...e.sequencer,
			steps: i
		},
		modules: t.map((e, t) => e.type === "performance" ? t === 0 ? e.steps ? {
			id: e.id,
			type: e.type,
			params: e.params
		} : e : e.steps ? e : {
			...e,
			steps: r(e)
		} : e)
	};
}
var gt = (e) => e.modules.find((e) => Kt(e.type)) ?? e.modules[0], _t = (e, t) => e.modules.find((e) => e.id === t)?.notes ?? [], vt = (e, t) => Math.max(0, Math.min(y, b - e.modules.reduce((e, n) => e + (n.id === t ? 0 : n.notes?.length ?? 0), 0))), yt = (e, t, n) => {
	let r = vt(e, t);
	return {
		...e,
		modules: e.modules.map((e) => e.id === t ? {
			...e,
			notes: n.length > r ? n.slice(0, r) : n
		} : e)
	};
}, bt = (e) => Y[e].ports.some((e) => e.id === "trig" && e.direction === "in");
function xt(e, t, n) {
	let r = bt(e.modules.find((e) => e.id === n).type), i = [
		{
			moduleId: t,
			portId: "pitch"
		},
		{
			moduleId: t,
			portId: "gate"
		},
		{
			moduleId: n,
			portId: r ? "trig" : "pitch"
		},
		...r ? [] : [{
			moduleId: n,
			portId: "gate"
		}]
	], a = {
		...e,
		cables: e.cables.filter((e) => !i.some((t) => X(e.from, t) || X(e.to, t)))
	};
	return r ? kt(a, i[1], i[2]) : kt(kt(a, i[0], i[2]), i[1], i[3]);
}
function St(e, t) {
	let n = Dt(e, {
		moduleId: t,
		portId: "pitch"
	}), r = Dt(e, {
		moduleId: t,
		portId: "gate"
	});
	return !n && !r ? null : !n && r?.to.portId === "trig" || n && r && n.to.moduleId === r.to.moduleId && n.to.portId === "pitch" && r.to.portId === "gate" ? r.to.moduleId : "";
}
function Ct(e, t) {
	let n = e.cables.filter((n) => n.from.moduleId === t && Tt(e, n.from)?.kind === "gate").map((t) => e.modules.find((e) => e.id === t.to.moduleId));
	return n.length && n.every((e) => e && bt(e.type)) ? n[0] : null;
}
var wt = (e) => Math.max(16, ...e.modules.filter((e) => e.type === "dictator").map((e) => w(e.params.length))), Tt = (e, t) => {
	let n = e.modules.find((e) => e.id === t.moduleId);
	return n && Y[n.type].ports.find((e) => e.id === t.portId);
}, X = (e, t) => e.moduleId === t.moduleId && e.portId === t.portId;
function Et(e, t) {
	let n = e.filter((e) => (e.copyOf ?? e.id) === (t.copyOf ?? t.id));
	return n.length > 1 ? n.indexOf(t) + 1 : null;
}
var Dt = (e, t) => e.cables.find((e) => X(e.from, t) || X(e.to, t));
function Ot(e, t, n) {
	let r = Tt(e, t), i = Tt(e, n);
	if (!r || !i) return "That socket no longer exists.";
	if (r.direction !== "out" || i.direction !== "in") return "Connect an output to an input.";
	if (r.kind !== i.kind) return `A ${r.kind.toUpperCase()} output needs a ${r.kind.toUpperCase()} input.`;
	if (e.cables.some((e) => X(e.to, n))) return "That input already has a cable. Pull its plug out first.";
	if (e.cables.some((e) => X(e.from, t))) return "That output jack already has a cable. Use its spare jack, or pull the plug out first.";
	let a = /* @__PURE__ */ new Set(), o = (n) => n === t.moduleId || !a.has(n) && (a.add(n), e.cables.filter((e) => e.from.moduleId === n).some((e) => o(e.to.moduleId)));
	return o(n.moduleId) ? "External feedback loops are not supported. Use ECHO’s feedback control." : null;
}
function kt(e, t, n, r = 1) {
	let i = Ot(e, t, n);
	if (i) throw Error(i);
	return {
		...e,
		cables: [...e.cables, {
			id: ct("cable"),
			from: t,
			to: n,
			amount: r
		}]
	};
}
function At(e, t, n) {
	let r = Tt(e, t), i = Tt(e, n);
	return !r || !i || r.direction === i.direction ? null : r.direction === "out" ? {
		from: t,
		to: n
	} : {
		from: n,
		to: t
	};
}
function jt(e, t, n, r = null) {
	if (!Tt(e, t) || !Tt(e, n)) return "That socket no longer exists.";
	let i = At(e, t, n);
	return i ? Ot(r ? {
		...e,
		cables: e.cables.filter((e) => e.id !== r)
	} : e, i.from, i.to) : "Connect an output to an input.";
}
function Mt(e, t, n, r) {
	if (!e.cables.find((e) => e.id === t)) throw Error("That cable no longer exists.");
	let i = jt(e, n, r, t);
	if (i) throw Error(i);
	let a = At(e, n, r);
	return {
		...e,
		cables: e.cables.map((e) => e.id === t ? {
			...e,
			...a
		} : e)
	};
}
function Nt(e, t) {
	return ft(e, t) || !e.modules.some((e) => e.id === t) ? e : ht(e, e.modules.filter((e) => e.id !== t), e.cables.filter((e) => e.from.moduleId !== t && e.to.moduleId !== t));
}
function Pt(e, t, n) {
	let r = [...e.modules], i = r.findIndex((e) => e.id === t), a = i + n;
	return i < 0 || a < 0 || a >= r.length - 1 || ft(e, t) ? e : ([r[i], r[a]] = [r[a], r[i]], ht(e, r));
}
var Ft = (e, t) => (e >> t & 1) == 1;
function It(e, t, n = 0) {
	let r = Math.max(1, Math.min(16, Math.round(e))), i = Math.max(0, Math.min(r, Math.round(t))), a = Math.round(n);
	return Array.from({ length: r }, (e, t) => ((t - a) % r + r) % r * i % r < i);
}
function Lt(e, t, n) {
	let r = e.params;
	return [...qe].reverse().find((e) => Ft(r[Je(t, e)] ?? 0, n)) ?? 1;
}
var Rt = (e, t) => zt(e, t).map((n) => [n, Lt(e, n, t % 16)]);
function zt(e, t) {
	let n = Y[e.type].drum, r = e.params;
	return n ? n.voices.filter(({ id: i }) => {
		if (n.mode === "steps") return Ft(r[`${i}Pattern`], t % 16);
		let a = Bt(e, i);
		return a[t % a.length];
	}).map((e) => e.id) : [];
}
function Bt(e, t) {
	let n = e.params, r = n[`${t}Steps`];
	return n[`${t}Custom`] ? Array.from({ length: r }, (e, r) => Ft(n[`${t}Pattern`], r)) : It(r, n[`${t}Hits`], n[`${t}Shift`]);
}
function Vt(e, t, n) {
	let r = e.params[`${t}Custom`] ? e.params[`${t}Pattern`] : Bt(e, t).reduce((e, t, n) => e | (t ? 1 << n : 0), 0);
	return {
		...e.params,
		[`${t}Custom`]: 1,
		[`${t}Pattern`]: r ^ 1 << n
	};
}
function Ht(e, t) {
	let n = e.params;
	if (n[`${t}Hits`]) return { [`${t}Custom`]: 0 };
	let r = n[`${t}Custom`] ? Bt(e, t).filter(Boolean).length : 0;
	return {
		[`${t}Custom`]: 0,
		[`${t}Hits`]: r || Math.max(1, Math.round(n[`${t}Steps`] * 3 / 8))
	};
}
var Ut = (e, t) => !!e.params[`${t}Custom`] || !e.params[`${t}Hits`];
function Wt(e, t) {
	let n = Y[t.type].drum;
	return t.type === "performance" ? pt(e, t.id).some((e) => e.enabled) : t.type === "dictator" ? !!t.notes?.length : n?.mode === "euclid" ? n.voices.some(({ id: e }) => Bt(t, e).some(Boolean)) : Y[t.type].params.some((e) => e.pattern && t.params[e.id]);
}
function Gt(e, t) {
	let n = e.modules.find((e) => e.id === t);
	if (!n) return e;
	if (n.type === "performance") return mt(e, t, pt(e, t).map((e) => ({
		...e,
		enabled: !1
	})));
	if (n.type === "dictator") return yt(e, t, []);
	let r = Y[n.type].drum;
	if (!r) return e;
	let i = Object.fromEntries(Y[n.type].params.filter((e) => e.pattern).map((e) => [e.id, 0]));
	if (r.mode === "euclid") for (let { id: e } of r.voices) Object.assign(i, {
		[`${e}Hits`]: 0,
		[`${e}Custom`]: 0
	});
	return {
		...e,
		modules: e.modules.map((e) => e.id === t ? {
			...e,
			params: {
				...e.params,
				...i
			}
		} : e)
	};
}
var Kt = (e) => [
	"performance",
	"dictator",
	"oscillator",
	"monarch",
	"oracle",
	"aurora",
	"prism",
	"strike",
	"noise",
	"boom",
	"punch",
	"orbit",
	"forge"
].includes(e), qt = (e) => [
	"oracle",
	"aurora",
	"prism"
].includes(e), Jt = (e) => Yt(e) || !!Y[e].drum, Yt = (e) => e === "performance" || e === "dictator";
function Xt(e, t) {
	let n = /* @__PURE__ */ new Set([t]);
	for (let t of n) for (let r of e.cables) r.from.moduleId === t && Tt(e, r.from)?.kind === "audio" && n.add(r.to.moduleId);
	return n;
}
function Zt(e, t) {
	let n = e.modules.find((e) => e.id === t);
	if (n && (Yt(n.type) || n.type === "skitter")) {
		let n = /* @__PURE__ */ new Set([t]);
		for (let t of n) for (let r of e.cables) r.from.moduleId === t && Tt(e, r.from)?.kind !== "audio" && n.add(r.to.moduleId);
		return [...n].some((n) => n !== t && Zt(e, n));
	}
	let r = Xt(e, t);
	return e.modules.some((e) => e.type === "output" && r.has(e.id));
}
function Qt(e, t, n, r = null) {
	let i = At(e, t, n);
	if (!i) throw Error("Connect an output to an input.");
	if (!r) return kt(e, i.from, i.to);
	let a = e.cables.find((e) => e.id === r);
	return a && X(a.from, i.from) && X(a.to, i.to) ? e : Mt(e, r, i.from, i.to);
}
var $t = {
	muted: /* @__PURE__ */ new Set(),
	soloed: /* @__PURE__ */ new Set()
}, en = (e, t) => `${e}:${t}`, tn = (e, t) => `${e}:step:${t}`, nn = /* @__PURE__ */ new Set([
	"oscillator",
	"noise",
	"boom",
	"punch",
	"orbit",
	"monarch",
	"oracle",
	"aurora",
	"prism",
	"strike",
	"forge"
]), rn = (e) => nn.has(e);
function an(e, t) {
	let n = /* @__PURE__ */ new Set([t]);
	for (let t of n) for (let r of e.cables) r.from.moduleId === t && Tt(e, r.from)?.kind !== "audio" && n.add(r.to.moduleId);
	return n.delete(t), e.modules.filter((t) => nn.has(t.type) && [...Xt(e, t.id)].some((e) => n.has(e))).map((e) => e.id);
}
function on(e, t) {
	let n = new Set(e.modules.map((e) => e.id)), r = new Set([...t.soloed].filter((e) => n.has(e)));
	for (let t of r) for (let n of e.cables) n.from.moduleId === t && Tt(e, n.from)?.kind !== "audio" && r.add(n.to.moduleId);
	let i = (t, n = /* @__PURE__ */ new Set()) => r.has(t) ? !0 : !n.has(t) && (n.add(t), e.cables.some((e) => e.from.moduleId === t && e.to.portId !== "chain" && i(e.to.moduleId, n)));
	return Object.fromEntries(e.modules.filter((e) => e.type !== "output").map((e) => [e.id, !t.muted.has(e.id) && (!r.size || !nn.has(e.type) || i(e.id))]));
}
var sn = (e) => Y[e].drum?.voices.map((e) => e.id) ?? (e === "mixer" ? He : []);
function cn(e, t, n) {
	let r = sn(e.type).some((t) => n.soloed.has(en(e.id, t)));
	return !n.muted.has(en(e.id, t)) && (!r || n.soloed.has(en(e.id, t)));
}
function ln(e, t, n) {
	return !n.muted.has(tn(e, t)) && (!Array.from({ length: 16 }, (t, n) => tn(e, n)).some((e) => n.soloed.has(e)) || n.soloed.has(tn(e, t)));
}
function un(e, t, n) {
	let r = [], i = Dt(e, {
		moduleId: t,
		portId: n
	});
	for (; i;) {
		let t = e.modules.find((e) => e.id === i.from.moduleId);
		if (!t || r.includes(t) || (r.unshift(t), nn.has(t.type) || t.type === "mixer")) break;
		let n = Y[t.type].ports.filter((e) => e.direction === "in" && e.kind === "audio");
		i = n.length === 1 ? Dt(e, {
			moduleId: t.id,
			portId: n[0].id
		}) : void 0;
	}
	return r;
}
function dn(e, t) {
	let n = Y[t.type].name;
	return e.modules.filter((e) => e.type === t.type).length > 1 ? `${n} #${e.modules.findIndex((e) => e.id === t.id) + 1}` : n;
}
function fn(e, t, n) {
	let r = un(e, t, n), i = n.toUpperCase();
	return {
		source: r.length ? dn(e, r[0]) : `Channel ${i}`,
		tooltip: r.map((t) => dn(e, t)).join(" → "),
		connected: r.length > 0
	};
}
function pn(e, t, n) {
	let r = new Set(e.muted), i = new Set(e.soloed), [a, o] = n === "muted" ? [r, i] : [i, r];
	return a.delete(t) || (a.add(t), o.delete(t)), {
		muted: r,
		soloed: i
	};
}
function mn(e, t) {
	return e.muted.has(t) ? pn(e, t, "soloed") : e.soloed.has(t) ? pn(e, t, "muted") : e;
}
var hn = (e, t) => t === e.id || t.startsWith(`${e.id}:`), gn = (e, t) => [...t.muted, ...t.soloed].some((t) => hn(e, t));
function _n(e, t) {
	return gn(t, e) ? {
		muted: new Set([...e.muted].filter((e) => !hn(t, e))),
		soloed: new Set([...e.soloed].filter((e) => !hn(t, e)))
	} : e;
}
var vn = [
	"Vintage Bass",
	"Vintage Lead",
	"Boom Bap",
	"Late Night Hip-Hop",
	"Roots Reggae",
	"Dub Session",
	"Trap Soul",
	"Broken Beat",
	"Orbit Percussion"
], yn = [
	"Neon Skyline",
	"Digital Boogie",
	"Midnight Ballad",
	"New Wave Motion",
	"Glass Arcade",
	"Analog Sunrise"
], bn = [
	"French Touch",
	"Distortion Disco",
	"Electro Pogo",
	"Electroclash"
], xn = [
	"High Dive",
	"Undertow",
	"Deep End"
], Sn = [
	"Rust Machine",
	"Black Mass",
	"Bone Orchard"
], Cn = [
	["EDM / House", [
		"House",
		"French Touch",
		"Distortion Disco",
		"Electro Pogo",
		"Electroclash"
	]],
	["Funk / Soul", [
		"Groove",
		"Digital Boogie",
		"Midnight Ballad",
		"Broken Beat"
	]],
	["Industrial / Rock", Sn],
	["Reggae", ["Roots Reggae", "Dub Session"]],
	["Synthwave / 80s", [
		"Neon Skyline",
		"Vintage Lead",
		"New Wave Motion",
		"Glass Arcade",
		"Analog Sunrise"
	]],
	["Trap / Hip-Hop", [
		...xn,
		"Trap Soul",
		"Late Night Hip-Hop",
		"Boom Bap",
		"Vintage Bass"
	]],
	["Miscellaneous", ["Orbit Percussion"]]
];
Cn.flatMap(([, e]) => e);
var wn = "Bone Orchard", Tn = (e, t) => e.includes(t);
function En(e = wn) {
	if (Tn(xn, e)) return De(e);
	if (Tn(Sn, e)) return ke(e);
	if (Tn(bn, e)) return be(e);
	if (Tn(yn, e)) return ve(e);
	if (Tn(vn, e)) return ge(e);
	let t = e === "Groove" ? ["boom", "orbit"] : ["punch"], n = [
		"performance",
		"oscillator",
		"filter",
		"amplifier",
		"equalizer",
		"envelope",
		"lfo",
		"delay",
		...t,
		"output"
	].map((e) => lt(e, e)), r = (e) => n.find((t) => t.type === e);
	e === "Groove" ? (Object.assign(r("envelope").params, {
		decay: .16,
		sustain: .3
	}), Object.assign(r("equalizer").params, {
		hpf: 30,
		lfGain: 2,
		lfFreq: 90,
		lmfGain: -3,
		lmfFreq: 350,
		hmfGain: 2.5,
		hmfFreq: 1500,
		lpf: 1e4
	}), r("delay").params.mix = .15) : (r("oscillator").params.wave = 3, Object.assign(r("filter").params, {
		cutoff: 900,
		resonance: 5
	}), Object.assign(r("envelope").params, {
		attack: .002,
		decay: .14,
		sustain: 0,
		release: .08
	}), Object.assign(r("equalizer").params, {
		hpf: 40,
		lfGain: 2,
		lfFreq: 70,
		lfBell: 1,
		lmfGain: -3,
		lmfFreq: 300,
		hmfGain: 2,
		hmfFreq: 2e3,
		lpf: 12e3
	}), r("delay").params.mix = .12);
	let i = [
		36,
		36,
		43,
		36,
		48,
		36,
		46,
		43,
		36,
		36,
		43,
		48,
		46,
		43,
		38,
		43
	], a = (t) => e === "House" ? t % 4 != 0 : t !== 1 && t !== 9, o = {
		version: 1,
		name: e,
		modules: n,
		cables: [],
		sequencer: {
			bpm: e === "Groove" ? 94 : 124,
			swing: e === "Groove" ? .12 : 0,
			steps: i.map((e, t) => ({
				enabled: a(t),
				note: e,
				velocity: t % 4 == 0 ? 1 : .75,
				gate: .65
			}))
		}
	}, s = ["delay", ...t];
	for (let [e, n, r, i, a] of [
		[
			"oscillator",
			"out",
			"filter",
			"in",
			1
		],
		[
			"filter",
			"out",
			"amplifier",
			"in",
			1
		],
		[
			"amplifier",
			"out",
			"equalizer",
			"in",
			1
		],
		[
			"equalizer",
			"out",
			"delay",
			"in",
			1
		],
		...t.map((e, t) => [
			s[t],
			"out",
			e,
			"chain",
			1
		]),
		[
			s.at(-1),
			"out",
			"output",
			"in",
			1
		],
		[
			"performance",
			"pitch",
			"oscillator",
			"pitch",
			1
		],
		[
			"performance",
			"gate",
			"envelope",
			"gate",
			1
		],
		[
			"envelope",
			"out",
			"amplifier",
			"cv",
			1
		],
		[
			"lfo",
			"out",
			"filter",
			"cv",
			.12
		]
	]) o = kt(o, {
		moduleId: e,
		portId: n
	}, {
		moduleId: r,
		portId: i
	}, a);
	return o;
}
function Dn(e) {
	let t = `@@note-${Math.random().toString(36).slice(2)}@@`;
	return JSON.stringify(e, (e, n) => e === "notes" && Array.isArray(n) ? n.map((e) => `${t}${e.join(",")}`) : n, 2).replaceAll(RegExp(`"${t}([\\d,]+)"`, "g"), "[$1]");
}
function On(e) {
	let t = e.cables.map((e) => JSON.stringify([
		e.from.moduleId,
		e.from.portId,
		e.to.moduleId,
		e.to.portId,
		e.amount
	])).sort();
	return JSON.stringify({
		name: e.name,
		modules: e.modules,
		sequencer: e.sequencer,
		cables: t
	});
}
function kn(e) {
	if (e.length > 1e6) throw Error("Patch files must be smaller than 1 MB.");
	let t = JSON.parse(e), n = (e) => typeof e == "object" && !!e && !Array.isArray(e), r = () => {
		throw Error("This is not a valid Rackloose v1 patch.");
	}, i = (e) => !Array.isArray(e) || e.length !== 16 ? r() : e.map((e) => !n(e) || typeof e.enabled != "boolean" || typeof e.note != "number" || !Number.isInteger(e.note) || e.note < 24 || e.note > 96 || typeof e.velocity != "number" || !Number.isFinite(e.velocity) || e.velocity < 0 || e.velocity > 1 || typeof e.gate != "number" || !Number.isFinite(e.gate) || e.gate < .1 || e.gate > .95 ? r() : {
		enabled: e.enabled,
		note: e.note,
		velocity: e.velocity,
		gate: e.gate
	}), a = (e) => e === void 0 ? [] : !Array.isArray(e) || e.length > 2048 ? r() : T(e.map((e) => {
		if (!Array.isArray(e) || e.length !== 4 || !e.every((e) => Number.isInteger(e))) return r();
		let [t, n, i, a] = e;
		return t < 0 || t >= v || n < 1 || n > v || i < 0 || i > 127 || a < 1 || a > 127 ? r() : [
			t,
			n,
			i,
			a
		];
	}));
	if (!n(t) || t.version !== 1 || typeof t.name != "string" || t.name.length > 100 || !Array.isArray(t.modules) || !Array.isArray(t.cables) || !n(t.sequencer) || t.modules.length < 1 || t.modules.length > 32 || t.cables.length > 128) return r();
	let o = /* @__PURE__ */ new Set(), s = t.modules.map((e, t) => {
		if (!n(e) || typeof e.id != "string" || !/^[\w-]{1,80}$/.test(e.id) || o.has(e.id) || typeof e.type != "string" || !Object.hasOwn(Y, e.type) || !n(e.params)) return r();
		o.add(e.id);
		let s = e.type, c = e.params, l = Object.fromEntries(Y[s].params.map((e) => {
			let t = c[e.id] === void 0 ? e.legacyFrom !== void 0 && c[e.legacyFrom] !== void 0 ? c[e.legacyFrom] : e.legacyDefault : c[e.id];
			return typeof t != "number" || !Number.isFinite(t) || t < e.min || t > e.max || (e.choices || e.pattern) && !Number.isInteger(t) ? r() : [e.id, t];
		}));
		return s === "dictator" ? {
			id: e.id,
			type: s,
			params: l,
			notes: a(e.notes)
		} : s === "performance" && t > 0 ? {
			id: e.id,
			type: s,
			params: l,
			steps: i(e.steps)
		} : {
			id: e.id,
			type: s,
			params: l
		};
	});
	if (s.reduce((e, t) => e + (t.notes?.length ?? 0), 0) > 8192 || s.filter((e) => e.type === "output").length !== 1 || s.at(-1)?.type !== "output") return r();
	let c = t.sequencer;
	if (typeof c.bpm != "number" || !Number.isFinite(c.bpm) || c.bpm < 40 || c.bpm > 240 || typeof c.swing != "number" || !Number.isFinite(c.swing) || c.swing < 0 || c.swing > .6) return r();
	let l = i(c.steps), u = {
		version: 1,
		name: t.name,
		modules: s,
		cables: [],
		sequencer: {
			bpm: c.bpm,
			swing: c.swing,
			steps: l
		}
	}, d = /* @__PURE__ */ new Set();
	for (let e of t.cables) {
		if (!n(e) || typeof e.id != "string" || !/^[\w-]{1,80}$/.test(e.id) || d.has(e.id) || !n(e.from) || !n(e.to) || typeof e.from.moduleId != "string" || typeof e.from.portId != "string" || typeof e.to.moduleId != "string" || typeof e.to.portId != "string" || typeof e.amount != "number" || !Number.isFinite(e.amount) || e.amount < -1 || e.amount > 1) return r();
		d.add(e.id);
		let t = {
			moduleId: e.from.moduleId,
			portId: e.from.portId
		}, i = {
			moduleId: e.to.moduleId,
			portId: e.to.portId
		}, a = Tt(u, t);
		if (a && u.cables.some((e) => X(e.from, t))) {
			let e = Y[u.modules.find((e) => e.id === t.moduleId).type].ports.find((e) => (e.copyOf ?? e.id) === (a.copyOf ?? a.id) && !u.cables.some((n) => X(n.from, {
				moduleId: t.moduleId,
				portId: e.id
			})));
			if (!e) continue;
			t.portId = e.id;
		}
		if (Ot(u, t, i) || Tt(u, t)?.kind !== "cv" && e.amount !== 1) return r();
		u = {
			...u,
			cables: [...u.cables, {
				id: e.id,
				from: t,
				to: i,
				amount: e.amount
			}]
		};
	}
	return u;
}
function An(e, t) {
	try {
		let n = e.getItem(t);
		return {
			patch: n ? kn(n) : null,
			error: null
		};
	} catch {
		return {
			patch: null,
			error: "Saved patch unavailable. You can still play and export patch files."
		};
	}
}
function jn(e, t, n) {
	try {
		return e.setItem(t, Dn(n)), null;
	} catch {
		return "Local save unavailable. Export a patch file to keep your work.";
	}
}
var Mn = (e, t) => e.logarithmic ? Math.log(t / e.min) / Math.log(e.max / e.min) : (t - e.min) / (e.max - e.min), Nn = [
	"C",
	"C♯",
	"D",
	"D♯",
	"E",
	"F",
	"F♯",
	"G",
	"G♯",
	"A",
	"A♯",
	"B"
], Pn = (e) => `${Nn[e % 12]}${Math.floor(e / 12) - 1}`, Fn = class {
	notes = /* @__PURE__ */ new Map();
	press(e, t) {
		return this.notes.delete(e), this.notes.set(e, t), this.current;
	}
	release(e) {
		return this.notes.delete(e), this.current;
	}
	clear() {
		this.notes.clear();
	}
	has(e) {
		return this.notes.has(e);
	}
	get current() {
		return [...this.notes.values()].at(-1) ?? null;
	}
	get entries() {
		return [...this.notes];
	}
}, In = (e, t, n) => 60 / e / 4 * (n % 2 == 0 ? 1 + t : 1 - t);
function Ln(e, t, n = 0) {
	let r = [], i = n;
	for (let n = 0; n < t * wt(e); n++) {
		let t = n % 16, a = In(e.sequencer.bpm, e.sequencer.swing, t);
		r.push({
			step: e.sequencer.steps[t],
			index: t,
			time: i,
			duration: a
		}), i += a;
	}
	return {
		events: r,
		duration: i - n
	};
}
var Rn = (e) => [...e].map((e) => e.charCodeAt(0) & 127), zn = (e) => [
	e >>> 24 & 255,
	e >>> 16 & 255,
	e >>> 8 & 255,
	e & 255
];
function Bn(e) {
	let t = [e & 127];
	for (let n = e >>> 7; n > 0; n >>>= 7) t.unshift(n & 127 | 128);
	return t;
}
var Vn = (e, t) => [
	...Rn(e),
	...zn(t.length),
	...t
], Hn = (e, t) => [
	255,
	e,
	...Bn(t.length),
	...t
];
function Un(e, t) {
	let n = Math.round(6e7 / t), r = [
		0,
		...Hn(81, [
			n >> 16 & 255,
			n >> 8 & 255,
			n & 255
		]),
		0,
		...Hn(88, [
			4,
			2,
			24,
			8
		]),
		0,
		...Hn(47, [])
	], i = e.map(({ name: e, notes: t, channel: n = 0 }) => {
		let r = t.flatMap(([e, t, r, i]) => [{
			tick: e,
			data: [
				144 | n,
				r,
				i
			],
			off: !1
		}, {
			tick: e + t,
			data: [
				128 | n,
				r,
				64
			],
			off: !0
		}]).sort((e, t) => e.tick - t.tick || Number(t.off) - Number(e.off)), i = 0, a = [0, ...Hn(3, Rn(e.replace(/[^\x20-\x7e]/g, "-").slice(0, 100)))];
		for (let e of r) a.push(...Bn(e.tick - i), ...e.data), i = e.tick;
		return Vn("MTrk", [
			...a,
			0,
			...Hn(47, [])
		]);
	});
	return new Uint8Array([
		...Vn("MThd", [
			0,
			1,
			...[e.length + 1].flatMap((e) => [e >> 8, e & 255]),
			3,
			192
		]),
		...Vn("MTrk", r),
		...i.flat()
	]);
}
var Wn = () => {
	throw Error("This MIDI file is damaged or not a MIDI file.");
};
function Gn(e) {
	if (e.length > 1e6) throw Error("MIDI files must be smaller than 1 MB.");
	let t = new DataView(e.buffer, e.byteOffset, e.byteLength), n = (t) => String.fromCharCode(...e.subarray(t, t + 4));
	if (e.length < 14 || n(0) !== "MThd") return Wn();
	let r = t.getUint32(4), i = t.getUint16(8), a = t.getUint16(10), o = t.getUint16(12);
	if (r < 6 || i > 1 || 8 + r > e.length) return Wn();
	if (o & 32768) throw Error("MIDI files timed in SMPTE frames are not supported.");
	if (!o || a > 256) return Wn();
	let s = (e) => Math.round(e * 960 / o), c = null, l = 8 + r, u = 0, d = [];
	for (; l + 8 <= e.length && u < a;) {
		let r = n(l), i = t.getUint32(l + 4), a = l + 8 + i;
		if (a > e.length) return Wn();
		if (r === "MTrk") {
			u++;
			let t = l + 8, n = 0, r = 0, i = "", o = /* @__PURE__ */ new Map(), f = /* @__PURE__ */ new Map(), p = () => t < a ? e[t++] : Wn(), m = () => {
				let e = 0;
				for (let t = 0; t < 4; t++) {
					let t = p();
					if (e = e * 128 + (t & 127), !(t & 128)) return e;
				}
				return Wn();
			}, h = (e, t, n) => {
				let r = o.get(e * 128 + t)?.shift();
				if (r) {
					let i = f.get(e) ?? [];
					i.push([
						r.tick,
						Math.max(1, n - r.tick),
						t,
						r.velocity
					]), f.set(e, i);
				}
			};
			for (; t < a;) {
				n += m();
				let l = p();
				if (l === 255) {
					let n = p(), r = m();
					if (t + r > a) return Wn();
					let o = e.subarray(t, t + r);
					t += r, n === 3 && !i && (i = String.fromCharCode(...o).replace(/[^\x20-\x7e]/g, "").trim().slice(0, 100));
					let s = o[0] << 16 | o[1] << 8 | o[2];
					if (n === 81 && r === 3 && s > 0 && c === null && (c = Math.round(6e7 / s * 100) / 100), n === 47) break;
					continue;
				}
				if (l === 240 || l === 247) {
					let e = m();
					if (t += e, t > a) return Wn();
					continue;
				}
				if (l < 128) {
					if (!r) return Wn();
					t--, l = r;
				} else r = l;
				let u = l & 240, d = l & 15, f = p(), g = u === 192 || u === 208 ? 0 : p();
				if (f > 127 || g > 127) return Wn();
				if (u === 144 && g > 0) {
					let e = d * 128 + f;
					o.set(e, [...o.get(e) ?? [], {
						tick: s(n),
						velocity: g
					}]);
				} else (u === 128 || u === 144) && h(d, f, s(n));
			}
			for (let e of o.keys()) for (; o.get(e)?.length;) h(Math.floor(e / 128), e % 128, s(n));
			for (let [e, t] of [...f].sort(([e], [t]) => e - t)) d.push({
				name: i || `Track ${u}`,
				channel: e,
				notes: t.sort((e, t) => e[0] - t[0] || e[2] - t[2])
			});
		}
		l = a;
	}
	return u < Math.min(a, 1) ? Wn() : {
		bpm: c,
		tracks: d
	};
}
function Kn(e, t) {
	let n = e.reduce((e, [t]) => Math.max(e, t), 0), r = _.findIndex((e) => n < e * g), i = r < 0 ? _.length - 1 : r, a = C(i), o = /* @__PURE__ */ new Set(), s = [];
	for (let [t, n, r, i] of T(e)) t < 0 || t >= a || o.has(t * 128 + r) || (o.add(t * 128 + r), s.push([
		t,
		Math.max(1, Math.min(n, a - t)),
		r,
		Math.max(1, Math.min(127, i))
	]));
	let c = s.slice(0, Math.max(0, Math.min(y, t)));
	return {
		notes: c,
		length: i,
		dropped: e.length - c.length
	};
}
// src/midiInput.ts
var qn = () => typeof navigator < "u" && typeof navigator.requestMIDIAccess == "function";
function Jn(e) {
	if (e.length < 3) return null;
	let t = e[0] & 240, n = e[1], r = e[2];
	return n > 127 || r > 127 ? null : t === 144 ? r ? {
		on: !0,
		note: n,
		velocity: r
	} : {
		on: !1,
		note: n,
		velocity: 0
	} : t === 128 ? {
		on: !1,
		note: n,
		velocity: 0
	} : null;
}
async function Yn(e, t = () => {}) {
	let n = await navigator.requestMIDIAccess({ sysex: !1 }), r = !1, i = () => {
		for (let t of n.inputs.values()) t.onmidimessage = (n) => {
			let i = n.data && Jn(n.data);
			i && !r && e({
				...i,
				timeStamp: n.timeStamp,
				input: t.name ?? t.id
			});
		};
		t([...n.inputs.values()].filter((e) => e.state !== "disconnected").map((e) => e.name || e.id));
	};
	return n.onstatechange = () => {
		r || i();
	}, i(), () => {
		r = !0, n.onstatechange = null;
		for (let e of n.inputs.values()) e.onmidimessage = null;
	};
}
var Xn = () => ({
	past: [],
	future: [],
	key: null,
	at: 0
});
function Zn(e, t, n, r) {
	return n !== null && n === e.key && r - e.at < 1e3 && !e.future.length ? {
		...e,
		at: r
	} : {
		past: [...e.past, t].slice(-50),
		future: [],
		key: n,
		at: r
	};
}
function Qn(e, t) {
	let n = e.past.at(-1);
	return n === void 0 ? null : {
		state: n,
		history: {
			past: e.past.slice(0, -1),
			future: [t, ...e.future],
			key: null,
			at: 0
		}
	};
}
function $n(e, t) {
	let [n, ...r] = e.future;
	return n === void 0 ? null : {
		state: n,
		history: {
			past: [...e.past, t].slice(-50),
			future: r,
			key: null,
			at: 0
		}
	};
}
var er = "This browser could not save to My Presets. Export a file to keep your work.", tr = 100, nr = (e, t) => e.trim().toLocaleLowerCase() === t.trim().toLocaleLowerCase(), rr = (e, t) => e.patch.name.localeCompare(t.patch.name, void 0, {
	sensitivity: "base",
	numeric: !0
}) || e.savedAt - t.savedAt;
function ir(e, t) {
	try {
		let n = e.getItem(t);
		if (!n) return {
			presets: [],
			error: null
		};
		let r = JSON.parse(n);
		if (typeof r != "object" || !r || !("presets" in r) || !Array.isArray(r.presets)) throw Error("Not a preset list");
		let i = [], a = /* @__PURE__ */ new Set();
		for (let e of r.presets.slice(0, 200)) try {
			if (typeof e != "object" || !e) continue;
			let { id: t, savedAt: n, patch: r } = e;
			if (typeof t != "string" || !/^[\w-]{1,80}$/.test(t) || a.has(t) || typeof n != "number" || !Number.isFinite(n)) continue;
			let o = kn(JSON.stringify(r));
			if (i.some((e) => nr(e.patch.name, o.name))) continue;
			a.add(t), i.push({
				id: t,
				savedAt: n,
				patch: o
			});
		} catch {}
		return {
			presets: i.sort(rr),
			error: null
		};
	} catch {
		return {
			presets: [],
			error: "My Presets could not be read. Export files to keep your presets."
		};
	}
}
function ar(e, t, n) {
	try {
		return e.setItem(t, JSON.stringify({
			version: 1,
			presets: n
		})), null;
	} catch {
		return er;
	}
}
function or(e, t) {
	return [...e.filter((e) => e.id !== t.id && !nr(e.patch.name, t.patch.name)), t].sort(rr);
}
var sr = (e, t, n) => e.find((e) => e.id !== n && nr(e.patch.name, t));
function cr(e, t) {
	for (let n = 1;; n++) {
		let r = n === 1 ? "" : ` (${n})`, i = `${t.slice(0, tr - r.length).trimEnd()}${r}`;
		if (!sr(e, i)) return i;
	}
}
function lr(e) {
	return e.trim().toLowerCase().replace(/[^a-z0-9_-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80).replace(/-+$/, "") || "rackloose-patch";
}
function ur(e, t) {
	return e ? t ? t.error ? {
		state: "failed",
		text: "Edited · not saved",
		detail: t.error
	} : {
		state: "saved",
		text: "Edited · saved locally",
		detail: "Your edits are kept in this browser and come back after a reload. Save adds them to My Presets."
	} : {
		state: "edited",
		text: "Edited",
		detail: ""
	} : {
		state: "clean",
		text: "",
		detail: ""
	};
}
// src/audio/hold.ts
var dr = /* @__PURE__ */ new WeakMap(), fr = 64;
function pr(e, t, n) {
	let r = () => t, i = 0;
	for (let t of e) if (t.type === "ramp") {
		if (t.time > n) {
			let e = r(i);
			return e + (t.value - e) * (n - i) / (t.time - i);
		}
		r = () => t.value, i = t.time;
	} else {
		if (t.time > n) break;
		let e = r(t.time), a = t.time;
		r = t.type === "set" ? () => t.value : (n) => t.value + (e - t.value) * Math.exp(-(n - a) / t.constant), i = t.time;
	}
	return r(n);
}
function mr(e, t) {
	if (typeof e.cancelAndHoldAtTime == "function" || dr.has(e)) return e;
	let n = [], { setValueAtTime: r, linearRampToValueAtTime: i, setTargetAtTime: a, cancelScheduledValues: o } = e, s, c = (r) => {
		s ??= e.value;
		let i = n.length;
		for (; i && n[i - 1].time > r.time;) i--;
		if (n.splice(i, 0, r), t && n.length > fr) {
			let e = -1;
			for (let r = 0; r < n.length && n[r].time <= t.currentTime - 1; r++) n[r].type !== "ramp" && (e = r);
			e > 0 && (s = pr(n.slice(0, e), s, n[e].time), n.splice(0, e));
		}
	};
	return Object.assign(e, {
		setValueAtTime(t, n) {
			return c({
				type: "set",
				time: n,
				value: t,
				constant: 0
			}), r.call(e, t, n);
		},
		linearRampToValueAtTime(t, n) {
			return c({
				type: "ramp",
				time: n,
				value: t,
				constant: 0
			}), i.call(e, t, n);
		},
		setTargetAtTime(t, n, r) {
			return c({
				type: "target",
				time: n,
				value: t,
				constant: r
			}), a.call(e, t, n, r);
		},
		cancelScheduledValues(t) {
			return n.splice(0, n.length, ...n.filter((e) => e.time < t)), o.call(e, t);
		}
	}), dr.set(e, {
		events: n,
		hold: (t) => {
			let r = pr(n, s ?? e.value, t), i = n.find((e) => e.time >= t);
			e.cancelScheduledValues(t), i?.type === "ramp" ? e.linearRampToValueAtTime(r, t) : e.setValueAtTime(r, t);
		}
	}), e;
}
function hr(e, t) {
	if (typeof e.cancelAndHoldAtTime == "function") {
		e.cancelAndHoldAtTime(t);
		return;
	}
	let n = dr.get(e)?.hold;
	if (n) n(t);
	else {
		let n = e.value;
		e.cancelScheduledValues(t), e.setValueAtTime(n, t);
	}
}
// src/audio/drums.ts
var gr = [
	205.3,
	304.4,
	369.6,
	522.7,
	540,
	800
], _r = (e) => 2 ** (e / 12);
function vr(e, t, n, { keep: r, start: i, noise: a }) {
	let o = /* @__PURE__ */ new Set(), s = /* @__PURE__ */ new Map(), c = (t = 0, i = n) => {
		let a = r(e.createGain());
		return a.gain.value = t, a.connect(i), a;
	}, l = /* @__PURE__ */ new Set(), u = (e, t, n) => {
		l.add(e), e.setValueAtTime(t, n);
	}, d = /* @__PURE__ */ new Map(), f = (t) => {
		let n = d.get(t);
		return n || (n = r(e.createStereoPanner()), n.channelCount = 1, n.channelCountMode = "explicit", n.connect(c(Math.SQRT2)), d.set(t, n)), n;
	}, p = (t, n, i = .7) => {
		let a = r(e.createBiquadFilter());
		return a.type = t, a.frequency.value = n, a.Q.value = i, a;
	}, m = (...e) => (e.reduce((e, t) => e.connect(t)), e.at(-1)), h = null, g = () => (h || (h = i(e.createBufferSource()), h.buffer = a, h.loop = !0), h), _ = (t, n) => {
		let a = r(e.createGain());
		return a.gain.value = n, {
			sum: a,
			oscillators: t.map((t) => {
				let n = i(e.createOscillator());
				return n.type = "square", n.frequency.value = t, n.connect(a), n;
			})
		};
	}, v = (e, t, ...n) => {
		let r = c(0, f(e)), i = n.map((e) => e.frequency.value);
		return m(t, ...n, r), {
			gain: r.gain,
			tune: (e, t) => n.forEach((n, r) => u(n.frequency, i[r] * e, t))
		};
	}, y = /* @__PURE__ */ new Map(), b = (t, n, r, i, a = 5e-4) => {
		mr(t, e);
		let o = y.get(t) ?? [], s = o.filter((t) => t.time < e.currentTime).at(-1);
		y.set(t, [
			...s ? [s] : [],
			...o.filter((t) => t.time >= e.currentTime),
			{
				time: n,
				peak: r,
				decay: i,
				rise: a
			}
		].sort((e, t) => e.time - t.time)), t.setTargetAtTime(r, n, a), t.setTargetAtTime(0, n + a * 5, i / 4.6);
	}, x = (e, t) => e.setTargetAtTime(0, t, .003);
	function S(e) {
		if (o.delete(e)) {
			for (let t of [
				...e.sources,
				...e.nodes,
				e.vca
			]) t.disconnect();
			s.get(e.voice) === e && s.delete(e.voice);
		}
	}
	function C(t, n, r, i, a, c = f(t)) {
		let l = e.createGain(), u = [];
		l.gain.value = 0, mr(l.gain, e), l.connect(c);
		let d = {
			voice: t,
			vca: l,
			nodes: u,
			sources: a(l, u),
			start: n,
			end: n + i * 1.25 + .05,
			naturalEnd: n + i * 1.25 + .05,
			decay: i
		};
		l.gain.setValueAtTime(0, n), l.gain.linearRampToValueAtTime(r, n + .0015), l.gain.setTargetAtTime(0, n + .0015, i / 4.6);
		for (let e of d.sources) e.start(n), e.stop(d.end);
		d.sources[0].onended = () => S(d), o.add(d);
		let p = s.get(t), [m, h] = p && p.start > n ? [d, p] : [p, d];
		if (s.set(t, h), m && o.has(m) && m.end > h.start) {
			m.vca.gain.setTargetAtTime(0, h.start, .002), m.end = h.start + .03, m.chokeAt = h.start;
			for (let e of m.sources) e.stop(m.end);
		}
	}
	let w = (t, n, r, i, a = 1) => {
		let o = e.createOscillator();
		if (o.type = r, o.frequency.value = i, a === 1) o.connect(t);
		else {
			let r = e.createGain();
			r.gain.value = a, o.connect(r).connect(t), n.push(r);
		}
		return o;
	}, T = (e, t, n, r, i) => {
		e.frequency.setValueAtTime(n * r, t), e.frequency.exponentialRampToValueAtTime(n, t + i);
	}, E = () => {};
	if (t === "boom") {
		let e = v("snare", g(), p("highpass", 1800)), t = v("rim", g(), p("highpass", 5e3)), n = v("clap", g(), p("bandpass", 1e3, 1.4)), r = _(gr, .5).sum, i = p("highpass", 5e3), a = v("hat", r, p("bandpass", 1e4, 1), p("highpass", 7e3)), o = v("open", r, p("bandpass", 1e4, 1), p("highpass", 7e3)), s = v("crash", r, p("bandpass", 7e3, .5), i);
		m(g(), c(.35, i));
		let l = v("ride", _(gr.map((e) => e * 1.13), .5).sum, p("bandpass", 4800, 2.5), p("highpass", 3e3)), u = _([540, 800], .5), d = v("bell", u.sum, p("bandpass", 2640, 1.4)), f = (e, t, n, r, i) => C(e, t, .9 * i, r, (e, r) => {
			let i = w(e, r, "sine", n), a = w(e, r, "triangle", n * 1.5, .15);
			return T(i, t, n, 1.6, .06), T(a, t, n * 1.5, 1.6, .06), [i, a];
		});
		E = (r, i, c) => {
			let p = c[`${r}Level`] ?? 1;
			if (r === "kick") C("kick", i, p, c.kickDecay, (e) => {
				let t = w(e, [], "sine", c.kickTune);
				return T(t, i, c.kickTune, 2, .025), [t];
			});
			else if (r === "snare") {
				let t = c.snareTone, n = _r(c.snareTune);
				C("snare", i, .55 * p, .65 * c.snareDecay, (e, r) => [w(e, r, "sine", 185 * n, 1 - .6 * t), w(e, r, "sine", 330 * n, .35 + .65 * t)]), b(e.gain, i, .6 * c.snappy * p, c.snareDecay);
			} else if (r === "rim") {
				let e = _r(c.rimTune);
				C("rim", i, .7 * p, c.rimDecay, (t, n) => [w(t, n, "triangle", 455 * e, .6), w(t, n, "triangle", 1667 * e)]), b(t.gain, i, .5 * p, .008 / .03 * c.rimDecay);
			} else if (r === "clap") {
				n.tune(J(c.clapTone, 3), i);
				for (let e of [
					0,
					.01,
					.021
				]) b(n.gain, i + e, 1.4 * p, .016, 4e-4);
				b(n.gain, i + .032, 1.4 * p, c.clapDecay);
			} else if (r === "hat") x(o.gain, i), a.tune(J(c.hatTone, 2), i), b(a.gain, i, 1.25 * p, c.hatDecay);
			else if (r === "open") o.tune(J(c.openTone, 2), i), b(o.gain, i, p, c.openDecay);
			else if (r === "lowTom") f("lowTom", i, 95 * _r(c.tomTune), c.tomDecay, p);
			else if (r === "highTom") f("highTom", i, 145 * _r(c.highTomTune), c.highTomDecay * .85, p);
			else if (r === "crash") s.tune(J(c.crashTone, 2), i), b(s.gain, i, .75 * p, c.crashDecay, .002);
			else if (r === "ride") l.tune(J(c.rideTone, 2), i), b(l.gain, i, .8 * p, c.rideDecay, .001);
			else if (r === "bell") {
				let e = _r(c.bellTune);
				u.oscillators.forEach((t, n) => t.frequency.setValueAtTime([540, 800][n] * e, i)), b(d.gain, i, .9 * p, c.bellDecay);
			}
		};
	} else if (t === "punch") {
		let t = c(1, f("kick")), n = r(e.createWaveShaper()), i = c(1, n), a = c(0, i);
		n.curve = Float32Array.from({ length: 1025 }, (e, t) => Math.tanh(2.2 * (t / 512 - 1)) / Math.tanh(2.2)), n.oversample = "2x", n.connect(t), m(g(), p("lowpass", 4e3), a);
		let o = p("lowpass", 6e3), s = v("snare", g(), p("highpass", 1200), o), l = v("clap", g(), p("bandpass", 1100, 1.6)), d = r(e.createGain());
		m(_(gr.map((e) => e * 1.5), .5).sum, d), m(g(), c(.35, d));
		let h = v("hat", d, p("highpass", 7500)), y = v("open", d, p("highpass", 7500));
		E = (e, n, r) => {
			let c = r[`${e}Level`] ?? 1;
			if (e === "kick") u(t.gain, c, n), C("kick", n, 1, r.kickDecay, (e) => {
				let t = w(e, [], "sine", r.kickTune), i = t.frequency;
				return i.setValueAtTime(r.kickTune * 5, n), i.exponentialRampToValueAtTime(r.kickTune * 1.3, n + .03), i.exponentialRampToValueAtTime(r.kickTune, n + .16), [t];
			}, i), b(a.gain, n, .7 * r.kickClick, .012);
			else if (e === "snare") {
				let e = _r(r.snareTune);
				C("snare", n, .5 * c, .11 / .18 * r.snareDecay, (t, r) => [180, 330].map((i, a) => {
					let o = w(t, r, "triangle", i * e, a ? .6 : 1);
					return T(o, n, i * e, 1.15, .02), o;
				})), u(o.frequency, 3e3 + 7e3 * r.snareTone, n), b(s.gain, n, .75 * r.snappy * c, r.snareDecay);
			} else if (e === "clap") {
				l.tune(J(r.clapTone, 3), n);
				for (let e of [
					0,
					.011,
					.022
				]) b(l.gain, n + e, 1.5 * c, .018, 4e-4);
				b(l.gain, n + .033, 1.5 * c, r.clapDecay);
			} else e === "hat" ? (x(y.gain, n), h.tune(J(r.hatTone, 2), n), b(h.gain, n, .9 * c, r.hatDecay)) : e === "open" && (y.tune(J(r.openTone, 2), n), b(y.gain, n, .75 * c, r.openDecay));
		};
	} else if (t === "orbit") {
		let e = p("bandpass", 6500, 1.2), t = c(0, f("sand")), n = p("highpass", 4500), r = c(0, f("shaker"));
		m(g(), e, p("highpass", 3e3), t), m(g(), n, r), E = (i, a, o) => {
			let s = _r(o.pitch + o[`${i}Tune`]), c = o[`${i}Decay`], l = o[`${i}Level`], d = o[`${i}Tone`];
			i === "skin" || i === "tom" ? C(i, a, (i === "skin" ? .8 : .95) * l, c, (e, t) => {
				let n = (i === "skin" ? 196 : 98) * s, r = w(e, t, "sine", n), o = w(e, t, "sine", n * (i === "skin" ? 311 / 196 : 1.5), d * .5);
				return T(r, a, n, i === "skin" ? 1.4 : 2.2, .035), T(o, a, n * (i === "skin" ? 311 / 196 : 1.5), 1.4, .035), [r, o];
			}) : i === "wood" ? C("wood", a, .6 * l, c, (e, t) => {
				let n = w(e, t, "sine", 1450 * s), r = w(e, t, "sine", 3915 * s, d * .6);
				return T(n, a, 1450 * s, 1.05, .005), [n, r];
			}) : i === "sand" ? (u(e.frequency, Math.min(18e3, 6500 * s * (.5 + d)), a), b(t.gain, a, .9 * l, c, .004)) : i === "shaker" ? (u(n.frequency, Math.min(16e3, (1500 + d * 6e3) * s), a), b(r.gain, a, .65 * l, c, .008)) : i === "metal" && C("metal", a, .3 * l, c, (e, t) => [
				440,
				623,
				1067,
				1573
			].map((n, r) => w(e, t, r ? "sine" : "triangle", n * s, r ? .15 + d * .7 : 1)));
		};
	}
	return {
		trigger(e, t, n, r = 1) {
			u(f(e).pan, n[`${e}Pan`] ?? 0, t), E(e, t, r === 1 ? n : {
				...n,
				[`${e}Level`]: (n[`${e}Level`] ?? 1) * r
			});
		},
		cancelScheduled(e) {
			for (let t of [...o]) if (t.start >= e) {
				for (let n of t.sources) n.stop(e);
				S(t);
			}
			s.clear();
			for (let t of o) {
				if (t.chokeAt !== void 0 && t.chokeAt >= e) {
					hr(t.vca.gain, e), t.vca.gain.setTargetAtTime(0, e, t.decay / 4.6), t.end = t.naturalEnd, t.chokeAt = void 0;
					for (let e of t.sources) e.stop(t.end);
				}
				(!s.has(t.voice) || s.get(t.voice).start < t.start) && s.set(t.voice, t);
			}
			for (let t of l) t.cancelScheduledValues(e);
			for (let [t, n] of y) {
				let r = n.filter((t) => t.time < e).at(-1);
				hr(t, e), r ? t.setTargetAtTime(0, Math.max(e, r.time + r.rise * 5), r.decay / 4.6) : t.setValueAtTime(0, e), y.set(t, r ? [r] : []);
			}
		},
		dispose() {
			for (let e of o) for (let t of e.sources) t.stop();
			for (let e of [...o]) S(e);
			s.clear();
		}
	};
}
// src/audio/strike.ts
var yr = 28e3, br = /* @__PURE__ */ new Map();
function xr(e) {
	let t = br.get(e);
	if (t) return t;
	let n = Be.findIndex((t) => t.id === e);
	if (n < 0) throw Error(`Unknown STRIKE voice: ${e}`);
	let r = [
		"crash",
		"ride",
		"open"
	].includes(e), i = Math.ceil(yr * (r ? 3 : 1.5)), a = new Float32Array(i), o = 7103 + n * 197, s = 0, c = 0, l = 0, u = (e, t) => Math.sin(2 * Math.PI * e * t), d = {
		lowTom: 100,
		midTom: 142,
		highTom: 195,
		lowConga: 210,
		highConga: 310
	};
	for (let t = 0; t < i; t++) {
		o ^= o << 13, o ^= o >>> 17, o ^= o << 5;
		let n = (o >>> 0) / 2 ** 31 - 1, r = t / yr;
		s = .65 * s + .35 * n;
		let f = n - c;
		c = n;
		let p = 0;
		if (e === "kick") l += 2 * Math.PI * (54 + 120 * Math.exp(-r * 80)) / yr, p = Math.sin(l) * Math.exp(-r * 9) + .28 * s * Math.exp(-r * 170) + .1 * u(105, r) * Math.exp(-r * 25);
		else if (e === "snare") p = (.55 * u(185, r) + .28 * u(331, r)) * Math.exp(-r * 25) + .75 * (n - s) * Math.exp(-r * 15);
		else if (e === "rim") p = (u(420, r) + .65 * u(1750, r) + .35 * u(3100, r)) * Math.exp(-r * 85) + n * .25 * Math.exp(-r * 300);
		else if (e === "clap") {
			let e = [
				0,
				.011,
				.024
			].reduce((e, t) => e + (r >= t ? Math.exp(-(r - t) * 230) : 0), 0);
			p = (n - s) * (e + (r > .035 ? .65 * Math.exp(-(r - .035) * 16) : 0));
		} else if (e in d) {
			let t = d[e], n = e.includes("Conga");
			l += 2 * Math.PI * t * (1 + .55 * Math.exp(-r * 55)) / yr, p = (Math.sin(l) + .3 * u(t * (n ? 2.14 : 1.59), r)) * Math.exp(-r * (n ? 14 : 8)) + .22 * s * Math.exp(-r * 95);
		} else if (e === "bell") p = (u(540, r) + .65 * u(800, r) + .22 * u(1620, r)) * Math.exp(-r * 11);
		else {
			let t = [
				3421,
				4517,
				5683,
				7129,
				9181
			].reduce((t, n, i) => t + u(n * (e === "ride" ? .68 : 1), r) / (i + 2), 0), n = e === "hat" ? 34 : e === "open" ? 5 : e === "crash" ? 1.8 : e === "ride" ? 2.3 : e === "cabasa" ? 32 : 16;
			p = ((e === "cabasa" ? 0 : .4) * t + (e === "ride" ? .2 : .65) * f) * Math.exp(-r * n), e === "tambourine" && (p *= .65 + .35 * u(85, r)), e === "crash" && (p *= Math.min(1, r * 180));
		}
		let m = Math.tanh(p), h = Math.sign(m) * Math.log1p(255 * Math.abs(m)) / Math.log(256), g = Math.round(h * 127) / 127;
		a[t] = Math.sign(g) * Math.expm1(Math.abs(g) * Math.log(256)) / 255 * Math.min(1, t / 12) * Math.min(1, (i - 1 - t) / 128);
	}
	return br.set(e, a), a;
}
var Sr = {
	rate: yr,
	sample: xr,
	chokedBy: { open: ["hat"] }
}, Cr = (e, t) => wr(e, t, Sr);
function wr(e, t, { rate: n, sample: r, chokedBy: i = {}, peak: a = 1.6, tone: o = (e) => 700 * 20 ** e }) {
	let s = /* @__PURE__ */ new Map(), c = /* @__PURE__ */ new Set(), l = (e) => [e, ...i[e] ?? []], u = (e) => {
		if (c.delete(e)) for (let t of [
			e.source,
			e.gain,
			e.filter,
			e.pan
		]) t.disconnect();
	};
	function d(t) {
		let n = e.currentTime, r = /* @__PURE__ */ new Map();
		for (let e of c) {
			let t = r.get(e.voice) ?? [];
			t.push(e), r.set(e.voice, t);
		}
		for (let e of r.values()) e.sort((e, t) => e.start - t.start);
		for (let [e, i] of r) if (!t || l(e).includes(t)) for (let t of i) {
			let i = l(e).flatMap((e) => r.get(e) ?? []).filter((n) => n.start > t.start || n.voice !== e && n.start === t.start).reduce((e, t) => !e || t.start < e.start ? t : e, void 0)?.start ?? Infinity, a = t.gain.gain, o = (e) => t.peak * Math.min(1, Math.max(0, e - t.start) / .001) * Math.exp(-Math.max(0, e - t.start - .001) * 4.6 / t.decay);
			a.cancelScheduledValues(n), n < t.start + .001 ? (a.setValueAtTime(o(n), n), a.setValueAtTime(0, Math.max(n, t.start)), a.linearRampToValueAtTime(t.peak, t.start + .001)) : a.setValueAtTime(i < n ? o(i) * Math.max(0, 1 - (n - i) / .004) : o(n), n), a.setTargetAtTime(0, Math.max(n, t.start + .001), t.decay / 4.6), i >= n && i < t.end && (a.cancelScheduledValues(i), a.setValueAtTime(o(i), i), a.linearRampToValueAtTime(0, i + .004)), t.source.stop(Math.max(n, Math.min(t.end, i + .005)));
		}
	}
	return {
		trigger(i, l, f, p = 1) {
			let m = s.get(i);
			if (!m) {
				let t = r(i);
				m = e.createBuffer(1, t.length, n), m.copyToChannel(new Float32Array(t), 0), s.set(i, m);
			}
			let h = e.createBufferSource(), g = e.createGain(), _ = e.createBiquadFilter(), v = e.createStereoPanner();
			h.buffer = m, h.playbackRate.value = 2 ** (f[`${i}Tune`] / 12), _.type = "lowpass", _.frequency.value = Math.min(2e4, o(f[`${i}Tone`])), _.Q.value = -3.01, v.pan.value = f[`${i}Pan`], g.gain.value = 0, h.connect(_).connect(g).connect(v).connect(t);
			let y = {
				voice: i,
				start: l,
				end: l + Math.min(m.duration / h.playbackRate.value, f[`${i}Decay`] * 2) + .01,
				peak: f[`${i}Level`] * a * p,
				decay: f[`${i}Decay`],
				source: h,
				gain: g,
				filter: _,
				pan: v
			};
			h.onended = () => u(y), c.add(y), h.start(l), d(i);
		},
		cancelScheduled(e) {
			for (let t of [...c]) t.start >= e && (t.source.stop(e), u(t));
			d();
		},
		dispose() {
			for (let e of [...c]) e.source.stop(), u(e);
			s.clear();
		}
	};
}
// src/audio/poly.ts
function Tr(e, t) {
	let n = !1, r;
	return (i, a) => {
		if (clearTimeout(r), r = void 0, i && !n) e.connect(t), n = !0;
		else if (!i && n) {
			let i = () => {
				r = void 0, n = !1;
				try {
					e.disconnect(t);
				} catch {}
			};
			a ? i() : r = setTimeout(i, 100);
		}
	};
}
var Z = class {
	voices;
	constructor(e = 5) {
		this.voices = Array.from({ length: e }, () => ({
			key: null,
			start: -Infinity,
			releaseAt: -Infinity,
			freeAt: -Infinity
		}));
	}
	allocate(e, t = /* @__PURE__ */ new Set()) {
		let n = this.voices.map((e, t) => ({
			voice: e,
			index: t
		})).filter(({ index: e }) => !t.has(e)), r = (e, t) => e.reduce((e, n) => t(n.voice) < t(e.voice) ? n : e).index, i = n.filter(({ voice: t }) => t.freeAt <= e), a = n.filter(({ voice: t }) => t.releaseAt <= e);
		return i.length ? r(i, (e) => e.freeAt) : a.length ? r(a, (e) => e.releaseAt) : r(n, (e) => e.start);
	}
	start(e, t, n) {
		Object.assign(this.voices[e], {
			key: t,
			start: n,
			releaseAt: Infinity,
			freeAt: Infinity
		});
	}
	release(e, t, n) {
		return this.voices.flatMap((r, i) => {
			if (n !== void 0 && r.key !== n || r.releaseAt <= e) return [];
			let a = r.start > e;
			return Object.assign(r, {
				start: Math.min(r.start, e),
				releaseAt: e,
				freeAt: e + t
			}), [{
				index: i,
				pending: a
			}];
		});
	}
}, Er = (e, t) => Math.sin(2 * Math.PI * e * t);
function Dr(e, t, n) {
	let r = new Float32Array(Math.ceil(e * t));
	return {
		data: r,
		each(t) {
			let i = n, a = 0;
			for (let n = 0; n < r.length; n++) {
				i ^= i << 13, i ^= i >>> 17, i ^= i << 5;
				let o = (i >>> 0) / 2 ** 31 - 1;
				a = .7 * a + .3 * o, r[n] = t(n / e, {
					noise: o,
					low: a,
					high: o - a,
					sin: Er
				}) * Math.min(1, n / 8) * Math.min(1, (r.length - 1 - n) / 256);
			}
		}
	};
}
function Or(e, t) {
	let n = 0;
	for (let t of e) n = Math.max(n, Math.abs(t));
	if (n > 0) for (let r = 0; r < e.length; r++) e[r] *= t / n;
}
// src/audio/forge.ts
var kr = 44100, Ar = /* @__PURE__ */ new Map();
function Q(e, t, n, r) {
	let i = r, a = () => (i = i * 16807 % 2147483647, i / 2147483647);
	return Array.from({ length: e }, () => ({
		frequency: t * (n / t) ** a(),
		level: .4 + a(),
		decay: .6 + a(),
		phase: a() * 2 * Math.PI
	}));
}
function jr(e) {
	let t = Ar.get(e);
	if (t) return t;
	let n = Ke.findIndex((t) => t.id === e);
	if (n < 0) throw Error(`Unknown FORGE voice: ${e}`);
	let { data: r, each: i } = Dr(kr, {
		crash: 4,
		china: 3,
		ride: 4,
		open: 2,
		anvil: 2,
		lowTom: 1.6,
		highTom: 1.3,
		kick: 1.2,
		snare: 1
	}[e] ?? .5, 9241 + n * 173), a = {
		hat: [
			26,
			3e3,
			14e3
		],
		pedal: [
			26,
			3e3,
			14e3
		],
		open: [
			30,
			2600,
			13e3
		],
		crash: [
			44,
			1800,
			12500
		],
		china: [
			40,
			1100,
			9e3
		],
		ride: [
			28,
			2400,
			11e3
		]
	}[e], o = a ? Q(a[0], a[1], a[2], 77 + n * 31) : [], s = o.map((e) => Math.sin(e.phase)), c = o.map((e) => Math.cos(e.phase)), l, u = (e, t) => {
		l ??= o.map((e) => ({
			cos: Math.cos(2 * Math.PI * e.frequency / kr),
			sin: Math.sin(2 * Math.PI * e.frequency / kr),
			fall: Math.exp(-t * e.decay / kr)
		}));
		let n = 0;
		for (let e = 0; e < o.length; e++) {
			let { cos: t, sin: r, fall: i } = l[e], a = s[e], u = c[e];
			n += o[e].level * a, s[e] = (a * t + u * r) * i, c[e] = (u * t - a * r) * i;
		}
		return n / o.length;
	}, d = 0, f = 0;
	return i((t, { noise: n, high: r, sin: i }) => {
		if (f = .55 * f + .45 * r, e === "kick") {
			d += 2 * Math.PI * (52 + 88 * Math.exp(-t * 35)) / kr;
			let e = Math.sin(d) * Math.exp(-t * 6.5), n = r * Math.exp(-t * 600) + .5 * i(3200, t) * Math.exp(-t * 300);
			return Math.tanh(2.6 * (e + .55 * n));
		}
		if (e === "snare") {
			let e = i(190, t) * Math.exp(-t * 22) + .6 * i(287, t) * Math.exp(-t * 28) + .35 * i(412, t) * Math.exp(-t * 35), r = f * Math.exp(-t * 10), a = n * Math.exp(-t * 220);
			return Math.tanh(1.9 * (.7 * e + 1.1 * r + .6 * a));
		}
		return e === "lowTom" || e === "highTom" ? (d += 2 * Math.PI * (e === "lowTom" ? 82 : 132) * (1 + .3 * Math.exp(-t * 30)) / kr, Math.tanh(1.5 * ((Math.sin(d) + .25 * Math.sin(1.52 * d)) * Math.exp(-t * (e === "lowTom" ? 4.5 : 5.5)) + .4 * r * Math.exp(-t * 300)))) : e === "anvil" ? [
			[1, 4],
			[2.76, 6],
			[5.4, 9],
			[8.93, 13]
		].reduce((e, [n, r], a) => e + i(520 * n, t) * Math.exp(-t * r) / (a + 1), 0) + .6 * r * Math.exp(-t * 500) : e === "hat" ? .7 * u(t, 40) + .55 * f * Math.exp(-t * 55) + .5 * r * Math.exp(-t * 900) : e === "pedal" ? (.6 * u(t, 30) + .4 * f * Math.exp(-t * 35)) * Math.min(1, t * 400) : e === "open" ? .7 * u(t, 3.2) + .45 * f * Math.exp(-t * 4.5) + .4 * r * Math.exp(-t * 700) : e === "crash" ? (.8 * u(t, 1.3) + .6 * f * Math.exp(-t * 2.2)) * Math.min(1, t * 250) : e === "china" ? (.8 * u(t, 2.2) * (1 + .6 * i(370, t)) + .6 * f * Math.exp(-t * 3)) * Math.min(1, t * 300) : .55 * u(t, 1.1) + (.5 * i(3150, t) + .35 * i(4270, t)) * Math.exp(-t * 4) + .15 * f * Math.exp(-t * 2) + .4 * r * Math.exp(-t * 800);
	}), Or(r, .9), Ar.set(e, r), r;
}
function Mr(e) {
	let t = e.createBuffer(2, Math.ceil(e.sampleRate * .34), e.sampleRate), n = 31337;
	for (let r = 0; r < 2; r++) {
		let i = t.getChannelData(r);
		for (let t = 0; t < i.length; t++) {
			n ^= n << 13, n ^= n >>> 17, n ^= n << 5;
			let r = t / e.sampleRate;
			i[t] = ((n >>> 0) / 2 ** 31 - 1) * Math.exp(-r * 3) * Math.min(1, (i.length - 1 - t) / 64) * .35;
		}
	}
	return t;
}
var Nr = {
	rate: kr,
	sample: jr,
	chokedBy: { open: ["hat", "pedal"] },
	peak: 1.4,
	tone: (e) => 1200 * 16 ** e
};
function Pr(e, t, n) {
	let r = n(e.createGain()), i = n(e.createGain()), a = n(e.createWaveShaper()), o = n(e.createGain()), s = n(e.createConvolver()), c = n(e.createGain());
	a.curve = Float32Array.from({ length: 2049 }, (e, t) => {
		let n = (t / 1024 - 1) * 6;
		return Math.max(-1, Math.min(1, n > 0 ? Math.tanh(n) : Math.tanh(1.4 * n) * .9));
	}), a.oversample = "2x", r.connect(i).connect(t), a.connect(o).connect(t), s.buffer = Mr(e), s.connect(c).connect(t);
	let l = Tr(r, a), u = Tr(i, s), d = 0, f, p = () => {
		d < Ke.length && (jr(Ke[d++].id), f = setTimeout(p, 0));
	};
	f = setTimeout(p, 0);
	let m = !1;
	return {
		input: r,
		classic: () => wr(e, r, Nr),
		dispose() {
			clearTimeout(f);
		},
		apply(t) {
			let n = (t, n) => {
				m ? t.setTargetAtTime(n, e.currentTime, .01) : t.value = n;
			};
			l(t.drive > 0, !m), u(t.room > 0, !m), n(i.gain, 1 - .45 * t.drive), n(o.gain, .75 * t.drive), n(c.gain, t.room * .9), m = !0;
		}
	};
}
// src/audio/prism-processor.js?raw
var Fr = "/** Self-contained phase-modulation DSP, imported directly by tests and as inline source by the worklet loader. */\nexport const ALGORITHMS = [\n  {inputs: [[1], [], [3], [], [5], []], carriers: [0, 2, 4]},\n  {inputs: [[1], [2], [], [4], [5], []], carriers: [0, 3]},\n  {inputs: [[1], [2], [3], [4], [5], []], carriers: [0]},\n  {inputs: [[3], [3], [3], [4, 5], [], []], carriers: [0, 1, 2]},\n  {inputs: [[1, 2], [3], [4], [], [5], []], carriers: [0]},\n  {inputs: [[], [], [], [], [], []], carriers: [0, 1, 2, 3, 4, 5]},\n];\nconst TAU = 2 * Math.PI, QUANTUM = 128;\n/** Blocks a voice's ladder keeps running after the voice ends, so its tail rings out (about 23 ms). */\nconst FILTER_TAIL = 8;\n/** The gain that matches the Ladder filter's level to Off at PRISM's default settings. */\nexport const FILTER_LEVEL = 1.02;\n/**\n * `makeFilter`, when given, makes one Rust ladder (a LadderDSP) per voice for the Filter section; without it PRISM plays\n * unfiltered, as it did before the section existed.\n */\nexport class PrismDSP {\n  constructor(rate, makeFilter) {\n    this.rate = rate; this.events = []; this.params = {}; this.level = 0; this.disposed = false;\n    this.makeFilter = makeFilter; this.filters = []; this.wet = 0; this.fade = 1 - Math.exp(-1 / (0.008 * rate));\n    if (makeFilter) {\n      this.voiceOut = Array.from({length: 16}, () => new Float32Array(QUANTUM));\n      this.voiceDetune = Array.from({length: 16}, () => new Float32Array(QUANTUM));\n      this.used = new Uint8Array(16); this.tails = new Uint8Array(16);\n      this.dry = new Float32Array(QUANTUM); this.wets = new Float32Array(QUANTUM); this.levels = new Float32Array(QUANTUM);\n    }\n    this.voices = Array.from({length: 16}, () => ({key: null, start: -Infinity, released: -Infinity, free: -Infinity,\n      phase: new Float64Array(6), env: new Float64Array(6), stage: new Uint8Array(6), attackStep: new Float64Array(6), releaseStep: new Float64Array(6), values: new Float64Array(6), frequency: 0, velocity: 1, feedback: 0, lastFeedback: 0}));\n  }\n  enqueue(event) {\n    if (event.type === 'off') this.events = this.events.filter(e => !(e.time >= event.time && (event.key === undefined || e.key === event.key) && (e.type === 'on' || e.type === 'off')));\n    this.events.push(event); this.events.sort((a, b) => a.time - b.time);\n  }\n  release(time, key) {\n    for (const v of this.voices) if (v.key !== null && (key === undefined || v.key === key) && v.released === Infinity) {\n      v.released = time; v.free = time + Math.max(...this.ops.map(o => o.release));\n      for (let i = 0; i < 6; i++) {v.stage[i] = 3; v.releaseStep[i] = v.env[i] / (this.ops[i].release * this.rate);}\n    }\n  }\n  apply(event) {\n    if (event.type === 'params') {\n      this.params = event.params;\n      this.ops = Array.from({length: 6}, (_, i) => {const id = `op${i + 1}`, p = this.params; return {\n        ratio: p[`${id}Ratio`] * 2 ** (p[`${id}Detune`] / 1200), level: p[`${id}Level`], attack: p[`${id}Attack`],\n        decay: Math.exp(-1 / (p[`${id}Decay`] * this.rate / 4)), sustain: p[`${id}Sustain`], release: p[`${id}Release`],\n      };});\n    } else if (event.type === 'off') this.release(event.time, event.key);\n    else if (event.type === 'on' && this.ops) {\n      this.release(event.time, event.key);\n      const taken = new Set();\n      for (const note of event.notes) {\n        const available = this.voices.filter(v => !taken.has(v));\n        const silent = available.filter(v => v.free <= event.time), released = available.filter(v => v.released <= event.time);\n        const candidates = silent.length ? silent : released.length ? released : available;\n        const field = silent.length ? 'free' : released.length ? 'released' : 'start';\n        const v = candidates.reduce((a, b) => b[field] < a[field] ? b : a);\n        taken.add(v);\n        if (v.free <= event.time) {v.phase.fill(0); v.env.fill(0); v.feedback = 0; v.lastFeedback = 0;}\n        v.key = event.key; v.start = event.time; v.free = Infinity; v.released = Infinity;\n        v.frequency = 440 * 2 ** ((note - 69) / 12); v.cents = (note - 60) * 100; v.velocity = event.velocity;\n        for (let i = 0; i < 6; i++) {v.stage[i] = 0; v.attackStep[i] = (1 - v.env[i]) / (this.ops[i].attack * this.rate);}\n      }\n    }\n  }\n  render(output, startFrame, pitch, brightness) {\n    if (this.disposed) {output.fill(0); return;}\n    // The per-voice filter buffers hold one render quantum, so longer renders (tests) go a quantum at a time.\n    if (this.makeFilter && output.length > QUANTUM) {\n      for (let i = 0; i < output.length; i += QUANTUM) this.render(output.subarray(i, i + QUANTUM), startFrame + i, pitch?.subarray(i, i + QUANTUM), brightness?.subarray(i, i + QUANTUM));\n      return;\n    }\n    // The Filter section crossfades in and out over 8 ms. While it is fully off, the original unfiltered path runs.\n    const filtering = !!this.makeFilter && (this.params.filterModel === 1 || this.wet > 0);\n    if (filtering) for (let i = 0; i < 16; i++) {this.voiceOut[i].fill(0); this.voiceDetune[i].fill(this.voiceDetune[i][QUANTUM - 1]);}\n    for (let n = 0; n < output.length; n++) {\n      const time = (startFrame + n) / this.rate;\n      while (this.events.length && this.events[0].time <= time) this.apply(this.events.shift());\n      if (!this.ops) {output[n] = 0; continue;}\n      const p = this.params, algorithm = ALGORITHMS[p.algorithm];\n      const bend = Math.max(-9600, Math.min(9600, (pitch?.[n] ?? 0) + Math.sin(TAU * p.lfoRate * time) * p.lfoDepth * 100));\n      const tune = 2 ** (bend / 1200);\n      const color = Math.max(0, Math.min(4, p.brightness + (brightness?.[n] ?? 0)));\n      let sum = 0;\n      for (let index = 0; index < this.voices.length; index++) {\n        const v = this.voices[index];\n        if (v.free <= time) continue;\n        const touch = 1 - p.velocity + p.velocity * v.velocity;\n        for (let i = 5; i >= 0; i--) {\n          const op = this.ops[i];\n          if (v.stage[i] === 0) {v.env[i] = Math.min(1, v.env[i] + v.attackStep[i]); if (v.env[i] >= 1) v.stage[i] = 1;}\n          else if (v.stage[i] === 1) v.env[i] = op.sustain + (v.env[i] - op.sustain) * op.decay;\n          else v.env[i] = Math.max(0, v.env[i] - v.releaseStep[i]);\n          const frequency = Math.min(this.rate * 0.45, v.frequency * tune * op.ratio);\n          // The step is under half a turn, so subtracting a turn wraps exactly as the remainder would.\n          v.phase[i] += TAU * frequency / this.rate; if (v.phase[i] >= TAU) v.phase[i] -= TAU;\n          // A released operator at zero contributes nothing, so its sine is skipped.\n          if (v.env[i] === 0) {v.values[i] = 0; continue;}\n          let modulation = i === 5 ? (v.feedback + v.lastFeedback) * 0.5 * p.feedback * 3.5 : 0;\n          const inputs = algorithm.inputs[i];\n          for (let k = 0; k < inputs.length; k++) modulation += v.values[inputs[k]] * 5 * color * touch;\n          v.values[i] = Math.sin(v.phase[i] + modulation) * v.env[i] * op.level;\n        }\n        v.lastFeedback = v.feedback; v.feedback = v.values[5];\n        let voice = 0;\n        for (let k = 0; k < algorithm.carriers.length; k++) voice += v.values[algorithm.carriers[k]];\n        voice = voice / Math.sqrt(algorithm.carriers.length) * v.velocity;\n        sum += voice;\n        if (filtering) {\n          // Each voice's ladder follows its first carrier's envelope and its note, including bends.\n          this.voiceOut[index][n] = voice; this.used[index] = 1;\n          this.voiceDetune[index][n] = p.filterEnv * 4800 * v.env[0] + p.filterTrack * (v.cents + bend);\n        }\n      }\n      this.level += (p.level - this.level) * 0.003;\n      if (!filtering) {output[n] = sum * this.level * 0.18; continue;}\n      this.wet += ((p.filterModel === 1 ? 1 : 0) - this.wet) * this.fade;\n      if (this.wet < 1e-5 && p.filterModel !== 1) this.wet = 0;\n      this.dry[n] = sum; this.wets[n] = this.wet; this.levels[n] = this.level;\n    }\n    if (filtering) this.mixFiltered(output);\n  }\n\n  /** Runs each sounding voice (and each ringing tail) through its ladder and crossfades the result with the dry mix. */\n  mixFiltered(output) {\n    const p = this.params, n = output.length;\n    output.fill(0);\n    for (let i = 0; i < 16; i++) {\n      if (this.used[i]) this.tails[i] = FILTER_TAIL;\n      if (!this.tails[i]) continue;\n      const filter = (this.filters[i] ??= this.makeFilter()), buffer = this.voiceOut[i];\n      filter.render(buffer, buffer, p.filterCutoff, p.filterResonance, p.filterDrive, this.voiceDetune[i], 0);\n      for (let k = 0; k < n; k++) output[k] += buffer[k];\n      if (!this.used[i]) this.tails[i]--;\n      this.used[i] = 0;\n    }\n    for (let k = 0; k < n; k++) output[k] = (this.dry[k] * (1 - this.wets[k]) + output[k] * FILTER_LEVEL * this.wets[k]) * this.levels[k] * 0.18;\n  }\n\n  dispose() {\n    this.disposed = true; this.events = [];\n    for (const filter of this.filters) filter?.dispose();\n    this.filters = [];\n  }\n}\n// The guard lets unit tests import the exact processor DSP without an audio environment.\nif (typeof registerProcessor !== 'undefined') {\n  class PrismProcessor extends AudioWorkletProcessor {\n    constructor(options) {\n      // dsp-processor.js shares its ladder through the global scope; without the Rust DSP, PRISM plays unfiltered.\n      const module = options?.processorOptions?.module, Ladder = globalThis.RacklooseDSP?.LadderDSP;\n      super(); this.dsp = new PrismDSP(sampleRate, module && Ladder ? () => new Ladder(module, sampleRate) : undefined);\n      this.port.onmessage = ({data}) => {\n        if (data.type === 'flush') this.port.postMessage({id: data.id});\n        else if (data.type === 'dispose') this.dsp.dispose();\n        else this.dsp.enqueue(data);\n      };\n    }\n    process(inputs, outputs) {\n      this.dsp.render(outputs[0][0], currentFrame, inputs[0]?.[0], inputs[1]?.[0]);\n      return !this.dsp.disposed;\n    }\n  }\n  registerProcessor('rackloose-prism-v1', PrismProcessor);\n}\n", Ir = "/** Original behavioral models, not measured circuit replicas. See docs/studio-processors.md for calibration and sources. */\nexport const COHERE_ATTACKS = [0.0001, 0.0003, 0.001, 0.003, 0.01, 0.03];\nexport const COHERE_RELEASES = [0.1, 0.3, 0.6, 1.2];\nexport const TALON_RATIOS = [1, 2, 3, 4, 6, 10, 20, 100];\nexport const BRIT_LOW = [35, 60, 110, 220];\nexport const BRIT_MID = [360, 700, 1600, 3200, 4800, 7200];\nexport const BRIT_HP = [0, 50, 80, 160, 300];\nconst db = x => 10 ** (x / 20);\nconst unity = [1, 0, 0, 0, 0];\n\n/** Normalized biquads and one pole filters. A third-order Butterworth HP is a first order plus a Q=1 biquad. */\nexport function coefficients(type, frequency, gain, Q, rate) {\n  if (!frequency) return unity.slice();\n  const w = 2 * Math.PI * Math.min(frequency, rate * 0.45) / rate, c = Math.cos(w), s = Math.sin(w);\n  const A = 10 ** (gain / 40), alpha = s / (2 * Q), shelf = s * Math.sqrt(2 * A);\n  let b0, b1, b2, a0, a1, a2;\n  if (type === 'pole') {\n    const k = Math.tan(w / 2); return [1 / (1 + k), -1 / (1 + k), 0, (k - 1) / (k + 1), 0];\n  } else if (type === 'highpass') {\n    [b0, b1, b2, a0, a1, a2] = [(1 + c) / 2, -(1 + c), (1 + c) / 2, 1 + alpha, -2 * c, 1 - alpha];\n  } else if (type === 'bell') {\n    [b0, b1, b2, a0, a1, a2] = [1 + alpha * A, -2 * c, 1 - alpha * A, 1 + alpha / A, -2 * c, 1 - alpha / A];\n  } else if (type === 'low') {\n    [b0, b1, b2, a0, a1, a2] = [A * (A + 1 - (A - 1) * c + shelf), 2 * A * (A - 1 - (A + 1) * c), A * (A + 1 - (A - 1) * c - shelf), A + 1 + (A - 1) * c + shelf, -2 * (A - 1 + (A + 1) * c), A + 1 + (A - 1) * c - shelf];\n  } else {\n    [b0, b1, b2, a0, a1, a2] = [A * (A + 1 + (A - 1) * c + shelf), -2 * A * (A - 1 + (A + 1) * c), A * (A + 1 + (A - 1) * c - shelf), A + 1 - (A - 1) * c + shelf, 2 * (A - 1 - (A + 1) * c), A + 1 - (A - 1) * c - shelf];\n  }\n  return [b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0];\n}\nexport function britFilters(p, rate) {\n  const hp = BRIT_HP[p.hpf] ?? 0;\n  return [coefficients('pole', hp, 0, 1, rate), coefficients('highpass', hp, 0, 1, rate),\n    coefficients('low', BRIT_LOW[p.lfFreq] ?? 110, p.lfGain, 0.7, rate),\n    coefficients('bell', BRIT_MID[p.midFreq] ?? 1600, p.midGain, 0.75, rate), coefficients('high', 12000, p.hfGain, 0.7, rate)];\n}\nexport function britResponse(p, frequency, rate = 48000) {\n  if (p.active) return 0;\n  const w = 2 * Math.PI * frequency / rate;\n  const magnitude = (a, b, c) => Math.hypot(a + b * Math.cos(w) + c * Math.cos(2 * w), b * Math.sin(w) + c * Math.sin(2 * w));\n  return britFilters(p, rate).reduce((sum, [b0, b1, b2, a1, a2]) => sum + 20 * Math.log10(magnitude(b0, b1, b2) / magnitude(1, a1, a2)), 0);\n}\n\n/** Each TALON mode has its own threshold and knee; Input drives a fixed characteristic instead of moving a threshold. */\nfunction curveSettings(type, p) {\n  let ratio, threshold, knee;\n  if (type === 'cohere') {\n    ratio = [2, 4, 10][p.ratio] ?? 4;\n    threshold = p.threshold + [-3, 0, 2][p.ratio]; knee = [9, 6, 3][p.ratio];\n  } else {\n    ratio = TALON_RATIOS[p.ratio] ?? 6;\n    threshold = [-18, -26, -24, -22, -20, -18, -16, -18][p.ratio];\n    knee = [0, 15, 12, 9, 6, 4, 2, 3][p.ratio];\n    if (p.fierce) {ratio = Math.max(12, ratio * 2); threshold -= 3; knee = 2;}\n  }\n  return [1 - 1 / ratio, threshold, knee];\n}\nfunction curveGain(level, slope, threshold, knee) {\n  if (!slope) return 0;\n  const over = level - threshold;\n  return over <= -knee / 2 ? 0 : over >= knee / 2 ? -over * slope : -slope * (over + knee / 2) ** 2 / (2 * knee);\n}\nexport function compressionCurve(type, level, p) {return curveGain(level, ...curveSettings(type, p));}\n\nclass Filter {\n  constructor(rate) {this.c = unity.slice(); this.target = unity.slice(); this.z1 = 0; this.z2 = 0; this.smooth = 1 - Math.exp(-1 / (rate * 0.008));}\n  set(c, initial) {this.target = c; if (initial) this.c = c.slice();}\n  run(x) {\n    const c = this.c;\n    for (let i = 0; i < 5; i++) c[i] += (this.target[i] - c[i]) * this.smooth;\n    const y = c[0] * x + this.z1;\n    this.z1 = c[1] * x - c[3] * y + this.z2; this.z2 = c[2] * x - c[4] * y;\n    return y;\n  }\n}\n\n// 4x interpolation/decimation of the nonlinear residual only: linear audio keeps its full bandwidth.\n// Two symmetric 49-tap Blackman-windowed sinc FIRs give exactly 12 base-rate samples of delay.\nexport const FIR = Float64Array.from({length: 49}, (_, i) => {\n  const n = i - 24, cutoff = 0.1125;\n  return (n ? Math.sin(2 * Math.PI * cutoff * n) / (Math.PI * n) : 2 * cutoff) * (0.42 - 0.5 * Math.cos(2 * Math.PI * i / 48) + 0.08 * Math.cos(4 * Math.PI * i / 48));\n});\nconst total = FIR.reduce((sum, x) => sum + x, 0); for (let i = 0; i < FIR.length; i++) FIR[i] /= total;\nclass Fir {\n  constructor() {this.buffer = new Float64Array(49); this.index = 0;}\n  /** Stores `x` without computing an output, for decimation steps whose output is discarded. */\n  push(x) {this.buffer[this.index] = x; this.index = (this.index + 1) % 49;}\n  run(x) {\n    this.buffer[this.index] = x; let sum = 0, at = this.index;\n    for (let i = 0; i < 49; i++) {sum += FIR[i] * this.buffer[at]; if (--at < 0) at = 48;}\n    this.index = (this.index + 1) % 49; return sum;\n  }\n}\n/**\n * The FIR over a 4x zero-stuffed signal, computed polyphase: phase `i` reads only the taps that meet a real sample,\n * in the same order, so it matches the full filter exactly at a quarter of the work.\n */\nclass Interpolator {\n  constructor() {this.buffer = new Float64Array(13); this.index = 0;}\n  push(x) {this.index = this.index ? this.index - 1 : 12; this.buffer[this.index] = x;}\n  run(phase) {\n    let sum = 0, at = this.index;\n    for (let k = phase; k < 49; k += 4) {sum += FIR[k] * this.buffer[at]; if (++at > 12) at = 0;}\n    return sum;\n  }\n}\nexport const STUDIO_LATENCY = 12;\nclass Delay {\n  constructor() {this.buffer = new Float64Array(STUDIO_LATENCY); this.index = 0;}\n  run(x) {const y = this.buffer[this.index]; this.buffer[this.index] = x; this.index = (this.index + 1) % this.buffer.length; return y;}\n}\nexport class Color {\n  constructor(rate) {this.up = new Interpolator(); this.down = new Fir(); this.clean = new Delay(); this.previous = 0; this.blocked = 0; this.dc = Math.exp(-2 * Math.PI * 5 / rate);}\n  run(x, amount, bias) {\n    let residual = 0;\n    const offset = Math.tanh(bias), slope = amount * (1 - offset * offset);\n    this.up.push(x * 4);\n    for (let i = 0; i < 4; i++) {\n      const up = this.up.run(i);\n      const shaped = (Math.tanh(amount * up + bias) - offset) / slope;\n      // Only every fourth decimated sample is kept, so the others are stored without being filtered.\n      if (i === 0) residual = this.down.run(shaped - up); else this.down.push(shaped - up);\n    }\n    // AC coupling of the nonlinear residual removes the DC generated by asymmetric coloration.\n    this.blocked = residual - this.previous + this.dc * this.blocked; this.previous = residual;\n    return this.clean.run(x) + this.blocked;\n  }\n}\n\nexport class StudioDSP {\n  constructor(type, rate) {\n    this.type = type; this.rate = rate; this.params = null; this.events = []; this.disposed = false; this.reduction = 0;\n    this.gain = [0, 0]; this.memory = [0, 0]; this.input = 1; this.output = 1; this.wet = 1; this.drive = 0;\n    this.smooth = 1 - Math.exp(-1 / (rate * 0.008));\n    this.channels = Array.from({length: 2}, () => ({filters: Array.from({length: 5}, () => new Filter(rate)),\n      hp: new Filter(rate), emphasis: new Filter(rate), audioPole: new Filter(rate), audioHp: new Filter(rate), color: new Color(rate), dry: new Delay(), clean: new Delay(), amount: 0.15, bias: 0}));\n  }\n  enqueue(event) {this.events.push(event); this.events.sort((a, b) => a.time - b.time);}\n  configure(p) {\n    const initial = !this.params; this.params = {...p};\n    this.inputTarget = db(this.type === 'talon' ? p.input : 0); this.outputTarget = db(p.output);\n    this.wetTarget = p.active ? 0 : 1; this.driveTarget = p.drive ?? 0;\n    if (initial) {this.input = this.inputTarget; this.output = this.outputTarget; this.wet = this.wetTarget; this.drive = this.driveTarget;}\n    if (this.type !== 'brit') {\n      this.curveTarget = curveSettings(this.type, p); this.linkTarget = this.type === 'cohere' ? 1 : p.link;\n      this.attackTarget = this.type === 'cohere' ? COHERE_ATTACKS[p.attack] : p.attack;\n      this.releaseTarget = this.type === 'cohere' ? COHERE_RELEASES[p.release] ?? 0.3 : p.release;\n      if (initial) {this.curve = this.curveTarget.slice(); this.link = this.linkTarget; this.attack = this.attackTarget; this.release = this.releaseTarget;}\n    }\n    for (const channel of this.channels) {\n      if (this.type === 'brit') britFilters(p, this.rate).forEach((c, i) => channel.filters[i].set(c, initial));\n      const hp = this.type === 'cohere' ? [0, 30, 60, 106, 125, 185][p.scHpf] : p.detectorHp ? 80 : 0;\n      channel.hp.set(coefficients('highpass', hp, 0, Math.SQRT1_2, this.rate), initial);\n      channel.emphasis.set(coefficients('bell', 6000, p.detectorBand ? 10 : 0, 1, this.rate), initial);\n      // Third-order Bessel HP, normalized to -3 dB at 65 Hz. Distinct from the detector filter.\n      channel.audioPole.set(coefficients('pole', p.audioHp ? 65 * 0.754 : 0, 0, 1, this.rate), initial);\n      channel.audioHp.set(coefficients('highpass', p.audioHp ? 65 * 0.691 : 0, 0, 0.691, this.rate), initial);\n      if (initial && this.type === 'talon') {channel.amount = [0.15, 0.8, 1.5][p.color]; channel.bias = p.color === 1 ? 0.3 : 0;}\n    }\n  }\n  envelope(level, channel) {\n    const p = this.params, target = curveGain(level, this.curve[0], this.curve[1], this.curve[2]), current = this.gain[channel];\n    // A slow reservoir makes Auto and Opto depend on both the depth and duration of preceding compression.\n    this.memory[channel] += (Math.max(0, -current) - this.memory[channel]) * (1 - Math.exp(-1 / (this.rate * 0.6)));\n    let release = this.release;\n    if (this.type === 'cohere' && p.release === 4) release = 0.1 + Math.min(1.1, this.memory[channel] * 0.09);\n    if (this.type === 'talon') {\n      if (p.ratio === 5) release = Math.min(20, this.release * (1 + this.memory[channel] * 0.9));\n      else if (p.ratio === 7) release *= 0.45 + Math.min(1.5, Math.max(0, -current) / 15);\n      else release *= [1, 1.15, 1.05, 1, 0.9, 1, 0.8, 1][p.ratio];\n      if (p.ratio !== 5) release = Math.min(3.5, release);\n      if (p.fierce) release *= 0.65;\n    }\n    const seconds = target < current ? this.attack : release;\n    this.gain[channel] += (target - current) * (1 - Math.exp(-1 / (seconds * this.rate)));\n    return db(this.gain[channel]);\n  }\n  render(inputs, outputs, startFrame = 0) {\n    if (this.disposed) {outputs.forEach(out => out.fill(0)); return;}\n    const frames = outputs[0].length;\n    for (let n = 0; n < frames; n++) {\n      const time = (startFrame + n) / this.rate;\n      while (this.events.length && this.events[0].time <= time) this.configure(this.events.shift().params);\n      if (!this.params) {outputs.forEach(out => {out[n] = 0;}); continue;}\n      const p = this.params;\n      this.input += (this.inputTarget - this.input) * this.smooth; this.output += (this.outputTarget - this.output) * this.smooth;\n      this.wet += (this.wetTarget - this.wet) * this.smooth; this.drive += (this.driveTarget - this.drive) * this.smooth;\n      const left = inputs[0]?.[n] ?? 0, right = inputs[1]?.[n] ?? left;\n      const l = left * this.input, r = right * this.input;\n      let gainL = 1, gainR = 1;\n      if (this.type !== 'brit') {\n        for (let i = 0; i < 3; i++) this.curve[i] += (this.curveTarget[i] - this.curve[i]) * this.smooth;\n        this.link += (this.linkTarget - this.link) * this.smooth;\n        this.attack += (this.attackTarget - this.attack) * this.smooth; this.release += (this.releaseTarget - this.release) * this.smooth;\n        const a = this.channels[0], b = this.channels[1];\n        const levelL = 20 * Math.log10(Math.max(1e-12, Math.abs(a.emphasis.run(a.hp.run(l)))));\n        const levelR = 20 * Math.log10(Math.max(1e-12, Math.abs(b.emphasis.run(b.hp.run(r)))));\n        const dominant = Math.max(levelL, levelR);\n        this.envelope(levelL + this.link * (dominant - levelL), 0); this.envelope(levelR + this.link * (dominant - levelR), 1);\n        // Converge existing independent histories continuously when linking, never copy one channel's gain instantly.\n        const commonGain = Math.min(this.gain[0], this.gain[1]), commonMemory = Math.max(this.memory[0], this.memory[1]), coupling = this.link * this.smooth;\n        for (let i = 0; i < 2; i++) {this.gain[i] += (commonGain - this.gain[i]) * coupling; this.memory[i] += (commonMemory - this.memory[i]) * coupling;}\n        gainL = db(this.gain[0]); gainR = db(this.gain[1]);\n        this.reduction = Math.min(this.gain[0], this.gain[1]) * this.wet;\n      }\n      for (let i = 0; i < outputs.length; i++) {\n        const channel = this.channels[i], raw = i === 0 ? left : right;\n        let wet = i === 0 ? l : r;\n        if (this.type === 'brit') {\n          for (const filter of channel.filters) wet = filter.run(wet);\n          wet = channel.color.run(wet, 0.22 * db(this.drive), 0.12);\n        } else if (this.type === 'talon') {\n          wet = channel.audioHp.run(channel.audioPole.run(wet * (i === 0 ? gainL : gainR)));\n          const amount = [0.15, 0.8, 1.5][p.color] * (1 + Math.min(2, -this.gain[i] / 20));\n          channel.amount += (amount - channel.amount) * this.smooth; channel.bias += ((p.color === 1 ? 0.3 : 0) - channel.bias) * this.smooth;\n          wet = channel.color.run(wet, channel.amount, channel.bias);\n        } else wet = channel.clean.run(wet * (i === 0 ? gainL : gainR));\n        const dry = channel.dry.run(raw);\n        outputs[i][n] = dry + this.wet * (wet * this.output - dry);\n      }\n    }\n  }\n}\n\nif (typeof registerProcessor !== 'undefined') {\n  class StudioProcessor extends AudioWorkletProcessor {\n    constructor(options) {\n      super(); this.dsp = new StudioDSP(options.processorOptions.type, sampleRate); this.meterFrames = 0;\n      this.port.onmessage = ({data}) => {\n        if (data.type === 'flush') this.port.postMessage({id: data.id});\n        else if (data.type === 'dispose') {this.dsp.disposed = true; this.dsp.events = [];}\n        else this.dsp.enqueue(data);\n      };\n    }\n    process(inputs, outputs) {\n      this.dsp.render(inputs[0] ?? [], outputs[0], currentFrame);\n      this.meterFrames += outputs[0][0].length;\n      if (this.meterFrames >= sampleRate / 25) {this.meterFrames = 0; this.port.postMessage({reduction: this.dsp.reduction});}\n      return !this.dsp.disposed;\n    }\n  }\n  registerProcessor('rackloose-studio-v1', StudioProcessor);\n}\n", Lr = "/**\n * Hosts Rackloose's Rust DSP (crates/rackloose-dsp, compiled to WebAssembly): the zero-delay-feedback ladder filter\n * for MONARCH, ORACLE, AURORA and SIEVE, and the modeled drum engine for BOOM, PUNCH, ORBIT, STRIKE and FORGE. PRISM\n * reaches the ladder through `globalThis.RacklooseDSP`. Imported directly by tests and as inline source by the worklet\n * loader.\n *\n * Audio moves through fixed buffers in Wasm linear memory, so nothing allocates per block. Every processor in a context\n * shares one instance of the module, and every view is rebuilt when an allocation grows that memory.\n */\nconst RENDER_QUANTUM = 128, DRUM_PARAMS = 8;\nlet shared = null;\n\n/**\n * The context's one instance of the module. Every AudioWorkletNode receives its own structured clone of `module`, so the\n * instance belongs to the worklet scope (one per audio context) rather than to a module object: an instance per\n * processor would reserve a Wasm memory each, and enough of them exhaust the browser's Wasm address space. It needs no\n * imports, so instantiating is synchronous.\n */\nexport function wasmFor(module) {\n  shared ??= new WebAssembly.Instance(module, {}).exports;\n  return shared;\n}\n\n/** One ladder: cutoff, resonance and drive are smoothed in Rust; detune (cents) applies sample-exact. */\nexport class LadderDSP {\n  constructor(module, sampleRate) {\n    this.wasm = wasmFor(module);\n    this.ptr = this.wasm.ladder_new(sampleRate);\n    this.last = {cutoff: NaN, resonance: NaN, drive: NaN, mode: NaN};\n    this.fresh = true;\n    this.buffer = null;\n  }\n\n  views() {\n    const {memory, ladder_input_ptr, ladder_detune_ptr, ladder_output_ptr} = this.wasm;\n    this.buffer = memory.buffer;\n    this.input = new Float32Array(this.buffer, ladder_input_ptr(this.ptr), RENDER_QUANTUM);\n    this.detune = new Float32Array(this.buffer, ladder_detune_ptr(this.ptr), RENDER_QUANTUM);\n    this.output = new Float32Array(this.buffer, ladder_output_ptr(this.ptr), RENDER_QUANTUM);\n  }\n\n  /**\n   * Filters `input` (missing means silence) into `output`. `detune` holds one value for the block or one per sample;\n   * `mode` is 0 24 dB low-pass, 1 12 dB low-pass, 2 band-pass, 3 high-pass.\n   */\n  render(input, output, cutoff, resonance, drive, detune, mode = 0) {\n    if (!this.ptr) {output.fill(0); return;}\n    if (this.wasm.memory.buffer !== this.buffer) this.views();\n    const n = Math.min(output.length, RENDER_QUANTUM);\n    if (input) this.input.set(input.length > n ? input.subarray(0, n) : input); else this.input.fill(0, 0, n);\n    if (detune.length === 1) this.detune.fill(detune[0], 0, n); else this.detune.set(detune.length > n ? detune.subarray(0, n) : detune);\n    const {last, wasm, ptr} = this;\n    if (cutoff !== last.cutoff) wasm.ladder_set_cutoff(ptr, (last.cutoff = cutoff));\n    if (resonance !== last.resonance) wasm.ladder_set_resonance(ptr, (last.resonance = resonance));\n    if (drive !== last.drive) wasm.ladder_set_drive(ptr, (last.drive = drive));\n    if (mode !== last.mode) wasm.ladder_set_mode(ptr, (last.mode = mode));\n    // The first block starts on its settings instead of gliding from Rust's defaults.\n    if (this.fresh) {wasm.ladder_reset(ptr); this.fresh = false;}\n    wasm.ladder_process(ptr, n);\n    output.set(n === RENDER_QUANTUM ? this.output : this.output.subarray(0, n));\n  }\n\n  dispose() {\n    if (!this.ptr) return;\n    this.wasm.ladder_free(this.ptr);\n    this.ptr = 0;\n    this.input = this.detune = this.output = null;\n  }\n}\n\n/**\n * One drum machine. Hits arrive ahead of time as {time, voice, velocity, params} and start sample-accurately inside\n * the block that contains them; a late hit starts at the next block. `chokes` lists [voice, by] pairs.\n */\nexport class DrumsDSP {\n  constructor(module, sampleRate, kit, chokes = []) {\n    this.wasm = wasmFor(module);\n    this.rate = sampleRate;\n    this.ptr = this.wasm.drums_new(sampleRate, kit);\n    for (const [voice, by] of chokes) this.wasm.drums_choke(this.ptr, voice, by);\n    this.events = [];\n    this.buffer = null;\n  }\n\n  views() {\n    const {memory, drums_params_ptr, drums_output_ptr} = this.wasm;\n    this.buffer = memory.buffer;\n    this.params = new Float32Array(this.buffer, drums_params_ptr(this.ptr), DRUM_PARAMS);\n    this.left = new Float32Array(this.buffer, drums_output_ptr(this.ptr, 0), RENDER_QUANTUM);\n    this.right = new Float32Array(this.buffer, drums_output_ptr(this.ptr, 1), RENDER_QUANTUM);\n  }\n\n  /** Copies a sampled kit's one-shot for `voice` into Wasm memory. */\n  load(voice, pcm) {\n    if (!this.ptr) return;\n    const at = this.wasm.drums_load_sample(this.ptr, voice, pcm.length);\n    if (at) new Float32Array(this.wasm.memory.buffer, at, pcm.length).set(pcm);\n  }\n\n  enqueue(event) {\n    let i = this.events.length;\n    while (i > 0 && this.events[i - 1].time > event.time) i--;\n    this.events.splice(i, 0, event);\n  }\n\n  /** Drops hits scheduled at or after `time`. Hits already sounding keep their natural tails. */\n  cancel(time) {this.events = this.events.filter(event => event.time < time);}\n\n  render(left, right, startFrame) {\n    if (!this.ptr) {left.fill(0); right?.fill(0); return;}\n    if (this.wasm.memory.buffer !== this.buffer) this.views();\n    const n = Math.min(left.length, RENDER_QUANTUM), end = startFrame + n;\n    while (this.events.length && this.events[0].time * this.rate < end) {\n      const event = this.events.shift(), offset = Math.max(0, Math.floor(event.time * this.rate) - startFrame);\n      this.params.fill(0); this.params.set(event.params.slice(0, DRUM_PARAMS));\n      this.wasm.drums_trigger(this.ptr, event.voice, Math.min(offset, n - 1), event.velocity);\n    }\n    this.wasm.drums_process(this.ptr, n);\n    if (this.wasm.memory.buffer !== this.buffer) this.views();\n    left.set(n === RENDER_QUANTUM ? this.left : this.left.subarray(0, n));\n    right?.set(n === RENDER_QUANTUM ? this.right : this.right.subarray(0, n));\n  }\n\n  dispose() {\n    if (!this.ptr) return;\n    this.wasm.drums_free(this.ptr);\n    this.ptr = 0;\n    this.events = [];\n  }\n}\n\n// The guard lets unit tests import the exact processor DSP without an audio environment.\nif (typeof registerProcessor !== 'undefined') {\n  globalThis.RacklooseDSP = {LadderDSP, wasmFor};\n\n  class LadderProcessor extends AudioWorkletProcessor {\n    static get parameterDescriptors() {\n      return [\n        {name: 'cutoff', defaultValue: 1000, minValue: 20, maxValue: 20000, automationRate: 'k-rate'},\n        {name: 'resonance', defaultValue: 0, minValue: 0, maxValue: 1, automationRate: 'k-rate'},\n        {name: 'drive', defaultValue: 0, minValue: 0, maxValue: 1, automationRate: 'k-rate'},\n        {name: 'mode', defaultValue: 0, minValue: 0, maxValue: 3, automationRate: 'k-rate'},\n        // Cents, like BiquadFilterNode.detune, with its unbounded range. Rust clamps the resulting cutoff.\n        {name: 'detune', defaultValue: 0, automationRate: 'a-rate'},\n      ];\n    }\n    constructor({processorOptions}) {\n      super(); this.dsp = new LadderDSP(processorOptions.module, sampleRate);\n      this.port.onmessage = ({data}) => {\n        if (data.type === 'flush') this.port.postMessage({id: data.id});\n        else if (data.type === 'dispose') this.dsp.dispose();\n      };\n    }\n    process(inputs, outputs, parameters) {\n      if (!this.dsp.ptr) return false;\n      const {cutoff, resonance, drive, mode, detune} = parameters;\n      this.dsp.render(inputs[0]?.[0], outputs[0][0], cutoff[0], resonance[0], drive[0], detune, Math.round(mode[0]));\n      return true;\n    }\n  }\n  registerProcessor('rackloose-ladder-v1', LadderProcessor);\n\n  class DrumsProcessor extends AudioWorkletProcessor {\n    constructor({processorOptions: {module, kit, chokes}}) {\n      super(); this.dsp = new DrumsDSP(module, sampleRate, kit, chokes);\n      this.port.onmessage = ({data}) => {\n        if (data.type === 'hit') this.dsp.enqueue(data);\n        else if (data.type === 'sample') this.dsp.load(data.voice, data.pcm);\n        else if (data.type === 'cancel') this.dsp.cancel(data.time);\n        else if (data.type === 'flush') this.port.postMessage({id: data.id});\n        else if (data.type === 'dispose') this.dsp.dispose();\n      };\n    }\n    process(inputs, outputs) {\n      if (!this.dsp.ptr) return false;\n      const [left, right] = outputs[0];\n      this.dsp.render(left, right, currentFrame);\n      return true;\n    }\n  }\n  registerProcessor('rackloose-drums-v1', DrumsProcessor);\n}\n", Rr = "data:application/wasm;base64,AGFzbQEAAAABmwEXYAJ/fwF/YAN/f38Bf2ACf38AYAF/AGADf39/AGABfwF/YAR/f39/AGAEf39/fwF/YAAAYAJ9fwF/YAR/f399AGABfQF/YAJ/fQBgBX9/f39/AX9gBn9/f39/fwBgCX9/f39/f35+fgBgA399fwF/YAR/fX9/AX9gAX0BfWAGf39/f39/AX9gBX9+fn5+AGACfX8BfWACfX0BfQNoZwMABAUDBgIHBQMCBAYDBAQDAQgJAgAFAgMKBQMFCwUCAwwMAgwCAgICAAADBw0NAAIAAQAIAw4ADwQEAAEQEBEGCAICAgMDAwACAgQGAwIBAAEAAgICAgISExISEhISFBISFRYWEhIEBQFwARUVBQMBABEGCQF/AUGAgMAACwffAhUGbWVtb3J5AgALZHJ1bXNfY2hva2UADwpkcnVtc19mcmVlABARZHJ1bXNfbG9hZF9zYW1wbGUAEQlkcnVtc19uZXcAExBkcnVtc19vdXRwdXRfcHRyABUQZHJ1bXNfcGFyYW1zX3B0cgAWDWRydW1zX3Byb2Nlc3MAFwtkcnVtc19yZXNldAAYDWRydW1zX3RyaWdnZXIAGRFsYWRkZXJfZGV0dW5lX3B0cgAaC2xhZGRlcl9mcmVlABsQbGFkZGVyX2lucHV0X3B0cgAcCmxhZGRlcl9uZXcAHRFsYWRkZXJfb3V0cHV0X3B0cgAeDmxhZGRlcl9wcm9jZXNzAB8MbGFkZGVyX3Jlc2V0ACARbGFkZGVyX3NldF9jdXRvZmYAIRBsYWRkZXJfc2V0X2RyaXZlACIPbGFkZGVyX3NldF9tb2RlACMUbGFkZGVyX3NldF9yZXNvbmFuY2UAJAkaAQBBAQsUAS8pKjFNT1BRUlNUVUdISUpCQ04K4oEGZ9cDBAF/AX0BfgJ9I4CAgIAAQSBrIgEkgICAgAACQCAAKgLcDiICQwAAoEFgDQAgAUGAgICNBDYCCCABIAI4AgwgAUGBgICAAK1CIIYiAyABQQxqrYQ3AxggASADIAFBCGqthDcDEEHPgcCAACABQRBqQeSIwIAAEIKAgIAAAAsgAEMAAIA/IAJDAACgQSAAKgKwDSAAKgKoDUOaaxc6lJIQ3oCAgAAiBCAEQwAAoEFdGyIEIAQgAl4bQ9sPSUCUIAAqAtgOlRDbgICAACICQwAAgD+SlSIEOAKADyAAIAIgBJQiAjgC8A4gACACIAKUIgQ4AvQOIAAgBCAElCIFOAL8DiAAIAIgBJQ4AvgOIABDAACAP0MAAAAAIAAqArwNIgIgAkMAAAAAXRsiAiACQwAAgD9eG0MAAIBAlCICOAKEDyAAQwAAgD9DAAAAACAAKgLIDSIEIARDAAAAAF0bIgQgBEMAAIA/XhtDAABAQJQQ3ICAgAAiBDgCkA8gAEMAAIA/IASVOAKUDyAAQwAAgD8gBSAClEMAAIA/kpU4AowPIAAgAkMAAAA/lEMAAIA/kkMAAIA/IAAtAJwPQQJJGzgCiA8gACAEkYs4ApgPIAFBIGokgICAgAALgQECAn8CfSABKAIIIgJBgICAAXEhAyAAKgIAIQQCQCACQYCAgIABcQ0AAkAgBIsiBUPKGw5aYA0AIARDAAAAAFwgBUMXt9E4XXENACABIAQgA0EARxC9gICAAA8LIAEgBCADQQBHEL6AgIAADwsgASAEIANBAEcgAS8BDhC/gICAAAtHAQF/I4CAgIAAQSBrIgMkgICAgAAgAyABNgIQIAMgADYCDCADQQE7ARwgAyACNgIYIAMgA0EMajYCFCADQRRqEKuAgIAAAAuxBQEBf0EAIQECQCAAKAIAQf////8HcUH////7B0oNACAAKAIEQf////8HcUH////7B0oNACAAKAIIQf////8HcUH////7B0oNACAAKAIMQf////8HcUH////7B0oNACAAKAIQQf////8HcUH////7B0oNACAAKAIUQf////8HcUH////7B0oNACAAKAIYQf////8HcUH////7B0oNACAAKAIcQf////8HcUH////7B0oNACAAKAIgQf////8HcUH////7B0oNACAAKAIkQf////8HcUH////7B0oNACAAKAIoQf////8HcUH////7B0oNACAAKAIsQf////8HcUH////7B0oNACAAKAIwQf////8HcUH////7B0oNACAAKAI0Qf////8HcUH////7B0oNACAAKAI4Qf////8HcUH////7B0oNACAAKAI8Qf////8HcUH////7B0oNACAAKAJAQf////8HcUH////7B0oNACAAKAJEQf////8HcUH////7B0oNACAAKAJIQf////8HcUH////7B0oNACAAKAJMQf////8HcUH////7B0oNACAAKAJQQf////8HcUH////7B0oNACAAKAJUQf////8HcUH////7B0oNACAAKAJYQf////8HcUH////7B0oNACAAKAJcQf////8HcUH////7B0oNACAAKAJgQf////8HcUH////7B0oNACAAKAJkQf////8HcUH////7B0oNACAAKAJoQf////8HcUH////7B0oNACAAKAJsQf////8HcUH////7B0oNACAAKAJwQf////8HcUH////7B0oNACAAKAJ0Qf////8HcUH////7B0oNACAAKAJ4Qf////8HcUH////7B0oNACAAKAJ8Qf////8HcUH////7B0oNAEEBIQELIAELewEDfyOAgICAAEEQayIBJICAgIAAIAFBBGogACgCACICIAAoAgQgAkEBdCICQQQgAkEESxsiAhCFgICAAAJAIAEoAgRBAUcNACABKAIIIAEoAgwQhoCAgAAACyABKAIIIQMgACACNgIAIAAgAzYCBCABQRBqJICAgIAAC5MBAQF/QQEhBAJAAkAgA0Gu9KIXTQ0AQQAhA0EEIQEMAQsgA0EsbCEDAkACQAJAAkAgAUUNACACIAFBLGxBBCADEIeAgIAAIQEMAQsCQCADDQBBBCEBDAILIAMQiICAgAAhAQsgAQ0AIABBBDYCBAwBCyAAIAE2AgRBACEEC0EIIQELIAAgAWogAzYCACAAIAQ2AgALHAACQCAARQ0AIAAgARCUgICAAAALEJKAgIAAAAuOBgEFfwJAAkACQAJAAkAgAEF8aiIEKAIAIgVBeHEiBkEEQQggBUEDcSIHGyABakkNAAJAIAdFDQAgBiABQSdqSw0CC0EQIANBC2pBeHEgA0ELSRshASAAQXhqIQgCQCAHDQAgAUGAAkkNBSAIRQ0FIAYgAU0NBSAGIAFrQYCACEsNBSAADwsgCCAGaiEHAkACQCAGIAFPDQAgB0EAKALYrMCAAEYNAQJAIAdBACgC1KzAgABGDQAgBygCBCIFQQJxDQcgBUF4cSIFIAZqIgYgAUkNByAHIAUQpYCAgAACQCAGIAFrIgdBEEkNACAEIAEgBCgCAEEBcXJBAnI2AgAgCCABaiIBIAdBA3I2AgQgCCAGaiIGIAYoAgRBAXI2AgQgASAHEKaAgIAADAcLIAQgBiAEKAIAQQFxckECcjYCACAIIAZqIgYgBigCBEEBcjYCBAwGC0EAKALMrMCAACAGaiIGIAFJDQYCQAJAIAYgAWsiB0EPSw0AIAQgBUEBcSAGckECcjYCACAIIAZqIgYgBigCBEEBcjYCBEEAIQdBACEBDAELIAQgASAFQQFxckECcjYCACAIIAFqIgEgB0EBcjYCBCAIIAZqIgYgBzYCACAGIAYoAgRBfnE2AgQLQQAgATYC1KzAgABBACAHNgLMrMCAAAwFCyAGIAFrIgZBD00NBCAEIAEgBUEBcXJBAnI2AgAgCCABaiIBIAZBA3I2AgQgByAHKAIEQQFyNgIEIAEgBhCmgICAAAwEC0EAKALQrMCAACAGaiIGIAFLDQIMBAtB4KLAgABBLkGQo8CAABCOgICAAAALQaCjwIAAQS5B0KPAgAAQjoCAgAAACyAEIAEgBUEBcXJBAnI2AgAgCCABaiIHIAYgAWsiBkEBcjYCBEEAIAY2AtCswIAAQQAgBzYC2KzAgAALIAhFDQAgAA8LAkAgAxCIgICAACIGDQBBAA8LAkAgA0F8QXggBCgCACIBQQNxGyABQXhxaiIBIAMgAUkbIgNFDQAgBiAAIAP8CgAACyAAEI2AgIAAIAYLsioCCH8BfgJAAkACQCAAQfQBSw0AAkACQAJAAkBBACgCxKzAgAAiAUEQIABBC2pB+ANxIABBC0kbIgJBA3YiA3YiAEEDcQ0AIAJBACgCzKzAgABNDQUgAA0BQQAoAsiswIAAIgBFDQUgAGhBAnRBrKnAgABqKAIAIgQoAgRBeHEgAmshAyAEIQEDQAJAIAQoAhAiAA0AIAQoAhQiAA0AIAEoAhghBQJAAkACQCABKAIMIgAgAUcNACABQRRBECABKAIUIgAbaigCACIEDQFBACEADAILIAEoAggiBCAANgIMIAAgBDYCCAwBCyABQRRqIAFBEGogABshBgNAIAYhByAEIgBBFGogAEEQaiAAKAIUIgQbIQYgAEEUQRAgBBtqKAIAIgQNAAsgB0EANgIACyAFRQ0FAkACQCABIAEoAhxBAnRBrKnAgABqIgQoAgBGDQACQCAFKAIQIAFGDQAgBSAANgIUIAANAgwICyAFIAA2AhAgAA0BDAcLIAQgADYCACAARQ0FCyAAIAU2AhgCQCABKAIQIgRFDQAgACAENgIQIAQgADYCGAsgASgCFCIERQ0FIAAgBDYCFCAEIAA2AhgMBQsgACgCBEF4cSACayIEIAMgBCADSSIEGyEDIAAgASAEGyEBIAAhBAwACwsCQAJAIABBf3NBAXEgA2oiBkEDdCIAQbyqwIAAaiICIABBxKrAgABqKAIAIgMoAggiBEYNACAEIAI2AgwgAiAENgIIDAELQQAgAUF+IAZ3cTYCxKzAgAALIAMgAEEDcjYCBCADIABqIgAgACgCBEEBcjYCBCADQQhqDwsCQAJAIAAgA3RBAiADdCIAQQAgAGtycWgiB0EDdCIDQbyqwIAAaiIEIANBxKrAgABqKAIAIgAoAggiBkYNACAGIAQ2AgwgBCAGNgIIDAELQQAgAUF+IAd3cTYCxKzAgAALIAAgAkEDcjYCBCAAIAJqIgEgAyACayICQQFyNgIEIAAgA2ogAjYCAAJAQQAoAsyswIAAIgRFDQBBACgC1KzAgAAhAwJAAkBBACgCxKzAgAAiBkEBIARBA3Z0IgdxDQBBACAGIAdyNgLErMCAACAEQXhxQbyqwIAAaiIEIQYMAQsgBEF4cSIEQbyqwIAAaiEGIARBxKrAgABqKAIAIQQLIAYgAzYCCCAEIAM2AgwgAyAGNgIMIAMgBDYCCAtBACABNgLUrMCAAEEAIAI2AsyswIAAIABBCGoPC0EAQQAoAsiswIAAQX4gASgCHHdxNgLIrMCAAAsCQAJAAkAgA0EQSQ0AIAEgAkEDcjYCBCABIAJqIgQgA0EBcjYCBCAEIANqIAM2AgBBACgCzKzAgAAiBkUNAUEAKALUrMCAACEAAkACQEEAKALErMCAACIHQQEgBkEDdnQiBXENAEEAIAcgBXI2AsSswIAAIAZBeHFBvKrAgABqIgYhBwwBCyAGQXhxIgZBvKrAgABqIQcgBkHEqsCAAGooAgAhBgsgByAANgIIIAYgADYCDCAAIAc2AgwgACAGNgIIDAELIAEgAyACaiIAQQNyNgIEIAEgAGoiACAAKAIEQQFyNgIEDAELQQAgBDYC1KzAgABBACADNgLMrMCAAAsgAUEIaiIARQ0BDAILIABBC2oiA0F4cSECQQAoAsiswIAAIghFDQBBHyEFAkAgAEH1//8HTw0AIAJBJiADQQh2ZyIAa3ZBAXEgAEEBdGtBPmohBQtBACACayEDAkACQAJAAkAgBUECdEGsqcCAAGooAgAiAQ0AQQAhBEEAIQAMAQtBACEEIAJBAEEZIAVBAXZrIAVBH0YbdCEGQQAhAANAAkAgASIBKAIEQXhxIgcgAkkNACAHIAJrIgcgA08NACABIQQgByEDIAcNAEEAIQMgASEAIAEhBAwDCyABKAIUIgcgACAHIAEgBkEddkEEcWooAhAiAUcbIAAgBxshACAGQQF0IQYgAQ0ACwsCQCAAIARyDQBBACEEQQIgBXQiAEEAIABrciAIcSIARQ0DIABoQQJ0QaypwIAAaigCACEACyAARQ0BCwNAIAAoAgRBeHEiASACayIGIAMgBiADSSIHGyEFIAEgAkkhBiAAIAQgBxshBwJAIAAoAhAiAQ0AIAAoAhQhAQsgAyAFIAYbIQMgBCAHIAYbIQQgASEAIAENAAsLIARFDQACQEEAKALMrMCAACIAIAJJDQAgAyAAIAJrTw0BCyAEKAIYIQUCQAJAAkAgBCgCDCIAIARHDQAgBEEUQRAgBCgCFCIAG2ooAgAiAQ0BQQAhAAwCCyAEKAIIIgEgADYCDCAAIAE2AggMAQsgBEEUaiAEQRBqIAAbIQYDQCAGIQcgASIAQRRqIABBEGogACgCFCIBGyEGIABBFEEQIAEbaigCACIBDQALIAdBADYCAAsCQCAFRQ0AAkACQAJAIAQgBCgCHEECdEGsqcCAAGoiASgCAEYNAAJAIAUoAhAgBEYNACAFIAA2AhQgAA0CDAQLIAUgADYCECAADQEMAwsgASAANgIAIABFDQELIAAgBTYCGAJAIAQoAhAiAUUNACAAIAE2AhAgASAANgIYCyAEKAIUIgFFDQEgACABNgIUIAEgADYCGAwBC0EAQQAoAsiswIAAQX4gBCgCHHdxNgLIrMCAAAsCQAJAAkACQCADQRBJDQAgBCACQQNyNgIEIAQgAmoiASADQQFyNgIEIAEgA2ogAzYCAAJAIANBgAJJDQBBHyEAIANBgICACEkNAgwDCwJAAkBBACgCxKzAgAAiAEEBIANBA3Z0IgZxDQBBACAAIAZyNgLErMCAACADQfgBcUG8qsCAAGoiACEDDAELIANB+AFxIgBBvKrAgABqIQMgAEHEqsCAAGooAgAhAAsgAyABNgIIIAAgATYCDCABIAM2AgwgASAANgIIDAMLIAQgAyACaiIAQQNyNgIEIAQgAGoiACAAKAIEQQFyNgIEDAILIANBJiADQQh2ZyIAa3ZBAXEgAEEBdHJBPnMhAAsgAUIANwIQIAEgADYCHCAAQQJ0QaypwIAAaiEGAkBBACgCyKzAgABBASAAdCIHcQ0AIAYgATYCACABIAY2AhggASABNgIMIAEgATYCCEEAQQAoAsiswIAAIAdyNgLIrMCAAAwBCwJAAkACQCAGKAIAIgcoAgRBeHEgA0cNACAHIQAMAQsgA0EAQRkgAEEBdmsgAEEfRht0IQYDQCAHIAZBHXZBBHFqIgUoAhAiAEUNAiAGQQF0IQYgACEHIAAoAgRBeHEgA0cNAAsLIAAoAggiAyABNgIMIAAgATYCCCABQQA2AhggASAANgIMIAEgAzYCCAwBCyAFQRBqIAE2AgAgASAHNgIYIAEgATYCDCABIAE2AggLIARBCGoiAA0BCwJAAkACQAJAAkACQEEAKALMrMCAACIAIAJPDQACQEEAKALQrMCAACIAIAJLDQBBACEAQQAtAJipwIAAIQRBAEEBOgCYqcCAAEGArcCAACEBIAJBr4AEaiIGQYCAfHEhAwJAAkBBgIDEgABBgK3AgABNDQAgA0GAgMSAAEGArcCAAGtLDQAgBEH/AXENAEGAgMSAAEGArcCAAGshBwwBCyAGQRB2QAAiBEF/Rg0IQQAhACAEQRB0IgFFDQggA0FwaiADIAFBACADa0YbIQcLQQBBACgC3KzAgAAgB2oiADYC3KzAgABBACAAQQAoAuCswIAAIgMgACADSxs2AuCswIAAAkACQAJAQQAoAtiswIAAIgNFDQBBrKrAgAAhAANAIAEgACgCACIEIAAoAgQiBmpGDQIgACgCCCIADQAMAwsLAkACQEEAKALorMCAACIARQ0AIAEgAE8NAQtBACABNgLorMCAAAtBAEH/HzYC7KzAgABBACAHNgKwqsCAAEEAIAE2AqyqwIAAQQBBvKrAgAA2AsiqwIAAQQBBxKrAgAA2AtCqwIAAQQBBvKrAgAA2AsSqwIAAQQBBzKrAgAA2AtiqwIAAQQBBxKrAgAA2AsyqwIAAQQBB1KrAgAA2AuCqwIAAQQBBzKrAgAA2AtSqwIAAQQBB3KrAgAA2AuiqwIAAQQBB1KrAgAA2AtyqwIAAQQBB5KrAgAA2AvCqwIAAQQBB3KrAgAA2AuSqwIAAQQBB7KrAgAA2AviqwIAAQQBB5KrAgAA2AuyqwIAAQQBB9KrAgAA2AoCrwIAAQQBB7KrAgAA2AvSqwIAAQQBBADYCuKrAgABBAEH8qsCAADYCiKvAgABBAEH0qsCAADYC/KrAgABBAEH8qsCAADYChKvAgABBAEGEq8CAADYCkKvAgABBAEGEq8CAADYCjKvAgABBAEGMq8CAADYCmKvAgABBAEGMq8CAADYClKvAgABBAEGUq8CAADYCoKvAgABBAEGUq8CAADYCnKvAgABBAEGcq8CAADYCqKvAgABBAEGcq8CAADYCpKvAgABBAEGkq8CAADYCsKvAgABBAEGkq8CAADYCrKvAgABBAEGsq8CAADYCuKvAgABBAEGsq8CAADYCtKvAgABBAEG0q8CAADYCwKvAgABBAEG0q8CAADYCvKvAgABBAEG8q8CAADYCyKvAgABBAEHEq8CAADYC0KvAgABBAEG8q8CAADYCxKvAgABBAEHMq8CAADYC2KvAgABBAEHEq8CAADYCzKvAgABBAEHUq8CAADYC4KvAgABBAEHMq8CAADYC1KvAgABBAEHcq8CAADYC6KvAgABBAEHUq8CAADYC3KvAgABBAEHkq8CAADYC8KvAgABBAEHcq8CAADYC5KvAgABBAEHsq8CAADYC+KvAgABBAEHkq8CAADYC7KvAgABBAEH0q8CAADYCgKzAgABBAEHsq8CAADYC9KvAgABBAEH8q8CAADYCiKzAgABBAEH0q8CAADYC/KvAgABBAEGErMCAADYCkKzAgABBAEH8q8CAADYChKzAgABBAEGMrMCAADYCmKzAgABBAEGErMCAADYCjKzAgABBAEGUrMCAADYCoKzAgABBAEGMrMCAADYClKzAgABBAEGcrMCAADYCqKzAgABBAEGUrMCAADYCnKzAgABBAEGkrMCAADYCsKzAgABBAEGcrMCAADYCpKzAgABBAEGsrMCAADYCuKzAgABBAEGkrMCAADYCrKzAgABBAEG0rMCAADYCwKzAgABBAEGsrMCAADYCtKzAgABBACABQQ9qQXhxIgBBeGoiAzYC2KzAgABBAEG0rMCAADYCvKzAgABBACABIABrIAdBWGoiAGpBCGoiBDYC0KzAgAAgAyAEQQFyNgIEIAEgAGpBKDYCBEEAQYCAgAE2AuSswIAADAgLIAMgAU8NACAEIANLDQAgACgCDEUNAwtBAEEAKALorMCAACIAIAEgACABSRs2AuiswIAAIAEgB2ohBEGsqsCAACEAAkACQAJAA0AgACgCACIGIARGDQEgACgCCCIADQAMAgsLIAAoAgxFDQELQayqwIAAIQACQANAAkAgACgCACIEIANLDQAgAyAEIAAoAgRqIgRJDQILIAAoAgghAAwACwtBACABQQ9qQXhxIgBBeGoiBjYC2KzAgABBACABIABrIAdBWGoiAGpBCGoiBTYC0KzAgAAgBiAFQQFyNgIEIAEgAGpBKDYCBEEAQYCAgAE2AuSswIAAIAMgBEFgakF4cUF4aiIAIAAgA0EQakkbIgZBGzYCBEEAKQKsqsCAACEJIAZBEGpBACkCtKrAgAA3AgAgBkEIaiIAIAk3AgBBACAHNgKwqsCAAEEAIAE2AqyqwIAAQQAgADYCtKrAgABBAEEANgK4qsCAACAGQRxqIQADQCAAQQc2AgAgAEEEaiIAIARJDQALIAYgA0YNByAGIAYoAgRBfnE2AgQgAyAGIANrIgBBAXI2AgQgBiAANgIAAkAgAEGAAkkNACADIAAQ1oCAgAAMCAsCQAJAQQAoAsSswIAAIgRBASAAQQN2dCIBcQ0AQQAgBCABcjYCxKzAgAAgAEH4AXFBvKrAgABqIgAhBAwBCyAAQfgBcSIAQbyqwIAAaiEEIABBxKrAgABqKAIAIQALIAQgAzYCCCAAIAM2AgwgAyAENgIMIAMgADYCCAwHCyAAIAE2AgAgACAAKAIEIAdqNgIEIAFBD2pBeHFBeGoiASACQQNyNgIEIAZBD2pBeHFBeGoiBCABIAJqIgBrIQMgBEEAKALYrMCAAEYNAyAEQQAoAtSswIAARg0EAkAgBCgCBCICQQNxQQFHDQAgBCACQXhxIgIQpYCAgAAgAiADaiEDIAQgAmoiBCgCBCECCyAEIAJBfnE2AgQgACADQQFyNgIEIAAgA2ogAzYCAAJAIANBgAJJDQAgACADENaAgIAADAYLAkACQEEAKALErMCAACICQQEgA0EDdnQiBHENAEEAIAIgBHI2AsSswIAAIANB+AFxQbyqwIAAaiIDIQIMAQsgA0H4AXEiA0G8qsCAAGohAiADQcSqwIAAaigCACEDCyACIAA2AgggAyAANgIMIAAgAjYCDCAAIAM2AggMBQtBACAAIAJrIgM2AtCswIAAQQBBACgC2KzAgAAiACACaiIENgLYrMCAACAEIANBAXI2AgQgACACQQNyNgIEIABBCGohAAwGC0EAKALUrMCAACEDAkACQCAAIAJrIgRBD0sNAEEAQQA2AtSswIAAQQBBADYCzKzAgAAgAyAAQQNyNgIEIAMgAGoiACAAKAIEQQFyNgIEDAELQQAgBDYCzKzAgABBACADIAJqIgE2AtSswIAAIAEgBEEBcjYCBCADIABqIAQ2AgAgAyACQQNyNgIECyADQQhqDwsgACAGIAdqNgIEQQBBACgC2KzAgAAiAEEPakF4cSIDQXhqIgQ2AtiswIAAQQAgACADa0EAKALQrMCAACAHaiIDakEIaiIBNgLQrMCAACAEIAFBAXI2AgQgACADakEoNgIEQQBBgICAATYC5KzAgAAMAwtBACAANgLYrMCAAEEAQQAoAtCswIAAIANqIgM2AtCswIAAIAAgA0EBcjYCBAwBC0EAIAA2AtSswIAAQQBBACgCzKzAgAAgA2oiAzYCzKzAgAAgACADQQFyNgIEIAAgA2ogAzYCAAsgAUEIag8LQQAhAEEAKALQrMCAACIDIAJNDQBBACADIAJrIgM2AtCswIAAQQBBACgC2KzAgAAiACACaiIENgLYrMCAACAEIANBAXI2AgQgACACQQNyNgIEIABBCGoPCyAAC7MgASt/I4CAgIAAQdAQayIBJICAgIAAAkAgACgCCCICRQ0AIAAoAgQiAyACQdASbGohBCABQY0MakEDaiEFIAFB2QdqQQNqIQYgAUHhCWpBA2ohByABQYAKakEDaiEIIAFB9QpqQQNqIQkgAUGUC2pBA2ohCiABQekGakEDaiELIAFBgBBqQTxqIQIgAUGAEGpBKGohDCABQYAQakEUaiENIAFBsA9qQTxqIQ4gAUGwD2pBKGohDyABQbAPakEUaiEQIAFB4A5qQTxqIREgAUHgDmpBKGohEiABQeAOakEUaiETIAFBkA5qQTxqIRQgAUGQDmpBKGohFSABQZAOakEUaiEWIAFBwA1qQTxqIRcgAUHADWpBKGohGCABQcANakEUaiEZIAFBsAxqQewAaiEaIAFBsAxqQcgAaiEbIAFBsAxqQSRqIRwgAUH1BWpBA2ohHSABQcYBakEDaiEeIAFByQNqQQNqIR8gAUHoA2pBA2ohICABQd0EakEDaiEhIAFB/ARqQQNqISIgAUHRAGpBA2ohIyABQbAMakE8aiEkIAFBsAxqQShqISUgAUGwDGpBFGohJiABQfgHakHsAGohJyABQfgHakHIAGohKCABQfgHakEkaiEpIAFB+AdqQQNqISogAUHlAWpBA2ohKwNAIClCADcCACApQgA3AgggKUIANwIQIClCADcCGCApQQA7ASAgKEIANwIAIChCADcCCCAoQgA3AhAgKEIANwIYIChBADsBICAnQgA3AgAgJ0IANwIIICdCADcCECAnQgA3AhggJ0EAOwEgIAFBADsBmAggAUIANwOQCCABQgA3A4gIIAFCADcDgAggAUIANwP4ByAWQgA3AgAgFkIANwIIIBZBADoAECAVQgA3AgAgFUIANwIIIBVBADoAECAUQgA3AgAgFEIANwIIIBRBADoAECATQgA3AgAgE0IANwIIIBNBADoAECABQQA6AKAOIAFCADcDmA4gAUIANwOQDiABQgA3A+AOIAFCADcD6A4gAUEAOgDwDiASQQA6ABAgEkIANwIIIBJCADcCACARQQA6ABAgEUIANwIIIBFCADcCACAQQQA6ABAgEEIANwIIIBBCADcCACAPQQA6ABAgD0IANwIIIA9CADcCACAOQgA3AgAgDkIANwIIIA5BADoAECABQQA6AMAPIAFCADcDuA8gAUIANwOwDyABQQA6AJAQIAFCADcDiBAgAUIANwOAECANQQA6ABAgDUIANwIIIA1CADcCACAMQQA6ABAgDEIANwIIIAxCADcCACACQQA6ABAgAkIANwIIIAJCADcCACABQQA6AMAMIAFCADcDuAwgAUIANwOwDCAmQQA6ABAgJkIANwIIICZCADcCACAlQQA6ABAgJUIANwIIICVCADcCACAkQQA6ABAgJEIANwIIICRCADcCACArIAFB+AdqQZAB/AoAACAjQQA2ABggI0IANwAQICNCADcACCAjQgA3AAAgASABQZAOakHQAPwKAAAgIkEAOgAgICJCADcAGCAiQgA3ABAgIkIANwAIICJCADcAACAhQgA3AAAgIUIANwAIICFCADcAECAhQQA2ABggAUGMBGogAUHgDmpB0AD8CgAAICBBADoAICAgQgA3ABggIEIANwAQICBCADcACCAgQgA3AAAgH0IANwAAIB9CADcACCAfQgA3ABAgH0EANgAYIAFB+AJqIAFBsA9qQdAA/AoAACAeQQA2ABggHkIANwAQIB5CADcACCAeQgA3AAAgAUHwAGogAUGAEGpB0AD8CgAAIB1CADcAGCAdQgA3ABAgHUIANwAIIB1CADcAACABQaAFaiABQbAMakHQAPwKAAAgHEIANwIAIBxCADcCCCAcQgA3AhAgHEIANwIYIBxBADsBICAbQgA3AgAgG0IANwIIIBtCADcCECAbQgA3AhggG0EAOwEgIBpCADcCACAaQgA3AgggGkIANwIQIBpCADcCGCAaQQA7ASAgAUEAOwHQDCABQgA3A8gMIAFCADcDwAwgAUIANwO4DCABQgA3A7AMIBlCADcCACAZQgA3AgggGUEAOgAQIBhCADcCACAYQgA3AgggGEEAOgAQIBdCADcCACAXQgA3AgggF0EAOgAQIBZCADcCACAWQgA3AgggFkEAOgAQIAFBADoA0A0gAUIANwPIDSABQgA3A8ANIAFCADcDkA4gAUIANwOYDiABQQA6AKAOIBVBADoAECAVQgA3AgggFUIANwIAIBRBADoAECAUQgA3AgggFEIANwIAIBNBADoAECATQgA3AgggE0IANwIAIBJBADoAECASQgA3AgggEkIANwIAIBFCADcCACARQgA3AgggEUEAOgAQIAFBADoA8A4gAUIANwPoDiABQgA3A+AOIAFBADoAwA8gAUIANwO4DyABQgA3A7APIBBBADoAECAQQgA3AgggEEIANwIAIA9BADoAECAPQgA3AgggD0IANwIAIA5BADoAECAOQgA3AgggDkIANwIAIAFBADoAkBAgAUIANwOIECABQgA3A4AQIA1BADoAECANQgA3AgggDUIANwIAIAxBADoAECAMQgA3AgggDEIANwIAIAJBADoAECACQgA3AgggAkIANwIAICogAUGwDGpBkAH8CgAAIAtBADYAGCALQgA3ABAgC0IANwAIIAtCADcAACABQZgGaiABQcANakHQAPwKAAAgCkEAOgAgIApCADcAGCAKQgA3ABAgCkIANwAIIApCADcAACAJQgA3AAAgCUIANwAIIAlCADcAECAJQQA2ABggAUGkCmogAUGQDmpB0AD8CgAAIAhBADoAICAIQgA3ABggCEIANwAQIAhCADcACCAIQgA3AAAgB0IANwAAIAdCADcACCAHQgA3ABAgB0EANgAYIAFBkAlqIAFB4A5qQdAA/AoAACAGQQA2ABggBkIANwAQIAZCADcACCAGQgA3AAAgAUGIB2ogAUGwD2pB0AD8CgAAIAVCADcAGCAFQgA3ABAgBUIANwAIIAVCADcAACABQbgLaiABQYAQakHQAPwKAAAgA0IANwMYIANCADcDECADQgA3AwggA0IANwMAIANB5ABqQf8BOgAAIANB5QBqIAEpAPUFNwAAIANB7QBqIAEpAP0FNwAAIANB9QBqIAEpAIUGNwAAIANB/QBqIAEpAI0GNwAAIANBhAFqIAEoAJQGNgAAIANBiAFqIAFBoAVqQdAA/AoAACADQdwBakEAOgAAIANB2AFqQQA7AQAgA0HgAWpBAEHNAPwLACADQdACakH/AToAACADQdECaiABKQD8BDcAACADQdkCaiABKQCEBTcAACADQeECaiABKQCMBTcAACADQekCaiABKQCUBTcAACADQfECaiABKACcBTYAACADQfUCaiABKQDdBDcAACADQf0CaiABKQDlBDcAACADQYUDaiABKQDtBDcAACADQYwDaiABKQD0BDcAACADQZQDaiABQYwEakHQAPwKAAAgA0GMBGpB/wE6AAAgA0HoA2pBADoAACADQeQDakEAOwEAIANBjQRqIAEpAOgDNwAAIANBlQRqIAEpAPADNwAAIANBnQRqIAEpAPgDNwAAIANBpQRqIAEpAIAENwAAIANBrQRqIAEoAIgENgAAIANBsQRqIAEpAMkDNwAAIANBuQRqIAEpANEDNwAAIANBwQRqIAEpANkDNwAAIANByARqIAEpAOADNwAAIANB0ARqIAFB+AJqQdAA/AoAACADQaQFakEAOgAAIANBoAVqQQA7AQAgA0GlBWogAUHlAWpBkwH8CgAAIANB8AZqQQA2AgAgA0HoBmpCADcDACADQeAGakIANwMAIANB2AZqQgA3AwAgA0HQBmpCADcDACADQcgGakIANwMAIANBwAZqQgA3AwAgA0G4BmpCADcDACADQbgHakH/AToAACADQZQHakH/AToAACADQbkHaiABKQDGATcAACADQcEHaiABKQDOATcAACADQckHaiABKQDWATcAACADQdAHaiABKQDdATcAACADQdgHaiABQfAAakHQAPwKAAAgA0GsCGpBADoAACADQagIakEAOwEAIANBrQhqIAEpAFE3AAAgA0G1CGogASkAWTcAACADQb0IaiABKQBhNwAAIANBxAhqIAEpAGg3AAAgA0HMCGogAUHQAPwKAAAgA0GoCWpCADcDACADQaAJakEAOgAAIANBnAlqQQA7AQAgA0GwCWpCADcDACADQbgJakIANwMAIANBwAlqQgA3AwAgA0GMCmpB/wE6AAAgA0GNCmogASkAjQw3AAAgA0GVCmogASkAlQw3AAAgA0GdCmogASkAnQw3AAAgA0GlCmogASkApQw3AAAgA0GsCmogASgArAw2AAAgA0GwCmogAUG4C2pB0AD8CgAAIANBhAtqQQA6AAAgA0GAC2pBADsBACADQYgLakEAQc0A/AsAIANB+AtqQf8BOgAAIANB+QtqIAEpAJQLNwAAIANBgQxqIAEpAJwLNwAAIANBiQxqIAEpAKQLNwAAIANBkQxqIAEpAKwLNwAAIANBmQxqIAEoALQLNgAAIANBnQxqIAEpAPUKNwAAIANBpQxqIAEpAP0KNwAAIANBrQxqIAEpAIULNwAAIANBtAxqIAEpAIwLNwAAIANBvAxqIAFBpApqQdAA/AoAACADQbQNakH/AToAACADQZANakEAOgAAIANBjA1qQQA7AQAgA0G1DWogASkAgAo3AAAgA0G9DWogASkAiAo3AAAgA0HFDWogASkAkAo3AAAgA0HNDWogASkAmAo3AAAgA0HVDWogASgAoAo2AAAgA0HZDWogASkA4Qk3AAAgA0HhDWogASkA6Qk3AAAgA0HpDWogASkA8Qk3AAAgA0HwDWogASkA+Ak3AAAgA0H4DWogAUGQCWpB0AD8CgAAIANBzA5qQQA6AAAgA0HJDmpBADoAACADQcgOakEAOgAAIANBzQ5qIAFB+AdqQZMB/AoAACADQZgQakEANgIAIANBkBBqQgA3AwAgA0GIEGpCADcDACADQYAQakIANwMAIANB+A9qQgA3AwAgA0HwD2pCADcDACADQegPakIANwMAIANB4A9qQgA3AwAgA0HgEGpB/wE6AAAgA0G8EGpB/wE6AAAgA0HhEGogASkA2Qc3AAAgA0HpEGogASkA4Qc3AAAgA0HxEGogASkA6Qc3AAAgA0H4EGogASkA8Ac3AAAgA0GAEWogAUGIB2pB0AD8CgAAIANB1BFqQQA6AAAgA0HREWpBADoAACADQdARakEAOgAAIANB1RFqIAEpAOkGNwAAIANB3RFqIAEpAPEGNwAAIANB5RFqIAEpAPkGNwAAIANB7BFqIAEpAIAHNwAAIANB9BFqIAFBmAZqQdAA/AoAACADQcgSakEAOgAAIANBxRJqQQA6AAAgA0HEEmpBADoAACADQdASaiIDIARHDQALCyAAQQA2AjggAEHgCGpBAEHQAvwLACAAQX82ArAjIAFB0BBqJICAgIAAC/KBAiIJfwF+AX8EfiR/CX0BfwJ9Bn8SfQJ8AX8JfQF/An0DfwJ9AX8CfQJ/BH0CfwR9AX8EfQN/A30Cfwh9A38LfQF/An0BfCOAgICAAEHgCmsiAiSAgICAACAAKAI4IQNBACEEIABBADYCOCAAKAI0IQUgACgCMCEGIABCgICAgMAANwIwIAFBgAFJIQcCQCADQQJJDQBBASEIA0AgCEEBaiEIIAQhCQJAA0AgBSAJaiIKQSRqKAIAIApB0ABqKAIATQ0BIAopAgAhCyAKIApBLGoiDCkCADcCACAKKQIIIQ0gCiAMKQIINwIIIAopAhAhDiAKIAwpAhA3AhAgCikCGCEPIAogDCkCGDcCGCAKKQIgIRAgCiAMKQIgNwIgIAooAighESAKIAwoAig2AiggAiARNgLoAyACIBA3A+ADIAIgDzcD2AMgAiAONwPQAyACIA03A8gDIAIgCzcDwAMgDCACKQPAAzcCACAMIAIoAugDNgIoIAwgAikD4AM3AiAgDCACKQPYAzcCGCAMIAIpA9ADNwIQIAwgAikDyAM3AgggCUFUaiIJQVRHDQALCyAEQSxqIQQgCCADRw0ACwsgAUGAASAHGyESAkACQAJAAkACQAJAAkACQAJAAkAgAUUNACAAQbAbaiETIABBsBNqIRQgAEGwC2ohFSACQaMJakEraiEWIAJBowlqQRdqIRcgAkGjCWpBA2ohGCACQcADakEraiEZIAJBwANqQRdqIRogAkHAA2pBA2ohGyACQaEKakEraiEcIAJBoQpqQRdqIR0gAkGhCmpBA2ohHiACQeIJakEraiEfIAJB4glqQRdqISAgAkHiCWpBA2ohISACQStqISIgAkEXaiEjIAJBA2ohJCACQfAAakEraiElIAJB8ABqQRdqISYgAkHwAGpBA2ohJyACQeQIakEraiEoIAJB5AhqQRdqISkgAkHkCGpBA2ohKiACQfwDaiErIAJB6ANqISwgAkHAA2pBFGohLSACQeAEaiEuIAJB5AJqIS8gAkEcaiEwQQAhMUEAITJBACEzA0AgEiE0AkAgMiADTw0AAkADQAJAIAUgMkEsbGoiCigCJCIMIDFNDQAgDCASIAwgEkkbITQMAwsCQCAKKgIAIjW8Qf////8HcUH////7B0oNACAKKgIEIja8Qf////8HcUH////7B0oNACAKKgIIIje8Qf////8HcUH////7B0oNACAKKgIMIji8Qf////8HcUH////7B0oNACAKKgIQIjm8Qf////8HcUH////7B0oNACAKKAIUQf////8HcUH////7B0oNACAKKAIYQf////8HcUH////7B0oNACAKKgIcIjq8Qf////8HcUH////7B0oNACAKKgIoITsgCigCICEEIAAqAjwiPCA8kiE9AkAgACgCICIKRQ0AIApBAnQhESAAKAIcIQlBASAEdCEIIAAoAgRByBJqIQwgACgCCCEHQQAhCkMAAIC/ID1DpptEO5SVEN6AgIAAITwDQAJAIAQgCkYNACAJKAIAIAhxRQ0AAkACQCAKIAdPDQAgDEHYdmotAABFDQEgDEG4b2oiPiA8ID4qAgAiPyA/ID9cGyI/ID8gPCA8IDxcGyJAID8gQF0bOAIADAELIAogB0HEicCAABCLgICAAAALIAwtAABBAUcNACAMQeB4aiI+IDwgPioCACI/ID8gP1wbIj8gPyA8IDwgPFwbIkAgPyBAXRs4AgALIAlBBGohCSAKQQFqIQogDEHQEmohDCARQXxqIhENAAsLAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAIAQgACgCFCIKTw0AIAQgACgCCCIKTw0BIAAoAhAgBEECdGoiDCgCACIKQQJPDQICQCAAKAIEIARB0BJsIkFqIApBqAlsaiIJLQCgCUUNACAJKgKAAiE8IAlDAACAvyA9Q28SAzuUlRDegICAACI/IDwgPCA8XBsiPCA8ID8gPyA/XBsiPyA8ID9dGzgCgAILIAxBASAKayJCNgIAIAAgACgCtCMiCkENdCAKcyIKQRF2IApzIgpBBXQgCnMiCkENdCAKcyIMQRF2IAxzIgxBBXQgDHMiDEENdCAMcyIJQRF2IAlzIglBBXQgCXMiCUENdCAJcyIRQRF2IBFzIhFBBXQgEXMiEUENdCARcyIIQRF2IAhzIghBBXQgCHMiCEENdCAIcyIHQRF2IAdzIgdBBXQgB3MiB0ENdCAHcyI+QRF2ID5zIj5BBXQgPnMiPjYCtCMgAC0AuCMiQ0ECdCJEKALkpMCAACJFQX9qIkYgBCBGIARJGyJGIEVPDR8gPrNDAACAL5QiPCA8kkMAAIC/kkMAAAA/lEMAAAA/kiFHIAezQwAAgC+UIjwgPJJDAACAv5JDAAAAP5RDAAAAP5IhSCAIs0MAAIAvlCI8IDySQwAAgL+SQwAAAD+UQwAAAD+SIUkgEbNDAACAL5QiPCA8kkMAAIC/kkMAAAA/lEMAAAA/kiFKIAmzQwAAgC+UIjwgPJJDAACAv5JDAAAAP5RDAAAAP5IhSyAMs0MAAIAvlCI8IDySQwAAgL+SQwAAAD+UQwAAAD+SIUwgCrNDAACAL5QiPCA8kkMAAIC/kkOmm0Q7lEMAAIA/kiE8IEQoAvikwIAAIEZBAnRqKgIAIT8gHkEAOgAQIB5CADcACCAeQgA3AAAgHUIANwAAIB1CADcACCAdQQA6ABAgHEIANwAAIBxCADcACCAcQQA6ABAgLUIANwIAIC1CADcCCCAtQQA6ABAgLEIANwIAICxCADcCCCAsQQA6ABAgAkIANwPAAyACQgA3A8gDIAJBADoA0AMgK0EAOgAQICtCADcCCCArQgA3AgAgJEIANwAAICRCADcACCAkQQA6ABAgI0IANwAAICNCADcACCAjQQA6ABAgIkIANwAAICJCADcACCAiQQA6ABAgJ0IANwAAICdCADcACCAnQQA6ABAgJkIANwAAICZCADcACCAmQQA6ABAgJUEAOgAQICVCADcACCAlQgA3AAAgAkIANwOIBiACQgA3A4AGIAJCADcD+AUgAiACKQDYCjcA7wUgAiACKQDRCjcD6AUgAiACKQDJCjcD4AUgAiACKQDBCjcD2AUgAiACKQC5CjcD0AUgAiACKQCxCjcDyAUgAiACKQCpCjcDwAUgAiACKQChCjcDuAUgAkIANwPgByACQgA3A9gHIAJCADcD0AcgIUEAOgAgICFCADcAGCAhQgA3ABAgIUIANwAIICFCADcAACAYQQA2ABggGEIANwAQIBhCADcACCAYQgA3AAAgAkGAAmogAkHAA2pB0AD8CgAAIAJCADcD4AYgAkIANwPYBiACQgA3A9AGIAIgAikAADcDkAYgAiACKQAINwOYBiACIAIpABA3A6AGIAIgAikAGDcDqAYgAiACKQAgNwOwBiACIAIpACg3A7gGIAIgAikAMDcDwAYgAiACKQA3NwDHBiACQgA3A9gIIAJCADcD0AggAkIANwPICCACIAIpAHA3A4gIIAIgAikAeDcDkAggAiACKQCAATcDmAggAiACKQCIATcDoAggAiACKQCQATcDqAggAiACKQCYATcDsAggAiACKQCgATcDuAggAiACKQCnATcAvwggAiACKACCCjYCyAcgAiACKQD6CTcDwAcgAiACKQDyCTcDuAcgAiACKQDqCTcDsAcgAiACKQDiCTcDqAcgAiACKQC6CTcAnwcgAiACKQCzCTcDmAcgAiACKQCrCTcDkAcgAiACKQCjCTcDiAcgAkIANwOACCACQgA3A/gHQwAAIEEgP0MAAKDBlRDkgICAACFNIEMOBQMEBQYGAwsgBCAKQdSJwIAAEIuAgIAAAAsgBCAKQeSJwIAAEIuAgIAAAAsgCkECQfSJwIAAEIuAgIAAAAtDAACgPyFOIAQOCgQFBgcMCwgICQoDC0NmZmY/IU4gBA4EDg8QEhELIDUgPJQhPCAEDgYTFhcSGBQSCyA9QwAAAD+UIj9DZmbmPpQiT0MAAKBBYEUNGSBPQwAAekQgT0MAAHpEXRtD2w9JQJQgPyA/kiJQlRDbgICAABpBACFGIE9DAACgQSA3IDdDAACgQV0bIj8gPyBPXhtD2w9JQJQgUJUQ24CAgAAhPyAqQQA6ABBCACELICpCADcACCAqQgA3AAAgKUIANwAAIClCADcACCApQQA6ABAgKEIANwAAIChCADcACCAoQQA6ABAgAkIANwPAAyACQgA3A8gDIAJCADcDyAggAkIANwPQCCACQgA3A9gIIAIgAikA5Ag3A4gIIAIgAikA7Ag3A5AIIAIgAikA9Ag3A5gIIAIgAikA/Ag3A6AIIAIgAikAhAk3A6gIIAIgAikAjAk3A7AIIAIgAikAlAk3A7gIIAIgAikAmwk3AL8IID9DAACAPyA/QwAAgD+SlSJRlCJSIFIgUpQiU5QhVEMAAIA/ID1DbxKDOpQiPyA/ID9cGyI/QwAAgD8gP0MAAIA/XhshVUMAAIA/IFMgU5QiVkPNzEw+lEMAAIA/kpUhV0MAAAAAIVhDAAAAACA5IDkgOVwbIj9DAAAAACA/QwAAAABeGyA1IDyUIjyUuyFZIDy7ID27oyFaID1DAAAAAJT8ASFbQQEhCEH/ASFDQzMzk8BDbxKDOiA2IDYgNlwbIjxDbxKDOiA8Q28SgzpeGyA9lJUQ3oCAgAAhXEEAIURDAAAAACFMQwAAAAAhS0MAAAAAIUpDAAAAACFJQwAAAAAhSEMAAAAAIUdDAAAAACFdQwAAAAAhXkMAAAAAIV9DAAAAACFgQwAAAAAhYUMAAAAAIWJDAAAAACFjQwAAAAAhZEMAAAAAITlBACFFQQAhZUEAIQlDAAAAACFmQwAAAAAhZ0MAAAAAIU5BACFoQQAhaUH/ASFqQwAAAAAha0MAAAAAIWxBACFtQQAhEUMAAAAAITdDAAAAACFuQwAAAAAhb0EAIXBBACFxQwAAAAAhckMAAAAAIXNDAAAAACF0QgAhDUMAAAAAIXVBACF2QQAhd0MAAAAAIXhDAAAAACF5QwAAAAAhekMAAAAAIXtBACF8QwAAAAAhfUMAAAAAIX5B/wEhNEEAIQdBACEMQwAAAAAhf0MAAAAAIYABQwAAAAAhP0EAIYEBQwAAAAAhQEMAAAAAITVBACGCAUEAIYMBQwAAAAAhhAFDAAAAACGFAUMAAAAAIYYBQQAhhwFBACGIAUMAAAAAIYkBQwAAAAAhigFDAAAAACGLAUMAAAAAIYwBQwAAAAAhjQFDAAAAACGOAUMAAAAAIY8BQwAAAAAhkAFDAAAAACE8IAQhkQFBASGSAUEAIZMBQwAAAAAhlAEMNAsgGEEAOgAQIBhCADcACCAYQgA3AAAgF0IANwAAIBdCADcACCAXQQA6ABAgFkIANwAAIBZCADcACCAWQQA6ABAgAkIANwPQBiACQgA3A9gGIAJCADcD4AYgAiACKQCjCTcDkAYgAiACKQCrCTcDmAYgAiACKQCzCTcDoAYgAiACKQC7CTcDqAYgAiACKQDDCTcDsAYgAiACKQDLCTcDuAYgAiACKQDTCTcDwAYgAiACKQDaCTcAxwYgPUNI4fo+lCI/QwAAIEFgRQ0ZQgAhCyA/QwAAJUUgP0MAACVFXRtD2w9JQJQgPZUQ24CAgAAhPyACQgA3A4AHIAJCADcD+AZDAACAPyA9Q28SAzqUIkAgQCBAXBsiQEMAAIA/IEBDAACAP14bIWdDbts2PyGVASA/ID9DAACAPyA/ID9Dbts2P5KUQwAAgD+SlSKWAZQilwGUIZgBIDUgPJQiPEMAAAdElCA9lSFdIDxDAABIRJQgPZUhXkMAAAAAIVggPUMAAAAAlPwBIWhEAAAAAAAAAAAhWUNmZqY/ITxBAiFtQwAAAD8hbEH/ASFDQQEhCUNmZmY/IU5BACFGQzMzk8BDbxKDOiA2IDYgNlwbIj9DbxKDOiA/Q28SgzpeGyA9lJUQ3oCAgAAhZkEAIURDAAAAACFfQwAAAAAhYEMAAAAAIWFDAAAAACFiQwAAAAAhY0MAAAAAIWRDAAAAACE5QQAhRUEAIWVBASFpQQEhakMAAAAAIWsMLQsgG0EAOgAQIBtCADcACCAbQgA3AAAgGkIANwAAIBpCADcACCAaQQA6ABAgGUIANwAAIBlCADcACCAZQQA6ABAgAkIANwP4BSACQgA3A4AGIAJCADcDiAYgAiACKQDAAzcDuAUgAiACKQDIAzcDwAUgAiACKQDQAzcDyAUgAiACKQDYAzcD0AUgAiACKQDgAzcD2AUgAiACKQDoAzcD4AUgAiACKQDwAzcD6AUgAiACKQD3AzcA7wUgPUNI4fo+lCI/QwAAIEFgRQ0ZQgAhCyA/QwDAWkUgP0MAwFpFXRtD2w9JQJQgPZUQ24CAgAAhPyACQgA3A4AIIAJCADcD+AdDAACAPyE5QwAAgD8gPUOmm8Q6lCJAIEAgQFwbIkBDAACAPyBAQwAAgD9eGyFkQ27btj8hkAEgPyA/QwAAgD8gPyA/Q27btj+SlEMAAIA/kpUijwGUIo4BlCGNASA1IDyUID2VIXogPUMXt9E5lPwBIZMBQwAAAAAhWCA9QwAAAACU/AEhRUMAAEDAID1DzczMPJSVEN6AgIAAvCFERAAAAAAAAAAAIVlDAACAPiGUAUPNzMw/ITxBgICA/AMhfEOPwnU9IXhBASFlQf8BIUNBACFGQzMzk8BDbxKDOiA2IDYgNlwbIj9DbxKDOiA/Q28SgzpeGyA9lJUQ3oCAgAAhY0MAAAAAIUxDAAAAACFLQwAAAAAhSkMAAAAAIUlDAAAAACFIQwAAAAAhR0MAAAAAIV1DAAAAACFeQwAAAAAhX0MAAAAAIWBDAAAAACFhQwAAAAAhYkEAIQlDAAAAACFmQwAAAAAhZ0MAAAAAIU5BACFoQQAhaUH/ASFqQwAAAAAha0MAAAAAIWxBACFtQQAhEUMAAAAAITdDAAAAACFuQwAAAAAhb0EAIXBBACFxQwAAAAAhckMAAAAAIXNDAAAAACF0QgAhDUMAAAAAIXVBACF2QQEhd0MAAIA/IXlDAAAAACF7QwAAAAAhfUMAAAAAIX5B/wEhNEEAIQdBACEMQwAAAAAhf0MAAAAAIYABQwAAAAAhP0EAIYEBQwAAAAAhQEMAAAAAITVBACGCAUEAIYMBQwAAAAAhhAFDAAAAACGFAUMAAAAAIYYBQQAhhwFBACGIAUMAAAAAIYkBQwAAAAAhigFDAAAAACGLAUMAAAAAIYwBQQAhCEMAAAAAIVxDAAAAACFVQwAAAAAhOEEAIVtBACGRAUH/ASGSAQwxCyAbQQA6ABAgG0IANwAIIBtCADcAACAaQgA3AAAgGkIANwAIIBpBADoAECAZQgA3AAAgGUIANwAIIBlBADoAECACQgA3A/gFIAJCADcDgAYgAkIANwOIBiACIAIpAMADNwO4BSACIAIpAMgDNwPABSACIAIpANADNwPIBSACIAIpANgDNwPQBSACIAIpAOADNwPYBSACIAIpAOgDNwPgBSACIAIpAPADNwPoBSACIAIpAPcDNwDvBSA9Q0jh+j6UIj9DAAAgQWBFDRlCACELID9DAADhRCA/QwAA4URdG0PbD0lAlCA9lRDbgICAACE/IAJCADcD4AcgAkIANwPYByACQgA3A9AHQwAAgD8gPUNvEgM6lCJAIEAgQFwbIkBDAACAPyBAQwAAgD9eGyGFAUMAAIA/ID1DppvEOpQiQCBAIEBcGyJAQwAAgD8gQEMAAIA/XhshZEOrqqo/IYwBID8gP0MAAIA/ID8gP0Orqqo/kpRDAACAP5KVIosBlCKKAZQhiQEgNkOamRk/lCGGAUMAAIA/IDVDmpkZP5STIXkgNUNmZiY/lEMzM7M+kiFzIDcgPJQiPEMAADlDlCA9lSF6IDxDAAClQ5QgPZUhdEMAAAAAIVggPUMAAAAAlPwBIUVDAABAwCA9QwrXIzyUlRDegICAALwiRK0hDUQAAAAAAAAAACFZQ2Zmpj8hPEGQro/tAyF8QxDXoz0hdUMK16M8IXJBASFlQf8BIUNBACEJQ83MDD8hOUECIUZDMzOTwENvEoM6IDggOCA4XBsiP0NvEoM6ID9DbxKDOl4bID2UlRDegICAACGEAUMzM5PAQ28SgzogOENmZiY/lCI/ID8gP1wbIj9DbxKDOiA/Q28SgzpeGyA9lJUQ3oCAgAAhY0MAAAAAIUxDAAAAACFLQwAAAAAhSkMAAAAAIUlDAAAAACFIQwAAAAAhR0MAAAAAIV1DAAAAACFeQwAAAAAhX0MAAAAAIWBDAAAAACFhQwAAAAAhYkMAAAAAIWZDAAAAACFnQwAAAAAhTkEAIWhBACFpQf8BIWpDAAAAACFrQwAAAAAhbEEAIW1BACERQwAAAAAhN0MAAAAAIW5DAAAAACFvQQAhcEEBIXFBACF2QQEhd0MK16M8IXgMJwsgG0EAOgAQIBtCADcACCAbQgA3AAAgGkIANwAAIBpCADcACCAaQQA6ABAgGUIANwAAIBlCADcACCAZQQA6ABAgAkIANwP4BSACQgA3A4AGIAJCADcDiAYgAiACKQDAAzcDuAUgAiACKQDIAzcDwAUgAiACKQDQAzcDyAUgAiACKQDYAzcD0AUgAiACKQDgAzcD2AUgAiACKQDoAzcD4AUgAiACKQDwAzcD6AUgAiACKQD3AzcA7wUgPUNI4fo+lCI/QwAAIEFgRQ0ZQgAhCyA/QwBAnEUgP0MAQJxFXRtD2w9JQJQgPZUQ24CAgAAhPyACQgA3A+AHIAJCADcD2AcgAkIANwPQB0MAAIA/IXNDAACAPyA9Q28SAzqUIkAgQCBAXBsiQEMAAIA/IEBDAACAP14bIYUBQwAAgD8gPUOmm8Q6lCJAIEAgQFwbIkBDAACAPyBAQwAAgD9eGyFkQ6uqqj8hjAEgPyA/QwAAgD8gPyA/Q6uqqj+SlEMAAIA/kpUiiwGUIooBlCGJASA1IDyUIjxDAIDjQ5QgPZUheiA8QwBg0ESUID2VIXRDAAAAACFYID1DAAAAAJT8ASFFQwAAQMAgPUNvEoM6lJUQ3oCAgAC8IkStIQ1EAAAAAAAAAAAhWUMAAABAITxDAAAAPyGGAUOamRk/IXlBASFlQf8BIUNBACEJQzMzMz8hOUECIUZDMzOTwENvEoM6IDYgNiA2XBsiP0NvEoM6ID9DbxKDOl4bID2UlRDegICAACFjQzMzk8BDbxKDOiA2Q4mIiD6UIj8gPyA/XBsiP0NvEoM6ID9DbxKDOl4bID2UlRDegICAACGEAUMAAAAAIUxDAAAAACFLQwAAAAAhSkMAAAAAIUlDAAAAACFIQwAAAAAhR0MAAAAAIV1DAAAAACFeQwAAAAAhX0MAAAAAIWBDAAAAACFhQwAAAAAhYkMAAAAAIWZDAAAAACFnQwAAAAAhTkEAIWhBACFpQf8BIWpDAAAAACFrQwAAAAAhbEEAIW1BACERQwAAAAAhN0MAAAAAIW5DAAAAACFvQQEhcEEBIXFDAAAAACFyQwAAAAAhdUEBIXZBASF3QwAAAAAheEMAAAAAIXtBACF8DCcLID1DSOH6PpQiPEMAACBBYEUNGUIAIQsgPEMAACBBIDVDAAB6RJQiPyA/QwAAIEFdGyI/ID8gPF4bQ9sPSUCUID2VENuAgIAAITwgAkIANwPgByACQgA3A9gHIAJCADcD0AdDbts2PyGMASA8IDxDAACAPyA8IDxDbts2P5KUQwAAgD+SlSKLAZQiigGUIYkBQwAAgD8gPUNvEgM6lCI8IDwgPFwbIjxDAACAPyA8QwAAgD9eGyGAASA9Q28SAz2U/AEhgQEgPUMxCKw8lPwBIYIBID1DCtcjPJT8ASGDAUMAAAAAIVggPUMAAAAAlPwBIYcBRAAAAAAAAAAAIVlDmpmZPyE8QQQhiAFDMzOzPyE/QwAAwD8hfkOrqio/IX1B/wEhQ0EAIURBASFGQzMzk8AgPUNvEoM8lJUQ3oCAgAAhQEMzM5PAQ28SgzogNiA2IDZcGyI2Q28SgzogNkNvEoM6XhsgPZSVEN6AgIAAIX9DAAAAACFMQwAAAAAhS0MAAAAAIUpDAAAAACFJQwAAAAAhSEMAAAAAIUdDAAAAACFdQwAAAAAhXkMAAAAAIV9DAAAAACFgQwAAAAAhYUMAAAAAIWJDAAAAACFjQwAAAAAhZEMAAAAAITlBACFFQQAhZUEAIQlDAAAAACFmQwAAAAAhZ0MAAAAAIU5BACFoQQAhaUH/ASFqQwAAAAAha0MAAAAAIWxBACFtQQAhEUMAAAAAITdDAAAAACFuQwAAAAAhb0EAIXBBACFxQwAAAAAhckMAAAAAIXNDAAAAACF0QgAhDUMAAAAAIXVBACF2QQAhd0MAAAAAIXhDAAAAACF5QwAAAAAhekMAAAAAIXtBACF8Qf8BITRBASEHQQEhDCBAIYQBQwAAgD8gPUMXt9E5lCI2IDYgNlwbIjZDAACAPyA2QwAAgD9eGyI1IYUBQzMzsz8hhgEMLQsgG0EAOgAQIBtCADcACCAbQgA3AAAgGkIANwAAIBpCADcACCAaQQA6ABAgGUIANwAAIBlCADcACCAZQQA6ABAgAkIANwP4BSACQgA3A4AGIAJCADcDiAYgAiACKQDAAzcDuAUgAiACKQDIAzcDwAUgAiACKQDQAzcDyAUgAiACKQDYAzcD0AUgAiACKQDgAzcD2AUgAiACKQDoAzcD4AUgAiACKQDwAzcD6AUgAiACKQD3AzcA7wUgPUNI4fo+lCI/QwAAIEFgRQ0ZQgAhCyA/QwCAO0UgP0MAgDtFXRtD2w9JQJQgPZUQ24CAgAAhPyACQgA3A+AHIAJCADcD2AcgAkIANwPQB0MAAIA/IXlDAACAPyA9Q1JJnTmUIkAgQCBAXBsiQEMAAIA/IEBDAACAP14bIYUBQwAAgD8gPUOmm8Q6lCJAIEAgQFwbIkBDAACAPyBAQwAAgD9eGyFkQ6uqqj8hjAEgPyA/QwAAgD8gPyA/Q6uqqj+SlEMAAIA/kpUiiwGUIooBlCGJASA1IDyUIjwgPZUheiA8QwAAwD+UID2VIXRDAAAAACFYID1DAAAAAJT8ASFFQwAAQMAgPUOPwnU9lJUQ3oCAgAC8IkStIQ1EAAAAAAAAAAAhWUNmZqY/ITxBmrPm+AMhfEPNzEw9IXhDmpkZPyF1Q5qZGT4hc0EBIWVB/wEhQ0EAIQlDZmZmPyE5QQIhRkMzM5PAID1DCtcjPJSVEN6AgIAAIYQBQzMzk8BDbxKDOiA2IDYgNlwbIj9DbxKDOiA/Q28SgzpeGyA9lJUQ3oCAgAAhY0MAAAAAIUxDAAAAACFLQwAAAAAhSkMAAAAAIUlDAAAAACFIQwAAAAAhR0MAAAAAIV1DAAAAACFeQwAAAAAhX0MAAAAAIWBDAAAAACFhQwAAAAAhYkMAAAAAIWZDAAAAACFnQwAAAAAhTkEAIWhBACFpQf8BIWpDAAAAACFrQwAAAAAhbEEAIW1BACERQwAAAAAhN0MAAAAAIW5DAAAAACFvQQEhcEEBIXFDAAAAACFyQQAhdkEBIXdDAAAAACF7QwAAAAAhfUMAAAAAIX5B/wEhNEEBIQdBACEMQwAAAAAhf0MAAAAAIYABQwAAAAAhP0EAIYEBQwAAAAAhQEMAAAAAITVBACGCAUEAIYMBQ5qZGT4hhgEMJwsgIUEAOgAQICFCADcACCAhQgA3AAAgIEIANwAAICBCADcACCAgQQA6ABAgH0IANwAAIB9CADcACCAfQQA6ABAgAkIANwPQBiACQgA3A9gGIAJCADcD4AYgAiACKQDiCTcDkAYgAiACKQDqCTcDmAYgAiACKQDyCTcDoAYgAiACKQD6CTcDqAYgAiACKQCCCjcDsAYgAiACKQCKCjcDuAYgAiACKQCSCjcDwAYgAiACKQCZCjcAxwYgPUNI4fo+lCI/QwAAIEFgRQ0ZQgAhCyA/QwAAIEEgNkMAwNpFlCJAIEBDAAAgQV0bIkAgQCA/XhtD2w9JQJQgPZUQ24CAgAAhQCACQgA3A4AHIAJCADcD+AYgP0MAACBBIDZDAECcRZQiNiA2QwAAIEFdGyI2IDYgP14bQ9sPSUCUID2VENuAgIAAIT8gAkIANwPwBiACQgA3A+gGQwAAAEAhlQEgQCBAQwAAgD8gQCBAQwAAAECSlEMAAIA/kpUilgGUIpcBlCGYASA/ID9DAACAPyA/ID9Dq6qqP5KUQwAAgD+SlSKZAZQimgGUIZsBQwAAgD8gPUNvEgM7lCI/ID8gP1wbIj9DAACAPyA/QwAAgD9eGyFnIDxDzUxNQ5QgPZUhXSA8QzMzmEOUID2VIV4gPEPNzLhDlCA9lSFfIDxDzawCRJQgPZUhYCA8QwAAB0SUID2VIWEgPEMAAEhElCA9lSFiQwAAAAAhWCA9QwAAAACU/AEhaEQAAAAAAAAAACFZQ5qZmT8hPEH/ASE0QQYhbUMAAAA/IWxDMzOzPiFrQQIhQ0EBIQlDAABAPyFOQQAhRkMzM5PAQ28SgzogNSA1IDVcGyI/Q28SgzogP0NvEoM6XhsgPZSVEN6AgIAAIWZBACFEQwAAAAAhY0MAAAAAIWRDAAAAACE5QQAhRUEAIWVBASFpQQEhagwECyAeQQA6ABAgHkIANwAIIB5CADcAACAdQgA3AAAgHUIANwAIIB1BADoAECAcQgA3AAAgHEIANwAIIBxBADoAECACQgA3A9AGIAJCADcD2AYgAkIANwPgBiACIAIpAKEKNwOQBiACIAIpAKkKNwOYBiACIAIpALEKNwOgBiACIAIpALkKNwOoBiACIAIpAMEKNwOwBiACIAIpAMkKNwO4BiACIAIpANEKNwPABiACIAIpANgKNwDHBiA9Q0jh+j6UIj9DAAAgQWBFDRlCACELID9DAAAgQSA2QwAAlkWUIkAgQEMAACBBXRsiQCBAID9eG0PbD0lAlCA9lRDbgICAACFAIAJCADcDgAcgAkIANwP4BiA/QwAAIEEgNkMAgDtFlCI2IDZDAAAgQV0bIjYgNiA/XhtD2w9JQJQgPZUQ24CAgAAhPyACQgA3A/AGIAJCADcD6AZDzczMPiGVASBAIEBDAACAPyBAIEBDzczMPpKUQwAAgD+SlSKWAZQilwGUIZgBID8gP0MAAIA/ID8gP0Orqqo/kpRDAACAP5KVIpkBlCKaAZQhmwFDAACAPyA9Q28SgzqUIj8gPyA/XBsiP0MAAIA/ID9DAACAP14bIWcgPEPXo5A/lCI8Q81MTUOUID2VIV0gPEMzM5hDlCA9lSFeIDxDzcy4Q5QgPZUhXyA8Q82sAkSUID2VIWAgPEMAAAdElCA9lSFhIDxDAABIRJQgPZUhYkMAAAAAIVggPUMAAAAAlPwBIWhEAAAAAAAAAAAhWUOamZk/ITxB/wEhNEEGIW1DAAAAPyFsQQIhQ0EBIQlDzcxMPyFOQQAhRkMzM5PAQ28SgzogNSA1IDVcGyI/Q28SgzogP0NvEoM6XhsgPZSVEN6AgIAAIWYMAgtDAACAPyFOCyAkQQA6ABAgJEIANwAIICRCADcAACAjQgA3AAAgI0IANwAIICNBADoAECAiQgA3AAAgIkIANwAIICJBADoAECACQgA3A9AGIAJCADcD2AYgAkIANwPgBiACIAIpAAA3A5AGIAIgAikACDcDmAYgAiACKQAQNwOgBiACIAIpABg3A6gGIAIgAikAIDcDsAYgAiACKQAoNwO4BiACIAIpADA3A8AGIAIgAikANzcAxwYgPUNI4fo+lCI/QwAAIEFgRQ0YQgAhCyA/QwAAIEEgNkMAQBxGlCJAIEBDAAAgQV0bIkAgQCA/XhtD2w9JQJQgPZUQ24CAgAAhQCACQgA3A4AHIAJCADcD+AYgP0MAACBBIDZDAMDaRZQiNiA2QwAAIEFdGyI2IDYgP14bQ9sPSUCUID2VENuAgIAAIT8gAkIANwPwBiACQgA3A+gGQwAAgD8hlQEgQCBAQwAAgD8gQCBAQwAAgD+SlEMAAIA/kpUilgGUIpcBlCGYASA/ID9DAACAPyA/ID9Dq6qqP5KUQwAAgD+SlSKZAZQimgGUIZsBQwAAgD8gPUNvEgM6lCI/ID8gP1wbIj9DAACAPyA/QwAAgD9eGyFnIDxDzUxNQ5QgPZUhXSA8QzMzmEOUID2VIV4gPEPNzLhDlCA9lSFfIDxDzawCRJQgPZUhYCA8QwAAB0SUID2VIWEgPEMAAEhElCA9lSFiQwAAAAAhWCA9QwAAAACU/AEhaEQAAAAAAAAAACFZQ5qZmT8hPEH/ASE0QQYhbUMAAAA/IWxBAiFDQQEhCUEAIUZDMzOTwENvEoM6IDUgNSA1XBsiP0NvEoM6ID9DbxKDOl4bID2UlRDegICAACFmC0EAIURDAAAAACFjQwAAAAAhZEMAAAAAITlBACFFQQAhZUEBIWlBASFqQwAAAAAhawtBACERQwAAAAAhN0MAAAAAIW5DAAAAACFvQQAhcEEAIXFDAAAAACFyQwAAAAAhc0MAAAAAIXRCACENQwAAAAAhdUEAIXZBACF3QwAAAAAheEMAAAAAIXlDAAAAACF6QwAAAAAhe0EAIXxDAAAAACF9QwAAAAAhfgwlCyAbQQA6ABAgG0IANwAIIBtCADcAACAaQgA3AAAgGkIANwAIIBpBADoAECAZQgA3AAAgGUIANwAIIBlBADoAECACQgA3A/gFIAJCADcDgAYgAkIANwOIBiACIAIpAMADNwO4BSACIAIpAMgDNwPABSACIAIpANADNwPIBSACIAIpANgDNwPQBSACIAIpAOADNwPYBSACIAIpAOgDNwPgBSACIAIpAPADNwPoBSACIAIpAPcDNwDvBSA9Q0jh+j6UIj9DAAAgQWBFDRZCACELID9DAAB6RSA/QwAAekVdG0PbD0lAlCA9lRDbgICAACE/IAJCADcD4AcgAkIANwPYByACQgA3A9AHQwAAgD8hOUMAAIA/ID1DbxIDOpQiQCBAIEBcGyJAQwAAgD8gQEMAAIA/XhshhQFDAACAPyA9Q6abxDqUIkAgQCBAXBsiQEMAAIA/IEBDAACAP14bIWRDq6qqPyGMASA/ID9DAACAPyA/ID9Dq6qqP5KUQwAAgD+SlSKLAZQiigGUIYkBIDdDMzMzP5QhhgEgNSA8lCA9lSF6QwAAAAAhTCA9QwAAAACU/AEhRUMAAEDAID1DMQisPJSVEN6AgIAAvCFERAAAAAAAAAAAIVlDzcwMQCE8QYCAgIQEIXxDmpmZPiF7Q4/C9TwheEEBIWVB/wEhQ0EAIUZDMzOTwCA9Q6abRDyUlRDegICAACGEAUMAAIC/ID1DzcxMPZSVEN6AgIAAIVhDMzOTwENvEoM6IDYgNiA2XBsiP0NvEoM6ID9DbxKDOl4bID2UlRDegICAACFjQwAAAAAhS0MAAAAAIUpDAAAAACFJQwAAAAAhSEMAAAAAIUdDAAAAACFdQwAAAAAhXkMAAAAAIV9DAAAAACFgQwAAAAAhYUMAAAAAIWJBACEJQwAAAAAhZkMAAAAAIWdDAAAAACFOQQAhaEEAIWlB/wEhakMAAAAAIWtDAAAAACFsQQAhbUEAIRFDAAAAACE3QwAAAAAhbkMAAAAAIW9BACFwQQAhcUMAAAAAIXJDAAAAACFzQwAAAAAhdEIAIQ1DAAAAACF1QQAhdkEBIXdDAACAPyF5DB4LIBtBADoAECAbQgA3AAggG0IANwAAIBpCADcAACAaQgA3AAggGkEAOgAQIBlCADcAACAZQgA3AAggGUEAOgAQIAJCADcD+AUgAkIANwOABiACQgA3A4gGIAIgAikAwAM3A7gFIAIgAikAyAM3A8AFIAIgAikA0AM3A8gFIAIgAikA2AM3A9AFIAIgAikA4AM3A9gFIAIgAikA6AM3A+AFIAIgAikA8AM3A+gFIAIgAikA9wM3AO8FID1DSOH6PpQiP0MAACBBYEUNFkIAIQsgP0MAAJZEID9DAACWRF0bQ9sPSUCUID2VENuAgIAAIUAgP0MAACBBIDVDAMDaRZRDAIA7RZIiNSA1QwAAIEFdGyI1IDUgP14bQ9sPSUCUID2VENuAgIAAIT8gAkIANwPwByACQgA3A+gHIAJCADcD0AcgAkIANwPYByACQgA3A+AHQ6uqqj8hjAFDAACAPyF5ID8gP0MAAIA/ID8gP0Orqqo/kpRDAACAP5KVIpwBlCKdAZQhngFDAACAPyA9Q28SAzqUIj8gPyA/XBsiP0MAAIA/ID9DAACAP14bIYUBQwAAgD8gPUOmm8Q6lCI/ID8gP1wbIj9DAACAPyA/QwAAgD9eGyFkIEAgQEMAAIA/IEAgQEOrqqo/kpRDAACAP5KVIosBlCKKAZQhiQEgNkMAAEA/lCGGASA3IDyUIjxDAAA0Q5QgPZUheiA8QwAApUOUID2VIXRDAAAAACFYID1DAAAAAJT8ASFFQwrXozwhckMAAEDAID1DCtejPJSVEN6AgIAAvCJErSENRAAAAAAAAAAAIVlDZmamPyE8QZiz5vADIXxDmJkZPiF1Q5qZGT8hc0EBIWVB/wEhQ0EAIQlDAAAAPyE5QQIhRkMzM5PAQ28SgzogOCA4IDhcGyI/Q28SgzogP0NvEoM6XhsgPZSVEN6AgIAAIYQBQzMzk8BDbxKDOiA4Q8dxHD+UIj8gPyA/XBsiP0NvEoM6ID9DbxKDOl4bID2UlRDegICAACFjQwAAAAAhTEMAAAAAIUtDAAAAACFKQwAAAAAhSUMAAAAAIUhDAAAAACFHQwAAAAAhXUMAAAAAIV5DAAAAACFfQwAAAAAhYEMAAAAAIWFDAAAAACFiQwAAAAAhZkMAAAAAIWdDAAAAACFOQQAhaEEAIWlB/wEhakMAAAAAIWtDAAAAACFsQQAhbUEAIRFDAAAAACE3QwAAAAAhbkMAAAAAIW9BASFwQQEhcUEBIXZBASF3QwrXozwheEMAAAAAIXtDAAAAACF9QwAAAAAhfkEAITQMHgsgPUNI4fo+lCI8QwAAIEFgRQ0WQgAhCyA8QwAAIEEgNUMAgIlElCI/ID9DAAAgQV0bIj8gPyA8XhtD2w9JQJQgPZUQ24CAgAAhPCACQgA3A+AHIAJCADcD2AcgAkIANwPQB0MAACA/IYwBIDwgPEMAAIA/IDwgPEMAACA/kpRDAACAP5KVIosBlCKKAZQhiQFDAACAPyA9Q28SAzqUIjwgPCA8XBsiPEMAAIA/IDxDAACAP14bIYABID1DAisHPZT8ASGBASA9Q1g5tDyU/AEhggEgPUNYOTQ8lPwBIYMBQwAAAAAhWCA9QwAAAACU/AEhhwFEAAAAAAAAAAAhWUOamZk/ITxBBCGIAUMAAMA/IX5Dq6oqPyF9Qf8BIUNBACFEQQEhRkMzM5PAID1DvHSTPJSVEN6AgIAAIUBDMzOTwENvEoM6IDYgNiA2XBsiP0NvEoM6ID9DbxKDOl4bID2UlRDegICAACF/QwAAAAAhTEMAAAAAIUtDAAAAACFKQwAAAAAhSUMAAAAAIUhDAAAAACFHQwAAAAAhXUMAAAAAIV5DAAAAACFfQwAAAAAhYEMAAAAAIWFDAAAAACFiQwAAAAAhY0MAAAAAIWRDAAAAACE5QQAhRUEAIWVBACEJQwAAAAAhZkMAAAAAIWdDAAAAACFOQQAhaEEAIWlB/wEhakMAAAAAIWtDAAAAACFsQQAhbUEAIRFDAAAAACE3QwAAAAAhbkMAAAAAIW9BACFwQQAhcUMAAAAAIXJDAAAAACFzQwAAAAAhdEIAIQ1DAAAAACF1QQAhdkEAIXdDAAAAACF4QwAAAAAheUMAAAAAIXpDAAAAACF7QQAhfEH/ASE0QQEhB0EBIQxDAADAPyE/IEAhhAFDAACAPyA9Qxe30TmUIjYgNiA2XBsiNkMAAIA/IDZDAACAP14bIjUhhQFDAADAPyGGAQwjC0MAAEA/IU4LICdBADoAECAnQgA3AAggJ0IANwAAICZCADcAACAmQgA3AAggJkEAOgAQICVCADcAACAlQgA3AAggJUEAOgAQIAJCADcD0AYgAkIANwPYBiACQgA3A+AGIAIgAikAcDcDkAYgAiACKQB4NwOYBiACIAIpAIABNwOgBiACIAIpAIgBNwOoBiACIAIpAJABNwOwBiACIAIpAJgBNwO4BiACIAIpAKABNwPABiACIAIpAKcBNwDHBiA9Q0jh+j6UIj9DAAAgQWBFDRVCACELID9DAAAgQSA2QwBg6kWUIkAgQEMAACBBXRsiQCBAID9eG0PbD0lAlCA9lRDbgICAACE/IAJCADcD8AYgAkIANwPoBiA/ID9DAACAPyA/ID9Dq6qqP5KUQwAAgD+SlSKZAZQimgGUIZsBQwAAgD8gPUNvEgM6lCI/ID8gP1wbIj9DAACAPyA/QwAAgD9eGyFnIDxDmvmZQ5QgPZUhXSA8Q8xM5EOUID2VIV4gPEOamQpElCA9lSFfIDxDNANERJQgPZUhYCA8QwCASkSUID2VIWEgPEMAAJZElCA9lSFiQwAAAAAhWCA9QwAAAACU/AEhaEQAAAAAAAAAACFZQ5qZmT8hPEEGIW1DAAAAPyFsQzMzsz4ha0H/ASFqQQIhQ0EBIQlBACFGQzMzk8BDbxKDOiA1IDUgNVwbIj9DbxKDOiA/Q28SgzpeGyA9lJUQ3oCAgAAhZkEAIURDAAAAACFjQwAAAAAhZEMAAAAAITlBACFFQQAhZUEBIWkMHQtBACFGIBtBADoAECAbQgA3AAggG0IANwAAIBpCADcAACAaQgA3AAggGkEAOgAQIBlCADcAACAZQgA3AAggGUEAOgAQIAJCADcD+AUgAkIANwOABiACQgA3A4gGIAIgAikAwAM3A7gFIAIgAikAyAM3A8AFIAIgAikA0AM3A8gFIAIgAikA2AM3A9AFIAIgAikA4AM3A9gFIAIgAikA6AM3A+AFIAIgAikA8AM3A+gFIAIgAikA9wM3AO8FQwAAgD8heUMAAIA/ID1DppvEOpQiPyA/ID9cGyI/QwAAgD8gP0MAAIA/XhshZCA3Q5qZmT6UITkgPEMAoMRElCA9lSFuIDxDAGCFRJQgPZUhbyA8QwDAG0SUID2VIXQgPEMAANxDlCA9lSF6QwAAAAAhWCA9QwAAAACU/AEhRUMAAEDAID1DbxKDOpSVEN6AgIAAIT9EAAAAAAAAAAAhWUPNzIw/ITxBASFlQf8BIUNDMzOTwENvEoM6IDYgNiA2XBsiQENvEoM6IEBDbxKDOl4bID2UlRDegICAACFjQwAAAAAhTEMAAAAAIUtDAAAAACFKQwAAAAAhSUMAAAAAIUhDAAAAACFHQwAAAAAhXUMAAAAAIV5DAAAAACFfQwAAAAAhYEMAAAAAIWFDAAAAACFiQQAhCUMAAAAAIWZDAAAAACFnQwAAAAAhTkEAIWhBACFpQf8BIWpDAAAAACFrQwAAAAAhbEEAIW1BASERQQAhcEEBIXFDAAAAACFyIDhDMzMzP5RDmpkZPpIiNyFzID+8IkStIgshDUMAAAAAIXVBASF2QQEhd0MAAAAAIXgMHQtBACFGIBtBADoAEEIAIQsgG0IANwAIIBtCADcAACAaQgA3AAAgGkIANwAIIBpBADoAECAZQgA3AAAgGUIANwAIIBlBADoAECACQgA3A/gFIAJCADcDgAYgAkIANwOIBiACIAIpAMADNwO4BSACIAIpAMgDNwPABSACIAIpANADNwPIBSACIAIpANgDNwPQBSACIAIpAOADNwPYBSACIAIpAOgDNwPgBSACIAIpAPADNwPoBSACIAIpAPcDNwDvBUMAAIA/IXlDAACAPyA9Q6abxDqUIj8gPyA/XBsiP0MAAIA/ID9DAACAP14bIWQgN0PNzEw/lCE5IDhDAAAAP5QhcyA8QwAAREOUIjwgPZUheiA8QwCAm0OUQwAAREOVID2VIXRDAAAAACFYID1DAAAAAJT8ASFFQwAAQMAgPUMpXA89lJUQ3oCAgAC8IkStIQ1EAAAAAAAAAAAhWUOamZk/ITxBzJmz9gMhfEMK1yM9IXhDzMzMPiF1QQEhZUH/ASFDQzMzk8BDbxKDOiA2IDYgNlwbIj9DbxKDOiA/Q28SgzpeGyA9lJUQ3oCAgAAhYwwBC0EAIUYgG0EAOgAQQgAhCyAbQgA3AAggG0IANwAAIBpCADcAACAaQgA3AAggGkEAOgAQIBlCADcAACAZQgA3AAggGUEAOgAQIAJCADcD+AUgAkIANwOABiACQgA3A4gGIAIgAikAwAM3A7gFIAIgAikAyAM3A8AFIAIgAikA0AM3A8gFIAIgAikA2AM3A9AFIAIgAikA4AM3A9gFIAIgAikA6AM3A+AFIAIgAikA8AM3A+gFIAIgAikA9wM3AO8FQwAAgD8heUMAAIA/ID1DppvEOpQiPyA/ID9cGyI/QwAAgD8gP0MAAIA/XhshZCA3QzMzcz+UITkgOEMAAAA/lCFzIDxDAADEQpQiPCA9lSF6IDxDAADAP5QgPZUhdEMAAAAAIVggPUMAAAAAlPwBIUVDAABAwCA9QylcDz2UlRDegICAALwiRK0hDUQAAAAAAAAAACFZQ2Zmpj8hPEGas+b8AyF8Q83MTD0heEPMzMw+IXVBASFlQf8BIUNDMzOTwENvEoM6IDYgNiA2XBsiP0NvEoM6ID9DbxKDOl4bID2UlRDegICAACFjC0MAAAAAIUxDAAAAACFLQwAAAAAhSkMAAAAAIUlDAAAAACFIQwAAAAAhR0MAAAAAIV1DAAAAACFeQwAAAAAhX0MAAAAAIWBDAAAAACFhQwAAAAAhYkEAIQlDAAAAACFmQwAAAAAhZ0MAAAAAIU5BACFoQQAhaUH/ASFqQwAAAAAha0MAAAAAIWxBACFtQQAhEUMAAAAAITdDAAAAACFuQwAAAAAhb0EAIXBBASFxQwAAAAAhckEAIXZBASF3QwAAAAAhewwbCyAbQQA6ABAgG0IANwAIIBtCADcAACAaQgA3AAAgGkIANwAIIBpBADoAECAZQgA3AAAgGUIANwAIIBlBADoAECACQgA3A/gFIAJCADcDgAYgAkIANwOIBiACIAIpAMADNwO4BSACIAIpAMgDNwPABSACIAIpANADNwPIBSACIAIpANgDNwPQBSACIAIpAOADNwPYBSACIAIpAOgDNwPgBSACIAIpAPADNwPoBSACIAIpAPcDNwDvBSA9Q0jh+j6UIj9DAAAgQWBFDRFCACELID9DAAB6RSA/QwAAekVdG0PbD0lAlCA9lRDbgICAACE/IAJCADcD4AcgAkIANwPYByACQgA3A9AHQwAAgD8heUMAAIA/ID1DF7dROZQiQCBAIEBcGyJAQwAAgD8gQEMAAIA/XhshhQFDAACAPyA9Q6abxDqUIkAgQCBAXBsiQEMAAIA/IEBDAACAP14bIWRDq6qqPyGMASA/ID9DAACAPyA/ID9Dq6qqP5KUQwAAgD+SlSKLAZQiigGUIYkBIDdDzczMPZQhhgEgOEOamRk/lCFzIDdDmpkZP5QhOSA8QwBAtUSUID2VIXogPEMAsHRFlCA9lSF0QwAAAAAhWCA9QwAAAACU/AEhRUMAAEDAID1DCtejO5SVEN6AgIAAvCFEQwAAQMAgPUNvEoM6lJUQ3oCAgAC8rSENRAAAAAAAAAAAIVlDMzOzPyE8QcCZs+oDIXxBASFlQf8BIUNBACEJQQIhRkMzM5PAID1DbxKDO5SVEN6AgIAAIYQBQzMzk8BDbxKDOiA2IDYgNlwbIj9DbxKDOiA/Q28SgzpeGyA9lJUQ3oCAgAAhY0MAAAAAIUxDAAAAACFLQwAAAAAhSkMAAAAAIUlDAAAAACFIQwAAAAAhR0MAAAAAIV1DAAAAACFeQwAAAAAhX0MAAAAAIWBDAAAAACFhQwAAAAAhYkMAAAAAIWZDAAAAACFnQwAAAAAhTkEAIWhBACFpQf8BIWpDAAAAACFrQwAAAAAhbEEAIW1BACERQwAAAAAhN0MAAAAAIW5DAAAAACFvQQAhcEEBIXFDAAAAACFyQwAAAAAhdUEAIXZBASF3QwAAAAAheAwUCyA9Q0jh+j6UIj9DAAAgQWBFDRFCACELID9DAAAgQUMAoIxGIDhDAAAAP5IgPEMAIMtFlJQiPCA8IDxcGyI8QwCgjEYgPEMAoIxGXRsiPCA8QwAAIEFdGyI8IDwgP14bQ9sPSUCUID2VENuAgIAAITwgP0MAgDtFID9DAIA7RV0bQ9sPSUCUID2VENuAgIAAIT8gAkIANwPwByACQgA3A+gHIAJCADcD0AcgAkIANwPYByACQgA3A+AHQ1VVVT8hjAEgPCA8QwAAgD8gPCA8Q1VVVT+SlEMAAIA/kpUiiwGUIooBlCGJAUMAAIA/ID1DbxKDO5QiPCA8IDxcGyI8QwAAgD8gPEMAAIA/XhshhQEgPyA/QwAAgD8gPyA/Q6uqqj+SlEMAAIA/kpUinAGUIp0BlCGeASA3Q2ZmZj+UIYYBQwAAAAAhWCA9QwAAAACU/AEhhwFEAAAAAAAAAAAhWUOamZk/ITxBASFGQQIhNEH/ASFDQQAhREMzM5PAQ28SgzogNiA2IDZcGyI/Q28SgzogP0NvEoM6XhsgPZSVEN6AgIAAIYQBQwAAAAAhTEMAAAAAIUtDAAAAACFKQwAAAAAhSUMAAAAAIUhDAAAAACFHQwAAAAAhXUMAAAAAIV5DAAAAACFfQwAAAAAhYEMAAAAAIWFDAAAAACFiQwAAAAAhY0MAAAAAIWRDAAAAACE5QQAhRUEAIWVBACEJQwAAAAAhZkMAAAAAIWdDAAAAACFOQQAhaEEAIWlB/wEhakMAAAAAIWtDAAAAACFsQQAhbUEAIRFDAAAAACE3QwAAAAAhbkMAAAAAIW9BACFwQQAhcUMAAAAAIXJDAAAAACFzQwAAAAAhdEIAIQ1DAAAAACF1QQAhdkEAIXdDAAAAACF4QwAAAAAheUMAAAAAIXpDAAAAACF7QQAhfEMAAAAAIX1DAAAAACF+QQEhB0EAIQxDAAAAACF/QwAAAAAhgAFDAAAAACE/QQAhgQFDAAAAACFAQwAAAAAhNUEAIYIBQQAhgwFBASGIAQwbCyA9Q0jh+j6UIj9DAAAgQWBFDRFCACELID9DAAAgQUMAAHpGIDhDAIC7RZRDAIC7RJIgPJQiPCA8IDxcGyI8QwAAekYgPEMAAHpGXRsiPCA8QwAAIEFdGyI8IDwgP14bQ9sPSUCUID2VENuAgIAAITwgAkIANwPgByACQgA3A9gHIAJCADcD0AdDq6qqPyGMASA8IDxDAACAPyA8IDxDq6qqP5KUQwAAgD+SlSKLAZQiigGUIYkBQwAAgD8gPUNvEgM8lCI8IDwgPFwbIjxDAACAPyA8QwAAgD9eGyGFASA3Q2ZmJj+UIYYBQwAAAAAhNyA9QwAAAACU/AEhhwFEAAAAAAAAAAAhWUOamZk/ITxBASGIAUH/ASFDQQAhRUECIUZDMzOTwENvEoM6IDYgNiA2XBsiP0NvEoM6ID9DbxKDOl4bID2UlRDegICAACGEAUMAAAAAIVhBACFEQwAAAAAhTEMAAAAAIUtDAAAAACFKQwAAAAAhSUMAAAAAIUhDAAAAACFHQwAAAAAhXUMAAAAAIV5DAAAAACFfQwAAAAAhYEMAAAAAIWFDAAAAACFiQwAAAAAhY0MAAAAAIWRDAAAAACE5QQAhZUEAIQlDAAAAACFmQwAAAAAhZ0MAAAAAIU5BACFoQQAhaUH/ASFqQwAAAAAha0MAAAAAIWxBACFtQQAhEUMAAAAAIW5DAAAAACFvQQAhcEEAIXFDAAAAACFyQwAAAAAhc0MAAAAAIXRCACENQwAAAAAhdUEAIXZBACF3QwAAAAAheEMAAAAAIXlDAAAAACF6QwAAAAAhe0EAIXxDAAAAACF9QwAAAAAhfkH/ASE0QQEhB0EAIQxDAAAAACF/QwAAAAAhgAFDAAAAACE/QQAhgQFDAAAAACFAQwAAAAAhNUEAIYIBQQAhgwEMGgsgRiBFQZSLwIAAEIuAgIAAAAsgAkGAgICNBDYC+AYgAiBPOALoByACQYGAgIAArUIghiILIAJB6AdqrYQ3A8gDIAIgCyACQfgGaq2ENwPAA0HPgcCAACACQcADakHkiMCAABCCgICAAAALIAJBgICAiQQ2AvgGIAIgPzgC6AcgAkGBgICAAK1CIIYiCyACQegHaq2ENwPIAyACIAsgAkH4BmqthDcDwANBz4HAgAAgAkHAA2pB5IjAgAAQgoCAgAAACyACQYCAgIkENgL4BiACID84AugHIAJBgYCAgACtQiCGIgsgAkHoB2qthDcDyAMgAiALIAJB+AZqrYQ3A8ADQc+BwIAAIAJBwANqQeSIwIAAEIKAgIAAAAsgAkGAgICJBDYC+AYgAiA/OALoByACQYGAgIAArUIghiILIAJB6AdqrYQ3A8gDIAIgCyACQfgGaq2ENwPAA0HPgcCAACACQcADakHkiMCAABCCgICAAAALIAJBgICAiQQ2AvgGIAIgPzgC6AcgAkGBgICAAK1CIIYiCyACQegHaq2ENwPIAyACIAsgAkH4BmqthDcDwANBz4HAgAAgAkHAA2pB5IjAgAAQgoCAgAAACyACQYCAgIkENgL4BiACIDw4AugHIAJBgYCAgACtQiCGIgsgAkHoB2qthDcDyAMgAiALIAJB+AZqrYQ3A8ADQc+BwIAAIAJBwANqQeSIwIAAEIKAgIAAAAsgAkGAgICJBDYC+AYgAiA/OALoByACQYGAgIAArUIghiILIAJB6AdqrYQ3A8gDIAIgCyACQfgGaq2ENwPAA0HPgcCAACACQcADakHkiMCAABCCgICAAAALIAJBgICAiQQ2AvgGIAIgPzgC6AcgAkGBgICAAK1CIIYiCyACQegHaq2ENwPIAyACIAsgAkH4BmqthDcDwANBz4HAgAAgAkHAA2pB5IjAgAAQgoCAgAAACyACQYCAgIkENgL4BiACID84AugHIAJBgYCAgACtQiCGIgsgAkHoB2qthDcDyAMgAiALIAJB+AZqrYQ3A8ADQc+BwIAAIAJBwANqQeSIwIAAEIKAgIAAAAsgAkGAgICJBDYC+AYgAiA/OALoByACQYGAgIAArUIghiILIAJB6AdqrYQ3A8gDIAIgCyACQfgGaq2ENwPAA0HPgcCAACACQcADakHkiMCAABCCgICAAAALIAJBgICAiQQ2AvgGIAIgPzgC6AcgAkGBgICAAK1CIIYiCyACQegHaq2ENwPIAyACIAsgAkH4BmqthDcDwANBz4HAgAAgAkHAA2pB5IjAgAAQgoCAgAAACyACQYCAgIkENgL4BiACID84AugHIAJBgYCAgACtQiCGIgsgAkHoB2qthDcDyAMgAiALIAJB+AZqrYQ3A8ADQc+BwIAAIAJBwANqQeSIwIAAEIKAgIAAAAsgAkGAgICJBDYC+AYgAiA8OALoByACQYGAgIAArUIghiILIAJB6AdqrYQ3A8gDIAIgCyACQfgGaq2ENwPAA0HPgcCAACACQcADakHkiMCAABCCgICAAAALIAJBgICAiQQ2AvgGIAIgPzgC6AcgAkGBgICAAK1CIIYiCyACQegHaq2ENwPIAyACIAsgAkH4BmqthDcDwANBz4HAgAAgAkHAA2pB5IjAgAAQgoCAgAAACyACQYCAgIkENgL4BiACID84AugHIAJBgYCAgACtQiCGIgsgAkHoB2qthDcDyAMgAiALIAJB+AZqrYQ3A8ADQc+BwIAAIAJBwANqQeSIwIAAEIKAgIAAAAsgAkGAgICJBDYC+AYgAiA/OALoByACQYGAgIAArUIghiILIAJB6AdqrYQ3A8gDIAIgCyACQfgGaq2ENwPAA0HPgcCAACACQcADakHkiMCAABCCgICAAAALIAJBgICAiQQ2AvgGIAIgPzgC6AcgAkGBgICAAK1CIIYiCyACQegHaq2ENwPIAyACIAsgAkH4BmqthDcDwANBz4HAgAAgAkHAA2pB5IjAgAAQgoCAgAAAC0MAAAAAIXsLQwAAAAAhfUMAAAAAIX5B/wEhNAtBASEHQQAhDEMAAAAAIX9DAAAAACGAAUMAAAAAIT9BACGBAUMAAAAAIUBDAAAAACE1QQAhggFBACGDAQsgRSGHAUEBIYgBDAQLQQAhEUMAAAAAITdDAAAAACFuQwAAAAAhb0EAIXBBACFxQwAAAAAhckMAAAAAIXNDAAAAACF0QgAhDUMAAAAAIXVBACF2QQAhd0MAAAAAIXhDAAAAACF5QwAAAAAhegtDAAAAACF7QQAhfAtDAAAAACF9QwAAAAAhfkH/ASE0C0EAIQdBACEMQwAAAAAhf0MAAAAAIYABQwAAAAAhP0EAIYEBQwAAAAAhQEMAAAAAITVBACGCAUEAIYMBQwAAAAAhhAFDAAAAACGFAUMAAAAAIYYBQQAhhwFBACGIAUMAAAAAIYkBQwAAAAAhigFDAAAAACGLAUMAAAAAIYwBC0MAAAAAIY0BQwAAAAAhjgFDAAAAACGPAUMAAAAAIZABQQAhCEMAAAAAIVxDAAAAACFVQwAAAAAhOEEAIVtBACGRAUH/ASGSAUEAIZMBQwAAAAAhlAELRAAAAAAAAAAAIVoLIAAtALgjIZ8BQwAAgD9DAACAvyA6IDpDAACAv10bIjYgNkMAAIA/XhtDAACAP5JD2w9JQJRDAACAPpQiNhDhgICAACE6IDYQ5oCAgAAhoAFDAACAPyE2AkAgPEMAAAAAXkUNAEMAAIA/QwAAgD9DAACAvyA8IDwgPJQiNiA2IDZDAAC9Q5KUQwBah0aSlEPA9wNIkpQgNiA2IDZDAADgQZRDAOBERZKUQwCic0eSlEPA9wNIkpUiNiA2QwAAgL9dGyI2IDZDAACAP14blSE2CyAEIAAoAggiCk8NAiAAKAIEIEFqIEJBqAlsaiIKIE84AiQgCiBQOAIgIAogWTkDGCAKIFo5AxAgCkIANwMIIAogOkMAAIA/Q/MEtT8gnwFBAksbIqEBlDgCBCAKIKABIKEBlDgCACAKIAIpA8ADNwMoIAogAikDyAM3AzAgCiAINgJsIAogkQE2AmggCiCSAToAZCAKQf601vwDNgJgIApC6LS7/ZPl2Z0/NwNYIAogVzgCVCAKQs2Zs/LTmbPGPzcCTCAKIFE4AkggCiBWOAJEIAogVDgCQCAKIFM4AjwgCiBSOAI4IAogWzYCiAEgCiA4OAKMASAKIFU4ApABIAogXDgClAEgCkEAOgCYASAKIAIpA9gINwOAASAKIAIpA9AINwN4IAogAikDyAg3A3AgCiACKQOICDcAmQEgCiACKQOQCDcAoQEgCiACKQOYCDcAqQEgCiACKQOgCDcAsQEgCiACKQOoCDcAuQEgCiACKQOwCDcAwQEgCiACKQO4CDcAyQEgCiACKQC/CDcA0AEgCiCNATgCmAIgCiCOATgClAIgCiCPATgCkAIgCiCQATgCjAIgCiA9OAKIAiAKID5BAXJBte/J5AJsNgKEAiAKQoCAgPyDgIDAPzcC/AEgCkMAAIBAQwAAAAAgOyA7QwAAAABdGyI9ID1DAACAQF4bIE2UOAL4ASAKIDY4AvQBIAogPDgC8AEgCiCTATYC7AEgCiCUATgC6AEgCiA5OALkASAKQQA2AuABIAogCDoA3AEgCkEAOwHYASAKIAIpA/gHNwKcAiAKIAIpA4AINwKkAiAKIJ4BOAK8AiAKIJ0BOAK4AiAKIJwBOAK0AiAKQavVqv0DNgKwAiAKQQA6AKwCIAogAikD8Ac3A8gCIAogAikD6Ac3A8ACIAogiAE2AvgCIAogRjoA9AIgCkIANwLsAiAKIH04AugCIAogfjgC5AIgCiCJATgC4AIgCiCKATgC3AIgCiCLATgC2AIgCiCMATgC1AIgCiA0OgDQAiAKIAIpA+AHNwKMAyAKIAIpA9gHNwKEAyAKIAIpA9AHNwL8AiAKQf8BOgCMBCAKIAc6AOgDIApBADsB5AMgCiAMOgDgAyAKIH84AtwDIAoggAE4AtgDIAogPzgC1AMgCiCBATYC0AMgCiAMOgDMAyAKIEA4AsgDIAogNTgCxAMgCiA/OALAAyAKIIIBNgK8AyAKIAw6ALgDIAogQDgCtAMgCiA1OAKwAyAKID84AqwDIAoggwE2AqgDIAogBzoApAMgCiCEATgCoAMgCiCFATgCnAMgCiCGATgCmAMgCiCHATYClAMgCiACKALIBzYArQQgCiACKQPABzcApQQgCiACKQO4BzcAnQQgCiACKQOwBzcAlQQgCiACKQOoBzcAjQQgCiACKQOIBzcAsQQgCiACKQOQBzcAuQQgCiACKQOYBzcAwQQgCiACKQCfBzcAyAQgCkHQBGogAkGAAmpB0AD8CgAAIAogmAE4AoAHIAoglwE4AvwGIAoglgE4AvgGIAoglQE4AvQGIAogazgC8AYgCiBsOALsBiAKIG02AugGIAogYjgC5AYgCiBhOALgBiAKIGA4AtwGIAogXzgC2AYgCiBeOALUBiAKIF04AtAGIAogRzgCzAYgCiBIOALIBiAKIEk4AsQGIAogSjgCwAYgCiBLOAK8BiAKIEw4ArgGIApBADoAtQYgCiAROgC0BiAKQQA2ArAGIAogNzgCrAYgCiBuOAKoBiAKQQA2AqQGIAogCzcCnAYgCkIANwKUBiAKQQA6AJEGIAogEToAkAYgCkEANgKMBiAKIDc4AogGIAogbzgChAYgCkEANgKABiAKIAs3A/gFIApCADcD8AUgCiBwOgDtBSAKIHE6AOwFIAogcjgC6AUgCiBzOALkBSAKIHQ4AuAFIApBADYC3AUgCiANNwLUBSAKQQA2AtAFIAogdTgCzAUgCiB2OgDJBSAKIHc6AMgFIAogeDgCxAUgCiB5OALABSAKIHo4ArwFIApBADYCuAUgCiBYOAK0BSAKIEQ2ArAFIAogezgCrAUgCiB8NgKoBSAKQQA6AKQFIApBADsBoAUgCiCZATgCnAcgCiCaATgCoAcgCiCbATgCpAcgCkGr1ar9AzYCmAcgCiBqOgCUByAKIGk2ArwHIAogQzoAuAcgCiACKQOABzcCjAcgCiACKQP4BjcChAcgCiACKQPoBjcDqAcgCiACKQPwBjcDsAcgCiACKQPQBjcDwAcgCiACKQPYBjcDyAcgCiACKQPgBjcD0AcgCiAJOgDoByAKIGY4AuQHIAogZzgC4AcgCiBOOALcByAKIGg2AtgHIAogAikDkAY3AOkHIAogAikDmAY3APEHIAogAikDoAY3APkHIAogAikDqAY3AIEIIAogAikDsAY3AIkIIAogAikDuAY3AJEIIAogAikDwAY3AJkIIAogAikAxwY3AKAIIAogZTYCsAggCiAJOgCsCCAKQQA7AagIIAogAikDiAY3AsQIIAogAikDgAY3ArwIIAogAikD+AU3ArQIIApBADoA3AggCiBjOALYCCAKIGQ4AtQIIAogOTgC0AggCiBFNgLMCCAKIAIpAO8FNwCUCSAKIAIpA+gFNwCNCSAKIAIpA+AFNwCFCSAKIAIpA9gFNwD9CCAKIAIpA9AFNwD1CCAKIAIpA8gFNwDtCCAKIAIpA8AFNwDlCCAKIAIpA7gFNwDdCCAKQQE6AKAJIApBADsBnAkLIDJBAWoiMiADRw0ACyADITIgEiE0DAELIAQgCkGEisCAABCLgICAAAALAkACQAJAAkAgNEEBdCIKIDFBAXQiDEkNACAKIAxrInxBAnQhcSAxQQN0IWoCQCAKIAxGImkNACAAIGpqIQoCQCBxRSIMDQAgCkGwC2pBACBx/AsACyAMDQAgCkGwE2pBACBx/AsACyATIHFqIXYgACgCBCJlIAAoAghB0BJsaiFtQQAhd0EAIQxBAA0CDAELIAwgCkGAAkGUisCAABCMgICAAAALQQEhCgwBC0EAIQoLAkADQAJAAkACQAJAAkACQCAKDgIAAQELIHcgZUYNBCB3QaAJaiEKIHdBqAlqIgkhdyAKLQAADQEMAwsgZSFEAkADQCBEIG1GDQcgREHQEmohZSBEQaAJai0AAA0BIERByBJqIQogZSFEIAotAABBAUcNAAsgZUGwbWpBqAlqIUQgZSF3DAILIERBqAlqIXcMAQsgCUHYdmohRCAJIXcLIAAoAiwhWyAAKAIoIYEBAkAgaQ0AIHFFDQAgE0EAIHH8CwALIEQoAuABIXACQCBELQDIBUUNACBEQagFaiFGIAIgREGwCGoiQ0HwAPwKAAACQAJAIEQtAOwFQQFGDQBBJCEKDAELAkAgRC0AkAZBAUYNAEHIACEKDAELQZABQewAIEQtALQGGyEKCyBEKgLkASE8IAJB8ABqIEZBkAH8CgAAAkAgaQ0AQwAAgD8gPJVDAAAAACA8QwAAAABeGyE5IAJB8ABqIApqIQlBACEIIAItAGwhByACLQBtIT4gAigCFCFFIAIqAgwhOiACKgIIITggAioCGCE3IAIqAhAhNSACKAIEIQQgAigCACExIBMhEQNAAkACQAJAAkACQAJAAkACQCAEIDFPDQAgBEEETw0BIAggcGogMCAEQRRsaiIKKAIATw0CCyAHID5xQQFxRQ0CIEUhCgwECyAEQQRBpIrAgAAQi4CAgAAACyACIAotABAiDDoAbSACQQE6AGwgBEEBaiEEIAoqAgwhNyAKKgIIITwgCioCBCE1IAwNASA1IDiTIDyVITpBACE+DAMLIAdBAXENAkMAAAAAIDggN5QiPCA8i0MI5TweXRshOEEAIQcMAwtDAACAP0MAAIC/IDyVEN6AgIAAkyE6IDxDAACgQJT8ASEKCyAKIApBAEdrIUUgOCA1IDiTIDqUkiE4QQEhPgJAIApBAkkNAEEBIQcMAgtBACEHIAJBADoAbAwBCyA4IDqSITgCQAJAIDpDAAAAAGBFDQAgOCA1YA0BC0EBIQcgOkMAAAAAXUUNASA4IDVfRQ0BC0EAIQcgAkEAOgBsIDUhOAsgOSA4lCE2IAJB8ABqIQpDAAAAACE9A0AgCkMAAAAAIAoqAgAiPCAKQQhqKgIAlCI/ID+LQwjlPB5dGzgCACAKQQRqIgxDAAAAACAMKgIAIj8gCkEMaioCAJQiQCBAi0MI5TweXRs4AgAgCkEQaiIMIAwqAgBDZmbmPiA/IDxDAACAP5KSIDYgCkEcaioCAJRDAACAP5KUIApBFGoqAgCUIjwgPCA8XBsiPENmZuY+IDxDZmbmPl0bkiI8QwAAgL+SIDwgPEMAAIA/YBsiPDgCACAKQRhqKgIAIT8CQAJAIApBIWotAAANAAJAAkAgPEPbD8lAlCI8Q9sPycCSIDwgPEPbD0lAXhsiPEPbD8k/Xg0AIDxD2w/Jv11FDQFD2w9JwCA8kyE8DAELQ9sPSUAgPJMhPAsgPEMAAIA/IDwgPJQiQEOrqio+IEAgQEMAgJ3FlUOJiAg8kpSTlJOUITwMAQsgPEMAAAC/kotDAACAwJRDAACAP5IhPAsgPSA/IDyUkiE9IApBJGoiCiAJRw0ACyARIDggPZQgESoCAJI4AgAgCEEBaiEIIBFBBGoiESB2Rw0ACyACIDc4AhggAiA1OAIQIAIgRTYCFCACIDo4AgwgAiA4OAIIIAIgBDYCBAsgQyACQfAA/AoAACBGIAJB8ABqQZAB/AoAAAsgREGwAmohaCBEKAKEAiEMQQAhCkEBIUEDQAJAIGggCkG8AWxqIkItALgBRQ0AIAJBgAJqIEJBvAH8CgAAAkAgaQ0AIAItALQDIQQgAi0AtQMhMSACKALcAiFDIAIqAtQCIUcgAioC0AIhPSACKgLgAiFgIAIqAtgCIUkgAigCzAIhCSACKgKYAiE5IAIqApwCITcgAioCvAIhPyACKgLAAiFAIAIoAsgCIUUgAioCgAIhYSACKgKMAiFdIAIqApQCIWIgAioCkAIhTSACKgKIAiFKIAIqAoQCIV4gAi0AoAIhPiACKgKkAiFYIAItAMQCIUYgAioCsAIhTCACKgK4AiFfIAIqArQCIUggAioCrAIhOyACKgKoAiFOIHAhESBxIQcgEyEIA0AgCCEKIE4gP5QgOyAMQQ10IAxzIgxBEXYgDHMiDEEFdCAMcyIMs0MAAIAvlCI8IDySQwAAgL+SIjggQJMiNpSSITwCQCBIQwAAAABeRQ0AIF9DAACAP0MAAIC/QwAAoEBDAACgwCBIIDyUIjwgPEMAAKDAXRsiPCA8QwAAoEBeGyI8IDwgPJQiPCA8IDxDAAC9Q5KUQwBah0aSlEPA9wNIkpQgPCA8IDxDAADgQZRDAOBERZKUQwCic0eSlEPA9wNIkpUiPCA8QwAAgL9dGyI8IDxDAACAP14blCE8CyBAIDsgP5SSIEwgNpSSIjYhNQJAAkACQCBGDgMCAAECCyBYIDyUITUMAQsgOCBYIDyUkyA2kyE1CwJAAkAgPkH/AUcNACA1ITgMAQsgXiA5lCBKIDUgN5MiS5SSIToCQCBNQwAAAABeRQ0AIGJDAACAP0MAAIC/QwAAoEBDAACgwCBNIDqUIjggOEMAAKDAXRsiOCA4QwAAoEBeGyI4IDggOJQiOCA4IDhDAAC9Q5KUQwBah0aSlEPA9wNIkpQgOCA4IDhDAADgQZRDAOBERZKUQwCic0eSlEPA9wNIkpUiOCA4QwAAgL9dGyI4IDhDAACAP14blCE6C0MAAAAAIDcgSiA5lJIgXSBLlJIiOCA4kiA3kyI3IDeLQwjlPB5dGyE3QwAAAAAgOiA6kiA5kyI5IDmLQwjlPB5dGyE5AkACQCA+DgMCAAECCyBhIDqUITgMAQsgNSBhIDqUkyA4kyE4CwJAAkACQAJAAkACQAJAAkAgCSBFTw0AIAlBBE8NASARIC8gCUEUbGoiCCgCAE8NAgsgBCAxcUEBcUUNAiBDIQQMBAsgCUEEQaSKwIAAEIuAgIAAAAsgAiAILQAQIgQ6ALUDIAJBAToAtAMgCUEBaiEJIAgqAgwhYCAIKgIIITogCCoCBCFJIAQNASBJID2TIDqVIUdBACExDAMLIARBAXENAkMAAAAAID0gYJQiPSA9i0MI5TweXRshPUEAIQQMAwtDAACAP0MAAIC/IDqVEN6AgIAAkyFHIDpDAACgQJT8ASEECyAEIARBAEdrIUMgPSBJID2TIEeUkiE9QQEhMQJAIARBAkkNAEEBIQQMAgtBACEEIAJBADoAtAMMAQsgPSBHkiE9AkACQCBHQwAAAABgRQ0AID0gSWANAQtBASEEIEdDAAAAAF1FDQEgPSBJX0UNAQtBACEEIAJBADoAtAMgSSE9CyAKQQRqIQhDAAAAACA2IDaSIECTIkAgQItDCOU8Hl0bIUBDAAAAACA8IDySID+TIjwgPItDCOU8Hl0bIT8gCiAKKgIAIDggPZSSOAIAIBFBAWohESAHQXxqIgcNAAsgAiA/OAK8AiACIEA4AsACIAIgNzgCnAIgAiBgOALgAiACIEk4AtgCIAIgCTYCzAIgAiA5OAKYAiACIEM2AtwCIAIgRzgC1AIgAiA9OALQAgsgQiACQYACakG8AfwKAAALQQEhCiBBQQFxIQlBACFBIAkNAAsCQCBELQCsCEUNACACQcADaiBEQbgGaiJCQfgB/AoAAAJAIGkNAEMAAIA/IAIqAuwDIokBkyFcQwAAgD8gAioC6AMieZMhVUMAAIA/IAIqAuQDIm+TIYwBQwAAgD8gAioC4AMiYJMhekMAAIA/IAIqAtwDIkqTIXJDAACAPyACKgLYAyI2kyFhIAItALAFIQggAi0AsQUhRiACKALYBCFBIAIqAtAEIUggAioCzAQhPCACKgLcBCFrIAIqAtQEIUkgAigCyAQhCSACKALEBCFDIAIqAqAEIWwgAioCrAQhYiACKgK0BCF0IAIqArAEIV4gAioCqAQhSyACKgKkBCFjIAItAMAEITEgAioC+AMhWCACKgL8AyFuIAIqAogEIWQgAioCkAQhdSACKgKMBCFfIAIqAoQEIUwgAioCgAQhZiACLQCcBCFFIAIqAvQDIV0gAioCuAQhOCACKgK8BCE6IAIqApQEITUgAioCmAQhOSACKgLUAyGGASACKgLQAyF4IAIqAswDIWcgAioCyAMhTSACKgLEAyE7IAIqAsADIT0gAigC8AMiBEEGRiFoIHEhPiBwIREgEyEHA0AgByEKAkACQCAEDQBDAAAAACE/DAELID1DAAAAP0MAAAC/ID1DAAAAP10iBxuSIT8CQAJAID0gNl0NAEMAAAAAIUAgPSBhXkUNASA9QwAAgL+SIDaVIkAgQCBAIECUkpJDAACAP5IhQAwBCyA9IDaVIkAgQJIgQCBAlJNDAACAv5IhQAsCQAJAID8gNl0NAEMAAAAAITcgPyBhXkUNASA/QwAAgL+SIDaVIj8gPyA/ID+UkpJDAACAP5IhNwwBCyA/IDaVIj8gP5IgPyA/lJNDAACAv5IhNwsgNiA9kiI9QwAAgL+SID0gPUMAAIA/YBshPUMAAIA/QwAAgL8gBxsgQJIgN5MhPyAEQQFGDQAgO0MAAAA/QwAAAL8gO0MAAAA/XSIHG5IhQAJAAkAgOyBKXQ0AQwAAAAAhNyA7IHJeRQ0BIDtDAACAv5IgSpUiNyA3IDcgN5SSkkMAAIA/kiE3DAELIDsgSpUiNyA3kiA3IDeUk0MAAIC/kiE3CwJAAkAgQCBKXQ0AQwAAAAAhRyBAIHJeRQ0BIEBDAACAv5IgSpUiQCBAIEAgQJSSkkMAAIA/kiFHDAELIEAgSpUiQCBAkiBAIECUk0MAAIC/kiFHCyBKIDuSIkBDAACAv5IgQCBAQwAAgD9gGyE7ID9DAACAP0MAAIC/IAcbIDeSIEeTkiE/IARBAkYNACBNQwAAAD9DAAAAvyBNQwAAAD9dIgcbkiFAAkACQCBNIGBdDQBDAAAAACE3IE0gel5FDQEgTUMAAIC/kiBglSI3IDcgNyA3lJKSQwAAgD+SITcMAQsgTSBglSI3IDeSIDcgN5STQwAAgL+SITcLAkACQCBAIGBdDQBDAAAAACFHIEAgel5FDQEgQEMAAIC/kiBglSJAIEAgQCBAlJKSQwAAgD+SIUcMAQsgQCBglSJAIECSIEAgQJSTQwAAgL+SIUcLIGAgTZIiQEMAAIC/kiBAIEBDAACAP2AbIU0gP0MAAIA/QwAAgL8gBxsgN5IgR5OSIT8gBEEDRg0AIGdDAAAAP0MAAAC/IGdDAAAAP10iBxuSIUACQAJAIGcgb10NAEMAAAAAITcgZyCMAV5FDQEgZ0MAAIC/kiBvlSI3IDcgNyA3lJKSQwAAgD+SITcMAQsgZyBvlSI3IDeSIDcgN5STQwAAgL+SITcLAkACQCBAIG9dDQBDAAAAACFHIEAgjAFeRQ0BIEBDAACAv5Igb5UiQCBAIEAgQJSSkkMAAIA/kiFHDAELIEAgb5UiQCBAkiBAIECUk0MAAIC/kiFHCyBvIGeSIkBDAACAv5IgQCBAQwAAgD9gGyFnID9DAACAP0MAAIC/IAcbIDeSIEeTkiE/IARBBEYNACB4QwAAAD9DAAAAvyB4QwAAAD9dIgcbkiFAAkACQCB4IHldDQBDAAAAACE3IHggVV5FDQEgeEMAAIC/kiB5lSI3IDcgNyA3lJKSQwAAgD+SITcMAQsgeCB5lSI3IDeSIDcgN5STQwAAgL+SITcLAkACQCBAIHldDQBDAAAAACFHIEAgVV5FDQEgQEMAAIC/kiB5lSJAIEAgQCBAlJKSQwAAgD+SIUcMAQsgQCB5lSJAIECSIEAgQJSTQwAAgL+SIUcLIHkgeJIiQEMAAIC/kiBAIEBDAACAP2AbIXggP0MAAIA/QwAAgL8gBxsgN5IgR5OSIT8gBEEFRg0AIIYBQwAAAD9DAAAAvyCGAUMAAAA/XSIHG5IhQAJAAkAghgEgiQFdDQBDAAAAACE3IIYBIFxeRQ0BIIYBQwAAgL+SIIkBlSI3IDcgNyA3lJKSQwAAgD+SITcMAQsghgEgiQGVIjcgN5IgNyA3lJNDAACAv5IhNwsCQAJAIEAgiQFdDQBDAAAAACFHIEAgXF5FDQEgQEMAAIC/kiCJAZUiQCBAIEAgQJSSkkMAAIA/kiFHDAELIEAgiQGVIkAgQJIgQCBAlJNDAACAv5IhRwsgiQEghgGSIkBDAACAv5IgQCBAQwAAgD9gGyGGAQJAIGhFDQAgP0MAAIA/QwAAgL8gBxsgN5IgR5OSIT8MAQsgAiBrOALcBCACIEk4AtQEIAIgCTYCyAQgAiBBNgLYBCACIEg4AtAEIAIgPDgCzAQgAiA5OAKYBCACIIYBOALUAyACIHg4AtADIAIgZzgCzAMgAiBNOALIAyACIDs4AsQDIAIgPTgCwAMgAiA6OAK8BCACIDU4ApQEIAIgODgCuARBBkEGQZSJwIAAEIuAgIAAAAsgDEENdCAMcyIMQRF2IAxzIgxBBXQgDHMiDLNDAACAL5QiQCBAkkMAAIC/kiFHIF0gP5QhNwJAAkAgRUH/AUcNACA3IT8MAQsgZiA1lCBMIDcgOZMiTpSSIUACQCBfQwAAAABeRQ0AIHVDAACAP0MAAIC/QwAAoEBDAACgwCBfIECUIj8gP0MAAKDAXRsiPyA/QwAAoEBeGyI/ID8gP5QiPyA/ID9DAAC9Q5KUQwBah0aSlEPA9wNIkpQgPyA/ID9DAADgQZRDAOBERZKUQwCic0eSlEPA9wNIkpUiPyA/QwAAgL9dGyI/ID9DAACAP14blCFAC0MAAAAAIDkgTCA1lJIgZCBOlJIiPyA/kiA5kyI5IDmLQwjlPB5dGyE5QwAAAAAgQCBAkiA1kyI1IDWLQwjlPB5dGyE1AkACQCBFDgMCAAECCyBuIECUIT8MAQsgNyBuIECUkyA/kyE/CyBYIEeUID+SITcCQAJAIDFB/wFHDQAgNyE/DAELIGMgOJQgSyA3IDqTIkeUkiFAAkAgXkMAAAAAXkUNACB0QwAAgD9DAACAv0MAAKBAQwAAoMAgXiBAlCI/ID9DAACgwF0bIj8gP0MAAKBAXhsiPyA/ID+UIj8gPyA/QwAAvUOSlEMAWodGkpRDwPcDSJKUID8gPyA/QwAA4EGUQwDgREWSlEMAonNHkpRDwPcDSJKVIj8gP0MAAIC/XRsiPyA/QwAAgD9eG5QhQAtDAAAAACA6IEsgOJSSIGIgR5SSIj8gP5IgOpMiOiA6i0MI5TweXRshOkMAAAAAIEAgQJIgOJMiOCA4i0MI5TweXRshOAJAAkAgMQ4DAgEAAgsgNyBsIECUkyA/kyE/DAELIGwgQJQhPwsCQAJAAkACQAJAAkACQAJAIAkgQ08NACAJQQRPDQEgESAuIAlBFGxqIgcoAgBPDQILIAggRnFBAXFFDQIgQSEIDAQLIAIgazgC3AQgAiBJOALUBCACIAk2AsgEIAIgQTYC2AQgAiBIOALQBCACIDw4AswEIAIgOTgCmAQgAiCGATgC1AMgAiB4OALQAyACIGc4AswDIAIgTTgCyAMgAiA7OALEAyACID04AsADIAIgOjgCvAQgAiA1OAKUBCACIDg4ArgEIAlBBEGkisCAABCLgICAAAALIAIgBy0AECIIOgCxBSACQQE6ALAFIAlBAWohCSAHKgIMIWsgByoCCCFAIAcqAgQhSSAIDQEgSSA8kyBAlSFIQQAhRgwDCyAIQQFxDQJDAAAAACA8IGuUIjwgPItDCOU8Hl0bITxBACEIDAMLQwAAgD9DAACAvyBAlRDegICAAJMhSCBAQwAAoECU/AEhCAsgCCAIQQBHayFBIDwgSSA8kyBIlJIhPEEBIUYCQCAIQQJJDQBBASEIDAILQQAhCCACQQA6ALAFDAELIDwgSJIhPAJAAkAgSEMAAAAAYEUNACA8IElgDQELQQEhCCBIQwAAAABdRQ0BIDwgSV9FDQELQQAhCCACQQA6ALAFIEkhPAsgCkEEaiEHIAogCioCACA/IDyUkjgCACARQQFqIREgPkF8aiI+DQALIAIgazgC3AQgAiBJOALUBCACIAk2AsgEIAIgQTYC2AQgAiBIOALQBCACIDw4AswEIAIgOTgCmAQgAiCGATgC1AMgAiB4OALQAyACIGc4AswDIAIgTTgCyAMgAiA7OALEAyACID04AsADIAIgOjgCvAQgAiA1OAKUBCACIDg4ArgECyBCIAJBwANqQfgB/AoAAAsgRCAMNgKEAgJAIEQqAugBIjVDAAAAAFsNACBEKALsASEHIEQqAqgCIT0gRCoCpAIhPwJAIGkNACBELQCsAiE+IEQqAqACIUcgRCoCnAIhOCBEKgKYAiE5IEQqApQCITYgRCoCkAIhNyBEKgKMAiE7IHEhCSBwIQwgEyERA0AgESEKIDcgP5QgNiA1QwAAAAAgDCAHSRsiOiA9kyJAlJIhPAJAIDhDAAAAAF5FDQAgR0MAAIA/QwAAgL9DAACgQEMAAKDAIDggPJQiPCA8QwAAoMBdGyI8IDxDAACgQF4bIjwgPCA8lCI8IDwgPEMAAL1DkpRDAFqHRpKUQ8D3A0iSlCA8IDwgPEMAAOBBlEMA4ERFkpRDAKJzR5KUQ8D3A0iSlSI8IDxDAACAv10bIjwgPEMAAIA/XhuUITwLID0gNiA/lJIgOSBAlJIiQCBAkiA9kyI9i0MI5TweXSEEIDwgPJIgP5MiP4tDCOU8Hl0hCAJAAkACQCA+DgMCAAECCyA7IDyUIUAMAQsgOiA7IDyUkyBAkyFACyAKQQRqIRFDAAAAACA9IAQbIT1DAAAAACA/IAgbIT8gCiBAIAoqAgCSOAIAIAxBAWohDCAJQXxqIgkNAAsLIEQgPTgCqAIgRCA/OAKkAiBwIHxqIEQqAogCQ28SAzuU/AEgB2pNDQAgREEANgLoAQsCQCBELQDcAUUNAAJAIEQoAmgiCiBbTw0AIGkNASBEQYgBaiFDIIEBIApBDGxqIgwoAggiEUF/aiEKIAwoAgQhByBEKwMYIaIBIEQrAwghWSBxIQggcCEEIBMhDANAAkACQAJAAkACQAJAAkAgEUEESQ0AIFkgogFmDQBBACBZ/AMiCUF/aiI+IAogPiAKSRsgPkEASBsiMSARTw0BQQAgCSAKIAkgCkkbIAlBAEgbIkUgEU8NAkEAIAlBAWoiPiAKID4gCkkbID5BAEgbIkYgEU8NA0EAIAlBAmoiPiAKID4gCkkbID5BAEgbIj4gEU8NBCBZIAm4oSFaIAcgMUECdGoqAgAhPCAHIEVBAnRqKgIAIT0gRCBZIEQrAxCgIlk5AwggPSBatiI/QwAAAD+UIAcgRkECdGoqAgAiQCA8kyA8IDySID1DAACgwJSSIEBDAACAQJSSIAcgPkECdGoqAgAiNpMgNiA9IECTQwAAQECUkiA8kyA/lJIgP5SSlJIhPAJAIEQtAGQiCUH/AUYNACBEQwAAAAAgRCoCOCI9IEQqAlxDAACAP0MAAIC/QwAAoEBDAACgwCBEKgJYIEQqAlQgPCBEKgJQlCBEKgJMIEQqAkggRCoCNCI/IEQqAigiQCBEKgJAlCBEKgIsIjYgRCoCPJSSID0gRCoCMCI4lJKSlJSTlJQiPCA8QwAAoMBdGyI8IDxDAACgQF4bIjwgPCA8lCI8IDwgPEMAAL1DkpRDAFqHRpKUQ8D3A0iSlCA8IDwgPEMAAOBBlEMA4ERFkpRDAKJzR5KUQ8D3A0iSlSI8IDxDAACAv10bIjwgPEMAAIA/XhuUIjUgQJOUIjwgQCA8kiI6kiI8IDyLQwjlPB5dGzgCKCBEQwAAAAAgPSA6IDaTlCI8IDYgPJIiQJIiPCA8i0MI5TweXRs4AiwgREMAAAAAID0gQCA4k5QiPCA4IDySIjaSIjwgPItDCOU8Hl0bOAIwIERDAAAAACA9IDYgP5OUIjwgPyA8kiI8kiI9ID2LQwjlPB5dGzgCNAJAAkACQAJAIAkOBAMAAQIDCyBAITwMAgsgQCA2IDaSkyA8kkMAAIBAlCE8DAELIDUgOkMAAIBAlJMgQEMAAMBAlJIgNkMAAIBAlJMgPJIhPAsgPCBEKgJglCE8CyBEKAJwIgkgRCgCbE8NBQJAAkAgCUEETw0AIAQgQyAJQRRsaiI+KAIATw0BDAcLIAlBBEGkisCAABCLgICAAAALIERBAToA2AEgRCA+LQAQIjE6ANkBIEQgPioCDDgChAEgRCA+KgIEIj84AnwgRCAJQQFqNgJwID4qAgghPQJAIDENACBEID8gRCoCdJMgPZU4AngMBgsgRCA9QwAAoECU/AE2AoABIERDAACAP0MAAIC/ID2VEN6AgIAAkzgCeAwFCyBEQQA6ANwBQwAAAAAhPAwFCyAxIBFBpInAgAAQi4CAgAAACyBFIBFBpInAgAAQi4CAgAAACyBGIBFBpInAgAAQi4CAgAAACyA+IBFBpInAgAAQi4CAgAAACwJAAkACQAJAIEQtANgBIglBAUcNACBELQDZAUEBcQ0BCyAJDQEgREMAAAAAIEQqAnQgRCoChAGUIj0gPYtDCOU8Hl0bIj04AnQMAgsgRCBEKgJ0Ij0gRCoCfCA9kyBEKgJ4lJIiPTgCdCBEIEQoAoABIgkgCUEAR2s2AoABIAlBAk8NASBEQQA6ANgBDAELIEQgRCoCeCJAIEQqAnSSIj04AnQgRCoCfCE/AkACQCBAQwAAAABgRQ0AID0gP2ANAQsgQEMAAAAAXUUNASA9ID9fRQ0BCyBEQQA6ANgBIEQgPzgCdCA/IT0LIDwgPZQhPAsgDCA8IAwqAgCSOAIAIARBAWohBCAMQQRqIQwgCEF8aiIIRQ0CDAALCyAKIFtBtInAgAAQi4CAgAAACyBEKgL8ASE8AkAgaQ0AIEQqAoACIUAgRCoCBCE2IEQqAgAhOCBEKgL4ASE6IEQqAvQBITUgRCoC8AEhPyB8IREgEyEKA0AgCiBqaiIJQYB4aiEMIAlBgHBqIQkgCioCACE9AkAgP0MAAAAAXkUNACA1QwAAgD9DAACAv0MAAKBAQwAAoMAgPyA9lCI9ID1DAACgwF0bIj0gPUMAAKBAXhsiPSA9ID2UIj0gPSA9QwAAvUOSlEMAWodGkpRDwPcDSJKUID0gPSA9QwAA4EGUQwDgREWSlEMAonNHkpRDwPcDSJKVIj0gPUMAAIC/XRsiPSA9QwAAgD9eG5QhPQsgCSAJKgIAIDggOiA8lCA9lCI9lJI4AgAgDCA2ID2UIAwqAgCSOAIAIApBBGohCiBAIDyUITwgEUF/aiIRDQALCyBEIDw4AvwBIEQgcCB8ajYC4AECQAJAIDxDrMUnN10NAEEBIQoCQCBELQDIBUEBRw0AQQAhCiBEKAK0CCBEKAKwCEkNACBELQCcCUEBcQ0AIEQqArgIi0OsxSc3XSEKCwJAAkAgRC0A6ANBAUcNAEEAIQkgRCgC/AIgRCgC+AJJDQEgRC0A5ANBAXENASBEKgKAA4tDrMUnN11FDQELAkAgRC0ApAVBAUcNAEEAIQkgRCgCuAQgRCgCtARJDQEgRC0AoAVBAXENASBEKgK8BItDrMUnN11FDQELQQEhCQtBASEMAkAgRC0ArAhFDQBBACEMIEQoAsAHIEQoArwHSQ0AIEQtAKgIQQFxDQAgRCoCxAeLQ6zFJzddIQwLAkACQCBELQDcAQ0AIAogCXEgDHENAQwDCyBEKAJwIEQoAmxJDQIgRC0A2AFBAXENAiAMIAkgCiBEKgJ0i0OsxSc3XXFxcUEBRw0CCyBEKgLoAUMAAAAAXA0BCyBEQQA6AKAJC0EBIQwgd0UNAQtBACEKDAELQQEhCgwACwsgMyAMciEzIDQhMSA0IBJJDQALAkACQCAzQQFxRQ0AIABBADYCsCMMAQsgAEF/IAAoArAjIgogEmoiDCAMIApJGyIKNgKwIyAKQT9JDQACQCASQQJ0IgpFIgwNACAAQeAAakEAIAr8CwALIAwNASAAQeAEakEAIAr8CwAMAQsgAEGACWohDCAAQeAIaiEHIABB4ABqIQkgEkECdCIIIREDQCAVQQRqKgIAIT0gFSoCACE8IAAgACgCgAoiCkF/aiIEQQ8gChsiCjYCgAogCkEfSw0HIAwgCkECdGogPDgCACAAKAKACkEQaiIKQSBPDQogDCAKQQJ0aiA8OAIAIAAoAoQKIgpBB0sNAiAHIApBAnRqIgoqAgAhPCAKID04AgAgACAAKAKECkEBakEHcTYChAogACgCgAoiCkERTw0DIAkgPEMAAAA/lCAMIApBAnRqIgoqAgAgCioCPJJD2fCluJRDAAAAAJIgCioCBCAKKgI4kkMDtFg6lJIgCioCCCAKKgI0kkNXdlK7lJIgCioCDCAKKgIwkkPGRRE8lJIgCioCECAKKgIskkPO56a8lJIgCioCFCAKKgIokkM9Ey89lJIgCioCGCAKKgIkkkNYuLy9lJIgCioCHCAKKgIgkkPvcqA+lJKSOAIAIBVBCGohFSAJQQRqIQkgEUF8aiIRDQALIABBqApqIQwgAEGICmohESAAQeAEaiEJA0AgFEEEaioCACE9IBQqAgAhPCAAIAAoAqgLIgpBf2oiBEEPIAobIgo2AqgLIApBH0sNByAMIApBAnRqIDw4AgAgACgCqAtBEGoiCkEfSw0KIAwgCkECdGogPDgCACAAKAKsCyIKQQdLDQIgESAKQQJ0aiIKKgIAITwgCiA9OAIAIAAgACgCrAtBAWpBB3E2AqwLIAAoAqgLIgpBEEsNAyAJIDxDAAAAP5QgDCAKQQJ0aiIKKgIAIAoqAjySQ9nwpbiUQwAAAACSIAoqAgQgCioCOJJDA7RYOpSSIAoqAgggCioCNJJDV3ZSu5SSIAoqAgwgCioCMJJDxkURPJSSIAoqAhAgCioCLJJDzuemvJSSIAoqAhQgCioCKJJDPRMvPZSSIAoqAhggCioCJJJDWLi8vZSSIAoqAhwgCioCIJJD73KgPpSSkjgCACAUQQhqIRQgCUEEaiEJIAhBfGoiCA0ACwsCQCAAKAIwIgpFDQAgACgCNCIJQXxqKAIAIgxBeHEiEUEEQQggDEEDcSIMGyAKQSxsIgpqSQ0DAkAgDEUNACARIApBJ2pLDQULIAkQjYCAgAALQQAhDCAAQQA2AjggACAFNgI0IAAgBjYCMCAAQeAEaiEJIABB4ABqIREDQCAAIAxqIgpB4ABqKAIAQf////8HcUGAgID8B04NByAKQeQAaigCAEH/////B3FB////+wdKDQcgCkHoAGooAgBB/////wdxQf////sHSg0HIApB7ABqKAIAQf////8HcUH////7B0oNByAMQRBqIgxBgARHDQALQQAhDAwECyAKQQhBhInAgAAQi4CAgAAACyAKIApBEGpBIEH0iMCAABCMgICAAAALQeCiwIAAQS5BkKPAgAAQjoCAgAAAC0Ggo8CAAEEuQdCjwIAAEI6AgIAAAAsDQCAAIAxqIgpB4ARqKAIAQf////8HcUH////7B0oNAiAKQeQEaigCAEH/////B3FB////+wdKDQIgCkHoBGooAgBB/////wdxQf////sHSg0CIApB7ARqKAIAQf////8HcUH////7B0oNAiAMQRBqIgxBgARHDQAMAwsLIARBIEHEiMCAABCLgICAAAALIAAQiYCAgAAgAUUNAAJAIBJBAnQiCkUiDA0AIBFBACAK/AsACyAMDQAgCUEAIAr8CwALIAJB4ApqJICAgIAADwsgCkEgQdSIwIAAEIuAgIAAAAtfAgF/AX4jgICAgABBIGsiAySAgICAACADIAE2AgwgAyAANgIIIANBgoCAgACtQiCGIgQgA0EIaq2ENwMYIAMgBCADQQxqrYQ3AxBBqIDAgAAgA0EQaiACEIKAgIAAAAvNAgIBfwF+I4CAgIAAQSBrIgQkgICAgAACQAJAAkAgACACSw0AIAEgAksNAUGCgICAAK1CIIYhBSAAIAFNDQIgBCAANgIIIAQgATYCDCAEIAUgBEEMaq2ENwMYIAQgBSAEQQhqrYQ3AxBBgIDAgAAgBEEQaiADEIKAgIAAAAsgBCAANgIIIAQgAjYCDCAEQYKAgIAArUIghiIFIARBDGqthDcDGCAEIAUgBEEIaq2ENwMQQd+AwIAAIARBEGogAxCCgICAAAALIAQgATYCCCAEIAI2AgwgBEGCgICAAK1CIIYiBSAEQQxqrYQ3AxggBCAFIARBCGqthDcDEEGYgcCAACAEQRBqIAMQgoCAgAAACyAEIAE2AgggBCACNgIMIAQgBSAEQQxqrYQ3AxggBCAFIARBCGqthDcDEEGYgcCAACAEQRBqIAMQgoCAgAAAC6kJAQV/IABBeGoiASAAQXxqKAIAIgJBeHEiAGohAwJAAkAgAkEBcQ0AIAJBAnFFDQEgASgCACICIABqIQACQCABIAJrIgFBACgC1KzAgABHDQAgAygCBEEDcUEDRw0BQQAgADYCzKzAgAAgAyADKAIEQX5xNgIEIAEgAEEBcjYCBCADIAA2AgAPCyABIAIQpYCAgAALAkACQAJAAkACQAJAAkACQCADKAIEIgJBAnENACADQQAoAtiswIAARg0CIANBACgC1KzAgABGDQMgAyACQXhxIgIQpYCAgAAgASACIABqIgBBAXI2AgQgASAAaiAANgIAIAFBACgC1KzAgABHDQFBACAANgLMrMCAAA8LIAMgAkF+cTYCBCABIABBAXI2AgQgASAAaiAANgIACyAAQYACSQ0CQR8hAyAAQYCAgAhJDQMMBQtBACABNgLYrMCAAEEAQQAoAtCswIAAIABqIgA2AtCswIAAIAEgAEEBcjYCBAJAIAFBACgC1KzAgABHDQBBAEEANgLMrMCAAEEAQQA2AtSswIAACyAAQQAoAuSswIAAIgJNDQVBACgC2KzAgAAiAEUNBUEAKALQrMCAACIEQSlJDQNBrKrAgAAhAQNAAkAgASgCACIDIABLDQAgACADIAEoAgRqSQ0FCyABKAIIIQEMAAsLQQAgATYC1KzAgABBAEEAKALMrMCAACAAaiIANgLMrMCAACABIABBAXI2AgQgASAAaiAANgIADwsCQAJAQQAoAsSswIAAIgNBASAAQQN2dCICcQ0AQQAgAyACcjYCxKzAgAAgAEH4AXFBvKrAgABqIgAhAwwBCyAAQfgBcSIAQbyqwIAAaiEDIABBxKrAgABqKAIAIQALIAMgATYCCCAAIAE2AgwgASADNgIMIAEgADYCCA8LIABBJiAAQQh2ZyIDa3ZBAXEgA0EBdHJBPnMhAwwBCwJAAkBBACgCtKrAgAAiAA0AQf8fIQEMAQtBACEBA0AgAUEBaiEBIAAoAggiAA0ACyABQf8fIAFB/x9LGyEBC0EAIAE2AuyswIAAIAQgAk0NAUEAQX82AuSswIAADAELIAFCADcCECABIAM2AhwgA0ECdEGsqcCAAGohAgJAAkBBACgCyKzAgABBASADdCIEcQ0AIAIgATYCACABIAI2AhggASABNgIMIAEgATYCCEEAQQAoAsiswIAAIARyNgLIrMCAAAwBCwJAAkACQCACKAIAIgQoAgRBeHEgAEcNACAEIQMMAQsgAEEAQRkgA0EBdmsgA0EfRht0IQIDQCAEIAJBHXZBBHFqIgUoAhAiA0UNAiACQQF0IQIgAyEEIAMoAgRBeHEgAEcNAAsLIAMoAggiACABNgIMIAMgATYCCCABQQA2AhggASADNgIMIAEgADYCCAwBCyAFQRBqIAE2AgAgASAENgIYIAEgATYCDCABIAE2AggLQQBBACgC7KzAgABBf2oiATYC7KzAgAAgAQ0AAkACQEEAKAK0qsCAACIADQBB/x8hAQwBC0EAIQEDQCABQQFqIQEgACgCCCIADQALIAFB/x8gAUH/H0sbIQELQQAgATYC7KzAgAAPCwsVACAAIAFBAXRBAXIgAhCCgICAAAALOgEBfwJAIABFDQAgASAAKAIgIgNPDQAgAiADTw0AIAAoAhwgAUECdGoiACAAKAIAQQEgAnRyNgIACwurBwEHfwJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQCAARQ0AAkAgACgCACIBRQ0AIAAoAgQiAkF8aigCACIDQXhxIgRBBEEIIANBA3EiAxsgAUHQEmwiAXJJDQICQCADRQ0AIAQgAUEnaksNBAsgAhCNgICAAAsCQCAAKAIMIgFFDQAgACgCECICQXxqKAIAIgNBeHEiBEEEQQggA0EDcSIDGyABQQJ0IgFqSQ0EAkAgA0UNACAEIAFBJ2pLDQYLIAIQjYCAgAALAkAgACgCGCIBRQ0AIAAoAhwiAkF8aigCACIDQXhxIgRBBEEIIANBA3EiAxsgAUECdCIBakkNBgJAIANFDQAgBCABQSdqSw0ICyACEI2AgIAACyAAKAIoIQUCQCAAKAIsIgNFDQAgBSEBA0ACQCABKAIAIgJFDQAgAUEEaigCACIGQXxqKAIAIgRBeHEiB0EEQQggBEEDcSIEGyACQQJ0IgJqSQ0KAkAgBEUNACAHIAJBJ2pLDQwLIAYQjYCAgAALIAFBDGohASADQX9qIgMNAAsLAkAgACgCJCIBRQ0AIAVBfGooAgAiA0F4cSICQQRBCCADQQNxIgMbIAFBDGwiAWpJDQoCQCADRQ0AIAIgAUEnaksNDAsgBRCNgICAAAsCQCAAKAIwIgFFDQAgACgCNCICQXxqKAIAIgNBeHEiBEEEQQggA0EDcSIDGyABQSxsIgFqSQ0MAkAgA0UNACAEIAFBJ2pLDQ4LIAIQjYCAgAALIABBfGooAgAiAUF4cSIDQcAjQcQjIAFBA3EiARtJDQ0CQCABRQ0AIANB5CNPDQ8LIAAQjYCAgAALDwtB4KLAgABBLkGQo8CAABCOgICAAAALQaCjwIAAQS5B0KPAgAAQjoCAgAAAC0HgosCAAEEuQZCjwIAAEI6AgIAAAAtBoKPAgABBLkHQo8CAABCOgICAAAALQeCiwIAAQS5BkKPAgAAQjoCAgAAAC0Ggo8CAAEEuQdCjwIAAEI6AgIAAAAtB4KLAgABBLkGQo8CAABCOgICAAAALQaCjwIAAQS5B0KPAgAAQjoCAgAAAC0HgosCAAEEuQZCjwIAAEI6AgIAAAAtBoKPAgABBLkHQo8CAABCOgICAAAALQeCiwIAAQS5BkKPAgAAQjoCAgAAAC0Ggo8CAAEEuQdCjwIAAEI6AgIAAAAtB4KLAgABBLkGQo8CAABCOgICAAAALQaCjwIAAQS5B0KPAgAAQjoCAgAAAC8ECAQV/QQAhAwJAAkACQAJAAkAgAEUNACAALQC4I0EDSQ0AIAEgACgCLE8NACACQf////8DSw0BIAJBAnQiBEH9////B08NAQJAAkAgBA0AQQQhA0EAIQQMAQsgBBCIgICAACIDRQ0DAkAgA0F8ai0AAEEDcUUNACAERQ0AIANBACAE/AsACyACIQQLAkAgACgCKCABQQxsaiIAKAIAIgFFDQAgACgCBCIFQXxqKAIAIgZBeHEiB0EEQQggBkEDcSIGGyABQQJ0IgFqSQ0EAkAgBkUNACAHIAFBJ2pLDQYLIAUQjYCAgAALIAAgAjYCCCAAIAM2AgQgACAENgIACyADDwsQkoCAgAAAC0EEIAQQhoCAgAAAC0HgosCAAEEuQZCjwIAAEI6AgIAAAAtBoKPAgABBLkHQo8CAABCOgICAAAALFwBBqYvAgABBI0G8i8CAABCCgICAAAALtTICCn8EfiOAgICAAEGgIGsiAiSAgICAAEEAIQMCQAJAAkACQAJAAkACQCABQQRLDQAgAkIANwPACCACQgA3A7gIIAJCADcDsAggAkIANwOoCCACQcgIakEAQYAI/AsAIAJBADsBKCACQgA3AyAgAkIANwMYIAJCADcDECACQgA3AwggAkIANwIsIAJCADcCNCACQgA3AjwgAkIANwJEIAJBADsBTCACQgA3A1AgAkIANwNYIAJCADcDYCACQgA3A2ggAkEAOwFwIAJCADcCdCACQgA3AnwgAkIANwKEASACQgA3AowBIAJBADsBlAEgAkEAOgCQGiACQgA3A4gaIAJCADcDgBogAkIANwKUGiACQgA3ApwaIAJBADoApBogAkIANwOoGiACQgA3A7AaIAJBADoAuBogAkIANwK8GiACQgA3AsQaIAJBADoAzBogAkIANwPQGiACQgA3A9gaIAJBADoA4BogAkIANwLkGiACQgA3AuwaIAJBADoA9BogAkEAOgCIGyACQgA3A4AbIAJCADcD+BogAkEAOgCcGyACQgA3ApQbIAJCADcCjBsgAkEAOgCwGyACQgA3A6gbIAJCADcDoBsgAkEAOgDEGyACQgA3ArwbIAJCADcCtBsgAkEAOgDYGyACQgA3A9AbIAJCADcDyBsgAkIANwLcGyACQgA3AuQbIAJBADoA7BsgAkEAOgCAHCACQgA3A/gbIAJCADcD8BsgAkEAOgCUHCACQgA3AowcIAJCADcChBwgAkEAOgCoHCACQgA3A6AcIAJCADcDmBwgAkEAOgC8HCACQgA3ArQcIAJCADcCrBwgAkEAOgDQHCACQgA3A8gcIAJCADcDwBwgAkEAOgDkHCACQgA3AtwcIAJCADcC1BwgAkEAOgD4HCACQgA3A/AcIAJCADcD6BwgAkEAOgCMHSACQgA3AoQdIAJCADcC/BwgAkGqE2pBA2ogAkEIakGQAfwKAAAgAkEANgCHEyACQgA3AP8SIAJCADcA9xIgAkIANwDvEiACQgA3AKIVIAJCADcAqhUgAkIANwCyFSACQgA3ALoVIAJBADoAwhUgAkIANwCDFSACQgA3AIsVIAJCADcAkxUgAkEANgCbFSACQgA3AN8UIAJCADcA5xQgAkIANwDvFCACQgA3APcUIAJBADoA/xQgAkEANgDYFCACQgA3ANAUIAJCADcAyBQgAkIANwDAFCACQgA3A9gRIAJCADcD4BEgAkIANwPoESACQgA3A/ARIAJCADcD+BEgAkIANwOAEiACQgA3AI4TIAJCADcAlhMgAkIANwCeEyACQQA2AKYTIAJCADcD0BIgAkIANwPYEiACQgA3A+ASIAJCADcAxhUgAkIANwDOFSACQgA3ANYVIAJCADcA3hUgAkGIEmpBAEHFAPwLACACQQA7ASggAkIANwMgIAJCADcDGCACQgA3AxAgAkIANwMIIAJCADcCLCACQgA3AjQgAkIANwI8IAJCADcCRCACQQA7AUwgAkIANwNQIAJCADcDWCACQgA3A2AgAkIANwNoIAJBADsBcCACQgA3AnQgAkIANwJ8IAJCADcChAEgAkIANwKMASACQQA7AZQBIAJBADoAoB0gAkIANwOYHSACQgA3A5AdIAJCADcCpB0gAkIANwKsHSACQQA6ALQdIAJCADcDuB0gAkIANwPAHSACQQA6AMgdIAJCADcCzB0gAkIANwLUHSACQQA6ANwdIAJCADcD4B0gAkIANwPoHSACQQA6APAdIAJCADcC9B0gAkIANwL8HSACQQA6AIQeIAJBADoAmB4gAkIANwOQHiACQgA3A4geIAJBADoArB4gAkIANwKkHiACQgA3ApweIAJBADoAwB4gAkIANwO4HiACQgA3A7AeIAJBADoA1B4gAkIANwLMHiACQgA3AsQeIAJBADoA6B4gAkIANwPgHiACQgA3A9geIAJCADcC7B4gAkIANwL0HiACQQA6APweIAJBADoAkB8gAkIANwOIHyACQgA3A4AfIAJBADoApB8gAkIANwKcHyACQgA3ApQfIAJBADoAuB8gAkIANwOwHyACQgA3A6gfIAJBADoAzB8gAkIANwLEHyACQgA3ArwfIAJBADoA4B8gAkIANwPYHyACQgA3A9AfIAJBADoA9B8gAkIANwLsHyACQgA3AuQfIAJBADoAiCAgAkIANwOAICACQgA3A/gfIAJBADoAnCAgAkIANwKUICACQgA3AowgIAJBpBZqQQNqIAJBCGpBkAH8CgAAIAJBADYAgRYgAkIANwD5FSACQgA3APEVIAJCADcA6RUgAkIANwCcGCACQgA3AKQYIAJCADcArBggAkIANwC0GCACQQA6ALwYIAJCADcA/RcgAkIANwCFGCACQgA3AI0YIAJBADYAlRggAkIANwDZFyACQgA3AOEXIAJCADcA6RcgAkIANwDxFyACQQA6APkXIAJBADYA0hcgAkIANwDKFyACQgA3AMIXIAJCADcAuhcgAkIANwPIECACQgA3A9AQIAJCADcD2BAgAkIANwPgECACQgA3A+gQIAJCADcD8BAgAkIANwCIFiACQgA3AJAWIAJCADcAmBYgAkEANgCgFiACQgA3A8ARIAJCADcDyBEgAkIANwPQESACQgA3AMAYIAJCADcAyBggAkIANwDQGCACQgA3ANgYIAJB+BBqQQBBxQD8CwAgAS0ApIvAgAAiBEECdCgCjKXAgAAiBUHQEmwiAxCIgICAACIGRQ0BQQAhAUEBIQcDQCAGIAFqIgNCADcDACADQQhqIAIpA9ASNwMAIANBEGogAikD2BI3AwAgA0EYaiACKQPgEjcDACADQeQAakH/AToAACADQeUAaiACKQDDFTcAACADQe0AaiACKQDLFTcAACADQfUAaiACKQDTFTcAACADQf0AaiACKQDbFTcAACADQYQBaiACKADiFTYAACADQYgBaiACQcAcakHQAPwKAAAgA0HgAWpCADcDACADQdwBakEAOgAAIANB2AFqQQA7AQAgA0HoAWogAkGIEmpBxQD8CgAAIANB0AJqQf8BOgAAIANB0QJqIAIpAJ8VNwAAIANB2QJqIAIpAKcVNwAAIANB4QJqIAIpAK8VNwAAIANB6QJqIAIpALcVNwAAIANB8QJqIAIoAL8VNgAAIANB9QJqIAIpAIAVNwAAIANB/QJqIAIpAIgVNwAAIANBhQNqIAIpAJAVNwAAIANBjANqIAIpAJcVNwAAIANBlANqIAJB0BpqQdAA/AoAACADQYwEakH/AToAACADQegDakEAOgAAIANB5ANqQQA7AQAgA0GNBGogAikA3BQ3AAAgA0GVBGogAikA5BQ3AAAgA0GdBGogAikA7BQ3AAAgA0GlBGogAikA9BQ3AAAgA0GtBGogAigA/BQ2AAAgA0GxBGogAikAvRQ3AAAgA0G5BGogAikAxRQ3AAAgA0HBBGogAikAzRQ3AAAgA0HIBGogAikA1BQ3AAAgA0HQBGogAkGgG2pB0AD8CgAAIANBpAVqQQA6AAAgA0GgBWpBADsBACADQaUFaiACQaoTakGTAfwKAAAgA0G4B2pB/wE6AAAgA0GUB2pB/wE6AAAgA0HsBmpCADcCACADQegGakEANgIAIANB4AZqIAIpA4ASNwMAIANB2AZqIAIpA/gRNwMAIANB0AZqIAIpA/ARNwMAIANByAZqIAIpA+gRNwMAIANBwAZqIAIpA+ARNwMAIANBuAZqIAIpA9gRNwMAIANBuQdqIAIpAIsTNwAAIANBwQdqIAIpAJMTNwAAIANByQdqIAIpAJsTNwAAIANB0AdqIAIpAKITNwAAIANB2AdqIAJB8BtqQdAA/AoAACADQawIakEAOgAAIANBqAhqQQA7AQAgA0GtCGogAikA7BI3AAAgA0G1CGogAikA9BI3AAAgA0G9CGogAikA/BI3AAAgA0HECGogAikAgxM3AAAgA0HMCGogAkGAGmpB0AD8CgAAIANBqAlqQgA3AwAgA0GgCWpBADoAACADQZwJakEAOwEAIANBjApqQf8BOgAAIANBsAlqIAIpA8ARNwMAIANBuAlqIAIpA8gRNwMAIANBwAlqIAIpA9ARNwMAIANBjQpqIAIpAL0YNwAAIANBlQpqIAIpAMUYNwAAIANBnQpqIAIpAM0YNwAAIANBpQpqIAIpANUYNwAAIANBrApqIAIoANwYNgAAIANBsApqIAJB0B9qQdAA/AoAACADQYgLakIANwMAIANBhAtqQQA6AAAgA0GAC2pBADsBACADQZALaiACQfgQakHFAPwKAAAgA0H4C2pB/wE6AAAgA0H5C2ogAikAmRg3AAAgA0GBDGogAikAoRg3AAAgA0GJDGogAikAqRg3AAAgA0GRDGogAikAsRg3AAAgA0GZDGogAigAuRg2AAAgA0GdDGogAikA+hc3AAAgA0GlDGogAikAghg3AAAgA0GtDGogAikAihg3AAAgA0G0DGogAikAkRg3AAAgA0G8DGogAkHgHWpB0AD8CgAAIANBtA1qQf8BOgAAIANBkA1qQQA6AAAgA0GMDWpBADsBACADQbUNaiACKQDWFzcAACADQb0NaiACKQDeFzcAACADQcUNaiACKQDmFzcAACADQc0NaiACKQDuFzcAACADQdUNaiACKAD2FzYAACADQdkNaiACKQC3FzcAACADQeENaiACKQC/FzcAACADQekNaiACKQDHFzcAACADQfANaiACKQDOFzcAACADQfgNaiACQbAeakHQAPwKAAAgA0HMDmpBADoAACADQcgOakEAOwEAIANBzQ5qIAJBpBZqQZMB/AoAACADQeAQakH/AToAACADQbwQakH/AToAACADQZQQakIANwIAIANBkBBqQQA2AgAgA0GIEGogAikD8BA3AwAgA0GAEGogAikD6BA3AwAgA0H4D2ogAikD4BA3AwAgA0HwD2ogAikD2BA3AwAgA0HoD2ogAikD0BA3AwAgA0HgD2ogAikDyBA3AwAgA0HhEGogAikAhRY3AAAgA0HpEGogAikAjRY3AAAgA0HxEGogAikAlRY3AAAgA0H4EGogAikAnBY3AAAgA0GAEWogAkGAH2pB0AD8CgAAIANB1BFqQQA6AAAgA0HQEWpBADsBACADQdURaiACKQDmFTcAACADQd0RaiACKQDuFTcAACADQeURaiACKQD2FTcAACADQewRaiACKQD9FTcAACADQfQRaiACQZAdakHQAPwKAAAgA0HIEmpBADoAACADQcQSakEAOwEAIAFB0BJqIQEgBSAHQQFqIgdHDQALIAYgAWoiAUGwbWoiA0EANgLUEiABQQA2AgAgAyACKQPQEjcD2BIgAyACKQPYEjcD4BIgAyACKQPgEjcD6BIgA0H/AToAtBMgAyACKQDDFTcAtRMgAyACKQDLFTcAvRMgAyACKQDTFTcAxRMgAyACKQDbFTcAzRMgAyACKADiFTYA1BMgA0HYE2ogAkHAHGpB0AD8CgAAIANCADcDsBQgA0EAOgCsFCADQQA7AagUIANBuBRqIAJBiBJqQcUA/AoAACADQf8BOgCgFSADIAIpAJ8VNwChFSADIAIpAKcVNwCpFSADIAIpAK8VNwCxFSADIAIpALcVNwC5FSADIAIoAL8VNgDBFSADIAIpAIAVNwDFFSADIAIpAIgVNwDNFSADIAIpAJAVNwDVFSADIAIpAJcVNwDcFSADQeQVaiACQdAaakHQAPwKAAAgA0H/AToA3BYgA0EAOgC4FiADQQA7AbQWIAMgAikA3BQ3AN0WIAMgAikA5BQ3AOUWIAMgAikA7BQ3AO0WIAMgAikA9BQ3APUWIAMgAigA/BQ2AP0WIAMgAikAvRQ3AIEXIAMgAikAxRQ3AIkXIAMgAikAzRQ3AJEXIAMgAikA1BQ3AJgXIANBoBdqIAJBoBtqQdAA/AoAACADQQA6APQXIANBADsB8BcgA0H1F2ogAkGqE2pBkwH8CgAAIANB/wE6AIgaIANB/wE6AOQZIANCADcCvBkgA0EANgK4GSADIAIpA4ASNwOwGSADIAIpA/gRNwOoGSADIAIpA/ARNwOgGSADIAIpA+gRNwOYGSADIAIpA+ARNwOQGSADIAIpA9gRNwOIGSADIAIpAIsTNwCJGiADIAIpAJMTNwCRGiADIAIpAJsTNwCZGiADIAIpAKITNwCgGiADQagaaiACQfAbakHQAPwKAAAgA0EAOgD8GiADQQA7AfgaIAMgAikA7BI3AP0aIAMgAikA9BI3AIUbIAMgAikA/BI3AI0bIAMgAikAgxM3AJQbIANBnBtqIAJBgBpqQdAA/AoAACADQgA3A/gbIANBADoA8BsgA0EAOwHsGyADQf8BOgDcHCADIAIpA8ARNwOAHCADIAIpA8gRNwOIHCADIAIpA9ARNwOQHCADIAIpAL0YNwDdHCADIAIpAMUYNwDlHCADIAIpAM0YNwDtHCADIAIpANUYNwD1HCADIAIoANwYNgD8HCADQYAdaiACQdAfakHQAPwKAAAgA0IANwPYHSADQQA6ANQdIANBADsB0B0gA0HgHWogAkH4EGpBxQD8CgAAIANB/wE6AMgeIAMgAikAmRg3AMkeIAMgAikAoRg3ANEeIAMgAikAqRg3ANkeIAMgAikAsRg3AOEeIAMgAigAuRg2AOkeIAMgAikA+hc3AO0eIAMgAikAghg3APUeIAMgAikAihg3AP0eIAMgAikAkRg3AIQfIANBjB9qIAJB4B1qQdAA/AoAACADQf8BOgCEICADQQA6AOAfIANBADsB3B8gAyACKQDWFzcAhSAgAyACKQDeFzcAjSAgAyACKQDmFzcAlSAgAyACKQDuFzcAnSAgAyACKAD2FzYApSAgAyACKQC3FzcAqSAgAyACKQC/FzcAsSAgAyACKQDHFzcAuSAgAyACKQDOFzcAwCAgA0HIIGogAkGwHmpB0AD8CgAAIANBADoAnCEgA0EAOwGYISADQZ0haiACQaQWakGTAfwKAAAgA0H/AToAsCMgA0H/AToAjCMgA0IANwLkIiADQQA2AuAiIAMgAikD8BA3A9giIAMgAikD6BA3A9AiIAMgAikD4BA3A8giIAMgAikD2BA3A8AiIAMgAikD0BA3A7giIAMgAikDyBA3A7AiIAMgAikAhRY3ALEjIAMgAikAjRY3ALkjIAMgAikAlRY3AMEjIAMgAikAnBY3AMgjIANB0CNqIAJBgB9qQdAA/AoAACADQQA6AKQkIANBADsBoCQgAyACKQDmFTcApSQgAyACKQDuFTcArSQgAyACKQD2FTcAtSQgAyACKQD9FTcAvCQgA0HEJGogAkGQHWpB0AD8CgAAIANBADoAmCUgA0EAOwGUJSAFQQJ0IgMQiICAgAAiCEUNAgJAIAhBfGotAABBA3FFDQAgA0UNACAIQQAgA/wLAAsgAxCIgICAACIJRQ0DAkAgCUF8ai0AAEEDcUUNACADRQ0AIAlBACAD/AsACyAFQQxsIgMQiICAgAAiCkUNBCAFQX9qIgtBA3EhASAKIQMCQAJAIAVBfmpBA0kNACAKQVBqIQcgC0F8cSELA0AgByIDQdgAakIENwIAIANB0ABqQgA3AgAgA0HIAGpCgICAgMAANwIAIANBwABqQgQ3AgAgA0E4akIANwIAIANBMGoiB0KAgICAwAA3AgAgC0F8aiILDQALIANB4ABqIQMgAQ0AIAdBJGohAQwBCwNAIANCgICAgMAANwIAIANBCGpBADYCACADQQxqIQMgAUF/aiIBDQALIANBdGohAQsgA0EANgIAIAFCBDcCEEGAFhCIgICAACIBRQ0FIAJBgBlqQQBBgAH8CwAgAiACKQPACCIMNwP4GCACIAIpA7gIIg03A/AYIAIgAikDsAgiDjcD6BggAiACKQOoCCIPNwPgGCACIA83A4gIIAIgDjcDkAggAiANNwOYCCACIAw3A6AIIAJBCGogAkHICGpBgAj8CgAAQbwjEIiAgIAAIgNFDQYgA0EANgI4IAMgATYCNCADQcAANgIwIAMgBTYCLCADIAo2AiggAyAFNgIkIAMgBTYCICADIAk2AhwgAyAFNgIYIAMgBTYCFCADIAg2AhAgAyAFNgIMIAMgBTYCCCADIAY2AgQgAyAFNgIAIAMgAikDiAg3AkAgAyACKQOQCDcCSCADIAIpA5gINwJQIAMgAikDoAg3AlggAyAAQwCAO0cgACAAvCIBQQBIG0MAgDtHIAFB/////wdxQYCAgHxqQYCAgPgHSRsgAUF/akH///8DSRs4AjwgA0HgAGogAkEIakGACPwKAAAgA0HgCGogAkHgGGpBoAH8CgAAIANCADcCgAogA0GICmogAkHgGGpBoAH8CgAAIANBqAtqQQBBiBj8CwAgAyAEOgC4IyADIARBufPd8XlsQZHpl6oCczYCtCMgA0F/NgKwIwsgAkGgIGokgICAgAAgAw8LQQggAxCGgICAAAALQQQgAxCGgICAAAALQQQgAxCGgICAAAALQQQgAxCGgICAAAALQQRBgBYQhoCAgAAAC0EEQbwjEJSAgIAAAAsNACABIAAQp4CAgAAACxYAIAAgAUEAR0EJdGpB4ABqQQAgABsLDQAgAEHAAGpBACAAGwsUAAJAIABFDQAgACABEIqAgIAACwsSAAJAIABFDQAgABCJgICAAAsL8QEBAn8jgICAgABBIGsiBCSAgICAAAJAIABFDQAgASAAKAIITw0AIAO8Qf////8HcUH////7B0oNACAAKAI4IgVBP0sNACAEIAApAlg3AxggBCAAKQJQNwMQIAQgACkCSDcDCCAEIAApAkA3AwAgAkH/ACACQf8ASRshAgJAIAUgACgCMEcNACAAQTBqEISAgIAACyAAIAVBAWo2AjggACgCNCAFQSxsaiIAIAQpAwA3AgAgACAEKQMINwIIIAAgBCkDEDcCECAAIAQpAxg3AhggACADOAIoIAAgAjYCJCAAIAE2AiALIARBIGokgICAgAALDQAgAEGABGpBACAAGwtzAQJ/AkACQAJAIABFDQAgAEF8aigCACIBQXhxQaQPQagPIAFBA3EiAhtJDQECQCACRQ0AIAFByA9PDQMLIAAQjYCAgAALDwtB4KLAgABBLkGQo8CAABCOgICAAAALQaCjwIAAQS5B0KPAgAAQjoCAgAAACwQAIAAL+QQDAn8DfQF+I4CAgIAAQcAPayIBJICAgIAAAkACQCAAQwCAO0cgACAAvCICQQBIG0MAgDtHIAJB/////wdxQYCAgHxqQYCAgPgHSRsgAkF/akH///8DSRsiA0NmZuY+lCIAQwAAoEFgRQ0AIABDAAB6RCAAQwAAekRdG0PbD0lAlCADIAOSIgSVENuAgIAAIQUgAUIANwLwDiABQgA3AugOIAFBADYCsA0gAUEIakEAQYAM/AsAIAFDAACAP0MAAIC/IANDCtcjPJSVEN6AgIAAkyIDOALYDSABQs2Zs/LTmbOmPjcC0A0gASADOALMDSABQgA3AsQNIAEgAzgCwA0gAULVmPSG1IrD7sAANwK4DSABIAA4ArQNIAFB3A1qQQBBhAH8CwAgAUEIakGADGpBAEGoAfwLACABQQA6AKQPIAFBgICA/AM2AqAPIAFCgICA/IOAgMA/NwKYDyABQoCAgICAgIDAPzcCjA8gASAAOALkDiABIAQ4AuAOIAFDAACAPyAFQwAAgD+SlSIAOAKIDyABIAUgAJQiADgC+A4gASAAIACUIgM4AvwOIAEgACADlDgCgA8gASADIAOUIgA4AoQPIAFDAACAPyAAQwAAAACUQwAAgD+SlTgClA8gAUEIahCAgICAAEGgDxCIgICAACICRQ0BIAIgAUEIakGgD/wKAAAgAUHAD2okgICAgAAgAg8LIAFBgICAjQQ2AqgPIAEgADgCrA8gAUGBgICAAK1CIIYiBiABQawPaq2ENwO4DyABIAYgAUGoD2qthDcDsA9Bz4HAgAAgAUGwD2pB5IjAgAAQgoCAgAAAC0EEQaAPEJSAgIAAAAsNACAAQYAIakEAIAAbC7sXBQd/BH0BfgF/D30jgICAgABBsAFrIgIkgICAgAACQCAARQ0AIAFBgAEgAUGAAUkbIQMCQCABRQ0AIABBoAxqIQQgAEGADGohBSAAQdQNaiEGIAMhByAAIQgCQAJAAkACQAJAAkADQCAIQYAEaioCACIJQwAAAAAgCbxB/////wdxQYCAgPwHSBshCgJAAkACQCAAKgKwDSIJIAAqArQNIgtcDQAgCiAAKgKoDVwNAQwCCwJAIAkgCyAJkyAAKgK4DZSSIgwgCVwNACAAIAsiCTgCsA0MAQsgDCEJAkAgCyAMk4tDvTeGNV0NACAAIAk4ArANDAELIAAgCyIJOAKwDQsgACAKOAKoDQJAIAAqAtwOIgtDAACgQWBFDQAgAEMAAIA/IAtDAACgQSAKQ5prFzqUIAmSEN6AgIAAIgkgCUMAAKBBXRsiCSAJIAteG0PbD0lAlCAAKgLYDpUQ24CAgAAiCUMAAIA/kpUiCjgCgA8gACAJIAqUIgk4AvAOIAAgCSAJlCIKOAL0DiAAIAogCpQiCzgC/A4gACAJIAqUOAL4DiAAQwAAgD8gCyAAKgKED5RDAACAP5KVOAKMDwwBCyACQYCAgI0ENgKoASACIAs4AqwBIAJBgYCAgACtQiCGIg0gAkGsAWqthDcDECACIA0gAkGoAWqthDcDCEHPgcCAACACQQhqQeSIwIAAEIKAgIAAAAsCQCAAKgK8DSIKIAAqAsANIgtbDQACQAJAIAogCyAKkyAAKgLEDZSSIgkgClwNACALIQkMAQsgCyAJk4tDvTeGNV1FDQAgCyEJCyAAIAk4ArwNIABDAACAP0MAAAAAIAkgCUMAAAAAXRsiCSAJQwAAgD9eG0MAAIBAlCIJOAKEDyAAIAlDAAAAP5RDAACAP5JDAACAPyAALQCcD0ECSRs4AogPIABDAACAPyAJIAAqAvwOlEMAAIA/kpU4AowPCwJAIAAqAsgNIgogACoCzA0iC1sNAAJAAkAgCiALIAqTIAAqAtANlJIiCSAKXA0AIAshCQwBCyALIAmTi0O9N4Y1XUUNACALIQkLIAAgCTgCyA0gAEMAAIA/QwAAAAAgCSAJQwAAAABdGyIJIAlDAACAP14bQwAAQECUENyAgIAAIgk4ApAPIABDAACAPyAJlTgClA8gACAJkYs4ApgPCyAIKgIAIQkgACAAKALUDiIOQX9qQQ8gDhsiDjYC1A4CQCAOQR9LDQAgBiAOQQJ0akMAAAAAIAkgCYtDCOU8Hl0bIgk4AgAgACgC1A5BEGoiDkEgTw0CIAYgDkECdGogCTgCACAAKALUDiIOQRFPDQNDAAAAACAAKgLwDiIJIAAqApQPIg9DAACAP0MAAIC/QwAAoEBDAACgwCAAKgKQDyIQIAAqAowPIhEgACoCiA8iEiAGIA5BAnRqIg4qAgAgDioCPJJD2fCluJRDAAAAAJIgDioCBCAOKgI4kkMDtFg6lJIgDioCCCAOKgI0kkNXdlK7lJIgDioCDCAOKgIwkkPGRRE8lJIgDioCECAOKgIskkPO56a8lJIgDioCFCAOKgIokkM9Ey89lJIgDioCGCAOKgIkkkNYuLy9lJIgDioCHCITIA4qAiCSQ+9yoD6UkiIKIAqSlCAAKgKEDyIUIAAqAoAPIhUgACoC7A4iFiAAKgL4DiIXIAAqAuAOIguUIAAqAvQOIhggACoC5A4iDJSSIAkgACoC6A4iGZSSkpSUk5SUIgogCkMAAKDAXRsiCiAKQwAAoEBeGyIKIAogCpQiCiAKIApDAAC9Q5KUQwBah0aSlEPA9wNIkpQgCiAKIApDAADgQZRDAOBERZKUQwCic0eSlEPA9wNIkpUiCiAKQwAAgL9dGyIKIApDAACAP14blCIaIAuTlCIKIAsgCpIiG5IiCiAKi0MI5TweXRshC0MAAAAAIAkgGyAMk5QiCiAMIAqSIgqSIgwgDItDCOU8Hl0bIQxDAAAAACAJIAogGZOUIhwgGSAckiIdkiIZIBmLQwjlPB5dGyEZQwAAAAAgCSAdIBaTlCIcIBYgHJIiHJIiFiAWi0MI5TweXRshFgJAAkACQAJAIAAtAJwPIg4OBAMAAQIDCyAKIRwMAgsgCiAdIB2SkyAckkMAAIBAlCEcDAELIBogG0MAAIBAlJMgCkMAAMBAlJIgHUMAAIBAlJMgHJIhHAtDAAAAACAJIA9DAACAP0MAAIC/QwAAoEBDAACgwCAQIBEgEyASlCAUIBUgFyALlCAYIAyUkiAJIBmUkiAWkpSUk5SUIgogCkMAAKDAXRsiCiAKQwAAoEBeGyIKIAogCpQiCiAKIApDAAC9Q5KUQwBah0aSlEPA9wNIkpQgCiAKIApDAADgQZRDAOBERZKUQwCic0eSlEPA9wNIkpUiCiAKQwAAgL9dGyIKIApDAACAP14blCIPIAuTlCIKIAsgCpIiHZIiCiAKi0MI5TweXRshG0MAAAAAIAkgHSAMk5QiCiAMIAqSIgqSIgsgC4tDCOU8Hl0bIQxDAAAAACAJIAogGZOUIgsgGSALkiILkiIZIBmLQwjlPB5dGyEZQwAAAAAgCSALIBaTlCIJIBYgCZIiCZIiFiAWi0MI5TweXRshFgJAAkACQAJAIA4OBAMCAQADCyAPIB1DAACAQJSTIApDAADAQJSSIAtDAACAQJSTIAmSIQkMAgsgCiALIAuSkyAJkkMAAIBAlCEJDAELIAohCQsgACoCmA8hCiAAIBY4AuwOIAAgGTgC6A4gACAMOALkDiAAIBs4AuAOIAAgACgCoA0iDkF/akEPIA4bIg42AqANIA5BH0sNBCAEIA5BAnRqIAogHJQiCzgCACAAKAKgDUEQaiIOQSBPDQUgBCAOQQJ0aiALOAIAIAAoAqQNIg5BB0sNBiAFIA5BAnRqIg4qAgAhCyAOIAogCZQ4AgAgACAAKAKkDUEBakEHcTYCpA0gACgCoA0iDkERTw0HIAhBgAhqIAtDAAAAP5QgBCAOQQJ0aiIOKgIAIA4qAjySQ9nwpbiUQwAAAACSIA4qAgQgDioCOJJDA7RYOpSSIA4qAgggDioCNJJDV3ZSu5SSIA4qAgwgDioCMJJDxkURPJSSIA4qAhAgDioCLJJDzuemvJSSIA4qAhQgDioCKJJDPRMvPZSSIA4qAhggDioCJJJDWLi8vZSSIA4qAhwgDioCIJJD73KgPpSSkjgCACAIQQRqIQggB0F/aiIHDQEMCAsLIA5BIEHEiMCAABCLgICAAAALIA5BIEHUiMCAABCLgICAAAALIA4gDkEQakEgQfSIwIAAEIyAgIAAAAsgDkEgQcSIwIAAEIuAgIAAAAsgDkEgQdSIwIAAEIuAgIAAAAsgDkEIQYSJwIAAEIuAgIAAAAsgDiAOQRBqQSBB9IjAgAAQjICAgAAACwJAIAAoAuAOQf////8HcUH////7B0oNACAAKALkDkH/////B3FB////+wdKDQAgACgC6A5B/////wdxQf////sHSg0AIAAoAuwOQf////8HcUH////7B0oNACAAQdQNahCDgICAAEUNACAAQaAMahCDgICAAEUNACAAKAKADEH/////B3FB////+wdKDQAgACgChAxB/////wdxQf////sHSg0AIAAoAogMQf////8HcUH////7B0oNACAAKAKMDEH/////B3FB////+wdKDQAgACgCkAxB/////wdxQf////sHSg0AIAAoApQMQf////8HcUH////7B0oNACAAKAKYDEH/////B3FB////+wdKDQAgACgCnAxB/////wdxQf////sHTA0BCyAAQeAOaiIOQgA3AgggDkIANwIAIAJBKGpBAEGAAfwLACAAQdQNakEAQYQB/AsAIAJCADcDICACQgA3AxggAkIANwMQIAJCADcDCCAAQYAMaiACQQhqQaAB/AoAACAAQgA3AqANIAFFDQAgA0ECdCIORQ0AIABBgAhqQQAgDvwLAAsgAkGwAWokgICAgAALtAEBAX8jgICAgABBoAFrIgEkgICAgAACQCAARQ0AIAAgACoCtA04ArANIAAgACoCwA04ArwNIAAgACoCzA04AsgNIAAQgICAgAAgAEIANwLoDiAAQgA3AuAOIAFBIGpBAEGAAfwLACAAQdQNakEAQYQB/AsAIAFCADcDGCABQgA3AxAgAUIANwMIIAFCADcDACAAQYAMaiABQaAB/AoAACAAQgA3AqANCyABQaABaiSAgICAAAvKAQMBfwF9AX4jgICAgABBIGsiAiSAgICAAAJAAkAgAEUNACABvEH/////B3FB////+wdKDQAgACoCrA0iA0MAAKBBYEUNASAAIANDAACgQSABIAFDAACgQV0bIgEgASADXhsQ2ICAgAA4ArQNCyACQSBqJICAgIAADwsgAkGAgICNBDYCCCACIAM4AgwgAkGBgICAAK1CIIYiBCACQQxqrYQ3AxggAiAEIAJBCGqthDcDEEHPgcCAACACQRBqQeSIwIAAEIKAgIAAAAtDAAJAIABFDQAgAbxB/////wdxQf////sHSg0AIABDAACAP0MAAAAAIAEgAUMAAAAAXRsiASABQwAAgD9eGzgCzA0LC2cBAn8CQAJAAkAgAEUNAEECIQJBACEDAkACQCABQX9qDgMDAQAEC0EDIQILIAAgAjoAnA8gAEMAAIA/OAKIDwsPC0EBIQMLIAAgAzoAnA8gACAAKgKED0MAAAA/lEMAAIA/kjgCiA8LQwACQCAARQ0AIAG8Qf////8HcUH////7B0oNACAAQwAAgD9DAAAAACABIAFDAAAAAF0bIgEgAUMAAIA/Xhs4AsANCwuSAwEEfyAAKAIMIQICQAJAAkACQCABQYACSQ0AIAAoAhghAwJAAkACQCACIABHDQAgAEEUQRAgACgCFCICG2ooAgAiAQ0BQQAhAgwCCyAAKAIIIgEgAjYCDCACIAE2AggMAQsgAEEUaiAAQRBqIAIbIQQDQCAEIQUgASICQRRqIAJBEGogAigCFCIBGyEEIAJBFEEQIAEbaigCACIBDQALIAVBADYCAAsgA0UNAgJAAkAgACAAKAIcQQJ0QaypwIAAaiIBKAIARg0AIAMoAhAgAEYNASADIAI2AhQgAg0DDAQLIAEgAjYCACACRQ0EDAILIAMgAjYCECACDQEMAgsCQCACIAAoAggiBEYNACAEIAI2AgwgAiAENgIIDwtBAEEAKALErMCAAEF+IAFBA3Z3cTYCxKzAgAAPCyACIAM2AhgCQCAAKAIQIgFFDQAgAiABNgIQIAEgAjYCGAsgACgCFCIBRQ0AIAIgATYCFCABIAI2AhgPCw8LQQBBACgCyKzAgABBfiAAKAIcd3E2AsiswIAAC+4GAQR/IAAgAWohAgJAAkACQAJAAkAgACgCBCIDQQFxDQAgA0ECcUUNASAAKAIAIgMgAWohAQJAIAAgA2siAEEAKALUrMCAAEcNACACKAIEQQNxQQNHDQFBACABNgLMrMCAACACIAIoAgRBfnE2AgQgACABQQFyNgIEIAIgATYCAA8LIAAgAxClgICAAAsCQAJAAkAgAigCBCIDQQJxDQAgAkEAKALYrMCAAEYNAiACQQAoAtSswIAARg0EIAIgA0F4cSIDEKWAgIAAIAAgAyABaiIBQQFyNgIEIAAgAWogATYCACAAQQAoAtSswIAARw0BQQAgATYCzKzAgAAPCyACIANBfnE2AgQgACABQQFyNgIEIAAgAWogATYCAAsCQCABQYACSQ0AQR8hAiABQYCAgAhJDQQMBQsCQAJAQQAoAsSswIAAIgJBASABQQN2dCIDcQ0AQQAgAiADcjYCxKzAgAAgAUH4AXFBvKrAgABqIgEhAgwBCyABQfgBcSIBQbyqwIAAaiECIAFBxKrAgABqKAIAIQELIAIgADYCCCABIAA2AgwgACACNgIMIAAgATYCCA8LQQAgADYC2KzAgABBAEEAKALQrMCAACABaiIBNgLQrMCAACAAIAFBAXI2AgQgAEEAKALUrMCAAEcNAEEAQQA2AsyswIAAQQBBADYC1KzAgAALDwtBACAANgLUrMCAAEEAQQAoAsyswIAAIAFqIgE2AsyswIAAIAAgAUEBcjYCBCAAIAFqIAE2AgAPCyABQSYgAUEIdmciAmt2QQFxIAJBAXRyQT5zIQILIABCADcCECAAIAI2AhwgAkECdEGsqcCAAGohAwJAQQAoAsiswIAAQQEgAnQiBHENACADIAA2AgAgACADNgIYIAAgADYCDCAAIAA2AghBAEEAKALIrMCAACAEcjYCyKzAgAAPCwJAAkACQCADKAIAIgQoAgRBeHEgAUcNACAEIQIMAQsgAUEAQRkgAkEBdmsgAkEfRht0IQMDQCAEIANBHXZBBHFqIgUoAhAiAkUNAiADQQF0IQMgAiEEIAIoAgRBeHEgAUcNAAsLIAIoAggiASAANgIMIAIgADYCCCAAQQA2AhggACACNgIMIAAgATYCCA8LIAVBEGogADYCACAAIAQ2AhggACAANgIMIAAgADYCCAsNACABIAAQ14CAgAAAC54BAgF/AX4jgICAgABBMGsiAiSAgICAACACQdyLwIAANgIEIAIgADYCACACQdyLwIAANgIMIAIgATYCCCACQQI2AhQgAkHljcCAADYCECACQYOAgIAArUIghiIDIAJBCGqthDcDKCACIAMgAq2ENwMgIAJBhICAgACtQiCGIAJBEGqthDcDGEGAgsCAACACQRhqQbCMwIAAEIKAgIAAAAscACAAKAIAIAEgACgCBCgCDBGAgICAAICAgIAAC8EKAQx/IAAoAgQhAiAAKAIAIQMCQAJAIAEoAggiBEGAgIDAAXFFDQACQAJAIARBgICAgAFxDQACQCACQRBJDQAgAiADIANBA2pBfHEiBWsiBmoiB0EDcSEIQQAhCUEAIQACQCADIAVGDQBBACEKQQAhAAJAIAZBfEsNAEEAIQpBACEAA0AgACADIApqIgssAABBv39KaiALQQFqLAAAQb9/SmogC0ECaiwAAEG/f0pqIAtBA2osAABBv39KaiEAIApBBGoiCg0ACwsgAyAKaiELA0AgACALLAAAQb9/SmohACALQQFqIQsgBkEBaiIGDQALCwJAIAhFDQAgBSAHQfz///8HcWoiCywAAEG/f0ohCSAIQQFGDQAgCSALLAABQb9/SmohCSAIQQJGDQAgCSALLAACQb9/SmohCQsgB0ECdiEIIAkgAGohCgNAIAUhCSAIRQ0DIAhBwAEgCEHAAUkbIgdBA3EhDAJAAkAgB0ECdCINQfAHcSIADQBBACELDAELIAkgAGohBkEAIQsgCSEAA0AgAEEMaigCACIFQX9zQQd2IAVBBnZyQYGChAhxIABBCGooAgAiBUF/c0EHdiAFQQZ2ckGBgoQIcSAAQQRqKAIAIgVBf3NBB3YgBUEGdnJBgYKECHEgACgCACIFQX9zQQd2IAVBBnZyQYGChAhxIAtqampqIQsgAEEQaiIAIAZHDQALCyAIIAdrIQggCSANaiEFIAtBCHZB/4H8B3EgC0H/gfwHcWpBgYAEbEEQdiAKaiEKIAxFDQALIAkgB0H8AXFBAnRqIgsoAgAiAEF/c0EHdiAAQQZ2ckGBgoQIcSEAAkAgDEEBRg0AIAsoAgQiBUF/c0EHdiAFQQZ2ckGBgoQIcSAAaiEAIAxBAkYNACALKAIIIgtBf3NBB3YgC0EGdnJBgYKECHEgAGohAAsgAEEIdkH/gRxxIABB/4H8B3FqQYGABGxBEHYgCmohCgwCCwJAIAINAEEAIQoMAgsgAkEDcSELQQAhBUEAIQoCQCACQQRJDQAgAkEMcSEGQQAhCkEAIQUDQCAKIAMgBWoiACwAAEG/f0pqIABBAWosAABBv39KaiAAQQJqLAAAQb9/SmogAEEDaiwAAEG/f0pqIQogBiAFQQRqIgVHDQALIAtFDQILIAMgBWohAANAIAogACwAAEG/f0pqIQogAEEBaiEAIAtBf2oiCw0ADAILCwJAAkACQCABLwEOIgoNAEEAIQIMAQsgAyACaiEGQQAhAiADIQsgCiEFA0AgCyIAIAZGDQICQAJAIAAsAAAiC0F/TA0AIABBAWohCwwBCwJAIAtBYE8NACAAQQJqIQsMAQsgAEEEQQMgC0FvSxtqIQsLIAsgAGsgAmohAiAFQX9qIgUNAAsLQQAhBQsgCiAFayEKCyAKIAEvAQwiAEkNAQsgASgCACADIAIgASgCBCgCDBGBgICAAICAgIAADwsgACAKayEJQQAhAEEAIQgCQAJAAkAgBEEddkEDcQ4EAgABAgILIAkhCAwBCyAJQf7/A3FBAXYhCAsgBEH///8AcSEKIAEoAgQhCyABKAIAIQUCQAJAA0AgAEH//wNxIAhB//8DcU8NAUEBIQYgAEEBaiEAIAUgCiALKAIQEYCAgIAAgICAgABFDQAMAgsLQQEhBiAFIAMgAiALKAIMEYGAgIAAgICAgAANACAJIAhrQf//A3EhCEEAIQADQAJAIABB//8DcSAISQ0AQQAPC0EBIQYgAEEBaiEAIAUgCiALKAIQEYCAgIAAgICAgABFDQALCyAGCzgCAX8BfiOAgICAAEEQayIBJICAgIAAIAApAgAhAiABIAA2AgwgASACNwIEIAFBBGoQxYCAgAAAC/QEAQh/I4CAgIAAQRBrIgQkgICAgAACQAJAAkAgA0EBcQ0AIAItAAAiBQ0BQQAhBQwCCyAAIAIgA0EBdiABKAIMEYGAgIAAgICAgAAhBQwBCyABKAIMIQZBACEHA0AgAkEBaiEIAkACQAJAAkACQCAFwEF/Sg0AIAVB/wFxIglBgAFGDQEgCUHAAUcNAyAEIAE2AgQgBCAANgIAIARCoICAgAY3AgggAyAHQQN0aiIFKAIAIAQgBSgCBBGAgICAAICAgIAARQ0CQQEhBQwGCwJAIAAgCCAFQf8BcSIFIAYRgYCAgACAgICAAA0AIAggBWohAgwEC0EBIQUMBQsCQCAAIAJBA2oiBSACLwABIgIgBhGBgICAAICAgIAADQAgBSACaiECDAMLQQEhBQwECyAHQQFqIQcgCCECDAELQaCAgIAGIQoCQCAFQQFxRQ0AIAJBBWohCCACKAABIQoLQQAhCQJAAkAgBUECcQ0AQQAhCyAIIQIMAQsgCEECaiECIAgvAAAhCwsCQAJAIAVBBHENACACIQgMAQsgAkECaiEIIAIvAAAhCQsCQAJAIAVBCHENACAIIQIMAQsgCEECaiECIAgvAAAhBwsCQCAFQRBxRQ0AIAMgC0H//wNxQQN0ai8BBCELCwJAIAVBIHFFDQAgAyAJQf//A3FBA3RqLwEEIQkLIAQgCTsBDiAEIAs7AQwgBCAKNgIIIAQgATYCBCAEIAA2AgACQCADIAdBA3RqIgUoAgAgBCAFKAIEEYCAgIAAgICAgABFDQBBASEFDAMLIAdBAWohBwsgAi0AACIFDQALQQAhBQsgBEEQaiSAgICAACAFC/YEAgd/AX4gACgCCCIFQYCAgAFxIgZBFXYgBGohBwJAAkAgBUGAgIAEcQ0AQQAhAQwBCwJAAkAgAg0AQQAhCAwBCyABLAAAQb9/SiEIIAJBAUYNACAIIAEsAAFBv39KaiEICyAIIAdqIQcLQStBfyAGGyEJAkACQCAHIAAvAQwiCk8NAAJAAkACQCAFQYCAgAhxDQAgCiAHayEKQQAhBkEAIQsCQAJAAkAgBUEddkEDcQ4EAgABAAILIAohCwwBCyAKQf7/A3FBAXYhCwsgBUH///8AcSEIIAAoAgQhByAAKAIAIQADQCAGQf//A3EgC0H//wNxTw0CQQEhBSAGQQFqIQYgACAIIAcoAhARgICAgACAgICAAEUNAAwFCwsgACAAKQIIIgynQYCAgP95cUGwgICAAnI2AghBASEFIAAoAgAiCCAAKAIEIgsgCSABIAIQroCAgAANA0EAIQYgCiAHa0H//wNxIQcDQCAGQf//A3EgB08NAkEBIQUgBkEBaiEGIAhBMCALKAIQEYCAgIAAgICAgABFDQAMBAsLQQEhBSAAIAcgCSABIAIQroCAgAANAiAAIAMgBCAHKAIMEYGAgIAAgICAgAANAiAKIAtrQf//A3EhC0EAIQYDQAJAIAZB//8DcSALSQ0AQQAPC0EBIQUgBkEBaiEGIAAgCCAHKAIQEYCAgIAAgICAgABFDQAMAwsLQQEhBSAIIAMgBCALKAIMEYGAgIAAgICAgAANASAAIAw3AghBAA8LQQEhBSAAKAIAIgYgACgCBCIAIAkgASACEK6AgIAADQAgBiADIAQgACgCDBGBgICAAICAgIAAIQULIAULRgACQCACQX9GDQAgACACIAEoAhARgICAgACAgICAAEUNAEEBDwsCQCADDQBBAA8LIAAgAyAEIAEoAgwRgYCAgACAgICAAAu9AgEHfyOAgICAAEEQayICJICAgIAAQQohAyAAKAIAIgQhBQJAIARB6AdJDQBBCiEDIAQhBQNAIAJBBmogA2oiBkF8aiAFIgAgAEGQzgBuIgVBkM4AbGsiB0H//wNxQeQAbiIIQQF0LwDnjcCAADsAACAGQX5qIAcgCEHkAGxrQf//A3FBAXQvAOeNwIAAOwAAIANBfGohAyAAQf+s4gRLDQALCwJAAkAgBUEJSw0AIAUhAAwBCyACQQZqIANBfmoiA2ogBSAFQf//A3FB5ABuIgBB5ABsa0H//wNxQQF0LwDnjcCAADsAAAsCQAJAIARFDQAgAEUNAQsgAkEGaiADQX9qIgNqIABBAXQtAOiNwIAAOgAACyABQQFBACACQQZqIANqQQogA2sQrYCAgAAhAyACQRBqJICAgIAAIAMLNAEBfyOAgICAAEEQayICJICAgIAAIAIgATYCDCACIAA2AgggAkEIaiACQQxqEKiAgIAAAAurBAMCfwN+An8jgICAgABBIGsiAiSAgICAACAAKAIAIQMCQAJAAkAgASgCCCIAQYCAgBBxDQAgAEGAgIAgcQ0BQRQhACADKQMAIgQhBQJAIARC6AdUDQBBFCEAIAQhBQNAIAJBDGogAGoiA0F8aiAFIgYgBkKQzgCAIgVCkM4Afn2nIgdB//8DcUHkAG4iCEEBdC8A543AgAA7AAAgA0F+aiAHIAhB5ABsa0H//wNxQQF0LwDnjcCAADsAACAAQXxqIQAgBkL/rOIEVg0ACwsCQCAFQglYDQAgAkEMaiAAQX5qIgBqIAWnIgMgA0H//wNxQeQAbiIDQeQAbGtB//8DcUEBdC8A543AgAA7AAAgA60hBQsCQAJAIARQDQAgBVANAQsgAkEMaiAAQX9qIgBqIAWnQQF0LQDojcCAADoAAAsgAUEBQQAgAkEMaiAAakEUIABrEK2AgIAAIQAMAgsgAykDACEGQREhAANAIAJBDGogAGpBfmogBqdBD3EtAMyLwIAAOgAAIABBf2ohACAGQgSIIgZCAFINAAsgAUHcocCAAEECIAJBDGogAGpBf2pBESAAaxCtgICAACEADAELIAMpAwAhBkERIQADQCACQQxqIABqQX5qIAanQQ9xLQDeocCAADoAACAAQX9qIQAgBkIEiCIGQgBSDQALIAFB3KHAgABBAiACQQxqIABqQX9qQREgAGsQrYCAgAAhAAsgAkEgaiSAgICAACAAC8YFAgx/An4jgICAgABBoAFrIgMkgICAgABBACEEIANBAEGgAfwLAAJAAkACQCAAKAKgASIFIAJJDQAgBUEpTw0CIAVBAWohBiAFQQJ0IQcgASACQQJ0aiEIQQAhCUEAIQoCQANAIAMgCUECdGohCwNAIAkhBCALIQwgASAIRg0EIAxBBGohCyAEQQFqIQkgASgCACENIAFBBGoiDiEBIA1FDQALIA2tIQ9CACEQIAchDSAEIQEgACELA0AgAUEoTw0CIAwgECAMNQIAfCALNQIAIA9+fCIQPgIAIBBCIIghECAMQQRqIQwgAUEBaiEBIAtBBGohCyANQXxqIg0NAAsgBSEMAkACQCAQUA0AIAQgBWoiDEEoTw0BIAMgDEECdGogEKc2AgAgBiEMCyAKIAwgBGoiDCAKIAxLGyEKIA4hAQwBCwsgDEEoQfiMwIAAEIuAgIAAAAsgAUEoQfiMwIAAEIuAgIAAAAsgAkEBaiEGIAJBAnQhByAAIAVBAnRqIQ4gACELQQAhCgJAA0AgAyAEQQJ0aiEJA0AgBCENIAkhDCALIA5GDQMgDEEEaiEJIA1BAWohBCALKAIAIQggC0EEaiIFIQsgCEUNAAsgCK0hD0IAIRAgByEIIA0hCyABIQkDQCALQShPDQIgDCAQIAw1AgB8IAk1AgAgD358IhA+AgAgEEIgiCEQIAxBBGohDCALQQFqIQsgCUEEaiEJIAhBfGoiCA0ACyACIQwCQAJAIBBQDQAgDSACaiIMQShPDQEgAyAMQQJ0aiAQpzYCACAGIQwLIAogDCANaiIMIAogDEsbIQogBSELDAELCyAMQShB+IzAgAAQi4CAgAAACyALQShB+IzAgAAQi4CAgAAACyAAIANBoAH8CgAAIAAgCjYCoAEgA0GgAWokgICAgAAgAA8LQQAgBUEoQfiMwIAAEIyAgIAAAAvCBAEJfwJAAkACQCABQYAKTw0AIAFBBXYhAgJAAkACQCAAKAKgASIDRQ0AIANBf2ohBCADQQJ0IABqQXxqIQUgAyACakECdCAAakF8aiEGIANBKUkhAwNAIANFDQIgAiAEaiIHQShPDQMgBiAFKAIANgIAIAZBfGohBiAFQXxqIQUgBEF/aiIEQX9HDQALCyABQR9xIQUCQCACRQ0AIAJBAnQiBEUNACAAQQAgBPwLAAsgACgCoAEiByACaiEEAkAgBQ0AIAAgBDYCoAEgAA8LIARBf2oiBkEnSw0DIAQhCCAAIAZBAnRqKAIAQSAgBWsiBnYiA0UNBAJAIARBJ0sNACAAIARBAnRqIAM2AgAgBEEBaiEIDAULIARBKEH4jMCAABCLgICAAAALIARBKEH4jMCAABCLgICAAAALIAdBKEH4jMCAABCLgICAAAALQYiNwIAAQR1B+IzAgAAQjoCAgAAACyAGQShB+IzAgAAQi4CAgAAACwJAIAJBAWoiCSAETw0AAkACQCAHQQFxRQ0AIAQhAwwBCyAAIARBf2oiA0ECdGoiASAAIARBAnRqQXhqKAIAIAZ2IAEoAgAgBXRyNgIACyAHQQJGDQAgA0ECdCAAakF0aiEEA0AgBEEIaiIHIARBBGoiASgCACIKIAZ2IAcoAgAgBXRyNgIAIAEgBCgCACAGdiAKIAV0cjYCACAEQXhqIQQgCSADQX5qIgNJDQALCyAAIAJBAnRqIgQgBCgCACAFdDYCACAAIAg2AqABIAALUgEBfyOAgICAAEEQayIAJICAgIAAIABBHDYCBCAAQeCjwIAANgIAIABBhICAgACtQiCGIACthDcDCEG1gsCAACAAQQhqQfyjwIAAEIKAgIAAAAsTAEGwj8CAAEEzIAAQgoCAgAAAC4QDAQF/AkACQCACRQ0AIAEtAABBME0NASAFQQI7AQACQAJAAkACQAJAIAPBIgZBAUgNACAFIAE2AgQgAiADQf//A3EiA0sNAiAFQQA7AQwgBSACNgIIIAUgAyACazYCECAEDQFBAiEBDAQLIAUgAjYCICAFIAE2AhwgBUECOwEYIAVBADsBDCAFQQI2AgggBUH1i8CAADYCBCAFQQAgBmsiAzYCEEEDIQEgBCACTQ0DIAQgAmsiAiADTQ0DIAIgBmohBAwCCyAFQQE2AiAgBUGvj8CAADYCHCAFQQI7ARgMAQsgBUECOwEYIAVBATYCFCAFQa+PwIAANgIQIAVBAjsBDCAFIAM2AgggBSACIANrIgI2AiAgBSABIANqNgIcAkAgBCACSw0AQQMhAQwCCyAEIAJrIQQLIAUgBDYCKCAFQQA7ASRBBCEBCyAAIAE2AgQgACAFNgIADwtByY/AgABBIUHsj8CAABCOgICAAAALQfyPwIAAQR9BnJDAgAAQjoCAgAAAC50KAgZ/An4CQAJAAkACQAJAAkAgAUEISQ0AIAFBB3EiAkUNBSAAKAKgASIDQShLDQECQCADDQAgAEEANgKgAQwGCyADQQJ0IgRBfGoiBUECdkEBaiIGQQNxIQcgAkECdCgC6J/AgAAgAnatIQhCACEJIAAhAgJAAkAgBUEMSQ0AIAZB/P///wdxIQVCACEJIAAhAgNAIAIgAjUCACAIfiAJfCIJPgIAIAJBBGoiBiAGNQIAIAh+IAlCIIh8Igk+AgAgAkEIaiIGIAY1AgAgCH4gCUIgiHwiCT4CACACQQxqIgYgBjUCACAIfiAJQiCIfCIJPgIAIAlCIIghCSACQRBqIQIgBUF8aiIFDQALIAdFDQELIAdBAnQhBQNAIAIgAjUCACAIfiAJfCIJPgIAIAJBBGohAiAJQiCIIQkgBUF8aiIFDQALCwJAIAlQDQAgA0EoRg0DIAAgBGogCac2AgAgA0EBaiEDCyAAIAM2AqABDAULIAAoAqABIgZBKEsNAgJAIAYNACAAQQA2AqABIAAPCyABQQJ0NQLon8CAACEIIAZBAnQiB0F8aiIFQQJ2QQFqIgFBA3EhA0IAIQkgACECAkACQCAFQQxJDQAgAUH8////B3EhBUIAIQkgACECA0AgAiACNQIAIAh+IAl8Igk+AgAgAkEEaiIBIAE1AgAgCH4gCUIgiHwiCT4CACACQQhqIgEgATUCACAIfiAJQiCIfCIJPgIAIAJBDGoiASABNQIAIAh+IAlCIIh8Igk+AgAgCUIgiCEJIAJBEGohAiAFQXxqIgUNAAsgA0UNAQsgA0ECdCEFA0AgAiACNQIAIAh+IAl8Igk+AgAgAkEEaiECIAlCIIghCSAFQXxqIgUNAAsLAkAgCVANACAGQShGDQQgACAHaiAJpzYCACAGQQFqIQYLIAAgBjYCoAEgAA8LQQAgA0EoQfiMwIAAEIyAgIAAAAtBKEEoQfiMwIAAEIuAgIAAAAtBACAGQShB+IzAgAAQjICAgAAAC0EoQShB+IzAgAAQi4CAgAAACwJAAkACQCABQQhxRQ0AIAAoAqABIgNBKEsNAQJAAkAgAw0AQQAhAwwBCyADQQJ0IgRBfGoiBUECdkEBaiIGQQNxIQdCACEIIAAhAgJAAkAgBUEMSQ0AIAZB/P///wdxIQVCACEIIAAhAgNAIAIgAjUCAELh6xd+IAh8Igg+AgAgAkEEaiIGIAY1AgBC4esXfiAIQiCIfCIIPgIAIAJBCGoiBiAGNQIAQuHrF34gCEIgiHwiCD4CACACQQxqIgYgBjUCAELh6xd+IAhCIIh8Igg+AgAgCEIgiCEIIAJBEGohAiAFQXxqIgUNAAsgB0UNAQsgB0ECdCEFA0AgAiACNQIAQuHrF34gCHwiCD4CACACQQRqIQIgCEIgiCEIIAVBfGoiBQ0ACwsgCFANACADQShGDQMgACAEaiAIpzYCACADQQFqIQMLIAAgAzYCoAELAkAgAUEQcUUNACAAQZCgwIAAQQIQsoCAgAAaCwJAIAFBIHFFDQAgAEGYoMCAAEEDELKAgIAAGgsCQCABQcAAcUUNACAAQaSgwIAAQQUQsoCAgAAaCwJAIAFBgAFxRQ0AIABBuKDAgABBChCygICAABoLAkAgAUGAAnFFDQAgAEHgoMCAAEETELKAgIAAGgsgACABELOAgIAAGiAADwtBACADQShB+IzAgAAQjICAgAAAC0EoQShB+IzAgAAQi4CAgAAAC/0CAQR/AkACQAJAAkACQAJAAkACQCAHIAhYDQAgByAIfSAIWA0EAkAgByAGfSAGWA0AIAcgBkIBhn0gCEIBhloNBAsgBiAIWA0HIAcgBiAIfSIIfSAIVg0HIAMgAksNBSABIANqIQkgAyEKA0AgCiILRQ0CIAtBf2oiCiABaiIMLQAAQTlGDQALIAwgDC0AAEEBajoAACADIAtrIgpFDQIgASALakEwIAr8CwAMAgsgAEEANgIADwsCQAJAIAMNAEExIQoMAQsgAUExOgAAQTAhCiADQX9qIgtFDQAgAUEBakEwIAv8CwALIARBAWrBIgQgBcFMDQAgAyACTw0AIAkgCjoAACADQQFqIQMLIAMgAk0NA0EAIAMgAkGsocCAABCMgICAAAALIAMgAk0NAkEAIAMgAkHMocCAABCMgICAAAALIABBADYCAA8LQQAgAyACQbyhwIAAEIyAgIAAAAsgACAEOwEIIAAgAzYCBCAAIAE2AgAPCyAAQQA2AgALmA0KAX8GfgF/BH4BfwV+An8BfgR/An4jgICAgABB0ABrIgMkgICAgAACQAJAAkACQAJAAkACQAJAAkACQAJAIAEpAwAiBEIAUQ0AIAEpAwgiBUIAUQ0BIAEpAxAiBkIAUQ0CIAYgBHwiByAGVA0DIAQgBVQNBCAHQoCAgICAgICAIFoNBSADIAEvARgiATsBQCADIAQgBX0iBTcDOCADIAUgB3kiBoYiCCAGiCIJNwNIIAkgBVINBiADIAE7AUAgAyAENwM4IAMgBCAGhiIJIAaIIgU3A0ggBSAEUg0HQaB/IAEgBqdrIgprwUHQAGxBsKcFakHOEG0iAUHQAEsNCSADQSBqIAFBBHQiASkD0JDAgAAiBEIAIAcgBoZCABDfgICAACADQRBqIARCACAIQgAQ34CAgAAgAyAEQgAgCUIAEN+AgIAAQgFBACAKIAEvAdiQwIAAamsiCq0iBIYiCEJ/fCELIAMpAxBCP4chDCADKQMAQj+IIQ0gAykDCCEOIAEvAdqQwIAAIQEgCkE/cSEPIAMpAxghEAJAIAMpAygiESADKQMgQj+IIhJ8IhNCAXwiFCAEiKciFUGQzgBJDQAgFUHAhD1JDQkCQCAVQYDC1y9JDQBBCEEJIBVBgJTr3ANJIgobIRZBgMLXL0GAlOvcAyAKGyEKDAwLQQZBByAVQYCt4gRJIgobIRZBwIQ9QYCt4gQgChshCgwLCwJAIBVB5ABJDQBBAkEDIBVB6AdJIgobIRZB5ABB6AcgChshCgwLC0EKQQEgFUEJSyIWGyEKDAoLQeCawIAAQRxBvJvAgAAQjoCAgAAAC0HMm8CAAEEdQeybwIAAEI6AgIAAAAtB/JvAgABBHEGYnMCAABCOgICAAAALQdCdwIAAQTZBiJ7AgAAQjoCAgAAAC0GIncCAAEE3QcCdwIAAEI6AgIAAAAtBqJzAgABBLUHYnMCAABCOgICAAAALIANByABqIANBOGoQsICAgAAACyADQcgAaiADQThqELCAgIAAAAtBBEEFIBVBoI0GSSIKGyEWQZDOAEGgjQYgChshCgwBCyABQdEAQYybwIAAEIuAgIAAAAsgFCALgyEEIA0gDnwhFyAPrSEGIBYgAWtBAWohGCAMIBB9IBR8QgF8IgkgC4MhBUEAIQECQAJAAkACQAJAAkACQAJAAkADQCACIAFqIhkgFSAKbiIPQTBqIho6AAAgAUEBaiEbIAkgFSAPIApsayIVrSAGhiIcIAR8IgdWDQICQCAWIAFHDQBCASEHA0AgByEJIAEiCkEQRg0FIAIgCmpBAWogBEIKfiIEIAaIp0EwaiIVOgAAIAlCCn4hByAKQQFqIQEgBUIKfiIFIAQgC4MiBFgNAAsgBSAEfSIcIAhUIQ8gByAUIBd9fiIGIAd8IQ0gBCAGIAd9IgtaDQcgHCAIWg0CDAcLIApBCkkhDyAKQQpuIQogGyEBIA9FDQALQeicwIAAELWAgIAAAAsgAiABaiEBIAUgCH0hFCAIIAt9IQxCACAEfSEGA0ACQCAEIAh8IgcgC1QNACALIAZ8IAwgBHxaDQBBACEPDAYLIAEgFUF/aiIVOgAAIBQgBnwiHCAIVCEPIAcgC1oNBiAGIAh9IQYgByEEIBwgCFQNBgwACwsgCSAHfSIIIAqtIAaGIgZUIQEgFCAXfSIFQgF8IR0gByAFQn98IgtaDQEgCCAGVA0BIBMgDHwgEH0gBCAGfCIEIBx8fUICfCEUIBMgF30gB30hDCAEIA18IA58IBJ9IBF9IBx8IQhCACEEA0ACQCAHIAZ8IgUgC1QNACAMIAR8IAhaDQBBACEBDAMLIBkgGkF/aiIaOgAAIBQgBHwiHCAGVCEBIAUgC1oNAyAIIAZ8IQggBCAGfSEEIAUhByAcIAZUDQMMAAsLQRFBEUH4nMCAABCLgICAAAALIAchBQsCQCAdIAVYDQAgAQ0AAkAgBSAGfCIEIB1UDQAgHSAFfSAEIB19VA0BCyAAQQA2AgAMBAsCQAJAIAVCAlQNACAFIAlCfHxYDQELIABBADYCAAwECyAAIBg7AQggACAbNgIEDAILIAQhBwsCQCANIAdYDQAgDw0AAkAgByAIfCIEIA1UDQAgDSAHfSAEIA19VA0BCyAAQQA2AgAMAgsCQAJAIAlCFH4gB1YNACAHIAUgCUJYfnxYDQELIABBADYCAAwCCyAAIBg7AQggACAKQQJqNgIECyAAIAI2AgALIANB0ABqJICAgIAAC9gvAwF/BH4efyOAgICAAEGwCmsiAySAgICAAAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQCABKQMAIgRCAFENACABKQMIIgVCAFENASABKQMQIgZCAFENAiAGIAR8IgcgBlQNAyAEIAVUDQQgASwAGiEIIAEuARghASADIAQ3AwggA0EBQQIgBEKAgICAEFQbNgKoASADQQhqQQhqQQBBmAH8CwAgAyAFNwOwASADQQFBAiAFQoCAgIAQVBs2AtACIANBsAFqQQhqQQBBmAH8CwAgAyAGNwPYAiADQQFBAiAGQoCAgIAQVBs2AvgDIANB2AJqQQhqQQBBmAH8CwAgA0GABGpBAEGcAfwLACADQQE2AvwDIANBATYCnAUgAawgB0J/fHl9QsKawegEfkKAoc2gtAJ8QiCIpyIJwSEKAkACQCABQQBIDQAgA0EIaiABELOAgIAAGiADQbABaiABELOAgIAAGiADQdgCaiABELOAgIAAGgwBCyADQfwDakEAIAFrwRCzgICAABoLAkACQCAKQX9KDQAgA0EIakEAIAprQf//A3EiARC3gICAABogA0GwAWogARC3gICAABogA0HYAmogARC3gICAABoMAQsgA0H8A2ogCUH//wFxELeAgIAAGgsgA0GMCWogA0EIakGkAfwKAAAgAygC+AMiCyADKAKsCiIBIAsgAUsbIgxBKEsNBQJAAkAgDA0AQQAhDAwBC0EAIQ1BACEOAkACQAJAIAxBAUYNACAMQQFxIQ8gDEE+cSEQQQAhDSADQYwJaiEBIANB2AJqIQlBACEOA0AgASAJKAIAIhEgASgCAGoiEiANQQFxaiITNgIAIAFBBGoiDSAJQQRqKAIAIhQgDSgCAGoiDSASIBFJIBMgEklyaiISNgIAIA0gFEkgEiANSXIhDSAJQQhqIQkgAUEIaiEBIBAgDkECaiIORw0ACyAPRQ0BCyADQYwJaiAOQQJ0IgFqIgkgA0HYAmogAWooAgAiEiAJKAIAaiIBIA1qIgk2AgAgASASSQ0BIAkgAUkNAQwCCyANRQ0BCyAMQShGDQcgA0GMCWogDEECdGpBATYCACAMQQFqIQwLIAMgDDYCrAogDCADKAKcBSIVIAwgFUsbIgFBKU8NByABQQJ0IQEgA0GMCWpBfGohEgJAA0ACQCABDQBBACEBDAILIBIgAWohCSABQXxqIgEgA0H8A2pqKAIAIg0gCSgCACIJRg0ACyANIAlLIA0gCUlrIQELAkACQCABIAhIDQACQAJAAkACQAJAIAMoAqgBIg1BKEsNAAJAIA0NAEEAIQ0MBQsgDUECdCIRQXxqIgFBAnZBAWoiCUEDcSEOIAFBDE8NAUIAIQQgA0EIaiEBDAILQQAgDUEoQfiMwIAAEIyAgIAAAAsgCUH8////B3EhCUIAIQQgA0EIaiEBA0AgASABNQIAQgp+IAR8IgQ+AgAgAUEEaiISIBI1AgBCCn4gBEIgiHwiBD4CACABQQhqIhIgEjUCAEIKfiAEQiCIfCIEPgIAIAFBDGoiEiASNQIAQgp+IARCIIh8IgQ+AgAgBEIgiCEEIAFBEGohASAJQXxqIgkNAAsgDkUNAQsgDkECdCEJA0AgASABNQIAQgp+IAR8IgQ+AgAgAUEEaiEBIARCIIghBCAJQXxqIgkNAAsLIARQDQAgDUEoRg0LIANBCGogEWogBKc2AgAgDUEBaiENCyADIA02AqgBAkACQAJAAkACQCADKALQAiIOQShLDQBBACEWQQAhASAORQ0EIA5BAnQiE0F8aiIBQQJ2QQFqIglBA3EhESABQQxPDQFCACEEIANBsAFqIQEMAgtBACAOQShB+IzAgAAQjICAgAAACyAJQfz///8HcSEJQgAhBCADQbABaiEBA0AgASABNQIAQgp+IAR8IgQ+AgAgAUEEaiISIBI1AgBCCn4gBEIgiHwiBD4CACABQQhqIhIgEjUCAEIKfiAEQiCIfCIEPgIAIAFBDGoiEiASNQIAQgp+IARCIIh8IgQ+AgAgBEIgiCEEIAFBEGohASAJQXxqIgkNAAsgEUUNAQsgEUECdCEJA0AgASABNQIAQgp+IAR8IgQ+AgAgAUEEaiEBIARCIIghBCAJQXxqIgkNAAsLAkAgBFBFDQAgDiEBDAELIA5BKEYNDCADQbABaiATaiAEpzYCACAOQQFqIQELIAMgATYC0AICQCALRQ0AIAtBAnQiEUF8aiIBQQJ2QQFqIglBA3EhDgJAAkACQCABQQxPDQBCACEEIANB2AJqIQEMAQsgCUH8////B3EhCUIAIQQgA0HYAmohAQNAIAEgATUCAEIKfiAEfCIEPgIAIAFBBGoiEiASNQIAQgp+IARCIIh8IgQ+AgAgAUEIaiISIBI1AgBCCn4gBEIgiHwiBD4CACABQQxqIhIgEjUCAEIKfiAEQiCIfCIEPgIAIARCIIghBCABQRBqIQEgCUF8aiIJDQALIA5FDQELIA5BAnQhCQNAIAEgATUCAEIKfiAEfCIEPgIAIAFBBGohASAEQiCIIQQgCUF8aiIJDQALCwJAIARQRQ0AIAMgCyIWNgL4AwwDCyALQShGDQ0gA0HYAmogEWogBKc2AgAgC0EBaiEWCyADIBY2AvgDDAELIApBAWohCiADKAKoASENIAshFgsgA0GgBWogA0H8A2pBpAH8CgAAIANBoAVqQQEQs4CAgAAhFyADQcQGaiADQfwDakGkAfwKAAAgA0HEBmpBAhCzgICAACEYIANB6AdqIANB/ANqQaQB/AoAAAJAAkACQCADQegHakEDELOAgIAAIhkoAqABIhogDSAaIA1LGyIbQShLDQAgA0H8A2pBfGohDyADQYwJakF8aiEcIANBoAVqQXxqIQsgA0HEBmpBfGohDCADQegHakF8aiEQIBcoAqABIR0gGCgCoAEhHkEAIR8DQCAfISAgG0ECdCEBAkACQANAIAFFDQEgECABaiEJIAFBfGoiASADQQhqaigCACISIAkoAgAiCUYNAAtBACEhIBIgCUkNAQsCQCAbRQ0AQQEhDUEAIQ4CQAJAIBtBAUYNACAbQQFxISIgG0E+cSEjQQAhDkEBIQ0gA0EIaiEBIANB6AdqIQkDQCABIAEoAgAiESAJKAIAQX9zaiISIA1BAXFqIhM2AgAgAUEEaiINIA0oAgAiFCAJQQRqKAIAQX9zaiINIBIgEUkgEyASSXJqIhI2AgAgDSAUSSASIA1JciENIAlBCGohCSABQQhqIQEgIyAOQQJqIg5HDQALICJFDQELIANBCGogDkECdCIBaiIJIAkoAgAiCSAZIAFqKAIAQX9zaiIBIA1qIhI2AgAgASAJSQ0BIBIgAUkNAQwkCyANRQ0jCyADIBs2AqgBQQghISAbIQ0LIB4gDSAeIA1LGyIbQSlPDQ8gG0ECdCEBAkACQANAIAFFDQEgDCABaiEJIAFBfGoiASADQQhqaigCACISIAkoAgAiCUYNAAsgEiAJTw0AIA0hGwwBCwJAIBtFDQBBASENQQAhDgJAAkAgG0EBRg0AIBtBAXEhIiAbQT5xISNBACEOQQEhDSADQQhqIQEgA0HEBmohCQNAIAEgASgCACIRIAkoAgBBf3NqIhIgDUEBcWoiEzYCACABQQRqIg0gDSgCACIUIAlBBGooAgBBf3NqIg0gEiARSSATIBJJcmoiEjYCACANIBRJIBIgDUlyIQ0gCUEIaiEJIAFBCGohASAjIA5BAmoiDkcNAAsgIkUNAQsgA0EIaiAOQQJ0IgFqIgkgCSgCACIJIBggAWooAgBBf3NqIgEgDWoiEjYCACABIAlJDQEgEiABSQ0BDCMLIA1FDSILIAMgGzYCqAEgIUEEciEhCyAdIBsgHSAbSxsiIkEpTw0QICJBAnQhAQJAAkADQCABRQ0BIAsgAWohCSABQXxqIgEgA0EIamooAgAiEiAJKAIAIglGDQALIBIgCU8NACAbISIMAQsCQCAiRQ0AQQEhDUEAIQ4CQAJAICJBAUYNACAiQQFxIRsgIkE+cSEjQQAhDkEBIQ0gA0EIaiEBIANBoAVqIQkDQCABIAEoAgAiESAJKAIAQX9zaiISIA1BAXFqIhM2AgAgAUEEaiINIA0oAgAiFCAJQQRqKAIAQX9zaiINIBIgEUkgEyASSXJqIhI2AgAgDSAUSSASIA1JciENIAlBCGohCSABQQhqIQEgIyAOQQJqIg5HDQALIBtFDQELIANBCGogDkECdCIBaiIJIAkoAgAiCSAXIAFqKAIAQX9zaiIBIA1qIhI2AgAgASAJSQ0BIBIgAUkNAQwiCyANRQ0hCyADICI2AqgBICFBAmohIQsgFSAiIBUgIksbIhtBKU8NESAbQQJ0IQECQAJAA0AgAUUNASABQXxqIgEgA0EIamooAgAiCSABIANB/ANqaigCACISRg0ACyAJIBJPDQAgIiEbDAELAkAgG0UNAEEBIQ1BACEOAkACQCAbQQFGDQAgG0EBcSEiIBtBPnEhI0EAIQ5BASENIANBCGohASADQfwDaiEJA0AgASABKAIAIhEgCSgCAEF/c2oiEiANQQFxaiITNgIAIAFBBGoiDSANKAIAIhQgCUEEaigCAEF/c2oiDSASIBFJIBMgEklyaiISNgIAIA0gFEkgEiANSXIhDSAJQQhqIQkgAUEIaiEBICMgDkECaiIORw0ACyAiRQ0BCyADQQhqIA5BAnQiAWoiCSAJKAIAIgkgA0H8A2ogAWooAgBBf3NqIgEgDWoiEjYCACABIAlJDQEgEiABSQ0BDCELIA1FDSALIAMgGzYCqAEgIUEBaiEhCyAgQRFGDRYgAiAgaiAhQTBqOgAAIAMoAtACIiEgGyAhIBtLGyIBQSlPDRIgIEEBaiEfIAFBAnQhAQJAA0ACQCABDQBBACEkDAILIAFBfGoiASADQQhqaigCACIJIAEgA0GwAWpqKAIAIhJGDQALIAkgEksgCSASSWshJAsgA0GMCWogA0EIakGkAfwKAAAgFiADKAKsCiIBIBYgAUsbIiJBKEsNEwJAAkAgIg0AQQAhIgwBC0EAIQ1BACEOAkACQAJAICJBAUYNACAiQQFxISUgIkE+cSEjQQAhDSADQYwJaiEBIANB2AJqIQlBACEOA0AgASAJKAIAIhEgASgCAGoiEiANQQFxaiITNgIAIAFBBGoiDSAJQQRqKAIAIhQgDSgCAGoiDSASIBFJIBMgEklyaiISNgIAIA0gFEkgEiANSXIhDSAJQQhqIQkgAUEIaiEBICMgDkECaiIORw0ACyAlRQ0BCyADQYwJaiAOQQJ0IgFqIgkgA0HYAmogAWooAgAiEiAJKAIAaiIBIA1qIgk2AgAgASASSQ0BIAkgAUkNAQwCCyANRQ0BCyAiQShGDRUgA0GMCWogIkECdGpBATYCACAiQQFqISILIAMgIjYCrAogIiAVICIgFUsbIgFBKU8NFSABQQJ0IQECQANAAkAgAQ0AQQAhAQwCCyAcIAFqIQkgDyABaiESIAFBfGohASASKAIAIhIgCSgCACIJRg0ACyASIAlLIBIgCUlrIQELICQgCEgNAiABIAhIDQNBACEOQQAhDQJAIBtFDQAgG0ECdCIRQXxqIgFBAnZBAWoiCUEDcSENAkACQAJAIAFBDE8NAEIAIQQgA0EIaiEBDAELIAlB/P///wdxIQlCACEEIANBCGohAQNAIAEgATUCAEIKfiAEfCIEPgIAIAFBBGoiEiASNQIAQgp+IARCIIh8IgQ+AgAgAUEIaiISIBI1AgBCCn4gBEIgiHwiBD4CACABQQxqIhIgEjUCAEIKfiAEQiCIfCIEPgIAIARCIIghBCABQRBqIQEgCUF8aiIJDQALIA1FDQELIA1BAnQhCQNAIAEgATUCAEIKfiAEfCIEPgIAIAFBBGohASAEQiCIIQQgCUF8aiIJDQALCwJAIARQRQ0AIBshDQwBCyAbQShGDRggA0EIaiARaiAEpzYCACAbQQFqIQ0LIAMgDTYCqAECQCAhRQ0AICFBAnQiEUF8aiIBQQJ2QQFqIglBA3EhDgJAAkACQCABQQxPDQBCACEEIANBsAFqIQEMAQsgCUH8////B3EhCUIAIQQgA0GwAWohAQNAIAEgATUCAEIKfiAEfCIEPgIAIAFBBGoiEiASNQIAQgp+IARCIIh8IgQ+AgAgAUEIaiISIBI1AgBCCn4gBEIgiHwiBD4CACABQQxqIhIgEjUCAEIKfiAEQiCIfCIEPgIAIARCIIghBCABQRBqIQEgCUF8aiIJDQALIA5FDQELIA5BAnQhCQNAIAEgATUCAEIKfiAEfCIEPgIAIAFBBGohASAEQiCIIQQgCUF8aiIJDQALCwJAIARQRQ0AICEhDgwBCyAhQShGDRkgA0GwAWogEWogBKc2AgAgIUEBaiEOCyADIA42AtACAkACQCAWDQBBACEWDAELIBZBAnQiEUF8aiIBQQJ2QQFqIglBA3EhDgJAAkACQCABQQxPDQBCACEEIANB2AJqIQEMAQsgCUH8////B3EhCUIAIQQgA0HYAmohAQNAIAEgATUCAEIKfiAEfCIEPgIAIAFBBGoiEiASNQIAQgp+IARCIIh8IgQ+AgAgAUEIaiISIBI1AgBCCn4gBEIgiHwiBD4CACABQQxqIhIgEjUCAEIKfiAEQiCIfCIEPgIAIARCIIghBCABQRBqIQEgCUF8aiIJDQALIA5FDQELIA5BAnQhCQNAIAEgATUCAEIKfiAEfCIEPgIAIAFBBGohASAEQiCIIQQgCUF8aiIJDQALCyAEUA0AIBZBKEYNGiADQdgCaiARaiAEpzYCACAWQQFqIRYLIAMgFjYC+AMgGiANIBogDUsbIhtBKUkNAAsLQQAgG0EoQfiMwIAAEIyAgIAAAAsgASAITg0ZIANBCGpBARCzgICAABogFSADKAKoASIBIBUgAUsbIgFBKU8NFyABQQJ0IQEgA0EIakF8aiENIANB/ANqQXxqIQ4DQCABRQ0BIA4gAWohCSANIAFqIRIgAUF8aiEBIBIoAgAiEiAJKAIAIglGDQALIBIgCUkNGQsgAiAfaiENIB8hAQJAA0AgASIJRQ0BIAlBf2oiASACaiISLQAAQTlGDQALIBIgEi0AAEEBajoAACAfIAlrIgFFDRkgAiAJakEwIAH8CwAMGQsgAkExOgAAAkAgIEUNACACQQFqQTAgIPwLAAsgIEEPSw0XIA1BMDoAACAKQQFqIQogIEECaiEfDBkLQeCawIAAQRxB6J7AgAAQjoCAgAAAC0HMm8CAAEEdQfiewIAAEI6AgIAAAAtB/JvAgABBHEGIn8CAABCOgICAAAALQdCdwIAAQTZB2J/AgAAQjoCAgAAAC0GIncCAAEE3QcifwIAAEI6AgIAAAAtBACAMQShB+IzAgAAQjICAgAAAC0EoQShB+IzAgAAQi4CAgAAAC0EAIAFBKEH4jMCAABCMgICAAAALQShBKEH4jMCAABCLgICAAAALQShBKEH4jMCAABCLgICAAAALQShBKEH4jMCAABCLgICAAAALQQAgG0EoQfiMwIAAEIyAgIAAAAtBACAiQShB+IzAgAAQjICAgAAAC0EAIBtBKEH4jMCAABCMgICAAAALQQAgAUEoQfiMwIAAEIyAgIAAAAtBACAiQShB+IzAgAAQjICAgAAAC0EoQShB+IzAgAAQi4CAgAAAC0EAIAFBKEH4jMCAABCMgICAAAALQRFBEUGYn8CAABCLgICAAAALQShBKEH4jMCAABCLgICAAAALQShBKEH4jMCAABCLgICAAAALQShBKEH4jMCAABCLgICAAAALQQAgAUEoQfiMwIAAEIyAgIAAAAsgH0ERQaifwIAAEIuAgIAAAAsgIEEQTQ0AQQAgH0ERQbifwIAAEIyAgIAAAAsgACAKOwEIIAAgHzYCBCAAIAI2AgAgA0GwCmokgICAgAAPC0HbjMCAAEEaQfiMwIAAEI6AgIAAAAtB24zAgABBGkH4jMCAABCOgICAAAALQduMwIAAQRpB+IzAgAAQjoCAgAAAC0HbjMCAAEEaQfiMwIAAEI6AgIAAAAukBQMCfwF+BX8jgICAgABBEGsiAiSAgICAAAJAAkAgAC8BDCIDDQAgACgCACAAKAIEIAEQvICAgAAhAQwBCyACIAEpAgg3AwggAiABKQIANwMAAkACQAJAIAApAggiBKciBUGAgIAIcQ0AIAIoAgQhBgwBCyAAKAIAIAIoAgAgAigCBCIBIAAoAgQoAgwRgYCAgACAgICAAA0BIAAgBUGAgID/eXFBsICAgAJyIgU2AgggAkIBNwMAQQAhBkEAIAMgAUH//wNxayIBIAEgA0sbIQMLAkAgAigCDCIHRQ0AIAIoAgghAQNAAkACQAJAAkACQCABLwEADgMAAQIACyABQQRqKAIAIQgMAwsgAUECai8BACIIDQFBASEIDAILIAFBCGooAgAhCAwBCyAIQfb/F2ogCEGc/x9qcSAIQZj4N2ogCEHwsR9qcXNBEXZBAWohCAtBfyAGIAhqIgggCCAGSRshBiABQQxqIQEgB0F/aiIHDQALCwJAIAYgA0H//wNxSQ0AIAAoAgAgACgCBCACELyAgIAAIQEgACAENwIIDAILIAMgBmshCUEAIQFBACEDAkACQAJAIAVBHXZBA3EOBAIAAQACCyAJIQMMAQsgCUH+/wNxQQF2IQMLIAVB////AHEhCCAAKAIEIQYgACgCACEHAkADQCABQf//A3EgA0H//wNxTw0BIAFBAWohASAHIAggBigCEBGAgICAAICAgIAARQ0ADAILCyAHIAYgAhC8gICAAA0AIAkgA2tB//8DcSEFQQAhAwNAAkAgA0H//wNxIAVJDQBBACEBIAAgBDcCCAwDC0EBIQEgA0EBaiEDIAcgCCAGKAIQEYCAgIAAgICAgABFDQALIAAgBDcCCAwBC0EBIQELIAJBEGokgICAgAAgAQuvBAEHfyOAgICAAEEQayIDJICAgIAAAkACQAJAIAIoAgQiBEUNACAAIAIoAgAgBCABKAIMEYGAgIAAgICAgAANAQsCQCACKAIMIgUNAEEAIQIMAgsgAigCCCIEIAVBDGxqIQYDQAJAAkACQAJAAkACQAJAAkAgBC8BAA4DAAECAAsgBCgCBCICQcEASQ0CIAFBDGooAgAhBQNAIABBpY3AgABBwAAgBRGBgICAAICAgIAADQkgAkFAaiICQcAASw0ADAQLCyAELwECIQIgA0EAOgAMIANBADYCCCACDQMgAyACQTByOgAIQQEhBQwECyAAIAQoAgQgBCgCCCABQQxqKAIAEYGAgIAAgICAgABFDQQMBgsgAkUNAyABQQxqKAIAIQULIABBpY3AgAAgAiAFEYGAgIAAgICAgAANBAwCCyADQQhqIAJB9v8XaiACQZz/H2pxIAJBmPg3aiACQfCxH2pxc0ERdiIHaiIIIAIgAkEKbiIJQQpsa0EwcjoAACAHQQFqIQUgB0UNACAIQX9qIAlBCnBBMHI6AAAgBUECRg0AIAhBfmogAkHkAG5BCnBBMHI6AAAgBUEDRg0AIAhBfWogAkHoB25BCnBBMHI6AAAgBUEERg0AIAhBfGogAkGQzgBuQTByOgAACyAAIANBCGogBSABQQxqKAIAEYGAgIAAgICAgAANAgsgBEEMaiIEIAZHDQALQQAhAgwBC0EBIQILIANBEGokgICAgAAgAgvYBQQFfwJ+An8BfiOAgICAAEGAAWsiAySAgICAACABvCIEQf///wNxIgVBgICABHIgBEEBdEH+//8HcSAEQRd2Qf8BcSIGGyIHrSIIQgGDIQlBAiEKAkACQAJAAkACQCAFRUEEQQNBAiAFGyAEQYCAgPwHcSIFGyAFQYCAgPwHRhsOBQQAAQIDBAtBAyEKDAMLQQQhCgwCCyAGQep+aiELIAmnQQFzIQpCASEMDAELQoCAgBAgCEIBhiAHQYCAgARGIgUbIQhCAkIBIAUbIQwgCadBAXMhCkHofkHpfiAFGyAGaiELCyADIAs7AXggAyAMNwNwIANCATcDaCADIAg3A2AgAyAKOgB6AkACQAJAAkACQAJAIApB/wFxQQFLDQBB7IvAgABBASAEQQBIIgobIQVB7IvAgABB7YvAgAAgChshCiAEQR92IQQgA0EgaiADQeAAaiADQQ9qELmAgIAAIAMoAiBFDQEgAyADKAIoNgJYIAMgAykCIDcDUAwCCyAKQX5qQf8BcSILRQ0CQQEhCkHsi8CAAEHti8CAACAEQQBIIgUbQeyLwIAAQQEgBRsgAhshBUEBIARBH3YgAhshBCADQQI7ASAgC0ECRg0DIANBAzYCKCADQfGLwIAANgIkIANBIGohCwwECyADQdAAaiADQeAAaiADQQ9qELqAgIAACyAKIAUgAhshBUEBIAQgAhshBCADIAMoAlAgAygCVCADLwFYQQEgA0EgahC2gICAACADKAIEIQogAygCACELDAILIANBAzYCKCADQe6LwIAANgIkIANBAjsBIEEBIQUgA0EgaiELQQAhBEEBIQoMAQsgA0EBNgIwIANBADsBLCADQQI2AiggA0H1i8CAADYCJCADQSBqIQtBAiEKCyADIAo2AlwgAyALNgJYIAMgBDYCVCADIAU2AlAgACADQdAAahC7gICAACEEIANBgAFqJICAgIAAIAQLnAcFBX8CfgJ/AX4BfyOAgICAAEGgAWsiAySAgICAACABvCIEQf///wNxIgVBgICABHIgBEEBdEH+//8HcSAEQRd2Qf8BcSIGGyIHrSIIQgGDIQlBAiEKAkACQAJAAkACQCAFRUEEQQNBAiAFGyAEQYCAgPwHcSIFGyAFQYCAgPwHRhsOBQQAAQIDBAtBAyEKDAMLQQQhCgwCCyAGQep+aiELIAmnQQFzIQpCASEMDAELQoCAgBAgCEIBhiAHQYCAgARGIgUbIQhCAkIBIAUbIQwgCadBAXMhCkHofkHpfiAFGyAGaiELCyADIAs7AYgBIAMgDDcDgAEgA0IBNwN4IAMgCDcDcCADIAo6AIoBAkACQAJAAkACQAJAAkACQAJAIApB/wFxQQFLDQAgA0HgAGogA0HwAGogA0EHahC5gICAACADKAJgRQ0BIAMgAygCaDYCmAEgAyADKQJgNwOQAQwCCyAKQX5qQf8BcSIGRQ0CQQEhCkHsi8CAAEHti8CAACAEQQBIIgUbQeyLwIAAQQEgBRsgAhshBUEBIARBH3YgAhshCyADQQI7ARggBkECRg0DIANBAzYCICADQfGLwIAANgIcDAcLIANBkAFqIANB8ABqIANBB2oQuoCAgAALIAMoApQBIgVFDQIgAygCkAEiCi0AAEEwTQ0DQeyLwIAAQQEgBEEASCILGyEHQeyLwIAAQe2LwIAAIAsbIQsgBEEfdiENIAMuAZgBIQYgA0EBNgIgIAMgCjYCHCADQQI7ARgCQCAFQX9qIgUNACADQSRqIQRBAyEKDAULIANBPGohBCADIAU2AjggA0ECOwEwIANBr4/AgAA2AiggA0ECOwEkIANBATYCLCADIApBAWo2AjRBBSEKDAQLIANBAzYCICADQe6LwIAANgIcIANBAjsBGEEBIQVBACELQQEhCgwECyADQQM2AiAgA0H3i8CAADYCHAwDC0HJj8CAAEEhQayQwIAAEI6AgIAAAAtB/I/AgABBH0G8kMCAABCOgICAAAALIAsgByACGyEFQQEgDSACGyELIARBATsBDCAEQQI7AQAgBEECQQEgBkEBSCICGzYCCCAEQc2QwIAAQcyQwIAAIAIbNgIEIAQgBkF/aiICIAJBH3UiAnMgAms7AQ4LIAMgCjYCbCADIAs2AmQgAyAFNgJgIAMgA0EYajYCaCAAIANB4ABqELuAgIAAIQQgA0GgAWokgICAgAAgBAuPMwcFfwJ+Bn8EfgV/AX4SfyOAgICAAEHwDmsiBCSAgICAACABvCIFQf///wNxIgZBgICABHIgBUEBdEH+//8HcSAFQRd2Qf8BcSIHGyIIrSIJQgGDIQpBAiELIANB//8DcSEMAkACQAJAAkACQAJAAkACQAJAIAZFQQRBA0ECIAYbIAVBgICA/AdxIgYbIAZBgICA/AdGGw4FAwIABAEDC0EEIQsMAgtCgICAECAJQgGGIAhBgICABEYiCxshCSAKp0EBcyEGQeh+Qel+IAsbIAdqIQ0MAwtBAyELCyALQX5qIQYgBUEfdiELDAILIAdB6n5qIQ0gCqdBAXMhBgsgBkH/AXFBAU0NASAFQR92IQsgBkF+aiEGCwJAAkACQCAGQf8BcSIIRQ0AQQEhBkHsi8CAAEHti8CAACALG0Hsi8CAAEEBIAsbIAIbIQtBASAFQR92IAIbIQcgCEECRw0BIARBAjsBzA0gA0H//wNxDQJBASEGIARBATYC1A0gBEH0i8CAADYC0A0gBEHMDWohCAwECyAEQQM2AtQNIARB7ovAgAA2AtANIARBAjsBzA1BASELIARBzA1qIQhBACEHQQEhBgwDCyAEQQM2AtQNIARB8YvAgAA2AtANIARBAjsBzA0gBEHMDWohCAwCCyAEIAw2AtwNIARBADsB2A1BAiEGIARBAjYC1A0gBEH1i8CAADYC0A0gBEHMDWohCAwBCwJAAkACQAJAAkACQAJAAkACQAJAAkACQEF0QQUgDUEASBsgDWwiBkHA/QBPDQAgCUIAUQ0BQaB/IA0gCXkiCqdrIgdrQdAAbEGwpwVqQc4QbSILQdAASw0CIAZBBHYiDkEVaiEPQQAgA2tBgIB+IAPBQX9KG8EhECAEQRBqIAtBBHQiBikD0JDAgABCACAJIAqGQgAQ34CAgABCAUFAIAcgBi8B2JDAgABqayILrSIRhiISQn98IhMgBCkDEEI/iCAEKQMYfCIKgyIUUA0FIAYvAdqQwIAAIQggC0E/cSEVAkAgCiARiKciB0GQzgBJDQAgB0HAhD1JDQQCQCAHQYDC1y9JDQBBCEEJIAdBgJTr3ANJIgYbIRZBgMLXL0GAlOvcAyAGGyEGDAYLQQZBByAHQYCt4gRJIgYbIRZBwIQ9QYCt4gQgBhshBgwFCwJAIAdB5ABJDQBBAkEDIAdB6AdJIgYbIRZB5ABB6AcgBhshBgwFC0EKQQEgB0EJSyIWGyEGDAQLQfqLwIAAQSVBoIzAgAAQjoCAgAAAC0HgmsCAAEEcQfyawIAAEI6AgIAAAAsgC0HRAEGMm8CAABCLgICAAAALQQRBBSAHQaCNBkkiBhshFkGQzgBBoI0GIAYbIQYLIBWtIREgFiAIa0EBasEiFyAQTA0DIAtB//8DcSEYIBcgEGsiC8EgDyALIA9JGyIZQX9qIRVBACELAkADQCAEQSxqIAtqIAcgBm4iCEEwajoAACAHIAggBmxrIQcgFSALRg0DIBYgC0YNASALQQFqIQsgBkEKSSEIIAZBCm4hBiAIRQ0AC0Gcm8CAABC1gICAAAALIAtBAWohBkFsIA5rIQsgGEF/akE/ca0hGkIBIQoDQCAKIBqIQgBSDQEgCyAGakEBRg0DIARBLGogBmogFEIKfiIUIBGIp0EwajoAACAKQgp+IQogFCATgyEUIBkgBkEBaiIGRw0ACyAEQawIaiAEQSxqIA8gGSAXIBAgFCASIAoQuICAgAAMBAsgBEEANgKsCAwECyAEQawIaiAEQSxqIA8gGSAXIBAgB60gEYYgFHwgBq0gEYYgEhC4gICAAAwCCyAGIA9BrJvAgAAQi4CAgAAACyAEQawIaiAEQSxqIA9BACAXIBAgCkIKgCAGrSARhiASELiAgIAACyAEKAKsCCIIRQ0AIAQvAbQIIRggBCgCsAghFwwBCyAEQQE2AtgJIAQgCTcDuAggBEHACGpBAEGYAfwLACAEQeQJakEAQZwB/AsAIARBATYC4AkgBEEBNgKACyANrCAJQn98eX1CwprB6AR+QoChzaC0AnxCIIinIgbBIRgCQAJAIA1BAEgNACAEQbgIaiANELOAgIAAGgwBCyAEQeAJakEAIA1rQf//A3EQs4CAgAAaCwJAAkAgGEF/Sg0AIARBuAhqQQAgGGtB//8DcRC3gICAABoMAQsgBEHgCWogBkH//wFxELeAgIAAGgsgBEHMDWogBEHgCWpBpAH8CgAAIARBzA1qQXhqIRYgDyEIA0ACQAJAAkACQCAEKALsDiIGQShLDQAgBkUNAyAGQQJ0IgZBfGoiCw0BIARBzA1qIAZqIQZCACEJDAILQQAgBkEoQfiMwIAAEIyAgIAAAAsgC0ECdkEBaiIHQQFxIQ0gFiAGaiELIAdB/v///wdxIQdCACEJA0AgCyIGQQRqIgsgCUIghiALNQIAhCIJQoCU69wDgCIKPgIAIAYgCSAKQoCU69wDfn1CIIYgBjUCAIQiCUKAlOvcA4AiCj4CACAJIApCgJTr3AN+fSEJIAZBeGohCyAHQX5qIgcNAAsgDUUNAQsgBkF8aiIGIAlCIIYgBjUCAIRCgJTr3AOAPgIACyAIQXdqIghBCUsNAAsCQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkAgCEECdCgC6J/AgABBAXQiC0UNAAJAAkACQAJAAkAgBCgC7A4iBkEoSw0AAkAgBg0AQQAhBgwFCyALrSEJIAZBAnQiBkF8aiILDQEgBEHMDWogBmohBkIAIQoMAgtBACAGQShB+IzAgAAQjICAgAAACyALQQJ2QQFqIgtBAXEhCCALQf7///8HcSELIAYgBEHMDWpqQXhqIQdCACEKA0AgByIGQQRqIgcgCkIghiAHNQIAhCIKIAmAIhQ+AgAgBiAKIBQgCX59QiCGIAY1AgCEIgogCYAiFD4CACAKIBQgCX59IQogBkF4aiEHIAtBfmoiCw0ACyAIRQ0BCyAGQXxqIgYgCkIghiAGNQIAhCAJgD4CAAsgBCgC7A4hBgsgBCgC2AkiDiAGIA4gBksbIhtBKEsNAQJAAkAgGw0AQQAhGwwBC0EAIQhBACENAkACQAJAIBtBAUYNACAbQQFxIRwgG0E+cSEXQQAhCCAEQcwNaiEGIARBuAhqIQtBACENA0AgBiALKAIAIhYgBigCAGoiByAIQQFxaiIVNgIAIAZBBGoiCCALQQRqKAIAIhkgCCgCAGoiCCAHIBZJIBUgB0lyaiIHNgIAIAggGUkgByAISXIhCCALQQhqIQsgBkEIaiEGIBcgDUECaiINRw0ACyAcRQ0BCyAEQcwNaiANQQJ0IgZqIgsgBEG4CGogBmooAgAiByALKAIAaiIGIAhqIgs2AgAgBiAHSQ0BIAsgBkkNAQwCCyAIRQ0BCyAbQShGDQMgBEHMDWogG0ECdGpBATYCACAbQQFqIRsLIAQgGzYC7A4gBCgCgAsiHSAbIB0gG0sbIgZBKU8NAyAGQQJ0IQYgBEHMDWpBfGohCwJAAkADQCAGRQ0BIAsgBmooAgAiByAGQXxqIgYgBEHgCWpqKAIAIghGDQALIAcgCE8NAAJAIA4NAEEAIQ4gBEEANgLYCQwCCyAOQQJ0Ig1BfGoiBkECdkEBaiILQQNxIQgCQAJAAkAgBkEMTw0AQgAhCSAEQbgIaiEGDAELIAtB/P///wdxIQtCACEJIARBuAhqIQYDQCAGIAY1AgBCCn4gCXwiCT4CACAGQQRqIgcgBzUCAEIKfiAJQiCIfCIJPgIAIAZBCGoiByAHNQIAQgp+IAlCIIh8Igk+AgAgBkEMaiIHIAc1AgBCCn4gCUIgiHwiCT4CACAJQiCIIQkgBkEQaiEGIAtBfGoiCw0ACyAIRQ0BCyAIQQJ0IQsDQCAGIAY1AgBCCn4gCXwiCT4CACAGQQRqIQYgCUIgiCEJIAtBfGoiCw0ACwsCQCAJUA0AIA5BKEYNByAEQbgIaiANaiAJpzYCACAOQQFqIQ4LIAQgDjYC2AkMAQsgGEEBaiEYC0EAIR5BASEWAkACQCAYwSIGIBBIIh8NACAYIBBrwSAPIAYgEGsgD0kbIhcNAQtBACEXDBELIARBhAtqIARB4AlqQaQB/AoAACAEQYQLakEBELOAgIAAISAgBEGoDGogBEHgCWpBpAH8CgAAIARBqAxqQQIQs4CAgAAhISAEQcwNaiAEQeAJakGkAfwKAAAgBEHgCWpBfGohIiAEQYQLakF8aiEjIARBqAxqQXxqIRwgBEHMDWpBfGohGyAEQcwNakEDELOAgIAAISQgICgCoAEhJSAhKAKgASEmICQoAqABISdBACEoAkACQANAICghKSAOQSlPDQggKUEBaiEoIA5BAnQhB0EAIQYDQCAHIAZGDQMgBEG4CGogBmohCyAGQQRqIQYgCygCAEUNAAsgJyAOICcgDksbIipBKU8NCSAqQQJ0IQYCQAJAA0AgBkUNASAbIAZqIQsgBkF8aiIGIARBuAhqaigCACIHIAsoAgAiC0YNAAtBACErIAcgC0kNAQtBASEIQQAhDQJAAkACQCAqQQFGDQAgKkEBcSEsICpBPnEhDkEAIQ1BASEIIARBuAhqIQYgBEHMDWohCwNAIAYgBigCACIWIAsoAgBBf3NqIgcgCEEBcWoiFTYCACAGQQRqIgggCCgCACIZIAtBBGooAgBBf3NqIgggByAWSSAVIAdJcmoiBzYCACAIIBlJIAcgCElyIQggC0EIaiELIAZBCGohBiAOIA1BAmoiDUcNAAsgLEUNAQsgBEG4CGogDUECdCIGaiILIAsoAgAiCyAkIAZqKAIAQX9zaiIGIAhqIgc2AgAgBiALSQ0BIAcgBkkNAQwVCyAIRQ0UCyAEICo2AtgJQQghKyAqIQ4LICYgDiAmIA5LGyIqQSlPDQogKkECdCEGAkACQANAIAZFDQEgHCAGaiELIAZBfGoiBiAEQbgIamooAgAiByALKAIAIgtGDQALIAcgC08NACAOISoMAQsCQCAqRQ0AQQEhCEEAIQ0CQAJAICpBAUYNACAqQQFxISwgKkE+cSEOQQAhDUEBIQggBEG4CGohBiAEQagMaiELA0AgBiAGKAIAIhYgCygCAEF/c2oiByAIQQFxaiIVNgIAIAZBBGoiCCAIKAIAIhkgC0EEaigCAEF/c2oiCCAHIBZJIBUgB0lyaiIHNgIAIAggGUkgByAISXIhCCALQQhqIQsgBkEIaiEGIA4gDUECaiINRw0ACyAsRQ0BCyAEQbgIaiANQQJ0IgZqIgsgCygCACILICEgBmooAgBBf3NqIgYgCGoiBzYCACAGIAtJDQEgByAGSQ0BDBQLIAhFDRMLIAQgKjYC2AkgK0EEciErCyAlICogJSAqSxsiLEEpTw0LICxBAnQhBgJAAkADQCAGRQ0BICMgBmohCyAGQXxqIgYgBEG4CGpqKAIAIgcgCygCACILRg0ACyAHIAtPDQAgKiEsDAELAkAgLEUNAEEBIQhBACENAkACQCAsQQFGDQAgLEEBcSEqICxBPnEhDkEAIQ1BASEIIARBuAhqIQYgBEGEC2ohCwNAIAYgBigCACIWIAsoAgBBf3NqIgcgCEEBcWoiFTYCACAGQQRqIgggCCgCACIZIAtBBGooAgBBf3NqIgggByAWSSAVIAdJcmoiBzYCACAIIBlJIAcgCElyIQggC0EIaiELIAZBCGohBiAOIA1BAmoiDUcNAAsgKkUNAQsgBEG4CGogDUECdCIGaiILIAsoAgAiCyAgIAZqKAIAQX9zaiIGIAhqIgc2AgAgBiALSQ0BIAcgBkkNAQwTCyAIRQ0SCyAEICw2AtgJICtBAmohKwsgHSAsIB0gLEsbIg5BKU8NDCAOQQJ0IQYCQAJAA0AgBkUNASAiIAZqIQsgBkF8aiIGIARBuAhqaigCACIHIAsoAgAiC0YNAAsgByALTw0AICwhDgwBCwJAIA5FDQBBASEIQQAhDQJAAkAgDkEBRg0AIA5BAXEhLCAOQT5xISpBACENQQEhCCAEQbgIaiEGIARB4AlqIQsDQCAGIAYoAgAiFiALKAIAQX9zaiIHIAhBAXFqIhU2AgAgBkEEaiIIIAgoAgAiGSALQQRqKAIAQX9zaiIIIAcgFkkgFSAHSXJqIgc2AgAgCCAZSSAHIAhJciEIIAtBCGohCyAGQQhqIQYgKiANQQJqIg1HDQALICxFDQELIARBuAhqIA1BAnQiBmoiCyALKAIAIgsgBEHgCWogBmooAgBBf3NqIgYgCGoiBzYCACAGIAtJDQEgByAGSQ0BDBILIAhFDRELIAQgDjYC2AkgK0EBaiErCyApIA9GDQEgBEEsaiApaiArQTBqOgAAAkACQCAODQBBACEODAELIA5BAnQiDUF8aiIGQQJ2QQFqIgtBA3EhCAJAAkACQCAGQQxPDQBCACEJIARBuAhqIQYMAQsgC0H8////B3EhC0IAIQkgBEG4CGohBgNAIAYgBjUCAEIKfiAJfCIJPgIAIAZBBGoiByAHNQIAQgp+IAlCIIh8Igk+AgAgBkEIaiIHIAc1AgBCCn4gCUIgiHwiCT4CACAGQQxqIgcgBzUCAEIKfiAJQiCIfCIJPgIAIAlCIIghCSAGQRBqIQYgC0F8aiILDQALIAhFDQELIAhBAnQhCwNAIAYgBjUCAEIKfiAJfCIJPgIAIAZBBGohBiAJQiCIIQkgC0F8aiILDQALCyAJUA0AIA5BKEYNDiAEQbgIaiANaiAJpzYCACAOQQFqIQ4LIAQgDjYC2AkgKCAXRw0AC0EAIRYMEgsgDyAPQciewIAAEIuAgIAAAAsgFyAPSw0LIBcgKUYNESAXIClrIgZFDREgBEEsaiApakEwIAb8CwAMEQtBwIzAgABBG0H4jMCAABCOgICAAAALQQAgG0EoQfiMwIAAEIyAgIAAAAtBKEEoQfiMwIAAEIuAgIAAAAtBACAGQShB+IzAgAAQjICAgAAAC0EoQShB+IzAgAAQi4CAgAAAC0EAIA5BKEH4jMCAABCMgICAAAALQQAgKkEoQfiMwIAAEIyAgIAAAAtBACAqQShB+IzAgAAQjICAgAAAC0EAICxBKEH4jMCAABCMgICAAAALQQAgDkEoQfiMwIAAEIyAgIAAAAtBKEEoQfiMwIAAEIuAgIAAAAsgKSAXIA9B2J7AgAAQjICAgAAAC0HbjMCAAEEaQfiMwIAAEI6AgIAAAAtB24zAgABBGkH4jMCAABCOgICAAAALQduMwIAAQRpB+IzAgAAQjoCAgAAAC0HbjMCAAEEaQfiMwIAAEI6AgIAAAAsCQAJAAkACQAJAAkAgHUUNACAdQQJ0Ig1BfGoiBkECdkEBaiILQQNxIQgCQAJAAkAgBkEMTw0AQgAhCSAEQeAJaiEGDAELIAtB/P///wdxIQtCACEJIARB4AlqIQYDQCAGIAY1AgBCBX4gCXwiCT4CACAGQQRqIgcgBzUCAEIFfiAJQiCIfCIJPgIAIAZBCGoiByAHNQIAQgV+IAlCIIh8Igk+AgAgBkEMaiIHIAc1AgBCBX4gCUIgiHwiCT4CACAJQiCIIQkgBkEQaiEGIAtBfGoiCw0ACyAIRQ0BCyAIQQJ0IQsDQCAGIAY1AgBCBX4gCXwiCT4CACAGQQRqIQYgCUIgiCEJIAtBfGoiCw0ACwsCQCAJUEUNACAdIR4MAQsgHUEoRg0BIARB4AlqIA1qIAmnNgIAIB1BAWohHgsgBCAeNgKACyAeIA4gHiAOSxsiBkEpTw0BIAZBAnQhBiAEQbgIakF8aiEIIARB4AlqQXxqIQ0CQAJAA0AgBkUNASANIAZqIQsgCCAGaiEHIAZBfGohBiAHKAIAIgcgCygCACILRg0ACyAHIAtLIAcgC0lrQf8BcQ4CAAEGCwJAIBZFDQBBACEXDAcLIBdBf2oiBiAPTw0DIARBLGogBmotAABBAXFFDQULIBcgD0sNAyAEQSxqIBdqIQcgFyEGAkADQCAGIgtFDQEgC0F/aiIGIARBLGpqLQAAQTlGDQALIARBLGogBmoiBiAGLQAAQQFqOgAAIBcgC2siBkUNBSAEQSxqIAtqQTAgBvwLAAwFC0ExIQYCQCAWDQAgBEExOgAsQTAhBiAXQX9qIgtFDQAgBEEtakEwIAv8CwALIBhBAWohGCAfDQQgFyAPTw0EIAcgBjoAACAXQQFqIRcMBAtBKEEoQfiMwIAAEIuAgIAAAAtBACAGQShB+IzAgAAQjICAgAAACyAGIA9BmJ7AgAAQi4CAgAAAC0EAIBcgD0GonsCAABCMgICAAAALIBcgD00NAEEAIBcgD0G4nsCAABCMgICAAAALIARBLGohCAtB7IvAgABB7YvAgAAgBUEASCIGG0Hsi8CAAEEBIAYbIAIbIQtBASAFQR92IAIbIQcCQCAYwSAQTA0AIARBCGogCCAXIBggDCAEQcwNahC2gICAACAEKAIMIQYgBCgCCCEIDAELQQIhBiAEQQI7AcwNAkAgA0H//wNxDQBBASEGIARBATYC1A0gBEH0i8CAADYC0A0gBEHMDWohCAwBCyAEIAw2AtwNIARBADsB2A0gBEECNgLUDSAEQfWLwIAANgLQDSAEQcwNaiEICyAEIAY2ArQMIAQgCDYCsAwgBCAHNgKsDCAEIAs2AqgMIAAgBEGoDGoQu4CAgAAhBiAEQfAOaiSAgICAACAGC+oBAQJ/I4CAgIAAQRBrIgQkgICAgABBAEEAKAKoqcCAACIFQQFqNgKoqcCAAAJAAkACQCAFQQBIDQACQAJAQQAtAKCpwIAADQBBAEEBOgCgqcCAAEEAQQAoApypwIAAQQFqNgKcqcCAAEEAKAKkqcCAACIFQX9MDQIgBUEBaiIBIAVODQEQtICAgAAACyAEQQhqIAAgASgCGBGCgICAAICAgIAAAAtBACABQX9qNgKkqcCAACABQQBMDQFBAEEAOgCgqcCAACACDQILAAtBrKTAgABBzQBB1KTAgAAQgoCAgAAACxDBgICAAAALAwAACwkAIABBADYCAAseACAAQQApAsiiwIAANwIIIABBACkCwKLAgAA3AgALDgBBAEEBOgDwrMCAAAALCwAgABDGgICAAAALjAEBA38jgICAgABBEGsiASSAgICAAAJAIAAoAgAiAigCBCIDQQFxRQ0AIAIoAgAhAiABIANBAXY2AgQgASACNgIAIAFBiKLAgAAgACgCCCIALQAIIAAtAAkQwICAgAAACyABQX82AgAgASAANgIMIAFBpKLAgAAgACgCCCIALQAIIAAtAAkQwICAgAAAC4QBAQN/AkACQAJAIAAoAgAiAUEBSA0AIAAoAgQiAkF8aigCACIAQXhxIgNBBEEIIABBA3EiABsgAWpJDQECQCAARQ0AIAMgAUEnaksNAwsgAhCNgICAAAsPC0HgosCAAEEuQZCjwIAAEI6AgIAAAAtBoKPAgABBLkHQo8CAABCOgICAAAALVAACQCAAKAIAQX9GDQAgASgCACAAKAIEIAAoAgggASgCBCgCDBGBgICAAICAgIAADwsgASgCACABKAIEIAAoAgwoAgAiACgCACAAKAIEEKyAgIAAC/0BAgJ/AX4jgICAgABBIGsiAiSAgICAAAJAIAEoAgBBf0cNACABKAIMIQMgAkEANgIYIAJCgICAgBA3AhAgAkEQakHwocCAACADKAIAIgMoAgAgAygCBBCsgICAABogAiACKAIYIgM2AgggAiACKQIQIgQ3AwAgASADNgIIIAEgBDcCAAsgASgCCCEDIAFBADYCCCABKQIAIQQgAUKAgICAEDcCACACIAM2AhggAiAENwMQAkBBDBCIgICAACIBDQBBBEEMEJSAgIAAAAsgASACKAIYNgIIIAEgAikDEDcCACAAQZykwIAANgIEIAAgATYCACACQSBqJICAgIAAC6EBAgJ/AX4jgICAgABBIGsiAiSAgICAAAJAIAEoAgBBf0cNACABKAIMIQMgAkEANgIcIAJCgICAgBA3AhQgAkEUakHwocCAACADKAIAIgMoAgAgAygCBBCsgICAABogAiACKAIcIgM2AhAgAiACKQIUIgQ3AwggASADNgIIIAEgBDcCAAsgAEGcpMCAADYCBCAAIAE2AgAgAkEgaiSAgICAAAufAQEBfyOAgICAAEEQayIDJICAgIAAAkAgAiABaiIBIAJPDQBBAEEAEIaAgIAAAAsgA0EEaiAAKAIAIgIgACgCBCABIAJBAXQiAiABIAJLGyICQQggAkEISxsiAhDMgICAAAJAIAMoAgRBAUcNACADKAIIIAMoAgwQhoCAgAAACyADKAIIIQEgACACNgIAIAAgATYCBCADQRBqJICAgIAAC4EBAQF/QQAhBAJAAkAgA0EATg0AQQEhAUEEIQIMAQsCQAJAIAFFDQAgAiABQQEgAxCHgICAACEEDAELIAMQiICAgAAhBAsCQAJAIAQNAEEBIQEgAEEBNgIEDAELIAAgBDYCBEEAIQELQQghAiADIQQLIAAgAmogBDYCACAAIAE2AgALggEBA38CQAJAAkAgACgCACIBRQ0AIAAoAgQiAkF8aigCACIAQXhxIgNBBEEIIABBA3EiABsgAWpJDQECQCAARQ0AIAMgAUEnaksNAwsgAhCNgICAAAsPC0HgosCAAEEuQZCjwIAAEI6AgIAAAAtBoKPAgABBLkHQo8CAABCOgICAAAALHgAgAEEAKQLYosCAADcCCCAAQQApAtCiwIAANwIAC1oBAX8CQAJAAkAgAiAAKAIAIAAoAggiA2tNDQAgACADIAIQy4CAgAAgACgCCCEDDAELIAJFDQELIAJFDQAgACgCBCADaiABIAL8CgAACyAAIAMgAmo2AghBAAuaAgEGfyAAKAIIIQICQAJAIAFBgAFPDQBBASEDDAELAkAgAUGAEE8NAEECIQMMAQtBA0EEIAFBgIAESRshAwsCQCADIAAoAgAgAmtNDQAgACACIAMQy4CAgAALIAAoAgQgAmohBAJAAkAgAUGAAUkNACABQT9xQYB/ciEFIAFBBnYhBgJAIAFBgBBPDQAgBCAFOgABIAQgBkHAAXI6AAAMAgsgAUEMdiEHIAZBP3FBgH9yIQYCQCABQf//A0sNACAEIAU6AAIgBCAGOgABIAQgB0HgAXI6AAAMAgsgBCAFOgADIAQgBjoAAiAEIAdBP3FBgH9yOgABIAQgAUESdkFwcjoAAAwBCyAEIAE6AAALIAAgAyACajYCCEEACxQAIABB8KHAgAAgASACEKyAgIAACyQAIAEoAgAgACgCACAAKAIEIAEoAgQoAgwRgYCAgACAgICAAAtMAQJ/IAEoAgQhAiABKAIAIQMCQEEIEIiAgIAAIgENAEEEQQgQlICAgAAACyABIAI2AgQgASADNgIAIABBjKTAgAA2AgQgACABNgIACxQAIABBjKTAgAA2AgQgACABNgIACwwAIAAgASkCADcDAAvDAgEEf0EfIQICQCABQYCAgAhPDQAgAUEmIAFBCHZnIgJrdkEBcSACQQF0ckE+cyECCyAAQgA3AhAgACACNgIcIAJBAnRBrKnAgABqIQMCQEEAKALIrMCAAEEBIAJ0IgRxDQAgAyAANgIAIAAgAzYCGCAAIAA2AgwgACAANgIIQQBBACgCyKzAgAAgBHI2AsiswIAADwsCQAJAAkAgAygCACIEKAIEQXhxIAFHDQAgBCECDAELIAFBAEEZIAJBAXZrIAJBH0YbdCEDA0AgBCADQR12QQRxaiIFKAIQIgJFDQIgA0EBdCEDIAIhBCACKAIEQXhxIAFHDQALCyACKAIIIgMgADYCDCACIAA2AgggAEEANgIYIAAgAjYCDCAAIAM2AggPCyAFQRBqIAA2AgAgACAENgIYIAAgADYCDCAAIAA2AggLDQAgACABEMSAgIAAAAuNAgICfwJ9AkACQAJAIAC8IgFBgICABEgNACABQf////sHSw0BQYF/IQJDAAAAACEAIAFBgICA/ANGDQEMAgsCQCAAQwAAAABcDQBDAACAvyAAIACUlQ8LAkAgAUEASA0AIABDAAAATJS8IQFB6H4hAgwCCyAAIACTQwAAAACVIQALIAAPCyABQY32qwJqIgFBF3YgAmqyIgNDgHExP5QgAUH///8DcUHzidT5A2q+QwAAgL+SIgAgA0PR9xc3lCAAIABDAAAAQJKVIgMgACAAQwAAAD+UlCIEIAMgA5QiACAAIACUIgBD7umRPpRDqqoqP5KUIAAgAEMmnng+lEMTzsw+kpSSkpSSIASTkpILqR8IB38BfAh/AXwFfwF8BX8BfCOAgICAAEGwBGsiBiSAgICAACAGQgA3A5gBIAZCADcDkAEgBkIANwOIASAGQgA3A4ABIAZCADcDeCAGQgA3A3AgBkIANwNoIAZCADcDYCAGQgA3A1ggBkIANwNQIAZCADcDSCAGQgA3A0AgBkIANwM4IAZCADcDMCAGQgA3AyggBkIANwMgIAZCADcDGCAGQgA3AxAgBkIANwMIIAZCADcDACAGQgA3A7gCIAZCADcDsAIgBkIANwOoAiAGQgA3A6ACIAZCADcDmAIgBkIANwOQAiAGQgA3A4gCIAZCADcDgAIgBkIANwP4ASAGQgA3A/ABIAZCADcD6AEgBkIANwPgASAGQgA3A9gBIAZCADcD0AEgBkIANwPIASAGQgA3A8ABIAZCADcDuAEgBkIANwOwASAGQgA3A6gBIAZCADcDoAEgBkIANwPYAyAGQgA3A9ADIAZCADcDyAMgBkIANwPAAyAGQgA3A7gDIAZCADcDsAMgBkIANwOoAyAGQgA3A6ADIAZCADcDmAMgBkIANwOQAyAGQgA3A4gDIAZCADcDgAMgBkIANwP4AiAGQgA3A/ACIAZCADcD6AIgBkIANwPgAiAGQgA3A9gCIAZCADcD0AIgBkIANwPIAiAGQgA3A8ACIAZB4ANqQQBB0AD8CwAgBUECdCgCoKXAgAAiByABQX9qIghqIQkgBEF9akEYbSIKQQAgCkEAShsiCyAIayEKIAtBAnQgAUECdGtBtKXAgABqIQxBACEBA0ACQAJAIApBAE4NAEQAAAAAAAAAACENDAELIAwoAgC3IQ0LIAYgAUEDdGogDTkDAAJAIAEgCU8NACAMQQRqIQwgCkEBaiEKIAEgASAJSWoiASAJTQ0BCwtBACEKA0AgCiAIaiEJRAAAAAAAAAAAIQ1BACEBAkADQCANIAAgAUEDdGorAwAgBiAJIAFrQQN0aisDAKKgIQ0gASAITw0BIAEgASAISWoiASAITQ0ACwsgBkHAAmogCkEDdGogDTkDAAJAIAogB08NACAKIAogB0lqIgogB00NAQsLRAAAAAAAAPB/RAAAAAAAAOB/IAQgC0FobGoiDkFoaiIPQf4PSyIQG0QAAAAAAAAAAEQAAAAAAABgAyAPQblwSSIRG0QAAAAAAADwPyAPQYJ4SCISGyAPQf8HSiITGyAPQf0XIA9B/RdJG0GCcGogDkHpd2ogEBsiFCAPQfBoIA9B8GhLG0GSD2ogDkGxB2ogERsiFSAPIBIbIBMbQf8Haq1CNIa/oiEWIAdBAnQgBkHgA2pqQXxqIRdBLyAOa0EfcSEYQTAgDmtBH3EhGSAPQQBKIRogD0F/aiEbIAchCgJAA0AgBkHAAmogCiIEQQN0aisDACENAkAgBEUNACAGQeADaiEJIAQhAQNAIAkgDSANRAAAAAAAAHA+ovwCtyIcRAAAAAAAAHDBoqD8AjYCACAGQcACaiABQQN0akF4aisDACAcoCENIAFBAUYiCg0BIAlBBGohCUEBIAFBf2ogChsiAQ0ACwsCQAJAAkAgEw0AIBINASAPIQEMAgsgDUQAAAAAAADgf6IiDUQAAAAAAADgf6IgDSAQGyENIBQhAQwBCyANRAAAAAAAAGADoiINRAAAAAAAAGADoiANIBEbIQ0gFSEBCyANIAFB/wdqrUI0hr+iIg0gDUQAAAAAAADAP6KcRAAAAAAAACDAoqAiDSAN/AIiHbehIQ0CQAJAAkACQAJAAkAgGg0AAkAgDw0AIAZB4ANqIARBAnRqQXxqKAIAQRd1IR4MAgtBAiEeQQAhHyANRAAAAAAAAOA/ZkUNBQwCCyAGQeADaiAEQQJ0akF8aiIBIAEoAgAiASABIBl1IgEgGXRrIgk2AgAgCSAYdSEeIAEgHWohHQsgHkEBSA0BC0EBIQkCQCAERQ0AQQAhCkEAIQwCQCAEQQFGDQAgBEEBcSEgIARBHnEhH0EAIQogBkHgA2ohAUEAIQwDQCABKAIAIQkCQAJAAkACQCAMRQ0AQf///wchDAwBCyAJRQ0BQYCAgAghDAsgASAMIAlrNgIAQQAhDAwBC0EBIQwLIAFBBGoiISgCACEJAkACQAJAAkAgDA0AQf///wchDAwBCyAJRQ0BQYCAgAghDAsgISAMIAlrNgIAQQEhDEEAIQkMAQtBACEMQQEhCQsgAUEIaiEBIB8gCkECaiIKRw0ACyAgRQ0BCyAGQeADaiAKQQJ0aiIKKAIAIQECQAJAIAxFDQBB////ByEJDAELQQEhCSABRQ0BQYCAgAghCQsgCiAJIAFrNgIAQQAhCQsCQCAaRQ0AQf///wMhAQJAAkAgGw4CAQACC0H///8BIQELIAZB4ANqIARBAnRqQXxqIgogCigCACABcTYCAAsgHUEBaiEdIB5BAkYNAQsgHiEfDAELRAAAAAAAAPA/IA2hIg0gDSAWoSAJGyENQQIhHwsCQCANRAAAAAAAAAAAYg0AIBchASAEIQoCQCAHIARBf2oiCUsNAEEAIQwCQANAIAZB4ANqIAlBAnRqKAIAIAxyIQwgByAJTw0BIAcgCSAHIAlJayIJTQ0ACwsgFyEBIAQhCiAMRQ0AIAZB4ANqIARBAnRqQXxqIQEDQCAEQX9qIQQgD0FoaiEPIAEoAgAhCCABQXxqIQEgCEUNAAwECwsDQCAKQQFqIQogASgCACEJIAFBfGohASAJRQ0ACyAEIApPDQEgBEEBaiEMA0AgBiAMIAhqIglBA3RqIAwgC2pBAnQoArClwIAAtzkDAEEAIQFEAAAAAAAAAAAhDQJAA0AgDSAAIAFBA3RqKwMAIAYgCSABa0EDdGorAwCioCENIAEgCE8NASABIAEgCElqIgEgCE0NAAsLIAZBwAJqIAxBA3RqIA05AwAgDCAMIApJaiEBIAwgCk8NAiABIQwgASAKTQ0ADAILCwsCQAJAAkACQEEAIA9rIgFB/wdKDQAgAUGCeE4NAyANRAAAAAAAAGADoiENIAFBuHBNDQFByQcgD2shAQwDCyANRAAAAAAAAOB/oiENIAFB/g9LDQFBgXggD2shAQwCCyANRAAAAAAAAGADoiENIAFB8GggAUHwaEsbQZIPaiEBDAELIA1EAAAAAAAA4H+iIQ0gAUH9FyABQf0XSRtBgnBqIQELAkACQCANIAFB/wdqrUI0hr+iIg1EAAAAAAAAcEFmDQAgDSEcDAELIAZB4ANqIARBAnRqIA0gDUQAAAAAAABwPqL8ArciHEQAAAAAAABwwaKg/AI2AgAgBEEBaiEEIA4hDwsgBkHgA2ogBEECdGogHPwCNgIACwJAAkACQAJAIA9B/wdKDQAgD0GCeEgNAUQAAAAAAADwPyENDAMLIA9B/g9LDQEgD0GBeGohD0QAAAAAAADgfyENDAILAkAgD0G4cE0NACAPQckHaiEPRAAAAAAAAGADIQ0MAgsgD0HwaCAPQfBoSxtBkg9qIQ9EAAAAAAAAAAAhDQwBCyAPQf0XIA9B/RdJG0GCcGohD0QAAAAAAADwfyENCyANIA9B/wdqrUI0hr+iIQ0CQAJAIARBAXFFDQAgBCEADAELIAZBwAJqIARBA3RqIA0gBkHgA2ogBEECdGooAgC3ojkDACANRAAAAAAAAHA+oiENIARBf2ohAAsCQCAERQ0AIABBA3QgBkHAAmpqQXhqIQEgAEECdCAGQeADampBfGohCANAIAEgDUQAAAAAAABwPqIiHCAIKAIAt6I5AwAgAUEIaiANIAhBBGooAgC3ojkDACABQXBqIQEgCEF4aiEIIBxEAAAAAAAAcD6iIQ0gAEEBRyEJIABBfmohACAJDQALCyAEQQFqIR4gBkHAAmogBEEDdGohCSAEIQEDQAJAAkACQCAHIAQgASIMayILIAcgC0kbIgENAEQAAAAAAAAAACENQQAhCAwBCyABQQFqIgFBAXEhISABQX5xIQpEAAAAAAAAAAAhDUEAIQFBACEIA0AgDSABQbinwIAAaisDACAJIAFqIgArAwCioCABQcCnwIAAaisDACAAQQhqKwMAoqAhDSABQRBqIQEgCiAIQQJqIghHDQALICFFDQELIA0gCEEDdCsDuKfAgAAgBkHAAmogCCAMakEDdGorAwCioCENCyAGQaABaiALQQN0aiANOQMAIAlBeGohCSAMQX9qIQEgDA0ACwJAAkACQAJAIAUOBAECAgABC0QAAAAAAAAAACEiAkAgBEUNACAEIQECQANAIAZBoAFqIAFBA3RqIghBeGoiACAAKwMAIg0gCCsDACIcoCIWOQMAIAggHCANIBahoDkDACABQQFGIggNAUEBIAFBf2ogCBsiAQ0ACwsgBEEBRg0AIAQhAQJAA0AgBkGgAWogAUEDdGoiCEF4aiIAIAArAwAiDSAIKwMAIhygIhY5AwAgCCAcIA0gFqGgOQMAIAFBAkYiCA0BQQIgAUF/aiAIGyIBQQFLDQALC0QAAAAAAAAAACEiA0AgIiAGQaABaiAEQQN0aisDAKAhIiAEQQJGIgENAUECIARBf2ogARsiBEEBSw0ACwsgBisDoAEhDQJAIB8NACACIA05AwAgAiAiOQMQIAIgBisDqAE5AwgMAwsgAiANmjkDACACICKaOQMQIAIgBisDqAGaOQMIDAILAkACQCAeQQNxIgANAEQAAAAAAAAAACENIAQhCAwBCyAGQaABaiAEQQN0aiEBRAAAAAAAAAAAIQ0gBCEIA0AgCEF/aiEIIA0gASsDAKAhDSABQXhqIQEgAEF/aiIADQALCwJAIARBA0kNACAIQQN0IAZBoAFqakFoaiEBA0AgDSABQRhqKwMAoCABQRBqKwMAoCABQQhqKwMAoCABKwMAoCENIAFBYGohASAIQQNHIQAgCEF8aiEIIAANAAsLIAIgDZogDSAfGzkDAAwBCwJAAkAgHkEDcSIADQBEAAAAAAAAAAAhDSAEIQgMAQsgBkGgAWogBEEDdGohAUQAAAAAAAAAACENIAQhCANAIAhBf2ohCCANIAErAwCgIQ0gAUF4aiEBIABBf2oiAA0ACwsCQCAEQQNJDQAgCEEDdCAGQaABampBaGohAQNAIA0gAUEYaisDAKAgAUEQaisDAKAgAUEIaisDAKAgASsDAKAhDSABQWBqIQEgCEEDRyEAIAhBfGohCCAADQALCyACIA2aIA0gHxs5AwAgBisDoAEgDaEhDQJAIARFDQBBASEBA0AgDSAGQaABaiABQQN0aisDAKAhDSABIARPDQEgASABIARJaiIBIARNDQALCyACIA2aIA0gHxs5AwgLIAZBsARqJICAgIAAIB1BB3EL+ggFAX8BfAJ/AnwBfyOAgICAAEEQayIBJICAgIAAIAC7IQICQAJAIAC8IgNB/////wdxIgRB25+k+gNJDQACQCAEQdKn7YMESQ0AAkAgBEHW44iHBEkNAAJAIARB////+wdLDQAgAUIANwMIAkACQCAEQdqfpO4ESw0AIAIgAkSDyMltMF/kP6JEAAAAAAAAOEOgRAAAAAAAADjDoCIFRAAAAFD7Ifm/oqAgBURjYhphtBBRvqKgIQYgBfwCIQQMAQsgASAEIARBF3ZB6n5qIgdBF3Rrvrs5AwAgAUEBIAFBCGpBASAHQQAQ2YCAgAAhBAJAIANBAEgNACABKwMIIQYMAQtBACAEayEEIAErAwiaIQYLRAAAAAAAAPC/IAYgBiAGIAaiIgKiIgUgAkRyn5k4/RLBP6JEn8kYNE1V1T+goqAgBSACIAKiIgaiIAJEzjOMkPMdmT+iRP5ahh3JVKs/oCAGIAJEzRuXv7ligz+iRE707PytXWg/oKKgoqAiAqMgAiAEQQFxG7YhAAwECyAAIACTIQAMAwsCQCAEQeDbv4UESQ0ARBgtRFT7IRnARBgtRFT7IRlAIANBf0obIAKgIgYgBiAGIAaiIgKiIgYgAkRyn5k4/RLBP6JEn8kYNE1V1T+goqAgBiACIAKiIgWiIAJEzjOMkPMdmT+iRP5ahh3JVKs/oCAFIAJEzRuXv7ligz+iRE707PytXWg/oKKgoqC2IQAMAwtEAAAAAAAA8L9E0iEzf3zZEsBE0iEzf3zZEkAgA0F/ShsgAqAiBiAGIAYgBqIiAqIiBiACRHKfmTj9EsE/okSfyRg0TVXVP6CioCAGIAIgAqIiBaIgAkTOM4yQ8x2ZP6JE/lqGHclUqz+gIAUgAkTNG5e/uWKDP6JETvTs/K1daD+goqCioKO2IQAMAgsCQCAEQeSX24AESQ0ARBgtRFT7IQnARBgtRFT7IQlAIANBf0obIAKgIgYgBiAGIAaiIgKiIgYgAkRyn5k4/RLBP6JEn8kYNE1V1T+goqAgBiACIAKiIgWiIAJEzjOMkPMdmT+iRP5ahh3JVKs/oCAFIAJEzRuXv7ligz+iRE707PytXWg/oKKgoqC2IQAMAgtEAAAAAAAA8L9EGC1EVPsh+b9EGC1EVPsh+T8gA0F/ShsgAqAiBiAGIAYgBqIiAqIiBiACRHKfmTj9EsE/okSfyRg0TVXVP6CioCAGIAIgAqIiBaIgAkTOM4yQ8x2ZP6JE/lqGHclUqz+gIAUgAkTNG5e/uWKDP6JETvTs/K1daD+goqCioKO2IQAMAQsCQCAEQYCAgMwDSQ0AIAIgAqIiBiACoiIFIAZEcp+ZOP0SwT+iRJ/JGDRNVdU/oKIgAqAgBSAGIAaiIgKiIAZEzjOMkPMdmT+iRP5ahh3JVKs/oCACIAZEzRuXv7ligz+iRE707PytXWg/oKKgoqC2IQAMAQsgASAAQwAAgAOUIABDAACAe5IgBEGAgIAESRs4AgggASoCCBoLIAFBEGokgICAgAAgAAsKACAAENqAgIAAC7QCAwN/AX0CfCOAgICAAEEQayEBAkACQCAAvCICQf////8HcSIDQYCA8JcESw0AIANBgYCAmANPDQEgAEMAAIA/kg8LAkACQCADQYCAgPwHSw0AAkAgAkH///+XBEoNACACQQBODQMgAkH//9eYfEsNAiACQf//A3FFDQMgAUMBAACAIACVOAIMIAEqAgwaDAMLIABDAAAAf5QhAAsgAA8LIAFDAQAAgCAAlTgCDCABKgIMGkMAAAAADwsgAEMAAEBJkiIEvEEIaiIDQQ9xQQN0KwP4p8CAACIFIAAgBEMAAEDJkpO7IgZEAAAAAL6/zj+iRAAAAABDLuY/oCAFIAaiIgWioCAGRAAAAMDJsoM/okQAAACANGusP6AgBiAGoiAFoqKgIANBBHZB/wdqrUI0hr+itguvBAIEfwN9I4CAgIAAQRBrIQEgALwiAkEfdiEDAkACQAJAAkACQAJAAkAgAkH/////B3EiBEHQ2LqVBEkNAAJAIARBgICA/AdNDQAgAA8LAkAgBEGX5MWVBEsNACACQX9KDQIgAUMAAICAIACVOAIIIAEqAggaDAILAkAgAkF/Sg0AIAFDAACAgCAAlTgCCCABKgIIGkMAAAAAIQUgBEG047+WBE0NAgwHCyAAQwAAAH+UDwsCQCAEQZjkxfUDSw0AIARBgICAyANNDQJBACEEQwAAAAAhBiAAIQUMBQsgBEGSq5T8A00NAgsgAEM7qrg/lCADQQJ0KgL4qMCAAJL8ACEEDAILIAEgAEMAAAB/kjgCDCABKgIMGiAAQwAAgD+SDwsgA0EBcyADayEECyAAIASyIgVDAHIxv5SSIgAgBUOOvr81lCIGkyEFCyAAIAUgBSAFIAWUIgcgB0MVUjW7lEOPqio+kpSTIgeUQwAAAEAgB5OVIAaTkkMAAIA/kiEFIARFDQACQAJAAkACQCAEQf8ASg0AIARBgn9ODQMgBUMAAIAMlCEFIARBm35NDQEgBEHmAGohBAwDCyAFQwAAAH+UIQUgBEH+AUsNASAEQYF/aiEEDAILIAVDAACADJQhBSAEQbZ9IARBtn1LG0HMAWohBAwBCyAFQwAAAH+UIQUgBEH9AiAEQf0CSRtBgn5qIQQLIAUgBEEXdEGAgID8A2pBgICA/AdxvpQhBQsgBQsKACAAEN2AgIAAC24BBn4gACADQv////8PgyIFIAFC/////w+DIgZ+IgcgA0IgiCIIIAZ+IgYgBSABQiCIIgl+fCIFQiCGfCIKNwMAIAAgCCAJfiAFIAZUrUIghiAFQiCIhHwgCiAHVK18IAQgAX4gAyACfnx8NwMIC+YKBgF/AXwCfwF8AX8BfCOAgICAAEEQayIBJICAgIAAIAC7IQICQAJAIAC8IgNB/////wdxIgRB25+k+gNJDQACQCAEQdKn7YMESQ0AAkAgBEHW44iHBEkNAAJAAkACQAJAAkAgBEH////7B0sNACABQgA3AwgCQAJAIARB2p+k7gRLDQAgAiACRIPIyW0wX+Q/okQAAAAAAAA4Q6BEAAAAAAAAOMOgIgVEAAAAUPsh+b+ioCAFRGNiGmG0EFG+oqAhAiAF/AIhBAwBCyABIAQgBEEXdkHqfmoiBkEXdGu+uzkDACABQQEgAUEIakEBIAZBABDZgICAACEEAkAgA0EASA0AIAErAwghAgwBC0EAIARrIQQgASsDCJohAgsgBEEDcQ4EAgMEAQILIAAgAJMhAAwHCyACIAKiIgJEgV4M/f//37+iRAAAAAAAAPA/oCACIAKiIgVEQjoF4VNVpT+ioCACIAWiIAJEaVDu4EKT+T6iRCceD+iHwFa/oKKgtowhAAwGCyACIAIgAqIiBaIiByAFIAWioiAFRKdGO4yHzcY+okR058ri+QAqv6CiIAIgByAFRLL7bokQEYE/okR3rMtUVVXFv6CioKC2IQAMBQsgAiACoiICRIFeDP3//9+/okQAAAAAAADwP6AgAiACoiIFREI6BeFTVaU/oqAgAiAFoiACRGlQ7uBCk/k+okQnHg/oh8BWv6CioLYhAAwECyACIAKiIgUgApqiIgcgBSAFoqIgBUSnRjuMh83GPqJEdOfK4vkAKr+goiAHIAVEsvtuiRARgT+iRHesy1RVVcW/oKIgAqGgtiEADAMLAkAgBEHg27+FBEkNAEQYLURU+yEZwEQYLURU+yEZQCADQX9KGyACoCIFIAUgBaIiAqIiByACIAKioiACRKdGO4yHzcY+okR058ri+QAqv6CiIAUgByACRLL7bokQEYE/okR3rMtUVVXFv6CioKC2IQAMAwsCQCADQQBIDQAgAkTSITN/fNkSwKAiAiACoiICRIFeDP3//9+/okQAAAAAAADwP6AgAiACoiIFREI6BeFTVaU/oqAgAiAFoiACRGlQ7uBCk/k+okQnHg/oh8BWv6CioLaMIQAMAwsgAkTSITN/fNkSQKAiAiACoiICRIFeDP3//9+/okQAAAAAAADwP6AgAiACoiIFREI6BeFTVaU/oqAgAiAFoiACRGlQ7uBCk/k+okQnHg/oh8BWv6CioLYhAAwCCwJAIARB5JfbgARJDQBEGC1EVPshCcBEGC1EVPshCUAgA0F/ShsgAqAiBSAFoiICIAWaoiIHIAIgAqKiIAJEp0Y7jIfNxj6iRHTnyuL5ACq/oKIgByACRLL7bokQEYE/okR3rMtUVVXFv6CiIAWhoLYhAAwCCwJAIANBAEgNACACRBgtRFT7Ifm/oCICIAKiIgJEgV4M/f//37+iRAAAAAAAAPA/oCACIAKiIgVEQjoF4VNVpT+ioCACIAWiIAJEaVDu4EKT+T6iRCceD+iHwFa/oKKgtiEADAILIAJEGC1EVPsh+T+gIgIgAqIiAkSBXgz9///fv6JEAAAAAAAA8D+gIAIgAqIiBURCOgXhU1WlP6KgIAIgBaIgAkRpUO7gQpP5PqJEJx4P6IfAVr+goqC2jCEADAELAkAgBEGAgIDMA0kNACACIAKiIgUgAqIiByAFIAWioiAFRKdGO4yHzcY+okR058ri+QAqv6CiIAcgBUSy+26JEBGBP6JEd6zLVFVVxb+goiACoKC2IQAMAQsgASAAQwAAgAOUIABDAACAe5IgBEGAgIAESRs4AgggASoCCBoLIAFBEGokgICAgAAgAAsKACAAEOCAgIAAC6cBAAJAAkACQAJAIAFB/wBKDQAgAUGCf04NAyAAQwAAgAyUIQAgAUGbfk0NASABQeYAaiEBDAMLIABDAAAAf5QhACABQf4BSw0BIAFBgX9qIQEMAgsgAEMAAIAMlCEAIAFBtn0gAUG2fUsbQcwBaiEBDAELIABDAAAAf5QhACABQf0CIAFB/QJJG0GCfmohAQsgACABQRd0QYCAgPwDakGAgID8B3G+lAvCDAUBfQN/AX0EfwN9QwAAgD8hAgJAAkACQCAAvCIDQYCAgPwDRg0AIAG8IgRB/////wdxIgVFDQACQAJAAkAgAIsiBrwiB0GAgID8B0sNACAFQYCAgPwHSw0AIANBAE4NAUECIQggBUH////bBEsNAiAFQYCAgPwDSQ0BQQAhCCAFQZYBIAVBF3ZrIgl2IgogCXQgBUcNAkECIApBAXFrIQgMAgsgACABkg8LQQAhCAsCQAJAAkACQAJAIAVBgICA/ANGDQAgBUGAgID8B0cNAQJAAkAgB0GAgID8A0ogB0GAgID8A0hrQf8BcQ4CBwEAC0MAAAAAIAGMIARBf0obDwsgAUMAAAAAIARBf0obDwsgBEF/TA0BIAAPCwJAAkAgBEGAgID4A0YNACAEQYCAgIAERw0BIAAgAJQPCyADQX9KDQILAkACQAJAAkACQAJAIAdFDQAgB0H/////A3FBgICA/ANHDQELQwAAgD8gBpUgBiAEQQBIGyECIANBAE4NCCAHIAhqQYCAgPwDRw0BIAIgApMiACAAlQ8LQwAAgD8hCyADQQBODQMgCA4CAQIDCyACjCACIAhBAUYbDwsgACAAkyIAIACVDwtDAACAvyELCwJAIAVBgICA6ARLDQAgBkMAAIBLlLwgByAHQYCAgARJIgMbIghB////A3EiB0GAgID8A3IhBSAIQRd1Qel+QYF/IAMbaiEIQQAhAwJAIAdB8ojzAEkNAAJAIAdB1+f2Ak8NAEEBIQMMAQsgB0GAgID4A3IhBSAIQQFqIQgLIANBAnQiByoCiKnAgABDAACAPyAHKgKAqcCAACIAIAW+IgySlSICIAwgAJMiBiAFQQF2QYDg//8BcSADQRV0akGAgICCAmq+Ig0gBiAClCIGvEGAYHG+IgKUkyAAIA2TIAySIAKUk5QiACACIAKUIgxDAABAQJIgACAGIAKSlCAGIAaUIgAgAJQgACAAIAAgACAAQ0LxUz6UQ1UybD6SlEMFo4s+kpRDq6qqPpKUQ7dt2z6SlEOamRk/kpSSIg2SvEGAYHG+IgCUIAYgDSAAQwAAQMCSIAyTk5SSIgYgBiACIACUIgKSvEGAYHG+IgAgApOTQ084dj+UIABDxiP2uJSSkiICIAcqApCpwIAAIgYgAiAAQwBAdj+UIgySkiAIsiICkrxBgGBxviIAIAKTIAaTIAyTkyECDAMLAkAgB0H4///7A0kNAAJAIAdBh4CA/ANLDQAgBkMAAIC/kiIAQ3Cl7DaUIAAgAJRDAAAAPyAAIABDAACAvpRDq6qqPpKUk5RDO6q4v5SSIgIgAiAAQwCquD+UIgaSvEGAYHG+IgAgBpOTIQIMBAsCQCAEQQBKDQAgC0NgQqINlENgQqINlA8LIAtDyvJJcZRDyvJJcZQPCwJAIARBAEgNACALQ2BCog2UQ2BCog2UDwsgC0PK8klxlEPK8klxlA8LQwAAgD8gAJUPCyAAkQ8LAkACQAJAIAAgBEGAYHG+IgaUIgwgASAGkyAAlCABIAKUkiIBkiIAvCIFQYCAgJgESg0AIAVBgICAmARGDQEgALxB/////wdxIgNBgIDYmARLDQUgBUGAgNiYfEcNAiABIAAgDJNfRQ0CIAtDYEKiDZRDYEKiDZQPCyALQ8rySXGUQ8rySXGUDwsgAUM8qjgzkiAAIAyTXg0CIAC8Qf////8HcSEDC0EAIQQCQCADQYCAgPgDTQ0AQQBBgICABCADQRd2QQJqdiAFaiIDQf///wNxQYCAgARyQRYgA0EXdiIHa3YiBGsgBCAFQQBIGyEEIAEgDEGAgIB8IAdBAWp1IANxvpMiDJK8IQULAkACQCAEQRd0IAVBgIB+cb4iAEMAcjE/lCICIABDjL6/NZQgASAAIAyTk0MYcjE/lJIiBpIiACAAIAAgACAAlCIBIAEgASABIAFDTLsxM5RDDurdtZKUQ1WzijiSlENhCza7kpRDq6oqPpKUkyIBlCABQwAAAMCSlSAGIAAgApOTIgEgACABlJKTk0MAAIA/kiIAvGoiBUGAgIAESA0AIAW+IQAMAQsgACAEEOKAgIAAIQALIAsgAJQhAgsgAg8LIAtDyvJJcZRDyvJJcZQPCyALQ2BCog2UQ2BCog2UCwwAIAAgARDjgICAAAvWCgYBfwF8An8BfAF/AXwjgICAgABBEGsiASSAgICAACAAuyECAkACQAJAAkAgALwiA0H/////B3EiBEHbn6T6A0kNAAJAIARB0qftgwRJDQACQCAEQdbjiIcESQ0AAkACQAJAAkACQCAEQf////sHSw0AIAFCADcDCAJAAkAgBEHan6TuBEsNACACIAJEg8jJbTBf5D+iRAAAAAAAADhDoEQAAAAAAAA4w6AiBUQAAABQ+yH5v6KgIAVEY2IaYbQQUb6ioCECIAX8AiEEDAELIAEgBCAEQRd2Qep+aiIGQRd0a767OQMAIAFBASABQQhqQQEgBkEAENmAgIAAIQQCQCADQQBIDQAgASsDCCECDAELQQAgBGshBCABKwMImiECCyAEQQNxDgQCAwQBAgsgACAAkyEADAkLIAIgAiACoiIFoiIHIAUgBaKiIAVEp0Y7jIfNxj6iRHTnyuL5ACq/oKIgAiAHIAVEsvtuiRARgT+iRHesy1RVVcW/oKKgoLYhAAwICyACIAKiIgJEgV4M/f//37+iRAAAAAAAAPA/oCACIAKiIgVEQjoF4VNVpT+ioCACIAWiIAJEaVDu4EKT+T6iRCceD+iHwFa/oKKgtiEADAcLIAIgAqIiBSACmqIiByAFIAWioiAFRKdGO4yHzcY+okR058ri+QAqv6CiIAcgBUSy+26JEBGBP6JEd6zLVFVVxb+goiACoaC2IQAMBgsgAiACoiICRIFeDP3//9+/okQAAAAAAADwP6AgAiACoiIFREI6BeFTVaU/oqAgAiAFoiACRGlQ7uBCk/k+okQnHg/oh8BWv6CioLaMIQAMBQsgBEHf27+FBEsNAgJAIANBf0wNACACRNIhM3982RLAoCIFIAUgBaIiAqIiByACIAKioiACRKdGO4yHzcY+okR058ri+QAqv6CiIAUgByACRLL7bokQEYE/okR3rMtUVVXFv6CioKC2IQAMBQtE0iEzf3zZEsAgAqEiBSAFIAWiIgKiIgcgAiACoqIgAkSnRjuMh83GPqJEdOfK4vkAKr+goiAFIAcgAkSy+26JEBGBP6JEd6zLVFVVxb+goqCgtiEADAQLIARB45fbgARLDQICQCADQX9MDQBEGC1EVPsh+T8gAqEiBSAFIAWiIgKiIgcgAiACoqIgAkSnRjuMh83GPqJEdOfK4vkAKr+goiAFIAcgAkSy+26JEBGBP6JEd6zLVFVVxb+goqCgtiEADAQLIAJEGC1EVPsh+T+gIgUgBSAFoiICoiIHIAIgAqKiIAJEp0Y7jIfNxj6iRHTnyuL5ACq/oKIgBSAHIAJEsvtuiRARgT+iRHesy1RVVcW/oKKgoLYhAAwDCwJAIARBgICAzANJDQAgAiACoiICRIFeDP3//9+/okQAAAAAAADwP6AgAiACoiIFREI6BeFTVaU/oqAgAiAFoiACRGlQ7uBCk/k+okQnHg/oh8BWv6CioLYhAAwDCyABIABDAACAe5I4AgggASoCCBpDAACAPyEADAILRBgtRFT7IRnARBgtRFT7IRlAIANBf0obIAKgIgIgAqIiAkSBXgz9///fv6JEAAAAAAAA8D+gIAIgAqIiBURCOgXhU1WlP6KgIAIgBaIgAkRpUO7gQpP5PqJEJx4P6IfAVr+goqC2IQAMAQtEGC1EVPshCcBEGC1EVPshCUAgA0F/ShsgAqAiAiACoiICRIFeDP3//9+/okQAAAAAAADwP6AgAiACoiIFREI6BeFTVaU/oqAgAiAFoiACRGlQ7uBCk/k+okQnHg/oh8BWv6CioLaMIQALIAFBEGokgICAgAAgAAsKACAAEOWAgIAACwuiKQEAQYCAwAALmCkWc2xpY2UgaW5kZXggc3RhcnRzIGF0IMANIGJ1dCBlbmRzIGF0IMAAIGluZGV4IG91dCBvZiBib3VuZHM6IHRoZSBsZW4gaXMgwBIgYnV0IHRoZSBpbmRleCBpcyDAABJyYW5nZSBzdGFydCBpbmRleCDAIiBvdXQgb2YgcmFuZ2UgZm9yIHNsaWNlIG9mIGxlbmd0aCDAABByYW5nZSBlbmQgaW5kZXggwCIgb3V0IG9mIHJhbmdlIGZvciBzbGljZSBvZiBsZW5ndGggwAAkbWluID4gbWF4LCBvciBlaXRoZXIgd2FzIE5hTi4gbWluID0gwAgsIG1heCA9IMAAEGFzc2VydGlvbiBgbGVmdCDAFyByaWdodGAgZmFpbGVkCiAgbGVmdDogwAkKIHJpZ2h0OiDAAC9ydXN0Yy8yZDgxNDRiNzg4MDU5N2I2ZTZkM2RmZDYzYTlhOWVmYWUzZjUzM2QzL2xpYnJhcnkvY29yZS9zcmMvbnVtL2ltcC9mbHQyZGVjL3N0cmF0ZWd5L2dyaXN1LnJzAC9ydXN0Yy8yZDgxNDRiNzg4MDU5N2I2ZTZkM2RmZDYzYTlhOWVmYWUzZjUzM2QzL2xpYnJhcnkvY29yZS9zcmMvbnVtL2ltcC9kaXlfZmxvYXQucnMAc3JjL2RydW1zLnJzAC9ydXN0Yy8yZDgxNDRiNzg4MDU5N2I2ZTZkM2RmZDYzYTlhOWVmYWUzZjUzM2QzL2xpYnJhcnkvc3RkL3NyYy9zeXMvc3luYy9yd2xvY2svbm9fdGhyZWFkcy5ycwAvcnVzdGMvMmQ4MTQ0Yjc4ODA1OTdiNmU2ZDNkZmQ2M2E5YTllZmFlM2Y1MzNkMy9saWJyYXJ5L2NvcmUvc3JjL251bS9pbXAvZmx0MmRlYy9zdHJhdGVneS9kcmFnb24ucnMAL3J1c3RjLzJkODE0NGI3ODgwNTk3YjZlNmQzZGZkNjNhOWE5ZWZhZTNmNTMzZDMvbGlicmFyeS9jb3JlL3NyYy9udW0vaW1wL2JpZ251bS5ycwBzcmMvb3ZlcnNhbXBsZS5ycwAvcnVzdGMvMmQ4MTQ0Yjc4ODA1OTdiNmU2ZDNkZmQ2M2E5YTllZmFlM2Y1MzNkMy9saWJyYXJ5L2FsbG9jL3NyYy9yYXdfdmVjL21vZC5ycwAvcnVzdGMvMmQ4MTQ0Yjc4ODA1OTdiNmU2ZDNkZmQ2M2E5YTllZmFlM2Y1MzNkMy9saWJyYXJ5L2NvcmUvc3JjL251bS9pbXAvZmx0MmRlYy9tb2QucnMAL3J1c3QvZGVwcy9kbG1hbGxvYy0wLjIuMTMvc3JjL2RsbWFsbG9jLnJzAC9ydXN0Yy8yZDgxNDRiNzg4MDU5N2I2ZTZkM2RmZDYzYTlhOWVmYWUzZjUzM2QzL2xpYnJhcnkvY29yZS9zcmMvbnVtL2YzMi5ycwASAxAAEQAAAG0AAAAJAAAAEgMQABEAAABuAAAACQAAAPgDEABLAAAAHQYAAAkAAAASAxAAEQAAAHQAAAASAAAAEgMQABEAAADJAAAAFgAAAPABEAAMAAAAewEAABsAAADwARAADAAAAKIBAAAdAAAA8AEQAAwAAAAbAgAAGQAAAPABEAAMAAAA2gMAACoAAADwARAADAAAAN8DAAAeAAAA8AEQAAwAAADgAwAAEgAAAPABEAAMAAAA4AMAAAkAAADwARAADAAAAAUEAAASAAAA8AEQAAwAAABLBAAAFAAAAPABEAAMAAAAzAAAACsAAAAAAEBAZmbmP2ZmZkDNzCzAZmYmQM3MLEAAACBAAAAgQM3MjD/NzCxAZmaWQM3MzL3NzMw/MzNTwM3MjD/NzIw/MzMTQM3MTECamRk/ZmYmQDMz87/NzAxAzczMvpqZmb7wARAADAAAAFkAAAARAAAAAAECAwRjYXBhY2l0eSBvdmVyZmxvdwAAJAMQAFAAAAAcAAAABQAAADAxMjM0NTY3ODlhYmNkZWYAAAAABAAAAAQAAAAFAAAALStOYU5pbmYwMC4wZTBhc3NlcnRpb24gZmFpbGVkOiBidWYubGVuKCkgPj0gbWF4bGVuAHUDEABXAAAAiwIAAA0AAACaARAAVQAAAC4AAAAJAAAAYXNzZXJ0aW9uIGZhaWxlZDogb3RoZXIgPiAwYXNzZXJ0aW9uIGZhaWxlZDogbm9ib3Jyb3cAAAC/AhAAUgAAAIQBAAABAAAAYXNzZXJ0aW9uIGZhaWxlZDogZGlnaXRzIDwgNDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwPT0wMDAxMDIwMzA0MDUwNjA3MDgwOTEwMTExMjEzMTQxNTE2MTcxODE5MjAyMTIyMjMyNDI1MjYyNzI4MjkzMDMxMzIzMzM0MzUzNjM3MzgzOTQwNDE0MjQzNDQ0NTQ2NDc0ODQ5NTA1MTUyNTM1NDU1NTY1NzU4NTk2MDYxNjI2MzY0NjU2NjY3Njg2OTcwNzE3MjczNzQ3NTc2Nzc3ODc5ODA4MTgyODM4NDg1ODY4Nzg4ODk5MDkxOTI5Mzk0OTU5Njk3OTg5OS5hdHRlbXB0IHRvIGRpdmlkZSBieSB6ZXJvYXNzZXJ0aW9uIGZhaWxlZDogIWJ1Zi5pc19lbXB0eSgpAAB1AxAAVwAAALcAAAAFAAAAYXNzZXJ0aW9uIGZhaWxlZDogYnVmWzBdID4gYicwJwB1AxAAVwAAALgAAAAFAAAAdQMQAFcAAAAJAQAABQAAAHUDEABXAAAACgEAAAUAAABlZS0A30UaPQPPGubB+8z+AAAAAMrGmscX/nCr3PvU/gAAAABP3Ly+/LF3//b73P4AAAAADNZrQe+RVr4R/OT+AAAAADz8f5CtH9CNLPzs/gAAAACDmlUxKFxR00b89P4AAAAAtcmmrY+scZ1h/Pz+AAAAAMuL7iN3Ipzqe/wE/wAAAABtU3hAkUnMrpb8DP8AAAAAV862XXkSPIKx/BT/AAAAADdW+002lBDCy/wc/wAAAABPmEg4b+qWkOb8JP8AAAAAxzqCJcuFdNcA/Sz/AAAAAPSXv5fNz4agG/00/wAAAADlrCoXmAo07zX9PP8AAAAAjrI1KvtnOLJQ/UT/AAAAADs/xtLf1MiEa/1M/wAAAAC6zdMaJ0TdxYX9VP8AAAAAlsklu86fa5Og/Vz/AAAAAISlYn0kbKzbuv1k/wAAAAD22l8NWGaro9X9bP8AAAAAJvHD3pP44vPv/XT/AAAAALiA/6qorbW1Cv58/wAAAACLSnxsBV9ihyX+hP8AAAAAUzDBNGD/vMk//oz/AAAAAFUmupGMhU6WWv6U/wAAAAC9filwJHf533T+nP8AAAAAj7jluJ+936aP/qT/AAAAAJR9dIjPX6n4qf6s/wAAAADPm6iPk3BEucT+tP8AAAAAaxUPv/jwCIrf/rz/AAAAALYxMWVVJbDN+f7E/wAAAACsf3vQxuI/mRT/zP8AAAAABjsrKsQQXOQu/9T/AAAAANOSc2mZJCSqSf/c/wAAAAAOygCD8rWH/WP/5P8AAAAA6xoRkmQI5bx+/+z/AAAAAMyIUG8JzLyMmf/0/wAAAAAsZRniWBe30bP//P8AAAAAAAAAAAAAQJzO/wQAAAAAAAAAAAAQpdTo6P8MAAAAAAAAAGKsxet4rQMAFAAAAAAAhAmU+Hg5P4EeABwAAAAAALMVB8l7zpfAOAAkAAAAAABwXOp7zjJ+j1MALAAAAAAAaIDpq6Q40tVtADQAAAAAAEUimhcmJ0+fiAA8AAAAAAAn+8TUMaJj7aIARAAAAAAAqK3IjDhl3rC9AEwAAAAAANtlqxqOCMeD2ABUAAAAAACaHXFC+R1dxPIAXAAAAAAAWOcbpixpTZINAWQAAAAAAOqNcBpk7gHaJwFsAAAAAABKd++amaNtokIBdAAAAAAAhWt9tHt4CfJcAXwAAAAAAHcY3Xmh5FS0dwGEAAAAAADCxZtbkoZbhpIBjAAAAAAAPV2WyMVTNcisAZQAAAAAALOgl/pctCqVxwGcAAAAAADjX6CZvZ9G3uEBpAAAAAAAJYw52zTCm6X8AawAAAAAAFyfmKNymsb2FgK0AAAAAADOvulUU7/ctzECvAAAAAAA4kEi8hfz/IhMAsQAAAAAAKV4XNObziDMZgLMAAAAAADfUyF781oWmIEC1AAAAAAAOjAfl9y1oOKbAtwAAAAAAJaz41xT0dmotgLkAAAAAAA8RKek2Xyb+9AC7AAAAAAAEESkp0xMdrvrAvQAAAAAABqcQLbvjquLBgP8AAAAAAAshFemEO8f0CADBAEAAAAAKTGR6eWkEJs7AwwBAAAAAJ0MnKH7mxDnVQMUAQAAAAAp9Dti2SAorHADHAEAAAAAhc+nel5LRICLAyQBAAAAAC3drANA5CG/pQMsAQAAAACP/0ReL5xnjsADNAEAAAAAQbiMnJ0XM9TaAzwBAAAAAKkb47SS2xme9QNEAQAAAADZd9+6br+W6w8ETAEAAAAAYXNzZXJ0aW9uIGZhaWxlZDogZC5tYW50ID4gMDcBEABiAAAA3gEAAAUAAAA3ARAAYgAAAH8AAAAVAAAANwEQAGIAAAA1AgAAEQAAADcBEABiAAAAbgIAAAkAAAA3ARAAYgAAAKsAAAAFAAAAYXNzZXJ0aW9uIGZhaWxlZDogZC5taW51cyA+IDAAAAA3ARAAYgAAAKwAAAAFAAAAYXNzZXJ0aW9uIGZhaWxlZDogZC5wbHVzID4gMDcBEABiAAAArQAAAAUAAABhc3NlcnRpb24gZmFpbGVkOiBkLm1hbnQgKyBkLnBsdXMgPCAoMSA8PCA2MSkAAAA3ARAAYgAAALEAAAAFAAAANwEQAGIAAAAMAQAAEQAAADcBEABiAAAAQgEAAAkAAABhc3NlcnRpb24gZmFpbGVkOiBkLm1hbnQuY2hlY2tlZF9zdWIoZC5taW51cykuaXNfc29tZSgpADcBEABiAAAArwAAAAUAAABhc3NlcnRpb24gZmFpbGVkOiBkLm1hbnQuY2hlY2tlZF9hZGQoZC5wbHVzKS5pc19zb21lKCkAADcBEABiAAAArgAAAAUAAABbAhAAYwAAAHQBAAAkAAAAWwIQAGMAAAB5AQAALwAAAFsCEABjAAAAhgEAABIAAABbAhAAYwAAAGgBAAANAAAAWwIQAGMAAABOAQAAIgAAAFsCEABjAAAAeAAAAAUAAABbAhAAYwAAAHkAAAAFAAAAWwIQAGMAAAB6AAAABQAAAFsCEABjAAAAxAAAAAkAAABbAhAAYwAAAP0AAAANAAAAWwIQAGMAAAAEAQAAEgAAAFsCEABjAAAAfAAAAAUAAABbAhAAYwAAAHsAAAAFAAAAAQAAAAoAAABkAAAA6AMAABAnAACghgEAQEIPAICWmAAA4fUFAMqaO8Fv8oYjAAAAge+shVtBbS3uBAAAAR9qv2TtOG7tl6fa9Pk/6QNPGAABPpUuCZnfA/04FQ8v5HQj7PXP0wjcBMTasM28GX8zpgMmH+lOAgAAAXwumFuH075yn9nYhy8VEsZQ3mtwbkrPD9iV1W5xsiawZsatJDYVHVrTQjwOVP9jwHNVzBfv+WXyKLxV98fcgNztbvTO79xf91MFADcBEABiAAAA8QIAACYAAAA3ARAAYgAAAOUCAAAmAAAANwEQAGIAAADOAgAAJgAAADB4MDEyMzQ1Njc4OUFCQ0RFRgAABgAAAAwAAAAEAAAABwAAAAgAAAAJAAAAAAAAAAgAAAAEAAAACgAAAAsAAAAMAAAADQAAAA4AAAAQAAAABAAAAA8AAAAQAAAAEQAAABIAAABc9ulf3AL2ufHBcGzyYcEkSv4MNHFP91/fOOR5Jf4cdGFzc2VydGlvbiBmYWlsZWQ6IHBzaXplID49IHNpemUgKyBtaW5fb3ZlcmhlYWQAAM0DEAAqAAAAsQQAAAkAAABhc3NlcnRpb24gZmFpbGVkOiBwc2l6ZSA8PSBzaXplICsgbWF4X292ZXJoZWFkAADNAxAAKgAAALcEAAANAAAAcndsb2NrIG92ZXJmbG93ZWQgcmVhZCBsb2Nrc/0BEABdAAAAFQAAACwAAAAAAAAACAAAAAQAAAATAAAABgAAAAwAAAAEAAAAFAAAAHJ3bG9jayBoYXMgbm90IGJlZW4gbG9ja2VkIGZvciByZWFkaW5nAAD9ARAAXQAAAD4AAAAJAAAACwAAAAUAAAAGAAAAAQAAAAEAAAA0BRAAYAUQAHQFEACMBRAAkAUQAAsAAAAFAAAABgAAABAAAAALAAAAAwAAAAQAAAAEAAAABgAAAIP5ogBETm4A/CkVANFXJwDdNPUAYtvAADyZlQBBkEMAY1H+ALveqwC3YcUAOm4kANJNQgBJBuAACeouAByS0QDrHf4AKbEcAOg+pwD1NYIARLsuAJzphAC0JnAAQX5fANaROQBTgzkAnPQ5AItfhAAo+b0A+B87AN7/lwAPmAUAES/vAApaiwBtH20Az342AAnLJwBGT7cAnmY/AC3qXwC6J3UA5evHAD178QD3OQcAklKKAPtr6gAfsV8ACF2NADADVgB7/EYA8KtrACC8zwA29JoA46kdAF5hkQAIG+YAhZllAKAUXwCNQGgAgNj/ACdzTQAGBjEAylYVAMmocwB74mAAa4zAAAAAAED7Ifk/AAAAAC1EdD4AAACAmEb4PAAAAGBRzHg7AAAAgIMb8DkAAABAICV6OAAAAIAiguM2AAAAAB3zaTXNO39mnqDmP4cB63MUoec/26AqQuWs6D+Q8KOCkcTpP63TWpmf6Oo/nFKF3ZsZ7D+HpPvcGFjtP9qQpKKvpO4/AAAAAAAA8D8PiflsWLXwP3tRfTy4cvE/OGJ1bno48j8VtzEK/gbzPyI0Ekym3vM/Jyo21dq/9D8pVEjdB6v1PwAAAD8AAAC/AACAPwAAwD8AAAAA3M/RNQAAAAAAwBU/", zr, Br, Vr = !1;
function Hr() {
	return Br ??= (async () => {
		let e = Uint8Array.from(atob(Rr.slice(Rr.indexOf(",") + 1)), (e) => e.charCodeAt(0));
		zr = await WebAssembly.compile(e);
	})().catch((e) => {
		Br = void 0, Vr || (Vr = !0, console.warn("Rackloose DSP unavailable, so Ladder filters and Analog drums play Digital:", e));
	}), Br;
}
var Ur = () => zr, Wr = [
	Fr,
	Ir,
	Lr
].map((e) => ({
	source: e,
	contexts: /* @__PURE__ */ new WeakMap()
}));
async function Gr(e) {
	await Promise.all([Hr(), ...Wr.map(({ source: t, contexts: n }) => {
		let r = n.get(e);
		if (!r) {
			let i = URL.createObjectURL(new Blob([t], { type: "text/javascript" }));
			r = e.audioWorklet.addModule(i).finally(() => URL.revokeObjectURL(i)), n.set(e, r), r.catch(() => n.delete(e));
		}
		return r;
	})]);
}
function Kr(e, t, n, r) {
	let i = 0, a = !1, o, s = /* @__PURE__ */ new Map(), c = (e) => {
		for (let t of s.values()) clearTimeout(t.timer), e ? t.reject(e) : t.resolve();
		s.clear();
	};
	return e.port.onmessage = ({ data: e }) => {
		if (a) return;
		typeof e.reduction == "number" && Number.isFinite(e.reduction) && n?.(e.reduction);
		let t = e.id === void 0 ? void 0 : s.get(e.id);
		t && (clearTimeout(t.timer), t.resolve(), s.delete(e.id));
	}, e.onprocessorerror = () => {
		a || (o = /* @__PURE__ */ Error(`${t} audio processor failed. Reload the patch to retry.`), c(o), r?.(o));
	}, {
		flush() {
			return o ? Promise.reject(o) : a ? Promise.resolve() : new Promise((n, r) => {
				let a = ++i, o = setTimeout(() => {
					s.delete(a), r(/* @__PURE__ */ Error(`${t} did not finish preparing audio. Try again.`));
				}, 5e3);
				s.set(a, {
					resolve: n,
					reject: r,
					timer: o
				}), e.port.postMessage({
					type: "flush",
					id: a
				});
			});
		},
		dispose() {
			a || (a = !0, e.port.postMessage({ type: "dispose" }), c(), e.port.onmessage = null, e.onprocessorerror = null, e.port.close());
		}
	};
}
// src/audio/drumEngine.ts
var qr = {
	boom: 0,
	punch: 1,
	orbit: 2,
	strike: 3,
	forge: 4
}, Jr = {
	boom: [["open", "hat"]],
	punch: [["open", "hat"]],
	strike: [["open", "hat"]],
	forge: [["open", "hat"], ["open", "pedal"]]
}, Yr = (e) => 2 ** (e / 12), Xr = 8;
function Zr(e, t, n, r) {
	let i = Qr(e, t, n, r);
	return Array.from({ length: Xr }, (e, r) => r === 7 ? n[`${t}Pan`] ?? 0 : i[r] ?? 0);
}
function Qr(e, t, n, r) {
	if (e === "orbit") return [
		Yr(n.pitch + n[`${t}Tune`]),
		n[`${t}Decay`],
		Math.min(1, n[`${t}Level`]),
		n[`${t}Tone`]
	];
	if (r) {
		let e = Yr(n[`${t}Tune`]), i = r.sample(t).length / (r.rate * e), a = Math.min(2e4, (r.tone ?? ((e) => 700 * 20 ** e))(n[`${t}Tone`]));
		return [
			r.rate * e,
			n[`${t}Decay`],
			a,
			n[`${t}Level`] * (r.peak ?? 1.6),
			Math.min(i, n[`${t}Decay`] * 2) + .01
		];
	}
	return t === "kick" ? e === "punch" ? [
		n.kickTune,
		n.kickDecay,
		n.kickClick
	] : [n.kickTune, n.kickDecay] : t === "snare" ? [
		n.snareTone,
		n.snappy,
		Yr(n.snareTune),
		n.snareDecay
	] : t === "rim" ? [Yr(n.rimTune), n.rimDecay] : t === "clap" ? [J(n.clapTone, 3), n.clapDecay] : t === "lowTom" ? [95 * Yr(n.tomTune), n.tomDecay] : t === "highTom" ? [145 * Yr(n.highTomTune), n.highTomDecay * .85] : t === "bell" ? [Yr(n.bellTune), n.bellDecay] : [n[`${t}Decay`], J(n[`${t}Tone`], 2)];
}
function $r(e, t, n) {
	let r = n[`${t}Level`] ?? 1;
	return e === "boom" || e === "punch" ? r : e === "orbit" ? Math.max(1, r) : 1;
}
function ei(e, t, n, { keep: r, onError: i }) {
	let a = Ur();
	if (!a) return null;
	let o = Y[t].drum.voices.map((e) => e.id), s = t === "strike" ? Sr : t === "forge" ? Nr : void 0, c = (Jr[t] ?? []).map(([e, t]) => [o.indexOf(e), o.indexOf(t)]), l;
	try {
		l = r(new AudioWorkletNode(e, "rackloose-drums-v1", {
			numberOfInputs: 0,
			numberOfOutputs: 1,
			outputChannelCount: [2],
			processorOptions: {
				module: a,
				kit: qr[t],
				chokes: c
			}
		}));
	} catch (e) {
		return console.warn(`${Y[t].name} Analog engine unavailable, so it plays Digital:`, e), null;
	}
	l.connect(n);
	let u = Kr(l, Y[t].name, void 0, i), d = /* @__PURE__ */ new Set();
	return {
		trigger(e, n, r, i = 1) {
			let a = o.indexOf(e);
			a < 0 || (s && !d.has(e) && (d.add(e), l.port.postMessage({
				type: "sample",
				voice: a,
				pcm: s.sample(e)
			})), l.port.postMessage({
				type: "hit",
				time: n,
				voice: a,
				velocity: i * $r(t, e, r),
				params: Zr(t, e, r, s)
			}));
		},
		cancelScheduled(e) {
			l.port.postMessage({
				type: "cancel",
				time: e
			});
		},
		dispose: u.dispose,
		flush: u.flush
	};
}
function ti(e, t, n, r, i) {
	let a, o, s = i?.input ?? n, c = () => a ??= i ? i.classic() : t === "strike" ? Cr(e, s) : vr(e, t, s, r), l = () => o === void 0 ? o = ei(e, t, s, r) : o;
	return {
		trigger(e, t, n, r) {
			(n.engine === 1 ? l() ?? c() : c()).trigger(e, t, n, r);
		},
		cancelScheduled(e) {
			a?.cancelScheduled(e), o?.cancelScheduled(e);
		},
		dispose() {
			a?.dispose(), o?.dispose(), i?.dispose();
		},
		flush: () => o?.flush() ?? Promise.resolve()
	};
}
// src/audio/envelope.ts
function ni(e) {
	let t = [], n = (e) => {
		let n = t.findIndex(([t]) => t > e);
		if (n === 0 || !t.length) return 0;
		if (n < 0) return t[t.length - 1][1];
		let [r, i] = t[n - 1], [a, o] = t[n];
		return i + (o - i) * (e - r) / (a - r);
	}, r = (r, ...i) => {
		let a = n(r);
		hr(e, r), e.setValueAtTime(a, r);
		for (let [t, n] of i) e.linearRampToValueAtTime(n, t);
		t = [
			...t.filter(([e]) => e < r).slice(-16),
			[r, a],
			...i
		];
	};
	return {
		on(e, t, n, i, a) {
			r(e, [e + n, t], [e + n + i, t * a]);
		},
		off(e, t) {
			r(e, [e + t, 0]);
		}
	};
}
// src/audio/ladder.ts
function ri(e, { keep: t, onError: n, name: r }, i, a, o = []) {
	let s = t(e.createGain());
	s.gain.value = 0, s.connect(a);
	let c, l, u = !1, d = () => {
		let a = Ur();
		if (c || u || !a) return !!c;
		try {
			c = t(new AudioWorkletNode(e, "rackloose-ladder-v1", {
				numberOfInputs: 1,
				numberOfOutputs: 1,
				outputChannelCount: [1],
				processorOptions: { module: a }
			}));
		} catch (e) {
			return u = !0, console.warn(`${r} Ladder filter unavailable, so it plays Digital:`, e), !1;
		}
		for (let e of o) e.connect(c.parameters.get("detune"));
		return i.connect(c).connect(s), l = Kr(c, r, void 0, n), !0;
	};
	return {
		apply(t, n, r) {
			let i = t && d();
			if (r(s.gain, i ? n.level : 0), c) {
				let t = (e) => c.parameters.get(e);
				r(t("cutoff"), n.cutoff), r(t("resonance"), n.resonance), r(t("drive"), n.drive), r(t("detune"), n.detune ?? 0);
				let i = t("mode"), a = e.currentTime;
				i.cancelScheduledValues(a), i.setValueAtTime(n.mode ?? 0, a);
			}
			return i;
		},
		flush: () => l?.flush() ?? Promise.resolve(),
		dispose: () => l?.dispose()
	};
}
// src/audio/monarch.ts
var ii = [
	"sine",
	"triangle",
	"sawtooth",
	"square"
], ai = 1.4, oi = (e) => {
	let t = 1 + e * 5;
	return t / Math.tanh(t) / Math.sqrt(8 ** e);
};
function si(e, t, { keep: n, source: r, onError: i }) {
	let a = (t = 1) => {
		let r = n(e.createGain());
		return r.gain.value = t, r;
	}, o = a(), s = a(), c = a(), l = n(e.createWaveShaper()), u = n(e.createBiquadFilter());
	u.type = "lowpass", u.Q.value = .5, o.connect(u);
	let d = [n(e.createBiquadFilter()), n(e.createBiquadFilter())], f = a(0), p = a(), m = a(.5), h = a(), g = a();
	c.connect(l).connect(d[0]).connect(d[1]).connect(g).connect(f).connect(p);
	let _ = ri(e, {
		keep: n,
		onError: i,
		name: "MONARCH"
	}, c, f, [
		s,
		h,
		m
	]), v = r(e.createConstantSource()), y = r(e.createConstantSource());
	v.offset.value = 0, y.offset.value = 0, v.connect(f.gain), y.connect(h), u.connect(m);
	for (let e of d) e.type = "lowpass", s.connect(e.detune), h.connect(e.detune), m.connect(e.detune);
	let b = [
		1,
		2,
		3
	].map(() => {
		let t = r(e.createOscillator()), n = a();
		return t.frequency.value = 261.625565, t.connect(n).connect(c), u.connect(t.detune), {
			osc: t,
			level: n
		};
	}), x = r(e.createBufferSource()), S = a(0);
	x.buffer = t, x.loop = !0, x.connect(S).connect(c);
	let C = {}, w = !1, T = -1, E = (t, n) => {
		w ? t.setTargetAtTime(n, e.currentTime, .008) : t.value = n;
	}, ee = [[ni(v.offset), "amp"], [ni(y.offset), "filter"]];
	return {
		pitch: o,
		cv: s,
		output: p,
		apply(t) {
			C = t, b.forEach(({ osc: e, level: n }, r) => {
				let i = `osc${r + 1}`;
				e.type = ii[t[`${i}Wave`]], E(e.detune, t[`${i}Octave`] * 1200 + t[`${i}Detune`]), E(n.gain, t[`${i}Level`] * .23);
			}), E(S.gain, t.noise * .15), E(p.gain, t.level), E(u.frequency, t.glide ? Math.min(e.sampleRate * .45, 1 / (2 * Math.PI * t.glide)) : e.sampleRate * .45), E(m.gain, t.tracking), E(h.gain, t.envAmount * 4800), d.forEach((e, n) => {
				E(e.frequency, t.cutoff), E(e.Q, n === 0 ? .707 + t.resonance * 5 : .707);
			});
			let n = _.apply(t.filterModel === 1, {
				cutoff: t.cutoff,
				resonance: t.resonance,
				drive: t.drive,
				level: ai * oi(t.drive)
			}, E);
			if (E(g.gain, +!n), T !== t.drive) {
				T = t.drive;
				let e = 1 + t.drive * 5;
				l.curve = Float32Array.from({ length: 2049 }, (t, n) => Math.tanh(e * (n / 1024 - 1)) / Math.tanh(e)), l.oversample = "2x";
			}
			w = !0;
		},
		noteOn(e, t) {
			for (let [n, r] of ee) n.on(t, e, C[`${r}Attack`], C[`${r}Decay`], C[`${r}Sustain`]);
		},
		noteOff(e) {
			for (let [t, n] of ee) t.off(e, C[`${n}Release`]);
		},
		flush: _.flush,
		dispose: _.dispose
	};
}
// src/audio/oracle.ts
var ci = .25, li = .98, ui = [
	[
		4,
		-3,
		70
	],
	[
		-5,
		2,
		-40
	],
	[
		1,
		6,
		110
	],
	[
		-2,
		-6,
		-90
	],
	[
		6,
		1,
		20
	]
], di = 261.625565;
function fi(e, t, { keep: n, source: r, onError: i }) {
	let a = (t = 1) => {
		let r = n(e.createGain());
		return r.gain.value = t, r;
	}, o = (t = 0) => {
		let n = r(e.createConstantSource());
		return n.offset.value = t, n;
	}, s = (e) => Float32Array.from({ length: 1025 }, (t, n) => Math.tanh(e * (n / 512 - 1)) / Math.tanh(e)), c = (t, r, i) => {
		let a = n(e.createWaveShaper());
		return a.curve = s(24), a.oversample = "4x", t.connect(a), r.connect(a), Tr(a, i);
	}, l = a(), u = a(), d = a(.5), f = a(), p = n(e.createBiquadFilter());
	p.type = "highpass", p.frequency.value = 20, p.Q.value = -3.01, d.connect(p).connect(f);
	let m = r(e.createBufferSource()), h = a(0);
	m.buffer = t, m.loop = !0, m.connect(h);
	let g = r(e.createOscillator()), _ = a(0), v = a(0), y = a(0);
	g.connect(_), g.connect(v), g.connect(y);
	let b = ui.map((t) => {
		let s = o(), f = o(), p = o(), m = o(), g = o(), b = r(e.createOscillator()), x = r(e.createOscillator());
		b.type = "sawtooth", b.frequency.value = di, x.frequency.value = di;
		let S = a(), C = a(0), w = a(), T = a(), E = a(), ee = a(0), te = a(), ne = a();
		b.connect(S).connect(w), C.connect(w);
		let D = c(b, m, C);
		x.connect(E).connect(te), ee.connect(te);
		let re = c(x, g, ee), O = a(), k = a(0), ie = a(), A = [n(e.createBiquadFilter()), n(e.createBiquadFilter())];
		w.connect(T).connect(O), te.connect(ne).connect(O), h.connect(O), O.connect(A[0]).connect(A[1]).connect(ie).connect(k).connect(d), f.connect(k.gain);
		let ae = a(), oe = a(), se = a(0), ce = a(0), le = a(), ue = a(0), de = a(0);
		p.connect(oe), p.connect(se).connect(le), te.connect(ce).connect(le), le.connect(ue).connect(b.detune), le.connect(de);
		for (let e of [b.detune, x.detune]) s.connect(e), l.connect(e), _.connect(e);
		s.connect(ae), l.connect(ae), v.connect(m.offset), v.connect(g.offset);
		let fe = [
			ae,
			oe,
			de,
			u,
			y
		];
		for (let e of A) {
			e.type = "lowpass";
			for (let t of fe) t.connect(e.detune);
		}
		return {
			drift: t,
			note: s,
			amp: f,
			filterEnv: p,
			a: b,
			b: x,
			aWidth: m,
			bWidth: g,
			aComparator: D,
			bComparator: re,
			aSaw: S,
			aPulse: C,
			aLevel: T,
			bWave: E,
			bPulse: ee,
			bLevel: ne,
			filters: A,
			classic: ie,
			ladder: ri(e, {
				keep: n,
				onError: i,
				name: "ORACLE"
			}, O, k, fe),
			tracking: ae,
			envDepth: oe,
			polyEnv: se,
			polyB: ce,
			polyA: ue,
			polyFilter: de,
			pitched: !1
		};
	}), x = new Z(b.length), S = {}, C = !1, w = (t, n) => {
		C ? t.setTargetAtTime(n, e.currentTime, .008) : t.value = n;
	}, T = (e, t, n, r) => {
		let i = Math.max(.001, S[`${t}Attack`]);
		hr(e, r), e.linearRampToValueAtTime(n, r + i), e.setTargetAtTime(n * S[`${t}Sustain`], r + i, Math.max(.001, S[`${t}Decay`]) / 3);
	}, E = (e, t, n) => {
		hr(e, n), e.setTargetAtTime(0, n, Math.max(.001, S[`${t}Release`]) / 4);
	}, ee = (e, t) => {
		for (let { index: n, pending: r } of x.release(e, S.ampRelease, t)) {
			let t = b[n];
			r && hr(t.note.offset, e), E(t.amp.offset, "amp", e), E(t.filterEnv.offset, "filter", e);
		}
	};
	return {
		pitch: l,
		cv: u,
		output: f,
		apply(e) {
			S = e;
			let t = e.vintage, n = e.aShape, r = e.bShape, i = e.polyDest, a = e.lfoDest;
			for (let a of b) {
				w(a.a.detune, e.aOctave * 1200 + a.drift[0] * t), w(a.b.detune, e.bOctave * 1200 + e.bFine + a.drift[1] * t), a.b.type = r === 1 ? "triangle" : "sawtooth", w(a.aSaw.gain, n === 1 ? 0 : n === 2 ? .7 : 1), w(a.aPulse.gain, n === 0 ? 0 : n === 2 ? .7 : 1), w(a.bWave.gain, r === 2 ? 0 : 1), w(a.bPulse.gain, +(r === 2)), a.aComparator(n !== 0, !C), a.bComparator(r === 2, !C), w(a.aWidth.offset, 2 * e.aWidth - 1), w(a.bWidth.offset, 2 * e.bWidth - 1), w(a.aLevel.gain, e.aLevel * .25), w(a.bLevel.gain, e.bLevel * .25), w(a.polyEnv.gain, e.polyEnv * 3600), w(a.polyB.gain, e.polyOscB * 2400), w(a.polyA.gain, i === 1 ? 0 : 1), w(a.polyFilter.gain, i === 0 ? 0 : 1), w(a.tracking.gain, e.tracking), w(a.envDepth.gain, e.envAmount * 6e3), a.filters.forEach((n, r) => {
					w(n.frequency, e.cutoff), w(n.detune, a.drift[2] * t), w(n.Q, r === 0 ? -3.01 + e.resonance * 20 : -3.01);
				});
				let o = a.ladder.apply(e.filterModel === 1, {
					cutoff: e.cutoff,
					resonance: e.resonance,
					drive: ci,
					level: li,
					detune: a.drift[2] * t
				}, w);
				w(a.classic.gain, +!o);
			}
			g.type = [
				"triangle",
				"sawtooth",
				"square"
			][e.lfoShape], w(g.frequency, e.lfoRate), w(_.gain, a === 0 ? e.lfoAmount * 300 : 0), w(v.gain, a === 1 ? e.lfoAmount * .9 : 0), w(y.gain, a === 2 ? e.lfoAmount * 2400 : 0), w(h.gain, e.noise * .2), w(f.gain, e.level), C = !0;
		},
		noteOn(e, t, n, r) {
			ee(n, r);
			let i = /* @__PURE__ */ new Set();
			for (let a of (ze[S.chord]?.[1] ?? [0]).slice(0, b.length)) {
				let o = x.allocate(n, i), s = b[o], c = (e + a - 60) * 100;
				i.add(o), x.start(o, r, n), hr(s.note.offset, n), S.glide > 0 && s.pitched ? s.note.offset.setTargetAtTime(c, n, S.glide / 3) : s.note.offset.setValueAtTime(c, n), s.pitched = !0, T(s.amp.offset, "amp", t, n), T(s.filterEnv.offset, "filter", t, n);
			}
		},
		noteOff: ee,
		flush: () => Promise.all(b.map((e) => e.ladder.flush())).then(() => void 0),
		dispose: () => {
			for (let e of b) e.ladder.dispose();
		}
	};
}
// src/audio/aurora.ts
var pi = .25, mi = 1.22;
function hi(e, { keep: t, source: n, onError: r }) {
	let i = (n = 1) => {
		let r = t(e.createGain());
		return r.gain.value = n, r;
	}, a = () => {
		let t = n(e.createConstantSource());
		return t.offset.value = 0, t;
	}, o = i(), s = i(), c = i(), l = i(.22);
	l.connect(c);
	let u = n(e.createOscillator()), d = i(0), f = i(0), p = i(0);
	u.connect(d), u.connect(f), u.connect(p);
	let m = Float32Array.from({ length: 2049 }, (e, t) => Math.tanh(24 * (t / 1024 - 1))), h = Array.from({ length: 8 }, (c, u) => {
		let h = a(), g = a(), _ = a(), v = i(), y = i(0), b = i(), x = i(), S = i(0), C = [0, 1].map(() => {
			let r = n(e.createOscillator()), s = a(), c = i(), l = i(0), u = i(), p = i();
			r.frequency.value = 261.625565;
			let g = t(e.createWaveShaper());
			return g.curve = m, g.oversample = "4x", r.connect(c).connect(p), r.connect(g), s.connect(g), l.connect(p), p.connect(u).connect(v), h.connect(r.detune), o.connect(r.detune), d.connect(r.detune), f.connect(s.offset), {
				osc: r,
				width: s,
				raw: c,
				pulse: l,
				level: u,
				out: p,
				pulsed: Tr(g, l)
			};
		});
		C[1].out.connect(S).connect(C[0].osc.detune);
		let w = t(e.createBiquadFilter()), T = [t(e.createBiquadFilter()), t(e.createBiquadFilter())];
		w.type = "highpass", w.Q.value = -3.01;
		let E = i(0), ee = i(1);
		v.connect(w).connect(T[0]), T[0].connect(E).connect(y), T[0].connect(T[1]).connect(ee).connect(y), g.connect(y.gain), y.connect(l), h.connect(b), o.connect(b), _.connect(x);
		for (let e of T) e.type = "lowpass", b.connect(e.detune), x.connect(e.detune), s.connect(e.detune), p.connect(e.detune);
		return {
			note: h,
			oscillators: C,
			hpf: w,
			filters: T,
			twoPole: E,
			fourPole: ee,
			ladder: ri(e, {
				keep: t,
				onError: r,
				name: "AURORA"
			}, w, y, [
				b,
				x,
				s,
				p
			]),
			tracking: b,
			amount: x,
			cross: S,
			amp: ni(g.offset),
			env: ni(_.offset),
			pitched: !1,
			drift: [
				3,
				-4,
				1,
				5,
				-2,
				4,
				-5,
				2
			][u]
		};
	}), g = new Z(8), _ = {}, v = !1, y = (t, n) => {
		v ? t.setTargetAtTime(n, e.currentTime, .008) : t.value = n;
	}, b = (e, t) => {
		for (let { index: n, pending: r } of g.release(e, _.ampRelease, t)) {
			let t = h[n];
			r && hr(t.note.offset, e), t.amp.off(e, _.ampRelease), t.env.off(e, _.filterRelease);
		}
	};
	return {
		pitch: o,
		cv: s,
		output: c,
		apply(e) {
			_ = e;
			for (let t of h) {
				t.oscillators.forEach((n, r) => {
					let i = `osc${r + 1}`, a = e[`${i}Wave`];
					n.osc.type = [
						"sawtooth",
						"sawtooth",
						"triangle",
						"sine"
					][a], y(n.osc.detune, e[`${i}Octave`] * 1200 + e[`${i}Detune`] + t.drift * e.vintage * (r ? -.7 : 1)), y(n.width.offset, 2 * e[`${i}Width`] - 1), y(n.raw.gain, a === 1 ? 0 : 1), y(n.pulse.gain, +(a === 1)), n.pulsed(a === 1, !v), y(n.level.gain, r ? e.blend : 1 - e.blend);
				}), y(t.cross.gain, e.crossMod * 1800), y(t.hpf.frequency, e.hpf);
				let n = t.ladder.apply(e.filterModel === 1, {
					cutoff: e.cutoff,
					resonance: e.resonance,
					drive: pi,
					level: mi,
					mode: +(e.slope === 0),
					detune: t.drift * e.vintage * 9
				}, y);
				y(t.twoPole.gain, +(!n && e.slope === 0)), y(t.fourPole.gain, +(!n && e.slope === 1)), t.filters.forEach((n, r) => {
					y(n.frequency, e.cutoff), y(n.Q, r ? -3.01 : -3.01 + e.resonance * 17), y(n.detune, t.drift * e.vintage * 9);
				}), y(t.tracking.gain, e.tracking), y(t.amount.gain, e.envAmount * 6e3);
			}
			u.type = [
				"triangle",
				"sine",
				"square"
			][e.lfoShape], y(u.frequency, e.lfoRate), y(d.gain, e.lfoPitch * 100), y(f.gain, e.lfoWidth * .8), y(p.gain, e.lfoFilter * 2400), y(c.gain, e.level), v = !0;
		},
		noteOn(e, t, n, r) {
			b(n, r);
			let i = /* @__PURE__ */ new Set();
			for (let a of ze[_.chord]?.[1] ?? [0]) {
				let o = g.allocate(n, i), s = h[o], c = (e + a - 60) * 100;
				i.add(o), g.start(o, r, n), hr(s.note.offset, n), _.glide && s.pitched ? s.note.offset.setTargetAtTime(c, n, _.glide / 3) : s.note.offset.setValueAtTime(c, n), s.pitched = !0, s.amp.on(n, t, _.ampAttack, _.ampDecay, _.ampSustain), s.env.on(n, 1, _.filterAttack, _.filterDecay, _.filterSustain);
			}
		},
		noteOff: b,
		flush: () => Promise.all(h.map((e) => e.ladder.flush())).then(() => void 0),
		dispose: () => {
			for (let e of h) e.ladder.dispose();
		}
	};
}
// src/audio/prism.ts
function gi(e, { keep: t, onError: n }) {
	let r = t(new AudioWorkletNode(e, "rackloose-prism-v1", {
		numberOfInputs: 2,
		numberOfOutputs: 1,
		outputChannelCount: [1],
		processorOptions: { module: Ur() }
	})), i = t(e.createGain()), a = t(e.createGain());
	i.connect(r, 0, 0), a.connect(r, 0, 1);
	let o = {};
	return {
		pitch: i,
		cv: a,
		output: r,
		...Kr(r, "PRISM", void 0, n),
		apply(t) {
			o = t, r.port.postMessage({
				type: "params",
				time: e.currentTime,
				params: t
			});
		},
		noteOn(e, t, n, i) {
			r.port.postMessage({
				type: "on",
				time: n,
				key: i,
				velocity: t,
				notes: (ze[o.chord]?.[1] ?? [0]).map((t) => e + t)
			});
		},
		noteOff(e, t) {
			r.port.postMessage({
				type: "off",
				time: e,
				key: t
			});
		}
	};
}
// src/audio/studio.ts
function _i(e, t, n, r) {
	let i = n(new AudioWorkletNode(e, "rackloose-studio-v1", {
		numberOfInputs: 1,
		numberOfOutputs: 1,
		outputChannelCount: [2],
		channelCount: 2,
		channelCountMode: "explicit",
		processorOptions: { type: t }
	})), a = 0;
	return {
		input: i,
		output: i,
		...Kr(i, Y[t].name, (e) => {
			a = e;
		}, r),
		get reduction() {
			return a;
		},
		apply(t) {
			i.port.postMessage({
				type: "params",
				time: e.currentTime,
				params: t
			});
		}
	};
}
// src/audio/sieve.ts
var vi = [
	"lowpass",
	"highpass",
	"bandpass"
], yi = [
	0,
	3,
	2
], bi = .2, xi = [
	.1,
	1,
	2.5,
	4,
	6,
	9,
	12
], Si = [
	[
		.8,
		.1,
		-.8,
		-1.3,
		-1.9,
		-2.3,
		-2
	],
	[
		-4.1,
		-4.6,
		-5.3,
		-6,
		-6.7,
		-6.9,
		-4.7
	],
	[
		-6.9,
		2,
		6.4,
		9.1,
		12.1,
		16.8,
		22.8
	]
];
function Ci(e, t) {
	let n = Si[e], r = 0;
	for (; r < xi.length - 2 && t > xi[r + 1];) r++;
	let i = Math.min(1, Math.max(0, (t - xi[r]) / (xi[r + 1] - xi[r])));
	return 10 ** (-(n[r] + i * (n[r + 1] - n[r])) / 20);
}
var wi = (e) => Math.min(1, Math.max(0, (e - .1) / 11.9));
function Ti(e, { keep: t, onError: n }) {
	let r = () => t(e.createGain()), i = r(), a = r(), o = r(), s = r(), c = t(e.createBiquadFilter());
	i.connect(c).connect(s).connect(o), a.connect(c.detune);
	let l = ri(e, {
		keep: t,
		onError: n,
		name: "SIEVE"
	}, i, o, [a]), u = !1, d = (t, n) => {
		u ? t.setTargetAtTime(n, e.currentTime, .008) : t.value = n;
	};
	return {
		input: i,
		cv: a,
		output: o,
		apply(e) {
			c.type = vi[e.mode], d(c.frequency, e.cutoff), d(c.Q, e.resonance);
			let t = l.apply(e.filterModel === 1, {
				cutoff: e.cutoff,
				resonance: wi(e.resonance),
				drive: bi,
				level: Ci(e.mode, e.resonance),
				mode: yi[e.mode]
			}, d);
			d(s.gain, +!t), u = !0;
		},
		flush: l.flush,
		dispose: l.dispose
	};
}
// src/audio/rust.ts
var Ei = 4097;
function Di(e, t, n, r, i) {
	let a = 1 + 60 * t ** 2, o = .6 * n, s = .25 * i;
	return Float32Array.from({ length: Ei }, (t, n) => {
		let i = n / 4096 * 2 - 1, c = Math.sign(i) * Math.max(0, Math.abs(i) - s) / (1 - s), l = a * c + o * Math.min(1, a * Math.abs(c) * 4);
		switch (Ye[e]) {
			case "Rectify": return Math.abs(Math.tanh(1.5 * l));
			case "Fold": return Math.sin(Math.PI / 2 * l);
			case "Crush": {
				let e = 2 ** (r - 1);
				return Math.round(Math.tanh(l) * e) / e;
			}
			case "Broken": return l > 0 ? Math.tanh(3 * l) : Math.max(-.3, l * 1.5);
			default: return Math.max(-1, Math.min(1, l));
		}
	});
}
function Oi(e, t) {
	let n = t(e.createGain()), r = t(e.createGain()), i = t(e.createBiquadFilter()), a = t(e.createWaveShaper()), o = t(e.createBiquadFilter()), s = t(e.createBiquadFilter()), c = t(e.createGain()), l = t(e.createGain()), u = t(e.createGain());
	i.type = "peaking", i.Q.value = 1.1, i.gain.value = 9, o.type = "highpass", o.frequency.value = 30, s.type = "lowpass", s.Q.value = .5, n.connect(c).connect(u), n.connect(r).connect(i).connect(a).connect(o).connect(s).connect(l).connect(u);
	let d = "", f = !1;
	return {
		input: n,
		cv: r.gain,
		output: u,
		apply(t) {
			let n = (t, n) => {
				f ? t.setTargetAtTime(n, e.currentTime, .01) : t.value = n;
			}, r = [
				t.mode,
				t.drive,
				t.bias,
				t.crush,
				t.starve
			].join();
			r !== d && (a.curve = Di(t.mode, t.drive, t.bias, t.crush, t.starve), a.oversample = Ye[t.mode] === "Crush" ? "none" : "2x", d = r), n(i.frequency, t.body), n(s.frequency, 1500 * 12 ** t.tone), n(c.gain, 1 - t.mix), n(l.gain, t.mix * (.7 - .25 * t.drive)), n(u.gain, t.level * 1.4), f = !0;
		}
	};
}
// src/audio/processors.ts
var ki = (e) => 10 ** (e / 20), Ai = (e, t, n, r) => {
	r ? e.value = t : e.setTargetAtTime(t, n, .008);
}, ji = [
	[2e-4, .3],
	[2e-4, .45],
	[4e-4, .6],
	[4e-4, .75],
	[4e-4, .9],
	[2e-4, 1]
], Mi = 24, Ni = 6;
function Pi(e, t, n) {
	let r = ki(e), i = e + t, a = ki(i), o = (e) => 20 * Math.log10(e), s = (e, t) => e < r ? e : r + (1 - Math.exp(-t * (e - r))) / t, c = (e, t) => e < r ? 1 : (o(s(e * 1.001, t)) - o(s(e, t))) / (o(e * 1.001) - o(e)), l = .1, u = 1e4, d = 5;
	for (let e = 0; e < 15; e++) c(a, d) < 1 / n ? u = d : l = d, d = Math.sqrt(l * u);
	return (1 / (1 < a ? s(1, d) : ki(o(s(a, d)) + (0 - i) / n))) ** .6;
}
function Fi(e, { keep: t }) {
	let n = (n = 1) => {
		let r = t(e.createGain());
		return r.gain.value = n, r;
	}, r = (n, r, i = 0) => {
		let a = t(e.createBiquadFilter());
		return a.type = n, a.frequency.value = r, a.gain.value = i, a.Q.value = -3.01, a;
	}, i = n(), a = n(), o = t(e.createWaveShaper()), s = n(), c = .2, l = .5 * (1 - Math.tanh(c) ** 2);
	o.curve = Float32Array.from({ length: 2049 }, (e, t) => (Math.tanh(2 * (t / 1024 - 1) + c) - Math.tanh(c)) / l), o.oversample = "2x";
	let u = t(e.createDynamicsCompressor());
	u.knee.value = Mi, u.ratio.value = Ni, i.connect(a).connect(o).connect(r("highpass", 12)).connect(r("lowshelf", 90, 1)).connect(r("highshelf", 9e3, -1)).connect(u).connect(s);
	let d = !0, f = NaN, p = 1;
	return {
		input: i,
		output: s,
		compressor: u,
		apply(t) {
			let n = e.currentTime, [r, i] = ji[t.time] ?? ji[1];
			f !== t.threshold && (f = t.threshold, p = Pi(t.threshold, Mi, Ni)), Ai(a.gain, ki(t.input) / 4, n, d), Ai(u.threshold, t.threshold, n, d), u.attack.value = r, u.release.value = i, Ai(s.gain, ki(t.output) / p, n, d), d = !1;
		}
	};
}
function Ii(e, t) {
	return [
		{
			type: "highpass",
			frequency: e.hpf <= 16 ? 0 : e.hpf,
			Q: -3.01,
			gain: 0
		},
		{
			type: e.lfBell ? "peaking" : "lowshelf",
			frequency: e.lfFreq,
			Q: .7,
			gain: e.lfGain
		},
		{
			type: "peaking",
			frequency: e.lmfFreq,
			Q: e.lmfQ,
			gain: e.lmfGain
		},
		{
			type: "peaking",
			frequency: e.hmfFreq,
			Q: e.hmfQ,
			gain: e.hmfGain
		},
		{
			type: e.hfBell ? "peaking" : "highshelf",
			frequency: e.hfFreq,
			Q: .7,
			gain: e.hfGain
		},
		{
			type: "lowpass",
			frequency: e.lpf >= 22e3 ? t : Math.min(e.lpf, t),
			Q: -3.01,
			gain: 0
		}
	];
}
function Li({ type: e, frequency: t, Q: n, gain: r }, i, a) {
	let o = a / 2;
	if (e === "highpass" && t <= 0 || e === "lowpass" && t >= o) return 0;
	let s = 10 ** (r / 40), c = 2 * Math.PI * t / a, l = Math.cos(c), u = Math.sin(c), d = u / (2 * 10 ** (n / 20)), f = u / (2 * n), p = u / 2 * Math.SQRT2 * 2 * Math.sqrt(s), [m, h, g, _, v, y] = {
		lowpass: [
			(1 - l) / 2,
			1 - l,
			(1 - l) / 2,
			1 + d,
			-2 * l,
			1 - d
		],
		highpass: [
			(1 + l) / 2,
			-(1 + l),
			(1 + l) / 2,
			1 + d,
			-2 * l,
			1 - d
		],
		peaking: [
			1 + f * s,
			-2 * l,
			1 - f * s,
			1 + f / s,
			-2 * l,
			1 - f / s
		],
		lowshelf: [
			s * (s + 1 - (s - 1) * l + p),
			2 * s * (s - 1 - (s + 1) * l),
			s * (s + 1 - (s - 1) * l - p),
			s + 1 + (s - 1) * l + p,
			-2 * (s - 1 + (s + 1) * l),
			s + 1 + (s - 1) * l - p
		],
		highshelf: [
			s * (s + 1 + (s - 1) * l + p),
			-2 * s * (s - 1 + (s + 1) * l),
			s * (s + 1 + (s - 1) * l - p),
			s + 1 - (s - 1) * l + p,
			2 * (s - 1 - (s + 1) * l),
			s + 1 - (s - 1) * l - p
		]
	}[e] ?? [
		1,
		0,
		0,
		1,
		0,
		0
	], b = 2 * Math.PI * i / a, x = Math.cos(b), S = Math.sin(b), C = Math.cos(2 * b), w = Math.sin(2 * b), T = (e, t, n) => Math.hypot(e + t * x + n * C, t * S + n * w);
	return 20 * Math.log10(T(m, h, g) / T(_, v, y));
}
function Ri(e, { keep: t }) {
	let n = (n = 1) => {
		let r = t(e.createGain());
		return r.gain.value = n, r;
	}, r = n(), i = n(), a = n(0), o = n(), s = e.sampleRate / 2, c = Array.from({ length: 6 }, () => t(e.createBiquadFilter()));
	c.reduce((e, t) => e.connect(t), r).connect(i).connect(o), r.connect(a).connect(o);
	let l = !0;
	return {
		input: r,
		output: o,
		apply(t) {
			let n = e.currentTime;
			Ii(t, s).forEach((e, t) => {
				let r = c[t];
				r.type !== e.type && (r.type = e.type), e.frequency <= 0 || e.frequency >= s ? (r.frequency.cancelScheduledValues(n), r.frequency.setValueAtTime(e.frequency, n)) : Ai(r.frequency, e.frequency, n, l), Ai(r.Q, e.Q, n, l), Ai(r.gain, e.gain, n, l);
			}), Ai(i.gain, +!t.active, n, l), Ai(a.gain, +!!t.active, n, l), Ai(o.gain, ki(t.output), n, l), l = !1;
		}
	};
}
// src/audio/session.ts
function zi() {
	let e = typeof navigator > "u" ? void 0 : navigator.audioSession;
	if (!e || e.type === "playback") return () => {};
	let t = e.type;
	return e.type = "playback", () => {
		e.type === "playback" && (e.type = t);
	};
}
// src/audio/engine.ts
var Bi = [
	"sine",
	"triangle",
	"sawtooth",
	"square"
], Vi = (e, t) => `${e}:${t}`, Hi = (e, t, n) => {
	e.setTargetAtTime(t, n, .008);
}, Ui = .5, Wi = .09, Gi = 4, Ki = 120;
function qi({ analyser: e, data: t }) {
	e.getFloatTimeDomainData(t);
	let n = 0;
	for (let e of t) n = Math.max(n, Math.abs(e));
	return n > 0 ? Math.max(-60, 20 * Math.log10(n)) : -60;
}
function Ji(e, t = 0, n = 2, r = !1, i = 0) {
	let a = e.createBuffer(r ? 2 : 1, Math.ceil(e.sampleRate * n), e.sampleRate), o = 90210;
	for (let n = 0; n < a.numberOfChannels; n++) {
		let r = a.getChannelData(n), s = 0;
		for (let n = 0; n < r.length; n++) {
			o ^= o << 13, o ^= o >>> 17, o ^= o << 5;
			let a = (o >>> 0) / 2 ** 31 - 1;
			s = t === 1 ? .93 * s + .2 * a : t === 2 ? (s + .035 * a) / 1.035 : a, r[n] = s * (i ? Math.exp(-n / e.sampleRate / i * 5) : 1);
		}
	}
	return a;
}
var Yi = "seq", Xi = "manual", Zi = "audition", Qi = class {
	context;
	onError;
	master;
	nodes = [];
	sources = [];
	started = !1;
	runtime = /* @__PURE__ */ new Map();
	outputs = /* @__PURE__ */ new Map();
	inputs = /* @__PURE__ */ new Map();
	cvAmounts = /* @__PURE__ */ new Map();
	notes = /* @__PURE__ */ new Map();
	white = null;
	mix = $t;
	open = {};
	muted = !1;
	manualTarget = null;
	manualOwned = /* @__PURE__ */ new Set();
	targets = /* @__PURE__ */ new Map();
	pulses = /* @__PURE__ */ new Map();
	dictators = /* @__PURE__ */ new Map();
	take = null;
	manualKeys = /* @__PURE__ */ new Set();
	patch;
	constructor(e, t, n = e.destination, r = $t, i) {
		this.context = e, this.onError = i, this.patch = t, this.master = this.keep(e.createGain());
		let a = this.keep(e.createDynamicsCompressor());
		a.threshold.value = -12, a.knee.value = 12, a.ratio.value = 8, a.attack.value = .003, a.release.value = .15, this.master.connect(a).connect(n);
		for (let e of t.modules) this.buildModule(e);
		for (let e of t.modules) Yt(e.type) && this.targets.set(e.id, an(t, e.id));
		for (let n of t.cables) {
			let r = this.outputs.get(Vi(n.from.moduleId, n.from.portId)), i = this.inputs.get(Vi(n.to.moduleId, n.to.portId));
			if (!r || !i || this.isNoteCable(n)) continue;
			let a = Y[t.modules.find((e) => e.id === n.to.moduleId).type].ports.find((e) => e.id === n.to.portId);
			if (a.kind === "cv") {
				let t = this.keep(e.createGain());
				t.gain.value = n.amount * (a.scale ?? 1), r.connect(t), "setValueAtTime" in i, t.connect(i), this.cvAmounts.set(n.id, t);
			} else "setValueAtTime" in i, r.connect(i);
		}
		this.applyPatch(t, !0), this.setMix(r, !0);
		for (let e of this.sources) e.start(0);
		this.started = !0;
	}
	keep(e) {
		return this.nodes.push(e), e;
	}
	isNoteCable(e) {
		let t = this.patch.modules.find((t) => t.id === e.from.moduleId)?.type;
		return e.to.portId === "pitch" && qt(this.patch.modules.find((t) => t.id === e.to.moduleId).type) && !!t && Yt(t);
	}
	polyNote(e, t, n, r) {
		let i = this.patch.cables.find((t) => t.to.moduleId === e && this.isNoteCable(t));
		return i ? 60 + ((i.from.moduleId === t ? n : this.noteAt(i.from.moduleId, r)) - 60) * i.amount : 60;
	}
	noteAt(e, t) {
		let n = this.notes.get(e) ?? [];
		for (let e = n.length - 1; e >= 0; e--) if (n[e].time <= t) return n[e].note;
		return 48;
	}
	get main() {
		return (this.patch.modules.find((e) => e.type === "performance") ?? this.patch.modules[0]).id;
	}
	gain(e = 1) {
		let t = this.keep(this.context.createGain());
		return t.gain.value = e, t;
	}
	source(e) {
		return "offset" in e && mr(e.offset, this.context), this.started && e.start(this.context.currentTime), this.keep(e), this.sources.push(e), e;
	}
	buildModule(e) {
		let { context: t } = this, n = (t) => Vi(e.id, t), r = (e, t) => this.inputs.set(n(e), t), i = this.gain(), a = (e, t, r = !0) => this.outputs.set(n(e), r ? t.connect(i) : t), o = !1, s = (e, n) => {
			o ? Hi(e, n, t.currentTime) : e.value = n;
		}, c = () => {}, l, u, d, f, p, m, h, g, _, v, y, b = (e) => {
			p = this.source(t.createConstantSource()), p.offset.value = 0;
			let n = this.gain(1200);
			p.connect(n), "setValueAtTime" in e, n.connect(e);
		};
		switch (e.type) {
			case "performance":
			case "dictator":
				l = this.source(t.createConstantSource()), l.offset.value = -1, a("pitch", l, !1);
				break;
			case "oscillator": {
				let e = this.source(t.createOscillator()), n = this.gain();
				e.frequency.value = 261.625565, e.connect(n), r("pitch", e.detune), b(e.detune), r("fm", e.detune), a("out", n), c = (t) => {
					e.type = Bi[t.wave], s(e.detune, t.octave * 1200 + t.tune * 100 + t.fine), s(n.gain, t.level * .35);
				};
				break;
			}
			case "monarch":
				this.white ??= Ji(t, 0, 1), f = si(t, this.white, {
					onError: this.onError,
					keep: (e) => this.keep(e),
					source: (e) => this.source(e)
				}), r("pitch", f.pitch), b(f.pitch), r("cv", f.cv), a("out", f.output), c = f.apply;
				break;
			case "oracle":
			case "aurora":
			case "prism": {
				this.white ??= Ji(t, 0, 1);
				let n = {
					onError: this.onError,
					keep: (e) => this.keep(e),
					source: (e) => this.source(e)
				};
				g = e.type === "oracle" ? fi(t, this.white, n) : e.type === "aurora" ? hi(t, n) : gi(t, n), r("pitch", g.pitch), r("cv", g.cv), a("out", g.output), c = g.apply;
				break;
			}
			case "compressor":
				_ = Fi(t, { keep: (e) => this.keep(e) }), r("in", _.input), a("out", _.output), c = _.apply;
				break;
			case "cohere":
			case "talon":
			case "brit":
				m = _i(t, e.type, (e) => this.keep(e), this.onError), r("in", m.input), a("out", m.output), c = m.apply;
				break;
			case "equalizer": {
				let e = Ri(t, { keep: (e) => this.keep(e) });
				r("in", e.input), a("out", e.output), c = e.apply;
				break;
			}
			case "noise": {
				let n = this.source(t.createBufferSource()), r = this.gain();
				n.buffer = Ji(t, e.params.color), n.loop = !0, n.connect(r), a("out", r), c = (e) => s(r.gain, e.level * .3);
				break;
			}
			case "mixer": {
				let e = () => {
					let e = this.keep(t.createAnalyser());
					return e.fftSize = 512, {
						analyser: e,
						data: new Float32Array(e.fftSize)
					};
				}, n = this.gain(), i = this.gain(), o = this.keep(t.createChannelSplitter(2));
				y = {
					channels: [],
					bus: [e(), e()]
				}, n.connect(i).connect(o), y.bus.forEach(({ analyser: e }, t) => o.connect(e, t));
				let l = He.map((i, a) => {
					let o = this.gain(), s = this.gain(), c = e(), l = [this.gain(), this.gain()], u = this.gain(), d = this.keep(t.createChannelSplitter(2)), f = this.keep(t.createChannelMerger(2));
					return u.channelCount = 2, u.channelCountMode = "explicit", u.channelInterpretation = "speakers", o.connect(s).connect(u).connect(d), s.connect(c.analyser), l.forEach((e, t) => d.connect(e, t).connect(f, 0, t)), f.connect(n), r(i, o), y.channels.push(c), {
						id: He[a],
						level: o,
						gate: s,
						sides: l
					};
				});
				v = Object.fromEntries(l.map(({ id: e, gate: t }) => [e, t])), a("out", i), c = (e) => {
					for (let { id: t, level: n, sides: [r, i] } of l) {
						let a = e[Ue(t)];
						s(n.gain, e[t]), s(r.gain, a > 0 ? Math.cos(a * Math.PI / 2) : 1), s(i.gain, a < 0 ? Math.cos(-a * Math.PI / 2) : 1);
					}
					s(i.gain, e.master);
				};
				break;
			}
			case "filter":
				h = Ti(t, {
					keep: (e) => this.keep(e),
					onError: this.onError
				}), r("in", h.input), r("cv", h.cv), a("out", h.output), c = h.apply;
				break;
			case "amplifier": {
				let t = this.gain(), n = this.gain();
				t.connect(n), t.gain.value = +!this.patch.cables.some((t) => t.to.moduleId === e.id && t.to.portId === "cv"), r("in", t), r("cv", t.gain), a("out", n), c = (e) => s(n.gain, e.level);
				break;
			}
			case "envelope": {
				let e = this.source(t.createConstantSource());
				e.offset.value = 0, a("out", e), u = ni(e.offset);
				break;
			}
			case "lfo": {
				let e = this.source(t.createOscillator());
				r("cv", e.frequency), a("out", e), c = (t) => {
					e.type = Bi[t.wave], s(e.frequency, t.rate);
				};
				break;
			}
			case "delay": {
				let e = this.gain(), n = this.gain(), i = this.gain(), o = this.gain(), l = this.keep(t.createDelay(1)), u = this.gain();
				e.connect(i).connect(n), e.connect(l).connect(o).connect(n), l.connect(u).connect(l), r("in", e), a("out", n), c = (e) => {
					s(l.delayTime, e.time), s(u.gain, e.feedback), s(i.gain, 1 - e.mix), s(o.gain, e.mix);
				};
				break;
			}
			case "reverb": {
				let e = this.gain(), n = this.gain(), i = this.gain(), o = this.gain(), l = this.keep(t.createConvolver());
				e.connect(i).connect(n), e.connect(l).connect(o).connect(n), r("in", e), a("out", n);
				let u = -1;
				c = (e) => {
					u !== e.decay && (l.buffer = Ji(t, 0, e.decay, !0, e.decay), u = e.decay), s(i.gain, 1 - e.mix), s(o.gain, e.mix);
				};
				break;
			}
			case "boom":
			case "punch":
			case "orbit":
			case "strike":
			case "forge": {
				let n = this.gain(), o = this.gain(), l = this.gain(), u = this.gain();
				n.connect(o).connect(i).connect(u), l.connect(u), r("chain", l), a("out", u, !1), this.white ??= Ji(t, 0, 1);
				let f = e.type === "forge" ? Pr(t, n, (e) => this.keep(e)) : void 0;
				d = ti(t, e.type, n, {
					keep: (e) => this.keep(e),
					start: (e) => this.source(e),
					noise: this.white,
					onError: this.onError
				}, f), c = (e) => {
					f?.apply(e), s(o.gain, e.level * Ui);
				};
				break;
			}
			case "rust": {
				let e = Oi(t, (e) => this.keep(e));
				r("in", e.input), r("cv", e.cv), a("out", e.output), c = e.apply;
				break;
			}
			case "output": r("in", this.master), c = (e) => s(this.master.gain, this.muted ? 0 : e.volume * .8);
		}
		for (let t of Y[e.type].ports) {
			let e = t.copyOf && this.outputs.get(n(t.copyOf));
			e && this.outputs.set(n(t.id), e);
		}
		this.runtime.set(e.id, {
			module: e,
			apply: (e) => {
				c(e), o = !0;
			},
			gate: i,
			channels: v,
			meters: y,
			pitch: l,
			envelope: u,
			drums: d,
			monarch: f,
			sieve: h,
			poly: g,
			valve: _,
			studio: m,
			manualPitch: p
		});
	}
	applyPatch(e, t = !1) {
		for (let n of e.modules) {
			let e = this.runtime.get(n.id);
			e && (t || JSON.stringify(e.module.params) !== JSON.stringify(n.params)) && (e.apply(n.params), e.module = n);
		}
		for (let n of e.cables) {
			let r = this.cvAmounts.get(n.id);
			if (r && (t || this.patch.cables.find((e) => e.id === n.id)?.amount !== n.amount)) {
				let t = e.modules.find((e) => e.id === n.to.moduleId), i = Y[t.type].ports.find((e) => e.id === n.to.portId)?.scale ?? 1;
				Hi(r.gain, this.manualTarget === n.to.moduleId && n.to.portId === "pitch" && !qt(t.type) ? 0 : n.amount * i, this.context.currentTime);
			}
		}
		this.patch = e;
	}
	gatedBy(e) {
		let t = new Set(this.patch.cables.filter((t) => t.from.moduleId === e && Tt(this.patch, t.from)?.kind === "gate").map((e) => e.to.moduleId));
		return [...this.runtime.values()].filter((e) => (e.envelope || e.monarch || e.poly) && t.has(e.module.id));
	}
	setMix(e, t = !1) {
		this.mix = e, this.open = on(this.patch, e);
		let n = (e, n) => {
			t ? e.gain.value = +!!n : Hi(e.gain, +!!n, this.context.currentTime);
		};
		for (let { module: t, gate: r, channels: i } of this.runtime.values()) {
			n(r, this.open[t.id] !== !1);
			for (let [r, a] of Object.entries(i ?? {})) n(a, cn(t, r, e));
		}
	}
	openEnvelope(e, t, n, r, i, a) {
		if (e.monarch) {
			e.monarch.noteOn(t, n);
			return;
		}
		if (e.poly) {
			e.poly.noteOn(this.polyNote(e.module.id, a, r, n), t, n, i);
			return;
		}
		let o = e.module.params;
		e.envelope?.on(n, t, o.attack, o.decay, o.sustain);
	}
	closeEnvelope(e, t, n) {
		e.monarch && e.monarch.noteOff(t), e.poly?.noteOff(t, n), e.envelope?.off(t, e.module.params.release);
	}
	setNote(e, t, n) {
		let r = this.runtime.get(e)?.pitch;
		r && (r.offset.cancelScheduledValues(n), r.offset.setValueAtTime((t - 60) / 12, n), this.notes.set(e, [...(this.notes.get(e) ?? []).filter((e) => e.time < n).slice(-63), {
			time: n,
			note: t
		}]));
	}
	gateOn(e, t, n, r) {
		if (this.open[e] !== !1) for (let i of this.gatedBy(e)) this.manualOwned.has(i.module.id) || this.openEnvelope(i, n, r, t, Yi, e);
	}
	noteOn(e, t = 1, n = this.context.currentTime, r = this.main) {
		this.manualTarget !== r && (this.setNote(r, e, n), this.gateOn(r, e, t, n));
	}
	noteOff(e = this.context.currentTime, t = this.main) {
		for (let n of this.gatedBy(t)) this.manualOwned.has(n.module.id) || this.closeEnvelope(n, e, Yi);
	}
	sequence(e, t, n, r) {
		let i = t % 16, a = e.filter((e) => e !== this.manualTarget).flatMap((e) => {
			let t = pt(this.patch, e)[i], a = this.runtime.get(e)?.module.params.lag;
			return t?.enabled && ln(e, i, this.mix) ? [{
				id: e,
				step: t,
				at: this.lagged(n, a),
				end: this.lagged(n + r * t.gate, a)
			}] : [];
		});
		for (let { id: e, step: t, at: n } of a) this.setNote(e, t.note, n);
		for (let { id: e, step: t, at: n, end: r } of a) if (this.gateOn(e, t.note, t.velocity, n), this.noteOff(r, e), this.open[e] !== !1) for (let t of this.targets.get(e) ?? []) this.pulse(t, n, e);
	}
	setTake(e) {
		this.take = e;
	}
	dictatorState(e) {
		let t = this.dictators.get(e);
		return t || this.dictators.set(e, t = {
			sounding: [],
			line: new A()
		}), t;
	}
	clipNotes(e, t, n, r) {
		let i = this.take?.id === e.id ? this.take : null, a = r ? [] : ee(e.notes ?? [], t, n).filter(([e]) => !i || !k(e, i.covered));
		return i ? T([...a, ...ee(i.notes, t, n)]) : a;
	}
	dictatorStep(e, t, n, r) {
		if (!(t < 0)) for (let i of e) {
			let e = this.patch.modules.find((e) => e.id === i);
			if (!e || e.type !== "dictator" || !this.runtime.has(i)) continue;
			let a = this.dictatorState(i), o = C(e.params.length), s = t * 240, c = s % o, l = (t) => this.lagged(n + (t - s) / 240 * r, e.params.lag), u = [];
			for (let e of a.sounding) e.end <= s + 240 && u.push({
				tick: Math.max(s, e.end),
				ends: e
			});
			if (this.open[i] !== !1) {
				let t = this.take?.id === i && this.take.hideFrom !== null && s >= this.take.hideFrom;
				for (let n of this.clipNotes(e, c, c + 240, t)) u.push({
					tick: s + n[0] - c,
					note: n
				});
			}
			u.sort((e, t) => e.tick - t.tick || ("ends" in e ? -1 : 0) - ("ends" in t ? -1 : 0));
			let d = this.gatedBy(i), f = this.kitsOf(i), p = this.manualTarget === i, m = d.filter((e) => e.poly && (p || !this.manualOwned.has(e.module.id))), h = p ? [] : d.filter((e) => !e.poly && !this.manualOwned.has(e.module.id));
			for (let e of u) {
				let t = l(e.tick);
				if ("ends" in e) {
					a.sounding = a.sounding.filter((t) => t !== e.ends);
					for (let n of m) n.poly.noteOff(t, e.ends.key);
					let n = a.line.off(e.ends.id);
					if (n === null) for (let e of h) this.closeEnvelope(e, t, Yi);
					else if (n && !p) {
						this.setNote(i, n.note, t);
						for (let e of h) this.openEnvelope(e, n.velocity / 127, t, n.note, Yi, i);
					}
					continue;
				}
				let [n, r, u, d] = e.note, g = `dictator:${i}:${u}`;
				for (let e of a.sounding.filter((e) => e.note === u)) a.sounding = a.sounding.filter((t) => t !== e), a.line.off(e.id);
				let _ = {
					id: `${e.tick}:${u}`,
					key: g,
					note: u,
					end: Math.min(s - c + o, s + n - c + r)
				};
				a.sounding.push(_), a.line.on(_.id, u, d), p || this.setNote(i, u, t);
				for (let e of m) e.poly.noteOn(this.polyNote(e.module.id, i, u, t), d / 127, t, g);
				for (let e of h) this.openEnvelope(e, d / 127, t, u, Yi, i);
				this.drumNote(f, u, d / 127, t, i);
				for (let e of this.targets.get(i) ?? []) f.some((t) => t.module.id === e) || this.pulse(e, t, i);
			}
		}
	}
	kitsOf(e) {
		return this.patch.cables.filter((t) => t.from.moduleId === e && t.to.portId === "trig" && Tt(this.patch, t.from)?.kind === "gate").flatMap((e) => {
			let t = this.runtime.get(e.to.moduleId);
			return t?.drums ? [t] : [];
		});
	}
	drumNote(e, t, n, r, i) {
		for (let a of e) {
			let e = de(Y[a.module.type].drum?.voices ?? [], t);
			e && cn(a.module, e, this.mix) && (a.drums.trigger(e, this.lagged(r, a.module.params[`${e}Lag`]), a.module.params, n), this.pulse(a.module.id, r, i));
		}
	}
	releaseDictator(e, t) {
		let n = this.dictators.get(e);
		if (n) {
			for (let r of this.gatedBy(e)) if (r.poly) for (let e of n.sounding) r.poly.noteOff(t, e.key);
			else n.line.size && !this.manualOwned.has(r.module.id) && this.closeEnvelope(r, t, Yi);
			n.sounding = [], n.line.clear();
		}
	}
	lagged(e, t = 0) {
		return Math.max(this.context.currentTime, e + t / 1e3);
	}
	pulse(e, t, n) {
		this.pulses.set(e, [...(this.pulses.get(e) ?? []).slice(-63), {
			time: t,
			sequencer: n
		}]);
	}
	lastPulse(e, t) {
		let n = this.pulses.get(e);
		if (!n) return -1;
		let r = n.length - 1;
		for (; r >= 0 && n[r].time > t;) r--;
		return r > 0 && n.splice(0, r), r < 0 ? -1 : n[0].time;
	}
	mixerLevels(e) {
		let t = this.runtime.get(e)?.meters;
		return t ? {
			channels: t.channels.map(qi),
			bus: t.bus.map(qi)
		} : null;
	}
	manualOn(e, t, n = Xi, r = 1) {
		this.manualTarget !== e && this.manualOff();
		let i = this.runtime.get(e), a = this.context.currentTime;
		if (i) {
			if (this.manualTarget = e, i.poly) this.manualOwned = /* @__PURE__ */ new Set([e]), i.poly.noteOff(a, Yi), i.poly.noteOn(t, r, a, n);
			else if (i.module.type === "dictator") {
				let i = this.gatedBy(e);
				if (this.manualOwned = new Set(i.map((e) => e.module.id)), this.open[e] === !1) return;
				this.setNote(e, t, a), this.manualKeys.add(n), this.drumNote(this.kitsOf(e), t, r, a, e);
				for (let o of i) o.poly ? o.poly.noteOn(this.polyNote(o.module.id, e, t, a), r, a, `${Xi}:${n}`) : this.openEnvelope(o, r, a, t, Xi, e);
			} else {
				if (i.module.type === "performance") {
					if (this.manualOwned = new Set(this.gatedBy(e).map((e) => e.module.id)), this.setNote(e, t, a), this.open[e] === !1) return;
				} else {
					let n = Xt(this.patch, e);
					this.manualOwned = new Set(i.monarch ? [e] : this.patch.cables.filter((e) => n.has(e.to.moduleId) && this.runtime.get(e.from.moduleId)?.envelope).map((e) => e.from.moduleId));
					for (let t of this.patch.cables) t.to.moduleId === e && t.to.portId === "pitch" && this.cvAmounts.get(t.id)?.gain.setValueAtTime(0, a);
					i.manualPitch?.offset.setValueAtTime((t - 60) / 12, a);
				}
				for (let n of this.manualOwned) {
					let i = this.runtime.get(n);
					i.poly?.noteOff(a, Yi), this.openEnvelope(i, r, a, t, Xi, e);
				}
			}
		}
	}
	manualRelease(e, t) {
		let n = this.context.currentTime, r = this.runtime.get(this.manualTarget ?? "");
		if (r?.module.type !== "dictator") r?.poly?.noteOff(n, e);
		else {
			this.manualKeys.delete(e);
			for (let i of this.manualOwned) {
				let a = this.runtime.get(i);
				a?.poly ? a.poly.noteOff(n, `${Xi}:${e}`) : a && t && (this.setNote(r.module.id, t.note, n), this.openEnvelope(a, t.velocity, n, t.note, Xi, r.module.id));
			}
		}
	}
	manualOff() {
		let e = this.context.currentTime, t = this.manualTarget, n = this.runtime.get(t ?? "")?.module.type === "dictator";
		for (let t of this.manualOwned) {
			let r = this.runtime.get(t);
			if (r?.poly && n) for (let t of this.manualKeys) r.poly.noteOff(e, `${Xi}:${t}`);
			else r && this.closeEnvelope(r, e);
		}
		this.manualKeys.clear(), this.runtime.get(t ?? "")?.manualPitch?.offset.setValueAtTime(0, e);
		for (let n of this.patch.cables) n.to.moduleId === t && n.to.portId === "pitch" && this.cvAmounts.get(n.id)?.gain.setValueAtTime(n.amount * 1200, e);
		this.manualOwned.clear(), this.manualTarget = null;
	}
	reduction(e) {
		return this.runtime.get(e)?.studio?.reduction ?? this.runtime.get(e)?.valve?.compressor.reduction ?? 0;
	}
	drumStep(e, t, n) {
		for (let { module: r, drums: i } of this.runtime.values()) {
			let a = r.type === "skitter";
			if (!(i || a) || n && r.id !== n || a && this.open[r.id] === !1) continue;
			let o = Rt(r, e).filter(([e]) => cn(r, e, this.mix)), s = In(this.patch.sequencer.bpm, this.patch.sequencer.swing, e % 16), c = (e) => e > 2 ? r.params.rollFade ?? 0 : 0;
			for (let [e, n] of o) for (let o = 0; o < n; o++) {
				let l = t + o * s / n, u = 1 - c(n) * o / n;
				a ? this.skitterHit(r, e, l, u, s / n) : i.trigger(e, this.lagged(l, r.params[`${e}Lag`]), r.params, u);
			}
			o.length && this.pulse(r.id, t, r.id);
		}
	}
	skitterTargets(e, t) {
		return this.patch.cables.filter((n) => n.from.moduleId === e && (Tt(this.patch, n.from)?.copyOf ?? n.from.portId) === t).map((e) => this.runtime.get(e.to.moduleId)).filter((e) => !!e);
	}
	skitterHit(e, t, n, r, i) {
		if (t === "synth") for (let t of this.skitterTargets(e.id, "gate")) !this.manualOwned.has(t.module.id) && (t.envelope || t.monarch || t.poly) && (this.openEnvelope(t, r, n, 60, Yi, e.id), this.closeEnvelope(t, n + i * (e.params.gate ?? .5), Yi), this.pulse(t.module.id, n, e.id));
		else for (let i of this.skitterTargets(e.id, "trig")) {
			let a = Ge[i.module.type]?.[t];
			a && i.drums && cn(i.module, a, this.mix) && (i.drums.trigger(a, this.lagged(n, i.module.params[`${a}Lag`]), i.module.params, r), this.pulse(i.module.id, n, e.id));
		}
	}
	skitterKits(e) {
		return this.patch.modules.some((t) => t.id === e && t.type === "skitter") ? this.skitterTargets(e, "trig").filter((e) => e.drums).map((e) => e.module.id) : [];
	}
	hit(e, t, n = this.context.currentTime, r = 1) {
		let i = this.runtime.get(e);
		i && cn(i.module, t, this.mix) && (i.module.type === "skitter" ? this.open[e] !== !1 && this.skitterHit(i.module, t, n, r, .12) : i.drums?.trigger(t, n, i.module.params, r));
	}
	cancelModule(e, t = this.context.currentTime) {
		let n = this.runtime.get(e);
		for (let [n, r] of this.pulses) this.pulses.set(n, r.filter((n) => n.sequencer !== e || n.time <= t));
		if (n?.drums && n.drums.cancelScheduled(t), n?.module.type === "skitter") {
			for (let n of this.skitterKits(e)) this.runtime.get(n).drums.cancelScheduled(t);
			for (let n of this.gatedBy(e)) this.manualOwned.has(n.module.id) || this.closeEnvelope(n, t, Yi);
		}
		n?.module.type === "dictator" && this.releaseDictator(e, t), n?.pitch && (this.noteOff(t, e), this.manualTarget !== e && (hr(n.pitch.offset, t), this.notes.set(e, (this.notes.get(e) ?? []).filter((e) => e.time <= t))));
	}
	cancelScheduled(e = this.context.currentTime) {
		for (let t of this.patch.modules) Jt(t.type) && this.cancelModule(t.id, e);
	}
	setMute(e) {
		this.muted = e, Hi(this.master.gain, e ? 0 : this.patch.modules.find((e) => e.type === "output").params.volume * .8, this.context.currentTime);
	}
	async flush() {
		await Promise.all([...this.runtime.values()].map((e) => Promise.all([
			e.poly?.flush?.(),
			e.studio?.flush(),
			e.monarch?.flush(),
			e.sieve?.flush(),
			e.drums?.flush?.()
		])));
	}
	dispose() {
		for (let { poly: e, studio: t, monarch: n, sieve: r } of this.runtime.values()) e?.dispose?.(), t?.dispose(), n?.dispose(), r?.dispose();
		this.master.gain.cancelScheduledValues(this.context.currentTime), this.master.gain.value = 0;
		for (let { drums: e } of this.runtime.values()) e?.dispose();
		for (let e of this.sources) e.stop();
		for (let e of this.nodes) e.disconnect();
		this.sources = [], this.nodes = [];
	}
}, $i = (e) => JSON.stringify({
	modules: e.modules.map((e) => [
		e.id,
		e.type,
		e.type === "noise" ? e.params.color : null
	]).sort(),
	cables: e.cables.map((e) => [
		e.id,
		e.from,
		e.to
	]).sort()
}), ea = class {
	patch;
	onError;
	context = null;
	graph = null;
	analyser = null;
	timer = null;
	notes = new Fn();
	target = null;
	running = /* @__PURE__ */ new Map();
	nextTime = 0;
	count = 0;
	timeline = [];
	frozen = -1;
	remaining = .04;
	muted = !1;
	mix = $t;
	suspended = !1;
	disposed = !1;
	revision = 0;
	manualRevision = 0;
	transportRevision = 0;
	moduleRevisions = /* @__PURE__ */ new Map();
	releaseSession = null;
	inputs = /* @__PURE__ */ new Map();
	velocities = /* @__PURE__ */ new Map();
	past = [];
	clickOn = !1;
	countIn = {
		left: 0,
		total: 0
	};
	clicks = /* @__PURE__ */ new Map();
	armed = null;
	take = null;
	onTake;
	heard = {
		notes: [],
		open: /* @__PURE__ */ new Map()
	};
	offset = 0;
	held = /* @__PURE__ */ new Map();
	playing = !1;
	constructor(e, t) {
		this.patch = e, this.onError = t;
	}
	get activeNote() {
		return this.notes.current;
	}
	get activeNotes() {
		return this.poly ? this.notes.entries.map(([, e]) => e) : this.notes.current === null ? [] : [this.notes.current];
	}
	get poly() {
		let e = this.patch.modules.find((e) => e.id === this.target)?.type;
		return !!e && (qt(e) || e === "dictator");
	}
	get armedId() {
		return this.armed;
	}
	get recording() {
		return !!this.take;
	}
	takeNotes(e) {
		return this.take?.id === e ? this.take.notes : null;
	}
	arm(e) {
		this.take && this.take.id !== e && this.finishTake(), this.armed = e;
	}
	async record(e = 0) {
		let t = this.armed, n = this.patch.modules.find((e) => e.id === t && e.type === "dictator");
		if (!t || !n || this.take || this.suspended || this.disposed) return !1;
		let r = this.playing, i = r ? Math.max(0, Math.round(this.tickOf() ?? this.count * 240)) : this.count * 240, a = this.take = {
			id: t,
			start: i,
			replace: n.params.mode === 1,
			grid: n.params.qrec ? x[n.params.quantize]?.[1] ?? null : null,
			notes: [],
			open: /* @__PURE__ */ new Map(),
			covered: []
		};
		return this.showTake(), r ? this.running.has(t) || await this.play(t) : await this.play(void 0, e * 16), this.take === a ? this.playing ? (this.showTake(), !0) : (this.take = null, this.graph?.setTake(null), !1) : !1;
	}
	discardTake() {
		let e = this.take;
		if (!e) return 0;
		let t = e.notes.length + e.open.size;
		return e.notes = [], e.open.clear(), e.covered = [], e.start = Math.max(e.start, Math.round(this.tickOf() ?? e.start)), this.showTake(), t;
	}
	showTake() {
		let e = this.take;
		this.graph?.setTake(e && {
			id: e.id,
			notes: e.notes,
			hideFrom: e.replace ? e.start : null,
			covered: e.replace ? e.covered : []
		});
	}
	get canCapture() {
		return this.heard.notes.length > 0;
	}
	takeHeard(e) {
		let t = O(this.heard.notes, e);
		return this.heard.notes = [], t;
	}
	setRecordOffset(e) {
		this.offset = Number.isFinite(e) ? Math.max(-100, Math.min(100, e)) : 0;
	}
	inputTick(e) {
		return this.tick(), this.tickOf((e ?? performance.now()) - this.offset);
	}
	finishTake() {
		let e = this.take;
		if (!e) return;
		let t = Math.round(this.tickOf() ?? e.start);
		for (let n of [...e.open.keys()]) this.captureEnd(n, void 0, t);
		this.take = null;
		let n = this.patch.modules.find((t) => t.id === e.id);
		n ? (this.graph?.setTake({
			id: e.id,
			notes: e.notes,
			hideFrom: null,
			covered: []
		}), this.onTake?.(e.id, e.notes, e.replace ? [...e.covered, ...re(e.start, t, C(n.params.length))] : [], e.replace)) : this.graph?.setTake(null);
	}
	captureStart(e, t, n, r) {
		let i = this.take, a = this.inputTick(r);
		if (a === null || a < i.start - Ki) return;
		let o = Math.max(i.start, Math.round(a));
		i.open.set(e, {
			start: i.grid ? te(o, i.grid) : o,
			raw: o,
			note: t,
			velocity: Math.round(n * 127)
		});
	}
	captureEnd(e, t, n) {
		let r = this.take, i = r?.open.get(e), a = this.patch.modules.find((e) => e.id === r?.id);
		if (!r || !i) return;
		r.open.delete(e);
		let o = n ?? Math.round(this.inputTick(t) ?? i.raw + 1);
		!a || r.notes.length >= 2048 || (r.notes = T([...r.notes, D(i.start, Math.max(1, o - i.raw), i.note, i.velocity, C(a.params.length))]), this.showTake());
	}
	hearStart(e, t, n, r, i) {
		let a = this.inputTick(r);
		a === null || a < -Ki || this.patch.modules.find((e) => e.id === i)?.type === "noise" || this.heard.open.set(e, {
			raw: Math.max(0, Math.round(a)),
			note: t,
			velocity: Math.round(n * 127)
		});
	}
	hearEnd(e, t) {
		let n = this.heard.open.get(e);
		if (!n) return;
		this.heard.open.delete(e);
		let r = Math.round(this.inputTick(t) ?? n.raw + 1), i = [...this.heard.notes, [
			n.raw,
			Math.max(1, r - n.raw),
			n.note,
			n.velocity
		]];
		this.heard.notes = i.filter(([e]) => e > n.raw - v).slice(-y);
	}
	reduction(e) {
		return this.ready ? this.graph.reduction(e) : 0;
	}
	get sampleRate() {
		return this.context?.sampleRate ?? 48e3;
	}
	get ready() {
		return !!this.graph && this.context?.state === "running";
	}
	get sounding() {
		let e = this.context?.currentTime ?? 0;
		for (; this.timeline.length > 1 && this.timeline[1].time <= e;) this.past.push(this.timeline.shift());
		for (; this.past.length && this.past[0].time + this.past[0].duration < e - Gi;) this.past.shift();
		return this.playing && this.timeline[0]?.time <= e ? this.timeline[0] : null;
	}
	get clock() {
		let e = this.sounding;
		return e && e.count >= 0 ? e.count : this.frozen;
	}
	get countingIn() {
		let e = this.sounding?.count;
		return e !== void 0 && e < 0 ? e : null;
	}
	clockSteps() {
		return this.sounding, [...this.past, ...this.timeline];
	}
	tickOf(e = performance.now()) {
		if (!this.context || !this.playing) return null;
		let t = this.context, n = typeof t.getOutputTimestamp == "function" ? t.getOutputTimestamp() : null, r = oe(e, n && {
			contextTime: n.contextTime ?? 0,
			performanceTime: n.performanceTime ?? 0
		}, {
			currentTime: t.currentTime,
			latency: (t.outputLatency || 0) + (t.baseLatency || 0),
			now: performance.now()
		});
		return ae(this.clockSteps(), r);
	}
	setClick(e) {
		this.clickOn = e, !e && this.context && this.cancelClicks(this.context.currentTime, !1);
	}
	click(e, t, n = !1) {
		let r = this.context;
		if (!r) return;
		let i = r.createOscillator(), a = r.createGain();
		i.frequency.value = t ? 1760 : 1320, a.gain.setValueAtTime(t ? .45 : .3, e), a.gain.exponentialRampToValueAtTime(.001, e + .04), i.connect(a).connect(r.destination), i.start(e), i.stop(e + .05), i.onended = () => {
			i.disconnect(), a.disconnect(), this.clicks.delete(i);
		}, this.clicks.set(i, n);
	}
	cancelClicks(e, t = !0) {
		for (let [n, r] of this.clicks) if (t || !r) try {
			n.stop(e);
		} catch {}
	}
	get step() {
		return this.clock < 0 ? -1 : this.clock % 16;
	}
	modulePlaying(e) {
		return this.playing && this.running.has(e);
	}
	moduleClock(e) {
		let t = this.clock;
		return this.running.has(e) && t >= this.running.get(e) ? t : -1;
	}
	pulsing(e) {
		if (!this.graph || !this.context || !this.ready) return !1;
		let t = this.context.currentTime - (this.context.outputLatency || 0), n = this.graph.lastPulse(e, t);
		return n >= 0 && t - n < Wi;
	}
	mixerLevels(e) {
		let t = {
			channels: He.map(() => -60),
			bus: [-60, -60]
		}, n = this.graph && this.ready ? this.graph.mixerLevels(e) : null;
		if (!n || !this.context) return this.held.delete(e), t;
		let r = this.context.currentTime, i = this.held.get(e), a = i ? (r - i.time) * 24 : 0, o = (e, t, n) => Math.max(e, n ? n[t] - a : -60), s = {
			channels: n.channels.map((e, t) => o(e, t, i?.levels.channels)),
			bus: n.bus.map((e, t) => o(e, t, i?.levels.bus))
		};
		return this.held.set(e, {
			time: r,
			levels: s
		}), s;
	}
	get meter() {
		if (!this.analyser || !this.ready) return 0;
		let e = new Float32Array(this.analyser.fftSize);
		return this.analyser.getFloatTimeDomainData(e), Math.min(1, Math.sqrt(e.reduce((e, t) => e + t * t, 0) / e.length) * 6);
	}
	async unlock() {
		if (this.suspended || this.disposed) return !1;
		let e = this.revision;
		if (!this.context) {
			if (typeof AudioContext > "u") throw Error("Web Audio is unavailable in this browser. Try a current Chrome or Safari.");
			this.releaseSession = zi(), this.context = new AudioContext({ latencyHint: "interactive" }), this.analyser = this.context.createAnalyser(), this.analyser.fftSize = 256, this.analyser.connect(this.context.destination);
		}
		let t = this.context;
		if (await t.resume(), this.disposed || this.suspended || e !== this.revision) return !1;
		try {
			await Gr(t);
		} catch (t) {
			if (this.disposed || this.suspended || e !== this.revision) return !1;
			throw t;
		}
		return this.disposed || this.suspended || e !== this.revision ? !1 : (this.graph || (this.graph = new Qi(this.context, this.patch, this.analyser, this.mix, (e) => {
			this.panic(), this.onError?.(e);
		}), this.graph.setMute(this.muted)), !0);
	}
	unlockForInput(e, t = !1) {
		return e === void 0 ? this.unlock() : (this.inputs.get(e)?.cancel(), new Promise((n, r) => {
			let i = () => {
				this.inputs.get(e) === a && this.inputs.delete(e);
			}, a = {
				started: !1,
				cancel: () => {
					i(), n(!1);
				},
				start: (e) => {
					a.started = !0, e.then((e) => {
						i(), n(e);
					}, (e) => {
						i(), r(e);
					});
				}
			};
			this.inputs.set(e, a), (!t || this.ready) && a.start(this.unlock());
		}));
	}
	lifted(e) {
		if (e !== void 0 && !this.inputs.has(e)) return;
		let t = [...this.inputs.values()].filter((e) => !e.started);
		if (!t.length) return;
		let n = this.unlock();
		for (let e of t) e.start(n);
	}
	update(e) {
		let t = $i(e) !== $i(this.patch);
		this.patch = e;
		for (let t of this.running.keys()) e.modules.some((e) => e.id === t && Jt(e.type)) || this.running.delete(t);
		if (this.target && !e.modules.some((e) => e.id === this.target) && this.releaseManual(), this.playing && !this.running.size && this.pause(), this.graph && this.context) {
			if (t) {
				if (this.graph.dispose(), this.graph = new Qi(this.context, e, this.analyser, this.mix, (e) => {
					this.panic(), this.onError?.(e);
				}), this.graph.setMute(this.muted), this.showTake(), this.target && this.poly) for (let [e, t] of this.notes.entries) this.graph.manualOn(this.target, t, e, this.velocityOf(e));
				else this.notes.current !== null && this.target && this.graph.manualOn(this.target, this.notes.current, void 0, this.velocityOf());
				for (let e of this.timeline) e.time >= this.context.currentTime && this.schedule([...this.running.keys()], e);
			} else this.graph.applyPatch(e), this.take || this.graph.setTake(null);
		}
	}
	async press(e, t, n = this.patch.modules[0].id, r = !1, i = 1, a) {
		if (this.suspended || this.disposed) return;
		n !== this.target && this.releaseManual(), this.target = n, this.notes.press(e, t), this.velocities.set(e, i), e !== Zi && (this.take?.id === n ? this.captureStart(e, t, i, a) : this.hearStart(e, t, i, a, n));
		let o = this.manualRevision, s = !this.ready;
		await this.unlockForInput(e, r) && o === this.manualRevision && this.target === n && (this.poly ? this.notes.has(e) ? this.graph.manualOn(n, t, e, i) : s && this.tap(n, t, e, i) : this.notes.current === null ? s && this.tap(n, t, void 0, i) : this.graph.manualOn(n, this.notes.current, void 0, this.velocityOf()));
	}
	audition(e, t, n) {
		return this.release(Zi), this.press(Zi, e, t, !1, n);
	}
	endAudition() {
		this.release(Zi);
	}
	velocityOf(e = this.notes.entries.at(-1)?.[0]) {
		return e !== void 0 && this.velocities.get(e) || 1;
	}
	tap(e, t, n, r = 1) {
		let i = this.manualRevision;
		this.graph.manualOn(e, t, n, r), setTimeout(() => {
			i === this.manualRevision && this.target === e && this.graph && (n === void 0 ? this.notes.current === null && this.graph.manualOff() : this.notes.has(n) || this.graph.manualRelease(n));
		}, 150);
	}
	release(e, t) {
		if (this.captureEnd(e, t), this.hearEnd(e, t), this.poly) {
			if (!this.notes.has(e)) return;
			this.velocities.delete(e);
			let t = this.notes.current, n = this.notes.release(e);
			n === null ? this.graph?.manualOff() : this.graph?.manualRelease(e, t === n ? void 0 : {
				note: n,
				velocity: this.velocityOf()
			});
			return;
		}
		let n = this.notes.current, r = this.notes.release(e);
		this.velocities.delete(e), n !== r && (r !== null && this.target ? this.graph?.manualOn(this.target, r, void 0, this.velocityOf()) : this.graph?.manualOff());
	}
	async hit(e, t, n, r = !1, i = 1) {
		if (this.suspended || this.disposed) return;
		let a = this.manualRevision;
		await this.unlockForInput(n, r) && a === this.manualRevision && this.graph.hit(e, t, void 0, i);
	}
	cancel(e) {
		this.inputs.get(e)?.cancel(), this.release(e);
	}
	releaseManual() {
		for (let e of [...this.take?.open.keys() ?? []]) this.captureEnd(e);
		for (let e of [...this.heard.open.keys()]) this.hearEnd(e);
		this.manualRevision++, this.notes.clear(), this.velocities.clear(), this.graph?.manualOff(), this.target = null;
		for (let e of this.inputs.values()) e.cancel();
	}
	schedule(e, t) {
		if (!this.graph) return;
		let n = e.filter((e) => this.patch.modules.some((t) => t.id === e && t.type === "performance")), r = e.filter((e) => this.patch.modules.some((t) => t.id === e && t.type === "dictator"));
		this.graph.sequence(n, t.count, t.time, t.duration), this.graph.dictatorStep(r, t.count, t.time, t.duration);
		for (let i of e) !n.includes(i) && !r.includes(i) && this.graph.drumStep(t.count, t.time, i);
	}
	startClock(e = 0) {
		this.playing = !0, this.nextTime = this.context.currentTime + Math.max(.01, this.remaining), this.timeline = [], this.past = [], this.countIn = {
			left: e,
			total: e
		}, this.tick(), this.timer = setInterval(() => this.tick(), 25);
	}
	async play(e, t = 0) {
		let n = this.transportRevision, r = this.patch.modules.filter((t) => Jt(t.type) && (!e || t.id === e)).map((e) => ({
			id: e.id,
			revision: this.moduleRevisions.get(e.id)
		}));
		if (!await this.unlock() || n !== this.transportRevision) return;
		let i = r.filter((e) => e.revision === this.moduleRevisions.get(e.id) && this.patch.modules.some((t) => t.id === e.id)).map((e) => e.id);
		if (i.length) {
			if (this.playing) {
				let e = this.timeline.filter((e) => e.time > this.context.currentTime);
				for (let t of i) if (!this.running.has(t)) {
					this.running.set(t, e[0]?.count ?? this.count);
					for (let n of e) this.schedule([t], n);
				}
			} else {
				this.running.clear();
				for (let e of i) this.running.set(e, this.count);
				this.startClock(t);
			}
		}
	}
	async rejoin() {
		if (!this.playing || this.countingIn !== null || this.countIn.left) return [];
		let e = this.patch.modules.filter((e) => Jt(e.type) && !this.running.has(e.id)).map((e) => e.id);
		return e.length ? (await this.play(), e.filter((e) => this.running.has(e))) : [];
	}
	stopModule(e) {
		let t = this.graph?.skitterKits(e) ?? [];
		if (this.moduleRevisions.set(e, (this.moduleRevisions.get(e) ?? 0) + 1), this.running.delete(e), this.graph?.cancelModule(e), t.length && this.graph && this.context) {
			let e = [...this.running.keys()].filter((e) => t.includes(e) || this.graph.skitterKits(e).some((e) => t.includes(e)));
			for (let t of this.timeline) t.time >= this.context.currentTime && this.schedule(e, t);
		}
		this.running.size || this.pause();
	}
	tick() {
		if (this.context && this.graph && this.playing) for (; this.nextTime < this.context.currentTime + .1 + 50 / 1e3;) {
			let { bpm: e, swing: t } = this.patch.sequencer;
			if (this.countIn.left) {
				let n = this.countIn.total - this.countIn.left, r = In(e, t, n);
				this.timeline.push({
					count: n - this.countIn.total,
					time: this.nextTime,
					duration: r
				}), n % 4 == 0 && this.click(this.nextTime, n % 16 == 0, !0), this.countIn.left--, this.nextTime += r;
				continue;
			}
			let n = In(e, t, this.count % 16), r = {
				count: this.count,
				time: this.nextTime,
				duration: n
			};
			this.timeline.push(r), this.clickOn && this.count % 4 == 0 && this.click(r.time, this.count % 16 == 0), this.schedule([...this.running.keys()], r), this.nextTime += n, this.count++;
		}
	}
	pause() {
		if (this.transportRevision++, !this.playing) return;
		this.finishTake();
		for (let e of [...this.heard.open.keys()]) this.hearEnd(e);
		let e = this.context.currentTime, t = this.sounding;
		t && t.count >= 0 && (this.frozen = t.count);
		let n = this.timeline.find((t) => t.time > e && t.count >= 0);
		this.countIn.left || (t?.count ?? 0) < 0 ? (this.count = this.timeline.find((e) => e.count >= 0)?.count ?? this.count, this.remaining = .04) : (this.count = n?.count ?? this.count, this.remaining = Math.max(0, (n?.time ?? this.nextTime) - e)), this.playing = !1, this.timer && clearInterval(this.timer), this.timer = null, this.timeline = [], this.past = [], this.countIn = {
			left: 0,
			total: 0
		}, this.cancelClicks(e), this.graph?.cancelScheduled();
	}
	rewind() {
		this.playing ? this.seek(0) : this.reset();
	}
	reset() {
		this.pause(), this.running.clear(), this.frozen = -1, this.count = 0, this.remaining = .04, this.heard = {
			notes: [],
			open: /* @__PURE__ */ new Map()
		};
	}
	seek(e) {
		if (this.suspended || this.disposed || !Number.isFinite(e)) return;
		let t = Math.max(0, Math.round(e));
		for (let [e, n] of this.running) this.running.set(e, Math.min(n, t));
		if (this.heard = {
			notes: [],
			open: /* @__PURE__ */ new Map()
		}, !this.playing || !this.context) {
			this.count = t, this.frozen = t, this.remaining = .04;
			return;
		}
		let n = this.context.currentTime, r = this.timeline.filter((e) => e.time > n && e.count >= 0), i = (r[0]?.count ?? this.count) * 240, a = this.take;
		if (r.length && (this.timeline = this.timeline.filter((e) => !r.includes(e)), this.nextTime = r[0].time, this.cancelClicks(n, !1), this.graph?.cancelScheduled(r[0].time)), a) {
			let e = this.patch.modules.find((e) => e.id === a.id);
			for (let e of [...a.open.keys()]) this.captureEnd(e, void 0, i);
			a.replace && e && (a.covered = [...a.covered, ...re(a.start, i, C(e.params.length))]), a.start = t * 240, this.showTake();
		}
		this.count = t, this.tick();
	}
	stop() {
		this.reset();
	}
	setMute(e) {
		this.muted = e, this.graph?.setMute(e);
	}
	setMix(e) {
		this.mix = e, this.graph?.setMix(e);
	}
	panic() {
		this.revision++, this.reset(), this.releaseManual(), this.graph?.dispose(), this.graph = null;
	}
	setSuspended(e) {
		this.suspended = e, e && this.panic();
	}
	dispose() {
		this.disposed = !0, this.panic(), this.analyser?.disconnect(), this.context && this.context.close().catch(() => {}), this.context = null, this.releaseSession?.(), this.releaseSession = null;
	}
};
async function ta(e, t = 4, n = $t) {
	let r = 44100, i = Ln(e, t, .04), a = new OfflineAudioContext(2, Math.ceil((i.duration + 2.04) * r), r);
	e.modules.some((e) => [
		"prism",
		"cohere",
		"talon",
		"brit"
	].includes(e.type) || e.params.filterModel === 1 || e.params.engine === 1) && await Gr(a);
	let o = new Qi(a, e, a.destination, n), s = e.modules.filter((e) => e.type === "performance").map((e) => e.id), c = e.modules.filter((e) => e.type === "dictator").map((e) => e.id);
	i.events.forEach(({ time: e, duration: t }, n) => {
		o.sequence(s, n, e, t), o.dictatorStep(c, n, e, t), o.drumStep(n, e);
	});
	try {
		return await o.flush(), await a.startRendering();
	} finally {
		o.dispose();
	}
}
function na(e) {
	let t = e.numberOfChannels, n = e.length * t * 2, r = new ArrayBuffer(44 + n), i = new DataView(r), a = (e, t) => {
		for (let n = 0; n < t.length; n++) i.setUint8(e + n, t.charCodeAt(n));
	};
	a(0, "RIFF"), i.setUint32(4, 36 + n, !0), a(8, "WAVE"), a(12, "fmt "), i.setUint32(16, 16, !0), i.setUint16(20, 1, !0), i.setUint16(22, t, !0), i.setUint32(24, e.sampleRate, !0), i.setUint32(28, e.sampleRate * t * 2, !0), i.setUint16(32, t * 2, !0), i.setUint16(34, 16, !0), a(36, "data"), i.setUint32(40, n, !0);
	let o = Array.from({ length: t }, (t, n) => e.getChannelData(n));
	for (let n = 0; n < e.length; n++) for (let e = 0; e < t; e++) {
		let r = Math.max(-1, Math.min(1, o[e][n]));
		i.setInt16(44 + (n * t + e) * 2, Math.round(r * (r < 0 ? 32768 : 32767)), !0);
	}
	return r;
}
var $ = {
	app: "_app_1w5tp_1",
	toolbar: "_toolbar_1w5tp_26",
	brand: "_brand_1w5tp_27",
	brandMark: "_brandMark_1w5tp_31",
	toolbarActions: "_toolbarActions_1w5tp_32",
	audioButton: "_audioButton_1w5tp_34",
	statusLed: "_statusLed_1w5tp_35",
	rackLight: "_rackLight_1w5tp_35",
	deviceLed: "_deviceLed_1w5tp_35",
	patchBar: "_patchBar_1w5tp_41",
	patchRow: "_patchRow_1w5tp_42",
	barGroup: "_barGroup_1w5tp_43",
	rackActions: "_rackActions_1w5tp_46",
	patchIdentity: "_patchIdentity_1w5tp_49",
	patchName: "_patchName_1w5tp_50",
	nameField: "_nameField_1w5tp_53",
	dirtyMark: "_dirtyMark_1w5tp_56",
	saveStatus: "_saveStatus_1w5tp_58",
	saveLed: "_saveLed_1w5tp_59",
	visuallyHidden: "_visuallyHidden_1w5tp_62",
	historyActions: "_historyActions_1w5tp_63",
	icon: "_icon_1w5tp_64",
	addButton: "_addButton_1w5tp_66",
	presetsButton: "_presetsButton_1w5tp_67",
	flipButton: "_flipButton_1w5tp_71",
	rackHeading: "_rackHeading_1w5tp_72",
	rack: "_rack_1w5tp_35",
	module: "_module_1w5tp_75",
	revealFlash: "_revealFlash_1w5tp_1",
	moduleHeader: "_moduleHeader_1w5tp_92",
	moduleIdentity: "_moduleIdentity_1w5tp_93",
	moduleName: "_moduleName_1w5tp_94",
	moduleSubtitle: "_moduleSubtitle_1w5tp_95",
	moduleTools: "_moduleTools_1w5tp_96",
	moduleNumber: "_moduleNumber_1w5tp_97",
	screw: "_screw_1w5tp_99",
	screwTL: "_screwTL_1w5tp_101",
	screwTR: "_screwTR_1w5tp_101",
	screwBL: "_screwBL_1w5tp_101",
	screwBR: "_screwBR_1w5tp_101",
	moduleBody: "_moduleBody_1w5tp_102",
	controls: "_controls_1w5tp_103",
	knobControl: "_knobControl_1w5tp_104",
	controlLabel: "_controlLabel_1w5tp_105",
	dial: "_dial_1w5tp_106",
	dialTicks: "_dialTicks_1w5tp_107",
	dialCap: "_dialCap_1w5tp_108",
	knobValue: "_knobValue_1w5tp_111",
	selectControl: "_selectControl_1w5tp_112",
	choiceGlyph: "_choiceGlyph_1w5tp_114",
	moduleDecoration: "_moduleDecoration_1w5tp_115",
	deviceLabel: "_deviceLabel_1w5tp_117",
	envelopeGraphic: "_envelopeGraphic_1w5tp_119",
	drumPads: "_drumPads_1w5tp_121",
	drumLane: "_drumLane_1w5tp_123",
	laneLevel: "_laneLevel_1w5tp_124",
	voiceButton: "_voiceButton_1w5tp_127",
	pads: "_pads_1w5tp_128",
	padGroup: "_padGroup_1w5tp_129",
	pad: "_pad_1w5tp_128",
	euclid: "_euclid_1w5tp_137",
	euclidHeading: "_euclidHeading_1w5tp_139",
	euclidCell: "_euclidCell_1w5tp_140",
	orbitRings: "_orbitRings_1w5tp_141",
	orbitPath: "_orbitPath_1w5tp_143",
	mixButtons: "_mixButtons_1w5tp_145",
	muteToggle: "_muteToggle_1w5tp_147",
	soloToggle: "_soloToggle_1w5tp_148",
	clearToggle: "_clearToggle_1w5tp_149",
	swapToggle: "_swapToggle_1w5tp_149",
	sequenceBody: "_sequenceBody_1w5tp_151",
	step: "_step_1w5tp_151",
	stepCell: "_stepCell_1w5tp_153",
	sequenceTop: "_sequenceTop_1w5tp_155",
	lcd: "_lcd_1w5tp_156",
	lcdDots: "_lcdDots_1w5tp_159",
	numberField: "_numberField_1w5tp_160",
	fader: "_fader_1w5tp_163",
	swingField: "_swingField_1w5tp_171",
	transport: "_transport_1w5tp_173",
	playButton: "_playButton_1w5tp_174",
	transportCaption: "_transportCaption_1w5tp_176",
	steps: "_steps_1w5tp_177",
	stepLed: "_stepLed_1w5tp_179",
	stepNumber: "_stepNumber_1w5tp_183",
	sequenceHint: "_sequenceHint_1w5tp_184",
	lcdStack: "_lcdStack_1w5tp_186",
	stepTransport: "_stepTransport_1w5tp_187",
	transportKeys: "_transportKeys_1w5tp_188",
	stepEditButton: "_stepEditButton_1w5tp_190",
	stepEditor: "_stepEditor_1w5tp_193",
	meters: "_meters_1w5tp_195",
	meterRow: "_meterRow_1w5tp_196",
	muteButton: "_muteButton_1w5tp_197",
	rackBottom: "_rackBottom_1w5tp_198",
	aboutButton: "_aboutButton_1w5tp_199",
	keyboardPanel: "_keyboardPanel_1w5tp_200",
	keyboardTop: "_keyboardTop_1w5tp_201",
	keyHint: "_keyHint_1w5tp_201",
	keyControls: "_keyControls_1w5tp_203",
	octaveControls: "_octaveControls_1w5tp_204",
	keysToggle: "_keysToggle_1w5tp_204",
	piano: "_piano_1w5tp_205",
	whiteKey: "_whiteKey_1w5tp_207",
	blackKey: "_blackKey_1w5tp_209",
	toastAnchor: "_toastAnchor_1w5tp_212",
	toast: "_toast_1w5tp_212",
	library: "_library_1w5tp_215",
	libraryHeading: "_libraryHeading_1w5tp_216",
	libraryGrid: "_libraryGrid_1w5tp_217",
	presetBrowser: "_presetBrowser_1w5tp_219",
	presetActions: "_presetActions_1w5tp_220",
	sectionLabel: "_sectionLabel_1w5tp_221",
	presetList: "_presetList_1w5tp_222",
	presetRow: "_presetRow_1w5tp_223",
	presetLoad: "_presetLoad_1w5tp_225",
	presetConfirm: "_presetConfirm_1w5tp_228",
	dangerButton: "_dangerButton_1w5tp_229",
	presetEmpty: "_presetEmpty_1w5tp_230",
	factoryCategory: "_factoryCategory_1w5tp_232",
	factoryCategoryLabel: "_factoryCategoryLabel_1w5tp_232",
	factoryGrid: "_factoryGrid_1w5tp_233",
	saveDialog: "_saveDialog_1w5tp_234",
	saveTitle: "_saveTitle_1w5tp_235",
	saveWarning: "_saveWarning_1w5tp_237",
	saveNote: "_saveNote_1w5tp_238",
	saveButtons: "_saveButtons_1w5tp_239",
	saveButton: "_saveButton_1w5tp_239",
	miniDevice: "_miniDevice_1w5tp_240",
	routingBar: "_routingBar_1w5tp_241",
	legend: "_legend_1w5tp_242",
	portGroups: "_portGroups_1w5tp_244",
	portGroup: "_portGroup_1w5tp_244",
	portHeading: "_portHeading_1w5tp_244",
	portRow: "_portRow_1w5tp_244",
	socketControl: "_socketControl_1w5tp_244",
	jacks: "_jacks_1w5tp_246",
	socket: "_socket_1w5tp_244",
	trim: "_trim_1w5tp_249",
	cables: "_cables_1w5tp_252",
	cableHits: "_cableHits_1w5tp_252",
	cable: "_cable_1w5tp_252",
	cableLine: "_cableLine_1w5tp_256",
	cableShadow: "_cableShadow_1w5tp_256",
	cableHit: "_cableHit_1w5tp_252",
	loosePlug: "_loosePlug_1w5tp_258",
	helpBackdrop: "_helpBackdrop_1w5tp_260",
	help: "_help_1w5tp_260",
	helpHeading: "_helpHeading_1w5tp_260",
	about: "_about_1w5tp_199",
	aboutFacts: "_aboutFacts_1w5tp_262",
	aboutTagline: "_aboutTagline_1w5tp_262",
	aboutCopyright: "_aboutCopyright_1w5tp_262",
	exportControls: "_exportControls_1w5tp_269",
	hitLed: "_hitLed_1w5tp_269",
	globalControls: "_globalControls_1w5tp_305",
	globalTransport: "_globalTransport_1w5tp_306",
	playStoppedButton: "_playStoppedButton_1w5tp_310",
	rewindButton: "_rewindButton_1w5tp_310",
	clearAllButton: "_clearAllButton_1w5tp_311",
	positionField: "_positionField_1w5tp_316",
	globalPosition: "_globalPosition_1w5tp_317",
	clickButton: "_clickButton_1w5tp_319",
	clickLed: "_clickLed_1w5tp_319",
	keyboardTarget: "_keyboardTarget_1w5tp_321",
	midiToggle: "_midiToggle_1w5tp_323",
	midiLed: "_midiLed_1w5tp_324",
	routingHint: "_routingHint_1w5tp_326",
	moduleNameButton: "_moduleNameButton_1w5tp_328",
	moduleTransport: "_moduleTransport_1w5tp_329",
	clearPatternButton: "_clearPatternButton_1w5tp_333",
	performancePads: "_performancePads_1w5tp_337",
	orbitEditor: "_orbitEditor_1w5tp_343",
	orbitVoiceEditor: "_orbitVoiceEditor_1w5tp_344",
	orbitEditorHeading: "_orbitEditorHeading_1w5tp_345",
	orbitSteps: "_orbitSteps_1w5tp_349",
	groupControls: "_groupControls_1w5tp_357",
	grMeter: "_grMeter_1w5tp_374",
	grUnit: "_grUnit_1w5tp_377",
	grNeedle: "_grNeedle_1w5tp_378",
	eqGraphic: "_eqGraphic_1w5tp_393",
	countInField: "_countInField_1w5tp_403",
	soundEditor: "_soundEditor_1w5tp_437",
	editorHeading: "_editorHeading_1w5tp_438",
	fmDisplay: "_fmDisplay_1w5tp_441",
	operatorTabs: "_operatorTabs_1w5tp_443",
	console: "_console_1w5tp_481",
	channelStrip: "_channelStrip_1w5tp_482",
	mixBus: "_mixBus_1w5tp_482",
	scribble: "_scribble_1w5tp_484",
	channelSource: "_channelSource_1w5tp_486",
	faderValue: "_faderValue_1w5tp_489",
	faderBay: "_faderBay_1w5tp_492",
	faderScale: "_faderScale_1w5tp_493",
	faderSlot: "_faderSlot_1w5tp_495",
	faderCap: "_faderCap_1w5tp_497",
	levelMeter: "_levelMeter_1w5tp_500",
	processorHint: "_processorHint_1w5tp_518",
	britPanel: "_britPanel_1w5tp_535",
	britSection: "_britSection_1w5tp_536",
	britWell: "_britWell_1w5tp_538",
	panelLegend: "_panelLegend_1w5tp_539",
	marconi: "_marconi_1w5tp_543",
	marconiRing: "_marconiRing_1w5tp_543",
	marconiSkirt: "_marconiSkirt_1w5tp_548",
	marconiFlutes: "_marconiFlutes_1w5tp_549",
	marconiDome: "_marconiDome_1w5tp_551",
	marconiPointer: "_marconiPointer_1w5tp_553",
	ringPointer: "_ringPointer_1w5tp_558",
	britCurve: "_britCurve_1w5tp_561",
	britSwitch: "_britSwitch_1w5tp_563",
	britLamp: "_britLamp_1w5tp_565",
	talonPanel: "_talonPanel_1w5tp_569",
	talonSection: "_talonSection_1w5tp_570",
	talonWell: "_talonWell_1w5tp_572",
	talonKnob: "_talonKnob_1w5tp_573",
	talonGrip: "_talonGrip_1w5tp_576",
	talonCap: "_talonCap_1w5tp_577",
	talonIndex: "_talonIndex_1w5tp_578",
	talonLamps: "_talonLamps_1w5tp_581",
	talonLed: "_talonLed_1w5tp_586",
	talonLatches: "_talonLatches_1w5tp_588",
	talonPush: "_talonPush_1w5tp_589",
	talonMeter: "_talonMeter_1w5tp_591",
	talonSwitch: "_talonSwitch_1w5tp_598",
	talonLamp: "_talonLamp_1w5tp_581",
	talonOutput: "_talonOutput_1w5tp_602",
	rollBrush: "_rollBrush_1w5tp_617",
	orbitDevice: "_orbitDevice_1w5tp_681",
	engineSwitch: "_engineSwitch_1w5tp_698",
	engineCaption: "_engineCaption_1w5tp_700",
	togglePlate: "_togglePlate_1w5tp_702",
	toggleLegend: "_toggleLegend_1w5tp_704",
	toggle: "_toggle_1w5tp_702",
	toggleSlot: "_toggleSlot_1w5tp_714",
	toggleKnob: "_toggleKnob_1w5tp_717",
	toggleBrim: "_toggleBrim_1w5tp_720",
	toggleRib: "_toggleRib_1w5tp_722",
	toggleCap: "_toggleCap_1w5tp_724",
	dictatorBody: "_dictatorBody_1w5tp_743",
	armButton: "_armButton_1w5tp_747",
	armLed: "_armLed_1w5tp_748",
	recordLed: "_recordLed_1w5tp_748",
	recordBlink: "_recordBlink_1w5tp_1",
	quantizeRow: "_quantizeRow_1w5tp_752",
	lampButton: "_lampButton_1w5tp_755",
	lampLed: "_lampLed_1w5tp_756",
	noteStripFrame: "_noteStripFrame_1w5tp_758",
	stripSeek: "_stripSeek_1w5tp_758",
	noteStrip: "_noteStrip_1w5tp_758",
	playhead: "_playhead_1w5tp_761",
	dictatorActions: "_dictatorActions_1w5tp_762",
	playsControl: "_playsControl_1w5tp_763",
	offsetControl: "_offsetControl_1w5tp_763",
	midiTracks: "_midiTracks_1w5tp_764",
	recordButton: "_recordButton_1w5tp_765",
	editButton: "_editButton_1w5tp_770",
	pianoRoll: "_pianoRoll_1w5tp_771",
	rollTools: "_rollTools_1w5tp_772",
	rollToolGroup: "_rollToolGroup_1w5tp_773",
	rollStatus: "_rollStatus_1w5tp_777",
	rollClose: "_rollClose_1w5tp_778",
	rollScroller: "_rollScroller_1w5tp_779",
	rollCanvas: "_rollCanvas_1w5tp_780",
	rollRulerRow: "_rollRulerRow_1w5tp_781",
	rollCorner: "_rollCorner_1w5tp_782",
	rollLaneLabel: "_rollLaneLabel_1w5tp_782",
	rollRuler: "_rollRuler_1w5tp_781",
	rollBody: "_rollBody_1w5tp_784",
	rollKeys: "_rollKeys_1w5tp_785",
	rollWhite: "_rollWhite_1w5tp_786",
	rollBlack: "_rollBlack_1w5tp_786",
	rollGrid: "_rollGrid_1w5tp_788",
	rollShade: "_rollShade_1w5tp_790",
	rollRowLine: "_rollRowLine_1w5tp_790",
	rollOctave: "_rollOctave_1w5tp_790",
	rollBar: "_rollBar_1w5tp_791",
	rollBeat: "_rollBeat_1w5tp_791",
	rollStep: "_rollStep_1w5tp_791",
	rollNote: "_rollNote_1w5tp_792",
	rollTake: "_rollTake_1w5tp_793",
	rollCursor: "_rollCursor_1w5tp_794",
	rollMarquee: "_rollMarquee_1w5tp_795",
	rollLaneRow: "_rollLaneRow_1w5tp_797",
	rollLane: "_rollLane_1w5tp_782"
};
// src/components/Knob.tsx
function ra(e, t) {
	return e.choices ? e.choices[t] ?? "" : e.unit === "ms" ? t ? `${t > 0 ? "+" : "−"}${Math.abs(t)}ms` : "On beat" : e.unit === "Hz" && t >= 1e3 ? `${(t / 1e3).toFixed(1)}k` : e.unit === "s" && t < .001 ? `${Math.round(t * 1e6)}μs` : e.unit === "s" && t < 1 ? `${e.step < .001 ? Number((t * 1e3).toFixed(2)) : Math.round(t * 1e3)}ms` : `${Number(t.toFixed(2))}${e.unit ?? ""}`;
}
function ia({ param: e, value: t, onChange: n, prefix: r = "", format: i, disabled: a = !1, travel: o = 130 }) {
	let s = u(null), c = Mn(e, t), l = Math.max(4, Math.ceil(-Math.log10(e.step)));
	function d(t) {
		let r = Math.max(0, Math.min(1, t)), i = e.logarithmic ? e.min * (e.max / e.min) ** r : e.min + r * (e.max - e.min);
		n(Math.max(e.min, Math.min(e.max, Number((Math.round(i / e.step) * e.step).toFixed(l)))));
	}
	function f(e) {
		e.isPrimary && e.button === 0 && (s.current = {
			y: e.clientY,
			fraction: c
		}, e.currentTarget.setPointerCapture(e.pointerId), e.preventDefault());
	}
	let p = i ? i(t) : ra(e, t);
	return {
		props: {
			role: "slider",
			tabIndex: a ? -1 : 0,
			"aria-disabled": a || void 0,
			"aria-label": `${r} ${e.label}`.trim(),
			"aria-valuemin": e.min,
			"aria-valuemax": e.max,
			"aria-valuenow": t,
			"aria-valuetext": p,
			onPointerDown: a ? void 0 : f,
			onPointerMove: (e) => {
				s.current && d(s.current.fraction + (s.current.y - e.clientY) / o);
			},
			onPointerUp: () => {
				s.current = null;
			},
			onPointerCancel: () => {
				s.current = null;
			},
			onDoubleClick: a ? void 0 : () => n(e.initial),
			onKeyDown: (r) => {
				!a && [
					"ArrowUp",
					"ArrowRight",
					"ArrowDown",
					"ArrowLeft",
					"Home",
					"End"
				].includes(r.key) && (r.preventDefault(), r.key === "Home" ? n(e.min) : r.key === "End" ? n(e.max) : e.logarithmic ? d(c + (["ArrowUp", "ArrowRight"].includes(r.key) ? .025 : -.025)) : n(Math.max(e.min, Math.min(e.max, Number((t + (["ArrowUp", "ArrowRight"].includes(r.key) ? e.step : -e.step)).toFixed(l))))));
			}
		},
		fraction: c,
		display: p
	};
}
function aa({ param: e, value: t, onChange: n, prefix: r = "", format: i, trim: a = !1, disabled: o = !1, caption: s }) {
	let { props: c, fraction: l, display: u } = ia({
		param: e,
		value: t,
		onChange: n,
		prefix: r,
		format: i,
		disabled: o
	}), d = /* @__PURE__ */ h("div", {
		className: a ? `${$.dial} ${$.trim}` : $.dial,
		...c,
		title: a ? `${e.label} ${u}` : void 0,
		children: [/* @__PURE__ */ m("span", { className: $.dialTicks }), /* @__PURE__ */ m("span", {
			className: $.dialCap,
			style: { transform: `rotate(${-135 + l * 270}deg)` },
			children: /* @__PURE__ */ m("span", {})
		})]
	});
	return a ? d : /* @__PURE__ */ h("div", {
		className: $.knobControl,
		title: e.hint,
		children: [
			/* @__PURE__ */ m("span", {
				className: $.controlLabel,
				children: s ?? e.label
			}),
			d,
			/* @__PURE__ */ m("span", {
				className: $.knobValue,
				children: u
			})
		]
	});
}
// src/components/CableLayer.tsx
var oa = (e) => `${e.moduleId}:${e.portId}`, sa = (e, t) => {
	let n = Math.min(140, Math.abs(e.y - t.y) * .2 + Math.abs(e.x - t.x) * .25 + 40);
	return `M${e.x},${e.y} C${e.x + 12},${e.y + n} ${t.x - 12},${t.y + n} ${t.x},${t.y}`;
};
function ca({ patch: e, rackRef: t, selected: n, onSelect: r, drag: i }) {
	let [a, o] = d({}), [c, l] = d(null);
	s(() => {
		let e = t.current;
		if (!e) return;
		function n() {
			let t = e.getBoundingClientRect(), n = {};
			e.querySelectorAll("[data-port-key]").forEach((r) => {
				let i = r.getBoundingClientRect();
				n[r.dataset.portKey] = {
					x: i.x - t.x + i.width / 2 + e.scrollLeft,
					y: i.y - t.y + i.height / 2 + e.scrollTop
				};
			}), o(n);
		}
		n();
		let r = new ResizeObserver(n);
		return r.observe(e), e.querySelectorAll("article").forEach((e) => r.observe(e)), window.addEventListener("resize", n), () => {
			r.disconnect(), window.removeEventListener("resize", n);
		};
	}, [e.modules, t]);
	let u = (t) => {
		let n = e.modules.find((e) => e.id === t.moduleId), r = Y[n.type].ports, i = Tt(e, t), a = Et(r, i), o = n.type === "mixer" && i.direction === "in" ? `Channel ${i.id.toUpperCase()}: ${fn(e, n.id, i.id).source}` : i.label;
		return `${Y[n.type].name} ${o}${a && a > 1 ? ` ${a}` : ""}`;
	}, f = i && Tt(e, i.anchor), g = i && a[oa(i.anchor)], _ = i && (i.target ? a[oa(i.target)] : i.point), v = f && g && _ ? f.direction === "out" ? sa(g, _) : sa(_, g) : null, y = e.cables.flatMap((t) => {
		let n = a[oa(t.from)], r = a[oa(t.to)];
		return n && r && t.id !== i?.cableId ? [{
			cable: t,
			path: sa(n, r),
			kind: Tt(e, t.from).kind
		}] : [];
	});
	return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("svg", {
		className: $.cableHits,
		"aria-label": "Patch cables",
		children: y.map(({ cable: e, path: t }) => /* @__PURE__ */ m("path", {
			className: $.cableHit,
			d: t,
			role: "button",
			tabIndex: 0,
			"aria-label": `Cable from ${u(e.from)} to ${u(e.to)}`,
			onClick: () => r(e.id),
			onPointerEnter: () => l(e.id),
			onPointerLeave: () => l((t) => t === e.id ? null : t),
			onKeyDown: (t) => {
				(t.key === "Enter" || t.key === " ") && (t.preventDefault(), r(e.id));
			}
		}, e.id))
	}), /* @__PURE__ */ h("svg", {
		className: $.cables,
		"aria-hidden": "true",
		children: [y.map(({ cable: e, path: t, kind: r }) => /* @__PURE__ */ h("g", {
			className: $.cable,
			"data-kind": r,
			"data-selected": n === e.id,
			"data-hovered": c === e.id,
			children: [/* @__PURE__ */ m("path", {
				className: $.cableShadow,
				d: t
			}), /* @__PURE__ */ m("path", {
				className: $.cableLine,
				d: t
			})]
		}, e.id)), v && /* @__PURE__ */ h("g", {
			className: $.cable,
			"data-kind": f.kind,
			"data-held": "true",
			"data-snapped": !!i.target,
			"data-invalid": !!i.error,
			children: [
				/* @__PURE__ */ m("path", {
					className: $.cableShadow,
					d: v
				}),
				/* @__PURE__ */ m("path", {
					className: $.cableLine,
					d: v
				}),
				!i.target && /* @__PURE__ */ m("circle", {
					className: $.loosePlug,
					cx: _.x,
					cy: _.y,
					r: 8
				})
			]
		})]
	})] });
}
// src/audio/studio-processor.js
var la = [
	1e-4,
	3e-4,
	.001,
	.003,
	.01,
	.03
], ua = [
	.1,
	.3,
	.6,
	1.2
], da = [
	1,
	2,
	3,
	4,
	6,
	10,
	20,
	100
], fa = [
	35,
	60,
	110,
	220
], pa = [
	360,
	700,
	1600,
	3200,
	4800,
	7200
], ma = [
	0,
	50,
	80,
	160,
	300
], ha = (e) => 10 ** (e / 20), ga = [
	1,
	0,
	0,
	0,
	0
];
function _a(e, t, n, r, i) {
	if (!t) return ga.slice();
	let a = 2 * Math.PI * Math.min(t, i * .45) / i, o = Math.cos(a), s = Math.sin(a), c = 10 ** (n / 40), l = s / (2 * r), u = s * Math.sqrt(2 * c), d, f, p, m, h, g;
	if (e === "pole") {
		let e = Math.tan(a / 2);
		return [
			1 / (1 + e),
			-1 / (1 + e),
			0,
			(e - 1) / (e + 1),
			0
		];
	}
	return e === "highpass" ? [d, f, p, m, h, g] = [
		(1 + o) / 2,
		-(1 + o),
		(1 + o) / 2,
		1 + l,
		-2 * o,
		1 - l
	] : e === "bell" ? [d, f, p, m, h, g] = [
		1 + l * c,
		-2 * o,
		1 - l * c,
		1 + l / c,
		-2 * o,
		1 - l / c
	] : e === "low" ? [d, f, p, m, h, g] = [
		c * (c + 1 - (c - 1) * o + u),
		2 * c * (c - 1 - (c + 1) * o),
		c * (c + 1 - (c - 1) * o - u),
		c + 1 + (c - 1) * o + u,
		-2 * (c - 1 + (c + 1) * o),
		c + 1 + (c - 1) * o - u
	] : [d, f, p, m, h, g] = [
		c * (c + 1 + (c - 1) * o + u),
		-2 * c * (c - 1 + (c + 1) * o),
		c * (c + 1 + (c - 1) * o - u),
		c + 1 - (c - 1) * o + u,
		2 * (c - 1 - (c + 1) * o),
		c + 1 - (c - 1) * o - u
	], [
		d / m,
		f / m,
		p / m,
		h / m,
		g / m
	];
}
function va(e, t) {
	let n = ma[e.hpf] ?? 0;
	return [
		_a("pole", n, 0, 1, t),
		_a("highpass", n, 0, 1, t),
		_a("low", fa[e.lfFreq] ?? 110, e.lfGain, .7, t),
		_a("bell", pa[e.midFreq] ?? 1600, e.midGain, .75, t),
		_a("high", 12e3, e.hfGain, .7, t)
	];
}
function ya(e, t, n = 48e3) {
	if (e.active) return 0;
	let r = 2 * Math.PI * t / n, i = (e, t, n) => Math.hypot(e + t * Math.cos(r) + n * Math.cos(2 * r), t * Math.sin(r) + n * Math.sin(2 * r));
	return va(e, n).reduce((e, [t, n, r, a, o]) => e + 20 * Math.log10(i(t, n, r) / i(1, a, o)), 0);
}
function ba(e, t) {
	let n, r, i;
	return e === "cohere" ? (n = [
		2,
		4,
		10
	][t.ratio] ?? 4, r = t.threshold + [
		-3,
		0,
		2
	][t.ratio], i = [
		9,
		6,
		3
	][t.ratio]) : (n = da[t.ratio] ?? 6, r = [
		-18,
		-26,
		-24,
		-22,
		-20,
		-18,
		-16,
		-18
	][t.ratio], i = [
		0,
		15,
		12,
		9,
		6,
		4,
		2,
		3
	][t.ratio], t.fierce && (n = Math.max(12, n * 2), r -= 3, i = 2)), [
		1 - 1 / n,
		r,
		i
	];
}
function xa(e, t, n, r) {
	if (!t) return 0;
	let i = e - n;
	return i <= -r / 2 ? 0 : i >= r / 2 ? -i * t : -t * (i + r / 2) ** 2 / (2 * r);
}
var Sa = class {
	constructor(e) {
		this.c = ga.slice(), this.target = ga.slice(), this.z1 = 0, this.z2 = 0, this.smooth = 1 - Math.exp(-1 / (e * .008));
	}
	set(e, t) {
		this.target = e, t && (this.c = e.slice());
	}
	run(e) {
		let t = this.c;
		for (let e = 0; e < 5; e++) t[e] += (this.target[e] - t[e]) * this.smooth;
		let n = t[0] * e + this.z1;
		return this.z1 = t[1] * e - t[3] * n + this.z2, this.z2 = t[2] * e - t[4] * n, n;
	}
}, Ca = Float64Array.from({ length: 49 }, (e, t) => {
	let n = t - 24, r = .1125;
	return (n ? Math.sin(2 * Math.PI * r * n) / (Math.PI * n) : 2 * r) * (.42 - .5 * Math.cos(2 * Math.PI * t / 48) + .08 * Math.cos(4 * Math.PI * t / 48));
}), wa = Ca.reduce((e, t) => e + t, 0);
for (let e = 0; e < Ca.length; e++) Ca[e] /= wa;
var Ta = class {
	constructor() {
		this.buffer = /* @__PURE__ */ new Float64Array(49), this.index = 0;
	}
	push(e) {
		this.buffer[this.index] = e, this.index = (this.index + 1) % 49;
	}
	run(e) {
		this.buffer[this.index] = e;
		let t = 0, n = this.index;
		for (let e = 0; e < 49; e++) t += Ca[e] * this.buffer[n], --n < 0 && (n = 48);
		return this.index = (this.index + 1) % 49, t;
	}
}, Ea = class {
	constructor() {
		this.buffer = /* @__PURE__ */ new Float64Array(13), this.index = 0;
	}
	push(e) {
		this.index = this.index ? this.index - 1 : 12, this.buffer[this.index] = e;
	}
	run(e) {
		let t = 0, n = this.index;
		for (let r = e; r < 49; r += 4) t += Ca[r] * this.buffer[n], ++n > 12 && (n = 0);
		return t;
	}
}, Da = class {
	constructor() {
		this.buffer = /* @__PURE__ */ new Float64Array(12), this.index = 0;
	}
	run(e) {
		let t = this.buffer[this.index];
		return this.buffer[this.index] = e, this.index = (this.index + 1) % this.buffer.length, t;
	}
}, Oa = class {
	constructor(e) {
		this.up = new Ea(), this.down = new Ta(), this.clean = new Da(), this.previous = 0, this.blocked = 0, this.dc = Math.exp(-2 * Math.PI * 5 / e);
	}
	run(e, t, n) {
		let r = 0, i = Math.tanh(n), a = t * (1 - i * i);
		this.up.push(e * 4);
		for (let e = 0; e < 4; e++) {
			let o = this.up.run(e), s = (Math.tanh(t * o + n) - i) / a;
			e === 0 ? r = this.down.run(s - o) : this.down.push(s - o);
		}
		return this.blocked = r - this.previous + this.dc * this.blocked, this.previous = r, this.clean.run(e) + this.blocked;
	}
}, ka = class {
	constructor(e, t) {
		this.type = e, this.rate = t, this.params = null, this.events = [], this.disposed = !1, this.reduction = 0, this.gain = [0, 0], this.memory = [0, 0], this.input = 1, this.output = 1, this.wet = 1, this.drive = 0, this.smooth = 1 - Math.exp(-1 / (t * .008)), this.channels = Array.from({ length: 2 }, () => ({
			filters: Array.from({ length: 5 }, () => new Sa(t)),
			hp: new Sa(t),
			emphasis: new Sa(t),
			audioPole: new Sa(t),
			audioHp: new Sa(t),
			color: new Oa(t),
			dry: new Da(),
			clean: new Da(),
			amount: .15,
			bias: 0
		}));
	}
	enqueue(e) {
		this.events.push(e), this.events.sort((e, t) => e.time - t.time);
	}
	configure(e) {
		let t = !this.params;
		this.params = { ...e }, this.inputTarget = ha(this.type === "talon" ? e.input : 0), this.outputTarget = ha(e.output), this.wetTarget = +!e.active, this.driveTarget = e.drive ?? 0, t && (this.input = this.inputTarget, this.output = this.outputTarget, this.wet = this.wetTarget, this.drive = this.driveTarget), this.type !== "brit" && (this.curveTarget = ba(this.type, e), this.linkTarget = this.type === "cohere" ? 1 : e.link, this.attackTarget = this.type === "cohere" ? la[e.attack] : e.attack, this.releaseTarget = this.type === "cohere" ? ua[e.release] ?? .3 : e.release, t && (this.curve = this.curveTarget.slice(), this.link = this.linkTarget, this.attack = this.attackTarget, this.release = this.releaseTarget));
		for (let n of this.channels) {
			this.type === "brit" && va(e, this.rate).forEach((e, r) => n.filters[r].set(e, t));
			let r = this.type === "cohere" ? [
				0,
				30,
				60,
				106,
				125,
				185
			][e.scHpf] : e.detectorHp ? 80 : 0;
			n.hp.set(_a("highpass", r, 0, Math.SQRT1_2, this.rate), t), n.emphasis.set(_a("bell", 6e3, e.detectorBand ? 10 : 0, 1, this.rate), t), n.audioPole.set(_a("pole", e.audioHp ? 49.01 : 0, 0, 1, this.rate), t), n.audioHp.set(_a("highpass", e.audioHp ? 44.915 : 0, 0, .691, this.rate), t), t && this.type === "talon" && (n.amount = [
				.15,
				.8,
				1.5
			][e.color], n.bias = e.color === 1 ? .3 : 0);
		}
	}
	envelope(e, t) {
		let n = this.params, r = xa(e, this.curve[0], this.curve[1], this.curve[2]), i = this.gain[t];
		this.memory[t] += (Math.max(0, -i) - this.memory[t]) * (1 - Math.exp(-1 / (this.rate * .6)));
		let a = this.release;
		this.type === "cohere" && n.release === 4 && (a = .1 + Math.min(1.1, this.memory[t] * .09)), this.type === "talon" && (n.ratio === 5 ? a = Math.min(20, this.release * (1 + this.memory[t] * .9)) : n.ratio === 7 ? a *= .45 + Math.min(1.5, Math.max(0, -i) / 15) : a *= [
			1,
			1.15,
			1.05,
			1,
			.9,
			1,
			.8,
			1
		][n.ratio], n.ratio !== 5 && (a = Math.min(3.5, a)), n.fierce && (a *= .65));
		let o = r < i ? this.attack : a;
		return this.gain[t] += (r - i) * (1 - Math.exp(-1 / (o * this.rate))), ha(this.gain[t]);
	}
	render(e, t, n = 0) {
		if (this.disposed) {
			t.forEach((e) => e.fill(0));
			return;
		}
		let r = t[0].length;
		for (let i = 0; i < r; i++) {
			let r = (n + i) / this.rate;
			for (; this.events.length && this.events[0].time <= r;) this.configure(this.events.shift().params);
			if (!this.params) {
				t.forEach((e) => {
					e[i] = 0;
				});
				continue;
			}
			let a = this.params;
			this.input += (this.inputTarget - this.input) * this.smooth, this.output += (this.outputTarget - this.output) * this.smooth, this.wet += (this.wetTarget - this.wet) * this.smooth, this.drive += (this.driveTarget - this.drive) * this.smooth;
			let o = e[0]?.[i] ?? 0, s = e[1]?.[i] ?? o, c = o * this.input, l = s * this.input, u = 1, d = 1;
			if (this.type !== "brit") {
				for (let e = 0; e < 3; e++) this.curve[e] += (this.curveTarget[e] - this.curve[e]) * this.smooth;
				this.link += (this.linkTarget - this.link) * this.smooth, this.attack += (this.attackTarget - this.attack) * this.smooth, this.release += (this.releaseTarget - this.release) * this.smooth;
				let e = this.channels[0], t = this.channels[1], n = 20 * Math.log10(Math.max(1e-12, Math.abs(e.emphasis.run(e.hp.run(c))))), r = 20 * Math.log10(Math.max(1e-12, Math.abs(t.emphasis.run(t.hp.run(l))))), i = Math.max(n, r);
				this.envelope(n + this.link * (i - n), 0), this.envelope(r + this.link * (i - r), 1);
				let a = Math.min(this.gain[0], this.gain[1]), o = Math.max(this.memory[0], this.memory[1]), s = this.link * this.smooth;
				for (let e = 0; e < 2; e++) this.gain[e] += (a - this.gain[e]) * s, this.memory[e] += (o - this.memory[e]) * s;
				u = ha(this.gain[0]), d = ha(this.gain[1]), this.reduction = Math.min(this.gain[0], this.gain[1]) * this.wet;
			}
			for (let e = 0; e < t.length; e++) {
				let n = this.channels[e], r = e === 0 ? o : s, f = e === 0 ? c : l;
				if (this.type === "brit") {
					for (let e of n.filters) f = e.run(f);
					f = n.color.run(f, .22 * ha(this.drive), .12);
				} else if (this.type === "talon") {
					f = n.audioHp.run(n.audioPole.run(f * (e === 0 ? u : d)));
					let t = [
						.15,
						.8,
						1.5
					][a.color] * (1 + Math.min(2, -this.gain[e] / 20));
					n.amount += (t - n.amount) * this.smooth, n.bias += ((a.color === 1 ? .3 : 0) - n.bias) * this.smooth, f = n.color.run(f, n.amount, n.bias);
				} else f = n.clean.run(f * (e === 0 ? u : d));
				let p = n.dry.run(r);
				t[e][i] = p + this.wet * (f * this.output - p);
			}
		}
	}
};
if (typeof registerProcessor < "u") {
	class e extends AudioWorkletProcessor {
		constructor(e) {
			super(), this.dsp = new ka(e.processorOptions.type, sampleRate), this.meterFrames = 0, this.port.onmessage = ({ data: e }) => {
				e.type === "flush" ? this.port.postMessage({ id: e.id }) : e.type === "dispose" ? (this.dsp.disposed = !0, this.dsp.events = []) : this.dsp.enqueue(e);
			};
		}
		process(e, t) {
			return this.dsp.render(e[0] ?? [], t[0], currentFrame), this.meterFrames += t[0][0].length, this.meterFrames >= sampleRate / 25 && (this.meterFrames = 0, this.port.postMessage({ reduction: this.dsp.reduction })), !this.dsp.disposed;
		}
	}
	registerProcessor("rackloose-studio-v1", e);
}
// src/components/Glyphs.tsx
var Aa = (e) => e.map((t, n) => `${n ? "L" : "M"}${(2 + n * 44 / (e.length - 1)).toFixed(1)} ${(17 - t * 14).toFixed(1)}`).join(" ");
function ja(e, t) {
	let n = t, r = .5, i = Array.from({ length: 25 }, () => (n = n * 16807 % 2147483647, r += (n / 2147483647 - r) * e, r)), a = Math.min(...i), o = Math.max(...i);
	return Aa(i.map((e) => .1 + (e - a) / (o - a) * .8));
}
var Ma = {
	Sine: Aa(Array.from({ length: 33 }, (e, t) => .5 + .5 * Math.sin(t / 32 * Math.PI * 4))),
	Triangle: Aa([
		0,
		1,
		0,
		1,
		0
	]),
	Saw: "M2 17L24 3V17L46 3V17",
	Square: "M2 17V3H13V17H24V3H35V17H46V3",
	Pulse: "M2 17V3H8V17H24V3H30V17H46",
	"Saw + Pulse": "M2 17L13 13.5V6.5L24 3V17L35 13.5V6.5L46 3V17",
	"Low-pass": "M2 7H24C30 7 31 3 33 6C35 10 38 17 46 18",
	"High-pass": "M2 18C10 17 13 10 15 6C17 3 18 7 24 7H46",
	"Band-pass": "M2 18C14 17 18 4 24 4C30 4 34 17 46 18",
	White: ja(1, 7),
	Pink: ja(.45, 11),
	Brown: ja(.16, 23),
	Bell: "M2 14C14 14 18 4 24 4C30 4 34 14 46 14",
	"Low shelf": "M2 6H14C20 6 22 14 30 14H46",
	"High shelf": "M2 14H18C26 14 28 6 34 6H46"
};
function Na({ param: e, value: t }) {
	let n = e.choices?.[t] ?? "", r = Ma[n === "Shelf" ? e.id === "hfBell" ? "High shelf" : "Low shelf" : n];
	return r ? /* @__PURE__ */ m("svg", {
		className: $.choiceGlyph,
		viewBox: "0 0 48 20",
		"aria-hidden": "true",
		children: /* @__PURE__ */ m("path", { d: r })
	}) : null;
}
function Pa({ params: e, brit: t = !1, rate: n = 48e3 }) {
	let r = Ii(e, 24e3), i = (e) => 25 - Math.max(-18, Math.min(18, e)) * 22 / 18, a = Array.from({ length: 72 }, (a, o) => {
		let s = 20 * 1e3 ** (o / 71);
		return `${o ? "L" : "M"}${(3 + o * 114 / 71).toFixed(1)} ${i(t ? ya(e, s, n) : r.reduce((e, t) => e + Li(t, s, 48e3), 0)).toFixed(1)}`;
	}).join("");
	return /* @__PURE__ */ h("svg", {
		className: $.eqGraphic,
		viewBox: "0 0 120 50",
		role: t ? "img" : void 0,
		"aria-label": t ? `BRIT filter response, 20 Hz to 20 kHz, at ${n / 1e3} kHz` : void 0,
		"aria-hidden": !t || void 0,
		"data-bypassed": e.active === 1,
		children: [
			[
				100,
				1e3,
				1e4
			].map((e) => /* @__PURE__ */ m("line", {
				x1: 3 + Math.log10(e / 20) / 3 * 114,
				x2: 3 + Math.log10(e / 20) / 3 * 114,
				y1: "3",
				y2: "47"
			}, e)),
			/* @__PURE__ */ m("line", {
				x1: "3",
				x2: "117",
				y1: "25",
				y2: "25"
			}),
			/* @__PURE__ */ m("path", { d: a })
		]
	});
}
function Fa({ reduction: e, label: t, max: n = 20 }) {
	let r = Math.min(n, Math.max(0, -e)), i = (e) => 45 - e / n * 90, a = (e, t) => {
		let n = (i(e) - 90) * Math.PI / 180;
		return [60 + Math.cos(n) * t, 60 + Math.sin(n) * t].map((e) => Number(e.toFixed(1)));
	};
	return /* @__PURE__ */ m("div", {
		className: $.grMeter,
		role: "meter",
		"aria-label": t,
		"aria-valuemin": 0,
		"aria-valuemax": n,
		"aria-valuenow": r,
		"aria-valuetext": `${r} dB gain reduction`,
		children: /* @__PURE__ */ h("svg", {
			viewBox: "0 0 120 50",
			"aria-hidden": "true",
			children: [
				/* @__PURE__ */ m("path", { d: `M${a(0, 48).join(" ")}A48 48 0 0 0 ${a(n, 48).join(" ")}` }),
				[
					0,
					n / 4,
					n / 2,
					n * 3 / 4,
					n
				].map((e) => {
					let [t, n] = a(e, 48), [r, i] = a(e, 53), [o, s] = a(e, 40);
					return /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("line", {
						x1: t,
						y1: n,
						x2: r,
						y2: i
					}), /* @__PURE__ */ m("text", {
						x: o,
						y: s,
						textAnchor: "middle",
						dominantBaseline: "middle",
						children: e
					})] }, e);
				}),
				/* @__PURE__ */ m("text", {
					className: $.grUnit,
					x: "8",
					y: "45",
					children: "GR dB"
				}),
				/* @__PURE__ */ m("line", {
					className: $.grNeedle,
					x1: "60",
					y1: "60",
					x2: "60",
					y2: "8",
					style: { transform: `rotate(${i(r)}deg)` }
				})
			]
		})
	});
}
var [Ia, La, , Ra] = Y.envelope.params;
function za({ params: e }) {
	let t = (t) => 9 + Mn(t, e[t.id]) * 24, n = 3 + t(Ia), r = n + t(La), i = 117 - t(Ra), a = 40 - e.sustain * 35, o = [
		["A", (3 + n) / 2],
		["D", (n + r) / 2],
		["S", (r + i) / 2],
		["R", (i + 117) / 2]
	];
	return /* @__PURE__ */ h("svg", {
		className: $.envelopeGraphic,
		viewBox: "0 0 120 50",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ m("path", { d: `M3 40L${n.toFixed(1)} 5L${r.toFixed(1)} ${a.toFixed(1)}L${i.toFixed(1)} ${a.toFixed(1)}L117 40` }), o.map(([e, t]) => /* @__PURE__ */ m("text", {
			x: t.toFixed(1),
			y: "48",
			textAnchor: "middle",
			children: e
		}, e))]
	});
}
var Ba = {
	play: /* @__PURE__ */ m("path", { d: "M3.5 2.2v9.6L11.6 7z" }),
	pause: /* @__PURE__ */ m("path", { d: "M3 2.2h2.9v9.6H3zM8.1 2.2H11v9.6H8.1z" }),
	stop: /* @__PURE__ */ m("path", { d: "M2.8 2.8h8.4v8.4H2.8z" }),
	reset: /* @__PURE__ */ m("path", { d: "M2.4 2.2h2v9.6h-2zM11.8 2.2v9.6L4.9 7z" }),
	undo: /* @__PURE__ */ m("path", {
		d: "M5.2 2.4 1.6 5.8l3.6 3.4V7.1h3.2a2.6 2.6 0 0 1 0 5.2H6.6v1.5h1.8a4.1 4.1 0 0 0 0-8.2H5.2z",
		transform: "translate(0 -1.2)"
	}),
	redo: /* @__PURE__ */ m("path", {
		d: "M8.8 2.4l3.6 3.4-3.6 3.4V7.1H5.6a2.6 2.6 0 0 0 0 5.2h1.8v1.5H5.6a4.1 4.1 0 0 1 0-8.2h3.2z",
		transform: "translate(0 -1.2)"
	})
};
function Va({ name: e }) {
	return /* @__PURE__ */ m("svg", {
		className: $.icon,
		viewBox: "0 0 14 14",
		"aria-hidden": "true",
		focusable: "false",
		children: Ba[e]
	});
}
// src/components/MixButtons.tsx
function Ha({ mixKey: e, label: t, mix: n, onToggle: r, solo: i = !0, onClear: a, clearable: o, onSwap: s }) {
	let c = n.muted.has(e), l = n.soloed.has(e);
	return /* @__PURE__ */ h("span", {
		className: $.mixButtons,
		children: [
			/* @__PURE__ */ m("button", {
				className: $.muteToggle,
				"aria-label": `Mute ${t}`,
				"aria-pressed": c,
				title: `Mute ${t}`,
				onClick: () => r(e, "muted"),
				children: "M"
			}),
			i && /* @__PURE__ */ m("button", {
				className: $.soloToggle,
				"aria-label": `Solo ${t}`,
				"aria-pressed": l,
				title: `Solo ${t}`,
				onClick: () => r(e, "soloed"),
				children: "S"
			}),
			a && /* @__PURE__ */ m("button", {
				className: $.clearToggle,
				"aria-label": `Clear ${t} mutes and solos`,
				title: `Clear ${t} mutes and solos`,
				disabled: !o,
				onClick: a,
				children: "CLR"
			}),
			s && /* @__PURE__ */ m("button", {
				className: $.swapToggle,
				"aria-label": `Swap ${t} mute and solo`,
				title: `Swap ${t} mute and solo`,
				disabled: !c && !l,
				onClick: s,
				children: "SWAP"
			})
		]
	});
}
// src/components/Drums.tsx
var Ua = [
	[1, "1/16"],
	[2, "1/32"],
	[3, "×3 · 1/32T"],
	[4, "×4 · 1/64"],
	[6, "×6 · 1/64T"]
], Wa = {
	2: "1/32",
	3: "1/32 triplet",
	4: "1/64",
	6: "1/64 triplet"
}, Ga = (e) => (t) => {
	if (t <= 0) return "-∞ dB";
	let n = 20 * Math.log10(t / e.initial);
	return Math.abs(n) < .05 ? "0 dB" : `${n > 0 ? "+" : ""}${n.toFixed(1)} dB`;
};
function Ka({ module: e, voice: t, onParams: n, labelled: r }) {
	let i = Y[e.type], a = i.params.find((e) => e.id === `${t}Level`);
	if (!a) return null;
	let o = /* @__PURE__ */ m(aa, {
		trim: !0,
		param: a,
		prefix: i.name,
		format: Ga(a),
		value: e.params[a.id],
		onChange: (e) => n({ [a.id]: e })
	});
	return r ? /* @__PURE__ */ h("div", {
		className: $.laneLevel,
		children: [o, /* @__PURE__ */ m("span", {
			"aria-hidden": "true",
			children: "LEVEL"
		})]
	}) : o;
}
function qa(e, t, n, r) {
	let i = e.params, a = 1 << n, o = Ft(i[`${t}Pattern`], n), s = Lt(e, t, n), c = (e) => Object.fromEntries(qe.map((n) => [Je(t, n), n === e ? i[Je(t, n)] | a : i[Je(t, n)] & ~a]));
	return r === 1 ? {
		[`${t}Pattern`]: i[`${t}Pattern`] ^ a,
		...o ? c(0) : {}
	} : {
		[`${t}Pattern`]: i[`${t}Pattern`] | a,
		...c(o && s === r ? 0 : r)
	};
}
function Ja({ name: e, brush: t, onBrush: n }) {
	return /* @__PURE__ */ h("div", {
		className: $.rollBrush,
		role: "group",
		"aria-label": `${e} pad mode`,
		children: [/* @__PURE__ */ m("span", { children: "NOTE" }), Ua.map(([e, r]) => /* @__PURE__ */ m("button", {
			"aria-pressed": t === e,
			onClick: () => n(e),
			children: r
		}, e))]
	});
}
function Ya({ module: e, mix: t, onMix: n, step: r, onParams: i, onAudition: a, disabled: o, selected: s, onSelect: c, brush: l = 1 }) {
	let u = Y[e.type], d = u.params.some((e) => e.id === Je(u.drum.voices[0].id, 2));
	return /* @__PURE__ */ m("div", {
		className: $.drumPads,
		children: u.drum.voices.map((f) => {
			let p = `${f.id}Pattern`, g = e.params[p];
			return /* @__PURE__ */ h("div", {
				className: $.drumLane,
				"data-silent": !cn(e, f.id, t),
				children: [
					/* @__PURE__ */ m("button", {
						className: $.voiceButton,
						"aria-label": `Play ${u.name} ${f.label}`,
						"aria-pressed": c ? s === f.id : void 0,
						disabled: o,
						onClick: () => {
							c?.(f.id), a(f.id);
						},
						children: f.label
					}),
					/* @__PURE__ */ m(Ha, {
						mixKey: en(e.id, f.id),
						label: `${u.name} ${f.label}`,
						mix: t,
						onToggle: n
					}),
					/* @__PURE__ */ m(Ka, {
						labelled: !0,
						module: e,
						voice: f.id,
						onParams: i
					}),
					/* @__PURE__ */ m("div", {
						className: $.pads,
						children: [
							0,
							1,
							2,
							3
						].map((t) => /* @__PURE__ */ m("div", {
							className: $.padGroup,
							"data-group": t,
							children: [
								0,
								1,
								2,
								3
							].map((n) => {
								let a = t * 4 + n, o = Ft(g, a), s = o && d ? Lt(e, f.id, a) : 1;
								return /* @__PURE__ */ h("button", {
									className: $.pad,
									"data-current": r === a,
									"data-roll": s > 1 ? s : void 0,
									"aria-pressed": o,
									"aria-label": `${u.name} ${f.label} step ${a + 1}${s > 1 ? `, ${Wa[s]}` : ""}`,
									onClick: () => i(d ? qa(e, f.id, a, l) : { [p]: g ^ 1 << a }),
									children: [/* @__PURE__ */ m("span", {}), s > 1 && /* @__PURE__ */ m("small", { children: s })]
								}, a);
							})
						}, t))
					})
				]
			}, f.id);
		})
	});
}
var Xa = [
	"Steps",
	"Hits",
	"Shift"
];
function Za({ module: t, mix: n, onMix: r, onParams: i, onAudition: a, disabled: o, clock: s, selected: c, onSelect: l, controls: u }) {
	let d = Y[t.type], f = d.drum.voices.find((e) => e.id === c), p = Bt(t, c);
	return /* @__PURE__ */ h("div", {
		className: $.orbitEditor,
		children: [
			/* @__PURE__ */ h("div", {
				className: $.euclid,
				role: "group",
				"aria-label": `${d.name} rhythm`,
				children: [
					/* @__PURE__ */ m("span", { children: "VOICE / EDIT" }),
					/* @__PURE__ */ m("span", {}),
					[...Xa, "Level"].map((e) => /* @__PURE__ */ m("span", {
						className: $.euclidHeading,
						children: e
					}, e)),
					d.drum.voices.map((s) => /* @__PURE__ */ h(e, { children: [
						/* @__PURE__ */ m("button", {
							className: $.voiceButton,
							"aria-label": `Play ${d.name} ${s.label}`,
							"aria-pressed": c === s.id,
							disabled: o,
							"data-silent": !cn(t, s.id, n),
							onClick: () => {
								l(s.id), a(s.id);
							},
							children: s.label
						}),
						/* @__PURE__ */ m(Ha, {
							mixKey: en(t.id, s.id),
							label: `${d.name} ${s.label}`,
							mix: n,
							onToggle: r
						}),
						Xa.map((e) => {
							let n = d.params.find((t) => t.id === `${s.id}${e}`);
							return /* @__PURE__ */ h("div", {
								className: $.euclidCell,
								children: [/* @__PURE__ */ m(aa, {
									trim: !0,
									param: n,
									prefix: d.name,
									disabled: e !== "Steps" && !!t.params[`${s.id}Custom`],
									value: t.params[n.id],
									onChange: (e) => i({ [n.id]: e })
								}), /* @__PURE__ */ m("output", { children: t.params[n.id] })]
							}, e);
						}),
						/* @__PURE__ */ m(Ka, {
							module: t,
							voice: s.id,
							onParams: i
						})
					] }, s.id))
				]
			}),
			/* @__PURE__ */ h("div", {
				className: $.orbitVoiceEditor,
				role: "group",
				"aria-label": `Edit ORBIT ${f.label}`,
				children: [
					/* @__PURE__ */ h("div", {
						className: $.orbitEditorHeading,
						children: [
							/* @__PURE__ */ h("label", { children: ["EDIT VOICE ", /* @__PURE__ */ m("select", {
								"aria-label": "Orbit edit voice",
								value: c,
								onChange: (e) => l(e.target.value),
								children: d.drum.voices.map((e) => /* @__PURE__ */ m("option", {
									value: e.id,
									children: e.label
								}, e.id))
							})] }),
							/* @__PURE__ */ m("span", { children: t.params[`${c}Custom`] ? "CUSTOM" : "EUCLIDEAN" }),
							/* @__PURE__ */ m("button", {
								disabled: !Ut(t, c),
								onClick: () => i(Ht(t, c)),
								"aria-label": `Generate ORBIT ${f.label} rhythm`,
								title: Ut(t, c) ? "Spread this lane’s hits evenly" : "Already Euclidean: turn Steps, Hits or Shift",
								children: "Generate"
							})
						]
					}),
					/* @__PURE__ */ m("div", {
						className: $.controls,
						children: [
							"Tune",
							"Decay",
							"Tone",
							"Pan",
							"Lag"
						].map((e) => {
							let n = d.params.find((t) => t.id === `${c}${e}`);
							return /* @__PURE__ */ m(aa, {
								param: {
									...n,
									label: e
								},
								prefix: `ORBIT ${f.label}`,
								value: t.params[n.id],
								onChange: (e) => i({ [n.id]: e })
							}, n.id);
						})
					}),
					/* @__PURE__ */ m("div", {
						className: $.orbitSteps,
						children: p.map((e, n) => /* @__PURE__ */ h("button", {
							className: $.pad,
							"aria-pressed": e,
							"data-current": s >= 0 && s % p.length === n,
							"aria-label": `ORBIT ${f.label} step ${n + 1}`,
							onClick: () => {
								let e = Vt(t, c, n);
								i({
									[`${c}Pattern`]: e[`${c}Pattern`],
									[`${c}Custom`]: 1
								});
							},
							children: [/* @__PURE__ */ m("span", {}), n + 1]
						}, n))
					}),
					/* @__PURE__ */ m("small", { children: "Tap a step to customize. Generate makes it Euclidean again." })
				]
			}),
			/* @__PURE__ */ h("div", {
				className: $.orbitDevice,
				children: [/* @__PURE__ */ m($a, {
					module: t,
					clock: s
				}), u]
			})
		]
	});
}
var Qa = [
	70,
	59,
	48,
	37,
	26,
	15
];
function $a({ module: e, clock: t }) {
	return /* @__PURE__ */ m("svg", {
		className: $.orbitRings,
		viewBox: "0 0 160 160",
		"aria-hidden": "true",
		children: Y[e.type].drum.voices.map(({ id: n }, r) => {
			let i = Bt(e, n), a = Qa[r], o = t < 0 ? -1 : t % i.length;
			return /* @__PURE__ */ h("g", {
				"data-voice": n,
				children: [/* @__PURE__ */ m("circle", {
					className: $.orbitPath,
					cx: "80",
					cy: "80",
					r: a
				}), i.map((e, t) => {
					let n = t / i.length * 2 * Math.PI - Math.PI / 2;
					return /* @__PURE__ */ m("circle", {
						cx: (80 + a * Math.cos(n)).toFixed(2),
						cy: (80 + a * Math.sin(n)).toFixed(2),
						r: t === o ? 3.8 : e ? 3 : 1.4,
						"data-hit": e,
						"data-current": t === o
					}, t);
				})]
			}, n);
		})
	});
}
// src/components/SoundEditors.tsx
function eo({ module: e, onParams: t, onAudition: n, disabled: r, selected: i, onSelect: a }) {
	let o = Y[e.type], s = o.drum.voices.find((e) => e.id === i);
	return /* @__PURE__ */ h("div", {
		className: $.soundEditor,
		role: "group",
		"aria-label": `${o.name} voice editor`,
		children: [/* @__PURE__ */ h("div", {
			className: $.editorHeading,
			children: [/* @__PURE__ */ h("label", { children: [/* @__PURE__ */ m("span", { children: "EDIT VOICE" }), /* @__PURE__ */ m("select", {
				"aria-label": `${o.name} edit voice`,
				value: i,
				onChange: (e) => a(e.target.value),
				children: o.drum.voices.map((e) => /* @__PURE__ */ m("option", {
					value: e.id,
					children: e.label
				}, e.id))
			})] }), /* @__PURE__ */ h("button", {
				disabled: r,
				onClick: () => n(i),
				children: ["Audition ", s.label]
			})]
		}), /* @__PURE__ */ m("div", {
			className: $.controls,
			children: o.params.filter((e) => e.voice === i && !e.pattern && e.id !== `${i}Level`).map((n) => /* @__PURE__ */ m(aa, {
				param: {
					...n,
					label: n.label.slice(s.label.length + 1)
				},
				prefix: `${o.name} ${s.label}`,
				value: e.params[n.id],
				onChange: (e) => t({ [n.id]: e })
			}, n.id))
		})]
	});
}
var to = [
	"2→1 + 4→3 + 6→5",
	"3→2→1 + 6→5→4",
	"6→5→4→3→2→1",
	"5+6→4→1+2+3",
	"4→2→1 + 6→5→3→1",
	"1 + 2 + 3 + 4 + 5 + 6"
];
function no({ module: e, onParams: t }) {
	let [n, r] = d(1);
	return /* @__PURE__ */ h("div", {
		className: $.soundEditor,
		role: "group",
		"aria-label": "PRISM operator editor",
		children: [
			/* @__PURE__ */ h("div", {
				className: $.fmDisplay,
				children: [
					/* @__PURE__ */ m("span", { children: Ve[e.params.algorithm] }),
					/* @__PURE__ */ m("strong", { children: to[e.params.algorithm] }),
					/* @__PURE__ */ m("small", { children: "16 VOICES · SIX OPERATORS · PHASE MODULATION" })
				]
			}),
			/* @__PURE__ */ m("div", {
				className: $.operatorTabs,
				role: "group",
				"aria-label": "Select PRISM operator",
				children: [
					1,
					2,
					3,
					4,
					5,
					6
				].map((e) => /* @__PURE__ */ h("button", {
					"aria-pressed": n === e,
					"aria-label": `Edit PRISM operator ${e}`,
					onClick: () => r(e),
					children: ["OP ", e]
				}, e))
			}),
			/* @__PURE__ */ m("div", {
				className: $.controls,
				children: Y.prism.params.filter((e) => e.voice === `op${n}`).map((r) => /* @__PURE__ */ m(aa, {
					param: r,
					prefix: `PRISM Operator ${n}`,
					value: e.params[r.id],
					onChange: (e) => t({ [r.id]: e })
				}, r.id))
			})
		]
	});
}
// src/components/PanelLegend.tsx
function ro({ size: e, height: t, inner: n, marks: r }) {
	let i = (n, r) => [e / 2 + n * Math.sin(r * Math.PI / 180), t / 2 - n * Math.cos(r * Math.PI / 180)], a = (e, t) => n + 10 + (e.length - 1) * 2.2 * Math.abs(Math.sin(t * Math.PI / 180));
	return /* @__PURE__ */ m("svg", {
		className: $.panelLegend,
		width: e,
		height: t,
		style: {
			width: e,
			height: t
		},
		viewBox: `0 0 ${e} ${t}`,
		"aria-hidden": "true",
		children: r.map(({ angle: e, text: t, lit: r }, o) => {
			let [s, c] = i(n, e), [l, u] = i(n + (t ? 4 : 2.5), e), [d, f] = i(a(t ?? "", e), e);
			return /* @__PURE__ */ h("g", {
				"data-lit": r || void 0,
				children: [/* @__PURE__ */ m("line", {
					x1: s,
					y1: c,
					x2: l,
					y2: u
				}), t && /* @__PURE__ */ m("text", {
					x: d,
					y: f,
					textAnchor: "middle",
					dominantBaseline: "central",
					children: t
				})]
			}, o);
		})
	});
}
// src/components/Brit.tsx
var io = (e) => Y.brit.params.find((t) => t.id === e), ao = (e, t) => {
	let n = Math.min(270, (t - 1) * 45);
	return -n / 2 + e * n / (t - 1);
}, oo = (e, t) => e.choices ? ao(t, e.choices.length) : -135 + Mn(e, t) * 270, so = 104, co = (e) => ({
	"--size": `${e}px`,
	"--height": `${so}px`
});
function lo({ angle: e, skirt: t }) {
	return /* @__PURE__ */ h(p, { children: [
		t && /* @__PURE__ */ m("span", { className: $.marconiSkirt }),
		/* @__PURE__ */ m("span", { className: $.marconiFlutes }),
		/* @__PURE__ */ m("span", { className: $.marconiDome }),
		/* @__PURE__ */ m("span", {
			className: $.marconiPointer,
			style: { transform: `rotate(${e}deg)` }
		})
	] });
}
var uo = (e, t) => [...Array.from({ length: 11 }, (e, t) => ({ angle: -135 + t * 27 })), ...t.map(([t, n]) => ({
	angle: oo(e, t),
	text: n
}))], fo = (e, t) => e.map((n, r) => ({
	angle: ao(r, e.length),
	text: n,
	lit: r === t
}));
function po({ module: e, prefix: t, onParams: n, id: r, color: i, size: a, knob: o, skirt: s, title: c, labels: l, marks: u }) {
	let d = io(r), f = e.params[r], { props: p, display: g } = ia({
		param: d,
		value: f,
		prefix: t,
		onChange: (e) => n({ [r]: e })
	});
	return /* @__PURE__ */ h("div", {
		className: $.britSection,
		children: [
			/* @__PURE__ */ m("strong", { children: c }),
			/* @__PURE__ */ h("div", {
				className: $.britWell,
				style: co(a),
				children: [/* @__PURE__ */ m(ro, {
					size: a,
					height: so,
					inner: o / 2 + 3,
					marks: l ? fo(l, f) : uo(d, u ?? [])
				}), /* @__PURE__ */ m("div", {
					className: $.marconi,
					"data-color": i,
					"data-skirt": s || void 0,
					style: { "--knob": `${o}px` },
					...p,
					children: /* @__PURE__ */ m(lo, {
						angle: oo(d, f),
						skirt: s
					})
				})]
			}),
			!l && /* @__PURE__ */ m("span", {
				className: $.knobValue,
				children: g
			})
		]
	});
}
function mo({ module: e, prefix: t, onParams: n, frequency: r, gain: i, color: a, title: o, labels: s }) {
	let c = io(r), l = io(i), u = ia({
		param: c,
		value: e.params[r],
		prefix: t,
		onChange: (e) => n({ [r]: e })
	}), d = ia({
		param: l,
		value: e.params[i],
		prefix: t,
		onChange: (e) => n({ [i]: e })
	});
	return /* @__PURE__ */ h("div", {
		className: $.britSection,
		children: [
			/* @__PURE__ */ m("strong", { children: o }),
			/* @__PURE__ */ h("div", {
				className: $.britWell,
				style: co(112),
				children: [
					/* @__PURE__ */ m(ro, {
						size: 112,
						height: so,
						inner: 36,
						marks: fo(s, e.params[r])
					}),
					/* @__PURE__ */ m("div", {
						className: $.marconiRing,
						style: { "--ring": "66px" },
						...u.props,
						children: /* @__PURE__ */ m("span", {
							className: $.ringPointer,
							style: { transform: `rotate(${oo(c, e.params[r])}deg)` }
						})
					}),
					/* @__PURE__ */ m("div", {
						className: $.marconi,
						"data-color": a,
						style: { "--knob": "38px" },
						...d.props,
						children: /* @__PURE__ */ m(lo, { angle: oo(l, e.params[i]) })
					})
				]
			}),
			/* @__PURE__ */ m("span", {
				className: $.knobValue,
				children: d.display
			})
		]
	});
}
function ho({ module: e, onParams: t, rate: n }) {
	let r = Y.brit.name, i = e.params.active === 0, a = (n) => ({
		module: e,
		onParams: t,
		prefix: `${r} ${n}`
	});
	return /* @__PURE__ */ h("div", {
		className: $.britPanel,
		"data-bypassed": !i,
		children: [
			/* @__PURE__ */ m(po, {
				...a("Signal"),
				id: "hpf",
				color: "blue",
				size: 96,
				knob: 46,
				title: "High pass",
				labels: [
					"OFF",
					"50",
					"80",
					"160",
					"300"
				]
			}),
			/* @__PURE__ */ m(mo, {
				...a("Low shelf"),
				frequency: "lfFreq",
				gain: "lfGain",
				color: "grey",
				title: "Low · Hz",
				labels: [
					"35",
					"60",
					"110",
					"220"
				]
			}),
			/* @__PURE__ */ m(mo, {
				...a("Mid bell"),
				frequency: "midFreq",
				gain: "midGain",
				color: "blue",
				title: "Mid · kHz",
				labels: [
					".36",
					".7",
					"1.6",
					"3.2",
					"4.8",
					"7.2"
				]
			}),
			/* @__PURE__ */ m(po, {
				...a("High shelf · 12 kHz"),
				id: "hfGain",
				color: "grey",
				size: 88,
				knob: 44,
				title: "High · 12k",
				marks: [
					[-16, "−16"],
					[0, "0"],
					[16, "+16"]
				]
			}),
			/* @__PURE__ */ m(po, {
				...a("Signal"),
				id: "drive",
				color: "red",
				size: 100,
				knob: 64,
				skirt: !0,
				title: "Drive",
				marks: [
					[0, "0"],
					[12, "12"],
					[24, "24"]
				]
			}),
			/* @__PURE__ */ m(po, {
				...a("Signal"),
				id: "output",
				color: "grey",
				size: 80,
				knob: 36,
				title: "Output",
				marks: [
					[-18, "−18"],
					[0, "0"],
					[18, "+18"]
				]
			}),
			/* @__PURE__ */ h("div", {
				className: $.britSection,
				children: [/* @__PURE__ */ m("strong", { children: "EQ" }), /* @__PURE__ */ h("button", {
					className: $.britSwitch,
					"aria-pressed": i,
					"aria-label": `${r} EQ in`,
					title: i ? "EQ in. Press to bypass." : "Bypassed. Press to switch the EQ in.",
					onClick: () => t({ active: +!!i }),
					children: [/* @__PURE__ */ m("span", { className: $.britLamp }), "IN"]
				})]
			}),
			/* @__PURE__ */ h("div", {
				className: `${$.britSection} ${$.britCurve}`,
				children: [/* @__PURE__ */ m("strong", { children: "Response" }), /* @__PURE__ */ m(Pa, {
					params: e.params,
					brit: !0,
					rate: n
				})]
			})
		]
	});
}
// src/components/Talon.tsx
var go = Y.talon.name, _o = (e) => Y.talon.params.find((t) => t.id === e), vo = (e) => `${go} ${e.group} ${e.label}`, yo = (e, t) => -135 + Mn(e, t) * 270, bo = 108, xo = [
	1,
	2,
	3,
	4,
	6,
	8,
	10,
	14,
	20,
	30
];
function So({ module: e, onParams: t, id: n, size: r, knob: i, title: a, marks: o }) {
	let s = _o(n), c = e.params[n], { props: l, display: u } = ia({
		param: s,
		value: c,
		prefix: `${go} ${s.group}`,
		onChange: (e) => t({ [n]: e })
	}), d = [...Array.from({ length: 11 }, (e, t) => ({ angle: -135 + t * 27 })), ...o.map(([e, t]) => ({
		angle: yo(s, e),
		text: t
	}))];
	return /* @__PURE__ */ h("div", {
		className: $.talonSection,
		children: [
			/* @__PURE__ */ m("strong", { children: a }),
			/* @__PURE__ */ h("div", {
				className: $.talonWell,
				style: {
					"--size": `${r}px`,
					"--height": `${bo}px`
				},
				children: [/* @__PURE__ */ m(ro, {
					size: r,
					height: bo,
					inner: i / 2 + 4,
					marks: d
				}), /* @__PURE__ */ h("div", {
					className: $.talonKnob,
					style: { "--knob": `${i}px` },
					...l,
					children: [
						/* @__PURE__ */ m("span", { className: $.talonGrip }),
						/* @__PURE__ */ m("span", { className: $.talonCap }),
						/* @__PURE__ */ m("span", {
							className: $.talonIndex,
							style: { transform: `rotate(${yo(s, c)}deg)` }
						})
					]
				})]
			}),
			/* @__PURE__ */ m("span", {
				className: $.knobValue,
				children: u
			})
		]
	});
}
function Co({ module: e, onParams: t, id: n, title: r, button: i, captions: a = [] }) {
	let o = _o(n), s = e.params[n], c = o.choices.length;
	function l(e) {
		let r = {
			ArrowDown: s + 1,
			ArrowRight: s + 1,
			ArrowUp: s - 1,
			ArrowLeft: s - 1,
			Home: 0,
			End: c - 1
		}[e.key];
		if (r === void 0) return;
		e.preventDefault();
		let i = Math.max(0, Math.min(c - 1, r));
		t({ [n]: i }), e.currentTarget.querySelectorAll("[role=\"radio\"]")[i].focus();
	}
	return /* @__PURE__ */ h("div", {
		className: $.talonSection,
		children: [
			/* @__PURE__ */ m("strong", { children: r }),
			/* @__PURE__ */ m("div", {
				className: $.talonLamps,
				role: "radiogroup",
				"aria-label": vo(o),
				onKeyDown: l,
				children: o.choices.map((e, r) => /* @__PURE__ */ h("button", {
					type: "button",
					role: "radio",
					"aria-checked": r === s,
					tabIndex: r === s ? 0 : -1,
					onClick: () => t({ [n]: r }),
					children: [
						/* @__PURE__ */ m("span", { className: $.talonLed }),
						e,
						a[r] && /* @__PURE__ */ m("small", {
							"aria-hidden": "true",
							children: a[r]
						})
					]
				}, e))
			}),
			/* @__PURE__ */ m("button", {
				type: "button",
				className: $.talonPush,
				"aria-label": `${vo(o)}: next`,
				title: `Step to the next ${o.label.toLowerCase()} mode`,
				onClick: () => t({ [n]: (s + 1) % c }),
				children: i
			})
		]
	});
}
function wo({ module: e, onParams: t, id: n, text: r }) {
	let i = _o(n), a = e.params[n] === 1;
	return /* @__PURE__ */ h("button", {
		type: "button",
		className: $.talonPush,
		"aria-pressed": a,
		"aria-label": vo(i),
		title: `${i.label}: ${i.choices[e.params[n]]}`,
		onClick: () => t({ [n]: +!a }),
		children: [/* @__PURE__ */ m("span", { className: $.talonLed }), r]
	});
}
function To({ reduction: e, label: t }) {
	let n = Math.min(40, Math.max(0, -e));
	return /* @__PURE__ */ h("div", {
		className: $.talonSection,
		children: [/* @__PURE__ */ m("strong", { children: "GR" }), /* @__PURE__ */ m("div", {
			className: $.talonMeter,
			role: "meter",
			"aria-label": t,
			"aria-valuemin": 0,
			"aria-valuemax": 40,
			"aria-valuenow": n,
			"aria-valuetext": `${n} dB gain reduction`,
			children: xo.map((e) => /* @__PURE__ */ h("span", {
				"data-lit": n >= e,
				"data-hot": e > 10 || void 0,
				children: [/* @__PURE__ */ m("i", {}), e]
			}, e))
		})]
	});
}
function Eo({ module: e, onParams: t, reduction: n, label: r }) {
	let i = {
		module: e,
		onParams: t
	}, a = e.params.active === 0;
	return /* @__PURE__ */ h("div", {
		className: $.talonPanel,
		"data-bypassed": !a,
		children: [
			/* @__PURE__ */ m(So, {
				...i,
				id: "input",
				size: 100,
				knob: 60,
				title: "Input",
				marks: [
					[-12, "−12"],
					[0, "0"],
					[12, "12"],
					[30, "30"]
				]
			}),
			/* @__PURE__ */ m(So, {
				...i,
				id: "attack",
				size: 84,
				knob: 46,
				title: "Attack · ms",
				marks: [
					[5e-5, ".05"],
					[.001, "1"],
					[.01, "10"],
					[.03, "30"]
				]
			}),
			/* @__PURE__ */ m(So, {
				...i,
				id: "release",
				size: 84,
				knob: 46,
				title: "Release · s",
				marks: [
					[.05, ".05"],
					[.3, ".3"],
					[1, "1"],
					[3.5, "3.5"]
				]
			}),
			/* @__PURE__ */ m(Co, {
				...i,
				id: "ratio",
				title: "Ratio",
				button: "Ratio"
			}),
			/* @__PURE__ */ h("div", {
				className: $.talonSection,
				children: [/* @__PURE__ */ m(Co, {
					...i,
					id: "color",
					title: "Harmonics",
					button: "Dist",
					captions: [
						"",
						"2nd",
						"3rd"
					]
				}), /* @__PURE__ */ h("div", {
					className: $.talonLatches,
					children: [/* @__PURE__ */ m(wo, {
						...i,
						id: "audioHp",
						text: "HP 65"
					}), /* @__PURE__ */ m(wo, {
						...i,
						id: "fierce",
						text: "Fierce"
					})]
				})]
			}),
			/* @__PURE__ */ h("div", {
				className: $.talonSection,
				children: [/* @__PURE__ */ m("strong", { children: "Detector" }), /* @__PURE__ */ h("div", {
					className: $.talonLatches,
					children: [
						/* @__PURE__ */ m(wo, {
							...i,
							id: "detectorHp",
							text: "HP 80"
						}),
						/* @__PURE__ */ m(wo, {
							...i,
							id: "detectorBand",
							text: "Band 6k"
						}),
						/* @__PURE__ */ m(wo, {
							...i,
							id: "link",
							text: "Link"
						})
					]
				})]
			}),
			/* @__PURE__ */ h("div", {
				className: $.talonOutput,
				children: [
					/* @__PURE__ */ m(To, {
						reduction: n,
						label: r
					}),
					/* @__PURE__ */ m(So, {
						...i,
						id: "output",
						size: 100,
						knob: 60,
						title: "Output",
						marks: [
							[-30, "−30"],
							[-12, "−12"],
							[0, "0"],
							[12, "+12"]
						]
					}),
					/* @__PURE__ */ h("div", {
						className: $.talonSection,
						children: [/* @__PURE__ */ m("strong", { children: "Comp" }), /* @__PURE__ */ h("button", {
							type: "button",
							className: $.talonSwitch,
							"aria-pressed": a,
							"aria-label": `${go} in`,
							title: a ? "In. Press to bypass." : "Bypassed. Press to switch TALON in.",
							onClick: () => t({ active: +!!a }),
							children: [/* @__PURE__ */ m("span", { className: $.talonLamp }), "IN"]
						})]
					})
				]
			}),
			e.params.ratio === 5 && /* @__PURE__ */ m("p", {
				className: $.processorHint,
				children: "Opto recovery lengthens with sustained reduction, up to 20 s."
			})
		]
	});
}
// src/components/EngineSwitch.tsx
var Do = [
	0,
	.14,
	.28,
	.42,
	.56,
	.7,
	.84
];
function Oo({ module: e, param: t, name: n, onParams: r }) {
	let i = e.params[t.id] === 1, [a, o] = t.choices;
	return /* @__PURE__ */ h("button", {
		type: "button",
		role: "switch",
		className: $.engineSwitch,
		"aria-checked": i,
		"aria-label": `${n} ${t.label}`,
		"data-modeled": i,
		title: `${t.label}: ${i ? o : a}. Slide to ${i ? a : o}.`,
		onClick: () => r({ [t.id]: +!i }),
		children: [/* @__PURE__ */ m("span", {
			className: $.engineCaption,
			children: t.label
		}), /* @__PURE__ */ h("span", {
			className: $.togglePlate,
			"aria-hidden": "true",
			children: [
				/* @__PURE__ */ m("span", {
					className: $.toggleLegend,
					"data-lit": !i,
					children: a
				}),
				/* @__PURE__ */ h("span", {
					className: $.toggle,
					children: [/* @__PURE__ */ m("span", { className: $.toggleSlot }), /* @__PURE__ */ h("span", {
						className: $.toggleKnob,
						children: [
							/* @__PURE__ */ m("span", { className: $.toggleBrim }),
							Do.map((e) => /* @__PURE__ */ m("span", {
								className: $.toggleRib,
								style: { "--f": e }
							}, e)),
							/* @__PURE__ */ m("span", { className: $.toggleCap })
						]
					})]
				}),
				/* @__PURE__ */ m("span", {
					className: $.toggleLegend,
					"data-lit": i,
					children: o
				})
			]
		})]
	});
}
// src/components/Mixer.tsx
var ko = 112, Ao = [
	[1, "0"],
	[10 ** (-3 / 20), "3"],
	[.5, "6"],
	[10 ** (-10 / 20), "10"],
	[.1, "20"],
	[0, "∞"]
], jo = [
	-48,
	-42,
	-36,
	-30,
	-24,
	-18,
	-12,
	-9,
	-6,
	-3,
	0
], Mo = (e) => Y.mixer.params.find((t) => t.id === e), No = (e) => e <= 0 ? "−∞" : `${(20 * Math.log10(e)).toFixed(1).replace("-", "−")} dB`, Po = (e) => Math.abs(e) < .005 ? "C" : `${e < 0 ? "L" : "R"}${Math.round(Math.abs(e) * 100)}`;
function Fo({ level: e, label: t }) {
	let n = Math.round(e);
	return /* @__PURE__ */ m("div", {
		className: $.levelMeter,
		role: "meter",
		"aria-label": t,
		"aria-valuemin": jo[0],
		"aria-valuemax": 0,
		"aria-valuenow": Math.max(jo[0], Math.min(0, n)),
		"aria-valuetext": e < jo[0] ? "Silent" : `${n} dB`,
		children: jo.map((t) => /* @__PURE__ */ m("i", {
			"data-lit": e >= t,
			"data-zone": t >= -3 ? "hot" : t >= -9 ? "warm" : void 0
		}, t))
	});
}
function Io({ param: e, value: t, prefix: n, onChange: r, children: i }) {
	let { props: a, fraction: o, display: s } = ia({
		param: e,
		value: t,
		prefix: n,
		onChange: r,
		format: No,
		travel: ko
	});
	return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ h("div", {
		className: $.faderBay,
		style: { "--travel": `${ko}px` },
		children: [
			/* @__PURE__ */ m("span", {
				className: $.faderScale,
				"aria-hidden": "true",
				children: Ao.map(([e, t]) => /* @__PURE__ */ m("span", {
					style: { "--at": e },
					children: t
				}, t))
			}),
			/* @__PURE__ */ m("div", {
				className: $.faderSlot,
				...a,
				children: /* @__PURE__ */ m("span", {
					className: $.faderCap,
					style: { "--at": o }
				})
			}),
			i
		]
	}), /* @__PURE__ */ m("span", {
		className: $.faderValue,
		children: s
	})] });
}
function Lo({ module: e, patch: t, mix: n, levels: r, onParams: i, onToggle: a, onSwap: o }) {
	let s = Y[e.type].name;
	return /* @__PURE__ */ h("div", {
		className: $.console,
		children: [He.map((c, l) => {
			let { source: u, tooltip: d, connected: f } = fn(t, e.id, c), p = c.toUpperCase(), g = Ue(c), _ = en(e.id, c);
			return /* @__PURE__ */ h("div", {
				className: $.channelStrip,
				role: "group",
				"aria-label": `${s} channel ${p}: ${u}`,
				"data-plugged": f,
				"data-silent": !cn(e, c, n),
				children: [
					/* @__PURE__ */ h("div", {
						className: $.scribble,
						title: d || void 0,
						children: [/* @__PURE__ */ m("span", {
							className: $.channelSource,
							"data-source-name": !0,
							children: u
						}), /* @__PURE__ */ m("b", { children: p })]
					}),
					/* @__PURE__ */ m(aa, {
						param: Mo(g),
						prefix: s,
						value: e.params[g],
						format: Po,
						caption: "PAN",
						onChange: (e) => i({ [g]: e })
					}),
					/* @__PURE__ */ m(Ha, {
						mixKey: _,
						label: `${s} channel ${p}`,
						mix: n,
						onToggle: a,
						onSwap: () => o(_)
					}),
					/* @__PURE__ */ m(Io, {
						param: Mo(c),
						prefix: s,
						value: e.params[c],
						onChange: (e) => i({ [c]: e }),
						children: /* @__PURE__ */ m(Fo, {
							level: r.channels[l],
							label: `${s} channel ${p} level`
						})
					})
				]
			}, c);
		}), /* @__PURE__ */ h("div", {
			className: $.mixBus,
			role: "group",
			"aria-label": `${s} mix bus`,
			children: [/* @__PURE__ */ h("div", {
				className: $.scribble,
				children: [/* @__PURE__ */ m("span", {
					className: $.channelSource,
					children: "MIX BUS"
				}), /* @__PURE__ */ m("b", { children: "L · R" })]
			}), /* @__PURE__ */ h(Io, {
				param: Mo("master"),
				prefix: s,
				value: e.params.master,
				onChange: (e) => i({ master: e }),
				children: [/* @__PURE__ */ m(Fo, {
					level: r.bus[0],
					label: `${s} mix bus left level`
				}), /* @__PURE__ */ m(Fo, {
					level: r.bus[1],
					label: `${s} mix bus right level`
				})]
			})]
		})]
	});
}
// src/components/TempoInput.tsx
var Ro = 40, zo = 240;
function Bo({ bpm: e, onChange: t }) {
	let [n, r] = d(String(e)), o = a();
	return i(() => {
		r(String(e));
	}, [e]), /* @__PURE__ */ h("div", {
		className: $.numberField,
		children: [
			/* @__PURE__ */ m("label", {
				htmlFor: o,
				children: "BPM"
			}),
			/* @__PURE__ */ m("input", {
				id: o,
				"aria-label": "Tempo",
				type: "number",
				min: Ro,
				max: zo,
				step: 1,
				value: n,
				onChange: (e) => {
					r(e.target.value);
					let n = Number(e.target.value);
					n >= Ro && n <= zo && t(n);
				},
				onBlur: () => {
					let i = n === "" ? e : Math.max(Ro, Math.min(zo, Number(n)));
					r(String(i)), t(i);
				}
			}),
			/* @__PURE__ */ m("input", {
				className: $.fader,
				type: "range",
				min: Ro,
				max: zo,
				step: 1,
				value: e,
				"aria-label": "Tempo slider",
				"aria-valuetext": `${e} BPM`,
				onChange: (e) => t(Number(e.target.value))
			})
		]
	});
}
// src/components/Presets.tsx
var Vo = (e) => new Date(e).toLocaleString(void 0, {
	dateStyle: "medium",
	timeStyle: "short"
});
function Ho({ presets: e, openId: t, dirty: n, onLoad: r, onLoadFactory: a, onExport: o, onDelete: s, onSaveAs: c, onImport: l, onExportCurrent: f, onClose: g }) {
	let [_, v] = d(null), y = u(null), b = u(null);
	return i(() => {
		_ && y.current?.focus();
	}, [_]), /* @__PURE__ */ h("div", {
		ref: b,
		tabIndex: -1,
		className: `${$.library} ${$.presetBrowser}`,
		role: "region",
		"aria-label": "Presets",
		children: [
			/* @__PURE__ */ h("div", {
				className: $.libraryHeading,
				children: [/* @__PURE__ */ m("strong", { children: "PRESETS" }), /* @__PURE__ */ h("span", {
					className: $.presetActions,
					children: [
						/* @__PURE__ */ m("button", {
							onClick: (e) => c(e.currentTarget),
							title: "Save a copy under a new name (⇧⌘S / Ctrl+Shift+S)",
							children: "Save as…"
						}),
						/* @__PURE__ */ m("button", {
							onClick: l,
							title: "Add a .json patch file to My Presets",
							children: "↑ Import file…"
						}),
						/* @__PURE__ */ m("button", {
							onClick: f,
							title: "Download the rack as a .json patch file",
							children: "↓ Export file"
						}),
						/* @__PURE__ */ m("button", {
							"aria-label": "Close presets",
							onClick: g,
							children: "×"
						})
					]
				})]
			}),
			/* @__PURE__ */ m("strong", {
				className: $.sectionLabel,
				children: "MY PRESETS · SAVED IN THIS BROWSER"
			}),
			e.length ? /* @__PURE__ */ m("ul", {
				className: $.presetList,
				"aria-label": "My presets",
				children: e.map((e) => {
					let { id: i, patch: { name: a } } = e, c = i === t;
					return /* @__PURE__ */ m("li", {
						className: $.presetRow,
						"data-open": c,
						children: _ === i ? /* @__PURE__ */ h(p, { children: [
							/* @__PURE__ */ h("span", {
								className: $.presetConfirm,
								children: [
									"Delete “",
									a,
									"”? This can’t be undone."
								]
							}),
							/* @__PURE__ */ m("button", {
								className: $.dangerButton,
								"aria-label": `Confirm delete ${a}`,
								onClick: () => {
									v(null), s(e), b.current?.focus();
								},
								children: "Delete"
							}),
							/* @__PURE__ */ m("button", {
								ref: y,
								"aria-label": `Keep ${a}`,
								onClick: () => v(null),
								children: "Keep"
							})
						] }) : /* @__PURE__ */ h(p, { children: [
							/* @__PURE__ */ h("button", {
								className: $.presetLoad,
								"aria-label": `Load ${a}`,
								"aria-current": c || void 0,
								onClick: () => r(e),
								children: [/* @__PURE__ */ m("strong", { children: a }), /* @__PURE__ */ m("small", { children: c ? n ? "OPEN · UNSAVED CHANGES" : "OPEN" : `Saved ${Vo(e.savedAt)}` })]
							}),
							/* @__PURE__ */ m("button", {
								"aria-label": `Export ${a}`,
								title: `Download ${a} as a .json patch file`,
								onClick: () => o(e.patch),
								children: "↓ Export"
							}),
							/* @__PURE__ */ m("button", {
								"aria-label": `Delete ${a}`,
								title: `Delete ${a} from this browser`,
								onClick: () => v(i),
								children: "Delete"
							})
						] })
					}, i);
				})
			}) : /* @__PURE__ */ m("p", {
				className: $.presetEmpty,
				children: "Nothing saved yet. Save keeps your rack here under its name; Import file adds a patch you exported."
			}),
			/* @__PURE__ */ m("strong", {
				className: $.sectionLabel,
				children: "FACTORY"
			}),
			/* @__PURE__ */ m("div", {
				role: "group",
				"aria-label": "Factory presets",
				children: Cn.map(([e, t]) => /* @__PURE__ */ h("div", {
					className: $.factoryCategory,
					children: [/* @__PURE__ */ m("span", {
						className: $.factoryCategoryLabel,
						"aria-hidden": "true",
						children: e.toUpperCase()
					}), /* @__PURE__ */ m("div", {
						className: $.factoryGrid,
						role: "group",
						"aria-label": `${e} presets`,
						children: t.map((e) => /* @__PURE__ */ m("button", {
							title: e,
							onClick: () => a(e),
							children: e
						}, e))
					})]
				}, e))
			})
		]
	});
}
function Uo({ initialName: e, presets: t, onSave: n, onCancel: r }) {
	let [o, s] = d(e), c = u(null), l = a(), f = a(), p = sr(t, o), g = !o.trim();
	i(() => {
		c.current?.select();
	}, []);
	function _(e) {
		if (e.key === "Escape") {
			e.preventDefault(), r();
			return;
		}
		if (e.key !== "Tab") return;
		let t = [...e.currentTarget.querySelectorAll("input, button:not(:disabled)")], n = t[0], i = t.at(-1);
		e.shiftKey && document.activeElement === n ? (e.preventDefault(), i?.focus()) : !e.shiftKey && document.activeElement === i && (e.preventDefault(), n?.focus());
	}
	return /* @__PURE__ */ m("div", {
		className: $.helpBackdrop,
		children: /* @__PURE__ */ m("div", {
			className: $.saveDialog,
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": l,
			"aria-describedby": f,
			onKeyDown: _,
			children: /* @__PURE__ */ h("form", {
				onSubmit: (e) => {
					e.preventDefault(), g || n(o);
				},
				children: [
					/* @__PURE__ */ m("strong", {
						id: l,
						className: $.saveTitle,
						children: "Save preset"
					}),
					/* @__PURE__ */ h("label", { children: ["Name", /* @__PURE__ */ m("input", {
						ref: c,
						autoFocus: !0,
						"aria-label": "Preset name",
						maxLength: 100,
						value: o,
						onChange: (e) => s(e.target.value)
					})] }),
					p && /* @__PURE__ */ h("p", {
						className: $.saveWarning,
						role: "status",
						children: [
							"“",
							p.patch.name,
							"” is already in My Presets. Saving replaces it."
						]
					}),
					/* @__PURE__ */ m("p", {
						id: f,
						className: $.saveNote,
						children: "Saved in this browser. Export a file to back it up or move it to another browser."
					}),
					/* @__PURE__ */ h("div", {
						className: $.saveButtons,
						children: [/* @__PURE__ */ m("button", {
							type: "button",
							onClick: r,
							children: "Cancel"
						}), /* @__PURE__ */ m("button", {
							type: "submit",
							className: $.saveButton,
							disabled: g,
							children: p ? "Replace" : "Save"
						})]
					})
				]
			})
		})
	});
}
// src/components/Live.tsx
function Wo() {
	let e = {
		pulsing: /* @__PURE__ */ new Set(),
		meter: 0,
		reductions: {},
		mixerLevels: {}
	}, t = /* @__PURE__ */ new Set();
	return {
		get: () => e,
		set(n) {
			if (!Object.keys(n).every((t) => n[t] === e[t])) {
				e = {
					...e,
					...n
				};
				for (let e of t) e();
			}
		},
		subscribe(e) {
			return t.add(e), () => {
				t.delete(e);
			};
		}
	};
}
var Go = t(null);
function Ko({ select: e, children: t }) {
	let n = r(Go), i = () => e(n.get());
	return /* @__PURE__ */ m(p, { children: t(f(n.subscribe, i, i)) });
}
// src/components/seek.ts
var qo = 4, Jo = (e) => `Bar ${Math.floor(e / 16) + 1}, beat ${Math.floor(e % 16 / qo) + 1}`;
function Yo(e, t, n, r) {
	let i = u(null), a = u({
		step: 0,
		at: -Infinity
	}), o = (e) => Math.max(0, Math.min(t - qo, Math.floor(e / qo) * qo)), s = (e) => {
		let n = e.currentTarget.getBoundingClientRect();
		return o((e.clientX - n.left) / n.width * t);
	}, c = n ?? 0;
	return {
		role: "slider",
		tabIndex: 0,
		"aria-label": `${e} playhead`,
		"aria-valuemin": 0,
		"aria-valuemax": t - 1,
		"aria-valuenow": c,
		"aria-valuetext": Jo(c),
		onPointerDown(e) {
			if (e.pointerType === "mouse" && e.button !== 0) return;
			let t = e.pointerType === "touch", n = s(e);
			i.current = {
				pointer: e.pointerId,
				x: e.clientX,
				y: e.clientY,
				touch: t,
				step: n
			}, t || (e.currentTarget.setPointerCapture?.(e.pointerId), r(n));
		},
		onPointerMove(e) {
			let t = i.current;
			if (!t || t.pointer !== e.pointerId) return;
			if (t.touch) {
				Math.hypot(e.clientX - t.x, e.clientY - t.y) > 8 && (i.current = null);
				return;
			}
			let n = s(e);
			n !== t.step && (t.step = n, r(n));
		},
		onPointerUp(e) {
			let t = i.current;
			i.current = null, t?.touch && t.pointer === e.pointerId && r(t.step);
		},
		onPointerCancel() {
			i.current = null;
		},
		onKeyDown(e) {
			let n = o(e.timeStamp - a.current.at < 300 ? a.current.step : c), i = e.shiftKey ? 16 : qo, s = {
				ArrowLeft: n - i,
				ArrowDown: n - i,
				ArrowRight: n + i,
				ArrowUp: n + i,
				PageDown: n - 16,
				PageUp: n + 16,
				Home: 0,
				End: t - 16
			}[e.key];
			s !== void 0 && (e.preventDefault(), e.stopPropagation(), a.current = {
				step: o(s),
				at: e.timeStamp
			}, r(o(s)));
		}
	};
}
// src/pianoRoll.ts
function Xo(e) {
	let t = [...e].sort((e, t) => e.note[0] - t.note[0] || e.note[2] - t.note[2] || Number(t.selected) - Number(e.selected)), n = [], r = /* @__PURE__ */ new Set();
	for (let e of t) {
		let t = n.at(-1);
		t && t[0] === e.note[0] && t[2] === e.note[2] || (e.selected && r.add(n.length), n.push(e.note));
	}
	return {
		notes: n,
		selected: r
	};
}
var Zo = (e, t, n) => Xo(e.map((e, r) => t.has(r) ? {
	note: n(e),
	selected: !0
} : {
	note: e,
	selected: !1
})), Qo = (e, t, n) => Math.max(t, Math.min(n, e)), $o = (e, t) => t ? Math.floor(e / t) * t : Math.round(e), es = (e, t) => t ? Math.round(e / t) * t : Math.round(e);
function ts(e, t, n) {
	for (let r = e.length - 1; r >= 0; r--) {
		let [i, a, o] = e[r];
		if (o === n && i <= t && t < i + a) return r;
	}
	return -1;
}
function ns(e, t, n, r, i) {
	let a = /* @__PURE__ */ new Set();
	return e.forEach(([e, o, s], c) => {
		s >= r && s <= i && e < n && e + o > t && a.add(c);
	}), a;
}
function rs(e, t, n, r, i, a) {
	if (e.length >= 2048) return {
		notes: [...e],
		selected: /* @__PURE__ */ new Set()
	};
	let o = Qo(Math.round(t), 0, a - 1), s = [
		o,
		Qo(Math.round(n), 1, a - o),
		Qo(Math.round(r), 0, 127),
		Qo(Math.round(i), 1, 127)
	];
	return Xo([...e.map((e) => ({
		note: e,
		selected: !1
	})), {
		note: s,
		selected: !0
	}]);
}
var is = (e, t) => ({
	notes: e.filter((e, n) => !t.has(n)),
	selected: /* @__PURE__ */ new Set()
});
function as(e, t, n, r, i) {
	let a = e.filter((e, n) => t.has(n));
	if (!a.length) return {
		notes: [...e],
		selected: /* @__PURE__ */ new Set()
	};
	let o = Math.min(...a.map((e) => e[0])), s = Math.max(...a.map((e) => e[0])), c = Math.min(...a.map((e) => e[2])), l = Math.max(...a.map((e) => e[2])), u = Qo(Math.round(n), -o, i - 1 - s), d = Qo(Math.round(r), -c, 127 - l);
	return Zo(e, t, ([e, t, n, r]) => [
		e + u,
		Math.min(t, i - e - u),
		n + d,
		r
	]);
}
function os(e, t, n, r, i = 1) {
	return Zo(e, t, ([e, t, a, o]) => [
		e,
		Qo(Math.round(t + n), Math.min(i, r - e), r - e),
		a,
		o
	]);
}
function ss(e, t, n, r = !1) {
	return Zo(e, t, ([e, t, i, a]) => [
		e,
		t,
		i,
		Qo(Math.round(r ? n : a + n), 1, 127)
	]);
}
function cs(e, t, n, r, i) {
	return Zo(e, t, ([e, t, a, o]) => {
		let s = te(e, n, r, i);
		return [
			s,
			Qo(t, 1, i - s),
			a,
			o
		];
	});
}
function ls(e, t, n, r) {
	let i = e.filter((e, n) => t.has(n));
	if (!i.length) return {
		notes: [...e],
		selected: /* @__PURE__ */ new Set()
	};
	let a = Math.min(...i.map((e) => e[0])), o = Math.max(...i.map((e) => e[0] + e[1])), s = Math.max(n, Math.ceil((o - a) / n) * n), c = i.map(([e, t, n, i]) => [
		e + s,
		Math.min(t, r - e - s),
		n,
		i
	]).filter(([e]) => e < r).slice(0, Math.max(0, y - e.length));
	return Xo([...e.map((e) => ({
		note: e,
		selected: !1
	})), ...c.map((e) => ({
		note: e,
		selected: !0
	}))]);
}
// src/components/PianoRoll.tsx
var us = 11, ds = 42, fs = 16, ps = 48, ms = 3, hs = 64, gs = 1408, _s = /* @__PURE__ */ new Set([
	1,
	3,
	6,
	8,
	10
]), vs = {
	3840: "1 bar",
	1920: "1/2",
	960: "1/4",
	480: "1/8",
	320: "1/8T",
	240: "1/16",
	160: "1/16T",
	120: "1/32"
}, ys = (e) => vs[e] ?? `${e} ticks`, bs = (e, t, n) => Math.max(t, Math.min(n, e)), xs = (e, t) => e.length === t.length && e.every((e, n) => e.every((e, r) => e === t[n][r]));
function Ss({ name: e, notes: t, take: n, loop: r, grid: l, clock: f, disabled: p, onChange: g, onAudition: _, onAuditionEnd: v, onClose: y, onSeek: b, handle: S }) {
	let C = r / 240, w = a().replace(/[^\w-]/g, ""), T = a(), [E, ee] = d("draw"), [te, ne] = d(l), [D, re] = d(13), [O, k] = d(() => /* @__PURE__ */ new Set()), [ie, A] = d(null), [ae, oe] = d(null), [ce, le] = d(() => ({
		tick: 0,
		pitch: t[0]?.[2] ?? 60
	})), [ue, de] = d(!1), [fe, j] = d({
		length: null,
		velocity: 100
	}), [M, pe] = d(null), [N, P] = d(null), F = u(null), I = u(null), L = u(null), me = u(t), he = u(null), R = C * D, ge = te ?? 240, z = (e) => e / 240 * D, _e = (e) => (127 - e) * us;
	i(() => {
		t !== me.current && (me.current = t, k(/* @__PURE__ */ new Set()), A(null), oe(null), F.current = null);
	}, [t]), s(() => {
		let e = I.current;
		e && re(bs(Math.floor((e.clientWidth - ds) / C), ms, hs));
	}, [C]), s(() => {
		let e = I.current;
		if (!e) return;
		let t = me.current.map((e) => e[2]), n = t.length ? (Math.min(...t) + Math.max(...t)) / 2 : 60;
		e.scrollTop = _e(n) - (e.clientHeight - fs - ps) / 2;
	}, []);
	let ve = f < 0 ? null : z(f % C * 240), ye = u(null), be = Yo(e, C, f < 0 ? null : f % C, b);
	s(() => {
		let e = I.current, t = ye.current;
		if (ye.current = ve, !e || ve === null || F.current) return;
		let r = (t) => t >= e.scrollLeft && t < e.scrollLeft + e.clientWidth - ds;
		!r(ve) && (n || t !== null && r(t)) && (e.scrollLeft = Math.floor(ve / (16 * D)) * 16 * D);
	}, [
		ve,
		n,
		D
	]);
	let xe = ie?.notes ?? t, Se = ie?.selected ?? O, Ce = xe.reduce((e, [t]) => e + +(t < r), 0), we = (e, n) => {
		me.current = e.notes, k(e.selected), A(null), xs(e.notes, t) || g(e.notes, n);
		let r = e.selected.size === 1 ? e.notes[[...e.selected][0]] : null;
		r && j({
			length: r[1],
			velocity: r[3]
		});
	}, Te = (e) => {
		let t = L.current.getBoundingClientRect();
		return {
			tick: bs((e.clientX - t.left) / D * 240, 0, r - 1),
			pitch: bs(127 - Math.floor((e.clientY - t.top) / us), 0, 127),
			x: e.clientX,
			y: e.clientY
		};
	}, Ee = (e, t, n = !1) => {
		p || _(e, t, n);
	}, De = () => v(), Oe = (e, t) => {
		let n = I.current;
		if (!n) return;
		let r = z(e), i = _e(t), a = n.clientWidth - ds, o = n.clientHeight - fs - ps;
		(r < n.scrollLeft || r > n.scrollLeft + a - 24) && (n.scrollLeft = r - a / 3), (i < n.scrollTop || i > n.scrollTop + o - us) && (n.scrollTop = i - o / 2);
	};
	function ke(e) {
		if (e.button !== 0 || p || F.current) return;
		e.preventDefault(), L.current?.focus({ preventScroll: !0 });
		let n = e.pointerType === "touch", i = Te(e), a = ts(t, i.tick, i.pitch), o = {
			pointer: e.pointerId,
			hit: a,
			tick: i.tick,
			pitch: i.pitch,
			x: i.x,
			y: i.y,
			moved: !1,
			extend: e.shiftKey,
			result: null,
			heard: i.pitch
		};
		if (a >= 0) {
			let [r, s, c, l] = t[a], u = O;
			if (e.shiftKey ? (u = new Set(O), u.has(a) ? u.delete(a) : u.add(a)) : O.has(a) || (u = /* @__PURE__ */ new Set([a])), k(u), le({
				tick: r,
				pitch: c
			}), !u.has(a)) return;
			let d = z(r + s) - (i.x - L.current.getBoundingClientRect().left) < Math.min(7, z(s) / 3);
			F.current = {
				...o,
				kind: d ? "resize" : "move",
				origin: t,
				selected: u,
				anchor: d ? r + s : r,
				heard: c
			}, Ee(c, l, n);
		} else if (E === "draw") {
			let e = rs(t, $o(i.tick, te), fe.length ?? ge, i.pitch, fe.velocity, r);
			if (!e.selected.size) return;
			let [a, s] = e.notes[[...e.selected][0]];
			A(e), le({
				tick: a,
				pitch: i.pitch
			}), F.current = {
				...o,
				kind: "draw",
				origin: e.notes,
				selected: e.selected,
				anchor: a + s,
				result: e
			}, he.current = {
				note: i.pitch,
				tick: a,
				at: performance.now()
			}, Ee(i.pitch, fe.velocity, n);
		} else {
			let n = e.shiftKey ? new Set(O) : /* @__PURE__ */ new Set();
			k(n), oe([
				i.tick,
				i.tick,
				i.pitch,
				i.pitch
			]), le({
				tick: $o(i.tick, te),
				pitch: i.pitch
			}), F.current = {
				...o,
				kind: "marquee",
				origin: t,
				selected: n,
				anchor: i.tick
			};
		}
		e.currentTarget.setPointerCapture(e.pointerId);
	}
	function B(e) {
		let t = F.current;
		if (!t || t.pointer !== e.pointerId || t.kind === "velocity") return;
		let n = Te(e);
		if (!t.moved && Math.hypot(n.x - t.x, n.y - t.y) < 4) return;
		if (t.moved = !0, t.kind === "marquee") {
			let e = Math.min(t.tick, n.tick), r = Math.max(t.tick, n.tick), i = Math.min(t.pitch, n.pitch), a = Math.max(t.pitch, n.pitch), o = ns(t.origin, e, r, i, a);
			for (let e of t.selected) o.add(e);
			oe([
				e,
				r,
				i,
				a
			]), k(o);
			return;
		}
		let i = n.tick - t.tick;
		if (t.kind === "move") {
			let a = t.origin[t.hit][2] + n.pitch - t.pitch;
			t.result = as(t.origin, t.selected, es(t.anchor + i, te) - t.anchor, n.pitch - t.pitch, r), a !== t.heard && a >= 0 && a <= 127 && (t.heard = a, De(), Ee(a, t.origin[t.hit][3], e.pointerType === "touch"));
		} else t.result = os(t.origin, t.selected, es(t.anchor + i, te) - t.anchor, r, te ?? 30);
		A(t.result);
	}
	function V(e) {
		let t = F.current;
		t && t.pointer === e.pointerId && (F.current = null, De(), oe(null), t.kind !== "marquee" && (!t.moved && t.kind !== "draw" ? (!t.extend && t.hit >= 0 && k(/* @__PURE__ */ new Set([t.hit])), A(null)) : t.result ? we(t.result) : A(null)));
	}
	function H(e) {
		let t = F.current;
		t && t.pointer === e.pointerId && (F.current = null, De(), A(null), oe(null));
	}
	function U(e) {
		if (p) return;
		let n = Te(e), i = ts(t, n.tick, n.pitch), a = he.current;
		i >= 0 && !(a && performance.now() - a.at < 600 && t[i][2] === a.note && t[i][0] === a.tick) ? we(is(t, /* @__PURE__ */ new Set([i]))) : i < 0 && E === "select" && we(rs(t, $o(n.tick, te), fe.length ?? ge, n.pitch, fe.velocity, r));
	}
	function W(e) {
		if (e.button !== 0 || p || F.current) return;
		let n = e.currentTarget.getBoundingClientRect(), i = e.clientX - n.left, a = -1, o = 8;
		if (t.forEach(([e], t) => {
			let n = Math.abs(z(e) + 1 - i) - (O.has(t) ? .5 : 0);
			e < r && n < o && (a = t, o = n);
		}), a < 0) return;
		e.preventDefault();
		let s = O.has(a) ? O : /* @__PURE__ */ new Set([a]);
		k(s), F.current = {
			kind: "velocity",
			pointer: e.pointerId,
			origin: t,
			selected: s,
			hit: a,
			anchor: t[a][3],
			tick: 0,
			pitch: 0,
			x: e.clientX,
			y: e.clientY,
			moved: !0,
			extend: !1,
			result: null,
			heard: -1
		}, e.currentTarget.setPointerCapture(e.pointerId), G(e);
	}
	function G(e) {
		let t = F.current;
		if (!t || t.pointer !== e.pointerId || t.kind !== "velocity") return;
		let n = e.currentTarget.getBoundingClientRect(), r = bs(Math.round((1 - (e.clientY - n.top - 3) / 42) * 127), 1, 127);
		t.result = t.selected.size === 1 ? ss(t.origin, t.selected, r, !0) : ss(t.origin, t.selected, r - t.anchor), A(t.result);
	}
	function Ae(e) {
		let t = F.current;
		t && t.pointer === e.pointerId && (F.current = null, t.result ? we(t.result) : A(null));
	}
	let je = () => new Set(t.flatMap(([e], t) => e < r ? [t] : []));
	function Me(e) {
		let n = [...je()];
		if (!n.length) return;
		let r = O.size ? Math.min(...O) : -1, i = n[(((r >= 0 ? n.indexOf(r) : n.findIndex((e) => t[e][0] >= ce.tick) - +(e > 0)) + e) % n.length + n.length) % n.length];
		k(/* @__PURE__ */ new Set([i])), le({
			tick: t[i][0],
			pitch: t[i][2]
		}), Oe(t[i][0], t[i][2]), Ee(t[i][2], t[i][3]), window.setTimeout(De, 160);
	}
	function Ne(e) {
		if (F.current || p || e.defaultPrevented) return;
		let n = e.key, i = e.metaKey || e.ctrlKey, a = O.size > 0, o = null;
		if (i && n.toLowerCase() === "a") k(je());
		else if (i && n.toLowerCase() === "d") a && (o = ls(t, O, Math.max(ge, 960), r));
		else if (i || e.altKey) return;
		else if (n === "Delete" || n === "Backspace") {
			if (a) o = is(t, O);
			else return;
		} else if (n === "ArrowUp" || n === "ArrowDown") {
			let i = (n === "ArrowUp" ? 1 : -1) * (e.shiftKey ? 12 : 1);
			if (a) o = as(t, O, 0, i, r);
			else {
				let e = bs(ce.pitch + i, 0, 127);
				le({
					...ce,
					pitch: e
				}), Oe(ce.tick, e);
			}
		} else if (n === "ArrowLeft" || n === "ArrowRight") {
			let i = n === "ArrowRight" ? 1 : -1;
			if (a && e.shiftKey) o = os(t, O, i * ge, r, ge);
			else if (a) o = as(t, O, i * ge, 0, r);
			else {
				let t = bs($o(ce.tick, te) + i * (e.shiftKey ? 3840 : ge), 0, r - ge);
				le({
					...ce,
					tick: t
				}), Oe(t, ce.pitch);
			}
		} else if (n === "n" || n === "N") o = rs(t, ce.tick, fe.length ?? ge, ce.pitch, fe.velocity, r), Ee(ce.pitch, fe.velocity), window.setTimeout(De, 160);
		else if (n === "]" || n === "[") Me(n === "]" ? 1 : -1);
		else if (n === "Escape") a ? k(/* @__PURE__ */ new Set()) : y();
		else return;
		if (e.preventDefault(), e.stopPropagation(), o) {
			we(o);
			let e = o.notes[Math.min(...o.selected)];
			e && (le({
				tick: e[0],
				pitch: e[2]
			}), Oe(e[0], e[2]));
		}
	}
	let K = O.size === 1 ? t[[...O][0]] : null, Pe = K ? `${Pn(K[2])} at ${se(Math.floor(K[0] / 240), C)}, ${ys(K[1])}, velocity ${K[3]}` : O.size ? `${O.size} of ${Ce} notes selected` : `${Ce} ${Ce === 1 ? "note" : "notes"} · cursor ${Pn(ce.pitch)} at ${se(Math.floor(ce.tick / 240), C)}`, Fe = O.size ? t[Math.min(...O)]?.[3] ?? "" : "", Ie = (e, n) => {
		O.size && we(e(t, O), n);
	};
	o(S, () => ({ quantize: (e) => p || !O.size ? 0 : (we(cs(t, O, e, 1, r)), O.size) }));
	let Le = c(() => Array.from({ length: 128 }, (e, t) => {
		let n = 127 - t, r = _s.has(n % 12);
		return /* @__PURE__ */ h("g", {
			"data-pitch": n,
			"data-down": n === N,
			children: [
				/* @__PURE__ */ m("rect", {
					y: t * us,
					width: ds,
					height: us,
					className: $.rollWhite
				}),
				r && /* @__PURE__ */ m("rect", {
					y: t * us,
					width: ds * .6,
					height: us,
					className: $.rollBlack
				}),
				n % 12 == 0 && /* @__PURE__ */ m("text", {
					x: 39,
					y: t * us + us - 2,
					children: Pn(n)
				})
			]
		}, n);
	}), [N]), Re = (e) => bs(127 - Math.floor((e.clientY - e.currentTarget.getBoundingClientRect().top) / us), 0, 127), q = () => {
		N !== null && (P(null), De());
	}, ze = c(() => xe.map(([e, t, n, i], a) => e < r && /* @__PURE__ */ m("rect", {
		className: $.rollNote,
		x: z(e),
		y: _e(n) + 1,
		width: Math.max(3, z(t) - 1),
		height: 9,
		rx: 2,
		fillOpacity: .5 + i / 127 * .5,
		"data-note": n,
		"data-tick": e,
		"data-length": t,
		"data-velocity": i,
		"data-selected": Se.has(a)
	}, a)), [
		xe,
		Se,
		r,
		D
	]), Be = Math.ceil(C / 16);
	return /* @__PURE__ */ h("div", {
		className: $.pianoRoll,
		role: "group",
		"aria-label": `${e} piano roll`,
		children: [
			/* @__PURE__ */ h("div", {
				className: $.rollTools,
				children: [
					/* @__PURE__ */ h("span", {
						className: $.rollToolGroup,
						role: "group",
						"aria-label": "Tool",
						children: [/* @__PURE__ */ m("button", {
							"aria-pressed": E === "draw",
							onClick: () => ee("draw"),
							title: "Click to draw a note, drag to set its length",
							children: "Draw"
						}), /* @__PURE__ */ m("button", {
							"aria-pressed": E === "select",
							onClick: () => ee("select"),
							title: "Drag across notes to select them; double-click to add one",
							children: "Select"
						})]
					}),
					/* @__PURE__ */ h("label", {
						className: $.playsControl,
						title: "Where notes land as you draw, move and resize them; Off places them freely. Quantize, beside the clip's settings, is separate.",
						children: ["SNAP", /* @__PURE__ */ h("select", {
							"aria-label": "Snap",
							value: te ?? 0,
							onChange: (e) => ne(Number(e.target.value) || null),
							children: [x.map(([e, t]) => /* @__PURE__ */ m("option", {
								value: t,
								children: e
							}, t)), /* @__PURE__ */ m("option", {
								value: 0,
								children: "Off"
							})]
						})]
					}),
					/* @__PURE__ */ h("span", {
						className: $.rollToolGroup,
						role: "group",
						"aria-label": "Zoom",
						children: [/* @__PURE__ */ m("button", {
							"aria-label": "Zoom out",
							title: "Zoom out",
							disabled: D <= ms,
							onClick: () => re(Math.max(ms, Math.floor(D / 1.5))),
							children: "−"
						}), /* @__PURE__ */ m("button", {
							"aria-label": "Zoom in",
							title: "Zoom in",
							disabled: D >= hs,
							onClick: () => re(Math.min(hs, Math.ceil(D * 1.5))),
							children: "＋"
						})]
					}),
					/* @__PURE__ */ h("label", {
						className: $.playsControl,
						title: "The selected notes' velocity, 1 to 127, as hard as each is played. The bars under the grid set it by dragging.",
						children: ["VEL", /* @__PURE__ */ m("input", {
							type: "number",
							min: 1,
							max: 127,
							"aria-label": "Velocity of the selected notes",
							disabled: p || !O.size,
							value: M ?? Fe,
							onChange: (e) => {
								let t = Number(e.target.value);
								pe(e.target.value), e.target.value && t >= 1 && t <= 127 && Ie((e, n) => ss(e, n, Math.round(t), !0), "roll-velocity");
							},
							onBlur: () => pe(null)
						})]
					}),
					/* @__PURE__ */ m("span", {
						className: $.rollToolGroup,
						role: "group",
						"aria-label": "Transpose",
						children: [
							[
								-12,
								"down an octave",
								"−12"
							],
							[
								-1,
								"down a semitone",
								"−1"
							],
							[
								1,
								"up a semitone",
								"+1"
							],
							[
								12,
								"up an octave",
								"+12"
							]
						].map(([e, t, n]) => /* @__PURE__ */ m("button", {
							"aria-label": `Transpose ${t}`,
							title: `Move the selected notes ${t}${Math.abs(e) === 12 ? " (Shift+↑/↓)" : " (↑/↓)"}`,
							disabled: p || !O.size,
							onClick: () => Ie((t, n) => as(t, n, 0, e, r)),
							children: n
						}, e))
					}),
					/* @__PURE__ */ m("button", {
						disabled: p || !O.size,
						onClick: () => Ie((e, t) => ls(e, t, Math.max(ge, 960), r)),
						title: "Copy the selected notes to just after them (⌘D / Ctrl+D)",
						children: "Duplicate"
					}),
					/* @__PURE__ */ m("button", {
						disabled: p || !O.size,
						onClick: () => Ie(is),
						"aria-label": "Delete the selected notes",
						title: "Delete the selected notes (Delete)",
						children: "Delete"
					}),
					/* @__PURE__ */ m("button", {
						disabled: !Ce,
						onClick: () => k(je()),
						title: "Select every note in the clip (⌘A / Ctrl+A)",
						children: "Select all"
					}),
					/* @__PURE__ */ m("span", {
						className: $.rollStatus,
						"aria-live": "polite",
						children: Pe
					}),
					/* @__PURE__ */ m("button", {
						className: $.rollClose,
						"aria-label": "Close piano roll",
						title: "Close the piano roll",
						onClick: y,
						children: "×"
					})
				]
			}),
			/* @__PURE__ */ m("div", {
				ref: I,
				className: $.rollScroller,
				children: /* @__PURE__ */ h("div", {
					className: $.rollCanvas,
					style: { width: ds + R },
					children: [
						/* @__PURE__ */ h("div", {
							className: $.rollRulerRow,
							children: [/* @__PURE__ */ m("span", { className: $.rollCorner }), /* @__PURE__ */ h("svg", {
								className: $.rollRuler,
								width: R,
								height: fs,
								style: {
									width: R,
									height: fs
								},
								...be,
								children: [Array.from({ length: Be }, (e, t) => /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("line", {
									x1: t * 16 * D,
									x2: t * 16 * D,
									y1: 0,
									y2: fs
								}), /* @__PURE__ */ m("text", {
									x: t * 16 * D + 3,
									y: 12,
									children: t + 1
								})] }, t)), ve !== null && /* @__PURE__ */ m("line", {
									className: $.playhead,
									x1: ve,
									x2: ve,
									y1: 0,
									y2: fs
								})]
							})]
						}),
						/* @__PURE__ */ h("div", {
							className: $.rollBody,
							children: [/* @__PURE__ */ m("svg", {
								className: $.rollKeys,
								width: ds,
								height: gs,
								style: {
									width: ds,
									height: gs
								},
								"aria-hidden": "true",
								onPointerDown: (e) => {
									if (e.pointerType !== "mouse" || e.button !== 0) return;
									let t = Re(e);
									P(t), Ee(t, 100);
								},
								onPointerMove: (e) => {
									if (N === null) return;
									let t = Re(e);
									t !== N && (De(), P(t), Ee(t, 100));
								},
								onPointerUp: q,
								onPointerLeave: q,
								onPointerCancel: q,
								children: Le
							}), /* @__PURE__ */ h("svg", {
								ref: L,
								className: $.rollGrid,
								width: R,
								height: gs,
								style: {
									width: R,
									height: gs
								},
								tabIndex: 0,
								role: "application",
								"aria-label": `${e} notes`,
								"aria-describedby": T,
								"data-notes": Ce,
								"data-tool": E,
								onPointerDown: ke,
								onPointerMove: B,
								onPointerUp: V,
								onPointerCancel: H,
								onLostPointerCapture: H,
								onDoubleClick: U,
								onKeyDown: Ne,
								onFocus: () => de(!0),
								onBlur: () => de(!1),
								children: [
									/* @__PURE__ */ h("defs", { children: [/* @__PURE__ */ m("pattern", {
										id: `${w}rows`,
										width: R,
										height: 132,
										patternUnits: "userSpaceOnUse",
										children: Array.from({ length: 12 }, (e, t) => {
											let n = 127 - t;
											return /* @__PURE__ */ h("g", { children: [_s.has(n % 12) && /* @__PURE__ */ m("rect", {
												y: t * us,
												width: R,
												height: us,
												className: $.rollShade
											}), /* @__PURE__ */ m("line", {
												x1: 0,
												x2: R,
												y1: (t + 1) * us,
												y2: (t + 1) * us,
												className: n % 12 == 0 ? $.rollOctave : $.rollRowLine
											})] }, t);
										})
									}), /* @__PURE__ */ m("pattern", {
										id: `${w}beats`,
										width: 16 * D,
										height: gs,
										patternUnits: "userSpaceOnUse",
										children: Array.from({ length: 16 }, (e, t) => (t % 4 == 0 || D >= 8) && /* @__PURE__ */ m("line", {
											x1: t * D,
											x2: t * D,
											y1: 0,
											y2: gs,
											className: t === 0 ? $.rollBar : t % 4 == 0 ? $.rollBeat : $.rollStep
										}, t))
									})] }),
									/* @__PURE__ */ m("rect", {
										width: R,
										height: gs,
										fill: `url(#${w}rows)`
									}),
									/* @__PURE__ */ m("rect", {
										width: R,
										height: gs,
										fill: `url(#${w}beats)`
									}),
									ze,
									n?.map(([e, t, n], i) => e < r && /* @__PURE__ */ m("rect", {
										className: $.rollTake,
										x: z(e),
										y: _e(n) + 1,
										width: Math.max(3, z(t) - 1),
										height: 9,
										rx: 2
									}, `take${i}`)),
									ue && !O.size && /* @__PURE__ */ m("rect", {
										className: $.rollCursor,
										x: z(ce.tick),
										y: _e(ce.pitch),
										width: Math.max(3, z(fe.length ?? ge)),
										height: us
									}),
									ae && /* @__PURE__ */ m("rect", {
										className: $.rollMarquee,
										x: z(ae[0]),
										y: _e(ae[3]),
										width: z(ae[1] - ae[0]),
										height: (ae[3] - ae[2] + 1) * us
									}),
									ve !== null && /* @__PURE__ */ m("line", {
										className: $.playhead,
										x1: ve,
										x2: ve,
										y1: 0,
										y2: gs
									})
								]
							})]
						}),
						/* @__PURE__ */ h("div", {
							className: $.rollLaneRow,
							children: [/* @__PURE__ */ m("span", {
								className: $.rollLaneLabel,
								children: "VEL"
							}), /* @__PURE__ */ m("svg", {
								className: $.rollLane,
								width: R,
								height: ps,
								style: {
									width: R,
									height: ps
								},
								role: "img",
								"aria-label": "Note velocities",
								onPointerDown: W,
								onPointerMove: G,
								onPointerUp: Ae,
								onPointerCancel: H,
								onLostPointerCapture: H,
								children: xe.map(([e, , , t], n) => e < r && /* @__PURE__ */ m("rect", {
									x: z(e),
									y: 45 - t / 127 * 42,
									width: 3,
									height: t / 127 * 42,
									"data-velocity": t,
									"data-selected": Se.has(n)
								}, n))
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ h("p", {
				id: T,
				className: $.visuallyHidden,
				children: [E === "draw" ? "Click to draw a note and drag to set its length. " : "Drag across notes to select them; double-click to add one. ", "Drag a note to move it, or its right edge to resize; double-click deletes it. Keys: arrows move the selection or the cursor, Shift+←/→ resizes, Shift+↑/↓ moves an octave, N adds a note at the cursor, [ and ] step through notes, Delete removes and ⌘D duplicates. Click or drag the bar numbers to move the playhead, or tap them on a touch screen, where dragging the keys or bar numbers scrolls."]
			})
		]
	});
}
// src/components/Dictator.tsx
var Cs = [
	"monarch",
	"oracle",
	"aurora",
	"prism"
], ws = (e) => Cs.includes(e.type) || bt(e.type), Ts = [], Es = Array.from({ length: 41 }, (e, t) => t * 5 - 100);
function Ds({ module: e, patch: t, name: n, clock: r, take: i, armed: a, recording: o, disabled: s, control: c, transport: l, plays: d, offset: f, editing: p, grid: g, onParam: _, onPlays: v, onArm: y, onClear: b, onQuantize: S, onCapture: w, onDiscard: T, onOffset: E, onEditing: ee, onNotes: te, onAudition: ne, onAuditionEnd: D, onSeek: re, importing: O, onExportMidi: k, onImportMidi: ie, onImportTracks: A, onImportCancel: ae }) {
	let oe = u(null), ce = u(null), le = u(null), ue = e.notes ?? Ts, de = C(e.params.length), fe = de / 240, j = t.modules.filter(ws), M = ue.length + (i?.length ?? 0), pe = o && a, N = e.params.qrec === 1, P = x[e.params.quantize]?.[0] ?? "1/16";
	return /* @__PURE__ */ h("div", {
		className: $.dictatorBody,
		children: [
			/* @__PURE__ */ h("div", {
				className: $.sequenceTop,
				children: [
					/* @__PURE__ */ h("div", {
						className: $.lcd,
						children: [
							/* @__PURE__ */ m("small", { children: pe ? "RECORDING" : "CLIP" }),
							/* @__PURE__ */ m("strong", { children: se(Math.max(0, r), fe).split(".").slice(0, 2).join(".") }),
							/* @__PURE__ */ m("span", {
								className: $.lcdDots,
								"aria-hidden": "true"
							})
						]
					}),
					/* @__PURE__ */ h("button", {
						className: $.armButton,
						"aria-pressed": a,
						"data-recording": pe,
						disabled: s,
						"aria-label": `${a ? "Disarm" : "Arm"} ${n} to record`,
						title: "Arm this DICTATOR to record into it: the keys play through it, and RECORD or R records what you play. With more than one DICTATOR, only the armed one records; arming another disarms this one.",
						onClick: y,
						children: [/* @__PURE__ */ m("span", { className: $.armLed }), "ARM"]
					}),
					/* @__PURE__ */ h("div", {
						className: $.controls,
						children: [
							c("length"),
							c("mode"),
							c("lag")
						]
					}),
					/* @__PURE__ */ h("div", {
						className: $.transport,
						children: [l, /* @__PURE__ */ m("span", {
							className: $.transportCaption,
							children: "LOOPING CLIP / POLY"
						})]
					})
				]
			}),
			/* @__PURE__ */ h("div", {
				className: $.quantizeRow,
				children: [
					c("quantize"),
					/* @__PURE__ */ m("button", {
						disabled: s || !ue.some(([e]) => e < de),
						"aria-label": `Quantize notes in ${n}`,
						onClick: () => S(p ? le.current?.quantize(g) ?? 0 : 0),
						title: `Move note starts onto the ${P} grid now: the notes selected in the piano roll, or else every note. Undo moves them back.`,
						children: "Quantize"
					}),
					/* @__PURE__ */ h("button", {
						className: $.lampButton,
						"aria-pressed": N,
						disabled: s,
						"aria-label": `Auto-quantize ${n} while recording`,
						onClick: () => _("qrec", +!N),
						title: Y.dictator.params.find((e) => e.id === "qrec")?.hint,
						children: [/* @__PURE__ */ m("span", { className: $.lampLed }), "AUTO"]
					})
				]
			}),
			p ? /* @__PURE__ */ m(Ss, {
				handle: le,
				name: n,
				notes: ue,
				take: i,
				loop: de,
				grid: g,
				clock: r,
				disabled: s,
				onChange: te,
				onAudition: ne,
				onAuditionEnd: D,
				onSeek: re,
				onClose: () => {
					ee(!1), oe.current?.focus();
				}
			}) : /* @__PURE__ */ m(ks, {
				name: n,
				notes: ue,
				take: i,
				loop: de,
				position: r < 0 ? null : r % fe,
				onSeek: re,
				label: `${n} clip, ${M} ${M === 1 ? "note" : "notes"}`
			}),
			/* @__PURE__ */ h("div", {
				className: $.dictatorActions,
				children: [
					/* @__PURE__ */ h("label", {
						className: $.playsControl,
						title: "Patch this clip's Pitch and Gate into an instrument in one step. Undo puts the cables back.",
						children: ["PLAYS", /* @__PURE__ */ h("select", {
							"aria-label": `${n} plays`,
							value: d ?? "",
							disabled: s,
							onChange: (e) => {
								e.target.value && v(e.target.value);
							},
							children: [/* @__PURE__ */ m("option", {
								value: "",
								children: d === null ? "Choose…" : "Patched by hand"
							}), j.map((e) => /* @__PURE__ */ m("option", {
								value: e.id,
								children: dn(t, e)
							}, e.id))]
						})]
					}),
					/* @__PURE__ */ m("button", {
						ref: oe,
						className: $.editButton,
						"aria-pressed": p,
						"aria-label": `Edit ${n} notes`,
						title: "Open the clip in the piano roll to draw, move and resize its notes",
						onClick: () => ee(!p),
						children: "EDIT"
					}),
					pe ? /* @__PURE__ */ m("button", {
						onClick: T,
						title: "Throw away this take so far and keep recording (Backspace)",
						children: "Discard take"
					}) : /* @__PURE__ */ m("button", {
						disabled: s || o,
						onClick: w,
						"aria-label": `Capture into ${n}`,
						title: "Keep what you just played with the transport running, without having pressed RECORD",
						children: "Capture"
					}),
					/* @__PURE__ */ m("button", {
						disabled: s || !ue.length,
						onClick: b,
						"aria-label": `Clear ${n} notes`,
						title: "Delete every note in the clip. Undo brings them back.",
						children: "Clear"
					}),
					/* @__PURE__ */ m("button", {
						disabled: !ue.some(([e]) => e < de),
						onClick: k,
						"aria-label": `Export ${n} as a MIDI file`,
						title: "Save the clip as a .mid file, for a DAW or another Rackloose",
						children: "Export .mid"
					}),
					/* @__PURE__ */ m("button", {
						disabled: s || pe,
						onClick: () => ce.current?.click(),
						"aria-label": `Import a MIDI file into ${n}`,
						title: "Replace the clip with the notes of a .mid file, up to 16 bars",
						children: "Import .mid"
					}),
					/* @__PURE__ */ m("input", {
						ref: ce,
						type: "file",
						accept: ".mid,.midi,audio/midi,audio/x-midi",
						hidden: !0,
						"aria-label": `MIDI file for ${n}`,
						onChange: (e) => {
							let t = e.target.files?.[0];
							e.target.value = "", t && ie(t);
						}
					}),
					/* @__PURE__ */ h("label", {
						className: $.offsetControl,
						title: "If the notes you record land later than you played them, as with Bluetooth headphones or a slow keyboard, record them this much earlier; if they land early, later. It changes only what is recorded, never what you hear, and is kept in this browser, for every DICTATOR.",
						children: ["REC TIMING", /* @__PURE__ */ m("select", {
							"aria-label": "Recording timing",
							value: f,
							onChange: (e) => E(Number(e.target.value)),
							children: Es.map((e) => /* @__PURE__ */ m("option", {
								value: e,
								children: e > 0 ? `${e} ms earlier` : e < 0 ? `${-e} ms later` : "As played"
							}, e))
						})]
					})
				]
			}),
			O && /* @__PURE__ */ m(Os, {
				importing: O,
				onPick: A,
				onCancel: ae
			})
		]
	});
}
function Os({ importing: e, onPick: t, onCancel: n }) {
	let [r, i] = d("all"), a = (e) => `${e} ${e === 1 ? "note" : "notes"}`;
	return /* @__PURE__ */ h("div", {
		className: $.midiTracks,
		role: "group",
		"aria-label": `Tracks of ${e.file}`,
		children: [
			/* @__PURE__ */ h("span", { children: [
				e.file,
				" has ",
				e.tracks.length,
				" tracks."
			] }),
			/* @__PURE__ */ h("select", {
				"aria-label": "Track to import",
				value: r,
				autoFocus: !0,
				onChange: (e) => i(e.target.value),
				children: [/* @__PURE__ */ h("option", {
					value: "all",
					children: ["All tracks · ", a(e.tracks.reduce((e, t) => e + t.notes.length, 0))]
				}), e.tracks.map((e, t) => /* @__PURE__ */ h("option", {
					value: t,
					children: [
						e.name,
						" · ch ",
						e.channel + 1,
						e.channel === 9 ? " drums" : "",
						" · ",
						a(e.notes.length)
					]
				}, t))]
			}),
			/* @__PURE__ */ m("button", {
				onClick: () => t(r === "all" ? null : Number(r)),
				children: "Import"
			}),
			/* @__PURE__ */ m("button", {
				onClick: n,
				children: "Cancel"
			})
		]
	});
}
function ks({ name: e, notes: t, take: n, loop: r, position: i, onSeek: a, label: o }) {
	let s = Yo(e, r / 240, i, a), c = i === null ? null : i * 240, l = [...t, ...n ?? []].filter(([e]) => e < r), u = l.length ? Math.min(...l.map((e) => e[2])) : 48, d = l.length ? Math.max(...l.map((e) => e[2])) : 59, f = Math.max(12, d - u + 1), p = d + Math.floor((f - (d - u + 1)) / 2), _ = ([e, t, n, i], a, o) => /* @__PURE__ */ m("rect", {
		x: e,
		y: p - n,
		width: Math.max(t, r / 400),
		height: 1,
		"data-take": a,
		opacity: .45 + i / 127 * .55,
		children: /* @__PURE__ */ h("title", { children: [
			Pn(n),
			" · velocity ",
			i
		] })
	}, `${a ? "t" : "n"}${o}`);
	return /* @__PURE__ */ h("div", {
		className: $.noteStripFrame,
		children: [/* @__PURE__ */ h("svg", {
			className: $.noteStrip,
			role: "img",
			"aria-label": o,
			"data-notes": l.length,
			viewBox: `0 0 ${r} ${f}`,
			preserveAspectRatio: "none",
			children: [
				Array.from({ length: r / g - 1 }, (e, t) => /* @__PURE__ */ m("line", {
					x1: (t + 1) * g,
					x2: (t + 1) * g,
					y1: 0,
					y2: f,
					vectorEffect: "non-scaling-stroke"
				}, t)),
				t.filter(([e]) => e < r).map((e, t) => _(e, !1, t)),
				n?.map((e, t) => _(e, !0, t)),
				c !== null && /* @__PURE__ */ m("line", {
					className: $.playhead,
					x1: c,
					x2: c,
					y1: 0,
					y2: f,
					vectorEffect: "non-scaling-stroke"
				})
			]
		}), /* @__PURE__ */ m("div", {
			className: $.stripSeek,
			...s
		})]
	});
}
// ../../../rackloose.svg?inline
var As = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2064%2064'%3e%3crect%20x='5'%20y='6'%20width='54'%20height='52'%20rx='3'%20fill='%23303337'%20stroke='%23101214'%20stroke-width='2'/%3e%3cpath%20d='M10%2010v44M54%2010v44'%20stroke='%23777'%20stroke-width='3'/%3e%3crect%20x='14'%20y='12'%20width='36'%20height='17'%20fill='%23b9503a'%20stroke='%23111'/%3e%3crect%20x='14'%20y='31'%20width='36'%20height='20'%20fill='%23a0ac9b'%20stroke='%23111'/%3e%3cg%20fill='%23232626'%20stroke='%23dfdfca'%3e%3ccircle%20cx='23'%20cy='21'%20r='5'/%3e%3ccircle%20cx='41'%20cy='21'%20r='5'/%3e%3c/g%3e%3cpath%20d='M23%2021v-4m18%204%203-3'%20stroke='%23fff'%20stroke-width='2'/%3e%3cg%20fill='%231b2221'%20stroke='%23555'%3e%3ccircle%20cx='22'%20cy='39'%20r='3'/%3e%3ccircle%20cx='42'%20cy='44'%20r='3'/%3e%3c/g%3e%3cpath%20d='M22%2039c-6%2020%2027%2020%2020%205'%20fill='none'%20stroke='%23f4bb50'%20stroke-width='3'/%3e%3cpath%20d='M7%208h50'%20stroke='%23a9abad'/%3e%3c/svg%3e", js = {
	channels: Array(8).fill(-60),
	bus: [-60, -60]
}, Ms = [
	"a",
	"w",
	"s",
	"e",
	"d",
	"f",
	"t",
	"g",
	"y",
	"h",
	"u",
	"j",
	"k",
	"o",
	"l",
	"p",
	";",
	"'"
], Ns = [...new Set(Object.values(S))].sort((e, t) => e - t), Ps = [
	"a",
	"s",
	"d",
	"f",
	"g",
	"h",
	"j",
	"k",
	"l",
	";",
	"'",
	"z",
	"x",
	"c",
	"v",
	"b"
], Fs = /* @__PURE__ */ new Set([
	1,
	3,
	6,
	8,
	10
]), Is = "input:not([type]), input[type=\"text\"], input[type=\"search\"], textarea, [contenteditable=\"true\"]", Ls = 30, Rs = 40, zs = {
	id: "depth",
	label: "Depth",
	min: -1,
	max: 1,
	step: .01,
	initial: 1
}, Bs = (e) => `${Math.round(e * 100)}%`, Vs = [
	"boom",
	"punch",
	"strike",
	"forge"
], Hs = {
	oscillator: "1V / OCT",
	filter: "CV CONTROL",
	delay: "WARM REPEATS",
	boom: "LONG LOW END",
	punch: "FOUR ON THE FLOOR",
	skitter: "NO SOUND · ALL BOUNCE",
	forge: "HIT IT HARDER",
	rust: "NOTHING CLEAN"
}, Us = {
	boom: "ANALOG KIT · 11 VOICES",
	punch: "DANCE FLOOR KIT · 5 VOICES",
	strike: "ORIGINAL DIGITAL KIT · 16 VOICES",
	forge: "INDUSTRIAL KIT · 11 VOICES"
};
function Ws(e, t, n) {
	let r = URL.createObjectURL(new Blob([e], { type: t })), i = document.createElement("a");
	i.href = r, i.download = n, i.click(), setTimeout(() => URL.revokeObjectURL(r), 1e3);
}
var Gs = (e) => {
	let [t, n] = e.dataset.portKey.split(":");
	return {
		moduleId: t,
		portId: n
	};
}, Ks = (e, t) => e === t || !!e && !!t && X(e, t), qs = (e, t) => e.error === t.error && e.inside === t.inside && e.cableId === t.cableId && X(e.anchor, t.anchor) && e.point.x === t.point.x && e.point.y === t.point.y && Ks(e.target, t.target), Js = (e, t) => X(e.from, t) ? e.to : e.from, Ys = (e, t) => ({
	...e,
	cables: e.cables.filter((e) => e.id !== t)
});
function Xs(e) {
	try {
		let t = localStorage.getItem(`${e}:baselinePatch`);
		if (t) {
			let e = kn(t);
			return {
				signature: On(e),
				patch: e
			};
		}
	} catch {}
	return null;
}
function Zs(e, { signature: t, patch: n }) {
	localStorage.setItem(`${e}:baseline`, t), localStorage.setItem(`${e}:baselinePatch`, Dn(n));
}
function Qs({ key: e, patch: t, open: n }) {
	let r = jn(localStorage, e, t);
	return r || (n ? localStorage.setItem(`${e}:open`, n) : localStorage.removeItem(`${e}:open`)), r;
}
function $s({ keysEnabled: e = !0, suspended: t = !1, storageKey: r = "rackloose.patch.v1", linkBrand: o = !0 }) {
	let [s, f] = d(() => En()), g = u(s), v = u(null), y = u(null), b = u(null), T = u(null), E = u(null), ee = u(null), te = u(null), [D, re] = d(!1), [O, k] = d(!1), [A, ae] = d(null), [oe, ue] = d(!1), [fe, j] = d(null), [M, pe] = d(null), [N, P] = l((e, t) => ({
		text: t,
		serial: e.serial + 1
	}), {
		text: "Ready when you are. Enable audio, then play a key or start the pattern.",
		serial: 0
	}), F = N.text, [I, L] = d(!0), [me, he] = d(!1), [R, ge] = d(!1), [z, _e] = d(!1), [ve, ye] = d(-1), [be, xe] = d([]), [Se, Ce] = d(48e3), [we] = d(Wo), [Te, Ee] = d(127), [De, Oe] = d(!1), [ke, B] = d(null), [V, H] = d(null), [U, W] = d(!1), [G, Ae] = d(1), [je, Ne] = d(null), K = u(() => {}), [Pe, Fe] = d(3), [Ie, Le] = d(!0), [Re, q] = d(null), ze = u(/* @__PURE__ */ new Map()), [Be, Ve] = d(null), [He, Ue] = d(null), [We, Ge] = d(null), [Ke, qe] = d(null), [Je, Ye] = d(null), [Xe, Ze] = d(4), [Qe, $e] = d(!1), [et, tt] = d($t), [nt, rt] = d("performance"), J = u("performance"), [it, at] = d(/* @__PURE__ */ new Set()), st = u(/* @__PURE__ */ new Map()), [lt, Ot] = d({}), [kt, At] = d({}), [Mt, Ft] = d(null), [It, Lt] = d(null), [Rt, zt] = d(!1), [Bt, Vt] = d(null), Ht = u(null), Ut = u(!1), qt = u(() => {}), Yt = u(!0), Xt = u(/* @__PURE__ */ new Set()), [en, nn] = d({}), [an, sn] = d(null), [cn, un] = d({}), [hn, vn] = d({
		undo: 0,
		redo: 0
	}), yn = u($t), bn = u(!1), xn = u(3), Sn = u(Xn()), Cn = u(null), [wn, Tn] = d([]), [jn, Mn] = d({}), [Nn, Fn] = d(""), In = u(""), [Ln, Rn] = d(null), zn = u(null), Bn = u(null), Vn = u(null), Hn = u(0), Wn = u(!1), Jn = u(null), tr = u(0), nr = a(), rr = a(), dr = a(), fr = a(), pr = `${r}:presets`, mr = wn.find((e) => e.id === jn[Nn]) ?? null, hr = mr?.id ?? null, gr = cn[Nn] ?? null, _r = c(() => On(s), [s]), vr = c(() => mr ? On(mr.patch) : gr?.signature ?? null, [mr, gr]), yr = vr !== null && _r !== vr, br = mr?.patch ?? gr?.patch ?? null;
	i(() => {
		g.current = s, v.current?.update(s);
	}, [s]), i(() => {
		let e = new ea(g.current, (e) => P(e.message));
		v.current = e, e.onTake = (...e) => K.current(...e);
		let n = 0, r = 0;
		function i(t) {
			let a = we.get(), o = g.current.modules.filter((t) => rn(t.type) && e.pulsing(t.id)).map((e) => e.id);
			if (we.set({ pulsing: o.length === a.pulsing.size && o.every((e) => a.pulsing.has(e)) ? a.pulsing : new Set(o) }), t - r > 40) {
				Ce(e.sampleRate), ye(e.clock), B(e.countingIn), he(e.playing), ge(e.ready), W(e.recording);
				let n = e.armedId, i = n ? e.takeNotes(n) : null;
				Ne((e) => e?.id === n && e?.notes === i || !e && !i ? e : i && n ? {
					id: n,
					notes: i
				} : null), xe((t) => {
					let n = e.activeNotes;
					return n.length === t.length && n.every((e, n) => e === t[n]) ? t : n;
				}), nn((t) => {
					let n = Object.fromEntries(g.current.modules.filter((e) => Jt(e.type)).map((t) => [t.id, {
						playing: e.modulePlaying(t.id),
						clock: e.moduleClock(t.id)
					}]));
					return JSON.stringify(n) === JSON.stringify(t) ? t : n;
				});
				let o = Object.fromEntries(g.current.modules.filter((e) => [
					"compressor",
					"cohere",
					"talon"
				].includes(e.type)).map((t) => [t.id, Math.round(e.reduction(t.id) * 2) / 2])), s = Object.fromEntries(g.current.modules.filter((e) => e.type === "mixer").map((t) => {
					let { channels: n, bus: r } = e.mixerLevels(t.id), i = {
						channels: n.map(Math.round),
						bus: r.map(Math.round)
					}, o = a.mixerLevels[t.id];
					return [t.id, o && JSON.stringify(o) === JSON.stringify(i) ? o : i];
				}));
				we.set({
					meter: e.meter,
					reductions: JSON.stringify(o) === JSON.stringify(a.reductions) ? a.reductions : o,
					mixerLevels: Object.keys(s).length === Object.keys(a.mixerLevels).length && Object.entries(s).every(([e, t]) => a.mixerLevels[e] === t) ? a.mixerLevels : s
				}), r = t;
			}
			n = requestAnimationFrame(i);
		}
		n = requestAnimationFrame(i);
		let a = () => {
			document.hidden ? e.setSuspended(!0) : e.setSuspended(t);
		};
		document.addEventListener("visibilitychange", a);
		let o = y.current, s = (t) => e.lifted(`pointer-${t.pointerId}`), c = () => e.lifted();
		return o?.addEventListener("pointerup", s, !0), o?.addEventListener("touchend", c, !0), () => {
			cancelAnimationFrame(n), document.removeEventListener("visibilitychange", a), o?.removeEventListener("pointerup", s, !0), o?.removeEventListener("touchend", c, !0), e.dispose(), v.current = null;
		};
	}, [t, we]), i(() => {
		v.current?.setSuspended(t);
	}, [t]), i(() => {
		L(!0);
		let e = setTimeout(() => L(!1), Math.min(9e3, 3500 + N.text.length * 40));
		return () => clearTimeout(e);
	}, [N]), i(() => {
		v.current?.setMute(z);
	}, [z, t]), i(() => {
		v.current?.setClick(De);
	}, [De, t]);
	let [xr, Sr] = d(0);
	i(() => {
		let e = 0;
		try {
			e = Math.round(Number(localStorage.getItem(`${r}:recordOffset`) ?? 0));
		} catch {}
		Sr(Number.isFinite(e) ? Math.max(-100, Math.min(100, e)) : 0);
	}, [r]), i(() => {
		v.current?.setRecordOffset(xr);
	}, [xr]);
	let Cr = n((e) => {
		Sr(e);
		try {
			e ? localStorage.setItem(`${r}:recordOffset`, String(e)) : localStorage.removeItem(`${r}:recordOffset`);
		} catch {}
	}, [r]);
	i(() => {
		v.current?.setMix(et);
	}, [et, t]);
	let wr = n((e) => {
		g.current = e.patch, yn.current = e.mix, bn.current = e.mainMuted, xn.current = e.octave, In.current = e.session, f(e.patch), tt(e.mix), _e(e.mainMuted), Fe(e.octave), Fn(e.session);
	}, []), Tr = n(() => {
		Sn.current = Xn(), vn({
			undo: 0,
			redo: 0
		});
	}, []), Z = n((e, t = null) => {
		let n = {
			patch: g.current,
			mix: yn.current,
			mainMuted: bn.current,
			octave: xn.current,
			session: In.current
		}, r = {
			...n,
			...typeof e == "function" ? e(n) : e
		};
		(r.patch !== n.patch || r.mix !== n.mix || r.mainMuted !== n.mainMuted || r.octave !== n.octave || r.session !== n.session) && (Sn.current = Zn(Sn.current, n, t, Date.now()), vn({
			undo: Sn.current.past.length,
			redo: 0
		}), wr(r));
	}, [wr]), Er = n((e, t = null) => Z((t) => ({ patch: e(t.patch) }), t), [Z]), Dr = n((e, t) => {
		let n = g.current.modules.find((t) => t.id === e), r = Object.keys(t);
		if (!n || r.every((e) => n.params[e] === t[e])) return;
		let i = r.length === 1 ? Y[n.type].params.find((e) => e.id === r[0]) : void 0;
		Er((n) => ({
			...n,
			modules: n.modules.map((n) => n.id === e ? {
				...n,
				params: {
					...n.params,
					...t
				}
			} : n)
		}), i && !i.choices && !i.pattern ? `param:${e}:${i.id}` : null);
	}, [Er]), Or = n((e, t) => Z((n) => ({ mix: pn(n.mix, e, t) })), [Z]), kr = n((e) => Z((t) => ({ mix: mn(t.mix, e) })), [Z]), Ar = n((e) => {
		let t = In.current;
		un((n) => ({
			...n,
			[t]: {
				signature: On(e),
				patch: e
			}
		}));
	}, []);
	i(() => {
		let e, t = {
			presets: [],
			error: null
		}, n = null;
		try {
			Cn.current && Cn.current.key !== r && Qs(Cn.current), e = An(localStorage, r), t = ir(localStorage, `${r}:presets`), n = localStorage.getItem(`${r}:open`);
		} catch {
			e = {
				patch: null,
				error: "Local save unavailable. Export a patch file to keep your work."
			};
		}
		(e.error ?? t.error) && P(e.error ?? t.error);
		let i = e.patch ?? En(), a = e.patch ? Xs(r) : null;
		v.current?.panic(), J.current = gt(i).id, rt(J.current);
		let o = ct("session");
		Tn(t.presets), Mn(n && t.presets.some((e) => e.id === n) ? { [o]: n } : {}), Rn(null), wr({
			patch: i,
			mix: $t,
			mainMuted: !1,
			octave: xn.current,
			session: o
		}), Tr(), un({ [o]: a ?? {
			signature: On(i),
			patch: i
		} }), pe(null), j(r);
	}, [
		r,
		wr,
		Tr
	]), i(() => {
		if (fe !== r) return;
		let e = Cn.current = {
			key: r,
			patch: s,
			open: hr
		}, t = setTimeout(() => {
			try {
				pe({ error: Qs(e) });
			} catch {
				pe({ error: "Local save unavailable. Export a patch file to keep your work." });
			}
		}, 400);
		return () => clearTimeout(t);
	}, [
		s,
		hr,
		fe,
		r
	]), i(() => {
		if (fe === r && gr) try {
			Zs(r, gr);
		} catch {}
	}, [
		gr,
		fe,
		r
	]), i(() => {
		let e = (e) => {
			if (e.key === pr || e.key === null) try {
				Tn(ir(localStorage, pr).presets);
			} catch {}
		};
		return window.addEventListener("storage", e), () => window.removeEventListener("storage", e);
	}, [pr]), i(() => {
		let e = () => {
			if (Cn.current) try {
				Qs(Cn.current);
			} catch {}
		};
		return window.addEventListener("pagehide", e), () => {
			window.removeEventListener("pagehide", e), e();
		};
	}, []), i(() => () => {
		cancelAnimationFrame(Hn.current), cancelAnimationFrame(tr.current);
	}, []), i(() => (Yt.current = !0, zt(qn()), () => {
		Yt.current = !1, Ht.current?.(), Ht.current = null;
	}), []);
	let Q = n((e) => P(e instanceof Error ? e.message : "Audio could not start. Try enabling it again."), []), jr = n((e, t = !1, n) => {
		(!t || Xt.current.has(e)) && (Xt.current.delete(e), t ? v.current?.cancel(e) : v.current?.release(e, n), st.current.delete(e) && at(new Set(st.current.values())));
	}, []), Mr = n(() => {
		v.current?.releaseManual(), Xt.current.clear(), st.current.clear(), at(/* @__PURE__ */ new Set());
	}, []), Nr = n((e, n, r = !1, i) => {
		if (t) return;
		let a = g.current, o = a.modules.find((e) => e.id === J.current) ?? gt(a), s = Y[o.type];
		if (!Kt(o.type)) {
			P("Add an instrument or sequencer to play from the keys.");
			return;
		}
		Zt(a, o.id) || P(`${s.name} has no audio path to MAIN. Flip the rack to connect it.`);
		let c = o.type === "dictator" ? Ct(a, o.id) : null;
		if (c) {
			let t = Y[c.type].drum.voices[n];
			if (!t || st.current.has(e)) return;
			st.current.set(e, t.id), at(new Set(st.current.values())), v.current?.press(e, le[t.id], o.id, r, Te / 127, i).catch(Q);
		} else if (s.drum) {
			let t = s.drum.voices[n];
			if (!t || st.current.has(e)) return;
			st.current.set(e, t.id), at(new Set(st.current.values())), v.current?.hit(o.id, t.id, e, r).catch(Q);
		} else o.type === "noise" && (st.current.set(e, "noise"), at(new Set(st.current.values()))), v.current?.press(e, o.type === "noise" ? 60 : (Pe + 1) * 12 + n, o.id, r, Te / 127, i).catch(Q);
	}, [
		Q,
		t,
		Pe,
		Te
	]), Pr = n((e, t) => Ot((n) => n[e] === t ? n : {
		...n,
		[e]: t
	}), []), Fr = n((e, n) => {
		t || v.current?.hit(e, n).catch(Q);
	}, [Q, t]), Ir = n(() => {
		v.current?.playing ? v.current.pause() : v.current?.play().catch(Q);
	}, [Q]), Lr = n(() => {
		v.current?.rejoin().then((e) => {
			let t = e.map((e) => g.current.modules.find((t) => t.id === e)).filter((e) => !!e).map((e) => dn(g.current, e));
			t.length && P(`${t.length > 1 ? `${t.slice(0, -1).join(", ")} and ${t.at(-1)}` : t[0]} ${t.length > 1 ? "play" : "plays"} again, in time with the rest.`);
		}).catch(Q);
	}, [Q]), Rr = n((e) => {
		Kt(e.type) && J.current !== e.id && (Mr(), J.current = e.id, rt(e.id));
	}, [Mr]), zr = n((e) => {
		v.current?.arm(e), H(e);
		let t = e && g.current.modules.find((t) => t.id === e);
		t && Rr(t);
	}, [Rr]), Br = n(() => {
		let e = v.current;
		if (!e || t) return;
		if (e.recording) {
			e.finishTake();
			return;
		}
		let n = g.current.modules.filter((e) => e.type === "dictator"), r = n.find((t) => t.id === e.armedId)?.id ?? n.find((e) => e.id === J.current)?.id ?? (n.length === 1 ? n[0].id : null);
		r ? (zr(r), e.record(e.playing ? 0 : G).then((e) => {
			e && P(`Recording into ${dn(g.current, g.current.modules.find((e) => e.id === r))}. Play the keys; RECORD or R stops.`);
		}).catch(Q)) : P(n.length ? "Arm a DICTATOR to record into: its ARM button, beside its clip." : "Add a DICTATOR to record what you play: Add device, then DICTATOR.");
	}, [
		t,
		zr,
		G,
		Q
	]), Vr = n(() => {
		let e = v.current?.discardTake() ?? 0;
		P(e ? `Discarded ${e} ${e === 1 ? "note" : "notes"}. Still recording: play again.` : "Nothing recorded yet. Still recording.");
	}, []), Hr = n((e) => {
		let t = v.current, n = g.current.modules.find((t) => t.id === e);
		if (!t || !n || t.recording) return;
		let r = t.takeHeard(C(n.params.length)), i = dn(g.current, n);
		r.length ? (Z((t) => ({ patch: yt(t.patch, e, ie(_t(t.patch, e), r, !1, [])) })), P(`Captured ${r.length} ${r.length === 1 ? "note" : "notes"} into ${i}. Undo takes ${r.length === 1 ? "it" : "them"} back.`)) : P("Nothing to capture yet. Play the keys while the transport runs, then Capture keeps it.");
	}, [Z]), Ur = n((e, n) => {
		let r = v.current, i = g.current.modules.find((t) => t.id === e);
		if (!r || !i || t) return;
		let a = w(i.params.length), o = Math.max(0, r.clock);
		r.seek(o - o % a + n);
	}, [t]);
	i(() => {
		K.current = (e, t, n, r) => {
			let i = g.current.modules.find((t) => t.id === e);
			if (!i) return;
			let a = i.notes ?? [], o = ie(a, t, r, n), s = o.length !== a.length || o.some((e, t) => e.some((e, n) => e !== a[t][n]));
			s && Z((t) => ({ patch: yt(t.patch, e, o) })), Cn.current &&= {
				...Cn.current,
				patch: g.current
			};
			let c = dn(g.current, i);
			P(t.length ? `Recorded ${t.length} ${t.length === 1 ? "note" : "notes"} into ${c}. Undo takes the take back.` : s ? `Cleared what ${c} passed over. Undo brings it back.` : "Recording stopped. Nothing was played.");
		};
	}, [Z]), i(() => {
		if (!e || t || A || Ln !== null) return;
		let n = (e) => {
			let t = e.key.toLowerCase();
			t !== "r" && !(t === "backspace" && v.current?.recording) || e.repeat || e.defaultPrevented || e.metaKey || e.ctrlKey || e.altKey || (e.target instanceof Element ? e.target : null)?.closest("input, select, textarea, [contenteditable=\"true\"]") || (e.preventDefault(), t === "r" ? Br() : Vr());
		};
		return window.addEventListener("keydown", n), () => window.removeEventListener("keydown", n);
	}, [
		e,
		t,
		A,
		Ln,
		Br,
		Vr
	]), i(() => {
		if (!e || t || A || Ln !== null) {
			Mr();
			return;
		}
		function n(e) {
			if (e.defaultPrevented || e.metaKey || e.ctrlKey || e.altKey || e.target instanceof Element && e.target.closest("input, select, textarea, [contenteditable=\"true\"]")) return;
			let t = g.current.modules.find((e) => e.id === J.current), n = t?.type === "dictator" ? Ct(g.current, t.id) : null, r = t && (Y[(n ?? t).type].drum?.voices.length ?? +(t.type === "noise")), i = r ? Ps.slice(0, r) : Ms, a = e.key.toLowerCase();
			if (!r && (a === "z" || a === "x")) {
				e.preventDefault(), e.repeat || Z((e) => ({ octave: Math.min(6, Math.max(1, e.octave + (a === "x" ? 1 : -1))) }), "octave");
				return;
			}
			if ((!r || n) && S[a] !== void 0) {
				e.preventDefault(), Ee(S[a]);
				return;
			}
			let o = i.indexOf(a);
			o >= 0 && (e.preventDefault(), e.repeat || Nr(`key-${e.code}`, o, !1, e.timeStamp));
		}
		let r = (e) => jr(`key-${e.code}`, !1, e.timeStamp);
		return window.addEventListener("keydown", n), window.addEventListener("keyup", r), window.addEventListener("blur", Mr), () => {
			window.removeEventListener("keydown", n), window.removeEventListener("keyup", r), window.removeEventListener("blur", Mr), Mr();
		};
	}, [
		e,
		t,
		Nr,
		jr,
		Ir,
		A,
		Ln,
		Mr,
		Z
	]), i(() => {
		qt.current = ({ on: n, note: r, velocity: i, timeStamp: a }) => {
			let o = `midi-${r}`;
			if (jr(o, !1, a), !n || !e || t) return;
			let s = g.current, c = s.modules.find((e) => e.id === J.current) ?? gt(s);
			if (!Kt(c.type)) return;
			let l = c.type === "dictator" ? Ct(s, c.id) : null, u = Y[(l ?? c).type].drum, d = u ? de(u.voices, r) : c.type === "noise" ? "noise" : null;
			(!u || d) && (d && (st.current.set(o, d), at(new Set(st.current.values()))), u && !l ? v.current?.hit(c.id, d, o, !1, i / 127).catch(Q) : v.current?.press(o, c.type === "noise" ? 60 : r, c.id, !1, i / 127, a).catch(Q));
		};
	}, [
		e,
		t,
		jr,
		Q
	]);
	async function Wr() {
		if (Ht.current) Ht.current(), Ht.current = null, Vt(null), Mr(), P("MIDI input off.");
		else if (!Ut.current) {
			Ut.current = !0;
			try {
				let e = [], t = await Yn((e) => qt.current(e), (t) => {
					e = t, Vt(t);
				});
				if (!Yt.current) {
					t();
					return;
				}
				Ht.current = t, P(e.length ? `MIDI on: ${e.join(", ")} plays the keyboard’s device.` : "MIDI on. Connect a MIDI keyboard to play the keyboard’s device.");
			} catch {
				P("MIDI access was blocked. Allow MIDI devices for this site in the browser, then turn MIDI on again.");
			} finally {
				Ut.current = !1;
			}
		}
	}
	i(() => {
		if (!e || t || A || Ln !== null) return;
		let n = (e) => {
			if (e.code !== "Space" || e.metaKey || e.ctrlKey || e.altKey) return;
			let t = e.target instanceof Element ? e.target : null;
			t?.closest(Is) || (y.current?.contains(t) || !e.defaultPrevented && !t?.closest("button, [role=\"button\"], [role=\"slider\"], input, select, [contenteditable=\"true\"]")) && (e.preventDefault(), e.stopPropagation(), e.type === "keydown" && !e.repeat && Ir());
		};
		return window.addEventListener("keydown", n, !0), window.addEventListener("keyup", n, !0), () => {
			window.removeEventListener("keydown", n, !0), window.removeEventListener("keyup", n, !0);
		};
	}, [
		e,
		t,
		A,
		Ln,
		Ir
	]), i(() => {
		if (!Je) return;
		let e = b.current, t = e?.querySelector(`[data-module-id="${Je}"]`);
		if (e && t) {
			let n = t.offsetTop - 6, r = t.offsetTop + t.offsetHeight + 6, i = matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth";
			n < e.scrollTop || r - n > e.clientHeight ? e.scrollTo({
				top: n,
				behavior: i
			}) : r > e.scrollTop + e.clientHeight && e.scrollTo({
				top: r - e.clientHeight,
				behavior: i
			});
		}
		let n = setTimeout(() => Ye(null), 1400);
		return () => clearTimeout(n);
	}, [Je]);
	let Gr = n(() => {
		Vn.current = null, cancelAnimationFrame(Hn.current), Hn.current = 0, Ge(null);
	}, []), Kr = n(() => {
		let e = Vn.current;
		return !e?.moved || e.cancelled ? !1 : (e.cancelled = !0, cancelAnimationFrame(Hn.current), Hn.current = 0, Ge(null), !0);
	}, []), qr = n((e) => {
		let t = (e === "undo" ? Qn : $n)(Sn.current, {
			patch: g.current,
			mix: yn.current,
			mainMuted: bn.current,
			octave: xn.current,
			session: In.current
		});
		if (!t) return;
		Sn.current = t.history, vn({
			undo: t.history.past.length,
			redo: t.history.future.length
		}), Vn.current && (Wn.current = !0), Gr(), Ue(null), sn(null), Ve((e) => e && t.state.patch.cables.some((t) => t.id === e) ? e : null), t.state.patch.modules.some((e) => e.id === J.current) || (Mr(), J.current = gt(t.state.patch).id, rt(J.current)), wr(t.state);
		let n = e === "undo" ? t.history.past.length : t.history.future.length;
		P(`${e === "undo" ? "Undone" : "Redone"}. ${n} more ${n === 1 ? "step" : "steps"} to ${e}.`);
	}, [
		wr,
		Mr,
		Gr
	]);
	i(() => {
		let t = (t) => {
			t.key !== "Escape" || t.defaultPrevented || (Kr() ? (t.preventDefault(), P("Drag cancelled. Your cables are unchanged.")) : (He || an || Be) && (e || y.current?.contains(t.target)) && (t.preventDefault(), Ue(null), sn(null), Ve(null), P(an ? "Plug back in its jack." : "Patching cancelled.")));
		}, n = () => Kr();
		return window.addEventListener("keydown", t, !0), window.addEventListener("blur", n), () => {
			window.removeEventListener("keydown", t, !0), window.removeEventListener("blur", n);
		};
	}, [
		He,
		an,
		Be,
		e,
		Kr
	]), i(() => {
		if (!Be) return;
		let t = (t) => {
			if (t.key !== "Delete" && t.key !== "Backspace" || t.defaultPrevented || t.metaKey || t.ctrlKey || t.altKey) return;
			let n = t.target instanceof Element ? t.target : null;
			n?.closest("input, select, textarea, [contenteditable=\"true\"]") || !e && !y.current?.contains(n) || (t.preventDefault(), Er((e) => Ys(e, Be)), Ve(null), Ue(null), sn(null), P("Cable removed. Undo puts it back."));
		};
		return window.addEventListener("keydown", t, !0), () => window.removeEventListener("keydown", t, !0);
	}, [
		Be,
		e,
		Er
	]), i(() => {
		let n = (n) => {
			if (n.defaultPrevented || n.altKey || !(n.metaKey || n.ctrlKey) || A || Ln !== null) return;
			let r = n.key.toLowerCase(), i = r === "z" && !n.shiftKey, a = r === "z" && n.shiftKey || r === "y" && n.ctrlKey && !n.shiftKey;
			if (!i && !a) return;
			let o = n.target instanceof Element ? n.target : null;
			(y.current?.contains(o) || e && !t && !o?.closest("input, select, textarea, [contenteditable=\"true\"]")) && (n.preventDefault(), qr(i ? "undo" : "redo"));
		};
		return window.addEventListener("keydown", n, !0), () => window.removeEventListener("keydown", n, !0);
	}, [
		e,
		t,
		A,
		Ln,
		qr
	]);
	let Jr = n((e) => {
		try {
			let t = e(ir(localStorage, pr).presets);
			if (t.length > 200) return "My Presets holds up to 200 presets. Delete or export some first.";
			let n = ar(localStorage, pr, t);
			return n || Tn(t), n;
		} catch {
			return er;
		}
	}, [pr]), Yr = n((e, t) => {
		let n = Jr((n) => or(n, {
			id: e,
			savedAt: Date.now(),
			patch: t
		}));
		if (n) {
			P(n);
			return;
		}
		let r = In.current;
		Mn((t) => ({
			...t,
			[r]: e
		})), Ar(t), P(`Saved “${t.name}” in this browser.`);
	}, [Jr, Ar]), Xr = n((e) => {
		Bn.current = e ?? (document.activeElement instanceof HTMLElement ? document.activeElement : null), Rn(g.current.name);
	}, []), Zr = n((e) => {
		let t = g.current;
		!mr || !t.name.trim() || sr(wn, t.name, mr.id) ? Xr(e) : Yr(mr.id, t);
	}, [
		mr,
		wn,
		Xr,
		Yr
	]);
	i(() => {
		let n = (n) => {
			if (n.defaultPrevented || n.altKey || !(n.metaKey || n.ctrlKey) || n.key.toLowerCase() !== "s") return;
			let r = n.target instanceof Element ? n.target : null, i = !!y.current?.contains(r);
			A || Ln !== null ? i && n.preventDefault() : (i || e && !t && !r?.closest("input, select, textarea, [contenteditable=\"true\"]")) && (n.preventDefault(), n.shiftKey ? Xr() : Zr());
		};
		return window.addEventListener("keydown", n, !0), () => window.removeEventListener("keydown", n, !0);
	}, [
		e,
		t,
		A,
		Ln,
		Zr,
		Xr
	]);
	function Qr(e, t, n, r = null) {
		Er((r) => {
			let i = pt(r, e), a = i[t];
			return !a || Object.keys(n).every((e) => a[e] === n[e]) ? r : mt(r, e, i.map((e, r) => r === t ? {
				...e,
				...n
			} : e));
		}, r && `${r}:${e}`);
	}
	function $r(e, t) {
		Er((n) => n.sequencer[e] === t ? n : {
			...n,
			sequencer: {
				...n.sequencer,
				[e]: t
			}
		}, e);
	}
	function ei(e, t) {
		Er((n) => n.cables.some((n) => n.id === e && n.amount !== t) ? {
			...n,
			cables: n.cables.map((n) => n.id === e ? {
				...n,
				amount: t
			} : n)
		} : n, `depth:${e}`);
	}
	function ti(e, t, n = null) {
		Gr(), sn(null), v.current?.panic(), Mr();
		let r = ct("session");
		n && Mn((e) => ({
			...e,
			[r]: n
		})), Z({
			patch: e,
			mix: $t,
			mainMuted: !1,
			session: r
		}), Ar(e), ue(!1), J.current = gt(e).id, rt(J.current), q(null), Ve(null), Ue(null), P(yr ? `${t} Undo brings back your unsaved changes.` : t);
	}
	function ni() {
		br && yr && (Vn.current && (Wn.current = !0), Gr(), Ue(null), sn(null), q(null), Ve((e) => e && br.cables.some((t) => t.id === e) ? e : null), br.modules.some((e) => e.id === J.current) || (Mr(), J.current = gt(br).id, rt(J.current)), Z({ patch: br }), P(`Reverted to “${br.name}” as ${mr ? "last saved" : "loaded"}. Undo brings back your changes.`));
	}
	function ri() {
		Rn(null);
		let e = Bn.current;
		Bn.current = null, e?.isConnected && e.focus();
	}
	function ii(e) {
		e !== g.current.name && Er((t) => ({
			...t,
			name: e
		})), Yr(sr(wn, e)?.id ?? ct("preset"), g.current), ri();
	}
	function ai(e) {
		let t = Jr((t) => t.filter((t) => t.id !== e.id));
		P(t ?? `Deleted “${e.patch.name}” from this browser.${e.id === hr ? " The rack still has it; Save adds it back." : ""}`);
	}
	function oi(e) {
		let t = `${lr(e.name)}.rackloose.json`;
		Ws(Dn(e), "application/json", t), P(`Exported ${t}. Import it in any browser to add it to My Presets.`);
	}
	function si(e) {
		let t = Bi(e), n = C(e.params.length), r = s.modules.find((t) => t.id === St(s, e.id)), i = (e.notes ?? []).filter(([e]) => e < n).map(([e, t, r, i]) => [
			e,
			Math.min(t, n - e),
			r,
			i
		]), a = `${lr(s.name)}-${lr(t)}.mid`;
		Ws(Un([{
			name: r ? `${t} - ${Bi(r)}` : t,
			notes: i,
			channel: Ct(s, e.id) ? 9 : 0
		}], s.sequencer.bpm), "audio/midi", a), P(`Exported ${a}: ${i.length} ${i.length === 1 ? "note" : "notes"} at ${s.sequencer.bpm} BPM.`);
	}
	async function ci(e, t) {
		try {
			if (t.size > 1e6) throw Error("MIDI files must be smaller than 1 MB.");
			let n = Gn(new Uint8Array(await t.arrayBuffer()));
			if (!n.tracks.length) {
				Lt(null), P(`${t.name} has no notes to import.`);
				return;
			}
			n.tracks.length === 1 ? li(e, t.name, n.tracks) : Lt({
				id: e,
				file: t.name,
				song: n
			});
		} catch (e) {
			Q(e);
		}
	}
	function li(e, t, n) {
		Lt(null);
		let r = g.current.modules.find((t) => t.id === e);
		if (!r) return;
		let i = Kn(n.flatMap((e) => e.notes), vt(g.current, e)), a = Bi(r);
		Er((t) => yt({
			...t,
			modules: t.modules.map((t) => t.id === e ? {
				...t,
				params: {
					...t.params,
					length: i.length
				}
			} : t)
		}, e, i.notes));
		let o = i.dropped ? ` ${i.dropped} ${i.dropped === 1 ? "note was" : "notes were"} left out: past 16 bars, repeated, or over the note limit.` : "";
		P(`Imported ${i.notes.length} ${i.notes.length === 1 ? "note" : "notes"} from ${t} into ${a}, ${_[i.length]} ${i.length ? "bars" : "bar"} long.${o} Undo puts the clip back.`);
	}
	function ui(e) {
		let t = dt(e), n = g.current.modules.find((e) => e.id === J.current && ws(e)), r = n && (bt(n.type) ? ["trig"] : ["pitch", "gate"]).every((e) => !Dt(g.current, {
			moduleId: n.id,
			portId: e
		}));
		Er((i) => {
			let a = ht(i, [
				...i.modules.slice(0, -1),
				t,
				i.modules.at(-1)
			]);
			return e === "dictator" && r ? xt(a, t.id, n.id) : a;
		});
		let i = e !== "dictator" && Wt({
			...g.current,
			modules: [...g.current.modules, t]
		}, t);
		Rr(t), k(!1), Ye(t.id), P(`${Y[e].name} added${i ? " with a starter pattern. CLEAR empties it; flip" : ". Flip"} the rack to connect it.`);
	}
	function di(e) {
		let t = {
			...e,
			id: ct(),
			params: { ...e.params },
			...e.type === "performance" ? { steps: pt(g.current, e.id) } : {}
		};
		Er((n) => {
			let r = [...n.modules];
			return r.splice(r.findIndex((t) => t.id === e.id) + 1, 0, t), t.notes ? yt(ht(n, r), t.id, t.notes) : ht(n, r);
		}), Rr(t), Ye(t.id), P(`${Y[e.type].name} duplicated without its cables.`);
	}
	function fi(e) {
		if (e.key === "Tab") {
			let t = e.currentTarget.querySelectorAll("button");
			t.length === 1 && (e.preventDefault(), t[0].focus());
		}
	}
	function pi() {
		ae(null), (A === "about" ? ee : E).current?.focus();
	}
	function mi(e, t, n = null) {
		try {
			let r = Qt(g.current, e, t, n);
			if (Ue(null), sn(null), r === g.current) {
				P("Plug back in its jack.");
				return;
			}
			Z({ patch: r }), P(n ? "Cable moved." : "Connected. Flip to the front to hear your patch.");
		} catch (e) {
			Q(e);
		}
	}
	function hi(e) {
		Er((t) => Ys(t, e)), Ve(null), sn(null), P("Cable unplugged. Undo puts it back.");
	}
	function gi(e) {
		if (Wn.current) {
			Wn.current = !1;
			return;
		}
		let t = Dt(g.current, e);
		if (an) {
			t?.id === an.cableId && !X(e, an.anchor) ? (sn(null), P("Plug back in its jack.")) : mi(an.anchor, e, an.cableId);
			return;
		}
		if (He && X(He, e)) {
			Ue(null), P("Patching cancelled.");
			return;
		}
		if (He) {
			mi(He, e);
			return;
		}
		if (t) {
			sn({
				cableId: t.id,
				anchor: Js(t, e)
			}), Ve(t.id), P("Plug lifted. Choose a free jack, or tap empty rack space to unplug. Tap the jack again or press Escape to put it back.");
			return;
		}
		let n = Tt(g.current, e);
		n && (Ue(e), Ve(null), P(`Choose a free ${n.kind.toUpperCase()} ${n.direction === "out" ? "input" : "output"}. Escape cancels.`));
	}
	function _i(e) {
		D && !e.target.closest("button, [role=\"button\"], [role=\"slider\"], input, select, label, a") && (an ? hi(an.cableId) : He ? (Ue(null), P("Patching cancelled.")) : Ve(null));
	}
	function vi(e) {
		let t = b.current;
		if (!t) return null;
		let n = t.getBoundingClientRect(), r = e.clientX >= n.left && e.clientX <= n.right && e.clientY >= n.top && e.clientY <= n.bottom, i = null, a = Ls;
		r && t.querySelectorAll("[data-port-key]").forEach((t) => {
			let r = t.getBoundingClientRect(), o = r.left + r.width / 2, s = r.top + r.height / 2, c = e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom ? -1 : Math.hypot(o - e.clientX, s - e.clientY);
			c >= a || s < n.top || s > n.bottom || (i = Gs(t), a = c);
		});
		let o = !!i && X(i, e.anchor), s = i && !o ? jt(g.current, e.anchor, i, e.cableId) : null;
		return {
			anchor: e.anchor,
			cableId: e.cableId,
			target: s || o ? null : i,
			candidate: i,
			error: s,
			inside: r,
			point: {
				x: e.clientX - n.left + t.scrollLeft,
				y: e.clientY - n.top + t.scrollTop
			}
		};
	}
	function yi() {
		let e = Vn.current, t = b.current;
		if (!e?.moved || e.cancelled || !t) {
			Hn.current = 0;
			return;
		}
		let n = t.getBoundingClientRect(), r = n.top + Rs - e.clientY, i = e.clientY - (n.bottom - Rs);
		r > 0 ? t.scrollTop -= Math.ceil(Math.min(r, Rs) / 3) : i > 0 && (t.scrollTop += Math.ceil(Math.min(i, Rs) / 3));
		let a = vi(e);
		Ge((e) => e && a && qs(e, a) ? e : a), Hn.current = requestAnimationFrame(yi);
	}
	function bi(e, t) {
		if (!e.isPrimary || e.button !== 0) return;
		e.stopPropagation(), Wn.current = !1;
		let n = Dt(g.current, t);
		Vn.current = {
			pointerId: e.pointerId,
			anchor: n ? Js(n, t) : t,
			cableId: n?.id ?? null,
			x: e.clientX,
			y: e.clientY,
			clientX: e.clientX,
			clientY: e.clientY,
			moved: !1,
			cancelled: !1
		}, e.currentTarget.setPointerCapture(e.pointerId);
	}
	function xi(e) {
		let t = Vn.current;
		if (t && t.pointerId === e.pointerId && !t.cancelled) {
			if (t.clientX = e.clientX, t.clientY = e.clientY, !t.moved) {
				if (Math.hypot(e.clientX - t.x, e.clientY - t.y) <= 5) return;
				t.moved = !0, Ue(null), sn(null), Ve(t.cableId), P(t.cableId ? "Plug pulled out. Drop it on a free jack, or on empty rack space to unplug. Escape puts it back." : "Drop the plug on a free highlighted jack. Escape cancels.");
			}
			Hn.current ||= requestAnimationFrame(yi);
		}
	}
	function Si(e) {
		let t = Vn.current;
		if (!t || t.pointerId !== e.pointerId) return;
		t.clientX = e.clientX, t.clientY = e.clientY, t.moved ||= Math.hypot(t.clientX - t.x, t.clientY - t.y) > 5;
		let n = vi(t);
		Gr(), (t.moved || t.cancelled) && (Wn.current = !0), t.moved && !t.cancelled && (n?.error ? P(`${n.error}${t.cableId ? " The plug went back in its jack." : ""}`) : n?.target ? (mi(t.anchor, n.target, t.cableId), t.cableId && Ve(t.cableId)) : t.cableId && n?.inside && !n.candidate ? hi(t.cableId) : P(t.cableId ? "Plug back in its jack." : "Connection cancelled. Your cables are unchanged."));
	}
	function Ci() {
		Vn.current && (Wn.current = !0, Gr());
	}
	function wi(e) {
		let t = an?.anchor ?? He;
		t && !Vn.current && e.pointerType === "mouse" && (Jn.current = {
			anchor: t,
			cableId: an?.cableId ?? null,
			clientX: e.clientX,
			clientY: e.clientY
		}, tr.current ||= requestAnimationFrame(() => {
			tr.current = 0;
			let e = Jn.current && vi(Jn.current);
			qe((t) => t && e && qs(t, e) ? t : e);
		}));
	}
	async function Ti(e) {
		if (e) {
			try {
				if (e.size > 1e6) throw Error("Patch files must be smaller than 1 MB.");
				let t = await e.text(), n = kn(t), r = n.cables.length;
				try {
					let e = JSON.parse(t);
					Array.isArray(e.cables) && (r = e.cables.length);
				} catch {}
				let i = r - n.cables.length, a = i > 0 ? ` ${i} ${i === 1 ? "cable shared a jack" : "cables shared jacks"} with no spare left, so ${i === 1 ? "it was" : "they were"} left out.` : "", o = n.name.trim() ? n.name : "Imported patch", s = sr(wn, o);
				if (s && On(s.patch) === On({
					...n,
					name: s.patch.name
				})) ti(s.patch, `“${s.patch.name}” is already in My Presets, so it opened.${a}`, s.id);
				else {
					let e = {
						id: ct("preset"),
						savedAt: Date.now(),
						patch: {
							...n,
							name: s ? cr(wn, o) : o
						}
					}, t = Jr((t) => or(t, e));
					ti(e.patch, t ? `Opened “${e.patch.name}”. ${t}${a}` : `Imported “${e.patch.name}” into My Presets.${s ? ` You already had a different “${s.patch.name}”.` : ""}${a}`, t ? null : e.id);
				}
			} catch (e) {
				Q(e);
			}
			T.current && (T.current.value = "");
		}
	}
	async function Ei() {
		$e(!0), P("Rendering your patch…");
		try {
			Ws(na(await ta(s, Xe, et)), "audio/wav", `${lr(s.name)}.wav`), P("WAV exported. Your loop includes a two-second effects tail.");
		} catch (e) {
			Q(e);
		} finally {
			$e(!1);
		}
	}
	let Di = s.cables.find((e) => e.id === Be), Oi = an?.anchor ?? He, ki = an?.cableId ?? null, Ai = We ?? (D && Oi && Ke && X(Ke.anchor, Oi) && Ke.cableId === ki ? Ke : null), ji = We?.anchor ?? Oi, Mi = We ? We.cableId : ki, Ni = Ai?.cableId ?? null;
	function Pi(e, t, n) {
		let r = Y[e.type], i = {
			moduleId: e.id,
			portId: t.id
		}, a = !!ji && X(ji, i), o = Dt(s, i), c = !!o && (o.id !== Ni || a), l = t.direction === "in" ? "input" : "output", u = e.type === "mixer" && t.direction === "in" ? fn(s, e.id, t.id) : null, d = u ? `Channel ${t.id.toUpperCase()}: ${u.source}` : t.label;
		return /* @__PURE__ */ m("button", {
			className: $.socket,
			"data-port-key": `${e.id}:${t.id}`,
			"data-kind": t.kind,
			"data-jack": n ?? void 0,
			"data-connected": c,
			"data-compatible": !!ji && !a && !jt(s, ji, i, Mi),
			"data-pending": a,
			"data-lifted": !!an && o?.id === an.cableId && !a,
			"data-target": !!Ai?.target && X(Ai.target, i),
			"data-selected-end": !!Di && Di.id !== Ni && (X(Di.from, i) || X(Di.to, i)),
			"aria-label": `${r.name} ${d} ${l}${n && n > 1 ? ` ${n}` : ""}`,
			"aria-description": `${t.kind.toUpperCase()} ${l}${u?.tooltip ? ` · ${u.tooltip}` : ""}`,
			title: `${d}${u?.tooltip ? ` · ${u.tooltip}` : ""}${n ? ` · jack ${n}` : ""} · ${t.kind.toUpperCase()}${o ? " · plugged" : ""}`,
			onClick: () => gi(i),
			onPointerDown: (e) => bi(e, i),
			onPointerMove: xi,
			onPointerUp: Si,
			onPointerCancel: Ci,
			onLostPointerCapture: Ci,
			children: /* @__PURE__ */ m("span", {})
		}, t.id);
	}
	function Fi(e) {
		let t = Y[e.type];
		return /* @__PURE__ */ m("div", {
			className: $.portGroups,
			children: ["in", "out"].filter((e) => t.ports.some((t) => t.direction === e)).map((n) => {
				let r = t.ports.filter((e) => e.direction === n);
				return /* @__PURE__ */ h("div", {
					className: $.portGroup,
					"data-direction": n,
					children: [/* @__PURE__ */ m("span", {
						className: $.portHeading,
						children: n === "in" ? "INPUTS" : "OUTPUTS"
					}), /* @__PURE__ */ m("div", {
						className: $.portRow,
						children: r.filter((e) => !e.copyOf).map((i) => {
							let a = r.filter((e) => e === i || e.copyOf === i.id), o = n === "in" && i.kind === "cv", c = o ? s.cables.find((t) => X(t.to, {
								moduleId: e.id,
								portId: i.id
							})) : void 0, l = e.type === "mixer" && n === "in" ? fn(s, e.id, i.id) : null;
							return /* @__PURE__ */ h("div", {
								className: $.socketControl,
								"data-source": !!l,
								"data-trim": o,
								"data-jacks": a.length,
								children: [
									a.length > 1 ? /* @__PURE__ */ m("div", {
										className: $.jacks,
										children: a.map((n) => Pi(e, n, Et(t.ports, n)))
									}) : Pi(e, i, null),
									o && /* @__PURE__ */ m(aa, {
										trim: !0,
										param: zs,
										value: c?.amount ?? zs.initial,
										format: Bs,
										prefix: `${t.name} ${i.label}`,
										disabled: !c,
										onChange: (e) => {
											c && ei(c.id, e);
										}
									}),
									/* @__PURE__ */ m("span", {
										title: l?.tooltip || void 0,
										children: l?.source ?? i.label
									}),
									(n !== "in" || i.kind !== "audio") && /* @__PURE__ */ h("small", { children: [i.kind.toUpperCase(), c && ` · ${Bs(c.amount)}`] })
								]
							}, i.id);
						})
					})]
				}, n);
			})
		});
	}
	function Ii(e) {
		let t = lt[e.id];
		return Y[e.type].drum?.voices.some((e) => e.id === t) ? t : void 0;
	}
	function Li(e, t, n) {
		return t.choices ? /* @__PURE__ */ h("label", {
			className: $.selectControl,
			title: t.hint,
			children: [
				/* @__PURE__ */ m("span", {
					className: $.controlLabel,
					children: t.label
				}),
				/* @__PURE__ */ m("select", {
					"aria-label": `${n} ${t.label}`,
					value: e.params[t.id],
					onChange: (n) => Dr(e.id, { [t.id]: Number(n.target.value) }),
					children: t.choices.map((e, t) => /* @__PURE__ */ m("option", {
						value: t,
						children: e
					}, e))
				}),
				/* @__PURE__ */ m(Na, {
					param: t,
					value: e.params[t.id]
				})
			]
		}, t.id) : /* @__PURE__ */ m(aa, {
			param: t,
			prefix: n,
			value: e.params[t.id],
			onChange: (n) => Dr(e.id, { [t.id]: n })
		}, t.id);
	}
	function Ri(e) {
		let t = Y[e.type], n = [...new Set(t.params.filter((e) => e.group && !e.voice).map((e) => e.group))];
		return n.length ? /* @__PURE__ */ m("div", {
			className: $.groupControls,
			"data-type": e.type,
			children: n.map((n) => /* @__PURE__ */ h("fieldset", {
				"data-group": n,
				children: [/* @__PURE__ */ m("legend", { children: n }), /* @__PURE__ */ m("div", {
					className: $.controls,
					children: t.params.filter((e) => e.group === n && !Me.includes(e.id)).map((r) => Li(e, r, `${t.name} ${n}`))
				})]
			}, n))
		}) : null;
	}
	function zi(e) {
		let t = Y[e.type];
		return /* @__PURE__ */ m("div", {
			className: $.controls,
			children: t.params.filter((e) => !e.voice && !e.group && !Me.includes(e.id)).map((n) => Li(e, n, t.name))
		});
	}
	function Bi(e) {
		return dn(s, e);
	}
	function Vi(e) {
		let n = !!en[e.id]?.playing;
		return /* @__PURE__ */ h("button", {
			className: $.playButton,
			disabled: t,
			"aria-label": `${n ? "Stop" : "Play"} ${Bi(e)} sequencer`,
			"data-playing": n,
			onClick: () => {
				v.current?.modulePlaying(e.id) ? v.current.stopModule(e.id) : v.current?.play(e.id).catch(Q);
			},
			children: [/* @__PURE__ */ m(Va, { name: n ? "stop" : "play" }), /* @__PURE__ */ m("span", { children: n ? "STOP" : "PLAY" })]
		});
	}
	function Hi(e) {
		let n = Bi(e), r = e.type === "performance" ? "steps" : "hits";
		return /* @__PURE__ */ m("button", {
			className: $.clearPatternButton,
			disabled: t || !Wt(s, e),
			"aria-label": `Clear ${n} pattern`,
			title: `Clear every ${e.type === "performance" ? "step" : "hit"} in the pattern. Undo brings them back.`,
			onClick: () => {
				Er((t) => Gt(t, e.id)), P(`${n} cleared. Undo brings its ${r} back.`);
			},
			children: /* @__PURE__ */ m("span", { children: "CLEAR" })
		});
	}
	let Ui = me && ke === null && !t && s.modules.some((e) => Jt(e.type) && !en[e.id]?.playing), Wi = s.modules.find((e) => e.id === nt) ?? gt(s), Gi = Y[Wi.type], Ki = Wi.type === "dictator" ? Ct(s, Wi.id) : null, qi = Y[(Ki ?? Wi).type], Ji = qi.drum?.voices ?? (Wi.type === "noise" ? [{
		id: "noise",
		label: "Noise"
	}] : null), Yi = (e) => {
		Gi.drum && !t && Pr(Wi.id, e);
	}, Xi = Ji && Ji.length > 6 ? Math.ceil(Ji.length / 2) : 6, Zi = Zt(s, Wi.id) ? null : `${Gi.name} needs an audio path to MAIN. Flip the rack to connect it.`;
	function Qi(e) {
		let n = Bi(e), r = Y.dictator, i = V === e.id, a = C(e.params.length), o = x[e.params.quantize]?.[1] ?? 240;
		return /* @__PURE__ */ m(Ds, {
			module: e,
			patch: s,
			name: n,
			clock: me ? en[e.id]?.clock ?? -1 : ve,
			take: je?.id === e.id ? je.notes : null,
			onSeek: (t) => Ur(e.id, t),
			armed: i,
			recording: U,
			disabled: t,
			offset: xr,
			onOffset: Cr,
			onCapture: () => Hr(e.id),
			onDiscard: Vr,
			transport: Vi(e),
			control: (t) => Li(e, r.params.find((e) => e.id === t), n),
			onParam: (t, n) => Dr(e.id, { [t]: n }),
			plays: St(s, e.id),
			editing: Mt === e.id,
			grid: o,
			onEditing: (t) => {
				Ft(t ? e.id : null), t && Rr(e);
			},
			onNotes: (t, n) => Er((n) => yt(n, e.id, t), n ? `${e.id}:${n}` : null),
			importing: It?.id === e.id ? {
				file: It.file,
				tracks: It.song.tracks
			} : null,
			onExportMidi: () => si(e),
			onImportMidi: (t) => void ci(e.id, t),
			onImportTracks: (t) => {
				It && li(e.id, It.file, t === null ? It.song.tracks : [It.song.tracks[t]]);
			},
			onImportCancel: () => Lt(null),
			onAudition: (n, r, i) => {
				t || U || i && !v.current?.ready || v.current?.audition(n, e.id, r / 127).catch(Q);
			},
			onAuditionEnd: () => v.current?.endAudition(),
			onArm: () => {
				i ? (U && v.current?.finishTake(), zr(null)) : zr(e.id);
			},
			onPlays: (t) => {
				let r = s.modules.find((e) => e.id === t);
				if (r) try {
					Er((n) => xt(n, e.id, t)), P(`${n} plays ${Bi(r)}. Undo puts the cables back as they were.`);
				} catch (e) {
					Q(e);
				}
			},
			onClear: () => {
				Er((t) => Gt(t, e.id)), P(`${n} cleared. Undo brings its notes back.`);
			},
			onQuantize: (t) => {
				t || Er((t) => yt(t, e.id, ne(e.notes ?? [], o, 1, a))), P(`${t ? `${t} selected ${t === 1 ? "note" : "notes"}` : `${n}'s notes`} moved onto the ${x[e.params.quantize]?.[0] ?? "1/16"} grid. Undo moves them back.`);
			}
		});
	}
	function $i(e = !1) {
		e && Re && ze.current.get(Re.moduleId)?.focus(), q(null);
	}
	function ra(e) {
		let t = pt(s, e.id), n = en[e.id]?.clock ?? -1, r = n < 0 ? -1 : n % 16, i = Bi(e), a = i !== Y[e.type].name, o = Re?.moduleId === e.id, c = o ? Re.index : null, l = c === null ? null : t[c];
		return /* @__PURE__ */ h("div", {
			className: $.sequenceBody,
			"data-editing": o,
			children: [
				/* @__PURE__ */ h("div", {
					className: $.sequenceTop,
					children: [
						/* @__PURE__ */ h("div", {
							className: $.lcdStack,
							children: [/* @__PURE__ */ h("div", {
								className: $.lcd,
								children: [
									/* @__PURE__ */ m("small", { children: "SEQUENCER" }),
									/* @__PURE__ */ h("strong", { children: [r >= 0 ? String(r + 1).padStart(2, "0") : "16", /* @__PURE__ */ m("span", { children: "STEPS" })] }),
									/* @__PURE__ */ m("span", {
										className: $.lcdDots,
										"aria-hidden": "true"
									})
								]
							}), /* @__PURE__ */ m("span", {
								className: $.transportCaption,
								children: "16TH NOTE / MONO"
							})]
						}),
						Y.performance.params.map((t) => Li(e, t, i)),
						/* @__PURE__ */ h("div", {
							className: `${$.transport} ${$.stepTransport}`,
							children: [Vi(e), /* @__PURE__ */ h("div", {
								className: $.transportKeys,
								children: [Hi(e), /* @__PURE__ */ m("button", {
									ref: (t) => {
										t ? ze.current.set(e.id, t) : ze.current.delete(e.id);
									},
									className: $.stepEditButton,
									"aria-pressed": o,
									"aria-label": `Edit ${i} steps`,
									title: "Pick a step to set its note, velocity and gate. Turn EDIT off to switch steps on and off again.",
									onClick: () => q(o ? null : {
										moduleId: e.id,
										index: null
									}),
									children: "EDIT"
								})]
							})]
						})
					]
				}),
				/* @__PURE__ */ m("div", {
					className: $.steps,
					role: "group",
					"aria-label": `${i} steps`,
					children: t.map((t, n) => /* @__PURE__ */ h("div", {
						className: $.stepCell,
						children: [/* @__PURE__ */ h("button", {
							className: $.step,
							"data-enabled": t.enabled,
							"data-silent": !ln(e.id, n, et),
							"data-current": r === n,
							"data-editing": c === n,
							"aria-label": `Step ${n + 1}: ${t.enabled ? Pn(t.note) : "rest"}`,
							"aria-pressed": o ? c === n : t.enabled,
							onClick: () => {
								o ? q({
									moduleId: e.id,
									index: n
								}) : Qr(e.id, n, { enabled: !t.enabled });
							},
							children: [
								/* @__PURE__ */ m("span", { className: $.stepLed }),
								/* @__PURE__ */ m("span", {
									className: $.stepNumber,
									children: String(n + 1).padStart(2, "0")
								}),
								/* @__PURE__ */ m("strong", { children: t.enabled || o ? Pn(t.note) : "—" })
							]
						}), /* @__PURE__ */ m(Ha, {
							mixKey: tn(e.id, n),
							label: a ? `${i} step ${n + 1}` : `step ${n + 1}`,
							mix: et,
							onToggle: Or
						})]
					}, n))
				}),
				c !== null && l && /* @__PURE__ */ h("div", {
					className: $.stepEditor,
					children: [
						/* @__PURE__ */ h("strong", { children: ["STEP ", String(c + 1).padStart(2, "0")] }),
						/* @__PURE__ */ h("label", { children: [/* @__PURE__ */ m("input", {
							type: "checkbox",
							checked: l.enabled,
							onChange: (t) => Qr(e.id, c, { enabled: t.target.checked })
						}), "Note on"] }),
						/* @__PURE__ */ h("label", { children: ["Note", /* @__PURE__ */ m("select", {
							"aria-label": "Step note",
							value: l.note,
							onChange: (t) => Qr(e.id, c, { note: Number(t.target.value) }),
							children: Array.from({ length: 73 }, (e, t) => t + 24).map((e) => /* @__PURE__ */ m("option", {
								value: e,
								children: Pn(e)
							}, e))
						})] }),
						/* @__PURE__ */ h("label", { children: [
							"Velocity",
							/* @__PURE__ */ m("input", {
								"aria-label": "Step velocity",
								type: "range",
								min: 0,
								max: 1,
								step: .01,
								value: l.velocity,
								onChange: (t) => Qr(e.id, c, { velocity: Number(t.target.value) }, `step:${c}:velocity`)
							}),
							/* @__PURE__ */ h("output", { children: [Math.round(l.velocity * 100), "%"] })
						] }),
						/* @__PURE__ */ h("label", { children: [
							"Gate",
							/* @__PURE__ */ m("input", {
								"aria-label": "Step gate",
								type: "range",
								min: .1,
								max: .95,
								step: .01,
								value: l.gate,
								onChange: (t) => Qr(e.id, c, { gate: Number(t.target.value) }, `step:${c}:gate`)
							}),
							/* @__PURE__ */ h("output", { children: [Math.round(l.gate * 100), "%"] })
						] }),
						/* @__PURE__ */ m("button", {
							onClick: () => $i(!0),
							"aria-label": "Close step editor",
							children: "×"
						})
					]
				}),
				/* @__PURE__ */ h("div", {
					className: $.sequenceHint,
					children: [o ? "Click a step to edit it. Turn EDIT off to switch steps on and off." : "Click a step to switch it on or off. EDIT sets its note, velocity & gate.", /* @__PURE__ */ m("span", { children: "PATCHABLE PITCH + GATE" })]
				})
			]
		});
	}
	let ia = on(s, et), oa = ur(yr, M), sa = wt(s), la = /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("img", {
		className: $.brandMark,
		src: As,
		width: "48",
		height: "48",
		alt: ""
	}), /* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("strong", { children: "Rackloose" }), /* @__PURE__ */ m("small", { children: "MODULAR SYNTHESIZER" })] })] }), ua = Ai || He || an ? Mi ? "Drop the plug on a free highlighted jack, or on empty rack space to unplug. Escape puts it back." : "Choose a free highlighted jack. Escape cancels." : Di ? "Drag either plug to move it. Delete unplugs this cable." : "One cable per jack. Drag from a jack to patch; drag a plug to move or unplug it.";
	return /* @__PURE__ */ m(Go.Provider, {
		value: we,
		children: /* @__PURE__ */ h("section", {
			ref: y,
			className: $.app,
			"aria-label": "Rackloose modular synthesizer",
			onKeyDown: (e) => {
				e.key !== "Escape" || e.defaultPrevented || (A ? pi() : Ln === null ? oe ? (ue(!1), zn.current?.focus()) : O ? (k(!1), te.current?.focus()) : He || Be || an ? (Ue(null), Ve(null), sn(null), P(an ? "Plug back in its jack." : "Patching cancelled.")) : Re && $i(!0) : ri());
			},
			children: [
				/* @__PURE__ */ h("header", {
					className: $.toolbar,
					children: [o ? /* @__PURE__ */ m("a", {
						className: $.brand,
						href: "https://rackloose.michaelzick.com/",
						target: "_blank",
						rel: "noopener noreferrer",
						title: "Open Rackloose in a new tab",
						children: la
					}) : /* @__PURE__ */ m("div", {
						className: $.brand,
						children: la
					}), /* @__PURE__ */ h("div", {
						className: $.toolbarActions,
						children: [
							/* @__PURE__ */ h("button", {
								className: $.audioButton,
								"data-ready": R,
								disabled: t,
								onClick: () => {
									R ? (v.current?.panic(), P("Audio stopped.")) : v.current?.unlock().then(() => P("Audio enabled. Play A–K, tap a key, or start the pattern.")).catch(Q);
								},
								children: [/* @__PURE__ */ m("span", { className: $.statusLed }), R ? "Audio on" : "Enable audio"]
							}),
							/* @__PURE__ */ m("button", {
								onClick: () => {
									v.current?.panic(), P("Panic: all sound and pending notes cleared.");
								},
								title: "Immediately silence all sound",
								children: "Panic"
							}),
							/* @__PURE__ */ m("button", {
								ref: E,
								onClick: () => ae("guide"),
								"aria-label": "Open user guide",
								title: "User guide",
								children: "?"
							})
						]
					})]
				}),
				/* @__PURE__ */ m("div", {
					className: $.patchBar,
					children: /* @__PURE__ */ h("div", {
						className: $.patchRow,
						children: [
							/* @__PURE__ */ h("div", {
								className: $.patchIdentity,
								children: [/* @__PURE__ */ h("label", {
									className: $.patchName,
									children: [/* @__PURE__ */ m("span", { children: "PATCH" }), /* @__PURE__ */ h("span", {
										className: $.nameField,
										"data-value": s.name,
										children: [/* @__PURE__ */ m("input", {
											"aria-label": "Patch name",
											"aria-describedby": yr ? fr : void 0,
											maxLength: 100,
											size: 1,
											value: s.name,
											onChange: (e) => {
												let t = e.target.value;
												Er((e) => e.name === t ? e : {
													...e,
													name: t
												}, "name");
											}
										}), yr && /* @__PURE__ */ h("span", {
											id: fr,
											className: $.dirtyMark,
											title: "Unsaved changes",
											children: [/* @__PURE__ */ m("span", {
												"aria-hidden": "true",
												children: "*"
											}), /* @__PURE__ */ m("span", {
												className: $.visuallyHidden,
												children: "Unsaved changes"
											})]
										})]
									})]
								}), /* @__PURE__ */ m("span", {
									className: $.saveStatus,
									"data-save-status": !0,
									"data-state": oa.state,
									"aria-live": "polite",
									title: oa.detail || void 0,
									children: oa.text && /* @__PURE__ */ h(p, { children: [
										/* @__PURE__ */ m("span", {
											className: $.saveLed,
											"aria-hidden": "true"
										}),
										/* @__PURE__ */ m("span", { children: oa.text }),
										oa.state === "failed" && /* @__PURE__ */ m("span", {
											className: $.visuallyHidden,
											children: oa.detail
										})
									] })
								})]
							}),
							/* @__PURE__ */ h("span", {
								className: $.barGroup,
								role: "group",
								"aria-label": "Save and presets",
								children: [/* @__PURE__ */ m("button", {
									"aria-label": "Save to My Presets",
									title: "Save to My Presets in this browser (⌘S / Ctrl+S)",
									onClick: (e) => Zr(e.currentTarget),
									children: "Save"
								}), /* @__PURE__ */ m("button", {
									ref: zn,
									className: $.presetsButton,
									"aria-expanded": oe,
									onClick: () => {
										ue(!oe), k(!1);
									},
									children: "Presets"
								})]
							}),
							/* @__PURE__ */ h("span", {
								className: `${$.barGroup} ${$.exportControls}`,
								role: "group",
								"aria-label": "Export audio",
								children: [/* @__PURE__ */ m("select", {
									"aria-label": "Export loop count",
									title: "Loops to render",
									value: Xe,
									onChange: (e) => Ze(Number(e.target.value)),
									children: [
										1,
										2,
										4,
										8
									].map((e) => /* @__PURE__ */ h("option", {
										value: e,
										children: [
											e,
											" ",
											e === 1 ? "loop" : "loops"
										]
									}, e))
								}), /* @__PURE__ */ m("button", {
									disabled: Qe,
									"aria-busy": Qe,
									title: "Render every sequencer to a WAV file",
									onClick: () => void Ei(),
									children: Qe ? "Rendering…" : "↓ Export WAV"
								})]
							}),
							/* @__PURE__ */ m("input", {
								ref: T,
								type: "file",
								accept: ".json,application/json",
								hidden: !0,
								"aria-label": "Import patch file",
								onChange: (e) => void Ti(e.target.files?.[0])
							}),
							/* @__PURE__ */ h("div", {
								className: $.rackActions,
								children: [/* @__PURE__ */ h("span", {
									className: `${$.barGroup} ${$.historyActions}`,
									role: "group",
									"aria-label": "Edit history",
									children: [
										/* @__PURE__ */ m("button", {
											"aria-label": "Undo",
											title: "Undo (⌘Z / Ctrl+Z)",
											disabled: !hn.undo,
											onClick: () => qr("undo"),
											children: /* @__PURE__ */ m(Va, { name: "undo" })
										}),
										/* @__PURE__ */ m("button", {
											"aria-label": "Redo",
											title: "Redo (⇧⌘Z / Ctrl+Y)",
											disabled: !hn.redo,
											onClick: () => qr("redo"),
											children: /* @__PURE__ */ m(Va, { name: "redo" })
										}),
										/* @__PURE__ */ m("button", {
											title: `Revert to the patch as ${mr ? "last saved" : "loaded"}`,
											disabled: !yr || !br,
											onClick: ni,
											children: "Revert"
										})
									]
								}), /* @__PURE__ */ h("span", {
									className: $.barGroup,
									role: "group",
									"aria-label": "Rack",
									children: [/* @__PURE__ */ m("button", {
										ref: te,
										className: $.addButton,
										"aria-expanded": O,
										onClick: () => {
											k(!O), ue(!1);
										},
										children: "＋ Add device"
									}), /* @__PURE__ */ h("button", {
										className: $.flipButton,
										"aria-label": D ? "Show front" : "Flip rack",
										"aria-pressed": D,
										onClick: () => {
											Gr(), re(!D), Ue(null), Ve(null), sn(null), P(D ? "Front panel. Turn a knob and make it yours." : "Rear panel. Drag from one jack to another, or tap one then the other.");
										},
										children: ["⇄ ", D ? "Show front" : "Flip rack"]
									})]
								})]
							})
						]
					})
				}),
				oe && /* @__PURE__ */ m(Ho, {
					presets: wn,
					openId: hr,
					dirty: yr,
					onSaveAs: Xr,
					onImport: () => T.current?.click(),
					onExportCurrent: () => oi(s),
					onExport: oi,
					onDelete: ai,
					onLoad: (e) => ti(e.patch, `Loaded “${e.patch.name}” from My Presets.`, e.id),
					onLoadFactory: (e) => ti(En(e), `${e} loaded. Your rack is patched and ready to play.`),
					onClose: () => {
						ue(!1), zn.current?.focus();
					}
				}),
				O && /* @__PURE__ */ h("div", {
					className: $.library,
					role: "region",
					"aria-label": "Device library",
					children: [/* @__PURE__ */ h("div", {
						className: $.libraryHeading,
						children: [/* @__PURE__ */ m("strong", { children: "MAKE ROOM FOR SOMETHING NEW." }), /* @__PURE__ */ m("button", {
							"aria-label": "Close device library",
							onClick: () => k(!1),
							children: "×"
						})]
					}), /* @__PURE__ */ m("div", {
						className: $.libraryGrid,
						children: ot.map((e) => /* @__PURE__ */ h("button", {
							"data-device": Y[e].color,
							disabled: s.modules.length >= 32,
							onClick: () => ui(e),
							children: [
								/* @__PURE__ */ h("span", {
									className: $.miniDevice,
									children: ["◉ ◉ ", /* @__PURE__ */ m("span", { children: "▰" })]
								}),
								/* @__PURE__ */ m("strong", { children: Y[e].name }),
								/* @__PURE__ */ m("small", { children: Y[e].subtitle })
							]
						}, e))
					})]
				}),
				/* @__PURE__ */ h("div", {
					className: $.rackHeading,
					children: [/* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m("span", { className: $.rackLight }), D ? "REAR PANEL / SIGNAL ROUTING" : "YOUR RACK / FRONT PANEL"] }), /* @__PURE__ */ h("span", { children: [
						s.modules.length,
						" DEVICES · ",
						s.cables.length,
						" CONNECTIONS"
					] })]
				}),
				D && /* @__PURE__ */ h("div", {
					className: $.routingBar,
					children: [/* @__PURE__ */ m("span", { children: ua }), /* @__PURE__ */ h("span", {
						className: $.legend,
						children: [
							/* @__PURE__ */ m("i", { "data-kind": "audio" }),
							" AUDIO ",
							/* @__PURE__ */ m("i", { "data-kind": "cv" }),
							" CV ",
							/* @__PURE__ */ m("i", { "data-kind": "gate" }),
							" GATE"
						]
					})]
				}),
				/* @__PURE__ */ h("div", {
					className: $.rack,
					ref: b,
					"data-holding": !!Ai,
					onClick: _i,
					onPointerMove: wi,
					onPointerLeave: () => qe(null),
					children: [
						D && /* @__PURE__ */ m(ca, {
							patch: s,
							rackRef: b,
							selected: Be,
							onSelect: (e) => {
								Ve(e), Ue(null), sn(null);
							},
							drag: Ai
						}),
						s.modules.map((e, n) => {
							let r = Y[e.type], i = ut(e.type), a = Vs.includes(e.type), o = (t) => Pr(e.id, t);
							return /* @__PURE__ */ h("article", {
								className: $.module,
								"data-module-id": e.id,
								"data-device": r.color,
								"data-rear": D,
								"data-revealed": Je === e.id,
								"data-silent": ia[e.id] === !1,
								"data-keyboard-target": Wi.id === e.id,
								onPointerDown: () => {
									D || Rr(e);
								},
								onFocus: () => {
									D || Rr(e);
								},
								"aria-label": `${r.name} ${r.subtitle}`,
								children: [
									/* @__PURE__ */ m("span", { className: `${$.screw} ${$.screwTL}` }),
									/* @__PURE__ */ m("span", { className: `${$.screw} ${$.screwTR}` }),
									/* @__PURE__ */ m("span", { className: `${$.screw} ${$.screwBL}` }),
									/* @__PURE__ */ m("span", { className: `${$.screw} ${$.screwBR}` }),
									/* @__PURE__ */ h("div", {
										className: $.moduleHeader,
										children: [
											/* @__PURE__ */ h("div", {
												className: $.moduleIdentity,
												children: [
													rn(e.type) && /* @__PURE__ */ m(Ko, {
														select: (t) => t.pulsing.has(e.id),
														children: (e) => /* @__PURE__ */ m("span", {
															className: $.hitLed,
															"data-lit": e,
															title: "Flashes on each sequencer hit",
															"aria-hidden": "true"
														})
													}),
													Kt(e.type) ? /* @__PURE__ */ m("button", {
														className: $.moduleNameButton,
														"aria-label": `Select ${r.name} ${n + 1} for keyboard`,
														"aria-pressed": Wi.id === e.id,
														onClick: () => {
															D || Rr(e);
														},
														children: r.name
													}) : /* @__PURE__ */ m("span", {
														className: $.moduleName,
														children: r.name
													}),
													/* @__PURE__ */ m("span", {
														className: $.moduleSubtitle,
														children: r.subtitle
													})
												]
											}),
											!D && i && /* @__PURE__ */ m(Oo, {
												module: e,
												param: i,
												name: r.name,
												onParams: (t) => Dr(e.id, t)
											}),
											/* @__PURE__ */ h("div", {
												className: $.moduleTools,
												children: [
													e.type !== "output" && /* @__PURE__ */ m(Ha, {
														mixKey: e.id,
														label: r.name,
														mix: et,
														onToggle: Or,
														clearable: gn(e, et),
														onClear: () => Z((t) => ({ mix: _n(t.mix, e) })),
														onSwap: () => kr(e.id)
													}),
													/* @__PURE__ */ m("span", {
														className: $.moduleNumber,
														children: String(n + 1).padStart(2, "0")
													}),
													!ft(s, e.id) && /* @__PURE__ */ h(p, { children: [
														/* @__PURE__ */ m("button", {
															"aria-label": `Move ${r.name} up`,
															disabled: n === 0,
															onClick: () => Er((t) => Pt(t, e.id, -1)),
															children: "↑"
														}),
														/* @__PURE__ */ m("button", {
															"aria-label": `Move ${r.name} down`,
															disabled: n === s.modules.length - 2,
															onClick: () => Er((t) => Pt(t, e.id, 1)),
															children: "↓"
														}),
														/* @__PURE__ */ m("button", {
															"aria-label": `Duplicate ${r.name}`,
															disabled: s.modules.length >= 32,
															onClick: () => di(e),
															children: "⧉"
														}),
														/* @__PURE__ */ m("button", {
															"aria-label": `Remove ${r.name}`,
															onClick: () => {
																Gr(), sn(null), J.current === e.id && Rr(gt({
																	...s,
																	modules: s.modules.filter((t) => t.id !== e.id)
																})), Er((t) => Nt(t, e.id)), Ve(null), Ue(null), P(`${r.name} removed. Undo brings it back with its cables.`);
															},
															children: "×"
														})
													] })
												]
											})
										]
									}),
									D ? Fi(e) : e.type === "performance" ? ra(e) : e.type === "dictator" ? Qi(e) : /* @__PURE__ */ h(p, { children: [
										r.drum && /* @__PURE__ */ h("div", {
											className: $.moduleTransport,
											children: [
												Vi(e),
												Hi(e),
												/* @__PURE__ */ h("span", { children: [
													"SHARED TEMPO · ",
													s.sequencer.bpm,
													" BPM"
												] })
											]
										}),
										r.drum?.mode !== "euclid" && /* @__PURE__ */ h("div", {
											className: $.moduleBody,
											"data-head": r.drum ? "drum" : void 0,
											children: [
												e.type === "mixer" ? /* @__PURE__ */ m(Ko, {
													select: (t) => t.mixerLevels[e.id] ?? js,
													children: (t) => /* @__PURE__ */ m(Lo, {
														module: e,
														patch: s,
														mix: et,
														levels: t,
														onParams: (t) => Dr(e.id, t),
														onToggle: Or,
														onSwap: kr
													})
												}) : zi(e),
												a && /* @__PURE__ */ m(eo, {
													module: e,
													selected: Ii(e) ?? r.drum.voices[0].id,
													onSelect: o,
													onParams: (t) => Dr(e.id, t),
													onAudition: (t) => Fr(e.id, t),
													disabled: t
												}),
												e.type === "skitter" && /* @__PURE__ */ m(Ja, {
													name: r.name,
													brush: kt[e.id] ?? 1,
													onBrush: (t) => At((n) => ({
														...n,
														[e.id]: t
													}))
												}),
												e.type !== "mixer" && /* @__PURE__ */ m("div", {
													className: $.moduleDecoration,
													children: e.type === "output" ? /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(Ko, {
														select: (e) => e.meter,
														children: (e) => /* @__PURE__ */ m("div", {
															className: $.meters,
															"aria-label": "Output level",
															role: "meter",
															"aria-valuemin": 0,
															"aria-valuemax": 1,
															"aria-valuenow": Number(e.toFixed(3)),
															children: [0, 1].map((t) => /* @__PURE__ */ h("div", {
																className: $.meterRow,
																children: [/* @__PURE__ */ m("span", { children: t === 0 ? "L" : "R" }), Array.from({ length: 18 }, (t, n) => /* @__PURE__ */ m("i", {
																	"data-lit": n / 18 < e,
																	"data-hot": n > 14
																}, n))]
															}, t))
														})
													}), /* @__PURE__ */ m("button", {
														"aria-pressed": z,
														onClick: () => Z((e) => ({ mainMuted: !e.mainMuted })),
														className: $.muteButton,
														children: z ? "UNMUTE" : "MUTE"
													})] }) : e.type === "envelope" ? /* @__PURE__ */ m(za, { params: e.params }) : ["compressor", "cohere"].includes(e.type) ? /* @__PURE__ */ m(Ko, {
														select: (t) => t.reductions[e.id] ?? 0,
														children: (e) => /* @__PURE__ */ m(Fa, {
															reduction: e,
															label: `${r.name} ${n + 1} gain reduction`
														})
													}) : e.type === "equalizer" ? /* @__PURE__ */ m(Pa, { params: e.params }) : /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("span", { className: $.deviceLed }), /* @__PURE__ */ h("span", {
														className: $.deviceLabel,
														children: [
															Hs[e.type] ?? "RACKLOOSE",
															/* @__PURE__ */ m("br", {}),
															/* @__PURE__ */ m("small", { children: Us[e.type] ?? "PATCH. PLAY. REPEAT." })
														]
													})] })
												})
											]
										}),
										e.type === "brit" ? /* @__PURE__ */ m(ho, {
											module: e,
											rate: Se,
											onParams: (t) => Dr(e.id, t)
										}) : e.type === "talon" ? /* @__PURE__ */ m(Ko, {
											select: (t) => t.reductions[e.id] ?? 0,
											children: (t) => /* @__PURE__ */ m(Eo, {
												module: e,
												reduction: t,
												label: `${r.name} ${n + 1} gain reduction`,
												onParams: (t) => Dr(e.id, t)
											})
										}) : Ri(e),
										e.type === "prism" && /* @__PURE__ */ m(no, {
											module: e,
											onParams: (t) => Dr(e.id, t)
										}),
										r.drum?.mode === "euclid" && /* @__PURE__ */ m(Za, {
											module: e,
											selected: Ii(e) ?? r.drum.voices[0].id,
											onSelect: o,
											clock: en[e.id]?.clock ?? -1,
											mix: et,
											onMix: Or,
											disabled: t,
											onParams: (t) => Dr(e.id, t),
											onAudition: (t) => Fr(e.id, t),
											controls: zi(e)
										}),
										r.drum?.mode === "steps" && /* @__PURE__ */ m(Ya, {
											module: e,
											brush: kt[e.id] ?? 1,
											...a ? {
												selected: Ii(e) ?? r.drum.voices[0].id,
												onSelect: o
											} : {},
											mix: et,
											onMix: Or,
											step: (en[e.id]?.clock ?? -1) < 0 ? -1 : en[e.id].clock % 16,
											disabled: t,
											onParams: (t) => Dr(e.id, t),
											onAudition: (t) => Fr(e.id, t)
										})
									] })
								]
							}, e.id);
						}),
						/* @__PURE__ */ h("div", {
							className: $.rackBottom,
							children: [/* @__PURE__ */ m("button", {
								ref: ee,
								className: $.aboutButton,
								"aria-label": "About Rackloose",
								title: "About Rackloose",
								onClick: () => ae("about"),
								children: "RACKLOOSE / BY MICHAEL ZICK © 2026"
							}), /* @__PURE__ */ m("span", { children: "NO RULES. JUST SIGNAL." })]
						})
					]
				}),
				/* @__PURE__ */ m("div", {
					className: $.toastAnchor,
					children: /* @__PURE__ */ m("div", {
						className: $.toast,
						role: "status",
						"data-shown": I,
						children: F
					})
				}),
				/* @__PURE__ */ h("div", {
					className: $.keyboardPanel,
					children: [
						/* @__PURE__ */ h("div", {
							className: $.globalControls,
							role: "group",
							"aria-label": "Global controls",
							children: [
								/* @__PURE__ */ h("div", {
									className: $.globalTransport,
									children: [
										/* @__PURE__ */ h("button", {
											className: $.playButton,
											disabled: t,
											onClick: Ir,
											"data-playing": me,
											"aria-label": me ? "Pause all sequencers" : "Play all sequencers",
											children: [/* @__PURE__ */ m(Va, { name: me ? "pause" : "play" }), /* @__PURE__ */ m("span", { children: me ? "PAUSE ALL" : "PLAY ALL" })]
										}),
										/* @__PURE__ */ h("button", {
											className: $.playStoppedButton,
											disabled: !Ui,
											onClick: Lr,
											"aria-label": "Play stopped sequencers",
											title: "Start every stopped sequencer again, in time with the rest. Mutes, solos and patch edits stay as they are.",
											children: [/* @__PURE__ */ m(Va, { name: "play" }), /* @__PURE__ */ m("span", { children: "PLAY STOPPED" })]
										}),
										/* @__PURE__ */ h("button", {
											className: $.rewindButton,
											onClick: () => v.current?.rewind(),
											"aria-label": "Rewind to the start",
											title: "Back to bar 1. Playing, it carries on from there.",
											children: [/* @__PURE__ */ m(Va, { name: "reset" }), /* @__PURE__ */ m("span", { children: "REWIND" })]
										}),
										/* @__PURE__ */ m("button", {
											className: $.clearAllButton,
											disabled: !et.muted.size && !et.soloed.size && !z,
											onClick: () => {
												Z({
													mix: $t,
													mainMuted: !1
												}), P("All mutes and solos cleared.");
											},
											"aria-label": "Clear all mutes and solos",
											children: /* @__PURE__ */ m("span", { children: "CLR ALL" })
										}),
										/* @__PURE__ */ h("button", {
											className: $.recordButton,
											disabled: t,
											"data-recording": U,
											"aria-pressed": U,
											"aria-label": U ? "Stop recording" : "Record",
											title: "Record into the armed DICTATOR (R)",
											onClick: Br,
											children: [/* @__PURE__ */ m("span", { className: $.recordLed }), /* @__PURE__ */ m("span", { children: U ? "STOP REC" : "RECORD" })]
										}),
										/* @__PURE__ */ h("label", {
											className: $.countInField,
											title: "Bars of clicks before recording starts from a stop",
											children: ["PRE", /* @__PURE__ */ m("select", {
												"aria-label": "Count-in",
												value: G,
												onChange: (e) => Ae(Number(e.target.value)),
												children: [
													0,
													1,
													2
												].map((e) => /* @__PURE__ */ m("option", {
													value: e,
													children: e ? `${e} bar${e > 1 ? "s" : ""}` : "Off"
												}, e))
											})]
										}),
										/* @__PURE__ */ h("button", {
											className: $.clickButton,
											"aria-pressed": De,
											title: "Click on every beat while the transport runs. It never reaches MAIN or an export.",
											onClick: () => Oe(!De),
											children: [/* @__PURE__ */ m("span", { className: $.clickLed }), /* @__PURE__ */ m("span", { children: "CLICK" })]
										})
									]
								}),
								/* @__PURE__ */ m(Bo, {
									bpm: s.sequencer.bpm,
									onChange: (e) => $r("bpm", e)
								}),
								/* @__PURE__ */ h("label", {
									className: $.swingField,
									children: [
										"SWING",
										/* @__PURE__ */ m("input", {
											className: $.fader,
											type: "range",
											min: 0,
											max: .6,
											step: .01,
											value: s.sequencer.swing,
											"aria-label": "Swing",
											onChange: (e) => $r("swing", Number(e.target.value))
										}),
										/* @__PURE__ */ h("span", { children: [Math.round(s.sequencer.swing * 100), "%"] })
									]
								})
							]
						}),
						/* @__PURE__ */ h("div", {
							className: $.keyboardTop,
							children: [
								/* @__PURE__ */ h("strong", {
									className: $.keyboardTarget,
									children: ["KEYBOARD → ", Bi(Wi)]
								}),
								Zi ? /* @__PURE__ */ m("span", {
									className: $.routingHint,
									title: Zi,
									children: Zi
								}) : e && /* @__PURE__ */ m("span", {
									className: $.keyHint,
									children: Ji ? `${Ji.length > 11 ? "Home row + Z X C V B" : "Home row · pads"}${Ki ? " · 1–0 velocity" : ""}` : "A–' notes · Z X octave · 1–0 velocity"
								}),
								/* @__PURE__ */ h("div", {
									className: $.positionField,
									title: `Where the transport is, as bar.beat.16th, counting through the longest loop in the rack: ${sa / 16} ${sa > 16 ? "bars" : "bar"}`,
									children: [/* @__PURE__ */ m("span", {
										"aria-hidden": "true",
										children: "POSITION"
									}), /* @__PURE__ */ m("span", {
										className: $.globalPosition,
										"aria-label": "Global position",
										"data-count-in": ke !== null,
										children: ke === null ? se(Math.max(0, ve), sa) : ce(ke)
									})]
								}),
								/* @__PURE__ */ h("div", {
									className: $.keyControls,
									children: [
										(!Ji || Ki) && /* @__PURE__ */ h("div", {
											className: $.octaveControls,
											children: [
												!Ji && /* @__PURE__ */ h(p, { children: [
													/* @__PURE__ */ m("button", {
														"aria-label": "Lower keyboard octave",
														disabled: Pe === 1,
														onClick: () => Z((e) => ({ octave: Math.max(1, e.octave - 1) }), "octave"),
														children: "−"
													}),
													/* @__PURE__ */ h("span", { children: ["OCT ", Pe] }),
													/* @__PURE__ */ m("button", {
														"aria-label": "Raise keyboard octave",
														disabled: Pe === 6,
														onClick: () => Z((e) => ({ octave: Math.min(6, e.octave + 1) }), "octave"),
														children: "＋"
													})
												] }),
												/* @__PURE__ */ m("button", {
													"aria-label": "Lower keyboard velocity",
													disabled: Te === Ns[0],
													onClick: () => Ee(Ns[Math.max(0, Ns.indexOf(Te) - 1)]),
													children: "−"
												}),
												/* @__PURE__ */ h("span", {
													title: "Velocity of the notes you play: 1–0 on the keyboard",
													children: ["VEL ", Te]
												}),
												/* @__PURE__ */ m("button", {
													"aria-label": "Raise keyboard velocity",
													disabled: Te === Ns.at(-1),
													onClick: () => Ee(Ns[Math.min(Ns.length - 1, Ns.indexOf(Te) + 1)]),
													children: "＋"
												})
											]
										}),
										Rt && /* @__PURE__ */ h("button", {
											className: $.midiToggle,
											"aria-pressed": Bt !== null,
											"aria-label": "MIDI input",
											title: Bt === null ? "Play the keyboard’s device from a MIDI keyboard" : Bt.length ? `MIDI in: ${Bt.join(", ")}` : "MIDI on: no MIDI keyboard connected",
											onClick: () => void Wr(),
											children: [/* @__PURE__ */ m("span", {
												className: $.midiLed,
												"data-connected": !!Bt?.length
											}), "MIDI"]
										}),
										/* @__PURE__ */ m("button", {
											className: $.keysToggle,
											"aria-expanded": Ie,
											"aria-controls": nr,
											onClick: () => Le(!Ie),
											children: Ie ? "Hide keys" : "Show keys"
										})
									]
								})
							]
						}),
						/* @__PURE__ */ m("div", {
							id: nr,
							hidden: !Ie,
							children: Ji ? /* @__PURE__ */ m("div", {
								className: $.performancePads,
								"data-voices": Ji.length,
								"data-rows": Ji.length > 6 ? 2 : 1,
								style: { "--pad-columns": Xi },
								"aria-label": `${qi.name} performance pads`,
								children: Ji.map((n, r) => /* @__PURE__ */ h("button", {
									"data-playing": it.has(n.id),
									"aria-label": `Keyboard ${qi.name} ${n.label}`,
									disabled: t,
									onPointerDown: (e) => {
										e.button === 0 && (e.preventDefault(), e.currentTarget.setPointerCapture(e.pointerId), Xt.current.add(`pointer-${e.pointerId}`), Nr(`pointer-${e.pointerId}`, r, e.pointerType !== "mouse", e.timeStamp), Yi(n.id));
									},
									onPointerUp: (e) => jr(`pointer-${e.pointerId}`, !1, e.timeStamp),
									onPointerCancel: (e) => jr(`pointer-${e.pointerId}`, !0),
									onLostPointerCapture: (e) => jr(`pointer-${e.pointerId}`, !0),
									onKeyDown: (e) => {
										e.key !== "Enter" && e.key !== " " || e.repeat || (e.preventDefault(), e.stopPropagation(), Nr(`pad-${n.id}`, r), Yi(n.id));
									},
									onKeyUp: (e) => {
										(e.key === "Enter" || e.key === " ") && (e.preventDefault(), jr(`pad-${n.id}`));
									},
									onBlur: () => jr(`pad-${n.id}`),
									children: [/* @__PURE__ */ m("span", { children: n.label }), e && /* @__PURE__ */ m("small", { children: Ps[r].toUpperCase() })]
								}, n.id))
							}) : /* @__PURE__ */ m("div", {
								className: $.piano,
								"aria-label": "Piano keyboard",
								children: Ms.map((e, n) => {
									let r = (Pe + 1) * 12 + n, i = Fs.has(n % 12);
									return /* @__PURE__ */ h("button", {
										className: i ? $.blackKey : $.whiteKey,
										"data-note": r,
										"data-playing": be.includes(r),
										"aria-label": `Play ${Pn(r)}`,
										disabled: t,
										onPointerDown: (e) => {
											e.button === 0 && (e.preventDefault(), e.currentTarget.setPointerCapture(e.pointerId), Xt.current.add(`pointer-${e.pointerId}`), Nr(`pointer-${e.pointerId}`, n, e.pointerType !== "mouse", e.timeStamp));
										},
										onPointerUp: (e) => jr(`pointer-${e.pointerId}`, !1, e.timeStamp),
										onPointerCancel: (e) => jr(`pointer-${e.pointerId}`, !0),
										onLostPointerCapture: (e) => jr(`pointer-${e.pointerId}`, !0),
										onKeyDown: (e) => {
											e.key !== "Enter" && e.key !== " " || e.repeat || (e.preventDefault(), e.stopPropagation(), Nr(`piano-${r}`, n));
										},
										onKeyUp: (e) => {
											(e.key === "Enter" || e.key === " ") && (e.preventDefault(), jr(`piano-${r}`));
										},
										onBlur: () => jr(`piano-${r}`),
										children: [/* @__PURE__ */ m("span", { children: Ms[n].toUpperCase() }), !i && /* @__PURE__ */ m("small", { children: Pn(r) })]
									}, n);
								})
							})
						})
					]
				}),
				A === "guide" && /* @__PURE__ */ m("div", {
					className: $.helpBackdrop,
					children: /* @__PURE__ */ h("div", {
						className: $.help,
						role: "dialog",
						"aria-modal": "true",
						"aria-labelledby": rr,
						onKeyDown: fi,
						children: [
							/* @__PURE__ */ h("div", {
								className: $.helpHeading,
								children: [
									/* @__PURE__ */ m("img", {
										src: "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2064%2064'%3e%3crect%20x='5'%20y='6'%20width='54'%20height='52'%20rx='3'%20fill='%23303337'%20stroke='%23101214'%20stroke-width='2'/%3e%3cpath%20d='M10%2010v44M54%2010v44'%20stroke='%23777'%20stroke-width='3'/%3e%3crect%20x='14'%20y='12'%20width='36'%20height='17'%20fill='%23b9503a'%20stroke='%23111'/%3e%3crect%20x='14'%20y='31'%20width='36'%20height='20'%20fill='%23a0ac9b'%20stroke='%23111'/%3e%3cg%20fill='%23232626'%20stroke='%23dfdfca'%3e%3ccircle%20cx='23'%20cy='21'%20r='5'/%3e%3ccircle%20cx='41'%20cy='21'%20r='5'/%3e%3c/g%3e%3cpath%20d='M23%2021v-4m18%204%203-3'%20stroke='%23fff'%20stroke-width='2'/%3e%3cg%20fill='%231b2221'%20stroke='%23555'%3e%3ccircle%20cx='22'%20cy='39'%20r='3'/%3e%3ccircle%20cx='42'%20cy='44'%20r='3'/%3e%3c/g%3e%3cpath%20d='M22%2039c-6%2020%2027%2020%2020%205'%20fill='none'%20stroke='%23f4bb50'%20stroke-width='3'/%3e%3cpath%20d='M7%208h50'%20stroke='%23a9abad'/%3e%3c/svg%3e",
										width: "34",
										height: "34",
										alt: ""
									}),
									/* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("small", { children: "RACKLOOSE · MODULAR SYNTHESIZER" }), /* @__PURE__ */ m("h2", {
										id: rr,
										children: "User Guide"
									})] }),
									/* @__PURE__ */ m("button", {
										autoFocus: !0,
										onClick: pi,
										"aria-label": "Close user guide",
										children: "×"
									})
								]
							}),
							/* @__PURE__ */ m("h3", { children: "Transport" }),
							/* @__PURE__ */ h("p", { children: [
								"Play All starts every sequencer and turns into Pause All while anything plays. Play Stopped starts every sequencer you stopped while the transport plays again, in time, and leaves mutes, solos and the patch alone. Rewind goes back to bar 1: playing, it plays on from there. Type a tempo or drag the small fader under it; the change is heard right away. Space always plays and pauses, whichever control has focus, except while typing in a text field. Each STEP–16, DICTATOR and drum machine also has its own Play/Stop, locked to the shared tempo, swing and position. POSITION, in the keyboard bar, shows it as bar.beat.16th of the longest loop: 11.2.1 is bar 11, beat 2, its first 16th. CLICK sounds each beat, higher on the first, straight to your speakers: it is never in an export. RECORD, or ",
								/* @__PURE__ */ m("strong", { children: "R" }),
								", records into a DICTATOR (see Recording)."
							] }),
							/* @__PURE__ */ m("h3", { children: "Playing" }),
							/* @__PURE__ */ h("p", { children: [
								"Click a device to aim the keyboard at it. MONARCH, ORACLE, AURORA, PRISM, SOLID and DICTATOR play on ",
								/* @__PURE__ */ m("strong", { children: "A W S E D F T G Y H U J K O L P ; '" }),
								", eighteen keys from C to the F above. ",
								/* @__PURE__ */ m("strong", { children: "Z" }),
								" and ",
								/* @__PURE__ */ m("strong", { children: "X" }),
								", or OCT, shift the octave, and the number keys set how hard you play, from ",
								/* @__PURE__ */ m("strong", { children: "1" }),
								" (softest) to ",
								/* @__PURE__ */ m("strong", { children: "0" }),
								" (full), shown as VEL. MONARCH plays one note at a time; ORACLE plays up to five, AURORA eight and PRISM sixteen. Their Chord setting turns every note, from the keys or STEP–16, into a chord. The chrome Engine switch in a device’s header slides between Digital, its black tab on the left, and Analog, its red tab on the right. On MONARCH, ORACLE, AURORA and SIEVE, Analog is a Moog-style ladder filter that self-oscillates near full Resonance; on PRISM it adds a ladder to every voice, set in its Filter section. Drum machines get pads on the home row, ",
								/* @__PURE__ */ m("strong", { children: "A S D F G H J K L ; '" }),
								", plus ",
								/* @__PURE__ */ m("strong", { children: "Z X C V B" }),
								" for STRIKE’s remaining five voices. STATIC holds noise on A. STEP–16 plays whatever its Pitch and Gate cables reach, and effects keep the last instrument. The light beside each instrument and drum machine flashes every time a sequencer plays it. Hide keys keeps every global control."
							] }),
							/* @__PURE__ */ m("h3", { children: "Recording" }),
							/* @__PURE__ */ h("p", { children: [
								"DICTATOR records what you play on the keys as MIDI notes, in a looping clip of 1 to 16 bars, and plays them back on whatever its Pitch and Gate cables reach: pick an instrument under PLAYS to patch it in one step. ARM a DICTATOR, which takes the keyboard, then press RECORD or ",
								/* @__PURE__ */ m("strong", { children: "R" }),
								". With more than one DICTATOR, only the armed one records, and arming another disarms it; with none armed, RECORD uses the DICTATOR the keys play, or asks you to arm one. From a stop, PRE counts in 0, 1 or 2 bars with the click before every sequencer starts; while playing, recording starts at once. Each key is its own note, so chords record as chords, at the velocity VEL shows, placed where you heard them. Every pass round the loop adds notes (Overdub), or Record set to Replace clears what the playhead passes. In the QUANTIZE row, which picks a grid from quarter notes to 1/32s, the Quantize button moves note starts onto it now (the notes selected in the piano roll, or else every note), and the AUTO lamp moves each note onto it as you record. RECORD, R, Pause or Panic stops, and the take is one step that Undo takes back whole; Backspace while recording throws the take away so far and keeps recording. Capture keeps what you just played with the transport running, without RECORD. If what you record lands late, as with Bluetooth headphones, REC TIMING records it up to 100 ms earlier, in this browser; it never changes what you hear. Lag plays the clip up to 50 ms late or early against the beat, which you hear against the click or other parts. DICTATOR’s mute and solo work like STEP–16’s, and Export WAV renders its whole clip. Rest the pointer on any control to see what it does."
							] }),
							/* @__PURE__ */ m("p", { children: "EDIT opens the clip in a piano roll. Draw clicks a note onto the SNAP grid, or drags it longer; Select drags across notes to select them. Drag a note to move it, its right edge to resize it, or the velocity lane under it to set how hard it plays; double-click deletes it. With the roll focused, the arrows move the selection, or a cursor, by a SNAP step or a semitone, Shift+arrows resize it or move it an octave, N adds a note at the cursor, [ and ] step through the notes, Delete removes them, ⌘A or Ctrl+A selects all, ⌘D or Ctrl+D duplicates, and Escape clears the selection, then closes the roll. On a touch screen, a finger draws on the grid and scrolls on the keys or the bar numbers. Each edit is one step that Undo takes back." }),
							/* @__PURE__ */ m("p", { children: "Click or drag DICTATOR’s strip, or the piano roll’s bar numbers, to move the playhead there, or tap them on a touch screen; with one focused, the arrows move it a beat and Shift+arrows a bar. The playhead is the shared position, so every sequencer moves with it, whether stopped, playing or recording." }),
							/* @__PURE__ */ m("p", { children: "Pick a drum machine under PLAYS and DICTATOR plays it by General MIDI note, the kick on 36, snare 38, closed hat 42 and so on, as hard as each note was played; the keyboard then shows that kit’s pads, which record as those notes. Export .mid saves the clip as a MIDI file for a DAW, and Import .mid replaces it with a file’s notes, one track or all of them. MIDI, beside the keys, plays the keyboard’s device from a MIDI keyboard in Chrome, Edge or Firefox once the browser has your permission, and records like the keys, at the velocity you play." }),
							/* @__PURE__ */ m("h3", { children: "Knobs and steps" }),
							/* @__PURE__ */ m("p", { children: "Drag a knob up or down, or use the arrow keys; double-click restores its default. Click a STEP–16 step to switch it on or off, as on a drum machine’s pads. To set a step’s note, velocity and gate, turn on EDIT, beside CLEAR under Play, which dashes every step’s border, and click the step; its Note on box switches it too. Turn EDIT off, or press Escape, to switch steps with a click again. A step that is off keeps its note for when you switch it back on, and CLEAR, under Play, turns every step into a rest the same way. A STEP–16’s Lag moves all its notes up to 50 ms ahead of the beat (turn it left) or behind it (right); centred is On beat. Add device adds more STEP–16s: each has its own 16 steps, Play/Stop and step mutes, and plays whatever its own Pitch and Gate cables reach, so separate parts can drive separate instruments. Typing in a field never plays notes." }),
							/* @__PURE__ */ m("h3", { children: "Patching cables" }),
							/* @__PURE__ */ m("p", { children: "Flip the rack to patch. Each jack holds one cable. Drag from an empty jack to a free one; jacks that can take it light up. Drag a plugged jack to pull its plug out: drop it on a free jack to move it, or on empty rack space to unplug it. You can also tap a plugged jack to lift its plug, then tap a free jack. Escape or a bad drop puts the plug back, and Delete unplugs a selected cable. Every output has a spare jack, and STEP–16 has three Pitch and three Gate jacks, so one signal can feed several places. Amber is audio, blue is CV and coral is gate; types must match. The trim beside a CV input sets its depth. SUM mixes eight channels and names each one after the instrument feeding it, through any effects; hover the name to see the chain." }),
							/* @__PURE__ */ m("h3", { children: "Mixing on SUM" }),
							/* @__PURE__ */ m("p", { children: "SUM is laid out like a console. Each channel strip has Pan, M and S, a fader and a level meter: green, amber from −9 dB and red from −3 dB. Drag a fader or pan knob, or use the arrow keys; double-click returns it to its default. The MIX BUS fader on the right sets the level of the whole mix, with its own left and right meters." }),
							/* @__PURE__ */ m("h3", { children: "Drums" }),
							/* @__PURE__ */ m("p", { children: "AURORA is an eight-voice Jupiter-8-inspired polysynth: blend two oscillators, shape them with high-pass and 12/24 dB low-pass filters, and animate pulse width with the LFO. PRISM is a focused DX7-inspired FM synth: choose one of six algorithms, then select an operator to edit its ratio, level and envelope. Brightness controls modulation depth; Velocity makes quieter sequenced notes softer in tone. Both use their own envelopes and work with STEP–16 Pitch and Gate, or directly from the keyboard." }),
							/* @__PURE__ */ m("p", { children: "STRIKE has sixteen vintage digital drum lanes, original generated one-shots inspired by LinnDrum. BOOM has eleven voices: kick, snare, rim, clap, closed and open hat, low and high tom, crash, ride and bell. A closed hat cuts off a ringing open hat. On BOOM, PUNCH, STRIKE and FORGE, click a voice’s name, tap its performance pad or pick it under Edit voice to hear it and shape it in the voice editor, with its own knobs, such as Tune, Decay and Tone, its Pan and its Lag. Lag moves just that voice up to 50 ms ahead of the beat (turn it left) or behind it (right), like hats pushed ahead or a snare laid back. ORBIT shows the same knobs for the lane you pick. Every drum machine’s Engine toggle picks Digital or Analog, which builds each voice from modeled analog circuits (or, on STRIKE and FORGE, plays its one-shots through a ladder tone filter) at the same level. Every device starts Analog, presets and older patches included. The knob marked LEVEL on each drum lane, in ORBIT’s Level column, sets that voice’s level: centred leaves it as it was, down silences it and full adds 6 dB. Hover it to read the change; double-click resets it. Click pads to program a voice’s steps. CLEAR, beside a drum machine’s Play, empties the pattern it came with, rolls and custom rings included, so you can start from silence; ORBIT’s rings keep their Steps and Shift, so Generate refills them. ORBIT voices each have Steps, Hits and Shift; tap its step pads for a custom rhythm, and Generate turns it back into a Euclidean one, spreading the hits you tapped evenly if the lane had no Hits. A drum machine’s Chain in passes another instrument through. SKITTER is a trap step sequencer that makes no sound: patch Trig out into a drum machine’s Trig in and its lanes play that kit’s kick, snare, clap, hats and perc, or patch Synth gate into MONARCH, CONTOUR or a polysynth. Pick a note under Note, then tap a step to play it as a 1/16, a pair of 1/32s, or a roll of 1/32 triplets, 1/64s or 1/64 triplets. FORGE is an industrial rock kit with its own Drive and gated Room, and RUST distorts anything patched into it, from fuzz to crushed bits." }),
							/* @__PURE__ */ m("h3", { children: "Dynamics and EQ" }),
							/* @__PURE__ */ m("p", { children: "VALVE is a tube limiter: Input drives the tube, Threshold sets where it starts to hold the level back, and Time constant picks how fast it lets go, from 1 (quick) to 6 (slow). The needle shows the gain reduction. CONSOLE is a channel EQ: high- and low-pass filters, LF and HF that switch between shelf and bell, and two sweepable mids with Q. The screen draws the curve you hear, and EQ Out bypasses it. Every factory preset carves at least one instrument with it." }),
							/* @__PURE__ */ m("h3", { children: "Mute and solo" }),
							/* @__PURE__ */ m("p", { children: "M mutes and S solos a device, drum voice, SUM channel or step, and the two are exclusive. CLR clears one device’s mutes and solos, with its voices’, channels’ or steps’, and SWAP turns a muted device or SUM channel soloed or a soloed one muted; CLR ALL clears everything, MAIN’s mute included. Silenced parts dim. These settings last for this session." }),
							/* @__PURE__ */ m("h3", { children: "Undo and unsaved changes" }),
							/* @__PURE__ */ h("p", { children: [
								"Undo and Redo, or ",
								/* @__PURE__ */ m("strong", { children: "⌘Z" }),
								" and ",
								/* @__PURE__ */ m("strong", { children: "⇧⌘Z" }),
								" (",
								/* @__PURE__ */ m("strong", { children: "Ctrl+Z" }),
								" and ",
								/* @__PURE__ */ m("strong", { children: "Ctrl+Y" }),
								"), step through your last 50 changes: knobs, steps, CLEAR, recorded takes, tempo, cables, devices, presets, mutes, solos and octave. A ",
								/* @__PURE__ */ m("strong", { children: "*" }),
								" after the patch name means it has changed since you last saved it to My Presets or loaded it, and Revert puts it back that way as one more step, so Undo brings your changes back. While it has changed, the line under the name says whether those edits are saved in this browser, which brings them back after a reload; if it says Not saved, export a file to keep them. Revert leaves mutes, solos and the transport alone: Play Stopped starts what you stopped, and Rewind only moves back to bar 1."
							] }),
							/* @__PURE__ */ m("h3", { children: "Presets and files" }),
							/* @__PURE__ */ h("p", { children: [
								"Your rack keeps itself between visits. Save, or ",
								/* @__PURE__ */ m("strong", { children: "⌘S" }),
								" (",
								/* @__PURE__ */ m("strong", { children: "Ctrl+S" }),
								"), keeps it in My Presets in this browser: the first save asks for a name, and later saves update that preset. Type a new name in PATCH and save to rename it; Save as… (",
								/* @__PURE__ */ m("strong", { children: "⇧⌘S" }),
								") makes a copy. Presets lists My Presets above the factory presets. Export downloads a preset as a .json file, Import file adds one to My Presets, and Delete removes your own presets. Export WAV renders the number of loops chosen next to it, every sequencer from the start, effects and mutes included, but not MAIN’s Mute. Once you edit the rack, the line under the patch name says whether your edits are kept in this browser, and messages appear briefly over the bottom of the rack. Panic silences everything at once."
							] })
						]
					})
				}),
				A === "about" && /* @__PURE__ */ m("div", {
					className: $.helpBackdrop,
					children: /* @__PURE__ */ h("div", {
						className: `${$.help} ${$.about}`,
						role: "dialog",
						"aria-modal": "true",
						"aria-labelledby": dr,
						onKeyDown: fi,
						children: [
							/* @__PURE__ */ h("div", {
								className: $.helpHeading,
								children: [
									/* @__PURE__ */ m("img", {
										src: "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2064%2064'%3e%3crect%20x='5'%20y='6'%20width='54'%20height='52'%20rx='3'%20fill='%23303337'%20stroke='%23101214'%20stroke-width='2'/%3e%3cpath%20d='M10%2010v44M54%2010v44'%20stroke='%23777'%20stroke-width='3'/%3e%3crect%20x='14'%20y='12'%20width='36'%20height='17'%20fill='%23b9503a'%20stroke='%23111'/%3e%3crect%20x='14'%20y='31'%20width='36'%20height='20'%20fill='%23a0ac9b'%20stroke='%23111'/%3e%3cg%20fill='%23232626'%20stroke='%23dfdfca'%3e%3ccircle%20cx='23'%20cy='21'%20r='5'/%3e%3ccircle%20cx='41'%20cy='21'%20r='5'/%3e%3c/g%3e%3cpath%20d='M23%2021v-4m18%204%203-3'%20stroke='%23fff'%20stroke-width='2'/%3e%3cg%20fill='%231b2221'%20stroke='%23555'%3e%3ccircle%20cx='22'%20cy='39'%20r='3'/%3e%3ccircle%20cx='42'%20cy='44'%20r='3'/%3e%3c/g%3e%3cpath%20d='M22%2039c-6%2020%2027%2020%2020%205'%20fill='none'%20stroke='%23f4bb50'%20stroke-width='3'/%3e%3cpath%20d='M7%208h50'%20stroke='%23a9abad'/%3e%3c/svg%3e",
										width: "34",
										height: "34",
										alt: ""
									}),
									/* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("small", { children: "RACKLOOSE · MODULAR SYNTHESIZER" }), /* @__PURE__ */ m("h2", {
										id: dr,
										children: "About Rackloose"
									})] }),
									/* @__PURE__ */ m("button", {
										autoFocus: !0,
										onClick: pi,
										"aria-label": "Close about Rackloose",
										children: "×"
									})
								]
							}),
							/* @__PURE__ */ h("dl", {
								className: $.aboutFacts,
								children: [
									/* @__PURE__ */ m("dt", { children: "Version" }),
									/* @__PURE__ */ m("dd", { children: "2.6.1" }),
									/* @__PURE__ */ m("dt", { children: "By" }),
									/* @__PURE__ */ m("dd", { children: "Michael Zick" })
								]
							}),
							/* @__PURE__ */ m("p", {
								className: $.aboutTagline,
								children: "Small studio. Endless possibilities."
							}),
							/* @__PURE__ */ m("p", {
								className: $.aboutCopyright,
								children: "© 2026 Michael Zick"
							})
						]
					})
				}),
				Ln !== null && /* @__PURE__ */ m(Uo, {
					initialName: Ln,
					presets: wn,
					onSave: ii,
					onCancel: ri
				})
			]
		})
	});
}
export { $s as RacklooseApp, kn as parsePatch, En as preset, Dn as serializePatch };
