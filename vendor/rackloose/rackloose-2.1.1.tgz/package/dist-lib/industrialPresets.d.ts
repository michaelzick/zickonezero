import type { Patch } from './model';
export { INDUSTRIAL_PRESETS } from './model';
type Name = typeof import('./model').INDUSTRIAL_PRESETS[number];
/**
 * Two dark industrial originals, neither with a cymbal crash: a slow doom crawl on double-tracked guitars and a funky
 * hip-hop groove on synths. Both layer BOOM's sub kick, snare and clap under FORGE on the same steps, BOOM playing
 * into FORGE's Chain in so both kits share one drum bus, the snares laid back and the hats pushed ahead with Lag.
 */
export declare function industrialPreset(name: Name): Patch;
