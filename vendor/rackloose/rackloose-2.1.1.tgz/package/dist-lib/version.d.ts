/** The package version, which vite.config.ts, vite.lib.config.ts and vitest.config.ts define from package.json. */
export declare const VERSION: string;
