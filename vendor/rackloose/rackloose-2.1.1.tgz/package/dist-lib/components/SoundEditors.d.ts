import { type RackModule } from '../model';
type EditorProps = {
    module: RackModule;
    onParams: (values: Record<string, number>) => void;
};
/**
 * The knobs that shape one voice of BOOM, PUNCH, STRIKE or FORGE, ending in its Pan; its Level is on its lane.
 * `selected` is the voice being edited, which clicking a voice's name on its lane or its performance pad also picks.
 */
export declare function VoiceEditor({ module, onParams, onAudition, disabled, selected, onSelect }: EditorProps & {
    onAudition: (voice: string) => void;
    disabled?: boolean;
    selected: string;
    onSelect: (voice: string) => void;
}): import("react").JSX.Element;
export declare function PrismEditor({ module, onParams }: EditorProps): import("react").JSX.Element;
export {};
