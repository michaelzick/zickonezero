import type { Param, RackModule } from '../model';
/**
 * A device's Engine toggle: a chrome slide switch on a legend plate in its header, slid right to the red tab
 * for Analog and left to the black tab for Digital. `name` labels it for assistive technology, such as "MONARCH Engine".
 */
export declare function EngineSwitch({ module, param, name, onParams }: {
    module: RackModule;
    param: Param;
    name: string;
    onParams: (values: Record<string, number>) => void;
}): import("react").JSX.Element;
