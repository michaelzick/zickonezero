import { type Mix, type Param, type RackModule } from '../model';
import { type MixToggle } from './MixButtons';
/** `onParams` changes one or more of the module's params as a single edit. */
type DrumProps = {
    module: RackModule;
    mix: Mix;
    onMix: MixToggle;
    onParams: (values: Record<string, number>) => void;
    onAudition: (voice: string) => void;
    disabled?: boolean;
};
/** A voice's level as gain from its default, which sits at the knob's centre: 0 dB there, +6 dB at full, -∞ at zero. */
export declare const decibels: (param: Param) => (value: number) => string;
/**
 * The params a tap on step `index` changes. With the 1/16 brush it toggles the step, clearing any 1/32s or roll it had;
 * another brush sets that note value on the step, turning it on, and tapping a step already set that way takes it back to 1/16.
 */
export declare function editRoll(module: RackModule, voice: string, index: number, brush: number): Record<string, number>;
/**
 * One lane of 16 pads per voice, in groups of four, after its labelled level knob. The voice name auditions it and, given
 * `onSelect`, picks it for the voice editor or lights its knobs, marking `selected`'s name. `step` lights the playhead.
 */
export declare function DrumPads({ module, mix, onMix, step, onParams, onAudition, disabled, selected, onSelect }: DrumProps & {
    step: number;
    selected?: string;
    onSelect?: (voice: string) => void;
}): import("react").JSX.Element;
/** Six rhythm lanes, each with its level under the Level heading, plus the sound and step editor for the `selected` lane. */
export declare function EuclidMatrix({ module, mix, onMix, onParams, onAudition, disabled, clock, selected, onSelect }: DrumProps & {
    clock: number;
    selected: string;
    onSelect: (voice: string) => void;
}): import("react").JSX.Element;
/** Concentric rings, outermost first: one dot per step, large dots for hits, and the playhead glowing at `clock`. */
export declare function OrbitRings({ module, clock }: {
    module: RackModule;
    clock: number;
}): import("react").JSX.Element;
export {};
