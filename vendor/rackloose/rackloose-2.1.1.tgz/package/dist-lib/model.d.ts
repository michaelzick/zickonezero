export type ModuleType = 'performance' | 'oscillator' | 'noise' | 'mixer' | 'filter' | 'amplifier' | 'envelope' | 'lfo' | 'delay' | 'reverb' | 'boom' | 'punch' | 'orbit' | 'monarch' | 'oracle' | 'aurora' | 'strike' | 'prism' | 'compressor' | 'equalizer' | 'cohere' | 'talon' | 'brit' | 'skitter' | 'forge' | 'rust' | 'output';
export type SignalKind = 'audio' | 'cv' | 'gate';
export type Endpoint = {
    moduleId: string;
    portId: string;
};
export type Cable = {
    id: string;
    from: Endpoint;
    to: Endpoint;
    amount: number;
};
/** `steps` belongs to each STEP–16 added after the first, which keeps its steps in `sequencer` as every v1 patch does. */
export type RackModule = {
    id: string;
    type: ModuleType;
    params: Record<string, number>;
    steps?: Step[];
};
export type Step = {
    enabled: boolean;
    note: number;
    velocity: number;
    gate: number;
};
export type Patch = {
    version: 1;
    name: string;
    modules: RackModule[];
    cables: Cable[];
    sequencer: {
        bpm: number;
        swing: number;
        steps: Step[];
    };
};
/**
 * `pattern` params hold 16 steps as a bitmask and are edited with pads. `voice` params belong to a drum voice's lane or
 * voice editor rather than the knob row. A patch saved before a param existed loads it from param `legacyFrom`, when it
 * has that, or else at `legacyDefault`.
 */
export type Param = {
    id: string;
    label: string;
    min: number;
    max: number;
    step: number;
    initial: number;
    unit?: string;
    logarithmic?: boolean;
    choices?: string[];
    pattern?: boolean;
    voice?: string;
    legacyDefault?: number;
    legacyFrom?: string;
    group?: string;
};
/** `copyOf` marks a spare jack carrying the same output signal as port `copyOf`. Every jack holds one cable. */
export type Port = {
    id: string;
    label: string;
    kind: SignalKind;
    direction: 'in' | 'out';
    scale?: number;
    copyOf?: string;
};
export type Voice = {
    id: string;
    label: string;
};
/** Drum devices play their own rhythm on the sequencer clock: `steps` from per-voice `${voice}Pattern` bitmasks, `euclid` from `${voice}Steps`, `Hits` and `Shift`. */
export type Drum = {
    mode: 'steps' | 'euclid';
    voices: Voice[];
};
export type Definition = {
    name: string;
    subtitle: string;
    color: string;
    params: Param[];
    ports: Port[];
    drum?: Drum;
};
/** How far, in milliseconds, Lag moves a drum voice or a STEP–16's notes ahead of the beat (−) or behind it (+). */
export declare const LAG_LIMIT = 50;
/**
 * The params of each device's Engine toggle: Digital, or Analog by the Rust DSP (a ladder filter on the synths and
 * SIEVE, analog-modeled voices on the drum machines). `filterModel` and `engine` keep the ids patches already saved.
 */
export declare const ENGINE_PARAMS: string[];
export declare const ORBIT_VOICES: Voice[];
/** ORACLE's chord memory: semitones above the played note, at most one per voice. Min 11 leaves out the fifth. */
export declare const CHORDS: [string, number[]][];
export declare const POLY_VOICES = 5;
export declare const STRIKE_VOICES: Voice[];
export declare const PRISM_ALGORITHMS: string[];
/** SUM's channels, each with its own input, fader, pan, mute and solo. */
export declare const MIXER_CHANNELS: string[];
/** The pan param of SUM channel `channel`. */
export declare const panOf: (channel: string) => string;
/**
 * SKITTER's lanes. It makes no sound: its drum lanes play the matching voice of each drum machine its Trig out
 * reaches, and its Synth lane opens the gates its Gate out reaches.
 */
export declare const SKITTER_LANES: Voice[];
/** The voice each SKITTER lane plays on a drum machine. A lane a kit has no voice for stays silent there. */
export declare const TRIG_VOICES: Partial<Record<ModuleType, Record<string, string>>>;
export declare const FORGE_VOICES: Voice[];
/** Hits a SKITTER step plays in the space of one 16th beyond a single 1/16: 1/32s, 1/32 triplets, 1/64s and 1/64 triplets, each kept in its own `${voice}Roll${n}` step mask. */
export declare const ROLLS: readonly [2, 3, 4, 6];
export declare const rollParam: (voice: string, hits: number) => string;
export declare const RUST_MODES: string[];
/** How far a voice's Tone knob moves its filters: by `octaves` across its travel, leaving them as they were at its centre. */
export declare const toneRatio: (amount: number, octaves: number) => number;
export declare const DEFINITIONS: Record<ModuleType, Definition>;
export declare const ADDABLE: ModuleType[];
export declare const newId: (prefix?: string) => string;
export declare const createModule: (type: ModuleType, id?: string) => RackModule;
/** The device's Engine toggle param, if it has one. */
export declare const engineParam: (type: ModuleType) => Param | undefined;
/** A device as the library adds it. A new STEP–16 brings its own steps: C3 on every beat, so it sounds once patched. */
export declare const newDevice: (type: ModuleType) => RackModule;
/** The first STEP–16 and MAIN stay at either end of the rack. Every other device, added STEP–16s included, can move or go. */
export declare const isPermanent: (patch: Patch, id: string) => boolean;
/** A STEP–16's steps: the first STEP–16's live in `sequencer`, and each one added after it carries its own. */
export declare const stepsOf: (patch: Patch, id: string) => Step[];
export declare function withSteps(patch: Patch, id: string, steps: Step[]): Patch;
export declare const getPort: (patch: Patch, endpoint: Endpoint) => Port | undefined;
export declare const sameEndpoint: (a: Endpoint, b: Endpoint) => boolean;
/** A jack's position among the spare jacks of its output, counted from 1, or null for a single jack. */
export declare function jackNumber(ports: Port[], port: Port): number | null;
/** The cable plugged into a jack, if any. Each jack holds at most one. */
export declare const cableAt: (patch: Patch, endpoint: Endpoint) => Cable | undefined;
export declare function connectionError(patch: Patch, from: Endpoint, to: Endpoint): string | null;
export declare function connect(patch: Patch, from: Endpoint, to: Endpoint, amount?: number): Patch;
export declare function orient(patch: Patch, a: Endpoint, b: Endpoint): {
    from: Endpoint;
    to: Endpoint;
} | null;
export declare function linkError(patch: Patch, a: Endpoint, b: Endpoint, ignoreCableId?: string | null): string | null;
export declare function moveCable(patch: Patch, cableId: string, from: Endpoint, to: Endpoint): Patch;
export declare function removeModule(patch: Patch, id: string): Patch;
export declare function moveModule(patch: Patch, id: string, delta: number): Patch;
export declare const stepOn: (bits: number, index: number) => boolean;
/** Spreads `hits` as evenly as possible over `steps`, rotated later by `shift`. Every result is a rotation of Bjorklund's pattern. */
export declare function euclid(steps: number, hits: number, shift?: number): boolean[];
/** How many hits voice `voice` plays at step `index` (0–15): 1, or 2, 3, 4 or 6 where that roll mask is set. */
export declare function rollAt(module: RackModule, voice: string, index: number): number;
/** Each voice a drum device strikes at step `count` and how many evenly spaced hits it plays within that step. */
export declare const drumRolls: (module: RackModule, count: number) => [voice: string, hits: number][];
/** The voices a drum device strikes at sequencer step `count`, counted from Play. Euclidean rings loop over their own length. */
export declare function drumHits(module: RackModule, count: number): string[];
export declare function orbitPattern(module: RackModule, voice: string): boolean[];
export declare function editOrbitStep(module: RackModule, voice: string, index: number): Record<string, number>;
/** Generate's params: back to a Euclidean ring. A ring with no Hits takes them from the custom steps, or 3 in every 8 steps, so Generate never empties the lane. */
export declare function generateOrbit(module: RackModule, voice: string): Record<string, number>;
/** Whether Generate would change the lane: it is custom, or a Euclidean ring with no hits. */
export declare const canGenerateOrbit: (module: RackModule, voice: string) => boolean;
export declare const isPlayable: (type: ModuleType) => boolean;
/** Instruments that sound several held notes at once. */
export declare const isPoly: (type: ModuleType) => boolean;
export declare const isSequencer: (type: ModuleType) => boolean;
export type KeyboardTarget = {
    moduleId: string;
};
/** Audio reachability deliberately excludes CV/gate links. */
export declare function audioReachable(patch: Patch, start: string): Set<string>;
export declare function hasAudioPath(patch: Patch, moduleId: string): boolean;
/** Links two free jacks picked in either order, or moves cable `movingId` there, keeping its id, depth and place. Returning a plug to its own jack changes nothing. */
export declare function patchConnection(patch: Patch, a: Endpoint, b: Endpoint, movingId?: string | null): Patch;
/**
 * Session-only mute and solo. Keys name a module by id, a drum voice or SUM channel as `${moduleId}:${voice}`, and a
 * STEP–16 step as `${moduleId}:step:${index}`. Module solo silences every sound source that doesn't feed a soloed module;
 * voice, channel and step solo are scoped to their own device.
 */
export type Mix = {
    muted: ReadonlySet<string>;
    soloed: ReadonlySet<string>;
};
export declare const EMPTY_MIX: Mix;
export declare const voiceKey: (moduleId: string, voice: string) => string;
export declare const stepKey: (moduleId: string, index: number) => string;
/** Instruments and drum machines: the devices that make sound of their own. */
export declare const isSource: (type: ModuleType) => boolean;
/**
 * The sound sources STEP–16 `sequencerId` plays. Its Pitch and Gate reach some devices directly and others through
 * CV, like CONTOUR into LEVEL; a source plays when it is one of them or its audio passes through one.
 */
export declare function sequencerSources(patch: Patch, sequencerId: string): string[];
/**
 * Whether each module's own output is open. Mute closes any module: a source stops sounding, a processor or modulator
 * stops passing signal, STEP–16 stops playing notes, and a drum device silences its voices while Chain in still passes.
 * While anything is soloed, a source stays open only if it is soloed or its cables reach a soloed module. Soloing a
 * CV or gate module solos what it modulates, and a drum device's Chain in does not count as feeding it, so soloing
 * BOOM plays BOOM alone.
 */
export declare function mixGates(patch: Patch, mix: Mix): Record<string, boolean>;
/** The parts of a device with their own mute and solo: a drum machine's voices, or SUM's channels. */
export declare const mixParts: (type: ModuleType) => string[];
/** Whether a drum voice or SUM channel sounds. Its solo is scoped to its own device. */
export declare function voicePlays(module: RackModule, voice: string, mix: Mix): boolean;
export declare function stepPlays(moduleId: string, index: number, mix: Mix): boolean;
/**
 * The devices feeding SUM channel `channel`, source first, such as BOOM then SPACE. It follows audio back through effects
 * with one audio input, and stops at an instrument, a drum machine, another SUM or an effect with nothing plugged in.
 * Empty when nothing is plugged into the channel.
 */
export declare function channelSource(patch: Patch, mixerId: string, channel: string): RackModule[];
/** Duplicate devices keep the same rack-slot numbering everywhere, including source-chain tooltips. */
export declare function deviceName(patch: Patch, module: RackModule): string;
/** One presentation for SUM's front controls, rear sockets and cable descriptions. */
export declare function channelLabel(patch: Patch, mixerId: string, channel: string): {
    source: string;
    tooltip: string;
    connected: boolean;
};
/** Turns mute or solo on or off for `key`. They are exclusive: turning one on turns the other off. */
export declare function toggleMix(mix: Mix, key: string, kind: keyof Mix): Mix;
export declare const hasModuleMix: (module: RackModule, mix: Mix) => boolean;
/** Clears every mute and solo that belongs to `module`, leaving other modules' settings alone. */
export declare function clearModuleMix(mix: Mix, module: RackModule): Mix;
export declare const GROOVE_PRESETS: readonly ["Vintage Bass", "Vintage Lead", "Boom Bap", "Late Night Hip-Hop", "Roots Reggae", "Dub Session", "Trap Soul", "Broken Beat", "Orbit Percussion"];
export declare const RETRO_PRESETS: readonly ["Neon Skyline", "Digital Boogie", "Midnight Ballad", "New Wave Motion", "Glass Arcade", "Analog Sunrise"];
export declare const STUDIO_PRESETS: readonly ["French Touch", "Distortion Disco", "Electro Pogo", "Electroclash"];
export declare const TRAP_PRESETS: readonly ["High Dive", "Undertow", "Deep End"];
export declare const INDUSTRIAL_PRESETS: readonly ["Black Mass", "Bone Orchard"];
/** Hip-hop, trap and R&B lead the list: the trap starters, then the urban grooves, before every other style. */
export declare const URBAN_PRESETS: readonly ["High Dive", "Undertow", "Deep End", "Trap Soul", "Late Night Hip-Hop", "Boom Bap"];
export declare const PRESETS: readonly ["High Dive", "Undertow", "Deep End", "Trap Soul", "Late Night Hip-Hop", "Boom Bap", "Groove", "House", ...("Vintage Bass" | "Vintage Lead" | "Roots Reggae" | "Dub Session" | "Broken Beat" | "Orbit Percussion")[], "Neon Skyline", "Digital Boogie", "Midnight Ballad", "New Wave Motion", "Glass Arcade", "Analog Sunrise", "French Touch", "Distortion Disco", "Electro Pogo", "Electroclash", "Black Mass", "Bone Orchard"];
export type PresetName = typeof PRESETS[number];
export declare function preset(kind?: PresetName): Patch;
export declare function serializePatch(patch: Patch): string;
/** Everything a patch saves, with cables compared by their ends instead of generated ids, so replugging a cable where it was counts as unchanged. */
export declare function patchSignature(patch: Patch): string;
export declare function parsePatch(text: string): Patch;
export declare function readSaved(storage: Pick<Storage, 'getItem'>, key: string): {
    patch: Patch | null;
    error: string | null;
};
export declare function savePatch(storage: Pick<Storage, 'setItem'>, key: string, patch: Patch): string | null;
export declare const paramFraction: (param: Param, value: number) => number;
export declare const NOTE_NAMES: string[];
export declare const noteName: (note: number) => string;
export declare const midiFrequency: (note: number) => number;
export declare class NoteStack {
    private notes;
    press(key: string, note: number): number | null;
    release(key: string): number | null;
    clear(): void;
    has(key: string): boolean;
    get current(): number | null;
    /** Held keys and their notes, oldest first. */
    get entries(): [string, number][];
}
export declare const stepDuration: (bpm: number, swing: number, index: number) => number;
export declare function loopSchedule(patch: Patch, loops: number, start?: number): {
    events: {
        step: Step;
        index: number;
        time: number;
        duration: number;
    }[];
    duration: number;
};
