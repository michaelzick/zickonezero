/**
 * SIEVE: a biquad (Digital) or a Rust multimode ladder (Ladder), with Cutoff CV sweeping either in cents.
 */
export declare function createSieve(context: BaseAudioContext, { keep, onError }: {
    keep: <T extends AudioNode>(node: T) => T;
    onError?: (error: Error) => void;
}): {
    input: GainNode;
    cv: GainNode;
    output: GainNode;
    apply(p: Record<string, number>): void;
    flush: () => Promise<void>;
    dispose: () => void | undefined;
};
