type Keep = <T extends AudioNode>(node: T) => T;
/** The ladder's settings, in the units its processor's AudioParams use. */
export type LadderSettings = {
    cutoff: number;
    resonance: number;
    drive: number;
    level: number;
    mode?: LadderMode;
    detune?: number;
};
/** 0 24 dB low-pass, 1 12 dB low-pass, 2 band-pass, 3 high-pass. */
export type LadderMode = 0 | 1 | 2 | 3;
/**
 * A Rust ladder filter (crates/rackloose-dsp) beside a device's Digital filter. `input` feeds it, and `modulation`
 * sources sweep its cutoff in cents, the way they sweep a BiquadFilterNode's detune. It is built on first use, so a
 * device left on Digital never runs a worklet, and where the DSP is unavailable the device stays Digital.
 */
export declare function ladderPath(context: BaseAudioContext, { keep, onError, name }: {
    keep: Keep;
    onError?: (error: Error) => void;
    name: string;
}, input: AudioNode, output: AudioNode, modulation?: AudioNode[]): {
    /**
     * Fades the ladder in when `on` (and available) or out, through `set`, the device's smoothed setter. Returns whether
     * the ladder is in, so the caller can fade its Digital filter the other way.
     */
    apply(on: boolean, settings: LadderSettings, set: (param: AudioParam, value: number) => void): boolean;
    flush: () => Promise<void>;
    dispose: () => void | undefined;
};
export {};
