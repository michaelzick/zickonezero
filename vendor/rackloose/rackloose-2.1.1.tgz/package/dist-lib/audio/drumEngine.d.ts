import { type DrumHost, type DrumKit } from './drums';
import { type SampleKit } from './strike';
import { type createForge } from './forge';
type Params = Record<string, number>;
type Drums = 'boom' | 'punch' | 'orbit' | 'strike' | 'forge';
/** The parameters the Rust engine reads for one hit; `drums::Drums::trigger` documents each voice's layout. */
export declare function hitParams(type: Drums, voice: string, p: Params, kit?: SampleKit): number[];
/**
 * How much a hit's lane level scales it beyond what `hitParams` passes, applied like velocity after the voice's own
 * saturation so it changes loudness alone. BOOM and PUNCH voices take their whole level this way. ORBIT's level drives
 * its voice up to unity, as it always has, and only the boost above unity comes here; the sampled kits' level is their
 * peak.
 */
export declare function hitGain(type: Drums, voice: string, p: Params): number;
/**
 * The Analog engine: one drum machine in the Rust drum engine (crates/rackloose-dsp), played by timestamped messages
 * to its worklet. Returns null where the Rust DSP is unavailable.
 */
export declare function createModeledKit(context: BaseAudioContext, type: Drums, bus: AudioNode, { keep, onError }: Pick<DrumHost, 'keep'> & {
    onError?: (error: Error) => void;
}): (DrumKit & {
    flush: () => Promise<void>;
}) | null;
/**
 * A drum machine that plays each hit on its Digital kit or its Analog engine, by the Engine setting at that hit. Each
 * is built the first time it plays, so a kit left on one never runs the other.
 */
export declare function createDrumMachine(context: BaseAudioContext, type: Drums, bus: AudioNode, host: DrumHost & {
    onError?: (error: Error) => void;
}, forge?: ReturnType<typeof createForge>): DrumKit & {
    flush: () => Promise<void>;
};
export {};
