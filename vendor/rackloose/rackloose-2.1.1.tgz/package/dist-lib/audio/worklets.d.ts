/** The compiled Rust DSP for `rackloose-ladder-v1` and `rackloose-drums-v1` nodes, once `prepareAudio` has finished. */
export declare const dspModule: () => WebAssembly.Module | undefined;
/** Each module registers once per context. A failed module can retry without re-registering successful modules. */
export declare function prepareAudio(context: BaseAudioContext): Promise<void>;
/** Shared initialization fences, persistent errors and teardown for instrument and effect worklets. */
export declare function workletControl(node: AudioWorkletNode, name: string, meter?: (value: number) => void, onError?: (error: Error) => void): {
    flush(): Promise<void>;
    dispose(): void;
};
