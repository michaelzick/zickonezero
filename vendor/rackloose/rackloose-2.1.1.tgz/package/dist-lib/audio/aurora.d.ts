import { type SynthHost, type PolyInstrument } from './poly';
/**
 * Eight independent dual-VCO voices. Pitch is sampled on note-on; modulation CV remains continuous. With Model on Ladder,
 * each voice's low-pass is a Rust ladder: 24 dB uses all four stages and 12 dB taps the second.
 */
export declare function createAurora(context: BaseAudioContext, { keep, source, onError }: SynthHost): PolyInstrument;
