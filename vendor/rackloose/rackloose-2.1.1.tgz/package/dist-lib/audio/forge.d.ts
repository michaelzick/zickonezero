import type { DrumKit } from './drums';
import { type SampleKit } from './strike';
/**
 * FORGE's kit, printed once per session from original physical-ish models. Cymbals sum dozens of inharmonic partials
 * with their own decays over a noise wash, so they shimmer rather than hiss; the kick and snare are driven hard.
 */
export declare function forgeSample(voice: string): Float32Array;
/** FORGE's kit: 44.1 kHz one-shots, hotter and darker-toned than STRIKE's, with both hats choking the open hat. */
export declare const FORGE_KIT: SampleKit;
/**
 * FORGE's bus, which its kit plays into through `input`: its own Drive, a parallel clipper connected only while Drive is
 * up, and Room, a gated room send connected only while Room is up. `classic` makes the Digital sample kit.
 */
export declare function createForge(context: BaseAudioContext, bus: AudioNode, keep: <T extends AudioNode>(node: T) => T): {
    input: GainNode;
    classic: () => DrumKit;
    dispose(): void;
    apply(p: Record<string, number>): void;
};
