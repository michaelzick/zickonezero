import type { Patch } from './model';
export { CONCERT_PRESETS } from './model';
type Name = typeof import('./model').CONCERT_PRESETS[number];
/** Solo piano, written for SONATA. */
export declare function concertPreset(name: Name): Patch;
