import { type KeysProps } from './KeysParts';
/**
 * SONATA's front panel, as a piano's: the fallboard, polished ebony with a gold-leaf decal (satin walnut and a brass
 * piano hinge on the upright), carrying turned-brass Width and Volume either side of the model switch and the lid's prop
 * stick, the piano drawn above it; the red key felt below it; then, as under the lid, the cast-iron frame, its openings
 * the tuning pins in their bronze plate, the hammers' felt and the soundboard's spruce.
 */
export declare function SonataPanel(props: KeysProps): import("react").JSX.Element;
