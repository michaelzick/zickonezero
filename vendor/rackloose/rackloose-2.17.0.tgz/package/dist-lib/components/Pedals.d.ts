import type { ControlLevels } from '../audio/engine';
import { type ControlKind } from '../wheels';
/** A piano's brass pedals, or the chrome and rubber ones under the electric pianos and the organ. */
export type PedalFinish = 'brass' | 'chrome';
/** What the middle pedal does: a grand's sostenuto, or an upright's practice felt. */
export type MiddlePedal = 'Sostenuto' | 'Mute';
type Move = (kind: ControlKind, level: number, held: boolean, timeStamp?: number) => void;
type PedalsProps = {
    /** The controls the keys' instruments answer, of which the pedals and, without wheels, the mod wheel's rotary switch show. */
    kinds: readonly ControlKind[];
    /** Where each sits as heard, a hand's or a DICTATOR lane's, which the pedals follow while no one has them. */
    levels: ControlLevels;
    disabled: boolean;
    finish?: PedalFinish;
    middle?: MiddlePedal;
    /** A move from 0 to 1. `held` while a foot (a pointer, a key or a latch) keeps the pedal where it is. */
    onMove: Move;
};
/**
 * The foot pedals beside the keys of a piano, an electric piano or the organ, in place of the wheels. Under each foot pedal a gauge shows how far down it is, with a tick at half pedal. Hold a foot pedal down, or click it to latch it until the next click; dragging up while holding it lifts it part way, for half-pedal. The
 * swell pedal stays where it is left, and the organ's rotary switch flips between slow and fast.
 */
export declare function Pedals({ kinds, levels, disabled, finish, middle, onMove }: PedalsProps): import("react").JSX.Element;
export {};
