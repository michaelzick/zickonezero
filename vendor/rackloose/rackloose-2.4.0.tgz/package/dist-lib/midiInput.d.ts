/**
 * Hardware MIDI keyboards through the Web MIDI API, in browsers that have it (Chrome, Edge and Firefox; not Safari).
 * Notes arrive with the time they were received on the `performance.now()` clock, so they record as precisely as keys.
 */
export type MidiNote = {
    on: boolean;
    note: number;
    velocity: number;
    timeStamp: number;
    input: string;
};
export declare const midiSupported: () => boolean;
/** A note-on or note-off from a channel message, or null for anything else. A note-on at velocity 0 is a note-off. */
export declare function parseMidiMessage(data: ArrayLike<number>): {
    on: boolean;
    note: number;
    velocity: number;
} | null;
/**
 * Asks for MIDI access and listens to every input, including ones plugged in later, calling `onNote` for each note and
 * `onInputs` with the inputs' names whenever they change. Resolves with a function that stops listening.
 */
export declare function listenToMidi(onNote: (note: MidiNote) => void, onInputs?: (names: string[]) => void): Promise<() => void>;
