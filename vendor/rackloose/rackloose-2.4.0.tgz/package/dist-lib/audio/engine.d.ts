import { type Mix, type Patch } from '../model';
export { prepareAudio } from './prism';
import { type Note } from '../dictator';
/** The quietest level a meter reports, in dBFS. */
export declare const METER_FLOOR = -60;
/** SUM's channel and mix bus levels, in dBFS. */
export type MixerLevels = {
    channels: number[];
    bus: number[];
};
/** A take being recorded into a DICTATOR, played with its clip until the patch has it, and where Replace began hiding the clip. */
/** A take shown with its clip: Replace hides the clip from absolute tick `hideFrom` on, and in the clip's `covered` spans. */
type Take = {
    id: string;
    notes: Note[];
    hideFrom: number | null;
    covered: [number, number][];
};
/** A graph shared by the real-time player and offline exporter. No React or DOM dependencies. */
export declare class AudioGraph {
    readonly context: BaseAudioContext;
    private onError?;
    readonly master: GainNode;
    private nodes;
    private sources;
    private started;
    private runtime;
    private outputs;
    private inputs;
    private cvAmounts;
    /** Each STEP–16's scheduled notes, so an instrument gated by one STEP–16 can play the Pitch of another. */
    private notes;
    private white;
    private mix;
    private open;
    private muted;
    private manualTarget;
    private manualOwned;
    /** The sound sources each STEP–16 plays, and when each source was last hit by a sequencer. */
    private targets;
    private pulses;
    /** Each DICTATOR's notes sounding from playback, and the line its monophonic instruments follow. */
    private dictators;
    private take;
    /** The keys held on a DICTATOR played from the keyboard, each its own voice on a polysynth. */
    private manualKeys;
    patch: Patch;
    constructor(context: BaseAudioContext, patch: Patch, destination?: AudioNode, mix?: Mix, onError?: ((error: Error) => void) | undefined);
    private keep;
    /** A STEP–16 or DICTATOR Pitch cable into a polyphonic instrument carries notes, not a voltage, so each voice keeps its own pitch through its release. */
    private isNoteCable;
    /**
     * The note a polyphonic instrument plays when STEP–16 `sequencer` opens its gate: the note on the STEP–16 its Pitch cable comes from,
     * scaled by that cable's depth like a voltage, or C4 unplugged like MONARCH.
     */
    private polyNote;
    /** A STEP–16's note at `time`, or C3, where its Pitch starts. */
    private noteAt;
    private get main();
    private gain;
    private source;
    private buildModule;
    applyPatch(patch: Patch, initial?: boolean): void;
    /** The envelopes and instruments STEP–16 `sequencer`'s Gate cables reach. Each gate input takes one cable, so one STEP–16 at most. */
    private gatedBy;
    /** Applies mute and solo, SUM's channels included. Gates follow the cables, so a rebuilt graph needs its mix again. */
    setMix(mix: Mix, initial?: boolean): void;
    private openEnvelope;
    private closeEnvelope;
    /** Moves a STEP–16's Pitch to `note` at `time`, and remembers it for `noteAt`. */
    private setNote;
    private gateOn;
    /** Plays a note on STEP–16 `sequencer`, the first one unless named. A STEP–16 played from the keyboard ignores its sequence. */
    noteOn(note: number, velocity?: number, time?: number, sequencer?: string): void;
    noteOff(time?: number, sequencer?: string): void;
    /**
     * Plays clock step `count` on the STEP–16s `ids`, honouring step mutes and solos. Every Pitch moves before any gate
     * opens, so an instrument gated by one STEP–16 and pitched by another hears that step's note.
     */
    sequence(ids: string[], count: number, time: number, duration: number): void;
    /** A take being recorded into a DICTATOR, or none; it plays with the clip until the patch holds it. */
    setTake(take: Take | null): void;
    private dictatorState;
    /** The notes DICTATOR `module` plays from clip ticks [from, to): its clip, less what Replace is recording over, and its take. */
    private clipNotes;
    /**
     * Plays clock step `count` on the DICTATORs `ids`: the notes starting in that 16th of each looping clip, and the notes
     * ending in it. A note ends in the step its length reaches, so a tempo change or a stop still catches it. Polysynths
     * give each note its own voice; CONTOUR and MONARCH follow the newest note, retriggering as they do from the keys.
     */
    dictatorStep(ids: string[], count: number, time: number, duration: number): void;
    /**
     * The drum machines DICTATOR `id`'s Gate jacks reach through their Trig in. Each note plays the kit voice its General
     * MIDI drum note names. Stopping the DICTATOR leaves hits already queued, a lookahead's worth, to sound like any hit.
     */
    private kitsOf;
    /** Plays the voice `note` names on each drum machine of `kits` at `velocity`, 0–1, moved by that voice's Lag. */
    private drumNote;
    /** Lets go of every note DICTATOR `id` is playing back, at `time`. */
    private releaseDictator;
    /** Step time `time` moved by Lag `lag`, in ms, but never into the past: a hit pulled ahead of the first step plays at once. */
    private lagged;
    /** Records a sequencer hit on sound source `moduleId` at `time`, for its hit LED. */
    private pulse;
    /** When sound source `moduleId` was last hit by a sequencer, up to `time`, or -1. */
    lastPulse(moduleId: string, time: number): number;
    /** SUM `moduleId`'s channel and mix bus peak levels, in dBFS. */
    mixerLevels(moduleId: string): MixerLevels | null;
    /**
     * Plays a module from the keyboard. MONARCH and STEP–16 follow one note; polyphonic instruments give each `key` its own voice and,
     * like MONARCH, take over from the sequence while played.
     */
    manualOn(moduleId: string, note: number, key?: string, velocity?: number): void;
    /**
     * Lets go of one key played on polyphonic instruments; the others keep sounding. On a DICTATOR, its other instruments
     * fall back to `fallback`, the newest key still held, when the key let go was the one they followed.
     */
    manualRelease(key: string, fallback?: {
        note: number;
        velocity: number;
    }): void;
    manualOff(): void;
    /** Current compressor gain reduction in dB, zero or negative. */
    reduction(moduleId: string): number;
    drumStep(count: number, time: number, moduleId?: string): void;
    /** The devices SKITTER `moduleId`'s jacks copied from `port` reach. */
    private skitterTargets;
    /**
     * One SKITTER hit on lane `lane` at `time`: a drum lane plays the matching voice of every drum machine its Trig out
     * reaches, moved by that voice's Lag, and the Synth lane opens every gate its Gate out reaches for Gate of the hit's `length`.
     */
    private skitterHit;
    /** The drum machines SKITTER `moduleId` plays, whose scheduled hits stopping it cancels. */
    skitterKits(moduleId: string): string[];
    hit(moduleId: string, voice: string, time?: number, velocity?: number): void;
    cancelModule(moduleId: string, time?: number): void;
    cancelScheduled(time?: number): void;
    setMute(muted: boolean): void;
    flush(): Promise<void>;
    dispose(): void;
}
type Tick = {
    count: number;
    time: number;
    duration: number;
};
export declare class SynthEngine {
    private patch;
    private onError?;
    private context;
    private graph;
    private analyser;
    private timer;
    private notes;
    private target;
    private running;
    private nextTime;
    private count;
    private timeline;
    private frozen;
    private remaining;
    private muted;
    private mix;
    private suspended;
    private disposed;
    private revision;
    private manualRevision;
    private transportRevision;
    private moduleRevisions;
    private releaseSession;
    private inputs;
    /** Each held key's velocity, so a monophonic target falling back to a held note plays it as it was pressed. */
    private velocities;
    /** Clock steps that have started, newest last, kept a few seconds so an input can be placed on the beat it was heard. */
    private past;
    /** Whether the click sounds each beat while the transport runs, the count-in steps still to play, and the clicks queued. */
    private clickOn;
    private countIn;
    /** Queued clicks, each marked when it belongs to a count-in, which plays whether or not the click is on. */
    private clicks;
    /** The DICTATOR armed to record, and the take being recorded into it, with the keys still held and where each began. */
    private armed;
    private take;
    /** Called with each finished take: its DICTATOR, its notes, the parts of the clip it passed over and whether it replaces them. */
    onTake?: (id: string, notes: Note[], spans: [number, number][], replace: boolean) => void;
    /**
     * What was played on the keys while the transport ran and no take recorded it, at absolute ticks, oldest first, and
     * the keys still held: Capture keeps it, like Ableton's Capture MIDI. It reaches back as far as the longest clip.
     */
    private heard;
    /** How much earlier than heard, in ms, input is recorded, making up for a slow keyboard; negative records it later. */
    private offset;
    /** Each SUM's meter readings as last shown, with when they were read, so meters fall back smoothly. */
    private held;
    playing: boolean;
    constructor(patch: Patch, onError?: ((error: Error) => void) | undefined);
    get activeNote(): number | null;
    /** Every key a polyphonic instrument is sounding, or the one note a mono target plays. */
    get activeNotes(): number[];
    /** Whether the target plays each held key: a polysynth, or a DICTATOR, which records every key. */
    private get poly();
    get armedId(): string | null;
    get recording(): boolean;
    /** The notes recorded so far into DICTATOR `id`, while a take is being recorded into it. */
    takeNotes(id: string): Note[] | null;
    /** Arms DICTATOR `id` to record, or none. Arming another one ends the take being recorded. */
    arm(id: string | null): void;
    /**
     * Records into the armed DICTATOR. Stopped, the transport counts in `countIn` bars and starts every sequencer, and the
     * take starts on the downbeat; playing, the take starts now and the DICTATOR joins if it was stopped.
     */
    record(countIn?: number): Promise<boolean>;
    /**
     * Throws away what the take has recorded so far, keys still held included, and keeps recording from now, as Backspace
     * does in Reason. What Replace had cleared comes back. Returns how many notes went.
     */
    discardTake(): number;
    /** Shows the graph the take being recorded, hiding what Replace has recorded over so far. */
    private showTake;
    /** Whether anything played since the transport was last reset is waiting for Capture. */
    get canCapture(): boolean;
    /** What was played, as Capture keeps it for a `loop`-tick clip, and starts listening afresh. Keys still held aren't kept. */
    takeHeard(loop: number): Note[];
    /** Records input `ms` milliseconds earlier than it was heard, within RECORD_OFFSET_LIMIT, or later when negative. */
    setRecordOffset(ms: number): void;
    /**
     * The absolute tick of input at `timeStamp`, or now, moved by the record offset. A busy page can hold the scheduler
     * back past the step being heard, so it catches up first rather than lose the note.
     */
    private inputTick;
    /** Ends the take: notes still held end now, and the take goes to `onTake` to become one change to the patch. */
    finishTake(): void;
    /** Starts a note held on key `key` in the take, on the tick it was heard, moved to the grid by Q-Rec. */
    private captureStart;
    /** Ends the note held on key `key`, as heard at `timeStamp` or at absolute tick `end`, adding it to the take. */
    private captureEnd;
    /** Starts a note held on key `key` in what Capture keeps, once the transport is past any count-in. */
    private hearStart;
    /** Ends the note held on key `key` in what Capture keeps, forgetting notes the longest clip couldn't hold. */
    private hearEnd;
    reduction(moduleId: string): number;
    get sampleRate(): number;
    get ready(): boolean;
    private get sounding();
    /** The 16th-note count sounding now, or where the transport paused, or -1 at the start. A count-in reads as -1 too. */
    get clock(): number;
    /** The count-in step sounding now, counted back from -1 at the last step before the downbeat, or null outside a count-in. */
    get countingIn(): number | null;
    /** The clock's recent and queued steps, oldest first, for placing inputs in time. */
    clockSteps(): Tick[];
    /**
     * The absolute tick a note played at `timeStamp` (an input event's, on the `performance.now()` clock) was heard on,
     * taking out the output latency, or null when the transport isn't running then.
     */
    tickOf(timeStamp?: number): number | null;
    /** Turns the click on each beat on or off. Clicks never reach MAIN or an export. */
    setClick(on: boolean): void;
    /** A short click at `time`, higher on the bar's first beat, straight to the speakers. */
    private click;
    /** Silences the clicks queued after `time`, leaving a count-in's unless `countIn` is set. */
    private cancelClicks;
    get step(): number;
    modulePlaying(id: string): boolean;
    moduleClock(id: string): number;
    /** Whether sound source `moduleId` was hit by a sequencer in the last moment of what is being heard. */
    pulsing(moduleId: string): boolean;
    /** SUM `moduleId`'s channel and mix bus levels in dBFS, held at their peaks and falling back about 24 dB a second. */
    mixerLevels(moduleId: string): MixerLevels;
    get meter(): number;
    unlock(): Promise<boolean>;
    /**
     * Defer a phone's first touch until release, inside the user gesture. Keep each request cancellable until startup completes;
     * releasing normally should still sound a short tap, but a canceled touch must never play on a later gesture.
     */
    private unlockForInput;
    /** The app calls this as a finger lifts. It starts audio for the touches waiting on it, and does nothing otherwise. */
    lifted(key?: string): void;
    update(patch: Patch): void;
    /** Plays `note` from key `key` on `moduleId` at `velocity`, 0–1, recording it into a take when `moduleId` is recording. `timeStamp` is the input event's. */
    press(key: string, note: number, moduleId?: string, touch?: boolean, velocity?: number, timeStamp?: number): Promise<void>;
    /** Plays `note` on `moduleId` as the piano roll auditions it, ending the last audition; `endAudition` lets it go. */
    audition(note: number, moduleId: string, velocity: number): Promise<void>;
    endAudition(): void;
    /** The velocity key `key` was pressed with, or the newest held key's. */
    private velocityOf;
    /** A key let go before audio finished starting (on a phone, a first tap always is) still plays, briefly. */
    private tap;
    release(key: string, timeStamp?: number): void;
    /** Plays drum `voice` on `moduleId` at `velocity`, 0–1, from a pad, a key or a MIDI keyboard. */
    hit(moduleId: string, voice: string, key?: string, touch?: boolean, velocity?: number): Promise<void>;
    cancel(key: string): void;
    releaseManual(): void;
    /** Schedules one clock step on the sequencers `ids`: STEP–16s together, so their notes line up, then drum machines. */
    private schedule;
    /** Starts the clock, after `countIn` 16ths of clicks when counting in. */
    private startClock;
    /** Plays every sequencer, or `moduleId`. Starting from a stop, it can first count in `countIn` 16ths of clicks. */
    play(moduleId?: string, countIn?: number): Promise<void>;
    /**
     * PLAY STOPPED: while the transport plays, starts every stopped sequencer again at the next 16th, in time with the rest,
     * and returns their ids. Stopped or counting in it does nothing, so a click that races a stop never starts the rack.
     */
    rejoin(): Promise<string[]>;
    stopModule(id: string): void;
    private tick;
    pause(): void;
    /** REWIND: back to bar 1. Playing, the clock carries on from there and stopped sequencers stay stopped; stopped, it resets. */
    rewind(): void;
    reset(): void;
    /**
     * Moves the transport to 16th `count`, taking every sequencer to its place there in its own loop. Playing, the clock
     * carries on from there at the next 16th and a take keeps recording, what Replace passed over still replaced; stopped
     * or paused, it starts from there. What Capture heard no longer lines up with the clip, so it starts listening afresh.
     */
    seek(count: number): void;
    stop(): void;
    setMute(muted: boolean): void;
    setMix(mix: Mix): void;
    panic(): void;
    setSuspended(suspended: boolean): void;
    dispose(): void;
}
/** Renders the pattern as heard, honouring mute and solo; MAIN's temporary Mute is not applied. */
export declare function renderAudio(patch: Patch, loops?: number, mix?: Mix): Promise<AudioBuffer>;
export declare function encodeWav(buffer: Pick<AudioBuffer, 'numberOfChannels' | 'length' | 'sampleRate' | 'getChannelData'>): ArrayBuffer;
