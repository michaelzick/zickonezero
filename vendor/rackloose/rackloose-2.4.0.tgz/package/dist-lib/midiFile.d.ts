import { type Note } from './dictator';
/**
 * Standard MIDI Files, format 1, written at DICTATOR's own 960 ticks to the quarter note. A file holds a tempo track
 * and one track of notes per part; reading takes the notes back from format 0 or 1 files, whatever their resolution.
 */
export type MidiTrack = {
    name: string;
    notes: Note[];
    channel?: number;
};
export type MidiSong = {
    bpm: number | null;
    tracks: (MidiTrack & {
        channel: number;
    })[];
};
/** The largest MIDI file Rackloose reads, like a patch file's limit. */
export declare const MIDI_SIZE_LIMIT = 1000000;
/** The General MIDI drum channel, counted from 0. */
export declare const DRUM_CHANNEL = 9;
/** A variable-length quantity: seven bits a byte, the top bit set on every byte but the last. */
export declare function vlq(value: number): number[];
/** A format 1 file: a tempo track at `bpm` in 4/4, then each track's notes on its channel (the drum channel for drums). */
export declare function writeMidi(tracks: MidiTrack[], bpm: number): Uint8Array<ArrayBuffer>;
/**
 * The notes of a Standard MIDI File, at 960 ticks to the quarter note, one track per track and channel that has any.
 * Files are untrusted: every length is checked, unknown chunks and events are skipped, and a note never ended ends
 * with its track. Timing in SMPTE frames isn't supported.
 */
export declare function readMidi(bytes: Uint8Array): MidiSong;
/**
 * A DICTATOR clip from a file's notes, for a DICTATOR with room for `room` notes: the shortest Length that holds every
 * note's start, 16 bars at most. Notes starting past it, repeats on the same tick and pitch, and the latest notes past
 * `room` are left out, and lengths end at the loop.
 */
export declare function clipFromMidi(notes: readonly Note[], room: number): {
    notes: Note[];
    length: number;
    dropped: number;
};
