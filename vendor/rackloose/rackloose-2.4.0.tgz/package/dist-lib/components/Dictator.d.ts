import { type ReactNode } from 'react';
import { type Note } from '../dictator';
import { type MidiSong } from '../midiFile';
import { type Patch, type RackModule } from '../model';
/**
 * The instruments a DICTATOR plays with one pick from PLAYS: those with a Pitch and a Note gate of their own, and the
 * drum machines, which play a voice per note through Trig in.
 */
export declare const DICTATOR_INSTRUMENTS: string[];
export declare const playable: (module: RackModule) => boolean;
type DictatorProps = {
    module: RackModule;
    patch: Patch;
    name: string;
    clock: number;
    take: Note[] | null;
    armed: boolean;
    recording: boolean;
    disabled: boolean;
    /** The control for one of DICTATOR's params, by id. */
    control: (paramId: string) => ReactNode;
    transport: ReactNode;
    plays: string | null;
    offset: number;
    editing: boolean;
    grid: number;
    onParam: (paramId: string, value: number) => void;
    /** The Quantize button: `selected` notes the open piano roll has already moved, or none, for the app to move every note. */
    onQuantize: (selected: number) => void;
    onPlays: (instrumentId: string) => void;
    onArm: () => void;
    onClear: () => void;
    onCapture: () => void;
    onDiscard: () => void;
    onOffset: (ms: number) => void;
    onEditing: (open: boolean) => void;
    onNotes: (notes: Note[], key?: string) => void;
    onAudition: (note: number, velocity: number, touch: boolean) => void;
    onAuditionEnd: () => void;
    /** Moves the transport to 16th `step` of the clip, in the pass of it now playing. */
    onSeek: (step: number) => void;
    importing: {
        file: string;
        tracks: MidiSong['tracks'];
    } | null;
    onExportMidi: () => void;
    onImportMidi: (file: File) => void;
    onImportTracks: (index: number | null) => void;
    onImportCancel: () => void;
};
/**
 * DICTATOR's panel: its clip's position, arm, its settings and transport, its Quantize row, the clip drawn as a strip of
 * notes or opened in the piano roll, and PLAYS, which patches its Pitch and Gate into an instrument in one step.
 */
export declare function DictatorPanel({ module, patch, name, clock, take, armed, recording, disabled, control, transport, plays, offset, editing, grid, onParam, onPlays, onArm, onClear, onQuantize, onCapture, onDiscard, onOffset, onEditing, onNotes, onAudition, onAuditionEnd, onSeek, importing, onExportMidi, onImportMidi, onImportTracks, onImportCancel }: DictatorProps): import("react").JSX.Element;
export {};
