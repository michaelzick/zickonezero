import { type RackModule } from '../model';
type EditorProps = {
    module: RackModule;
    onParams: (values: Record<string, number>) => void;
};
/**
 * The knobs that shape one voice of BOOM, PUNCH, STRIKE or FORGE, ending in its Pan and Lag; its Level is on its lane.
 * `selected` is the voice being edited, which clicking a voice's name on its lane or its performance pad also picks. It
 * sits in the panel's top row, between the kit's own knobs and its label, its voice menu and Audition stacked before its knobs.
 */
export declare function VoiceEditor({ module, onParams, onAudition, disabled, selected, onSelect }: EditorProps & {
    onAudition: (voice: string) => void;
    disabled?: boolean;
    selected: string;
    onSelect: (voice: string) => void;
}): import("react").JSX.Element;
export declare function PrismEditor({ module, onParams }: EditorProps): import("react").JSX.Element;
export {};
