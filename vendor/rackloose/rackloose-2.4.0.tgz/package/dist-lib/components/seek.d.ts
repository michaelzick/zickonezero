import { type KeyboardEvent, type PointerEvent } from 'react';
/**
 * Props that make an element spanning a clip of `steps` 16ths the slider for its playhead, at 16th `position`, or null
 * while it doesn't show. A click or a drag moves it to the beat under the pointer, and a tap does by finger, leaving a
 * finger's drag to scroll. The arrows move it a beat, with Shift or Page Up and Down a bar, and Home and End go to the
 * first and last bars.
 */
export declare function usePlayheadSeek(name: string, steps: number, position: number | null, onSeek: (step: number) => void): {
    readonly role: "slider";
    readonly tabIndex: 0;
    readonly 'aria-label': `${string} playhead`;
    readonly 'aria-valuemin': 0;
    readonly 'aria-valuemax': number;
    readonly 'aria-valuenow': number;
    readonly 'aria-valuetext': string;
    readonly onPointerDown: (event: PointerEvent<Element>) => void;
    readonly onPointerMove: (event: PointerEvent<Element>) => void;
    readonly onPointerUp: (event: PointerEvent<Element>) => void;
    readonly onPointerCancel: () => void;
    readonly onKeyDown: (event: KeyboardEvent<Element>) => void;
};
