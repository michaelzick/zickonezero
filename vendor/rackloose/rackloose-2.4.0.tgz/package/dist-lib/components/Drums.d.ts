import { type ReactNode } from 'react';
import { type Mix, type Param, type RackModule } from '../model';
import { type MixToggle } from './MixButtons';
/** `onParams` changes one or more of the module's params as a single edit. */
type DrumProps = {
    module: RackModule;
    mix: Mix;
    onMix: MixToggle;
    onParams: (values: Record<string, number>) => void;
    onAudition: (voice: string) => void;
    disabled?: boolean;
};
/** A voice's level as gain from its default, which sits at the knob's centre: 0 dB there, +6 dB at full, -∞ at zero. */
export declare const decibels: (param: Param) => (value: number) => string;
/**
 * The params a tap on step `index` changes. With the 1/16 brush it toggles the step, clearing any 1/32s or roll it had;
 * another brush sets that note value on the step, turning it on, and tapping a step already set that way takes it back to 1/16.
 */
export declare function editRoll(module: RackModule, voice: string, index: number, brush: number): Record<string, number>;
/** SKITTER's NOTE row, in its panel's top row: the note value, `brush` hits per 16th, that a tap on a pad writes. */
export declare function RollBrush({ name, brush, onBrush }: {
    name: string;
    brush: number;
    onBrush: (hits: number) => void;
}): import("react").JSX.Element;
/**
 * One lane of 16 pads per voice, in groups of four, after its labelled level knob. The voice name auditions it and, given
 * `onSelect`, picks it for the voice editor or lights its knobs, marking `selected`'s name. `step` lights the playhead.
 * On a device with rolls, a tap writes `brush`, picked in its RollBrush.
 */
export declare function DrumPads({ module, mix, onMix, step, onParams, onAudition, disabled, selected, onSelect, brush }: DrumProps & {
    step: number;
    selected?: string;
    onSelect?: (voice: string) => void;
    brush?: number;
}): import("react").JSX.Element;
/**
 * Six rhythm lanes, each with its level under the Level heading, the sound and step editor for the `selected` lane, and
 * the rings over the device's own `controls`.
 */
export declare function EuclidMatrix({ module, mix, onMix, onParams, onAudition, disabled, clock, selected, onSelect, controls }: DrumProps & {
    clock: number;
    selected: string;
    onSelect: (voice: string) => void;
    controls: ReactNode;
}): import("react").JSX.Element;
/** Concentric rings, outermost first: one dot per step, large dots for hits, and the playhead glowing at `clock`. */
export declare function OrbitRings({ module, clock }: {
    module: RackModule;
    clock: number;
}): import("react").JSX.Element;
export {};
