import type { Patch } from './model';
export { INDUSTRIAL_PRESETS } from './model';
type Name = typeof import('./model').INDUSTRIAL_PRESETS[number];
/**
 * Three industrial originals, none with a cymbal crash: a dry, funky crawl on FORGE alone, a slow doom crawl on
 * double-tracked guitars and a hip-hop groove with a bass line to hum. The last two layer BOOM's sub kick, snare and clap
 * under FORGE on the same steps, BOOM playing into FORGE's Chain in so both kits share one drum bus. All three lay the
 * snares back and push the hats ahead with Lag.
 */
export declare function industrialPreset(name: Name): Patch;
