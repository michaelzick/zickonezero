import { type Note } from './dictator';
/**
 * The piano roll's edits, as pure functions of a clip's sorted notes and the indices of the selected ones. Each returns
 * the notes sorted again and the selection's new indices. A drag recomputes from the notes as they were when it began,
 * so passing over another note never changes it, and only where the drag ends counts.
 */
export type Edit = {
    notes: Note[];
    selected: Set<number>;
};
/** `tick` rounded down to a `grid`-tick line, or kept as it is without a grid. */
export declare const snapDown: (tick: number, grid: number | null) => number;
/** `tick` rounded to the nearest `grid`-tick line, or kept as it is without a grid. */
export declare const snapNear: (tick: number, grid: number | null) => number;
/** The index of the note sounding at `tick` on `pitch`, the latest to start if several overlap, or -1. */
export declare function noteAt(notes: readonly Note[], tick: number, pitch: number): number;
/** The notes that overlap ticks [from, to) on pitches `low` to `high`, as a marquee selects them. */
export declare function notesWithin(notes: readonly Note[], from: number, to: number, low: number, high: number): Set<number>;
/** Draws a note in a `loop`-tick clip, selected alone, or leaves the clip as it is when it already holds NOTE_LIMIT notes. */
export declare function addNote(notes: readonly Note[], tick: number, length: number, pitch: number, velocity: number, loop: number): Edit;
/** Removes the selected notes. */
export declare const deleteNotes: (notes: readonly Note[], selected: ReadonlySet<number>) => Edit;
/**
 * Moves the selected notes `ticks` later and `semitones` higher, together: the move stops where the first or last of
 * them would leave the clip or the MIDI note range, and a note moved near the loop end is shortened to fit.
 */
export declare function moveNotes(notes: readonly Note[], selected: ReadonlySet<number>, ticks: number, semitones: number, loop: number): Edit;
/** Lengthens (or shortens) the selected notes by `ticks`, each to at least `shortest` ticks and never past the loop end. */
export declare function resizeNotes(notes: readonly Note[], selected: ReadonlySet<number>, ticks: number, loop: number, shortest?: number): Edit;
/** Changes the selected notes' velocities by `amount`, or sets them all to `amount` when `absolute`, within 1 to 127. */
export declare function changeVelocity(notes: readonly Note[], selected: ReadonlySet<number>, amount: number, absolute?: boolean): Edit;
/** Moves the selected notes' starts `amount` of the way to a `grid`-tick grid, keeping their lengths within the loop. */
export declare function quantizeSelected(notes: readonly Note[], selected: ReadonlySet<number>, grid: number, amount: number, loop: number): Edit;
/**
 * Copies the selected notes to just after them, moved by their span rounded up to a whole `grid` (as Reason's Duplicate
 * does), and selects the copies. Copies that would start past the loop end, or past NOTE_LIMIT, are left out.
 */
export declare function duplicateNotes(notes: readonly Note[], selected: ReadonlySet<number>, grid: number, loop: number): Edit;
