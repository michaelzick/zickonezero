import type { SynthEngine } from './audio/engine';
import type { MidiSong } from './midiFile';
import type { Mix, Patch, RackModule } from './model';
import type { SavedPreset } from './presets';
/** The app callbacks used by the local and hosted studio bridges. */
export type StudioAccess = {
    revision: number;
    patch: Patch;
    mix: Mix;
    mainMuted: boolean;
    engine: SynthEngine;
    targetId: string;
    velocity: number;
    octave: number;
    click: boolean;
    countIn: number;
    recordOffset: number;
    loops: number;
    history: {
        undo: number;
        redo: number;
    };
    dirty: boolean;
    revertable: boolean;
    presets: SavedPreset[];
    openPresetId: string | null;
    midi: {
        available: boolean;
        pending: boolean;
        inputs: string[] | null;
    };
    notice: string;
    editRack(patch: Patch, mix: Mix): void;
    loadPatch(patch: Patch, message: string, presetId?: string): void;
    storeAs(id: string, patch: Patch): string | null;
    deletePreset(entry: SavedPreset): string | null;
    stepHistory(action: 'undo' | 'redo'): void;
    revert(): void;
    selectTarget(module: RackModule): void;
    note(key: string, note: number, velocity: number, on: boolean, timeStamp?: number): Promise<void>;
    restControllers(): void;
    clearHeld(): void;
    arm(id: string | null): void;
    record(countIn?: number, signal?: AbortSignal): Promise<boolean>;
    capture(id: string): void;
    setCountIn(bars: number): void;
    changeRecordOffset(ms: number): void;
    setClick(enabled: boolean): void;
    setMainMute(enabled: boolean): void;
    setKeyboard(octave: number, velocity: number): void;
    toggleMidi(): Promise<void>;
    disconnectMidi(): Promise<void>;
    importPatch(text: string): {
        presetId: string | null;
        droppedCables: number;
        storageError: string | null;
    };
    placeMidi(id: string, name: string, tracks: MidiSong['tracks']): {
        notes: number;
        dropped: number;
        bars: number;
    } | undefined;
    midiFile(module: RackModule): {
        bytes: Uint8Array<ArrayBuffer>;
        name: string;
    };
    download(data: BlobPart, type: string, name: string): void;
    flushSave(): void;
};
