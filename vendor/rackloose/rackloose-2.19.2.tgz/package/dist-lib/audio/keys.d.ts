import type { PolyInstrument, SynthHost } from './poly';
/** The modeled keyboards, which share one processor: SONATA, VELVET, REED, PLANET, STRUT, DRAWBAR and SERENADE. */
export type KeysType = 'sonata' | 'velvet' | 'reed' | 'planet' | 'strut' | 'drawbar' | 'serenade';
/**
 * A modeled keyboard. Notes, pedals and params go to its processor as timestamped events, so a pedal a DICTATOR lane
 * presses lands on the same sample as the notes around it. The Pitch input bends every string in cents and the CV input
 * moves the keyboard's own CV target; its output is stereo.
 */
export declare function createKeys(type: KeysType, context: BaseAudioContext, { keep, onError }: SynthHost): PolyInstrument;
