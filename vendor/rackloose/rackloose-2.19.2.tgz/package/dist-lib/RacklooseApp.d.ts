import { type ModuleType } from './model';
import type { StudioAccess } from './studioAccess';
/**
 * What a player did, for a host's analytics. Values are bounded: factory preset and device names, counts and sources,
 * never a patch or preset name a player typed or imported.
 */
export type RacklooseEvent = {
    name: 'preset_load';
    source: 'factory';
    preset: string;
} | {
    name: 'preset_load';
    source: 'user';
} | {
    name: 'patch_save' | 'patch_import' | 'patch_export' | 'transport_play' | 'record_start' | 'guide_open';
} | {
    name: 'wav_export';
    loops: number;
} | {
    name: 'module_add';
    module_type: ModuleType;
};
export type RacklooseAppProps = {
    keysEnabled?: boolean;
    suspended?: boolean;
    storageKey?: string;
    linkBrand?: boolean;
    onEvent?: (event: RacklooseEvent) => void;
};
export declare function RacklooseApp(props: RacklooseAppProps): import("react").JSX.Element;
/** Internal entry point for the local studio. The public component has the same host props as before. */
export declare function RacklooseStudio({ keysEnabled, suspended, storageKey, linkBrand, onEvent, onStudio }: RacklooseAppProps & {
    onStudio?: (studio: StudioAccess | null) => void;
}): import("react").JSX.Element;
