import type { Patch } from './model';
export { STRING_PRESETS } from './model';
type Name = typeof import('./model').STRING_PRESETS[number];
/** String orchestra, written for SERENADE. */
export declare function stringPreset(name: Name): Patch;
