import type { Patch } from './model';
export declare function bachAir(name: string): Patch;
