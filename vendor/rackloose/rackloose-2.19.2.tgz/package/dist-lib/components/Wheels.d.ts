import type { ControlLevels } from '../audio/engine';
import type { WheelKind } from '../wheels';
type WheelsProps = {
    /** Where the wheels sit as heard, a hand's or a DICTATOR lane's, which they follow while no one holds them. */
    levels: ControlLevels;
    disabled: boolean;
    /** Whether the third wheel, the strings' vibrato, shows; and whether the mod wheel is the strings' dynamics, DYN. */
    vibrato?: boolean;
    dynamics?: boolean;
    /** A move: the pitch wheel from −1 to 1, the others from 0 to 1. `held` while a hand is on the wheel. */
    onMove: (kind: WheelKind, level: number, held: boolean, timeStamp?: number) => void;
};
/**
 * The pitch and mod wheels at the left of the keys, played by dragging up and down, and for the string orchestra a third,
 * its vibrato. The pitch wheel springs back to the centre when let go, as the originals' do; the others stay where they
 * are left, and a double-click takes them back to rest.
 */
export declare function Wheels({ levels, disabled, vibrato, dynamics, onMove }: WheelsProps): import("react").JSX.Element;
export {};
