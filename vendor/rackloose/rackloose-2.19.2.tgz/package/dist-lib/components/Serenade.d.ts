import { type KeysProps } from './KeysParts';
/** The grouped string controls beneath a burgundy concert-hall crest. */
export declare function SerenadePanel(props: KeysProps): import("react").JSX.Element;
