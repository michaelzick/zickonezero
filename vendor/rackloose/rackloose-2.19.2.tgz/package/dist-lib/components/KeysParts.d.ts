import { type ReactNode } from 'react';
import { type RackModule } from '../model';
/** A 0 to 1 knob reads out as its scale is printed, 0 to 10. */
export declare const tenths: (value: number) => string;
/** A 0 to 1 knob's printed scale: 0, 5 and 10. */
export declare const TEN: [number, string][];
/** What every keyboard's front panel gets: its module, and a way to set its params. */
export type KeysProps = {
    module: RackModule;
    onParams: (values: Record<string, number>) => void;
};
type Control = KeysProps & {
    id: string;
    title?: string;
};
/**
 * The knobs: `skirted`, black with a brushed-aluminium top, as on a tine piano's Suitcase; `chrome`, a black knob in a
 * chrome ring, as on reed pianos; `fluted`, a small black fluted knob, as on a clavinet; `bakelite`, an organ's;
 * `brass`, turned brass, `pin`, a tuning pin in its coil of wire, and `ebony` with an ivory index, as on a piano;
 * `gilt`, fluted brass under an engine-turned face, and `ivory`, aged catalin on a brass collar, as on a string orchestra's.
 */
export type KnobLook = 'skirted' | 'chrome' | 'fluted' | 'bakelite' | 'brass' | 'pin' | 'ebony' | 'gilt' | 'ivory';
/**
 * A pot with its printed scale: a tick at each tenth of its turn, and the values `marks` names. `format` writes its
 * readout in the panel's own units, as 0 to 10 where the scale is printed so.
 */
export declare function Dial({ module, onParams, id, title, look, size, knob, marks, format }: Control & {
    look: KnobLook;
    size?: number;
    knob?: number;
    marks?: [number, string][];
    format?: (value: number) => string;
}): import("react").JSX.Element;
/**
 * A switch between a choice's positions, each printed and each a radio: a `rocker` tab pressed in at one end, an organ's
 * ivory `tablet`, a `slide` whose thumb sits at the position chosen, a piano lid's `prop` stick, which slides the
 * same way, or a `tilt` switch, an ivory rocker lying on its side with its legends engraved in it, tipped in at the end
 * chosen. The arrows step between them. A `picture` drawn above it shows what the choice does.
 */
export declare function Rocker({ module, onParams, id, title, look, labels, picture }: Control & {
    look: 'rocker' | 'tablet' | 'slide' | 'prop' | 'tilt';
    labels?: string[];
    picture?: ReactNode;
}): import("react").JSX.Element;
/**
 * A rotary switch, its positions printed round it in `order` (the param's own order if none): a `chicken` head, as on
 * an organ's vibrato scanner, a `pointer` knob, or a `gilt` one, an ivory pointer on fluted brass, `spread` degrees
 * from the first to the last. `knob` sizes its body, and `readout` prints the position's whole name under it, where
 * the names round it are short. Drag it up or down, use the arrows, or click it on a position.
 */
export declare function Selector({ module, onParams, id, title, order, labels, look, size, spread: wide, knob: body, readout }: Control & {
    order?: number[];
    labels?: string[];
    look: 'chicken' | 'pointer' | 'gilt';
    size?: number;
    spread?: number;
    knob?: number;
    readout?: boolean | import('react').ReactElement;
}): import("react").JSX.Element;
/** A lever that slides along a slot, as a clavinet's mute does, `ends` printed at either end of its travel. */
export declare function Lever({ module, onParams, id, title, ends }: Control & {
    ends: [string, string];
}): import("react").JSX.Element;
/** A section of a keyboard's panel, its name printed above it: a control strip, a service plate under the lid. */
export declare function Plate({ name, kind, children }: {
    name?: string;
    kind: string;
    children: ReactNode;
}): import("react").JSX.Element;
export {};
