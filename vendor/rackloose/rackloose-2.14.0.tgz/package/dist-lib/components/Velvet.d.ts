import { type KeysProps } from './KeysParts';
/**
 * VELVET's front panel, as a tine piano's: the Suitcase's brushed-aluminium control strip with its black skirted knobs
 * and the model selector, the red key felt below it, and under the lid the harp's adjustments.
 */
export declare function VelvetPanel(props: KeysProps): import("react").JSX.Element;
