import { type KeysProps } from './KeysParts';
/**
 * REED's front panel, as a reed piano's: its molded case with the speaker grilles either side, the dark control cheek
 * with small chrome-ringed knobs and the speaker rocker, and the action's adjustments on a service plate.
 */
export declare function ReedPanel(props: KeysProps): import("react").JSX.Element;
