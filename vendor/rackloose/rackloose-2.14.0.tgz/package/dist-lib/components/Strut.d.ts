import { type KeysProps } from './KeysParts';
/**
 * STRUT's front panel, as a clavinet's: a black control strip on its wooden case, with the row of rocker tabs (the AB
 * and CD pickup rockers, then Brilliant, Treble, Medium and Soft), the mute's slide lever and small black knobs.
 */
export declare function StrutPanel(props: KeysProps): import("react").JSX.Element;
