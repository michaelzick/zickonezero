import type { Param } from '../model';
type DrawbarsProps = {
    params: Param[];
    values: Record<string, number>;
    prefix: string;
    onChange: (id: string, value: number) => void;
};
/**
 * DRAWBAR's nine drawbars. Pull one out, by dragging it down or with the arrow keys, to bring in more of its pitch:
 * each step is 3 dB, from 0 pushed in to 8 all the way out. A number key sets it, and double-click pushes it back to
 * its default.
 */
export declare function Drawbars({ params, values, prefix, onChange }: DrawbarsProps): import("react").JSX.Element;
export {};
