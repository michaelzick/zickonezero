import { type KeysProps } from './KeysParts';
/**
 * DRAWBAR's front panel, as a tonewheel organ's: the nine drawbars in their black frame, the row of ivory tablets for
 * the percussion and the rotor, the chicken-head vibrato and chorus scanner in the organ's own order, and black knobs.
 */
export declare function OrganPanel(props: KeysProps): import("react").JSX.Element;
