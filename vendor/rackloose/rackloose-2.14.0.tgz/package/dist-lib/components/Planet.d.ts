import { type KeysProps } from './KeysParts';
/**
 * PLANET's front panel, as a plucked reed piano's: black leatherette, a chrome trim strip carrying the N and T slide
 * and small chrome knobs, and the reeds' adjustments below.
 */
export declare function PlanetPanel(props: KeysProps): import("react").JSX.Element;
