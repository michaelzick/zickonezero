import { type Note } from './dictator';
import { type ControlKind, type LaneKey, type WheelPoint } from './wheels';
/**
 * Standard MIDI Files, format 1, written at DICTATOR's own 960 ticks to the quarter note. A file holds a tempo track
 * and one track of notes per part, with its pitch bend, mod wheel (CC1) and pedals (sustain CC64, expression CC11), each in the lane a DICTATOR keeps it in; reading takes them back from format 0 or 1 files,
 * whatever their resolution.
 */
export type MidiTrack = {
    name: string;
    notes: Note[];
    channel?: number;
} & Partial<Record<LaneKey, WheelPoint[]>>;
export type MidiSong = {
    bpm: number | null;
    tracks: (MidiTrack & {
        channel: number;
    })[];
};
/** The largest MIDI file Rackloose reads, like a patch file's limit. */
export declare const MIDI_SIZE_LIMIT = 1000000;
/** The General MIDI drum channel, counted from 0. */
export declare const DRUM_CHANNEL = 9;
/** A variable-length quantity: seven bits a byte, the top bit set on every byte but the last. */
export declare function vlq(value: number): number[];
/**
 * A format 1 file: a tempo track at `bpm` in 4/4, then each track's notes, pitch bend, mod wheel and pedals on its
 * channel (the drum channel for drums).
 */
export declare function writeMidi(tracks: MidiTrack[], bpm: number): Uint8Array<ArrayBuffer>;
/**
 * The notes of a Standard MIDI File, at 960 ticks to the quarter note, one track per track and channel that has any,
 * with that channel's pitch bend, mod wheel and pedals. Files are untrusted: every length is checked, unknown chunks and
 * events are skipped, and a note never ended ends with its track. Timing in SMPTE frames isn't supported.
 */
export declare function readMidi(bytes: Uint8Array): MidiSong;
/**
 * A DICTATOR clip from a file's notes and wheel and pedal moves, for a DICTATOR with room for `room` notes: the shortest
 * Length that holds every note's start and every move off rest, 16 bars at most. Notes starting past it, repeats on the
 * same tick and pitch, and the latest notes past `room` are left out, and lengths end at the loop. The wheels and pedals
 * keep their moves in the clip, at rest until the first; `lanes` holds every lane, empty for one the file never moves.
 */
export declare function clipFromMidi(notes: readonly Note[], room: number, wheels?: Partial<Record<LaneKey, readonly WheelPoint[]>>): {
    notes: Note[];
    length: number;
    dropped: number;
    lanes: Record<ControlKind, WheelPoint[]>;
};
