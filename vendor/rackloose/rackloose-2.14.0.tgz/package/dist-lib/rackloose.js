"use client";
import { Fragment as e, createContext as t, useCallback as n, useContext as r, useEffect as i, useId as a, useImperativeHandle as o, useLayoutEffect as s, useMemo as c, useReducer as l, useRef as u, useState as d, useSyncExternalStore as f } from "react";
import { Fragment as p, jsx as m, jsxs as h } from "react/jsx-runtime";
var g = 3840, _ = [
	1,
	2,
	4,
	8,
	16
], v = _.at(-1) * g, y = 2048, b = 8192, x = [
	["1/4", 960],
	["1/8", 480],
	["1/8T", 320],
	["1/16", 240],
	["1/16T", 160],
	["1/32", 120]
], S = {
	1: 1,
	2: 14,
	3: 28,
	4: 42,
	5: 56,
	6: 70,
	7: 84,
	8: 98,
	9: 112,
	0: 127
}, C = (e) => (_[e] ?? _[0]) * g, w = (e) => C(e) / 240, T = (e) => [...e].sort((e, t) => e[0] - t[0] || e[2] - t[2]);
function E(e, t) {
	let n = 0, r = e.length;
	for (; n < r;) {
		let i = n + r >> 1;
		e[i][0] < t ? n = i + 1 : r = i;
	}
	return n;
}
var D = (e, t, n) => e.slice(E(e, t), E(e, n));
function O(e, t, n = 1, r = v) {
	return (Math.round(e + (Math.round(e / t) * t - e) * n) % r + r) % r;
}
function ee(e, t, n, r) {
	return T(e.map(([e, i, a, o]) => {
		let s = O(e, t, n, r);
		return [
			s,
			Math.max(1, Math.min(i, r - s)),
			a,
			o
		];
	}));
}
function k(e, t, n, r, i) {
	let a = (Math.round(e) % i + i) % i;
	return [
		a,
		Math.max(1, Math.min(Math.round(t), i - a)),
		n,
		Math.max(1, Math.min(127, Math.round(r)))
	];
}
function te(e, t, n) {
	if (t <= e) return [];
	if (t - e >= n) return [[0, n]];
	let r = (e % n + n) % n, i = r + (t - e);
	return i <= n ? [[r, i]] : [[r, n], [0, i - n]];
}
var ne = (e) => (Math.floor(e / g) + 1) * g;
function A(e, t, n = e.length ? ne(Math.max(...e.map((e) => e[0]))) : 0) {
	return T(e.filter(([e]) => e >= n - t && e < n).map(([e, n, r, i]) => k(e, n, r, i, t)));
}
var j = (e, t) => t.some(([t, n]) => e >= t && e < n);
function M(e, t, n, r) {
	let i = e.filter(([e, , i]) => !(n && j(e, r)) && !t.some((t) => t[0] === e && t[2] === i));
	return T([...i, ...t.slice(0, Math.max(0, y - i.length))]);
}
var N = class {
	held = [];
	on(e, t, n) {
		return this.held = [...this.held.filter((t) => t.id !== e), {
			id: e,
			note: t,
			velocity: n
		}], {
			note: t,
			velocity: n
		};
	}
	off(e) {
		let t = this.held.at(-1);
		if (this.held = this.held.filter((t) => t.id !== e), t?.id !== e) return;
		let n = this.held.at(-1);
		return n && n.note !== t.note ? {
			note: n.note,
			velocity: n.velocity
		} : n ? void 0 : null;
	}
	clear() {
		this.held = [];
	}
	get size() {
		return this.held.length;
	}
};
function re(e, t) {
	for (let n = e.length - 1; n >= 0; n--) {
		let r = e[n];
		if (!(r.time > t)) return t >= r.time + r.duration && n === e.length - 1 ? null : r.count * 240 + Math.min(1, (t - r.time) / r.duration) * 240;
	}
	let n = e[0];
	return n && n.time - t <= n.duration ? n.count * 240 - (n.time - t) / n.duration * 240 : null;
}
function ie(e, t, n) {
	return t && t.performanceTime > 0 ? t.contextTime + (e - t.performanceTime) / 1e3 : n.currentTime - n.latency - Math.max(0, n.now - e) / 1e3;
}
function ae(e, t = 16) {
	let n = (e % t + t) % t;
	return `${Math.floor(n / 16) + 1}.${Math.floor(n % 16 / 4) + 1}.${n % 4 + 1}`;
}
var oe = (e) => `−${Math.ceil(-e / 16)}.${Math.floor((e % 16 + 16) % 16 / 4) + 1}`, se = {
	kick: 36,
	rim: 37,
	snare: 38,
	clap: 39,
	lowTom: 45,
	hat: 42,
	pedal: 44,
	open: 46,
	midTom: 47,
	crash: 49,
	highTom: 50,
	ride: 51,
	china: 52,
	tambourine: 54,
	bell: 56,
	anvil: 56,
	highConga: 63,
	lowConga: 64,
	cabasa: 69,
	skin: 36,
	wood: 37,
	sand: 38,
	shaker: 42,
	metal: 46,
	tom: 45
}, ce = {
	35: 36,
	40: 38,
	39: 38,
	41: 45,
	43: 45,
	44: 42,
	47: 45,
	48: 50,
	52: 49,
	55: 49,
	57: 49,
	53: 51,
	59: 51,
	62: 63,
	70: 69
};
function le(e, t) {
	for (let n = t, r = 0; n !== void 0 && r < 4; n = ce[n], r++) {
		let t = e.find((e) => se[e.id] === n);
		if (t) return t.id;
	}
	return null;
}
// src/presetKit.ts
var ue = (e) => [...e].reduce((e, t, n) => t === "x" ? e | 1 << n : e, 0), P = (e, t, n) => [...e].map((e, r) => ({
	note: t[r],
	enabled: e !== ".",
	velocity: e === "X" ? 1 : e === "o" ? .5 : .74,
	gate: typeof n == "number" ? n : n[r]
})), F = (...e) => e.flatMap(([e, t]) => Array(t).fill(e)), de = (...e) => T(e.map(([e, t, n, r]) => [
	Math.round(e * 240),
	Math.round((t - .1) * 240),
	n,
	r
])), I = (e) => Number((45 / e).toFixed(3)), fe = (...e) => Object.fromEntries(Array.from({ length: 6 }, (t, n) => {
	let [r, i, a, o, s, c, l] = e[n] ?? [
		1,
		0,
		0,
		.005,
		.3,
		0,
		.2
	];
	return Object.entries({
		Ratio: r,
		Detune: i,
		Level: a,
		Attack: o,
		Decay: s,
		Sustain: c,
		Release: l
	}).map(([e, t]) => [`op${n + 1}${e}`, t]);
}).flat()), pe = {
	epiano: fe([
		1,
		0,
		.85,
		.002,
		1.8,
		.12,
		.7
	], [
		1,
		0,
		.45,
		.002,
		1,
		.05,
		.5
	], [
		1,
		4,
		.45,
		.002,
		1.4,
		.1,
		.6
	], [
		14,
		0,
		.2,
		.002,
		.12,
		0,
		.1
	], [
		1,
		-4,
		.35,
		.002,
		1.6,
		.1,
		.6
	], [
		1,
		0,
		.12,
		.002,
		.6,
		0,
		.3
	]),
	bell: fe([
		1,
		0,
		.8,
		.002,
		2.2,
		0,
		1.4
	], [
		3.5,
		0,
		.5,
		.002,
		1.4,
		0,
		1
	], [
		2,
		3,
		.35,
		.002,
		1.5,
		0,
		1
	], [
		7,
		0,
		.3,
		.002,
		.6,
		0,
		.5
	], [
		4,
		0,
		.12,
		.002,
		.9,
		0,
		.6
	], [
		10.5,
		0,
		.15,
		.002,
		.3,
		0,
		.3
	]),
	reed: fe([
		1,
		0,
		.8,
		.03,
		.4,
		.8,
		.25
	], [
		2,
		0,
		.5,
		.03,
		.5,
		.6,
		.3
	], [
		1,
		6,
		.3,
		.03,
		.4,
		.8,
		.25
	], [
		2,
		0,
		.3,
		.03,
		.5,
		.5,
		.3
	]),
	kalimba: fe([
		1,
		0,
		.85,
		.002,
		.7,
		0,
		.4
	], [
		3,
		0,
		.35,
		.002,
		.08,
		0,
		.08
	], [
		1,
		5,
		.4,
		.002,
		.5,
		0,
		.3
	], [
		7,
		0,
		.18,
		.002,
		.04,
		0,
		.04
	]),
	slap: fe([
		1,
		0,
		.9,
		.002,
		.35,
		.25,
		.08
	], [
		1,
		0,
		.65,
		.002,
		.15,
		.05,
		.06
	], [
		1,
		3,
		.5,
		.002,
		.3,
		.2,
		.08
	], [
		3,
		0,
		.35,
		.002,
		.05,
		0,
		.04
	], [
		.5,
		0,
		.35,
		.002,
		.4,
		.3,
		.08
	], [
		.5,
		0,
		.1,
		.002,
		.2,
		0,
		.06
	]),
	bass: fe([
		1,
		0,
		.9,
		.002,
		.4,
		.3,
		.1
	], [
		1,
		0,
		.55,
		.002,
		.25,
		.1,
		.08
	], [
		.5,
		0,
		.5,
		.002,
		.5,
		.4,
		.1
	], [
		1,
		0,
		.2,
		.002,
		.15,
		0,
		.08
	]),
	pluck: fe([
		1,
		0,
		.8,
		.002,
		.45,
		0,
		.3
	], [
		2,
		0,
		.4,
		.002,
		.15,
		0,
		.1
	], [
		2,
		3,
		.35,
		.002,
		.35,
		0,
		.25
	], [
		5,
		0,
		.2,
		.002,
		.06,
		0,
		.05
	])
};
function L(e, t, n, r, i) {
	let a = {
		version: 1,
		name: e,
		modules: Object.entries(r).map(([e, { type: t, params: n, lanes: r, euclid: i, steps: a, notes: o, controls: s }], c) => {
			let l = Ut(t, e), u = Z[t].drum?.voices ?? [];
			if (r) for (let e of u) l.params[`${e.id}Pattern`] = ue(r[e.id] ?? "");
			if (i) for (let e of u) {
				let [t, n, r = 0] = i[e.id] ?? [0, l.params[`${e.id}Steps`]];
				Object.assign(l.params, {
					[`${e.id}Hits`]: t,
					[`${e.id}Steps`]: n,
					[`${e.id}Shift`]: r
				});
			}
			return Object.assign(l.params, n), a && c > 0 ? {
				...l,
				steps: a
			} : o ? {
				...l,
				notes: o,
				...s
			} : l;
		}),
		cables: [],
		sequencer: {
			bpm: t,
			swing: n,
			steps: Object.values(r)[0].steps ?? Gt("performance").steps
		}
	};
	for (let [e, t, n, r, o] of i) a = bn(a, {
		moduleId: e,
		portId: t
	}, {
		moduleId: n,
		portId: r
	}, o);
	return a;
}
var R = (e, t, n = "") => [[
	e,
	`pitch${n}`,
	t,
	"pitch"
], [
	e,
	`gate${n}`,
	t,
	"gate"
]], me = (...e) => e.slice(1).map((t, n) => [
	e[n],
	"out",
	t,
	"in"
]), he = (e, t, ...n) => [...e.flatMap((e, n) => [...me(...e), [
	e.at(-1),
	"out",
	t,
	"abcdefgh"[n]
]]), ...me(t, ...n)], ge = (e, ...t) => he(e, "mixer", ...t, "output");
function _e(e) {
	if (e === "Vintage Bass") return L(e, 94, .1, {
		performance: {
			type: "performance",
			steps: P("X..o.xx.X..x.xx.", [
				43,
				43,
				43,
				43,
				43,
				46,
				48,
				48,
				36,
				36,
				36,
				48,
				48,
				46,
				41,
				41
			], [
				.9,
				.5,
				.5,
				.5,
				.5,
				.6,
				.9,
				.5,
				.9,
				.5,
				.5,
				.45,
				.5,
				.6,
				.9,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Wave: 3,
				osc2Detune: 4,
				osc2Level: .4,
				osc3Wave: 1,
				osc3Level: .45,
				cutoff: 560,
				resonance: .3,
				drive: .3,
				envAmount: .45,
				filterAttack: .004,
				filterDecay: .25,
				filterSustain: .3,
				filterRelease: .15,
				ampAttack: .004,
				ampDecay: .4,
				ampSustain: .8,
				ampRelease: .08,
				glide: .01,
				level: .75
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 2,
				midFreq: 1,
				midGain: 3,
				drive: 6
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 35,
				lfGain: 1,
				lfFreq: 80,
				lfBell: 1,
				lmfGain: -5,
				lmfFreq: 250,
				lmfQ: .8,
				hmfGain: 4,
				hmfFreq: 1200,
				hmfQ: 1.1,
				lpf: 7e3
			}
		},
		melody: {
			type: "performance",
			steps: P("x".repeat(16), F([86, 6], [84, 1], [82, 1], [79, 6], [77, 1], [79, 1]), .95)
		},
		whistle: {
			type: "monarch",
			params: {
				osc1Wave: 0,
				osc1Level: .9,
				osc2Level: 0,
				osc3Level: 0,
				cutoff: 6e3,
				resonance: 0,
				drive: 0,
				envAmount: 0,
				tracking: 0,
				ampAttack: .03,
				ampDecay: .3,
				ampSustain: 1,
				ampRelease: .3,
				glide: .12,
				level: .5
			}
		},
		whistleEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lpf: 9e3
			}
		},
		echo: {
			type: "delay",
			params: {
				time: I(94),
				feedback: .35,
				mix: .25
			}
		},
		echoR: {
			type: "delay",
			params: {
				time: Number((60 / 94).toFixed(3)),
				feedback: .3,
				mix: 1
			}
		},
		chords: {
			type: "performance",
			steps: P("x.......x.......", F([67, 8], [60, 8]), .95)
		},
		keys: {
			type: "aurora",
			params: {
				osc1Wave: 2,
				osc2Wave: 1,
				osc2Detune: 8,
				blend: .45,
				cutoff: 2e3,
				resonance: .1,
				envAmount: .2,
				filterAttack: .05,
				filterDecay: .8,
				filterSustain: .4,
				ampAttack: .04,
				ampDecay: .9,
				ampSustain: .7,
				ampRelease: 1.6,
				lfoWidth: .3,
				chord: 4,
				vintage: .4,
				level: .65
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 300,
				lmfGain: -3,
				lmfFreq: 450,
				lmfQ: 1.2,
				hmfGain: 2,
				hmfFreq: 2500,
				hmfQ: .8,
				hfGain: 2,
				hfFreq: 1e4,
				output: 3
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 1.8,
				mix: .25
			}
		},
		drums: {
			type: "strike",
			params: {
				level: 1,
				kickDecay: .4,
				snareTune: -2,
				snareDecay: .3,
				snareLag: 10,
				clapLevel: .55,
				clapLag: 14,
				hatDecay: .06,
				hatLevel: .45,
				hatPan: .25,
				hatLag: -5,
				openLevel: .4,
				openPan: .25,
				openLag: -5,
				tambourineLevel: .3,
				tambourinePan: -.35
			},
			lanes: {
				kick: "x......xx.x.....",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "x.xxx.x.x.xxx.x.",
				open: ".....x.......x..",
				tambourine: "....x.......x..."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 3,
				ratio: 3,
				attack: .01,
				release: .15,
				color: 1,
				detectorHp: 1,
				output: 8
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 3,
				lfFreq: 65,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 400,
				lmfQ: 1.4,
				hmfGain: 4,
				hmfFreq: 3800,
				hmfQ: .9,
				lpf: 14e3
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: .7,
				c: .7,
				d: .45,
				e: .35,
				aPan: 0,
				bPan: 0,
				cPan: .3,
				dPan: -.3,
				ePan: .7
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 0,
				attack: 4,
				release: 4,
				scHpf: 2,
				output: 4.5
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...R("performance", "monarch"),
		...R("melody", "whistle"),
		...R("chords", "keys"),
		[
			"whistleEq",
			"out2",
			"echoR",
			"in"
		],
		...ge([
			[
				"drums",
				"talon",
				"drumEq"
			],
			[
				"monarch",
				"brit",
				"bassEq"
			],
			[
				"keys",
				"console",
				"space"
			],
			[
				"whistle",
				"whistleEq",
				"echo"
			],
			["echoR"]
		], "cohere")
	]);
	if (e === "Vintage Lead") return L(e, 120, 0, {
		performance: {
			type: "performance",
			steps: P("X.xx.xx.X.xxX.xx", [
				76,
				76,
				76,
				74,
				74,
				72,
				74,
				74,
				72,
				72,
				69,
				72,
				71,
				71,
				67,
				71
			], .7)
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 3,
				osc1Level: .7,
				osc2Detune: 9,
				osc2Level: .5,
				osc3Wave: 3,
				osc3Octave: 1,
				osc3Level: .2,
				cutoff: 2600,
				resonance: .25,
				drive: .2,
				envAmount: .35,
				tracking: .6,
				filterDecay: .2,
				filterSustain: .4,
				ampAttack: .004,
				ampDecay: .25,
				ampSustain: .7,
				ampRelease: .15,
				glide: .025,
				level: .6
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 300,
				lmfGain: -2,
				lmfFreq: 500,
				hmfGain: 3,
				hmfFreq: 3e3,
				hfGain: 2,
				hfFreq: 12e3
			}
		},
		echo: {
			type: "delay",
			params: {
				time: I(120),
				feedback: .3,
				mix: .22
			}
		},
		octaves: {
			type: "performance",
			steps: P("XxXxXxXxXxXxXxXx", [
				33,
				45,
				33,
				45,
				33,
				45,
				33,
				45,
				29,
				41,
				29,
				41,
				31,
				43,
				31,
				43
			], .5)
		},
		bass: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Detune: 6,
				osc2Level: .4,
				osc3Octave: 0,
				osc3Level: .3,
				cutoff: 600,
				resonance: .3,
				envAmount: .5,
				filterDecay: .12,
				filterSustain: .3,
				ampAttack: .002,
				ampDecay: .15,
				ampSustain: .5,
				ampRelease: .05,
				level: .7
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 1,
				lfGain: 2,
				midFreq: 3,
				midGain: 2,
				drive: 6
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 1,
				lfFreq: 70,
				lfBell: 1,
				lmfGain: -4.5,
				lmfFreq: 250,
				lmfQ: .9,
				hmfGain: 3,
				hmfFreq: 1200,
				hmfQ: 1.1,
				lpf: 7e3
			}
		},
		chords: {
			type: "performance",
			steps: P("x.......x...x...", F([57, 8], [50, 4], [52, 4]), .95)
		},
		strings: {
			type: "aurora",
			params: {
				osc2Wave: 0,
				osc2Detune: 12,
				hpf: 200,
				cutoff: 3e3,
				envAmount: .15,
				filterAttack: .1,
				filterDecay: .8,
				filterSustain: .6,
				ampAttack: .08,
				ampDecay: .6,
				ampSustain: .8,
				ampRelease: 1.2,
				lfoRate: .5,
				lfoWidth: .2,
				chord: 2,
				vintage: .4,
				level: .7
			}
		},
		stringsEq: {
			type: "equalizer",
			params: {
				lmfGain: -6,
				lmfFreq: 300,
				lmfQ: .7,
				hmfGain: 2,
				hmfFreq: 3e3,
				hmfQ: .8,
				hfGain: 2.5,
				hfFreq: 1e4,
				output: 2
			}
		},
		spaceEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lpf: 1e4
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2,
				mix: 1
			}
		},
		drums: {
			type: "boom",
			params: {
				kickTune: 54.2,
				kickDecay: .5,
				snareTone: .55,
				snappy: .7,
				hatDecay: .04,
				hatPan: .25,
				openDecay: .25,
				openPan: .25,
				level: .85
			},
			lanes: {
				kick: "x...x...x...x...",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "xx.xxx.xxx.xxx.x",
				open: "..x...x...x...x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .003,
				release: .1,
				color: 1,
				detectorHp: 1,
				output: 5
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2.5,
				lfFreq: 60,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 400,
				lmfQ: 1.4,
				hmfGain: 3.5,
				hmfFreq: 3800,
				hmfQ: .9,
				lpf: 14e3
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: .75,
				c: .7,
				d: .45,
				e: .4,
				aPan: 0,
				bPan: 0,
				cPan: -.35,
				dPan: .15,
				ePan: .4
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 1,
				attack: 4,
				release: 1,
				scHpf: 2,
				output: 3
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...R("performance", "monarch"),
		...R("octaves", "bass"),
		...R("chords", "strings"),
		[
			"stringsEq",
			"out2",
			"spaceEq",
			"in"
		],
		...ge([
			[
				"drums",
				"talon",
				"drumEq"
			],
			[
				"bass",
				"brit",
				"bassEq"
			],
			["strings", "stringsEq"],
			[
				"monarch",
				"console",
				"echo"
			],
			["spaceEq", "space"]
		], "cohere")
	]);
	if (e === "Boom Bap") return L(e, 84, .18, {
		performance: {
			type: "performance",
			steps: P("X.....x.X..x..x.", F([50, 8], [55, 6], [50, 2]), [
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.4,
				.5,
				.95,
				.5,
				.5,
				.4,
				.5,
				.5,
				.6,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 1,
				osc1Octave: -1,
				osc1Level: .8,
				osc2Wave: 2,
				osc2Octave: -1,
				osc2Detune: 0,
				osc2Level: .2,
				osc3Wave: 0,
				osc3Octave: -2,
				osc3Level: .35,
				cutoff: 600,
				resonance: .1,
				drive: .3,
				envAmount: .25,
				tracking: .4,
				filterDecay: .3,
				filterSustain: .3,
				ampAttack: .006,
				ampDecay: .5,
				ampSustain: .75,
				ampRelease: .12,
				glide: .01,
				level: .8
			}
		},
		delay: {
			type: "delay",
			params: {
				time: I(84),
				feedback: .3,
				mix: .18
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 50,
				kickDecay: .55,
				snareTone: .4,
				snappy: .45,
				snareLag: 10,
				hatDecay: .05,
				hatPan: .2,
				hatLag: -5,
				level: .85
			},
			lanes: {
				kick: "x.....x...x..x..",
				snare: "....x.......x...",
				hat: "x.x.x.x.x.x.x.xx"
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .8,
				woodTune: 3,
				woodLevel: .4,
				shakerDecay: .08,
				shakerLevel: .5
			},
			euclid: {
				wood: [
					3,
					16,
					3
				],
				shaker: [
					8,
					16,
					1
				]
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 35,
				lfGain: 3,
				lfFreq: 70,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 420,
				lmfQ: 1.4,
				hmfGain: 4,
				hmfFreq: 3400,
				hmfQ: 1,
				lpf: 12e3
			}
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .1,
				brightness: .8,
				velocity: .75,
				lfoRate: 4.5,
				lfoDepth: .03,
				chord: 4,
				level: .7,
				...pe.epiano,
				op1Ratio: 2,
				op2Ratio: 2,
				op3Ratio: 2,
				op4Ratio: 16,
				op5Ratio: 2,
				op6Ratio: 2
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 4,
				midFreq: 1,
				midGain: 2,
				hfGain: -6,
				drive: 10,
				output: 4
			}
		},
		keysEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lmfGain: -2,
				lmfFreq: 500,
				lmfQ: 1,
				hmfGain: 2,
				hmfFreq: 2500,
				hmfQ: 1,
				lpf: 1e4,
				output: 2
			}
		},
		echoR: {
			type: "delay",
			params: {
				time: Number((60 / 84).toFixed(3)),
				feedback: .3,
				mix: 1
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .006,
				release: .15,
				color: 2,
				detectorHp: 1,
				output: 6
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 35,
				lfGain: 1.5,
				lfFreq: 80,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 250,
				lmfQ: .8,
				hmfGain: 4,
				hmfFreq: 1100,
				hmfQ: 1.1,
				lpf: 6e3
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .85,
				b: .6,
				c: .6,
				d: .8,
				e: .35,
				aPan: 0,
				bPan: -.3,
				cPan: 0,
				dPan: .35,
				ePan: .7
			}
		},
		valve: {
			type: "compressor",
			params: {
				input: 1,
				threshold: -16,
				time: 1,
				output: 0
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...R("performance", "monarch"),
		...R("performance", "prism", 3),
		[
			"keysEq",
			"out2",
			"echoR",
			"in"
		],
		...ge([
			[
				"boom",
				"console",
				"talon"
			],
			[
				"prism",
				"brit",
				"keysEq",
				"delay"
			],
			["monarch", "bassEq"],
			["orbit"],
			["echoR"]
		], "valve")
	]);
	if (e === "Late Night Hip-Hop") return L(e, 72, .24, {
		performance: {
			type: "performance",
			steps: P("X.....o.X....x..", F([41, 8], [39, 5], [46, 3]), [
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.95,
				.5,
				.5,
				.5,
				.5,
				.7,
				.5,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 1,
				osc1Level: .8,
				osc2Wave: 2,
				osc2Detune: 0,
				osc2Level: .22,
				osc3Wave: 0,
				osc3Level: .4,
				cutoff: 650,
				resonance: .1,
				drive: .15,
				envAmount: .3,
				filterDecay: .4,
				ampAttack: .008,
				ampDecay: .6,
				ampSustain: .8,
				ampRelease: .25,
				glide: .02,
				level: .8
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 35,
				lfGain: 1.5,
				lfFreq: 80,
				lfBell: 1,
				lmfGain: -5,
				lmfFreq: 250,
				lmfQ: .8,
				hmfGain: 4,
				hmfFreq: 1200,
				hmfQ: 1.1,
				lpf: 7e3
			}
		},
		chords: {
			type: "performance",
			steps: P("x.......x.....o.", F([57, 8], [55, 8]), .95)
		},
		keys: {
			type: "aurora",
			params: {
				osc1Wave: 1,
				osc1Width: .3,
				osc2Wave: 2,
				osc2Octave: 1,
				blend: .4,
				cutoff: 1400,
				envAmount: .25,
				filterAttack: .01,
				filterDecay: 1.2,
				ampAttack: .06,
				ampDecay: 1.5,
				ampSustain: .6,
				ampRelease: 2,
				lfoWidth: .35,
				lfoFilter: .05,
				chord: 2,
				vintage: .5,
				level: .6
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 3,
				midFreq: 0,
				midGain: -3,
				hfGain: -5,
				drive: 8,
				output: 3
			}
		},
		keysEq: {
			type: "equalizer",
			params: {
				lmfGain: -3.5,
				lmfFreq: 320,
				lmfQ: 1.1,
				hmfGain: 1.5,
				hmfFreq: 2800,
				hmfQ: 1,
				lpf: 9e3
			}
		},
		roomEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lpf: 8e3
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2.4,
				mix: 1
			}
		},
		glint: {
			type: "performance",
			steps: P("...x..x....x....", [
				88,
				88,
				88,
				88,
				88,
				88,
				84,
				84,
				84,
				84,
				84,
				86,
				86,
				86,
				86,
				86
			], .9)
		},
		bell: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: 0,
				brightness: .55,
				velocity: .5,
				level: 1,
				...pe.bell
			}
		},
		bellEq: {
			type: "equalizer",
			params: {
				hpf: 350,
				hmfGain: -2,
				hmfFreq: 4e3,
				hmfQ: 1,
				lpf: 9e3,
				output: 1.5
			}
		},
		bellEcho: {
			type: "delay",
			params: {
				time: I(72),
				feedback: .4,
				mix: .35
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 47,
				kickDecay: .7,
				snareTone: .3,
				snappy: .35,
				snareLag: 12,
				rimLag: 10,
				rimPan: -.4,
				hatDecay: .04,
				hatPan: .25,
				hatLag: -6,
				openDecay: .3,
				level: .85
			},
			lanes: {
				kick: "x......x..x.....",
				snare: "....x.......x...",
				rim: "..............x.",
				hat: "..x...x...x...x."
			}
		},
		orbit: {
			type: "orbit",
			params: {
				pitch: -4,
				level: .8,
				shakerLevel: .5
			},
			euclid: { shaker: [
				6,
				16,
				2
			] }
		},
		talon: {
			type: "talon",
			params: {
				input: 4,
				ratio: 5,
				attack: .01,
				release: .4,
				color: 1,
				output: 9
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 3,
				lfFreq: 65,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 400,
				lmfQ: 1.4,
				hmfGain: 3.5,
				hmfFreq: 3400,
				hmfQ: .9,
				lpf: 11e3
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .9,
				b: .65,
				c: .6,
				d: 1,
				e: .45,
				f: .5,
				aPan: 0,
				bPan: 0,
				cPan: -.3,
				dPan: .4,
				ePan: .35,
				fPan: .5
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 25,
				lpf: 9e3,
				lfGain: 1.5,
				lfFreq: 120,
				lfBell: 1,
				hfGain: -2,
				hfFreq: 6e3
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -18,
				ratio: 0,
				attack: 4,
				release: 4,
				scHpf: 2,
				output: 4
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...R("performance", "monarch"),
		...R("chords", "keys"),
		...R("glint", "bell"),
		[
			"keysEq",
			"out2",
			"roomEq",
			"in"
		],
		...ge([
			[
				"boom",
				"talon",
				"drumEq"
			],
			["monarch", "bassEq"],
			[
				"keys",
				"brit",
				"keysEq"
			],
			["orbit"],
			["roomEq", "space"],
			[
				"bell",
				"bellEq",
				"bellEcho"
			]
		], "console", "cohere")
	]);
	if (e === "Roots Reggae") return L(e, 76, .2, {
		performance: {
			type: "performance",
			steps: P("..X...x.X..x.xx.", [
				33,
				33,
				33,
				33,
				33,
				33,
				36,
				36,
				38,
				38,
				38,
				38,
				38,
				41,
				40,
				40
			], [
				.65,
				.65,
				.85,
				.65,
				.65,
				.65,
				.5,
				.65,
				.85,
				.65,
				.65,
				.45,
				.65,
				.5,
				.85,
				.65
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 1,
				osc1Level: .7,
				osc2Wave: 1,
				osc2Octave: 1,
				osc2Detune: 0,
				osc2Level: .3,
				osc3Wave: 0,
				osc3Octave: 0,
				osc3Level: .5,
				cutoff: 600,
				resonance: .05,
				drive: .35,
				envAmount: .15,
				filterDecay: .3,
				ampAttack: .006,
				ampDecay: .35,
				ampSustain: .7,
				ampRelease: .12,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 2,
				midFreq: 0,
				midGain: -3,
				hfGain: -4,
				drive: 7
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lmfGain: -4,
				lmfFreq: 230,
				lmfQ: .9,
				hmfGain: 3,
				hmfFreq: 900,
				hmfQ: 1,
				lpf: 4500
			}
		},
		bubble: {
			type: "performance",
			steps: P("..xx..xx..xx..xx", F([57, 8], [50, 8]), .6)
		},
		organ: {
			type: "aurora",
			params: {
				osc1Wave: 1,
				osc2Wave: 3,
				osc2Octave: 1,
				osc2Detune: 0,
				blend: .5,
				cutoff: 2600,
				resonance: 0,
				slope: 0,
				envAmount: 0,
				ampAttack: .003,
				ampDecay: .2,
				ampSustain: .85,
				ampRelease: .04,
				lfoRate: 6,
				lfoPitch: .01,
				lfoWidth: 0,
				chord: 2,
				vintage: .2,
				level: .45
			}
		},
		organEq: {
			type: "equalizer",
			params: {
				hpf: 130,
				lmfGain: -4,
				lmfFreq: 280,
				lmfQ: .9,
				hmfGain: 2,
				hmfFreq: 2200,
				hmfQ: 1,
				lpf: 9e3
			}
		},
		skank: {
			type: "performance",
			steps: P("....X.......X...", F([69, 8], [62, 8]), .35)
		},
		guitar: {
			type: "oracle",
			params: {
				bShape: 2,
				bFine: 5,
				cutoff: 2800,
				resonance: .2,
				envAmount: .3,
				filterDecay: .12,
				filterSustain: 0,
				ampAttack: .002,
				ampDecay: .14,
				ampSustain: 0,
				ampRelease: .08,
				chord: 2,
				level: 1
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 300,
				lmfGain: -3,
				lmfFreq: 500,
				lmfQ: 1.2,
				hmfGain: 3.5,
				hmfFreq: 2200,
				hmfQ: 1.4,
				lpf: 9e3,
				output: 3
			}
		},
		echo: {
			type: "delay",
			params: {
				time: I(76),
				feedback: .4,
				mix: .3
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 1.6,
				mix: .22
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 46,
				kickDecay: .5,
				kickLevel: 1.3,
				snareTone: .5,
				rimLevel: .9,
				hatDecay: .05,
				hatPan: .25,
				hatLag: -4,
				openDecay: .35,
				openPan: .25,
				openLag: -4,
				level: .85
			},
			lanes: {
				kick: "........x.......",
				rim: "........x.......",
				hat: "x.x.x...x.x.x..x",
				open: "......x.......x."
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .8,
				metalDecay: .09,
				metalTone: .7,
				metalLevel: .5,
				sandDecay: .06,
				sandLevel: .55
			},
			euclid: {
				metal: [
					2,
					16,
					4
				],
				sand: [
					2,
					16,
					4
				]
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 1,
				ratio: 2,
				attack: .004,
				release: .25,
				color: 1,
				detectorHp: 1,
				output: 6
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2,
				lfFreq: 60,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 400,
				lmfQ: 1.4,
				hmfGain: 3,
				hmfFreq: 3500,
				hmfQ: .9,
				lpf: 13e3,
				output: 4.5
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: 1,
				c: .5,
				d: .9,
				e: 1,
				bPan: -.3,
				dPan: -.35,
				ePan: .35
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 0,
				attack: 4,
				release: 4,
				scHpf: 2,
				output: 4.5
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...R("performance", "monarch"),
		...R("bubble", "organ"),
		...R("skank", "guitar"),
		...ge([
			[
				"boom",
				"talon",
				"drumEq"
			],
			["orbit"],
			[
				"monarch",
				"brit",
				"bassEq"
			],
			["organ", "organEq"],
			[
				"guitar",
				"console",
				"echo",
				"space"
			]
		], "cohere")
	]);
	if (e === "Dub Session") return L(e, 70, .18, {
		performance: {
			type: "performance",
			steps: P("X..x..x.X.x...x.", F([40, 6], [43, 2], [47, 2], [50, 4], [47, 2]), .95)
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 0,
				osc1Level: .7,
				osc2Wave: 1,
				osc2Octave: 1,
				osc2Detune: 0,
				osc2Level: .3,
				osc3Wave: 0,
				osc3Octave: 2,
				osc3Level: .1,
				cutoff: 600,
				resonance: .1,
				drive: .25,
				envAmount: .1,
				ampAttack: .01,
				ampDecay: .5,
				ampSustain: .8,
				ampRelease: .35,
				glide: .006,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 2,
				lfGain: 2,
				midFreq: 0,
				midGain: -3,
				hfGain: -8,
				drive: 6
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 50,
				output: 3
			}
		},
		skank: {
			type: "performance",
			steps: P("....x.......x...", F([64, 16]), .3)
		},
		guitar: {
			type: "oracle",
			params: {
				bShape: 2,
				bFine: 5,
				cutoff: 2400,
				resonance: .2,
				envAmount: .3,
				filterDecay: .12,
				filterSustain: 0,
				ampAttack: .002,
				ampDecay: .15,
				ampSustain: 0,
				ampRelease: .1,
				chord: 2,
				level: 1
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 300,
				lmfGain: -3,
				lmfFreq: 450,
				hmfGain: 3,
				hmfFreq: 1800,
				lpf: 6e3,
				output: 2
			}
		},
		repeats: {
			type: "delay",
			params: {
				time: Number((60 / 70).toFixed(3)),
				feedback: .6,
				mix: .4
			}
		},
		melody: {
			type: "performance",
			steps: P("X.....X.X.X...X.", [
				71,
				71,
				71,
				71,
				71,
				71,
				74,
				74,
				71,
				71,
				69,
				69,
				69,
				69,
				67,
				67
			], .95)
		},
		melodica: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: 0,
				brightness: .9,
				velocity: .5,
				lfoRate: 5,
				lfoDepth: .12,
				level: 1,
				...pe.reed
			}
		},
		melodicaEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				hmfGain: 1.5,
				hmfFreq: 2500,
				hmfQ: 1,
				lpf: 1e4,
				output: 1.5
			}
		},
		hall: {
			type: "reverb",
			params: {
				decay: 2.2,
				mix: .3
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 40.6,
				kickDecay: .75,
				kickLevel: 1.3,
				snareTone: .35,
				snappy: .5,
				snareLag: 10,
				rimLag: 8,
				hatDecay: .06,
				hatPan: .25,
				hatLag: -5,
				openDecay: .5,
				openPan: .25,
				openLag: -5,
				level: .8
			},
			lanes: {
				kick: "x..x......x.....",
				snare: "....x.......x...",
				rim: ".......x........",
				hat: "x.x.x.x.x.x.x...",
				open: "..............x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 3,
				ratio: 2,
				attack: .003,
				release: .2,
				color: 2,
				output: 8
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 28,
				lfGain: 2,
				lfFreq: 45,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 380,
				lmfQ: 1.4,
				hmfGain: 3,
				hmfFreq: 3500,
				hmfQ: .9,
				lpf: 12e3,
				output: 2
			}
		},
		roomEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lpf: 8e3
			}
		},
		reverb: {
			type: "reverb",
			params: {
				decay: 1.4,
				mix: 1
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .9,
				skinTune: 5,
				skinDecay: .25,
				skinLevel: 1,
				woodLevel: .5
			},
			euclid: {
				skin: [
					1,
					16,
					12
				],
				wood: [
					2,
					16,
					6
				]
			}
		},
		percEq: {
			type: "equalizer",
			params: {
				hpf: 250,
				output: 2
			}
		},
		delay: {
			type: "delay",
			params: {
				time: I(70),
				feedback: .55,
				mix: .45
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: 1,
				c: .7,
				d: 1,
				e: 1,
				f: .35,
				bPan: -.35,
				dPan: .35,
				ePan: -.2
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 0,
				attack: 4,
				release: 4,
				scHpf: 2,
				output: 3
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...R("performance", "monarch"),
		...R("skank", "guitar"),
		...R("melody", "melodica"),
		[
			"drumEq",
			"out2",
			"roomEq",
			"in"
		],
		...ge([
			[
				"boom",
				"talon",
				"drumEq"
			],
			[
				"orbit",
				"percEq",
				"delay"
			],
			[
				"monarch",
				"brit",
				"bassEq"
			],
			[
				"guitar",
				"console",
				"repeats"
			],
			[
				"melodica",
				"melodicaEq",
				"hall"
			],
			["roomEq", "reverb"]
		], "cohere")
	]);
	if (e === "Positive Zions") {
		let t = 3840, n = (e, ...t) => [
			[
				0,
				3,
				116
			],
			[
				3,
				1,
				92
			],
			[
				6,
				2,
				100
			],
			[
				8,
				2,
				108
			],
			[
				10,
				2,
				96
			],
			[
				12,
				2,
				100
			],
			[
				14,
				2,
				104
			]
		].slice(0, t.length).map(([n, r, i], a) => [
			e * 16 + n,
			r,
			t[a],
			i
		]), r = [
			43,
			46,
			50,
			48
		], i = (e, t, n, ...r) => r.map((r) => [
			e,
			t,
			r,
			n
		]), a = [
			[
				62,
				67,
				70
			],
			[
				63,
				67,
				72
			],
			[
				62,
				67,
				70
			],
			[
				62,
				66,
				72
			]
		], o = [
			[
				70,
				74,
				79
			],
			[
				72,
				75,
				79
			],
			[
				70,
				74,
				79
			],
			[
				69,
				72,
				78
			]
		], s = [
			[
				67,
				70,
				74
			],
			[
				67,
				72,
				75
			],
			[
				67,
				70,
				74
			],
			[
				66,
				69,
				72
			]
		];
		return L(e, 74, .1, {
			tune: {
				type: "dictator",
				params: { length: 2 },
				notes: de(...n(0, ...r), ...n(1, 48, 51, 55, 53), ...n(2, ...r), ...n(3, 50, 48, 45, 42, 38, 42, 45))
			},
			bass: {
				type: "monarch",
				params: {
					osc1Wave: 1,
					osc1Level: .75,
					osc2Wave: 1,
					osc2Octave: 1,
					osc2Detune: 0,
					osc2Level: .25,
					osc3Wave: 0,
					osc3Octave: 0,
					osc3Level: .55,
					cutoff: 650,
					resonance: .05,
					drive: .2,
					envAmount: .15,
					filterDecay: .3,
					ampAttack: .006,
					ampDecay: .4,
					ampSustain: .75,
					ampRelease: .1,
					glide: .006,
					level: .8
				}
			},
			bassEq: {
				type: "equalizer",
				params: {
					hpf: 40,
					lfGain: 1.5,
					lfFreq: 90,
					lfBell: 1,
					lmfGain: -4,
					lmfFreq: 260,
					lmfQ: .9,
					hmfGain: 2.5,
					hmfFreq: 900,
					hmfQ: 1,
					lpf: 4500,
					output: 2
				}
			},
			bubble: {
				type: "dictator",
				params: { length: 2 },
				notes: de(...a.flatMap((e, t) => [
					2,
					3,
					6,
					7,
					10,
					11,
					14,
					15
				].flatMap((n) => i(t * 16 + n, 1, n % 4 == 2 ? 84 : 70, ...e))))
			},
			organ: {
				type: "drawbar",
				params: {
					drawbar1: 0,
					drawbar2: 0,
					drawbar3: 8,
					drawbar4: 6,
					drawbar5: 0,
					drawbar6: 3,
					drawbar7: 0,
					drawbar8: 0,
					drawbar9: 0,
					click: .5,
					leakage: .2,
					drive: .2,
					level: .5
				}
			},
			organEq: {
				type: "equalizer",
				params: {
					hpf: 220,
					lmfGain: -3,
					lmfFreq: 380,
					lmfQ: 1,
					hmfGain: 1.5,
					hmfFreq: 2e3,
					hmfQ: 1,
					lpf: 8e3
				}
			},
			skank: {
				type: "dictator",
				params: { length: 2 },
				notes: de(...o.flatMap((e, t) => [...i(t * 16 + 4, 1, 104, ...e), ...i(t * 16 + 12, 1, 100, ...e)]))
			},
			reed: {
				type: "reed",
				params: {
					hardness: .65,
					bark: .55,
					decay: .8,
					damper: .75,
					drive: .3,
					tremDepth: 0,
					speaker: 0,
					level: .75
				}
			},
			reedEq: {
				type: "equalizer",
				params: {
					hpf: 300,
					lmfGain: -3,
					lmfFreq: 500,
					lmfQ: 1.2,
					hmfGain: 3,
					hmfFreq: 2200,
					hmfQ: 1.2,
					lpf: 9e3,
					output: 2
				}
			},
			echo: {
				type: "delay",
				params: {
					time: I(74),
					feedback: .4,
					mix: .28
				}
			},
			strut: {
				type: "strut",
				params: {
					pickupAB: 1,
					pickupCD: 0,
					brilliant: 0,
					treble: 1,
					mute: .55,
					hardness: .6,
					release: .3,
					drive: .15,
					level: 1
				}
			},
			strutEq: {
				type: "equalizer",
				params: {
					hpf: 300,
					lmfGain: -2,
					lmfFreq: 600,
					lmfQ: 1,
					lpf: 1e4,
					output: 3
				}
			},
			chords: {
				type: "dictator",
				params: { length: 2 },
				notes: de(...s.flatMap((e, t) => i(t * 16, 4, 58, ...e))),
				controls: { sustains: [
					0,
					1,
					2,
					3
				].flatMap((e) => [[e * t, 0], [e * t + 120, 127]]) }
			},
			velvet: {
				type: "velvet",
				params: {
					model: 0,
					hardness: .4,
					bark: .25,
					bell: .4,
					decay: 1.2,
					bass: -2,
					treble: 1,
					drive: .15,
					tremRate: 4,
					tremDepth: .45,
					level: .9
				}
			},
			velvetEq: {
				type: "equalizer",
				params: {
					hpf: 300,
					lmfGain: -3,
					lmfFreq: 450,
					lmfQ: 1,
					hfGain: 1.5,
					hfFreq: 9e3,
					output: 2
				}
			},
			space: {
				type: "reverb",
				params: {
					decay: 2.2,
					mix: .3
				}
			},
			answer: {
				type: "dictator",
				params: { length: 2 },
				notes: de([
					10,
					2,
					74,
					92
				], [
					13,
					1,
					77,
					84
				], [
					14,
					2,
					79,
					100
				], [
					26,
					2,
					75,
					92
				], [
					29,
					1,
					74,
					84
				], [
					30,
					2,
					72,
					96
				], [
					42,
					2,
					74,
					92
				], [
					45,
					1,
					77,
					84
				], [
					46,
					4,
					81,
					104
				])
			},
			planet: {
				type: "planet",
				params: {
					model: 0,
					pluck: .6,
					bark: .5,
					decay: 1.1,
					damper: .5,
					drive: .15,
					tone: 1.5,
					level: .7
				}
			},
			planetEq: {
				type: "equalizer",
				params: {
					hpf: 300,
					lmfGain: -2,
					lmfFreq: 500,
					lmfQ: 1,
					hmfGain: 2,
					hmfFreq: 2600,
					hmfQ: 1,
					lpf: 1e4,
					output: 3
				}
			},
			planetEcho: {
				type: "delay",
				params: {
					time: I(74),
					feedback: .42,
					mix: .3
				}
			},
			hall: {
				type: "reverb",
				params: {
					decay: 2.4,
					mix: .25
				}
			},
			boom: {
				type: "boom",
				params: {
					kickTune: 48.3,
					kickDecay: .5,
					kickLevel: 1.3,
					kickLag: 14,
					hatDecay: .04,
					hatLevel: .5,
					hatPan: .25,
					hatLag: -3,
					openDecay: .22,
					openLevel: .7,
					openPan: .25,
					openLag: -3,
					level: .85
				},
				lanes: {
					kick: "x.....x.x.......",
					hat: "x...x...x...x...",
					open: "..x...x...x...x."
				}
			},
			snare: {
				type: "punch",
				params: {
					kickClick: .68,
					kickLevel: 1.23,
					kickLag: 14,
					snareTune: -4,
					snareDecay: .4,
					snareTone: 0,
					snappy: .56,
					snareLag: 6,
					level: .85
				},
				lanes: {
					kick: "x.......x.......",
					snare: "....x.......x...",
					clap: "....x.......x..."
				}
			},
			drums: {
				type: "mixer",
				params: {
					a: 1,
					b: .9
				}
			},
			talon: {
				type: "talon",
				params: {
					input: 2,
					ratio: 2,
					attack: .006,
					release: .2,
					color: 1,
					detectorHp: 1,
					output: 6
				}
			},
			drumEq: {
				type: "equalizer",
				params: {
					hpf: 30,
					lfGain: 2,
					lfFreq: 55,
					lfBell: 1,
					lmfGain: -4,
					lmfFreq: 400,
					lmfQ: 1.4,
					hmfGain: 3,
					hmfFreq: 3500,
					hmfQ: .9,
					lpf: 12e3,
					output: 3
				}
			},
			roomEq: {
				type: "equalizer",
				params: {
					hpf: 300,
					lpf: 5e3
				}
			},
			room: {
				type: "reverb",
				params: {
					decay: 1.6,
					mix: 1
				}
			},
			mixer: {
				type: "mixer",
				params: {
					a: .72,
					b: .66,
					c: .82,
					d: .57,
					e: .78,
					f: .85,
					g: .77,
					h: .3,
					cPan: -.45,
					dPan: -.35,
					ePan: .45,
					fPan: .25,
					gPan: -.2
				}
			},
			cohere: {
				type: "cohere",
				params: {
					threshold: -16,
					ratio: 0,
					attack: 4,
					release: 4,
					scHpf: 2,
					output: 2.5
				}
			},
			output: {
				type: "output",
				params: { volume: .7 }
			}
		}, [
			...R("tune", "bass"),
			...R("bubble", "organ"),
			...R("skank", "reed"),
			...R("skank", "strut", 2),
			...R("chords", "velvet"),
			...R("answer", "planet"),
			[
				"boom",
				"out",
				"drums",
				"a"
			],
			[
				"snare",
				"out",
				"drums",
				"b"
			],
			[
				"drumEq",
				"out2",
				"roomEq",
				"in"
			],
			...ge([
				[
					"drums",
					"talon",
					"drumEq"
				],
				["bass", "bassEq"],
				["organ", "organEq"],
				[
					"reed",
					"reedEq",
					"echo"
				],
				["strut", "strutEq"],
				[
					"velvet",
					"velvetEq",
					"space"
				],
				[
					"planet",
					"planetEq",
					"planetEcho",
					"hall"
				],
				["roomEq", "room"]
			], "cohere")
		]);
	}
	if (e === "Recuerdos") {
		let t = (e) => (t, ...n) => e.map(([e, r, i], a) => [
			t * 16 + e,
			r,
			n[a],
			i
		]), n = t([
			[
				0,
				2,
				116
			],
			[
				3,
				2,
				100
			],
			[
				6,
				3,
				110
			],
			[
				10,
				2,
				96
			],
			[
				12,
				2,
				112
			],
			[
				14,
				2,
				104
			]
		]), r = [
			71,
			71,
			74,
			73,
			71,
			66
		], i = t([
			[
				0,
				3,
				120
			],
			[
				4,
				2,
				100
			],
			[
				6,
				2,
				112
			],
			[
				8,
				3,
				116
			],
			[
				12,
				2,
				100
			],
			[
				14,
				2,
				108
			]
		]), a = (e, ...t) => [
			0,
			4,
			8,
			12
		].flatMap((n) => t.map((t) => [
			e * 16 + n,
			4,
			t,
			n ? 92 : 104
		])), o = (e, ...t) => Array.from({ length: 8 }, (n, r) => [
			e * 16 + r * 2,
			2,
			t[r % 4],
			r % 2 ? 80 : 96
		]);
		return L(e, 94, 0, {
			hook: {
				type: "dictator",
				params: { length: 2 },
				notes: de(...n(0, ...r), ...n(1, 73, 73, 76, 74, 73, 69), ...n(2, ...r), ...n(3, 70, 70, 73, 76, 74, 73))
			},
			lead: {
				type: "monarch",
				params: {
					osc1Wave: 3,
					osc1Level: .7,
					osc2Wave: 2,
					osc2Detune: 11,
					osc2Level: .5,
					osc3Wave: 2,
					osc3Octave: 0,
					osc3Detune: -9,
					osc3Level: .35,
					cutoff: 1500,
					resonance: .4,
					drive: .5,
					envAmount: .5,
					tracking: .6,
					filterAttack: .002,
					filterDecay: .18,
					filterSustain: .35,
					filterRelease: .1,
					ampAttack: .002,
					ampDecay: .3,
					ampSustain: .6,
					ampRelease: .07,
					glide: 0,
					level: .7
				}
			},
			grit: {
				type: "rust",
				params: {
					mode: 0,
					drive: .45,
					bias: .2,
					body: 1e3,
					tone: .5,
					mix: .45,
					level: .6
				}
			},
			leadEq: {
				type: "equalizer",
				params: {
					hpf: 300,
					lmfGain: -3,
					lmfFreq: 520,
					lmfQ: 1,
					hmfGain: 2,
					hmfFreq: 2200,
					hmfQ: 1,
					lpf: 7500,
					output: 2
				}
			},
			echo: {
				type: "delay",
				params: {
					time: I(94),
					feedback: .25,
					mix: .18
				}
			},
			room: {
				type: "reverb",
				params: {
					decay: 1.1,
					mix: .18
				}
			},
			leadR: {
				type: "delay",
				params: {
					time: .02,
					feedback: 0,
					mix: 1
				}
			},
			bassline: {
				type: "dictator",
				params: { length: 2 },
				notes: de(...i(0, 47, 47, 50, 47, 47, 45), ...i(1, 45, 45, 49, 45, 45, 43), ...i(2, 43, 43, 47, 43, 43, 42), ...i(3, 42, 42, 46, 42, 42, 46))
			},
			bass: {
				type: "monarch",
				params: {
					osc1Wave: 2,
					osc1Level: .7,
					osc2Wave: 3,
					osc2Detune: 5,
					osc2Level: .3,
					osc3Wave: 0,
					osc3Octave: 0,
					osc3Detune: 0,
					osc3Level: .45,
					cutoff: 700,
					resonance: .25,
					drive: .35,
					envAmount: .45,
					tracking: .55,
					filterAttack: .002,
					filterDecay: .25,
					filterSustain: .3,
					filterRelease: .1,
					ampAttack: .003,
					ampDecay: .45,
					ampSustain: .75,
					ampRelease: .07,
					glide: .006,
					level: .75
				}
			},
			fuzz: {
				type: "rust",
				params: {
					mode: 0,
					drive: .35,
					bias: .15,
					body: 650,
					tone: .5,
					mix: .25,
					level: .6
				}
			},
			bassEq: {
				type: "equalizer",
				params: {
					hpf: 35,
					lfGain: 1.5,
					lfFreq: 80,
					lfBell: 1,
					lmfGain: -7,
					lmfFreq: 280,
					lmfQ: .8,
					hmfGain: 4.5,
					hmfFreq: 1200,
					hmfQ: 1.1,
					lpf: 6500
				}
			},
			chords: {
				type: "dictator",
				params: {
					length: 2,
					lag: 15
				},
				notes: de(...a(0, 62, 66, 71), ...a(1, 64, 69, 73), ...a(2, 62, 67, 71), ...a(3, 64, 70, 73))
			},
			pad: {
				type: "aurora",
				params: {
					osc1Wave: 0,
					osc2Wave: 0,
					osc2Detune: 10,
					blend: .5,
					hpf: 220,
					cutoff: 1400,
					resonance: .12,
					slope: 1,
					envAmount: .15,
					tracking: .4,
					filterAttack: .08,
					filterDecay: .5,
					filterSustain: .6,
					filterRelease: .3,
					ampAttack: .07,
					ampDecay: .35,
					ampSustain: .55,
					ampRelease: .15,
					lfoRate: .3,
					lfoWidth: .2,
					vintage: .4,
					level: .75
				}
			},
			padEq: {
				type: "equalizer",
				params: {
					hpf: 300,
					lmfGain: -4.5,
					lmfFreq: 400,
					lmfQ: 1.1,
					lpf: 7e3,
					output: 4
				}
			},
			hall: {
				type: "reverb",
				params: {
					decay: 2.2,
					mix: .3
				}
			},
			hallL: {
				type: "delay",
				params: {
					time: .02,
					feedback: 0,
					mix: 1
				}
			},
			perc: {
				type: "strike",
				lanes: {
					cabasa: "xxxxxxxxxxxxxxxx",
					tambourine: "..x...x...x...x.",
					highConga: ".......x.......x",
					lowConga: "..........x....."
				},
				params: {
					level: .54,
					cabasaDecay: .05,
					cabasaLevel: .85,
					cabasaPan: -.6,
					cabasaLag: -3,
					tambourineDecay: .12,
					tambourineLevel: .9,
					tambourinePan: .6,
					highCongaLevel: .7,
					highCongaPan: .55,
					lowCongaLevel: .55,
					lowCongaPan: -.55
				}
			},
			boom: {
				type: "boom",
				lanes: {
					kick: "x...x...x...x...",
					snare: "...x..x....x..x.",
					rim: "...x..x....x..x."
				},
				params: {
					kickTune: 60.8,
					kickDecay: .38,
					kickLevel: 1.45,
					snareTune: 3,
					snareDecay: .14,
					snareTone: .75,
					snappy: .95,
					snareLevel: 1.35,
					snareLag: 3,
					rimLevel: .95,
					rimPan: -.3,
					rimLag: 3,
					level: 1
				}
			},
			strike: {
				type: "strike",
				lanes: {
					snare: "...x..x....x..x.",
					clap: "......x.......x.",
					hat: "x.xxx.x.x.xxx.x."
				},
				params: {
					level: .85,
					snareDecay: .13,
					snareTone: .85,
					snareLevel: .75,
					snareLag: 3,
					clapDecay: .18,
					clapLevel: .75,
					clapPan: .12,
					clapLag: 6,
					hatDecay: .04,
					hatTone: .75,
					hatLevel: .4,
					hatPan: .45,
					hatLag: -3
				}
			},
			drumComp: {
				type: "talon",
				params: {
					input: 5,
					ratio: 3,
					attack: .006,
					release: .1,
					color: 2,
					fierce: 1,
					detectorHp: 1,
					output: 6.5
				}
			},
			drumEq: {
				type: "equalizer",
				params: {
					hpf: 30,
					lfGain: 2.5,
					lfFreq: 62,
					lfBell: 1,
					lmfGain: -4.5,
					lmfFreq: 400,
					lmfQ: 1.4,
					hmfGain: 5,
					hmfFreq: 3800,
					hmfQ: .9,
					lpf: 13e3
				}
			},
			arpeggio: {
				type: "dictator",
				params: { length: 2 },
				notes: de(...o(0, 78, 83, 86, 83), ...o(1, 76, 81, 85, 81), ...o(2, 79, 83, 86, 83), ...o(3, 78, 82, 85, 82))
			},
			kalimba: {
				type: "prism",
				params: {
					algorithm: 0,
					feedback: 0,
					brightness: .8,
					velocity: .6,
					level: 1,
					...pe.kalimba
				}
			},
			kalimbaEq: {
				type: "equalizer",
				params: {
					hpf: 300,
					lmfGain: -2,
					lmfFreq: 600,
					hfGain: 2,
					hfFreq: 9e3,
					lpf: 12e3,
					output: 6
				}
			},
			kalimbaEcho: {
				type: "delay",
				params: {
					time: I(94),
					feedback: .35,
					mix: .3
				}
			},
			kalimbaEchoR: {
				type: "delay",
				params: {
					time: Number((60 / 94).toFixed(3)),
					feedback: .3,
					mix: 1
				}
			},
			mixer: {
				type: "mixer",
				params: {
					a: 1,
					b: .85,
					c: .9,
					d: .335,
					e: .3,
					f: .4,
					g: .33,
					h: .75,
					aPan: 0,
					bPan: 0,
					cPan: .6,
					dPan: -.2,
					ePan: .8,
					fPan: -.7,
					gPan: .7,
					hPan: -.6
				}
			},
			cohere: {
				type: "cohere",
				params: {
					threshold: -16,
					ratio: 0,
					attack: 4,
					release: 4,
					scHpf: 2,
					output: 3
				}
			},
			output: {
				type: "output",
				params: { volume: .7 }
			}
		}, [
			...R("hook", "lead"),
			...R("bassline", "bass"),
			...R("chords", "pad"),
			...R("arpeggio", "kalimba"),
			[
				"perc",
				"out",
				"boom",
				"chain"
			],
			[
				"boom",
				"out",
				"strike",
				"chain"
			],
			[
				"room",
				"out2",
				"leadR",
				"in"
			],
			[
				"kalimbaEq",
				"out2",
				"kalimbaEchoR",
				"in"
			],
			[
				"hall",
				"out2",
				"hallL",
				"in"
			],
			...ge([
				[
					"strike",
					"drumComp",
					"drumEq"
				],
				[
					"bass",
					"fuzz",
					"bassEq"
				],
				[
					"pad",
					"padEq",
					"hall"
				],
				[
					"lead",
					"grit",
					"leadEq",
					"echo",
					"room"
				],
				["leadR"],
				[
					"kalimba",
					"kalimbaEq",
					"kalimbaEcho"
				],
				["kalimbaEchoR"],
				["hallL"]
			], "cohere")
		]);
	}
	return e === "Trap Soul" ? L(e, 68, .06, {
		performance: {
			type: "performance",
			steps: P("X.......X.....x.", F([65, 8], [58, 8]), [
				.95,
				.65,
				.65,
				.65,
				.65,
				.65,
				.65,
				.65,
				.95,
				.65,
				.65,
				.65,
				.65,
				.65,
				.6,
				.65
			])
		},
		oracle: {
			type: "oracle",
			params: {
				aLevel: .7,
				bLevel: .6,
				bFine: 6,
				noise: .03,
				cutoff: 1600,
				resonance: .12,
				envAmount: .3,
				tracking: .4,
				filterAttack: .005,
				filterDecay: .9,
				filterSustain: .25,
				filterRelease: 1.6,
				ampAttack: .01,
				ampDecay: 1.2,
				ampSustain: .6,
				ampRelease: 2.4,
				lfoRate: .35,
				lfoAmount: .12,
				lfoDest: 2,
				vintage: .45,
				chord: 4,
				level: 1
			}
		},
		equalizer: {
			type: "equalizer",
			params: {
				hpf: 280,
				lmfGain: -3,
				lmfFreq: 420,
				lmfQ: 1.2,
				hmfGain: 2,
				hmfFreq: 2800,
				hmfQ: .8,
				hfGain: 3,
				hfFreq: 9e3,
				lpf: 16e3,
				output: 5
			}
		},
		reverb: {
			type: "reverb",
			params: {
				decay: 2.6,
				mix: .3
			}
		},
		performance2: {
			type: "performance",
			steps: P("X.....x.X..x..x.", [
				53,
				53,
				53,
				53,
				53,
				53,
				53,
				53,
				58,
				58,
				58,
				56,
				56,
				56,
				60,
				60
			], [
				.95,
				.65,
				.65,
				.65,
				.65,
				.65,
				.6,
				.65,
				.95,
				.65,
				.65,
				.5,
				.65,
				.65,
				.5,
				.65
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 0,
				osc1Octave: -2,
				osc1Level: .8,
				osc2Wave: 1,
				osc2Octave: -1,
				osc2Detune: 0,
				osc2Level: .2,
				osc3Level: 0,
				cutoff: 1400,
				resonance: 0,
				drive: .55,
				envAmount: .1,
				tracking: .3,
				ampAttack: .003,
				ampDecay: .8,
				ampSustain: .75,
				ampRelease: 1.1,
				glide: .035,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 2,
				midFreq: 1,
				midGain: 4,
				drive: 12,
				output: -2
			}
		},
		subEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lmfGain: -3,
				lmfFreq: 250,
				lmfQ: .8,
				hmfGain: 4,
				hmfFreq: 1200,
				hmfQ: 1,
				lpf: 6e3
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 52,
				kickDecay: .32,
				snareTone: .65,
				snappy: .8,
				hatDecay: .035,
				hatPan: .2,
				openDecay: .3,
				level: .8
			},
			lanes: {
				kick: "x.....x.x.....x.",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "x.x.x.xxx.x.x.xx",
				open: "...........x...."
			}
		},
		compressor: {
			type: "compressor",
			params: {
				input: 3,
				threshold: -26,
				time: 1,
				output: 10
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2.5,
				lfFreq: 60,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 400,
				lmfQ: 1.4,
				hmfGain: 4,
				hmfFreq: 3800,
				hmfQ: .9,
				lpf: 15e3
			}
		},
		bells: {
			type: "performance",
			steps: P("..X...X...X..X..", [
				84,
				84,
				84,
				84,
				84,
				84,
				80,
				80,
				80,
				80,
				82,
				82,
				82,
				77,
				77,
				77
			], .5)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .05,
				brightness: 1,
				velocity: .6,
				level: 1,
				...pe.bell
			}
		},
		bellEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lpf: 12e3
			}
		},
		delay: {
			type: "delay",
			params: {
				time: I(68),
				feedback: .4,
				mix: .3
			}
		},
		echoR: {
			type: "delay",
			params: {
				time: Number((60 / 68).toFixed(3)),
				feedback: .35,
				mix: 1
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: .3,
				c: 1,
				d: .9,
				e: .4,
				aPan: .2,
				bPan: 0,
				cPan: 0,
				dPan: -.35,
				ePan: .7
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -18,
				ratio: 0,
				attack: 4,
				release: 4,
				scHpf: 2,
				output: 4.5
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...R("performance", "oracle"),
		...R("performance2", "monarch"),
		...R("bells", "prism"),
		[
			"bellEq",
			"out2",
			"echoR",
			"in"
		],
		...ge([
			[
				"oracle",
				"equalizer",
				"reverb"
			],
			[
				"monarch",
				"brit",
				"subEq"
			],
			[
				"boom",
				"compressor",
				"drumEq"
			],
			[
				"prism",
				"bellEq",
				"delay"
			],
			["echoR"]
		], "cohere")
	]) : e === "Broken Beat" ? L(e, 108, .1, {
		performance: {
			type: "performance",
			steps: P("X..x..x...x..x.x", [
				36,
				36,
				36,
				48,
				48,
				48,
				46,
				46,
				46,
				46,
				41,
				41,
				41,
				44,
				44,
				43
			], .7)
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Wave: 3,
				osc2Detune: 5,
				osc2Level: .35,
				osc3Wave: 0,
				osc3Level: .45,
				cutoff: 700,
				resonance: .3,
				drive: .3,
				envAmount: .5,
				filterDecay: .16,
				filterSustain: .2,
				ampAttack: .003,
				ampDecay: .25,
				ampSustain: .55,
				ampRelease: .06,
				glide: .006,
				level: .7
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 2,
				lfGain: 2,
				midFreq: 2,
				midGain: 3,
				drive: 8
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 35,
				lfGain: 1,
				lfFreq: 80,
				lfBell: 1,
				lmfGain: -5,
				lmfFreq: 250,
				lmfQ: .8,
				hmfGain: 3.5,
				hmfFreq: 1300,
				hmfQ: 1.1,
				lpf: 7e3
			}
		},
		stabs: {
			type: "performance",
			steps: P("X..x...x..x..x..", F([48, 7], [53, 9]), .4)
		},
		keys: {
			type: "oracle",
			params: {
				aShape: 2,
				bFine: 8,
				cutoff: 1800,
				resonance: .15,
				envAmount: .45,
				filterDecay: .25,
				filterSustain: .2,
				ampAttack: .003,
				ampDecay: .35,
				ampSustain: .3,
				ampRelease: .25,
				chord: 4,
				vintage: .4,
				level: .9
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 200,
				lmfGain: -4.5,
				lmfFreq: 330,
				lmfQ: 1,
				hmfGain: 3,
				hmfFreq: 2800,
				hfGain: 2,
				hfFreq: 9e3,
				output: 3
			}
		},
		echoEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lpf: 9e3
			}
		},
		echo: {
			type: "delay",
			params: {
				time: I(108),
				feedback: .3,
				mix: 1
			}
		},
		punch: {
			type: "punch",
			params: {
				kickTune: 54,
				kickClick: .55,
				kickDecay: .4,
				snareTone: .55,
				snappy: .65,
				snareLag: 6,
				clapLag: 10,
				hatDecay: .04,
				hatPan: .25,
				hatLag: -4,
				openDecay: .2,
				openPan: .25,
				openLag: -4,
				level: .85
			},
			lanes: {
				kick: "x.....x..x...x..",
				snare: "....x.......x...",
				clap: "....x..........x",
				hat: "x.xxx.x.x.xxx.x.",
				open: ".....x.......x.."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .004,
				release: .12,
				color: 2,
				detectorHp: 1,
				output: 6
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2.5,
				lfFreq: 65,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 400,
				lmfQ: 1.4,
				hmfGain: 3.5,
				hmfFreq: 3800,
				hmfQ: .9,
				lpf: 14e3
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .5,
				skinTune: 5,
				tomTune: 7,
				sandLevel: .6
			},
			euclid: {
				skin: [3, 8],
				tom: [
					2,
					16,
					3
				],
				sand: [5, 12]
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .85,
				b: .5,
				c: .8,
				d: .75,
				e: .4,
				aPan: 0,
				bPan: .35,
				cPan: 0,
				dPan: -.3,
				ePan: .65
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 1,
				attack: 4,
				release: 1,
				scHpf: 2,
				output: 3.5
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...R("performance", "monarch"),
		...R("stabs", "keys"),
		[
			"console",
			"out2",
			"echoEq",
			"in"
		],
		...ge([
			[
				"punch",
				"talon",
				"drumEq"
			],
			["orbit"],
			[
				"monarch",
				"brit",
				"bassEq"
			],
			["keys", "console"],
			["echoEq", "echo"]
		], "cohere")
	]) : L(e, 96, .08, {
		performance: {
			type: "performance",
			steps: P("X..X..X.X..X..X.", [
				62,
				62,
				62,
				65,
				65,
				65,
				69,
				69,
				67,
				67,
				67,
				72,
				72,
				72,
				69,
				69
			], .5)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: 0,
				brightness: .9,
				velocity: .6,
				level: 1,
				...pe.kalimba
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 300,
				lmfGain: -2,
				lmfFreq: 450,
				hmfGain: 2.5,
				hmfFreq: 3500,
				hfGain: 3,
				hfFreq: 1e4,
				output: 3
			}
		},
		echo: {
			type: "delay",
			params: {
				time: I(96),
				feedback: .35,
				mix: .25
			}
		},
		echoR: {
			type: "delay",
			params: {
				time: Number((60 / 96).toFixed(3)),
				feedback: .3,
				mix: 1
			}
		},
		bass: {
			type: "performance",
			steps: P("X......o..x.....", F([38, 10], [36, 6]), [
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.6,
				.5,
				.5,
				.95,
				.5,
				.5,
				.5,
				.5,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 0,
				osc1Level: .8,
				osc2Wave: 1,
				osc2Detune: 0,
				osc2Level: .3,
				osc3Level: 0,
				cutoff: 900,
				resonance: 0,
				drive: .3,
				envAmount: .1,
				ampAttack: .006,
				ampDecay: .6,
				ampSustain: .8,
				ampRelease: .2,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 2,
				midFreq: 1,
				midGain: 4,
				drive: 10
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lmfGain: -3,
				lmfFreq: 250,
				lmfQ: .8,
				hmfGain: 4,
				hmfFreq: 1200,
				hmfQ: 1,
				lpf: 6e3
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 44,
				kickDecay: .9,
				level: .85
			},
			lanes: { kick: "x.......x......." }
		},
		talon: {
			type: "talon",
			params: {
				input: 3,
				ratio: 4,
				attack: .002,
				release: .2,
				color: 2,
				output: 4
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2.5,
				lfFreq: 60,
				lfBell: 1,
				lmfGain: -3,
				lmfFreq: 350,
				lmfQ: 1.2,
				hmfGain: 3,
				hmfFreq: 3e3,
				hmfQ: 1,
				lpf: 12e3
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .75,
				woodLevel: .5,
				metalLevel: .35,
				shakerLevel: .45
			},
			euclid: {
				skin: [
					5,
					16,
					2
				],
				wood: [
					3,
					8,
					2
				],
				sand: [7, 12],
				metal: [2, 15],
				shaker: [
					9,
					16,
					2
				],
				tom: [
					3,
					14,
					1
				]
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .95,
				b: .9,
				c: 1,
				d: .6,
				e: .4,
				aPan: 0,
				bPan: 0,
				cPan: -.3,
				dPan: 0,
				ePan: .7
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -18,
				ratio: 0,
				attack: 4,
				release: 4,
				scHpf: 2,
				output: 4
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...R("performance", "prism"),
		...R("bass", "monarch"),
		[
			"console",
			"out2",
			"echoR",
			"in"
		],
		...ge([
			[
				"boom",
				"talon",
				"drumEq"
			],
			["orbit"],
			[
				"prism",
				"console",
				"echo"
			],
			[
				"monarch",
				"brit",
				"bassEq"
			],
			["echoR"]
		], "cohere")
	]);
}
// src/retroPresets.ts
var ve = (...e) => he(e, "mixer", "cohere", "main"), ye = {
	cohere: {
		type: "cohere",
		params: {
			threshold: -16,
			ratio: 0,
			attack: 4,
			release: 4,
			scHpf: 2,
			output: 2
		}
	},
	main: {
		type: "output",
		params: { volume: .7 }
	}
};
function be(e) {
	return e === "Neon Skyline" ? L(e, 112, 0, {
		pads: {
			type: "performance",
			steps: P("X.......X.......", F([57, 8], [52, 8]), .95)
		},
		aurora: {
			type: "aurora",
			params: {
				osc2Wave: 0,
				osc2Detune: 12,
				hpf: 150,
				cutoff: 2400,
				envAmount: .2,
				filterAttack: .1,
				filterDecay: 1.5,
				filterSustain: .5,
				ampAttack: .08,
				ampDecay: 1,
				ampSustain: .8,
				ampRelease: 2.2,
				lfoRate: .4,
				lfoWidth: .3,
				chord: 2,
				vintage: .5,
				level: .8
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 150,
				lmfGain: -6,
				lmfFreq: 300,
				lmfQ: .7,
				hmfGain: 2,
				hmfFreq: 3e3,
				hmfQ: .8,
				hfGain: 3,
				hfFreq: 12e3,
				output: -1
			}
		},
		spaceEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lpf: 1e4
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2.6,
				mix: 1
			}
		},
		bass: {
			type: "performance",
			steps: P("X.x.X.x.X.x.X.x.", F([41, 8], [36, 8]), .55)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .2,
				brightness: 1,
				velocity: .6,
				level: 1,
				...pe.bass
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 2,
				midFreq: 2,
				midGain: 2,
				hfGain: 1,
				drive: 8,
				output: 8
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 35,
				lfGain: 1,
				lfFreq: 80,
				lfBell: 1,
				lmfGain: -4.5,
				lmfFreq: 250,
				lmfQ: .9,
				hmfGain: 3,
				hmfFreq: 1200,
				hmfQ: 1.1,
				lpf: 7e3
			}
		},
		arp: {
			type: "performance",
			steps: P("XxxxXxxxXxxxXxxx", [
				69,
				72,
				76,
				79,
				81,
				79,
				76,
				72,
				67,
				72,
				76,
				79,
				84,
				79,
				76,
				72
			], .5)
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 3,
				osc1Level: .7,
				osc2Detune: 5,
				osc2Level: .4,
				osc3Level: 0,
				cutoff: 2200,
				resonance: .3,
				envAmount: .4,
				filterDecay: .12,
				filterSustain: .1,
				ampAttack: .002,
				ampDecay: .18,
				ampSustain: .2,
				ampRelease: .12,
				level: .55
			}
		},
		arpEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				hmfGain: 1.5,
				hmfFreq: 2500,
				hmfQ: 1,
				lpf: 1e4
			}
		},
		echo: {
			type: "delay",
			params: {
				time: I(112),
				feedback: .35,
				mix: .3
			}
		},
		echoR: {
			type: "delay",
			params: {
				time: Number((60 / 112).toFixed(3)),
				feedback: .3,
				mix: 1
			}
		},
		strike: {
			type: "strike",
			params: {
				level: 1,
				kickTune: .35,
				kickDecay: .4,
				snareTune: -2,
				snareDecay: .3,
				clapLevel: .5,
				hatLevel: .4,
				hatPan: .2,
				tambourineLevel: .3,
				tambourinePan: -.3
			},
			lanes: {
				kick: "x...x...x...x...",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "x.x.x.x.x.x.x.x.",
				tambourine: "....x.......x..."
			}
		},
		drumComp: {
			type: "talon",
			params: {
				input: 3,
				ratio: 3,
				attack: 5e-4,
				release: .1,
				color: 1,
				detectorHp: 1,
				output: 8
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2.5,
				lfFreq: 60,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 400,
				lmfQ: 1.4,
				hmfGain: 3.5,
				hmfFreq: 3800,
				hmfQ: .9,
				lpf: 14e3,
				output: 3
			}
		},
		roomEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lpf: 8e3
			}
		},
		room: {
			type: "reverb",
			params: {
				decay: 1.2,
				mix: 1
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 0,
				ratio: 7,
				attack: 2e-4,
				release: .08,
				color: 2,
				output: 12
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .9,
				b: .8,
				c: .6,
				d: .5,
				e: .4,
				f: .3,
				g: .35,
				aPan: 0,
				bPan: 0,
				cPan: -.3,
				dPan: .3,
				ePan: .4,
				fPan: -.6,
				gPan: 0
			}
		},
		...ye,
		cohere: {
			type: "cohere",
			params: {
				...ye.cohere.params,
				output: 5.5
			}
		}
	}, [
		...R("pads", "aurora"),
		...R("bass", "prism"),
		...R("arp", "monarch"),
		[
			"console",
			"out2",
			"spaceEq",
			"in"
		],
		[
			"arpEq",
			"out2",
			"echoR",
			"in"
		],
		[
			"drumEq",
			"out2",
			"roomEq",
			"in"
		],
		...ve([
			"strike",
			"drumComp",
			"drumEq"
		], [
			"prism",
			"brit",
			"bassEq"
		], ["aurora", "console"], [
			"monarch",
			"arpEq",
			"echo"
		], ["spaceEq", "space"], ["echoR"], [
			"roomEq",
			"room",
			"talon"
		])
	]) : e === "Digital Boogie" ? L(e, 116, .12, {
		bass: {
			type: "performance",
			steps: P("X..x..x.X.xx..x.", [
				40,
				40,
				40,
				52,
				52,
				52,
				40,
				40,
				45,
				45,
				45,
				57,
				57,
				57,
				43,
				43
			], [
				.6,
				.5,
				.5,
				.3,
				.5,
				.5,
				.6,
				.5,
				.6,
				.5,
				.5,
				.3,
				.5,
				.5,
				.6,
				.5
			])
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .3,
				brightness: 1.1,
				velocity: .8,
				level: 1,
				...pe.slap
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 2,
				lfGain: 2,
				midFreq: 3,
				midGain: 3,
				drive: 6,
				output: 8
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 35,
				lfGain: 1,
				lfFreq: 80,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 280,
				lmfQ: .9,
				hmfGain: 2.5,
				hmfFreq: 1300,
				hmfQ: 1.1,
				lpf: 8e3,
				output: 3.5
			}
		},
		stabs: {
			type: "performance",
			steps: P("..X..x....X..x..", F([52, 8], [57, 8]), .6)
		},
		aurora: {
			type: "aurora",
			params: {
				osc2Detune: 8,
				cutoff: 2600,
				envAmount: .4,
				filterDecay: .2,
				filterSustain: .2,
				ampAttack: .003,
				ampDecay: .3,
				ampSustain: .2,
				ampRelease: .2,
				lfoWidth: .2,
				chord: 4,
				vintage: .35,
				level: .6
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 200,
				lmfGain: -4.5,
				lmfFreq: 330,
				lmfQ: 1,
				hmfGain: 3,
				hmfFreq: 2500,
				hmfQ: 1,
				hfGain: 2,
				hfFreq: 1e4,
				output: 3
			}
		},
		roomEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lpf: 9e3
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 1.2,
				mix: 1
			}
		},
		strike: {
			type: "strike",
			params: {
				level: 1,
				kickDecay: .35,
				snareDecay: .25,
				snareLag: 6,
				clapLevel: .6,
				clapLag: 10,
				hatDecay: .05,
				hatLevel: .35,
				hatPan: .25,
				hatLag: -4,
				bellLevel: .35,
				bellPan: -.3
			},
			lanes: {
				kick: "x.....x.x.....x.",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "x".repeat(16),
				bell: "......x.......x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .003,
				release: .1,
				color: 1,
				detectorHp: 1,
				output: 9
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2.5,
				lfFreq: 65,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 400,
				lmfQ: 1.4,
				hmfGain: 3.5,
				hmfFreq: 3800,
				hmfQ: .9,
				lpf: 14e3,
				output: 3
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .9,
				b: .75,
				c: .7,
				d: .4,
				aPan: 0,
				bPan: 0,
				cPan: -.3,
				dPan: .45
			}
		},
		...ye,
		cohere: {
			type: "cohere",
			params: {
				...ye.cohere.params,
				output: 4.5
			}
		}
	}, [
		...R("bass", "prism"),
		...R("stabs", "aurora"),
		[
			"console",
			"out2",
			"roomEq",
			"in"
		],
		...ve([
			"strike",
			"talon",
			"drumEq"
		], [
			"prism",
			"brit",
			"bassEq"
		], ["aurora", "console"], ["roomEq", "space"])
	]) : e === "Midnight Ballad" ? L(e, 76, .04, {
		keys: {
			type: "performance",
			steps: P("X.....x.X.....x.", F([58, 8], [51, 8]), .9)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .08,
				brightness: .75,
				velocity: .75,
				lfoRate: 4.5,
				lfoDepth: .04,
				chord: 3,
				level: .7,
				...pe.epiano
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 150,
				lmfGain: -6,
				lmfFreq: 300,
				lmfQ: .8,
				hmfGain: 2,
				hmfFreq: 2200,
				hmfQ: 1,
				hfGain: 3,
				hfFreq: 11e3,
				output: 6
			}
		},
		echoEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lpf: 9e3
			}
		},
		echo: {
			type: "delay",
			params: {
				time: I(76),
				feedback: .3,
				mix: 1
			}
		},
		strings: {
			type: "performance",
			steps: P("X.......X.......", F([58, 8], [63, 8]), .95)
		},
		aurora: {
			type: "aurora",
			params: {
				osc1Wave: 0,
				osc2Wave: 0,
				osc2Detune: 10,
				hpf: 250,
				cutoff: 2200,
				envAmount: .15,
				filterAttack: .15,
				filterDecay: 1.5,
				filterSustain: .6,
				ampAttack: .12,
				ampDecay: 1.2,
				ampSustain: .8,
				ampRelease: 2.8,
				lfoRate: .3,
				lfoWidth: .3,
				chord: 1,
				vintage: .45,
				level: .8
			}
		},
		stringsEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lmfGain: -4,
				lmfFreq: 500,
				lmfQ: 1,
				hmfGain: 2,
				hmfFreq: 3200,
				hmfQ: 1,
				hfGain: 2.5,
				hfFreq: 1e4,
				lpf: 14e3,
				output: 5
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2.8,
				mix: .4
			}
		},
		bass: {
			type: "performance",
			steps: P("X.....x.X.....x.", F([34, 6], [41, 2], [39, 6], [46, 2]), [
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.8,
				.5,
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.8,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 1,
				osc1Level: .8,
				osc2Wave: 2,
				osc2Detune: 0,
				osc2Level: .15,
				osc3Wave: 0,
				osc3Octave: 0,
				osc3Level: .25,
				cutoff: 850,
				resonance: .15,
				drive: .15,
				envAmount: .25,
				filterDecay: .5,
				filterSustain: .4,
				ampAttack: .015,
				ampDecay: .8,
				ampSustain: .7,
				ampRelease: .3,
				glide: .03,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				midFreq: 1,
				midGain: 2,
				hfGain: -3,
				drive: 4
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 38,
				lfGain: 1,
				lfFreq: 70,
				lfBell: 1,
				lmfGain: -4.5,
				lmfFreq: 220,
				lmfQ: .9,
				hmfGain: 3,
				hmfFreq: 800,
				hmfQ: 1,
				lpf: 4500,
				output: -1
			}
		},
		strike: {
			type: "strike",
			params: {
				level: .9,
				kickDecay: .25,
				kickTone: .55,
				kickLevel: 1.6,
				snareTune: -3,
				snareDecay: .5,
				snareLag: 10,
				hatLevel: .22,
				hatPan: .25,
				hatLag: -4,
				rideLevel: .09,
				rideDecay: .9,
				rideTone: .5,
				ridePan: -.25,
				rideLag: -4
			},
			lanes: {
				kick: "x.......x..x....",
				snare: "....x.......x...",
				hat: "x...x...x...x...",
				ride: "..x...x...x...x."
			}
		},
		drumComp: {
			type: "talon",
			params: {
				input: 0,
				ratio: 1,
				attack: .012,
				release: .15,
				color: 1,
				detectorHp: 1,
				output: 7
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 40,
				lfGain: -3.5,
				lfFreq: 110,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 220,
				lmfQ: .9,
				hmfGain: 1.5,
				hmfFreq: 3500,
				hmfQ: .9,
				lpf: 11e3,
				output: 4.5
			}
		},
		roomEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lpf: 8e3
			}
		},
		room: {
			type: "reverb",
			params: {
				decay: 1.6,
				mix: 1
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 0,
				ratio: 6,
				attack: 5e-4,
				release: .12,
				color: 1,
				output: 8
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .9,
				b: .9,
				c: .6,
				d: .55,
				e: .4,
				f: .28,
				aPan: 0,
				bPan: -.35,
				cPan: .4,
				dPan: 0,
				ePan: .65,
				fPan: 0
			}
		},
		...ye,
		cohere: {
			type: "cohere",
			params: {
				...ye.cohere.params,
				output: 5
			}
		}
	}, [
		...R("keys", "prism"),
		...R("strings", "aurora"),
		...R("bass", "monarch"),
		[
			"console",
			"out2",
			"echoEq",
			"in"
		],
		[
			"drumEq",
			"out2",
			"roomEq",
			"in"
		],
		...ve([
			"strike",
			"drumComp",
			"drumEq"
		], ["prism", "console"], [
			"aurora",
			"stringsEq",
			"space"
		], [
			"monarch",
			"brit",
			"bassEq"
		], ["echoEq", "echo"], [
			"roomEq",
			"room",
			"talon"
		])
	]) : e === "New Wave Motion" ? L(e, 132, 0, {
		bass: {
			type: "performance",
			steps: P("X.x.x.x.X.x.x.x.", [
				38,
				38,
				38,
				38,
				38,
				38,
				50,
				50,
				34,
				34,
				34,
				34,
				34,
				34,
				46,
				46
			], .6)
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Detune: 7,
				osc2Level: .5,
				osc3Wave: 3,
				osc3Octave: 0,
				osc3Level: .35,
				cutoff: 900,
				resonance: .3,
				drive: .35,
				envAmount: .45,
				filterDecay: .15,
				filterSustain: .3,
				ampAttack: .002,
				ampDecay: .15,
				ampSustain: .6,
				ampRelease: .05,
				level: .7
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 2,
				lfGain: 2,
				midFreq: 2,
				midGain: 4,
				hfGain: 2,
				drive: 10
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 35,
				lfGain: 1,
				lfFreq: 80,
				lfBell: 1,
				lmfGain: -4.5,
				lmfFreq: 250,
				lmfQ: .9,
				hmfGain: 3,
				hmfFreq: 1200,
				hmfQ: 1.1,
				lpf: 7e3
			}
		},
		pad: {
			type: "performance",
			steps: P("x.......x.......", F([50, 16]), .95)
		},
		aurora: {
			type: "aurora",
			params: {
				osc1Wave: 1,
				osc1Width: .35,
				osc2Wave: 0,
				osc2Detune: 9,
				hpf: 180,
				cutoff: 2600,
				envAmount: .2,
				filterAttack: .15,
				filterDecay: 1,
				filterSustain: .5,
				ampAttack: .06,
				ampDecay: .8,
				ampSustain: .75,
				ampRelease: 1.6,
				lfoRate: .7,
				lfoWidth: .45,
				chord: 2,
				vintage: .35,
				level: .7
			}
		},
		padEq: {
			type: "equalizer",
			params: {
				hpf: 150,
				lmfGain: -6,
				lmfFreq: 280,
				lmfQ: .7,
				hmfGain: 2.5,
				hmfFreq: 2800,
				hmfQ: .8,
				hfGain: 3,
				hfFreq: 11e3,
				output: 2
			}
		},
		spaceEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lpf: 1e4
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 1.8,
				mix: 1
			}
		},
		hook: {
			type: "performance",
			steps: P("X..X..X...X..X..", [
				81,
				81,
				81,
				77,
				77,
				77,
				74,
				74,
				74,
				74,
				76,
				76,
				76,
				77,
				77,
				77
			], .6)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .05,
				brightness: 1.1,
				velocity: .6,
				level: 1,
				...pe.bell
			}
		},
		hookEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				hmfGain: 1.5,
				hmfFreq: 3e3,
				hmfQ: 1,
				lpf: 12e3
			}
		},
		echo: {
			type: "delay",
			params: {
				time: I(132),
				feedback: .35,
				mix: .25
			}
		},
		echoR: {
			type: "delay",
			params: {
				time: Number((60 / 132).toFixed(3)),
				feedback: .3,
				mix: 1
			}
		},
		strike: {
			type: "strike",
			params: {
				level: 1,
				kickTune: -3.64,
				kickDecay: .35,
				snareDecay: .3,
				hatDecay: .05,
				hatLevel: .4,
				hatPan: .2,
				midTomPan: .3,
				lowTomPan: -.3
			},
			lanes: {
				kick: "x.......x.x.....",
				snare: "....x.......x...",
				hat: "x.x.x.x.x.x.x...",
				midTom: "..............x.",
				lowTom: "...............x"
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 4,
				attack: .002,
				release: .1,
				color: 2,
				detectorHp: 1,
				output: 10
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 3,
				lfFreq: 60,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 380,
				lmfQ: 1.2,
				hmfGain: 3,
				hmfFreq: 4e3,
				hmfQ: 1,
				lpf: 14e3
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: .65,
				c: .55,
				d: .7,
				e: .4,
				f: .3,
				aPan: 0,
				bPan: 0,
				cPan: -.4,
				dPan: .35,
				ePan: .5,
				fPan: -.65
			}
		},
		...ye,
		cohere: {
			type: "cohere",
			params: {
				...ye.cohere.params,
				output: 4
			}
		}
	}, [
		...R("bass", "monarch"),
		...R("pad", "aurora"),
		...R("hook", "prism"),
		[
			"padEq",
			"out2",
			"spaceEq",
			"in"
		],
		[
			"hookEq",
			"out2",
			"echoR",
			"in"
		],
		...ve([
			"strike",
			"talon",
			"console"
		], [
			"monarch",
			"brit",
			"bassEq"
		], ["aurora", "padEq"], [
			"prism",
			"hookEq",
			"echo"
		], ["spaceEq", "space"], ["echoR"])
	]) : e === "Glass Arcade" ? L(e, 108, 0, {
		arp: {
			type: "performance",
			steps: P("XxxxXxxxXxxxXxxx", [
				72,
				76,
				79,
				83,
				84,
				83,
				79,
				76,
				69,
				72,
				76,
				79,
				81,
				79,
				76,
				72
			], .5)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: 0,
				brightness: 1.2,
				velocity: .6,
				level: 1,
				...pe.bell,
				op1Decay: .6,
				op1Release: .4,
				op3Decay: .5,
				op3Release: .3
			}
		},
		arpEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lpf: 12e3
			}
		},
		echo: {
			type: "delay",
			params: {
				time: I(108),
				feedback: .4,
				mix: .3
			}
		},
		echoR: {
			type: "delay",
			params: {
				time: Number((60 / 108).toFixed(3)),
				feedback: .3,
				mix: 1
			}
		},
		melody: {
			type: "performance",
			steps: P("X.x.x...X.x.xx..", [
				76,
				76,
				79,
				79,
				81,
				81,
				79,
				79,
				76,
				76,
				74,
				74,
				72,
				74,
				74,
				74
			], .75)
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 3,
				osc1Level: .8,
				osc2Wave: 3,
				osc2Detune: 6,
				osc2Level: .35,
				osc3Level: 0,
				cutoff: 3200,
				resonance: .15,
				envAmount: .2,
				filterDecay: .2,
				filterSustain: .6,
				ampAttack: .003,
				ampDecay: .2,
				ampSustain: .75,
				ampRelease: .1,
				glide: .006,
				level: .55
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 2,
				midFreq: 3,
				midGain: 3,
				hfGain: 2,
				drive: 4,
				output: 4
			}
		},
		bass: {
			type: "performance",
			steps: P("X.x.X.x.X.x.X.x.", [
				36,
				36,
				48,
				48,
				36,
				36,
				48,
				48,
				33,
				33,
				45,
				45,
				33,
				33,
				45,
				45
			], .55)
		},
		aurora: {
			type: "aurora",
			params: {
				osc1Wave: 1,
				osc1Width: .25,
				osc2Wave: 1,
				osc2Octave: 0,
				osc2Detune: 0,
				osc2Width: .5,
				blend: .4,
				cutoff: 1400,
				resonance: .2,
				envAmount: .4,
				filterDecay: .15,
				filterSustain: .2,
				ampAttack: .002,
				ampDecay: .2,
				ampSustain: .5,
				ampRelease: .06,
				lfoWidth: 0,
				level: 1
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 35,
				lfGain: 1.5,
				lfFreq: 80,
				lfBell: 1,
				lmfGain: -4.5,
				lmfFreq: 250,
				lmfQ: .9,
				hmfGain: 3,
				hmfFreq: 1200,
				hmfQ: 1.1,
				lpf: 7e3
			}
		},
		strike: {
			type: "strike",
			params: {
				level: 1,
				kickTune: .35,
				kickDecay: .3,
				snareDecay: .22,
				hatDecay: .04,
				hatLevel: .3,
				hatPan: .2,
				openLevel: .35,
				openPan: .2
			},
			lanes: {
				kick: "x.....x.x.......",
				snare: "....x.......x...",
				hat: "x.x.x.x.x.x.x...",
				open: "..............x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 3,
				ratio: 3,
				attack: 3e-4,
				release: .1,
				color: 0,
				detectorHp: 1,
				output: 10
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2.5,
				lfFreq: 60,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 400,
				lmfQ: 1.4,
				hmfGain: 3.5,
				hmfFreq: 3800,
				hmfQ: .9,
				lpf: 14e3,
				output: 1
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .9,
				b: 1,
				c: .3,
				d: .85,
				e: .35,
				aPan: 0,
				bPan: .45,
				cPan: -.3,
				dPan: 0,
				ePan: -.65
			}
		},
		...ye,
		cohere: {
			type: "cohere",
			params: {
				...ye.cohere.params,
				output: 6
			}
		}
	}, [
		...R("arp", "prism"),
		...R("melody", "monarch"),
		...R("bass", "aurora"),
		[
			"arpEq",
			"out2",
			"echoR",
			"in"
		],
		...ve([
			"strike",
			"talon",
			"drumEq"
		], [
			"prism",
			"arpEq",
			"echo"
		], ["monarch", "brit"], ["aurora", "console"], ["echoR"])
	]) : L(e, 96, .06, {
		pads: {
			type: "performance",
			steps: P("X.......X.......", F([50, 8], [55, 8]), .95)
		},
		aurora: {
			type: "aurora",
			params: {
				osc1Wave: 0,
				osc2Wave: 2,
				osc2Octave: 1,
				osc2Detune: 6,
				blend: .4,
				hpf: 120,
				cutoff: 2e3,
				envAmount: .15,
				filterAttack: .12,
				filterDecay: 1.5,
				filterSustain: .6,
				ampAttack: .1,
				ampDecay: 1.2,
				ampSustain: .8,
				ampRelease: 2.4,
				lfoRate: .25,
				lfoWidth: .3,
				lfoFilter: .05,
				chord: 3,
				vintage: .4,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 2,
				midFreq: 0,
				midGain: -2,
				hfGain: 5,
				drive: 3
			}
		},
		padEq: {
			type: "equalizer",
			params: {
				lmfGain: -5,
				lmfFreq: 300,
				lmfQ: .7,
				hmfGain: 1.5,
				hmfFreq: 3e3,
				hmfQ: .8,
				output: -1
			}
		},
		spaceEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lpf: 1e4
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2.8,
				mix: 1
			}
		},
		pluck: {
			type: "performance",
			steps: P("X.XX.X.XX.X.XX.X", [
				74,
				74,
				78,
				81,
				81,
				85,
				85,
				81,
				79,
				79,
				83,
				86,
				86,
				83,
				83,
				79
			], .5)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: 0,
				brightness: .9,
				velocity: .6,
				level: 1,
				...pe.pluck,
				op1Level: 1
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 300,
				lmfGain: -2,
				lmfFreq: 450,
				lmfQ: 1,
				hmfGain: 2,
				hmfFreq: 3e3,
				hmfQ: .8,
				hfGain: 3,
				hfFreq: 12e3
			}
		},
		echo: {
			type: "delay",
			params: {
				time: I(96),
				feedback: .45,
				mix: .3
			}
		},
		echoR: {
			type: "delay",
			params: {
				time: Number((60 / 96).toFixed(3)),
				feedback: .3,
				mix: 1
			}
		},
		bass: {
			type: "performance",
			steps: P("X.....x.X.....x.", F([38, 8], [43, 8]), [
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 0,
				osc1Level: .8,
				osc2Wave: 1,
				osc2Octave: 1,
				osc2Detune: 0,
				osc2Level: .25,
				osc3Level: 0,
				cutoff: 400,
				resonance: 0,
				drive: .1,
				envAmount: .1,
				ampAttack: .01,
				ampDecay: .6,
				ampSustain: .8,
				ampRelease: .3,
				glide: .006,
				level: .8
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .9,
				woodTune: 5,
				woodLevel: .45,
				sandLevel: .5,
				sandPan: -.35,
				shakerDecay: .08,
				shakerLevel: .55,
				shakerPan: .35
			},
			euclid: {
				wood: [3, 8],
				sand: [
					5,
					16,
					2
				],
				shaker: [
					8,
					16,
					1
				]
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .7,
				b: 1,
				c: .6,
				d: 1,
				e: .4,
				f: .3,
				aPan: -.3,
				bPan: .3,
				cPan: 0,
				dPan: 0,
				ePan: .4,
				fPan: -.6
			}
		},
		...ye,
		cohere: {
			type: "cohere",
			params: {
				threshold: -14,
				ratio: 0,
				attack: 5,
				release: 4,
				scHpf: 2,
				output: 5
			}
		}
	}, [
		...R("pads", "aurora"),
		...R("pluck", "prism"),
		...R("bass", "monarch"),
		[
			"padEq",
			"out2",
			"spaceEq",
			"in"
		],
		[
			"console",
			"out2",
			"echoR",
			"in"
		],
		...ve([
			"aurora",
			"brit",
			"padEq"
		], [
			"prism",
			"console",
			"echo"
		], ["monarch"], ["orbit"], ["spaceEq", "space"], ["echoR"])
	]);
}
// src/studioPresets.ts
var xe = (...e) => he(e, "sum", "cohere", "main");
function Se(e) {
	return e === "French Touch" ? L(e, 123, .08, {
		seq: {
			type: "performance",
			steps: P("X.xx.x.xX.x.X.xx", [
				33,
				33,
				45,
				33,
				33,
				43,
				43,
				45,
				38,
				38,
				50,
				38,
				48,
				48,
				45,
				43
			], .8)
		},
		stabs: {
			type: "performance",
			steps: P("..X..x.x..X..x..", F([57, 8], [62, 8]), .55)
		},
		bass: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Wave: 3,
				osc2Detune: 5,
				osc2Level: .45,
				osc3Wave: 3,
				osc3Octave: 0,
				osc3Level: .5,
				cutoff: 520,
				resonance: .35,
				drive: .35,
				envAmount: .55,
				tracking: .6,
				filterAttack: .003,
				filterDecay: .16,
				filterSustain: .12,
				filterRelease: .08,
				ampAttack: .003,
				ampDecay: .3,
				ampSustain: .7,
				ampRelease: .06,
				glide: .006,
				level: .75
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 2,
				lfGain: 2.5,
				midFreq: 1,
				midGain: 3,
				drive: 8,
				output: -2
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 1,
				lfFreq: 70,
				lfBell: 1,
				lmfGain: -4.5,
				lmfFreq: 250,
				lmfQ: .9,
				hmfGain: 3,
				hmfFreq: 1200,
				hmfQ: 1.1,
				lpf: 7e3
			}
		},
		keys: {
			type: "aurora",
			params: {
				osc2Wave: 0,
				osc2Detune: 9,
				hpf: 180,
				cutoff: 2200,
				envAmount: .35,
				filterAttack: .002,
				filterDecay: .22,
				filterSustain: .2,
				ampAttack: .004,
				ampDecay: .35,
				ampSustain: .5,
				ampRelease: .22,
				lfoWidth: 0,
				chord: 4,
				vintage: .35,
				level: .75
			}
		},
		sieve: {
			type: "filter",
			params: {
				cutoff: 1100,
				resonance: 4.5
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 150,
				lmfGain: -5,
				lmfFreq: 320,
				lmfQ: .7,
				hmfGain: 3,
				hmfFreq: 2e3,
				hmfQ: 1,
				hfGain: 2,
				hfFreq: 1e4
			}
		},
		sweep: {
			type: "lfo",
			params: {
				wave: 1,
				rate: .12
			}
		},
		echoEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lpf: 1e4
			}
		},
		echo: {
			type: "delay",
			params: {
				time: I(123),
				feedback: .3,
				mix: 1
			}
		},
		drums: {
			type: "punch",
			params: {
				kickTune: 54.3,
				kickClick: .45,
				kickDecay: .5,
				snappy: .6,
				hatDecay: .04,
				hatPan: .25,
				openDecay: .28,
				openPan: .25,
				level: .85
			},
			lanes: {
				kick: "x...x...x...x...",
				clap: "....x.......x...",
				hat: "...x...x...x...x",
				open: "..x...x...x...x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .008,
				release: .12,
				color: 1,
				detectorHp: 1,
				output: 5
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2.5,
				lfFreq: 60,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 400,
				lmfQ: 1.4,
				hmfGain: 3.5,
				hmfFreq: 3800,
				hmfQ: .9,
				lpf: 14e3
			}
		},
		sum: {
			type: "mixer",
			params: {
				a: .8,
				b: .8,
				c: .5,
				d: .22,
				aPan: 0,
				bPan: -.3,
				cPan: 0,
				dPan: .45
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 1,
				attack: 4,
				release: 1,
				scHpf: 2,
				output: 3
			}
		},
		main: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...R("seq", "bass"),
		...R("stabs", "keys"),
		[
			"sweep",
			"out",
			"sieve",
			"cv",
			.8
		],
		[
			"console",
			"out2",
			"echoEq",
			"in"
		],
		...xe([
			"drums",
			"talon",
			"drumEq"
		], [
			"keys",
			"sieve",
			"console"
		], [
			"bass",
			"brit",
			"bassEq"
		], ["echoEq", "echo"])
	]) : e === "Distortion Disco" ? L(e, 116, 0, {
		seq: {
			type: "performance",
			steps: P("Xx.xX.x.Xx.xX.xx", [
				28,
				40,
				40,
				28,
				38,
				38,
				40,
				40,
				31,
				43,
				43,
				31,
				33,
				33,
				35,
				38
			], .8)
		},
		stabs: {
			type: "performance",
			steps: P("..X....x..X..x..", F([64, 8], [57, 8]), .7)
		},
		bass: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Detune: 14,
				osc2Level: .6,
				osc3Wave: 3,
				osc3Octave: 1,
				osc3Level: .3,
				cutoff: 650,
				resonance: .25,
				drive: .6,
				envAmount: .5,
				tracking: .7,
				filterDecay: .2,
				filterSustain: .3,
				ampAttack: .002,
				ampDecay: .2,
				ampSustain: .8,
				ampRelease: .05,
				level: .7
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 2,
				lfGain: 2,
				midFreq: 1,
				midGain: 6,
				hfGain: -4,
				drive: 12,
				output: 1
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 1,
				lfFreq: 70,
				lfBell: 1,
				lmfGain: -5,
				lmfFreq: 250,
				lmfQ: .9,
				hmfGain: 3,
				hmfFreq: 1200,
				hmfQ: 1.1,
				lpf: 6500
			}
		},
		prophet: {
			type: "oracle",
			params: {
				bFine: 10,
				aLevel: .8,
				bLevel: .7,
				cutoff: 1400,
				resonance: .2,
				envAmount: .5,
				filterAttack: .005,
				filterDecay: .3,
				filterSustain: .3,
				filterRelease: .2,
				ampAttack: .004,
				ampDecay: .5,
				ampSustain: .55,
				ampRelease: .25,
				chord: 2,
				vintage: .45,
				level: .9
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 150,
				lmfGain: -5,
				lmfFreq: 350,
				lmfQ: .7,
				hmfGain: 3,
				hmfFreq: 2500,
				hmfQ: 1,
				hfGain: 1.5,
				hfFreq: 9e3,
				lpf: 14e3
			}
		},
		spaceEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lpf: 1e4
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 1.4,
				mix: 1
			}
		},
		drums: {
			type: "strike",
			params: {
				level: .85,
				kickTune: -4.64,
				kickDecay: .35,
				kickLevel: 1,
				snareDecay: .25,
				snareLevel: .85,
				clapLevel: .6,
				hatDecay: .06,
				hatLevel: .5,
				hatPan: -.15,
				openLevel: .45,
				tambourineLevel: .4,
				tambourinePan: .25
			},
			lanes: {
				kick: "x...x...x...x...",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "x.x.x.x.x.x.x...",
				open: "..............x.",
				tambourine: "..x...x...x...x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 8,
				ratio: 6,
				attack: .001,
				release: .1,
				color: 2,
				fierce: 1,
				detectorHp: 1,
				output: 5
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2.5,
				lfFreq: 60,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 400,
				lmfQ: 1.4,
				hmfGain: 3.5,
				hmfFreq: 3800,
				hmfQ: .9,
				lpf: 14e3
			}
		},
		sum: {
			type: "mixer",
			params: {
				a: 1,
				b: .9,
				c: .6,
				d: .2,
				aPan: 0,
				bPan: .3,
				cPan: 0,
				dPan: -.4
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -18,
				ratio: 2,
				attack: 3,
				release: 1,
				scHpf: 2,
				output: 5
			}
		},
		main: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...R("seq", "bass"),
		...R("stabs", "prophet"),
		[
			"console",
			"out2",
			"spaceEq",
			"in"
		],
		...xe([
			"drums",
			"talon",
			"drumEq"
		], ["prophet", "console"], [
			"bass",
			"brit",
			"bassEq"
		], ["spaceEq", "space"])
	]) : e === "Electro Pogo" ? L(e, 128, 0, {
		seq: {
			type: "performance",
			steps: P(".xXx.xXx.xXx.xXx", [
				38,
				38,
				50,
				38,
				38,
				38,
				50,
				38,
				34,
				34,
				46,
				34,
				36,
				36,
				48,
				36
			], .6)
		},
		hook: {
			type: "performance",
			steps: P("X.x.xx.x.X.xX.x.", [
				69,
				69,
				74,
				74,
				77,
				76,
				76,
				74,
				74,
				77,
				77,
				74,
				76,
				76,
				79,
				79
			], .7)
		},
		bass: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Detune: 8,
				osc2Level: .5,
				osc3Wave: 3,
				osc3Level: .45,
				cutoff: 500,
				resonance: .4,
				drive: .55,
				envAmount: .6,
				filterDecay: .12,
				filterSustain: .15,
				ampDecay: .18,
				ampSustain: .6,
				ampRelease: .04,
				level: .7
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2,
				lfFreq: 70,
				lfBell: 1,
				lmfGain: -3,
				lmfFreq: 280,
				lmfQ: 1.2,
				hmfGain: 3,
				hmfFreq: 1200,
				hmfQ: 1.2,
				lpf: 9e3
			}
		},
		lead: {
			type: "oracle",
			params: {
				bOctave: 1,
				bFine: 6,
				bLevel: .5,
				cutoff: 2600,
				resonance: .3,
				envAmount: .35,
				filterDecay: .25,
				filterSustain: .4,
				ampAttack: .003,
				ampDecay: .3,
				ampSustain: .65,
				ampRelease: .15,
				glide: .035,
				level: 1
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 2,
				midFreq: 3,
				midGain: 4,
				hfGain: 4,
				drive: 6,
				output: 6
			}
		},
		echo: {
			type: "delay",
			params: {
				time: I(128),
				feedback: .32,
				mix: .22
			}
		},
		drums: {
			type: "punch",
			params: {
				kickTune: 50,
				kickClick: .7,
				kickDecay: .45,
				snareTone: .6,
				snappy: .8,
				hatDecay: .035,
				openDecay: .2,
				level: .85
			},
			lanes: {
				kick: "x...x...x...x...",
				snare: "....x.......x..x",
				clap: "....x.......x...",
				hat: "xx.xxx.xxx.xxx.x",
				open: "..x...x...x...x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .006,
				release: .09,
				color: 1,
				detectorHp: 1,
				output: 5
			}
		},
		sum: {
			type: "mixer",
			params: {
				a: .8,
				b: .8,
				c: .5
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -14,
				ratio: 1,
				attack: 5,
				release: 4,
				scHpf: 2,
				output: 2
			}
		},
		main: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...R("seq", "bass"),
		...R("hook", "lead"),
		...xe(["drums", "talon"], [
			"lead",
			"brit",
			"echo"
		], ["bass", "console"])
	]) : L(e, 126, 0, {
		seq: {
			type: "performance",
			steps: P("XxxxXxxxXxxxXxxx", [
				36,
				48,
				36,
				48,
				36,
				48,
				36,
				48,
				32,
				44,
				32,
				44,
				34,
				46,
				34,
				46
			], .65)
		},
		hook: {
			type: "performance",
			steps: P("..X..x.x..X..x..", [
				75,
				75,
				75,
				75,
				75,
				74,
				74,
				72,
				72,
				72,
				75,
				75,
				75,
				74,
				74,
				74
			], .8)
		},
		bass: {
			type: "monarch",
			params: {
				osc1Wave: 3,
				osc1Level: .8,
				osc2Detune: -7,
				osc2Level: .5,
				osc3Wave: 3,
				osc3Octave: 0,
				osc3Level: .35,
				cutoff: 420,
				resonance: .75,
				drive: .6,
				envAmount: .7,
				tracking: .6,
				filterAttack: .002,
				filterDecay: .11,
				filterSustain: 0,
				filterRelease: .05,
				ampAttack: .002,
				ampDecay: .15,
				ampSustain: .5,
				ampRelease: .04,
				level: .7
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 35,
				lfGain: 1,
				lfFreq: 70,
				lfBell: 1,
				lmfGain: -4.5,
				lmfFreq: 250,
				lmfQ: .9,
				hmfGain: 3.5,
				hmfFreq: 1500,
				hmfQ: 1.5,
				lpf: 9e3
			}
		},
		fm: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .35,
				brightness: 1,
				velocity: .7,
				lfoRate: 5.5,
				lfoDepth: .12,
				level: .55,
				...fe([
					1,
					0,
					.9,
					.005,
					.8,
					.6,
					.25
				], [
					1,
					0,
					.55,
					.02,
					.4,
					.35,
					.2
				], [
					1,
					9,
					.8,
					.005,
					.8,
					.6,
					.25
				], [
					3,
					0,
					.25,
					.003,
					.25,
					.1,
					.15
				], [
					2,
					-6,
					.35,
					.005,
					.6,
					.4,
					.25
				], [
					1,
					0,
					.35,
					.003,
					.3,
					.15,
					.15
				])
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 2,
				midFreq: 1,
				midGain: 3,
				hfGain: 2,
				drive: 10,
				output: 12
			}
		},
		hookEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lpf: 12e3
			}
		},
		echo: {
			type: "delay",
			params: {
				time: I(126),
				feedback: .38,
				mix: .28
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2.2,
				mix: .22
			}
		},
		drums: {
			type: "boom",
			params: {
				kickTune: 48.6,
				kickDecay: .4,
				snareTone: .6,
				snappy: .75,
				hatDecay: .05,
				hatPan: .25,
				bellPan: -.3,
				level: .85
			},
			lanes: {
				kick: "x...x...x...x...",
				snare: "....x.......x...",
				clap: "....x.......x...",
				rim: "...x.....x...x..",
				hat: "x.x.x.x.x.x.x.x.",
				bell: "..x..x....x..x.."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 4,
				attack: .003,
				release: .15,
				color: 2,
				fierce: 1,
				detectorHp: 1,
				output: 8
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2.5,
				lfFreq: 60,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 400,
				lmfQ: 1.4,
				hmfGain: 3.5,
				hmfFreq: 3800,
				hmfQ: .9,
				lpf: 14e3
			}
		},
		sum: {
			type: "mixer",
			params: {
				a: .8,
				b: .8,
				c: .34,
				aPan: 0,
				bPan: .2,
				cPan: 0
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 1,
				attack: 4,
				release: 1,
				scHpf: 2,
				output: 3
			}
		},
		main: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...R("seq", "bass"),
		...R("hook", "fm"),
		...xe([
			"drums",
			"talon",
			"drumEq"
		], [
			"fm",
			"brit",
			"hookEq",
			"echo",
			"space"
		], ["bass", "console"])
	]);
}
// src/trapPresets.ts
var z = (e, t, n) => ({
	performance: {
		type: "performance",
		steps: e
	},
	oscillator: {
		type: "oscillator",
		params: {
			wave: n.wave,
			octave: n.octave,
			level: 1
		}
	},
	filter: {
		type: "filter",
		params: {
			cutoff: n.cutoff,
			resonance: n.resonance
		}
	},
	amplifier: {
		type: "amplifier",
		params: { level: .8 }
	},
	envelope: {
		type: "envelope",
		params: {
			attack: n.attack,
			decay: n.decay,
			sustain: n.sustain,
			release: n.release
		}
	},
	leadEq: {
		type: "equalizer",
		params: {
			hpf: 300,
			lmfGain: -2,
			lmfFreq: 500,
			lmfQ: 1,
			hmfGain: 2.5,
			hmfFreq: 3e3,
			hmfQ: .9,
			lpf: 12e3
		}
	},
	delay: {
		type: "delay",
		params: {
			time: I(t),
			feedback: .38,
			mix: n.echo
		}
	},
	space: {
		type: "reverb",
		params: {
			decay: 2.6,
			mix: n.space
		}
	},
	echoR: {
		type: "delay",
		params: {
			time: Number((60 / t).toFixed(3)),
			feedback: .35,
			mix: 1
		}
	}
}), Ce = [
	[
		"oscillator",
		"out",
		"filter",
		"in"
	],
	[
		"filter",
		"out",
		"amplifier",
		"in"
	],
	[
		"amplifier",
		"out",
		"leadEq",
		"in"
	],
	[
		"leadEq",
		"out",
		"delay",
		"in"
	],
	[
		"delay",
		"out",
		"space",
		"in"
	],
	[
		"leadEq",
		"out2",
		"echoR",
		"in"
	],
	[
		"performance",
		"pitch",
		"oscillator",
		"pitch"
	],
	[
		"performance",
		"gate",
		"envelope",
		"gate"
	],
	[
		"envelope",
		"out",
		"amplifier",
		"cv",
		1
	]
], we = (e) => ({
	type: "monarch",
	params: {
		osc1Wave: 0,
		osc1Octave: 0,
		osc1Level: .9,
		osc2Wave: 1,
		osc2Octave: 1,
		osc2Detune: 0,
		osc2Level: .15,
		osc3Level: 0,
		cutoff: 1400,
		resonance: 0,
		drive: .5,
		envAmount: .1,
		tracking: .3,
		ampAttack: .003,
		ampDecay: 1.2,
		ampSustain: .7,
		ampRelease: .9,
		glide: .03,
		level: .4,
		...e
	}
}), Te = {
	grit: {
		type: "rust",
		params: {
			mode: 0,
			drive: .45,
			bias: .1,
			body: 500,
			tone: .45,
			mix: .3,
			level: .4
		}
	},
	subEq: {
		type: "equalizer",
		params: {
			hpf: 30,
			lmfGain: -3,
			lmfFreq: 250,
			lmfQ: .8,
			hmfGain: 4,
			hmfFreq: 1200,
			hmfQ: 1,
			lpf: 6e3
		}
	}
}, Ee = (e, t, n = {}) => ({
	type: "skitter",
	lanes: e,
	params: {
		...n,
		...Object.fromEntries(Object.entries(t).flatMap(([e, t]) => Object.entries(t).map(([t, n]) => [`${e}Roll${t}`, ue(n)])))
	}
}), De = (e, t) => ({
	type: "boom",
	lanes: e,
	params: {
		kickTune: 49,
		kickDecay: .55,
		snareTone: .35,
		snappy: .55,
		hatDecay: .045,
		openDecay: .35,
		level: .85,
		...t
	}
}), Oe = {
	type: "talon",
	params: {
		input: 4,
		ratio: 3,
		attack: .008,
		release: .12,
		color: 1,
		detectorHp: 1,
		output: 7
	}
}, ke = {
	cohere: {
		type: "cohere",
		params: {
			threshold: -18,
			ratio: 1,
			attack: 4,
			release: 4,
			scHpf: 2,
			output: 5.5
		}
	},
	output: {
		type: "output",
		params: { volume: .7 }
	}
};
function Ae(e) {
	return e === "High Dive" ? L(e, 76, 0, {
		...z(P("X.x.x..x..x.x...", [
			76,
			76,
			74,
			74,
			72,
			72,
			72,
			69,
			69,
			69,
			72,
			72,
			76,
			76,
			76,
			76
		], [
			.6,
			.6,
			.6,
			.6,
			.8,
			.8,
			.8,
			.9,
			.9,
			.9,
			.6,
			.6,
			.9,
			.9,
			.9,
			.9
		]), 76, {
			wave: 1,
			octave: 0,
			cutoff: 2600,
			resonance: 2,
			attack: .002,
			decay: .5,
			sustain: .15,
			release: .45,
			echo: .3,
			space: .35
		}),
		chords: {
			type: "performance",
			steps: P("X.......X.......", F([60, 8], [65, 8]), .95)
		},
		aurora: {
			type: "aurora",
			params: {
				osc1Wave: 0,
				osc2Wave: 2,
				osc2Detune: 4,
				blend: .45,
				hpf: 250,
				cutoff: 2200,
				resonance: .1,
				envAmount: .15,
				filterAttack: .2,
				filterDecay: 1.4,
				filterSustain: .5,
				ampAttack: .25,
				ampDecay: 1.2,
				ampSustain: .75,
				ampRelease: 1.8,
				lfoRate: .3,
				lfoPitch: 0,
				lfoWidth: .25,
				chord: 1,
				vintage: .3,
				level: .55
			}
		},
		bass: {
			type: "performance",
			steps: P("X.....x...X.....", F([33, 8], [29, 8]), [
				.95,
				.6,
				.6,
				.6,
				.6,
				.6,
				.7,
				.6,
				.6,
				.6,
				.95,
				.6,
				.6,
				.6,
				.6,
				.6
			])
		},
		monarch: we({ level: .3 }),
		...Te,
		skitter: Ee({
			hat: "x.x.x.x.x.x.xx.x",
			open: "..............x."
		}, { hat: { 2: "............xx.x" } }),
		boom: De({
			kick: "x.....x...x.....",
			snare: "....x.......x...",
			clap: "....x.......x..."
		}, {
			kickDecay: .45,
			snareTone: .5,
			snappy: .7
		}),
		console: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2.5,
				lfFreq: 60,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 400,
				lmfQ: 1.4,
				hmfGain: 4,
				hmfFreq: 3800,
				hmfQ: .9,
				hfGain: 1.5,
				hfFreq: 1e4,
				lpf: 15e3,
				output: 3.5
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: .75,
				c: .95,
				d: .8,
				e: .5,
				aPan: 0,
				bPan: 0,
				cPan: -.25,
				dPan: .2,
				ePan: .7
			}
		},
		valve: {
			type: "compressor",
			params: {
				input: 0,
				threshold: -20,
				time: 2,
				output: 2.5
			}
		},
		output: ke.output
	}, [
		...Ce,
		...R("chords", "aurora"),
		...R("bass", "monarch"),
		[
			"skitter",
			"trig",
			"boom",
			"trig"
		],
		...he([
			["boom", "console"],
			[
				"monarch",
				"grit",
				"subEq"
			],
			["space"],
			["aurora"],
			["echoR"]
		], "mixer", "valve", "output")
	]) : e === "Deep End" ? L(e, 64, .04, {
		performance: {
			type: "performance",
			steps: P("..X.......x.x...", F([74, 10], [75, 2], [74, 4]), [
				.9,
				.9,
				.95,
				.9,
				.9,
				.9,
				.9,
				.9,
				.9,
				.9,
				.9,
				.9,
				.95,
				.9,
				.9,
				.9
			])
		},
		lead: {
			type: "monarch",
			params: {
				osc1Wave: 0,
				osc1Octave: 0,
				osc1Level: .8,
				osc2Wave: 1,
				osc2Octave: 0,
				osc2Detune: 7,
				osc2Level: .25,
				osc3Level: 0,
				cutoff: 2800,
				resonance: 0,
				drive: 0,
				envAmount: 0,
				tracking: .5,
				ampAttack: .012,
				ampDecay: 1.2,
				ampSustain: .4,
				ampRelease: 1.4,
				glide: .18,
				level: .75
			}
		},
		leadEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lmfGain: -2,
				lmfFreq: 500,
				lmfQ: 1,
				hmfGain: 2.5,
				hmfFreq: 2800,
				hmfQ: .9,
				lpf: 1e4,
				output: 2
			}
		},
		delay: {
			type: "delay",
			params: {
				time: I(64),
				feedback: .45,
				mix: .32
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 3,
				mix: .42
			}
		},
		echoR: {
			type: "delay",
			params: {
				time: Number((60 / 64).toFixed(3)),
				feedback: .4,
				mix: 1
			}
		},
		bass: {
			type: "performance",
			steps: P("X.........x...x.", F([31, 10], [27, 4], [30, 2]), [
				.95,
				.6,
				.6,
				.6,
				.6,
				.6,
				.6,
				.6,
				.6,
				.6,
				.95,
				.6,
				.6,
				.6,
				.7,
				.6
			])
		},
		monarch: we({
			drive: .6,
			glide: .04,
			ampDecay: 1.6,
			ampRelease: 1.4,
			level: .28
		}),
		...Te,
		skitter: Ee({
			hat: "x.x.x.x.x.x.x.xx",
			perc: "...........x...."
		}, { hat: {
			2: "...............x",
			3: "......x.........",
			4: "..........x.....",
			6: "..............x."
		} }, { rollFade: .4 }),
		boom: De({
			kick: "x.........x.....",
			snare: "....x.......x...",
			clap: "....x.......x..."
		}, {
			kickDecay: .6,
			snareTone: .25,
			snappy: .45
		}),
		drumComp: Oe,
		console: {
			type: "equalizer",
			params: {
				hpf: 35,
				lfGain: 2.5,
				lfFreq: 55,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 350,
				lmfQ: 1.2,
				hmfGain: 3.5,
				hmfFreq: 3500,
				hmfQ: .9,
				lpf: 12e3
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: .75,
				c: 1,
				d: .5,
				aPan: 0,
				bPan: 0,
				cPan: -.2,
				dPan: .7
			}
		},
		valve: {
			type: "compressor",
			params: {
				input: 0,
				threshold: -20,
				time: 2,
				output: 1.8
			}
		},
		output: ke.output
	}, [
		...R("performance", "lead"),
		...R("bass", "monarch"),
		[
			"skitter",
			"trig",
			"boom",
			"trig"
		],
		[
			"leadEq",
			"out2",
			"echoR",
			"in"
		],
		...he([
			[
				"boom",
				"drumComp",
				"console"
			],
			[
				"monarch",
				"grit",
				"subEq"
			],
			[
				"lead",
				"leadEq",
				"delay",
				"space"
			],
			["echoR"]
		], "mixer", "valve", "output")
	]) : L(e, 72, .05, {
		...z(P("X...x.x.X...x...", F([71, 4], [67, 2], [69, 2], [71, 4], [74, 4]), .9), 72, {
			wave: 0,
			octave: 0,
			cutoff: 3200,
			resonance: 1,
			attack: .02,
			decay: .8,
			sustain: .5,
			release: .6,
			echo: .25,
			space: .4
		}),
		chords: {
			type: "performance",
			steps: P("X.....x.X.....x.", F([55, 8], [48, 8]), [
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.7,
				.5,
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.7,
				.5
			])
		},
		oracle: {
			type: "oracle",
			params: {
				aShape: 0,
				aLevel: .6,
				bShape: 1,
				bFine: 4,
				bLevel: .7,
				cutoff: 2600,
				resonance: .1,
				envAmount: .35,
				tracking: .5,
				filterAttack: .002,
				filterDecay: .35,
				filterSustain: .1,
				ampAttack: .003,
				ampDecay: .9,
				ampSustain: .15,
				ampRelease: .8,
				vintage: .35,
				chord: 3,
				level: .75
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 140,
				lmfGain: -4,
				lmfFreq: 320,
				lmfQ: 1.1,
				hmfGain: 2.5,
				hmfFreq: 2500,
				hmfQ: .8,
				hfGain: 2.5,
				hfFreq: 1e4,
				output: 1
			}
		},
		glint: {
			type: "performance",
			steps: P("..x.......x...x.", [
				86,
				86,
				86,
				86,
				86,
				86,
				86,
				86,
				88,
				88,
				88,
				88,
				83,
				83,
				83,
				83
			], .9)
		},
		pluck: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: 0,
				brightness: .7,
				velocity: .5,
				level: 1,
				...pe.pluck
			}
		},
		pluckEq: {
			type: "equalizer",
			params: {
				hpf: 350,
				hmfGain: -2,
				hmfFreq: 4e3,
				hmfQ: 1,
				lpf: 1e4,
				output: 10
			}
		},
		pluckEcho: {
			type: "delay",
			params: {
				time: I(72),
				feedback: .35,
				mix: .35
			}
		},
		bass: {
			type: "performance",
			steps: P("X.......X.......", F([31, 8], [36, 8]), .5)
		},
		monarch: we({
			ampRelease: .6,
			level: .3
		}),
		...Te,
		skitter: Ee({
			hat: "x.xxx.x.x.xxx.x.",
			open: ".......x........",
			synth: "x......x..x...x."
		}, {
			hat: { 3: "...x.......x...." },
			synth: { 2: "..............x." }
		}, { gate: .7 }),
		boom: De({
			kick: "x......x..x.....",
			snare: "....x.......x..."
		}, {
			kickDecay: .5,
			snareTone: .3,
			snappy: .5
		}),
		drumComp: Oe,
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2.5,
				lfFreq: 60,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 400,
				lmfQ: 1.4,
				hmfGain: 3.5,
				hmfFreq: 3500,
				hmfQ: .9,
				lpf: 13e3
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: .62,
				c: .8,
				d: .9,
				e: .45,
				f: .5,
				aPan: 0,
				bPan: 0,
				cPan: -.2,
				dPan: .25,
				ePan: .7,
				fPan: -.5
			}
		},
		...ke
	}, [
		...Ce,
		...R("chords", "oracle"),
		...R("glint", "pluck"),
		[
			"bass",
			"pitch",
			"monarch",
			"pitch"
		],
		[
			"skitter",
			"trig",
			"boom",
			"trig"
		],
		[
			"skitter",
			"gate",
			"monarch",
			"gate"
		],
		...he([
			[
				"boom",
				"drumComp",
				"drumEq"
			],
			[
				"monarch",
				"grit",
				"subEq"
			],
			["space"],
			["oracle", "console"],
			["echoR"],
			[
				"pluck",
				"pluckEq",
				"pluckEcho"
			]
		], "mixer", "cohere", "output")
	]);
}
// src/industrialPresets.ts
var je = (e, t, n, r, i, a) => ({
	[`riff${e}`]: {
		type: "performance",
		steps: t,
		params: { lag: n }
	},
	[`gtr${e}`]: {
		type: "monarch",
		params: r
	},
	[`fuzz${e}`]: {
		type: "rust",
		params: i
	},
	[`eq${e}`]: {
		type: "equalizer",
		params: a
	}
});
function Me(e) {
	if (e === "Rust Machine") return L(e, 93, .08, {
		seq: {
			type: "performance",
			steps: P("X.xX.xx.X.xX.xxo", [
				41,
				41,
				41,
				53,
				53,
				41,
				44,
				44,
				46,
				46,
				46,
				48,
				48,
				51,
				48,
				44
			], [
				.85,
				.7,
				.7,
				.6,
				.7,
				.7,
				.7,
				.7,
				.85,
				.7,
				.7,
				.6,
				.7,
				.7,
				.7,
				.6
			])
		},
		bass: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Wave: 3,
				osc2Detune: 6,
				osc2Level: .4,
				osc3Wave: 0,
				osc3Octave: -1,
				osc3Level: .45,
				cutoff: 480,
				resonance: .6,
				drive: .4,
				envAmount: .7,
				tracking: .5,
				filterAttack: .002,
				filterDecay: .14,
				filterSustain: .12,
				filterRelease: .06,
				ampAttack: .002,
				ampDecay: .25,
				ampSustain: .7,
				ampRelease: .05,
				glide: .006,
				level: .75
			}
		},
		fuzz: {
			type: "rust",
			params: {
				mode: 0,
				drive: .35,
				bias: .15,
				body: 600,
				tone: .5,
				mix: .35,
				level: .6
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 35,
				lfGain: 1.5,
				lfFreq: 80,
				lfBell: 1,
				lmfGain: -6,
				lmfFreq: 250,
				lmfQ: .8,
				hmfGain: 5,
				hmfFreq: 1300,
				hmfQ: 1.1,
				lpf: 7e3
			}
		},
		chops: {
			type: "performance",
			steps: P("..x..X..x..x.X..", F([65, 8], [70, 8]), .25)
		},
		guitar: {
			type: "oracle",
			params: {
				aShape: 1,
				aWidth: .3,
				bShape: 2,
				bFine: 4,
				bLevel: .5,
				cutoff: 3400,
				resonance: .1,
				envAmount: .3,
				filterDecay: .1,
				filterSustain: 0,
				ampAttack: .002,
				ampDecay: .12,
				ampSustain: 0,
				ampRelease: .06,
				chord: 2,
				vintage: .25,
				level: .9
			}
		},
		guitarEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lmfGain: -3,
				lmfFreq: 600,
				lmfQ: 1.2,
				hmfGain: 3,
				hmfFreq: 2500,
				hmfQ: 1,
				hfGain: 2,
				hfFreq: 9e3,
				output: 2
			}
		},
		echo: {
			type: "delay",
			params: {
				time: I(93),
				feedback: .25,
				mix: .18
			}
		},
		echoR: {
			type: "delay",
			params: {
				time: Number((60 / 93).toFixed(3)),
				feedback: .3,
				mix: 1
			}
		},
		pad: {
			type: "performance",
			steps: P("X.......X.......", F([65, 8], [58, 8]), .95)
		},
		aurora: {
			type: "aurora",
			params: {
				osc1Wave: 0,
				osc2Wave: 1,
				osc2Detune: 9,
				blend: .45,
				hpf: 150,
				cutoff: 1400,
				resonance: .15,
				envAmount: .1,
				filterAttack: .4,
				filterDecay: 1.6,
				filterSustain: .6,
				ampAttack: .6,
				ampDecay: 1.5,
				ampSustain: .8,
				ampRelease: 2.4,
				lfoRate: .2,
				lfoWidth: .35,
				lfoFilter: .05,
				chord: 4,
				vintage: .5,
				level: .7
			}
		},
		padEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lmfGain: -3,
				lmfFreq: 450,
				lmfQ: 1,
				hmfGain: 2,
				hmfFreq: 2800,
				hmfQ: 1,
				lpf: 8e3,
				output: 5
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2.6,
				mix: .4
			}
		},
		lead: {
			type: "performance",
			steps: P("X.......x...x...", F([65, 8], [63, 4], [60, 4]), .9)
		},
		power: {
			type: "monarch",
			params: {
				osc1Level: .7,
				osc2Detune: 12,
				osc2Level: .6,
				osc3Wave: 3,
				osc3Octave: -1,
				osc3Level: .25,
				cutoff: 2200,
				resonance: .2,
				drive: .6,
				envAmount: .2,
				filterDecay: .4,
				filterSustain: .6,
				ampAttack: .01,
				ampDecay: .4,
				ampSustain: .8,
				ampRelease: .2,
				glide: .02,
				level: .45
			}
		},
		grind: {
			type: "rust",
			params: {
				mode: 1,
				drive: .6,
				bias: .2,
				starve: .2,
				body: 900,
				tone: .5,
				mix: .85,
				level: .4
			}
		},
		forge: {
			type: "forge",
			params: {
				level: .9,
				drive: .3,
				room: .08,
				kickLevel: 1.2,
				kickDecay: .45,
				kickTone: .7,
				snareLevel: 1.1,
				snareDecay: .3,
				snareTone: .65,
				snareLag: 8,
				hatLevel: .45,
				hatDecay: .05,
				hatPan: .25,
				hatLag: -3,
				openLevel: .4,
				openPan: .25,
				openLag: -3,
				anvilLevel: .3,
				anvilPan: -.4
			},
			lanes: {
				kick: "x.....x...x..x..",
				snare: "....x.......x...",
				hat: "xxxxxxxxxxx.xxxx",
				open: "...........x....",
				anvil: "..............x."
			}
		},
		drumComp: {
			type: "talon",
			params: {
				input: 4,
				ratio: 3,
				attack: .008,
				release: .12,
				color: 1,
				detectorHp: 1,
				output: 5
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 3,
				lfFreq: 65,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 400,
				lmfQ: 1.4,
				hmfGain: 4.5,
				hmfFreq: 3800,
				hmfQ: .9,
				lpf: 14e3
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: .8,
				c: .9,
				d: .9,
				e: .6,
				f: .55,
				aPan: 0,
				bPan: 0,
				cPan: -.5,
				dPan: .4,
				ePan: 0,
				fPan: .75
			}
		},
		valve: {
			type: "compressor",
			params: {
				input: 1,
				threshold: -18,
				time: 1,
				output: 0
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...R("seq", "bass"),
		...R("chops", "guitar"),
		...R("pad", "aurora"),
		...R("lead", "power"),
		[
			"guitarEq",
			"out2",
			"echoR",
			"in"
		],
		...he([
			[
				"forge",
				"drumComp",
				"drumEq"
			],
			[
				"bass",
				"fuzz",
				"bassEq"
			],
			[
				"guitar",
				"guitarEq",
				"echo"
			],
			[
				"aurora",
				"padEq",
				"space"
			],
			["power", "grind"],
			["echoR"]
		], "mixer", "valve", "output")
	]);
	if (e === "Black Mass") {
		let t = P("X.....oxX..xX.x.", [
			37,
			37,
			37,
			37,
			37,
			37,
			37,
			40,
			43,
			43,
			43,
			42,
			38,
			38,
			36,
			36
		], [
			.95,
			.5,
			.5,
			.5,
			.5,
			.5,
			.4,
			.6,
			.95,
			.5,
			.5,
			.6,
			.95,
			.5,
			.8,
			.5
		]), n = {
			osc1Wave: 2,
			osc1Level: .8,
			osc2Wave: 2,
			osc2Level: .6,
			osc3Octave: -1,
			osc3Level: .45,
			cutoff: 1500,
			resonance: .08,
			drive: .7,
			envAmount: .2,
			filterAttack: .003,
			filterDecay: .5,
			filterSustain: .5,
			filterRelease: .6,
			ampAttack: .004,
			ampDecay: .8,
			ampSustain: .7,
			ampRelease: 1.1,
			glide: .04,
			level: .6
		};
		return L(e, 76, .04, {
			...je("L", t, 6, {
				...n,
				osc2Detune: -8,
				osc3Wave: 3
			}, {
				mode: 0,
				drive: .8,
				bias: .25,
				starve: .15,
				body: 200,
				tone: .36,
				mix: 1,
				level: .55
			}, {
				hpf: 105,
				lfGain: 1.5,
				lfFreq: 170,
				lfBell: 1,
				lmfGain: -5.5,
				lmfFreq: 380,
				lmfQ: 1.1,
				hmfGain: 4,
				hmfFreq: 1600,
				hmfQ: 1.1,
				lpf: 6500
			}),
			...je("R", t, 14, {
				...n,
				osc1Detune: -4,
				osc2Wave: 3,
				osc2Detune: 11,
				osc3Wave: 2,
				cutoff: 1350,
				drive: .75,
				glide: .05
			}, {
				mode: 0,
				drive: .78,
				bias: .4,
				starve: .12,
				body: 320,
				tone: .33,
				mix: 1,
				level: .55
			}, {
				hpf: 110,
				lfGain: 1.5,
				lfFreq: 150,
				lfBell: 1,
				lmfGain: -5.5,
				lmfFreq: 330,
				lmfQ: 1.1,
				hmfGain: 4,
				hmfFreq: 2200,
				hmfQ: 1.1,
				lpf: 6e3
			}),
			sub: {
				type: "monarch",
				params: {
					osc1Wave: 0,
					osc1Level: .9,
					osc2Wave: 1,
					osc2Octave: 1,
					osc2Detune: 0,
					osc2Level: .1,
					osc3Level: 0,
					cutoff: 600,
					resonance: 0,
					drive: .5,
					envAmount: .1,
					tracking: .3,
					ampAttack: .004,
					ampDecay: 1.4,
					ampSustain: .75,
					ampRelease: 1,
					glide: .05,
					level: .45
				}
			},
			lead: {
				type: "performance",
				steps: P("....X.......x.x.", F([68, 12], [69, 2], [67, 2]), .95)
			},
			voice: {
				type: "monarch",
				params: {
					osc1Wave: 0,
					osc1Level: .8,
					osc2Wave: 2,
					osc2Detune: 7,
					osc2Level: .15,
					osc3Level: 0,
					cutoff: 1800,
					resonance: 0,
					drive: 0,
					envAmount: 0,
					tracking: .5,
					ampAttack: .03,
					ampDecay: 1.4,
					ampSustain: .45,
					ampRelease: 1.8,
					glide: .22,
					level: 1
				}
			},
			voiceEq: {
				type: "equalizer",
				params: {
					hpf: 300,
					lmfGain: -2,
					lmfFreq: 500,
					lmfQ: 1,
					hmfGain: 2,
					hmfFreq: 2500,
					hmfQ: 1,
					lpf: 9e3,
					output: 4
				}
			},
			echo: {
				type: "delay",
				params: {
					time: I(76),
					feedback: .5,
					mix: .32
				}
			},
			space: {
				type: "reverb",
				params: {
					decay: 3,
					mix: .45
				}
			},
			echoR: {
				type: "delay",
				params: {
					time: Number((60 / 76).toFixed(3)),
					feedback: .42,
					mix: 1
				}
			},
			boom: {
				type: "boom",
				lanes: {
					kick: "x.......x.x....x",
					snare: "....x.......x...",
					clap: "....x.......x..."
				},
				params: {
					kickTune: 44,
					kickDecay: .7,
					kickLevel: 1.6,
					snareTune: -5,
					snareDecay: .45,
					snareTone: .6,
					snappy: .9,
					snareLevel: 1.6,
					snarePan: .1,
					snareLag: 12,
					clapTone: .55,
					clapDecay: .45,
					clapLevel: 1.4,
					clapPan: -.1,
					clapLag: 17,
					level: 1
				}
			},
			forge: {
				type: "forge",
				params: {
					level: 1,
					drive: .55,
					room: .5,
					kickTune: -1,
					kickDecay: .6,
					kickTone: .7,
					kickLevel: 1.6,
					snareTune: -4,
					snareDecay: .9,
					snareTone: .85,
					snareLevel: 1.6,
					snareLag: 12,
					hatLevel: .35,
					hatDecay: .06,
					hatTone: .4,
					hatPan: .3,
					hatLag: -6,
					lowTomTune: -5,
					lowTomDecay: 1.2,
					lowTomLevel: 1.3,
					lowTomPan: .4,
					lowTomLag: 8,
					anvilTune: -10,
					anvilDecay: 2.5,
					anvilTone: .35,
					anvilLevel: .35,
					anvilPan: -.55,
					anvilLag: 20
				},
				lanes: {
					kick: "x.......x.x....x",
					snare: "....x.......x...",
					hat: "x.xxx.xxx.xxx.xx",
					lowTom: "......x.......x.",
					anvil: "...........x...."
				}
			},
			drumComp: {
				type: "talon",
				params: {
					input: 4,
					ratio: 4,
					attack: .01,
					release: .15,
					color: 2,
					detectorHp: 1,
					output: 7.5
				}
			},
			drumEq: {
				type: "equalizer",
				params: {
					hpf: 30,
					lfGain: 3.5,
					lfFreq: 68,
					lfBell: 1,
					lmfGain: -4.5,
					lmfFreq: 380,
					lmfQ: 1.4,
					hmfGain: 5.5,
					hmfFreq: 3400,
					hmfQ: .9,
					lpf: 13e3
				}
			},
			mixer: {
				type: "mixer",
				params: {
					a: 1,
					b: .72,
					c: .72,
					d: .6,
					e: 1,
					f: .75,
					aPan: 0,
					bPan: -.9,
					cPan: .9,
					dPan: 0,
					ePan: -.15,
					fPan: .75
				}
			},
			valve: {
				type: "compressor",
				params: {
					input: 0,
					threshold: -18,
					time: 2,
					output: -3.2
				}
			},
			output: {
				type: "output",
				params: { volume: .7 }
			}
		}, [
			...R("riffL", "gtrL"),
			...R("riffR", "gtrR"),
			...R("riffL", "sub", 2),
			...R("lead", "voice"),
			[
				"voiceEq",
				"out2",
				"echoR",
				"in"
			],
			[
				"boom",
				"out",
				"forge",
				"chain"
			],
			...he([
				[
					"forge",
					"drumComp",
					"drumEq"
				],
				[
					"gtrL",
					"fuzzL",
					"eqL"
				],
				[
					"gtrR",
					"fuzzR",
					"eqR"
				],
				["sub"],
				[
					"voice",
					"voiceEq",
					"echo",
					"space"
				],
				["echoR"]
			], "mixer", "valve", "output")
		]);
	}
	let t = (e, ...t) => [
		[
			0,
			3,
			120
		],
		[
			3,
			1,
			96
		],
		[
			6,
			1,
			100
		],
		[
			7,
			3,
			116
		],
		[
			10,
			2,
			104
		],
		[
			12,
			2,
			100
		],
		[
			14,
			2,
			108
		]
	].map(([n, r, i], a) => [
		e * 16 + n,
		r,
		t[a],
		i
	]), n = [
		41,
		44,
		48,
		46,
		44,
		43,
		44
	], r = (e, t, ...n) => n.map((n) => [
		e,
		t,
		n,
		100
	]);
	return L(e, 92, .12, {
		tune: {
			type: "dictator",
			params: { length: 2 },
			notes: de(...t(0, ...n), ...t(1, 37, 49, 48, 44, 41, 39, 41), ...t(2, ...n), ...t(3, 39, 46, 49, 48, 46, 43, 40))
		},
		bass: {
			type: "monarch",
			params: {
				osc1Wave: 2,
				osc1Level: .75,
				osc2Wave: 3,
				osc2Detune: 5,
				osc2Level: .35,
				osc3Wave: 0,
				osc3Octave: -1,
				osc3Level: .35,
				cutoff: 750,
				resonance: .3,
				drive: .35,
				envAmount: .45,
				tracking: .6,
				filterAttack: .002,
				filterDecay: .3,
				filterSustain: .3,
				filterRelease: .12,
				ampAttack: .003,
				ampDecay: .5,
				ampSustain: .8,
				ampRelease: .07,
				glide: .006,
				level: .75
			}
		},
		fuzz: {
			type: "rust",
			params: {
				mode: 0,
				drive: .4,
				bias: .2,
				body: 700,
				tone: .5,
				mix: .35,
				level: .6
			}
		},
		bassEq: {
			type: "equalizer",
			params: {
				hpf: 35,
				lfGain: 1.5,
				lfFreq: 80,
				lfBell: 1,
				lmfGain: -6,
				lmfFreq: 250,
				lmfQ: .8,
				hmfGain: 5,
				hmfFreq: 1300,
				hmfQ: 1.1,
				lpf: 7e3
			}
		},
		chords: {
			type: "dictator",
			params: { length: 2 },
			notes: de(...r(0, 16, 65, 68, 72), ...r(16, 16, 65, 68, 73), ...r(32, 16, 65, 68, 72), ...r(48, 12, 63, 67, 70), ...r(60, 4, 64, 67, 72))
		},
		pad: {
			type: "aurora",
			params: {
				osc1Wave: 0,
				osc2Wave: 1,
				osc2Width: .35,
				osc2Detune: 9,
				blend: .5,
				hpf: 220,
				cutoff: 2e3,
				resonance: .1,
				slope: 1,
				envAmount: .2,
				filterAttack: .05,
				filterDecay: 1.2,
				filterSustain: .5,
				filterRelease: 1.2,
				ampAttack: .06,
				ampDecay: 1.5,
				ampSustain: .7,
				ampRelease: 1.4,
				lfoRate: .4,
				lfoWidth: .25,
				vintage: .3,
				level: .8
			}
		},
		padEq: {
			type: "equalizer",
			params: {
				hpf: 300,
				lmfGain: -3,
				lmfFreq: 450,
				lmfQ: 1,
				hmfGain: 3,
				hmfFreq: 2800,
				hmfQ: 1,
				lpf: 8e3
			}
		},
		hall: {
			type: "reverb",
			params: {
				decay: 2.6,
				mix: .4
			}
		},
		answer: {
			type: "dictator",
			params: {
				length: 2,
				lag: 6
			},
			notes: de([
				8,
				2,
				72,
				96
			], [
				11,
				4,
				75,
				104
			], [
				24,
				2,
				72,
				96
			], [
				27,
				4,
				77,
				104
			], [
				40,
				2,
				72,
				96
			], [
				43,
				4,
				79,
				108
			], [
				56,
				2,
				70,
				96
			], [
				59,
				4,
				67,
				100
			])
		},
		keys: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .05,
				brightness: 1.1,
				velocity: .5,
				lfoRate: 4.5,
				lfoDepth: .02,
				level: 1,
				...pe.epiano
			}
		},
		keysEq: {
			type: "equalizer",
			params: {
				output: 8,
				hpf: 300,
				lmfGain: -2,
				lmfFreq: 500,
				lmfQ: 1,
				hmfGain: 3,
				hmfFreq: 3e3,
				hmfQ: .9,
				lpf: 12e3
			}
		},
		echo: {
			type: "delay",
			params: {
				time: I(92),
				feedback: .42,
				mix: .35
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 3,
				mix: .4
			}
		},
		echoR: {
			type: "delay",
			params: {
				time: Number((60 / 92).toFixed(3)),
				feedback: .38,
				mix: 1
			}
		},
		boom: {
			type: "boom",
			lanes: {
				kick: "x......x..x...x.",
				snare: "....x.......x...",
				clap: "....x.......x...",
				rim: "......x........x"
			},
			params: {
				kickTune: 44,
				kickDecay: .5,
				kickLevel: 1.4,
				snareTune: -2,
				snareDecay: .35,
				snareTone: .65,
				snappy: .9,
				snareLevel: 1.5,
				snarePan: .1,
				snareLag: 14,
				clapTone: .6,
				clapDecay: .35,
				clapLevel: 1.4,
				clapPan: -.12,
				clapLag: 19,
				rimLevel: .5,
				rimPan: -.5,
				rimLag: 10,
				level: 1
			}
		},
		forge: {
			type: "forge",
			params: {
				level: 1,
				drive: .4,
				room: .3,
				kickTune: 0,
				kickDecay: .5,
				kickTone: .7,
				kickLevel: 1.6,
				snareTune: -1,
				snareDecay: .6,
				snareTone: .8,
				snareLevel: 1.6,
				snareLag: 14,
				hatLevel: .45,
				hatDecay: .05,
				hatTone: .5,
				hatPan: .4,
				hatLag: -6
			},
			lanes: {
				kick: "x......x..x...x.",
				snare: "....x.......x...",
				hat: "x.x.x.xxx.x.x.xx"
			}
		},
		drumComp: {
			type: "talon",
			params: {
				input: 4,
				ratio: 3,
				attack: .008,
				release: .12,
				color: 1,
				fierce: 1,
				detectorHp: 1,
				output: 7.5
			}
		},
		drumEq: {
			type: "equalizer",
			params: {
				hpf: 30,
				lfGain: 2.5,
				lfFreq: 70,
				lfBell: 1,
				lmfGain: -4,
				lmfFreq: 400,
				lmfQ: 1.4,
				hmfGain: 5,
				hmfFreq: 3800,
				hmfQ: .9,
				lpf: 14e3
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: .85,
				c: .85,
				d: 1,
				e: .8,
				aPan: 0,
				bPan: 0,
				cPan: 0,
				dPan: -.35,
				ePan: .7
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 0,
				attack: 4,
				release: 4,
				scHpf: 2,
				output: 1.5
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...R("tune", "bass"),
		...R("chords", "pad"),
		...R("answer", "keys"),
		[
			"keysEq",
			"out2",
			"echoR",
			"in"
		],
		[
			"boom",
			"out",
			"forge",
			"chain"
		],
		...he([
			[
				"forge",
				"drumComp",
				"drumEq"
			],
			[
				"bass",
				"fuzz",
				"bassEq"
			],
			[
				"pad",
				"padEq",
				"hall"
			],
			[
				"keys",
				"keysEq",
				"echo",
				"space"
			],
			["echoR"]
		], "mixer", "cohere", "output")
	]);
}
// src/wheels.ts
var B = [
	"bend",
	"mod",
	"sustain",
	"expression"
], Ne = (e) => e !== "bend" && e !== "mod", Pe = {
	bend: {
		min: -8192,
		max: 8191,
		rest: 0,
		cc: null,
		lane: "bends",
		tab: "PITCH",
		name: "pitch bend"
	},
	mod: {
		min: 0,
		max: 127,
		rest: 0,
		cc: 1,
		lane: "mods",
		tab: "MOD",
		name: "mod wheel"
	},
	sustain: {
		min: 0,
		max: 127,
		rest: 0,
		cc: 64,
		lane: "sustains",
		tab: "SUS",
		name: "sustain pedal"
	},
	expression: {
		min: 0,
		max: 127,
		rest: 127,
		cc: 11,
		lane: "expressions",
		tab: "SWELL",
		name: "swell pedal"
	}
}, Fe = Object.fromEntries(B.map((e) => [e, Pe[e].lane])), Ie = new Map(B.flatMap((e) => Pe[e].cc === null ? [] : [[Pe[e].cc, e]])), Le = 4096, Re = 16384;
function ze(e, t) {
	let { min: n, max: r } = Pe[e];
	return Math.max(n, Math.min(r, Math.round(t)));
}
function Be(e, t) {
	let n = ze(e, t);
	return e === "bend" ? n < 0 ? n / 8192 : n / 8191 : n / 127;
}
var Ve = (e, t) => ze(e, e === "bend" ? t < 0 ? t * 8192 : t * 8191 : t * 127), He = (e) => e.length < 2 ? e.join("") : `${e.slice(0, -1).join(", ")} and ${e.at(-1)}`, Ue = (e) => Be(e, Pe[e].rest);
function We(e) {
	let t = /* @__PURE__ */ new Map();
	for (let [n, r] of e) t.delete(n), t.set(n, r);
	return [...t].sort((e, t) => e[0] - t[0]);
}
function Ge(e) {
	return e.filter((t, n) => n === 0 || t[1] !== e[n - 1][1]);
}
function Ke(e, t) {
	let n = 0, r = e.length;
	for (; n < r;) {
		let i = n + r >> 1;
		e[i][0] < t ? n = i + 1 : r = i;
	}
	return n;
}
var qe = (e, t, n) => e.slice(Ke(e, t), Ke(e, n));
function Je(e, t, n) {
	let r = Ke(e, n);
	if (!r) return null;
	let i = Ke(e, Math.floor(t) + 1);
	return e[(i ? Math.min(i, r) : r) - 1][1];
}
function Ye(e, t, n, r, i, a) {
	let o = Math.min(n, i), s = Je(e, o >= i ? 0 : o, i) ?? a, c = e.filter(([e]) => e < t || e >= o), l = r.filter(([e]) => e >= t && e < o), u = o >= i ? 0 : o, d = s === null || [...c, ...l].some(([e]) => e === u) ? [] : [[u, s]];
	return Ge(We([
		...c,
		...l,
		...d
	]));
}
var Xe = (e, t, n) => Ge(e.filter(([e]) => e < t || e >= n));
function Ze(e, t, n, r) {
	let [i, a] = t[0] <= n[0] ? [t, n] : [n, t], o = [];
	for (let t = Math.floor(i[0] / r) * r; t <= a[0]; t += r) {
		let n = a[0] === i[0] ? 1 : Math.max(0, Math.min(1, (t - i[0]) / (a[0] - i[0])));
		o.push([t, ze(e, i[1] + (a[1] - i[1]) * n)]);
	}
	return o;
}
function Qe(e, t) {
	let n = Ke(e, Math.floor(t) + 1);
	return e[Math.max(0, n - 1)][1];
}
function $e(e, t, n) {
	let r = [...e];
	for (let e of t) {
		if (!e.length) continue;
		let t = e.at(-1)[0] + 1;
		for (let i = Math.max(e[0][0], t - n); i < t;) {
			let a = (i % n + n) % n, o = Math.min(t, i + n - a), s = a + o - i, c = [[a, Qe(e, i)], ...qe(e, i + 1, o).map(([e, t]) => [a + e - i, t])];
			r = Ye(r, a, s, c, n, null), i = o;
		}
	}
	return r;
}
function et(e, t, n) {
	return e.flatMap((e) => {
		if (!e.length || e.at(-1)[0] < t || e[0][0] >= n) return [];
		let r = qe(e, t, n);
		return [e[0][0] < t ? [[t, Qe(e, t)], ...r] : r];
	});
}
function tt(e, t) {
	let n = e.at(-1);
	return n ? t[0] - n[0] < 15 && e.length > 1 ? e[e.length - 2][1] === t[1] ? e.slice(0, -1) : [...e.slice(0, -1), [n[0], t[1]]] : n[1] === t[1] ? [...e] : [...e, [Math.max(t[0], n[0]), t[1]]] : [t];
}
function nt(e, t) {
	let n = Ge(We(e));
	for (let e = 30; n.length > t && e <= v; e *= 2) n = Ge(We(n.map(([t, n]) => [Math.floor(t / e) * e, n])));
	return n.slice(0, t);
}
function rt(e, t) {
	let n = Je(e, 0, t), r = qe(e, 0, t);
	return n === null ? [] : Ge(We([[0, n], ...r]));
}
function it(e, t, n) {
	let r = Pe[e].rest, i = qe(We(t), 0, n).map(([t, n]) => [t, ze(e, n)]);
	return i.some(([, e]) => e !== r) ? Ge(We([[0, r], ...i])) : [];
}
// src/model.ts
var V = (e, t, n, r, i, a = .01, o, s = !1) => ({
	id: e,
	label: t,
	min: n,
	max: r,
	initial: i,
	step: a,
	unit: o,
	logarithmic: s
}), H = (e, t, n, r) => ({
	id: e,
	label: t,
	choices: n,
	initial: r,
	min: 0,
	max: n.length - 1,
	step: 1
}), U = (e, t, n = "audio", r) => ({
	id: e,
	label: t,
	kind: n,
	direction: "in",
	scale: r
}), W = (e, t, n = "audio") => ({
	id: e,
	label: t,
	kind: n,
	direction: "out"
}), G = (e, t = 2) => Array.from({ length: t }, (t, n) => n ? {
	...e,
	id: `${e.id}${n + 1}`,
	copyOf: e.id
} : e), K = (e) => ({
	...e,
	legacyDefault: e.initial
}), at = (e) => ({
	...K(V(e, "Lag", -50, 50, 0, 1, "ms")),
	hint: "Plays these notes up to 50 ms late, or early when negative, to push or pull the part against the beat. You hear it against the click or the other parts, not on its own. Double-click puts it back on the beat."
}), q = (e, t) => ({
	...e,
	hint: t
}), ot = (e, t) => K(V("bendRange", "Bend", e, 12, t, 1, "st")), st = ["filterModel", "engine"], ct = (e) => K(H(e, "Engine", ["Digital", "Analog"], 1)), J = (e, t) => ({
	id: `${e}Pattern`,
	label: "Pattern",
	min: 0,
	max: 65535,
	step: 1,
	initial: [...t].reduce((e, t, n) => t === "x" ? e | 1 << n : e, 0),
	pattern: !0,
	voice: e
}), lt = (e, t, n, r, i) => [
	{
		...V(`${e}Steps`, `${t} steps`, 1, 16, n, 1),
		voice: e
	},
	{
		...V(`${e}Hits`, `${t} hits`, 0, 16, r, 1),
		voice: e
	},
	{
		...V(`${e}Shift`, `${t} shift`, 0, 15, i, 1),
		voice: e
	}
], ut = [
	"Skin",
	"Wood",
	"Sand",
	"Metal",
	"Shaker",
	"Tom"
].map((e) => ({
	id: e.toLowerCase(),
	label: e
})), dt = ({ id: e, label: t }, n) => {
	let [r, i, a] = [
		[
			16,
			5,
			2
		],
		[
			8,
			3,
			0
		],
		[
			12,
			8,
			0
		],
		[
			16,
			0,
			0
		],
		[
			16,
			0,
			0
		],
		[
			16,
			0,
			0
		]
	][n], o = (t) => ({
		...K(t),
		voice: e
	});
	return [
		...lt(e, t, r, i, a).map((e) => n > 2 ? o(e) : e),
		o(V(`${e}Tune`, `${t} tune`, -24, 24, 0, 1, "st")),
		o(V(`${e}Decay`, `${t} decay`, .02, 2, [
			.32,
			.07,
			.07,
			.5,
			.12,
			.4
		][n], .01, "s", !0)),
		o(V(`${e}Tone`, `${t} tone`, 0, 1, .5)),
		o(V(`${e}Level`, `${t} level`, 0, 2, 1)),
		o(V(`${e}Pan`, `${t} pan`, -1, 1, 0)),
		o({
			...at(`${e}Lag`),
			label: `${t} lag`
		}),
		o(H(`${e}Custom`, `${t} rhythm`, ["Euclidean", "Custom"], 0)),
		o(J(e, "................"))
	];
}, ft = (e, t) => [
	V(`${e}Attack`, "Attack", .002, 2, .008, .001, "s", !0),
	V(`${e}Decay`, "Decay", .01, 3, .25, .01, "s", !0),
	V(`${e}Sustain`, "Sustain", 0, 1, e === "amp" ? .65 : .2),
	V(`${e}Release`, "Release", .01, 4, .2, .01, "s", !0)
].map((e) => ({
	...e,
	group: t
})), pt = [
	U("chain", "Chain in"),
	U("trig", "Trig in", "gate"),
	...G(W("out", "Drums out"))
], Y = (e, t) => t.map((t) => ({
	...t,
	group: e
})), mt = [
	["Off", [0]],
	["Maj 7", [
		0,
		4,
		7,
		11
	]],
	["Min 7", [
		0,
		3,
		7,
		10
	]],
	["Maj 9", [
		0,
		4,
		7,
		11,
		14
	]],
	["Min 9", [
		0,
		3,
		7,
		10,
		14
	]],
	["Min 11", [
		0,
		3,
		10,
		14,
		17
	]],
	["Dom 9", [
		0,
		4,
		7,
		10,
		14
	]]
], X = [
	["kick", "Kick"],
	["snare", "Snare"],
	["rim", "Sidestick"],
	["clap", "Clap"],
	["hat", "Closed hat"],
	["open", "Open hat"],
	["lowTom", "Low tom"],
	["midTom", "Mid tom"],
	["highTom", "High tom"],
	["lowConga", "Low conga"],
	["highConga", "High conga"],
	["cabasa", "Cabasa"],
	["tambourine", "Tambourine"],
	["bell", "Cowbell"],
	["crash", "Crash"],
	["ride", "Ride"]
].map(([e, t]) => ({
	id: e,
	label: t
})), ht = [
	"Three pairs",
	"Twin stacks",
	"Serial stack",
	"Shared modulation",
	"Branched",
	"Additive"
], gt = [
	"16′",
	"5⅓′",
	"8′",
	"4′",
	"2⅔′",
	"2′",
	"1⅗′",
	"1⅓′",
	"1′"
], _t = [
	"an octave below",
	"a fifth above",
	"of the key",
	"an octave above",
	"an octave and a fifth above",
	"two octaves above",
	"two octaves and a third above",
	"two octaves and a fifth above",
	"three octaves above"
], vt = [
	"velvet",
	"reed",
	"planet",
	"strut",
	"drawbar"
], yt = [
	"Suitcase Mk I",
	"Stage Mk I",
	"Stage Mk II"
], bt = ["N", "T"], xt = [
	"a",
	"b",
	"c",
	"d",
	"e",
	"f",
	"g",
	"h"
], St = (e) => `${e}Pan`, Ct = [
	["kick", "Kick"],
	["snare", "Snare"],
	["clap", "Clap"],
	["hat", "Hat"],
	["open", "Open hat"],
	["perc", "Perc"],
	["synth", "Synth"]
].map(([e, t]) => ({
	id: e,
	label: t
})), wt = {
	boom: {
		kick: "kick",
		snare: "snare",
		clap: "clap",
		hat: "hat",
		open: "open",
		perc: "rim"
	},
	punch: {
		kick: "kick",
		snare: "snare",
		clap: "clap",
		hat: "hat",
		open: "open"
	},
	strike: {
		kick: "kick",
		snare: "snare",
		clap: "clap",
		hat: "hat",
		open: "open",
		perc: "rim"
	},
	forge: {
		kick: "kick",
		snare: "snare",
		hat: "hat",
		open: "open",
		perc: "anvil"
	},
	orbit: {
		kick: "skin",
		snare: "sand",
		clap: "sand",
		hat: "shaker",
		open: "metal",
		perc: "wood"
	}
}, Tt = [
	["kick", "Kick"],
	["snare", "Snare"],
	["hat", "Closed hat"],
	["pedal", "Pedal hat"],
	["open", "Open hat"],
	["lowTom", "Floor tom"],
	["highTom", "Rack tom"],
	["crash", "Crash"],
	["china", "China"],
	["ride", "Ride"],
	["anvil", "Anvil"]
].map(([e, t]) => ({
	id: e,
	label: t
})), Et = [
	2,
	3,
	4,
	6
], Dt = (e, t) => `${e}Roll${t}`, Ot = [
	"Fuzz",
	"Rectify",
	"Fold",
	"Crush",
	"Broken"
], kt = (e, t) => e.flatMap(({ id: e, label: n }) => [
	V(`${e}Tune`, "Tune", -24, 24, 0, 1, "st"),
	V(`${e}Decay`, "Decay", .03, 4, t(e), .01, "s", !0),
	V(`${e}Tone`, "Tone", 0, 1, .7),
	V(`${e}Level`, "Level", 0, 1.6, .8),
	V(`${e}Pan`, "Pan", -1, 1, 0),
	at(`${e}Lag`)
].map((t) => ({
	...t,
	voice: e,
	label: `${n} ${t.label}`
}))), At = [
	["kick", "Kick"],
	["snare", "Snare"],
	["rim", "Rim"],
	["clap", "Clap"],
	["hat", "Hat"],
	["open", "Open"],
	["lowTom", "Lo tom"],
	["highTom", "Hi tom"],
	["crash", "Crash"],
	["ride", "Ride"],
	["bell", "Bell"]
].map(([e, t]) => ({
	id: e,
	label: t
})), jt = [
	["kick", "Kick"],
	["snare", "Snare"],
	["clap", "Clap"],
	["hat", "Hat"],
	["open", "Open"]
].map(([e, t]) => ({
	id: e,
	label: t
})), Mt = (e) => e.map(({ id: e, label: t }) => K({
	...V(`${e}Level`, `${t} level`, 0, 2, 1),
	voice: e
})), Nt = (e, t) => e.flatMap(({ id: e, label: n }) => [
	...t[e],
	K(V(`${e}Pan`, "Pan", -1, 1, 0)),
	at(`${e}Lag`)
].map((t) => ({
	...t,
	voice: e,
	label: `${n} ${t.label}`
}))), Pt = (e) => K(V(e, "Tune", -12, 12, 0, 1, "st")), Ft = (e, t, n, r, i = .01) => V(e, "Decay", t, n, r, i, "s", !0), It = (e) => K(V(e, "Tone", 0, 1, .5)), Lt = (e, t) => 2 ** ((e - .5) * t), Rt = {
	kick: [V("kickTune", "Tune", 30, 90, 49, 1, "Hz"), V("kickDecay", "Decay", .1, 2.5, .8, .01, "s", !0)],
	snare: [
		Pt("snareTune"),
		K(Ft("snareDecay", .05, 1, .2)),
		V("snareTone", "Tone", 0, 1, .5),
		V("snappy", "Snappy", 0, 1, .6)
	],
	rim: [Pt("rimTune"), K(Ft("rimDecay", .01, .3, .03, .001))],
	clap: [It("clapTone"), K(Ft("clapDecay", .05, 1.5, .2))],
	hat: [Ft("hatDecay", .02, .6, .06), It("hatTone")],
	open: [K(Ft("openDecay", .1, 1.2, .4)), It("openTone")],
	lowTom: [Pt("tomTune"), K(Ft("tomDecay", .1, 1.5, .45))],
	highTom: [{
		...Pt("highTomTune"),
		legacyFrom: "tomTune"
	}, {
		...K(Ft("highTomDecay", .1, 1.5, .45)),
		legacyFrom: "tomDecay"
	}],
	crash: [K(Ft("crashDecay", .3, 3, 1.6)), It("crashTone")],
	ride: [K(Ft("rideDecay", .2, 2.5, 1)), It("rideTone")],
	bell: [V("bellTune", "Tune", -12, 12, 0, 1, "st"), K(Ft("bellDecay", .05, 1.5, .32))]
}, zt = {
	kick: [
		V("kickTune", "Tune", 40, 90, 55, 1, "Hz"),
		Ft("kickDecay", .1, 1.2, .45),
		V("kickClick", "Click", 0, 1, .5)
	],
	snare: [
		Pt("snareTune"),
		K(Ft("snareDecay", .05, 1, .18)),
		V("snareTone", "Tone", 0, 1, .5),
		V("snappy", "Snappy", 0, 1, .7)
	],
	clap: [It("clapTone"), K(Ft("clapDecay", .05, 1.5, .24))],
	hat: [Ft("hatDecay", .02, .3, .05), It("hatTone")],
	open: [Ft("openDecay", .1, 1, .35), It("openTone")]
}, Z = {
	performance: {
		name: "STEP–16",
		subtitle: "PATTERN & NOTE CONTROLLER",
		color: "performance",
		params: [at("lag")],
		ports: [...G(W("pitch", "Pitch · 1V/oct", "cv"), 3), ...G(W("gate", "Note gate", "gate"), 3)]
	},
	dictator: {
		name: "DICTATOR",
		subtitle: "NOTE RECORDER · LOOPING MIDI CLIP",
		color: "dictator",
		params: [
			q(H("length", "Length", _.map((e) => `${e} ${e === 1 ? "bar" : "bars"}`), 2), "How many bars the clip loops. Notes past the end stay in the clip, unheard, until it is long enough to play them again."),
			q(H("quantize", "Quantize", x.map(([e]) => e), 3), "The grid, from quarter notes to 1/32s, that the Quantize button beside it, and AUTO while recording, move note starts onto."),
			q(H("qrec", "Q-Rec", ["Off", "On"], 0), "AUTO quantizes while recording, as Reason’s Q Record does: on, each note you record starts on the Quantize grid; off, it keeps the timing you played, and the Quantize button can tidy it later."),
			q(H("mode", "Record", ["Overdub", "Replace"], 0), "Overdub adds what you play to the clip on every pass round the loop. Replace erases the notes the playhead passes while recording, so a new pass takes the place of the old one."),
			at("lag")
		],
		ports: [...G(W("pitch", "Pitch · 1V/oct", "cv"), 3), ...G(W("gate", "Note gate", "gate"), 3)]
	},
	oscillator: {
		name: "SOLID",
		subtitle: "ANALOG OSCILLATOR",
		color: "oscillator",
		params: [
			H("wave", "Waveform", [
				"Sine",
				"Triangle",
				"Saw",
				"Square"
			], 2),
			V("octave", "Octave", -3, 3, 0, 1),
			V("tune", "Tune", -12, 12, 0, 1, "st"),
			V("fine", "Fine", -50, 50, 0, 1, "ct"),
			V("level", "Level", 0, 1, .7)
		],
		ports: [
			U("pitch", "Pitch · 1V/oct", "cv", 1200),
			U("fm", "FM", "cv", 1200),
			...G(W("out", "Audio out"))
		]
	},
	noise: {
		name: "STATIC",
		subtitle: "NOISE GENERATOR",
		color: "noise",
		params: [H("color", "Color", [
			"White",
			"Pink",
			"Brown"
		], 0), V("level", "Level", 0, 1, .4)],
		ports: [...G(W("out", "Audio out"))]
	},
	mixer: {
		name: "SUM",
		subtitle: "EIGHT CHANNEL MIXER",
		color: "mixer",
		params: [
			...xt.map((e, t) => {
				let n = V(e, `Channel ${e.toUpperCase()}`, 0, 1, .7);
				return t > 2 ? K(n) : n;
			}),
			...xt.map((e) => K(V(St(e), `Channel ${e.toUpperCase()} pan`, -1, 1, 0))),
			K(V("master", "Mix bus", 0, 1, 1))
		],
		ports: [...xt.map((e) => U(e, `Channel ${e.toUpperCase()}`)), ...G(W("out", "Mix out"))]
	},
	filter: {
		name: "SIEVE",
		subtitle: "MULTIMODE FILTER",
		color: "filter",
		params: [
			H("mode", "Mode", [
				"Low-pass",
				"High-pass",
				"Band-pass"
			], 0),
			V("cutoff", "Cutoff", 40, 18e3, 1400, 1, "Hz", !0),
			V("resonance", "Resonance", .1, 12, 2.5, .1),
			ct("filterModel")
		],
		ports: [
			U("in", "Audio in"),
			U("cv", "Cutoff CV", "cv", 2400),
			...G(W("out", "Audio out"))
		]
	},
	amplifier: {
		name: "LEVEL",
		subtitle: "VOLTAGE CONTROLLED AMPLIFIER",
		color: "amplifier",
		params: [V("level", "Level", 0, 1, .8)],
		ports: [
			U("in", "Audio in"),
			U("cv", "Amplitude CV", "cv", 1),
			...G(W("out", "Audio out"))
		]
	},
	envelope: {
		name: "CONTOUR",
		subtitle: "ADSR ENVELOPE",
		color: "envelope",
		params: [
			V("attack", "Attack", .002, 2, .01, .001, "s", !0),
			V("decay", "Decay", .01, 3, .2, .01, "s", !0),
			V("sustain", "Sustain", 0, 1, .5),
			V("release", "Release", .01, 4, .18, .01, "s", !0)
		],
		ports: [U("gate", "Note gate", "gate"), ...G(W("out", "Envelope CV", "cv"))]
	},
	lfo: {
		name: "PULSE",
		subtitle: "LOW FREQUENCY OSCILLATOR",
		color: "lfo",
		params: [H("wave", "Waveform", [
			"Sine",
			"Triangle",
			"Saw",
			"Square"
		], 0), V("rate", "Rate", .05, 20, 2, .05, "Hz", !0)],
		ports: [U("cv", "Rate CV", "cv", 5), ...G(W("out", "Modulation CV", "cv"))]
	},
	delay: {
		name: "ECHO",
		subtitle: "FEEDBACK DELAY",
		color: "delay",
		params: [
			V("time", "Time", .02, 1, .28, .01, "s"),
			V("feedback", "Feedback", 0, .85, .32),
			V("mix", "Mix", 0, 1, .22)
		],
		ports: [U("in", "Audio in"), ...G(W("out", "Audio out"))]
	},
	reverb: {
		name: "SPACE",
		subtitle: "STEREO REVERBERATOR",
		color: "reverb",
		params: [V("decay", "Decay", .2, 3, 1.5, .1, "s"), V("mix", "Mix", 0, 1, .25)],
		ports: [U("in", "Audio in"), ...G(W("out", "Audio out"))]
	},
	boom: {
		name: "BOOM",
		subtitle: "ANALOG DRUM MACHINE",
		color: "boom",
		ports: pt,
		drum: {
			mode: "steps",
			voices: At
		},
		params: [
			...Nt(At, Rt),
			V("level", "Level", 0, 1, .8),
			ct("engine"),
			J("kick", "x......x..x....."),
			J("snare", "....x.......x..."),
			J("hat", "x.x.x.x.x.x.x.x."),
			J("bell", "...........x..x."),
			...[
				"rim",
				"clap",
				"open",
				"lowTom",
				"highTom",
				"crash",
				"ride"
			].map((e) => K(J(e, "................"))),
			...Mt(At)
		]
	},
	punch: {
		name: "PUNCH",
		subtitle: "DANCE FLOOR DRUM MACHINE",
		color: "punch",
		ports: pt,
		drum: {
			mode: "steps",
			voices: jt
		},
		params: [
			...Nt(jt, zt),
			V("level", "Level", 0, 1, .8),
			ct("engine"),
			J("kick", "x...x...x...x..."),
			J("snare", "............x..x"),
			J("clap", "....x.......x..."),
			J("hat", "xx..xx..xx..xx.."),
			J("open", "..x...x...x...x."),
			...Mt(jt)
		]
	},
	orbit: {
		name: "ORBIT",
		subtitle: "EUCLIDEAN PERCUSSION",
		color: "orbit",
		ports: pt,
		drum: {
			mode: "euclid",
			voices: ut
		},
		params: [
			V("pitch", "Pitch", -12, 12, 0, 1, "st"),
			V("level", "Level", 0, 1, .7),
			ct("engine"),
			...ut.flatMap(dt)
		]
	},
	monarch: {
		name: "MONARCH",
		subtitle: "VINTAGE MONOSYNTH",
		color: "monarch",
		ports: [
			U("pitch", "Pitch · 1V/oct", "cv", 1200),
			U("gate", "Note gate", "gate"),
			U("cv", "Cutoff CV", "cv", 2400),
			...G(W("out", "Audio out"))
		],
		params: [
			...[
				1,
				2,
				3
			].flatMap((e) => [
				H(`osc${e}Wave`, "Waveform", [
					"Sine",
					"Triangle",
					"Saw",
					"Square"
				], 2),
				V(`osc${e}Octave`, "Octave", -3, 3, e === 3 ? -1 : 0, 1),
				V(`osc${e}Detune`, "Detune", -50, 50, e === 2 ? 7 : 0, 1, "ct"),
				V(`osc${e}Level`, "Level", 0, 1, e === 1 ? .7 : .35)
			].map((t) => ({
				...t,
				group: `Oscillator ${e}`
			}))),
			...[
				ct("filterModel"),
				V("cutoff", "Cutoff", 40, 18e3, 1100, 1, "Hz", !0),
				V("resonance", "Resonance", 0, 1, .2),
				V("drive", "Drive", 0, 1, .25),
				V("envAmount", "Env amount", -1, 1, .5),
				V("tracking", "Key track", 0, 1, .5)
			].map((e) => ({
				...e,
				group: "Filter"
			})),
			...ft("filter", "Filter envelope"),
			...ft("amp", "Amplifier envelope"),
			...[
				V("noise", "Noise", 0, 1, 0),
				V("glide", "Glide", 0, 1, 0, .01, "s"),
				V("level", "Level", 0, 1, .7)
			].map((e) => ({
				...e,
				group: "Performance"
			})),
			...Y("Controllers", [
				q(ot(1, 5), "How far the pitch wheel bends the oscillators, up or down. As on a Minimoog, the wheel bends them after Glide, and the filter stays put."),
				q(K(V("modMix", "Mod mix", 0, 1, 0)), "What the mod wheel sends, as a Minimoog’s Modulation Mix: Oscillator 3 at the left, noise at the right, a blend of the two between."),
				q(K(H("modDest", "Mod to", [
					"Osc",
					"Filter",
					"Both"
				], 0)), "Where the mod wheel sends the Mod mix, as a Minimoog’s Oscillator and Filter Modulation switches do: oscillators 1 and 2’s pitch, the filter’s cutoff, or both."),
				q(K(H("osc3Mode", "Osc 3", ["Audio", "LFO"], 0)), "LFO takes Oscillator 3 off the keys and down to a crawl, as a Minimoog’s Osc 3 Control switch and Lo range do, so the mod wheel brings in vibrato or a trill. Its Octave then sets the rate, from about 0.6 Hz to 40 Hz, and its Level still sends it to the mixer, so turn that down to keep it out of the sound. Audio keeps it playing with the keys, and the mod wheel growls.")
			])
		]
	},
	oracle: {
		name: "ORACLE",
		subtitle: "FIVE-VOICE POLYSYNTH",
		color: "oracle",
		ports: [
			U("pitch", "Pitch · 1V/oct", "cv", 1200),
			U("gate", "Note gate", "gate"),
			U("cv", "Cutoff CV", "cv", 2400),
			...G(W("out", "Audio out"))
		],
		params: [
			...Y("Poly-Mod", [
				V("polyEnv", "Filt env", 0, 1, 0),
				V("polyOscB", "Osc B", 0, 1, 0),
				H("polyDest", "Dest", [
					"Freq A",
					"Filter",
					"Both"
				], 0)
			]),
			...Y("Oscillator A", [
				V("aOctave", "Octave", -2, 2, 0, 1),
				H("aShape", "Shape", [
					"Saw",
					"Pulse",
					"Saw + Pulse"
				], 0),
				V("aWidth", "Width", .05, .95, .5)
			]),
			...Y("Oscillator B", [
				V("bOctave", "Octave", -2, 2, 0, 1),
				V("bFine", "Fine", -50, 50, 7, 1, "ct"),
				H("bShape", "Shape", [
					"Saw",
					"Triangle",
					"Pulse"
				], 0),
				V("bWidth", "Width", .05, .95, .5)
			]),
			...Y("LFO", [
				V("lfoRate", "Rate", .05, 20, 4, .05, "Hz", !0),
				H("lfoShape", "Shape", [
					"Triangle",
					"Saw",
					"Square"
				], 0),
				q(V("lfoAmount", "Amount", 0, 1, 0), "How much modulation reaches Dest with the mod wheel down, as a Prophet-5 Rev 4’s LFO initial amount. The mod wheel brings in the rest, up to full."),
				H("lfoDest", "Dest", [
					"Pitch",
					"PW",
					"Filter"
				], 0),
				q(K(V("lfoMix", "Source mix", 0, 1, 0)), "What the LFO section sends, as a Prophet-5’s Wheel-Mod Source Mix: the LFO at the left, noise at the right, a blend of the two between.")
			]),
			...Y("Mixer", [
				V("aLevel", "Osc A", 0, 1, .8),
				V("bLevel", "Osc B", 0, 1, .6),
				V("noise", "Noise", 0, 1, 0)
			]),
			...Y("Filter", [
				ct("filterModel"),
				V("cutoff", "Cutoff", 40, 18e3, 1600, 1, "Hz", !0),
				V("resonance", "Resonance", 0, 1, .15),
				V("envAmount", "Env amount", 0, 1, .4),
				V("tracking", "Key track", 0, 1, .5)
			]),
			...ft("filter", "Filter envelope"),
			...ft("amp", "Amplifier envelope"),
			...Y("Voices", [
				V("glide", "Glide", 0, 1, 0, .01, "s"),
				V("vintage", "Vintage", 0, 1, .3),
				H("chord", "Chord", mt.map(([e]) => e), 0),
				V("level", "Level", 0, 1, .7),
				q(ot(1, 2), "How far the spring-loaded pitch wheel bends oscillators A and B, up or down: from a semitone to an octave, as a Prophet-5 sets it.")
			])
		]
	},
	aurora: {
		name: "AURORA",
		subtitle: "EIGHT-VOICE ANALOG POLYSYNTH",
		color: "aurora",
		ports: [
			U("pitch", "Pitch · 1V/oct", "cv", 1200),
			U("gate", "Note gate", "gate"),
			U("cv", "Cutoff CV", "cv", 2400),
			...G(W("out", "Audio out"))
		],
		params: [
			...[1, 2].flatMap((e) => Y(`Oscillator ${e}`, [
				H(`osc${e}Wave`, "Waveform", [
					"Saw",
					"Pulse",
					"Triangle",
					"Sine"
				], e === 1 ? 0 : 1),
				V(`osc${e}Octave`, "Octave", -2, 2, 0, 1),
				V(`osc${e}Detune`, "Detune", -50, 50, e === 2 ? 6 : 0, 1, "ct"),
				V(`osc${e}Width`, "Width", .05, .95, .5)
			])),
			...Y("Source mix", [
				V("blend", "Osc 1 / 2", 0, 1, .5),
				V("crossMod", "Cross mod", 0, 1, 0),
				V("hpf", "High-pass", 20, 3e3, 20, 1, "Hz", !0)
			]),
			...Y("Filter", [
				ct("filterModel"),
				V("cutoff", "Cutoff", 40, 18e3, 2200, 1, "Hz", !0),
				V("resonance", "Resonance", 0, 1, .15),
				H("slope", "Slope", ["12 dB", "24 dB"], 1),
				V("envAmount", "Env amount", -1, 1, .35),
				V("tracking", "Key track", 0, 1, .5)
			]),
			...ft("filter", "Filter envelope"),
			...ft("amp", "Amplifier envelope"),
			...Y("LFO", [
				V("lfoRate", "Rate", .05, 20, .6, .05, "Hz", !0),
				H("lfoShape", "Waveform", [
					"Triangle",
					"Sine",
					"Square"
				], 0),
				V("lfoPitch", "Pitch", 0, 1, 0),
				V("lfoWidth", "PWM", 0, 1, .15),
				V("lfoFilter", "Filter", 0, 1, 0)
			]),
			...Y("Voices", [
				V("glide", "Glide", 0, 1, 0, .01, "s"),
				V("vintage", "Vintage", 0, 1, .25),
				H("chord", "Chord", mt.map(([e]) => e), 0),
				V("level", "Level", 0, 1, .65)
			]),
			...Y("Bender", [
				q({
					...ot(0, 2),
					label: "VCO bend"
				}, "How far the pitch wheel bends both oscillators, up or down, as a Jupiter-8’s VCO bend sensitivity."),
				q(K(V("bendFilter", "VCF bend", 0, 1, 0)), "How far the pitch wheel moves the cutoff with it, up to two octaves either way, as a Jupiter-8’s VCF bend sensitivity."),
				q(K(V("leverLfo", "LFO mod", 0, 1, .5)), "How much LFO vibrato the mod wheel brings in at full, as pushing a Jupiter-8’s bender lever away does at the depth its LFO Mod knob sets. The LFO section sets its rate and shape.")
			])
		]
	},
	strike: {
		name: "STRIKE",
		subtitle: "VINTAGE DIGITAL DRUM MACHINE",
		color: "strike",
		ports: pt,
		drum: {
			mode: "steps",
			voices: X
		},
		params: [
			V("level", "Level", 0, 1, .8),
			ct("engine"),
			...X.flatMap(({ id: e, label: t }) => [J(e, e === "kick" ? "x.......x.x....." : e === "snare" ? "....x.......x..." : e === "hat" ? "x.x.x.x.x.x.x.x." : "................"), ...[
				V(`${e}Tune`, "Tune", -24, 24, 0, 1, "st"),
				V(`${e}Decay`, "Decay", .03, 3, ["crash", "ride"].includes(e) ? 1.8 : e === "open" ? .45 : e === "hat" ? .08 : .35, .01, "s", !0),
				V(`${e}Tone`, "Tone", 0, 1, .7),
				V(`${e}Level`, "Level", 0, 1.6, .8),
				V(`${e}Pan`, "Pan", -1, 1, 0),
				at(`${e}Lag`)
			].map((n) => ({
				...n,
				voice: e,
				label: `${t} ${n.label}`
			}))])
		]
	},
	prism: {
		name: "PRISM",
		subtitle: "SIX-OPERATOR FM SYNTH",
		color: "prism",
		ports: [
			U("pitch", "Pitch · 1V/oct", "cv", 1200),
			U("gate", "Note gate", "gate"),
			U("cv", "Brightness CV", "cv", 1),
			...G(W("out", "Audio out"))
		],
		params: [
			...Y("Sound", [
				H("algorithm", "Algorithm", ht, 0),
				V("feedback", "Feedback", 0, 1, .08),
				V("brightness", "Brightness", 0, 2, .8),
				V("velocity", "Velocity", 0, 1, .7)
			]),
			...Y("Performance", [
				V("lfoRate", "LFO rate", .05, 20, 5, .05, "Hz", !0),
				V("lfoDepth", "Vibrato", 0, 1, 0),
				H("chord", "Chord", mt.map(([e]) => e), 0),
				V("level", "Level", 0, 1, .65),
				q(ot(0, 2), "How far the spring-loaded pitch wheel bends, up or down: up to an octave, as a DX7’s Pitch bend range."),
				q(K(V("wheelRange", "Mod range", 0, 1, .5)), "How far the mod wheel reaches at full, as a DX7’s wheel Range, 0 to 99, which leaves the factory at 50."),
				q(K(H("wheelAssign", "Mod to", [
					"Pitch",
					"Amp",
					"EG bias"
				], 0)), "What the mod wheel does, as a DX7’s wheel assign: Pitch deepens the LFO’s vibrato, Amp brings in tremolo from it, and EG bias brightens the sound.")
			]),
			...Y("Filter", [ct("filterModel"), ...[
				V("filterCutoff", "Cutoff", 40, 18e3, 9e3, 1, "Hz", !0),
				V("filterResonance", "Resonance", 0, 1, .15),
				V("filterDrive", "Drive", 0, 1, .2),
				V("filterEnv", "Env amount", -1, 1, .25),
				V("filterTrack", "Key track", 0, 1, .5)
			].map(K)]),
			...Array.from({ length: 6 }, (e, t) => {
				let n = `op${t + 1}`;
				return [
					V(`${n}Ratio`, "Ratio", .5, 16, t % 2 ? 2 : 1, .5),
					V(`${n}Detune`, "Detune", -50, 50, 0, 1, "ct"),
					V(`${n}Level`, "Level", 0, 1, t < 2 ? .8 : .4),
					V(`${n}Attack`, "Attack", .002, 2, .005, .001, "s", !0),
					V(`${n}Decay`, "Decay", .01, 3, t % 2 ? .35 : 1.2, .01, "s", !0),
					V(`${n}Sustain`, "Sustain", 0, 1, t % 2 ? .05 : .25),
					V(`${n}Release`, "Release", .01, 4, .25, .01, "s", !0)
				].map((e) => ({
					...e,
					voice: n
				}));
			}).flat()
		]
	},
	velvet: {
		name: "VELVET",
		subtitle: "TINE ELECTRIC PIANO",
		color: "velvet",
		ports: [
			U("pitch", "Pitch · 1V/oct", "cv", 1200),
			U("gate", "Note gate", "gate"),
			U("cv", "Bark CV", "cv", 1),
			...G(W("out", "Audio out"))
		],
		params: [
			ct("engine"),
			...Y("Piano", [q(H("model", "Model", yt, 0), "Suitcase Mk I plays through its own preamp, a stereo tremolo that pans between two amps, and four 12-inch speakers. Stage Mk I has passive pickups set closer, for more bark, into a guitar amp with mono tremolo. Stage Mk II rings a brighter bell over a tighter bass.")]),
			...Y("Hammer", [q(V("hardness", "Hardness", 0, 1, .5), "How hard the neoprene hammer tips are: harder brings out the tine’s bell.")]),
			...Y("Pickup", [q(V("bark", "Bark", 0, 1, .4), "How close the pickups sit to the tines: closer, the hard notes growl and bark; further, everything stays round and bell-like."), q(V("bell", "Bell", 0, 1, .35), "The tine’s chime at the start of each note, the bright ring above the tone.")]),
			...Y("Tines", [q(V("decay", "Decay", .3, 2, 1, .01, "×"), "How long the tines ring."), q(V("damper", "Damper", 0, 1, .5), "How quickly the felt dampers stop a tine when you let go.")]),
			...Y("Amp", [
				q(V("drive", "Drive", 0, 1, .2), "The Suitcase’s preamp, or a Stage’s guitar amp, pushed into gentle overdrive."),
				V("bass", "Bass", -12, 12, 2, .5, "dB"),
				V("treble", "Treble", -12, 12, 0, .5, "dB"),
				q(V("tremRate", "Trem rate", .5, 10, 4.5, .05, "Hz", !0), "How fast the tremolo goes: the Suitcase sweeps the sound between left and right, a Stage’s amp pulses its level."),
				q(V("tremDepth", "Trem depth", 0, 1, .4), "How far the tremolo sweeps: none keeps the sound still and centred.")
			]),
			...Y("Output", [V("level", "Level", 0, 1, .7)])
		]
	},
	reed: {
		name: "REED",
		subtitle: "REED ELECTRIC PIANO",
		color: "reed",
		ports: [
			U("pitch", "Pitch · 1V/oct", "cv", 1200),
			U("gate", "Note gate", "gate"),
			U("cv", "Bark CV", "cv", 1),
			...G(W("out", "Audio out"))
		],
		params: [
			ct("engine"),
			...Y("Hammer", [q(V("hardness", "Hardness", 0, 1, .5), "How hard the felt hammers are: harder brings out the reed’s metallic upper modes.")]),
			...Y("Pickup", [q(V("bark", "Bark", 0, 1, .45), "How hard the reeds swing against the pickup: hard notes break up into the reed piano’s nasal bark.")]),
			...Y("Reeds", [q(V("decay", "Decay", .3, 2, 1, .01, "×"), "How long the reeds ring."), q(V("damper", "Damper", 0, 1, .5), "How quickly the dampers stop a reed when you let go.")]),
			...Y("Amp", [
				q(V("drive", "Drive", 0, 1, .25), "The amp pushed into overdrive."),
				q(V("tremRate", "Trem rate", .5, 10, 5.6, .05, "Hz", !0), "How fast the tremolo pulses the level."),
				q(V("tremDepth", "Trem depth", 0, 1, .3), "How deep the tremolo pulses."),
				q(H("speaker", "Speaker", ["Built-in", "Line"], 0), "Built-in plays through the piano’s own small speakers, forward and boxy; Line is the full-range output.")
			]),
			...Y("Output", [V("level", "Level", 0, 1, .7)])
		]
	},
	planet: {
		name: "PLANET",
		subtitle: "PLUCKED REED PIANO",
		color: "planet",
		ports: [
			U("pitch", "Pitch · 1V/oct", "cv", 1200),
			U("gate", "Note gate", "gate"),
			U("cv", "Bark CV", "cv", 1),
			...G(W("out", "Audio out"))
		],
		params: [
			ct("engine"),
			...Y("Reeds", [
				q(H("model", "Model", bt, 0), "The N’s leather pads grip hard and peel with a faint tick, and its electrostatic pickup barks as the reeds swing wide. The T’s rubber pads let go softly, and its coils round off the top for a mellower tone."),
				q(V("pluck", "Pluck", 0, 1, .5), "How sticky the pads are: stickier pads bend the reeds further and snap away quicker, louder and brighter; looser ones pluck soft and round."),
				q(V("decay", "Decay", .3, 2, 1, .01, "×"), "How long the reeds ring."),
				q(V("damper", "Damper", 0, 1, .5), "How quickly the pads stop a reed when they land back on it as you let go.")
			]),
			...Y("Pickup", [q(V("bark", "Bark", 0, 1, .4), "How hard the reeds swing against the pickups: more brings out the nasal bark, the N’s far more than the T’s.")]),
			...Y("Amp", [
				q(V("drive", "Drive", 0, 1, .2), "The amp pushed into overdrive."),
				q(V("tone", "Tone", -12, 12, 0, .5, "dB"), "Tilts the top end, above about 2 kHz, brighter or darker."),
				q(V("tremRate", "Trem rate", .5, 10, 5, .05, "Hz", !0), "How fast the tremolo pulses the level."),
				q(V("tremDepth", "Trem depth", 0, 1, 0), "How deep the tremolo pulses: none keeps the level still.")
			]),
			...Y("Output", [V("level", "Level", 0, 1, .7)])
		]
	},
	strut: {
		name: "STRUT",
		subtitle: "CLAVINET",
		color: "strut",
		ports: [
			U("pitch", "Pitch · 1V/oct", "cv", 1200),
			U("gate", "Note gate", "gate"),
			U("cv", "Hardness CV", "cv", 1),
			...G(W("out", "Audio out"))
		],
		params: [
			ct("engine"),
			...Y("Pickups", [q(H("pickupAB", "AB", ["A", "B"], 0), "With CD on C, A plays the lower pickup alone, full and round, and B the upper, thin and bright. With CD on D, A plays both in phase and B both out of phase, the hollow, nasal quack."), q(H("pickupCD", "CD", ["C", "D"], 1), "C plays one pickup, as AB chooses; D plays both, in phase or out as AB chooses.")]),
			...Y("Tone", [
				q(H("brilliant", "Brilliant", ["Off", "On"], 0), "Cuts the bass and lower mids for a thin, glassy edge."),
				q(H("treble", "Treble", ["Off", "On"], 1), "Cuts the deepest bass for a bright, cutting tone."),
				q(H("medium", "Medium", ["Off", "On"], 0), "Rolls off the top for a rounder tone."),
				q(H("soft", "Soft", ["Off", "On"], 0), "Rolls off much of the top for a dark, woody tone. The rockers combine, and with all four off the pickups play flat.")
			]),
			...Y("Mute", [q(V("mute", "Mute", 0, 1, 0), "Slides the felt mute against the strings near the bridge: further on, each note dies sooner and duller, to a short pizzicato.")]),
			...Y("Strings", [
				q(V("hardness", "Hardness", 0, 1, .5), "How hard the rubber tips are: harder tips push the string quicker, for a brighter attack."),
				q(V("decay", "Decay", .3, 2, 1, .01, "×"), "How long a held string rings."),
				q(V("release", "Release", 0, 1, .5), "The short, pitched plunk as a key lets its string fall back onto the yarn.")
			]),
			...Y("Output", [q(V("drive", "Drive", 0, 1, .15), "The amp it plays into, pushed harder: the hard notes break up into a funky growl."), V("level", "Level", 0, 1, .7)])
		]
	},
	drawbar: {
		name: "DRAWBAR",
		subtitle: "TONEWHEEL ORGAN · ROTARY SPEAKER",
		color: "drawbar",
		ports: [
			U("pitch", "Pitch · 1V/oct", "cv", 1200),
			U("gate", "Note gate", "gate"),
			U("cv", "Swell CV", "cv", 1),
			...G(W("out", "Audio out"))
		],
		params: [
			ct("engine"),
			...Y("Drawbars", gt.map((e, t) => q(V(`drawbar${t + 1}`, e, 0, 8, t < 3 ? 8 : 0, 1), `The ${e} drawbar: how much of the pitch ${_t[t]} each key sounds, from 0 out to 8 full.`))),
			...Y("Percussion", [
				q(H("percussion", "Percussion", ["Off", "On"], 0), "A ping on the second or third harmonic at the start of each phrase. Single-trigger: it sounds only when every key was up, so legato lines don’t retrigger it; play detached to hear it on every note. On takes over the 1′ drawbar."),
				q(H("percHarmonic", "Harmonic", ["2nd", "3rd"], 1), "The ping an octave above the key, or an octave and a fifth, the classic."),
				q(H("percDecay", "Decay", ["Fast", "Slow"], 0), "Fast dies away in about half a second, Slow in about two and a half."),
				q(H("percVolume", "Volume", ["Normal", "Soft"], 0), "Normal rings out over the drawbars and drops them 3 dB, as the original does; Soft is 6 dB quieter and leaves them be.")
			]),
			...Y("Vibrato", [q(H("vibrato", "Scanner", [
				"Off",
				"V1",
				"V2",
				"V3",
				"C1",
				"C2",
				"C3"
			], 0), "The scanner vibrato, V1 to V3 deeper and deeper, or the chorus, C1 to C3, which mixes it with the dry sound.")]),
			...Y("Tonewheels", [q(V("click", "Key click", 0, 1, .4), "The click of the key contacts closing, the organ’s percussive edge."), q(V("leakage", "Leakage", 0, 1, .3), "The faint other tonewheels that leak into every note on an old organ.")]),
			...Y("Rotary", [
				q(V("drive", "Drive", 0, 1, .25), "The rotary speaker’s tube amp pushed into growl."),
				q(H("rotary", "Rotor", ["Stop", "Run"], 1), "Run spins the horn and the drum; Stop holds them still. The mod wheel’s top half switches them fast, and the rotary switch beside the keys does too."),
				q(V("balance", "Balance", 0, 1, .5), "Tilts the cabinet between the horn’s treble and the drum’s bass: at either end the other rotor is 12 dB down."),
				V("level", "Level", 0, 1, .6)
			])
		]
	},
	compressor: {
		name: "VALVE",
		subtitle: "VARIABLE-MU LIMITER",
		color: "compressor",
		ports: [U("in", "Audio in"), ...G(W("out", "Audio out"))],
		params: [
			V("input", "Input", -12, 18, 0, .5, "dB"),
			V("threshold", "Threshold", -40, 0, -18, .5, "dB"),
			H("time", "Time constant", [
				"1",
				"2",
				"3",
				"4",
				"5",
				"6"
			], 1),
			V("output", "Output", -12, 12, 0, .5, "dB")
		]
	},
	equalizer: {
		name: "CONSOLE",
		subtitle: "FOUR-BAND CHANNEL EQ",
		color: "equalizer",
		ports: [U("in", "Audio in"), ...G(W("out", "Audio out"))],
		params: [
			H("active", "EQ", ["In", "Out"], 0),
			V("output", "Output", -12, 12, 0, .5, "dB"),
			...Y("Filters", [V("hpf", "High-pass", 16, 350, 16, 1, "Hz", !0), V("lpf", "Low-pass", 3e3, 22e3, 22e3, 10, "Hz", !0)]),
			...Y("LF", [
				V("lfGain", "Gain", -15, 15, 0, .5, "dB"),
				V("lfFreq", "Freq", 30, 450, 100, 1, "Hz", !0),
				H("lfBell", "Shape", ["Shelf", "Bell"], 0)
			]),
			...Y("LMF", [
				V("lmfGain", "Gain", -15, 15, 0, .5, "dB"),
				V("lmfFreq", "Freq", 200, 2500, 600, 1, "Hz", !0),
				V("lmfQ", "Q", .5, 4, 1, .1)
			]),
			...Y("HMF", [
				V("hmfGain", "Gain", -15, 15, 0, .5, "dB"),
				V("hmfFreq", "Freq", 600, 7e3, 2500, 10, "Hz", !0),
				V("hmfQ", "Q", .5, 4, 1, .1)
			]),
			...Y("HF", [
				V("hfGain", "Gain", -15, 15, 0, .5, "dB"),
				V("hfFreq", "Freq", 1500, 16e3, 8e3, 10, "Hz", !0),
				H("hfBell", "Shape", ["Shelf", "Bell"], 0)
			])
		]
	},
	cohere: {
		name: "COHERE",
		subtitle: "STEREO BUS COMPRESSOR",
		color: "cohere",
		ports: [U("in", "Audio in"), ...G(W("out", "Audio out"))],
		params: [...Y("Dynamics", [
			V("threshold", "Threshold", -40, 10, -18, .5, "dB"),
			H("ratio", "Ratio", [
				"2:1",
				"4:1",
				"10:1"
			], 1),
			H("attack", "Attack", [
				"0.1 ms",
				"0.3 ms",
				"1 ms",
				"3 ms",
				"10 ms",
				"30 ms"
			], 4),
			H("release", "Release", [
				"0.1 s",
				"0.3 s",
				"0.6 s",
				"1.2 s",
				"Auto"
			], 4)
		]), ...Y("Bus", [
			H("scHpf", "Detector HP", [
				"Off",
				"30 Hz",
				"60 Hz",
				"106 Hz",
				"125 Hz",
				"185 Hz"
			], 0),
			V("output", "Makeup", -12, 20, 0, .5, "dB"),
			H("active", "Process", ["In", "Bypass"], 0)
		])]
	},
	talon: {
		name: "TALON",
		subtitle: "HARMONIC DYNAMICS PROCESSOR",
		color: "talon",
		ports: [U("in", "Audio in"), ...G(W("out", "Audio out"))],
		params: [
			...Y("Dynamics", [
				V("input", "Input", -12, 30, 0, .5, "dB"),
				H("ratio", "Ratio", [
					"1:1",
					"2:1",
					"3:1",
					"4:1",
					"6:1",
					"10:1 Opto",
					"20:1",
					"Crush"
				], 4),
				V("attack", "Attack", 5e-5, .03, .003, 5e-5, "s", !0),
				V("release", "Release", .05, 3.5, .3, .01, "s", !0)
			]),
			...Y("Character", [
				H("color", "Harmonics", [
					"Clean",
					"Even",
					"Odd"
				], 0),
				H("audioHp", "Audio HP", ["Off", "65 Hz"], 0),
				H("fierce", "Fierce", ["Off", "On"], 0)
			]),
			...Y("Detector", [
				H("detectorHp", "High-pass", ["Off", "80 Hz"], 0),
				H("detectorBand", "Emphasis", ["Off", "6 kHz"], 0),
				H("link", "Stereo link", ["Off", "On"], 1)
			]),
			...Y("Output", [V("output", "Output", -30, 12, 0, .5, "dB"), H("active", "Process", ["In", "Bypass"], 0)])
		]
	},
	brit: {
		name: "BRIT",
		subtitle: "THREE-BAND CLASS A EQUALIZER",
		color: "brit",
		ports: [U("in", "Audio in"), ...G(W("out", "Audio out"))],
		params: [
			...Y("Low shelf", [H("lfFreq", "Freq", [
				"35 Hz",
				"60 Hz",
				"110 Hz",
				"220 Hz"
			], 2), V("lfGain", "Gain", -16, 16, 0, .5, "dB")]),
			...Y("Mid bell", [H("midFreq", "Freq", [
				"360 Hz",
				"700 Hz",
				"1.6 kHz",
				"3.2 kHz",
				"4.8 kHz",
				"7.2 kHz"
			], 2), V("midGain", "Gain", -18, 18, 0, .5, "dB")]),
			...Y("High shelf · 12 kHz", [V("hfGain", "Gain", -16, 16, 0, .5, "dB")]),
			...Y("Signal", [
				H("hpf", "High-pass", [
					"Off",
					"50 Hz",
					"80 Hz",
					"160 Hz",
					"300 Hz"
				], 0),
				V("drive", "Drive", 0, 24, 0, .5, "dB"),
				V("output", "Output", -18, 18, 0, .5, "dB"),
				H("active", "Process", ["In", "Bypass"], 0)
			])
		]
	},
	skitter: {
		name: "SKITTER",
		subtitle: "TRAP STEP SEQUENCER · 1/16 · 1/32 · ROLLS",
		color: "skitter",
		ports: [...G(W("trig", "Trig out · drums", "gate")), ...G(W("gate", "Synth gate", "gate"))],
		drum: {
			mode: "steps",
			voices: Ct
		},
		params: [
			V("rollFade", "Roll fade", 0, 1, .35),
			V("gate", "Gate", .1, 1, .5),
			...Ct.flatMap(({ id: e }) => [J(e, {
				snare: "....x.......x...",
				hat: "x.x.x.x.x.x.x.x."
			}[e] ?? "................"), ...Et.map((t) => ({
				...J(e, "................"),
				id: Dt(e, t),
				label: `Roll ×${t}`
			}))])
		]
	},
	forge: {
		name: "FORGE",
		subtitle: "INDUSTRIAL DRUM KIT",
		color: "forge",
		ports: pt,
		drum: {
			mode: "steps",
			voices: Tt
		},
		params: [
			V("level", "Level", 0, 1, .8),
			ct("engine"),
			V("drive", "Drive", 0, 1, .35),
			V("room", "Room", 0, 1, .2),
			...Tt.map(({ id: e }) => J(e, {
				kick: "x.......x.x.....",
				snare: "....x.......x...",
				hat: "x.x.x.x.x.x.x.x."
			}[e] ?? "................")),
			...kt(Tt, (e) => ({
				crash: 2.4,
				china: 1.6,
				ride: 2.6,
				open: .7,
				hat: .09,
				pedal: .12,
				lowTom: .7,
				highTom: .55,
				anvil: 1,
				kick: .5,
				snare: .45
			})[e] ?? .4)
		]
	},
	rust: {
		name: "RUST",
		subtitle: "INDUSTRIAL DISTORTION",
		color: "rust",
		ports: [
			U("in", "Audio in"),
			U("cv", "Drive CV", "cv", 4),
			...G(W("out", "Audio out"))
		],
		params: [
			H("mode", "Mode", Ot, 0),
			V("drive", "Drive", 0, 1, .6),
			V("bias", "Bias", 0, 1, .15),
			V("crush", "Bits", 2, 12, 6, 1),
			V("starve", "Starve", 0, 1, 0),
			V("body", "Body", 60, 2e3, 220, 1, "Hz", !0),
			V("tone", "Tone", 0, 1, .55),
			V("mix", "Mix", 0, 1, 1),
			V("level", "Level", 0, 1, .6)
		]
	},
	output: {
		name: "MAIN",
		subtitle: "STEREO MASTER OUTPUT",
		color: "output",
		params: [V("volume", "Master", 0, 1, .65)],
		ports: [U("in", "Audio in")]
	}
}, Bt = Object.keys(Z).filter((e) => e !== "output"), Vt = 0, Ht = (e = "module") => `${e}-${Date.now().toString(36)}-${++Vt}`, Ut = (e, t = Ht()) => ({
	id: t,
	type: e,
	params: Object.fromEntries(Z[e].params.map((e) => [e.id, e.initial]))
}), Wt = (e) => Z[e].params.find((e) => st.includes(e.id)), Gt = (e) => e === "performance" ? {
	...Ut(e),
	steps: Array.from({ length: 16 }, (e, t) => ({
		enabled: t % 4 == 0,
		note: 48,
		velocity: .8,
		gate: .5
	}))
} : e === "dictator" ? {
	...Ut(e),
	notes: []
} : Ut(e), Kt = (e, t) => e.modules.find((e) => e.id === t)?.type === "output", qt = (e, t) => e.modules[0].id === t ? e.sequencer.steps : e.modules.find((e) => e.id === t)?.steps ?? e.sequencer.steps;
function Jt(e, t, n) {
	return e.modules[0].id === t ? {
		...e,
		sequencer: {
			...e.sequencer,
			steps: n
		}
	} : {
		...e,
		modules: e.modules.map((e) => e.id === t ? {
			...e,
			steps: n
		} : e)
	};
}
function Yt(e, t, n = e.cables) {
	let r = (t) => e.modules.some((e) => e.id === t.id) ? qt(e, t.id) : t.steps ?? e.sequencer.steps, i = t[0]?.type === "performance" ? r(t[0]) : e.sequencer.steps;
	return {
		...e,
		cables: n,
		sequencer: i === e.sequencer.steps ? e.sequencer : {
			...e.sequencer,
			steps: i
		},
		modules: t.map((e, t) => e.type === "performance" ? t === 0 ? e.steps ? {
			id: e.id,
			type: e.type,
			params: e.params
		} : e : e.steps ? e : {
			...e,
			steps: r(e)
		} : e)
	};
}
var Xt = (e) => e.modules.find((e) => Ln(e.type)) ?? e.modules[0], Zt = (e, t) => e.modules.find((e) => e.id === t)?.notes ?? [], Qt = (e, t) => Math.max(0, Math.min(y, b - e.modules.reduce((e, n) => e + (n.id === t ? 0 : n.notes?.length ?? 0), 0))), $t = (e, t, n) => {
	let r = Qt(e, t);
	return {
		...e,
		modules: e.modules.map((e) => e.id === t ? {
			...e,
			notes: n.length > r ? n.slice(0, r) : n
		} : e)
	};
}, en = [], tn = (e, t) => e?.[Fe[t]] ?? en, nn = (e, t, n) => Math.max(0, Math.min(Le, Re - e.modules.reduce((e, r) => e + B.reduce((e, i) => e + (r.id === t && i === n ? 0 : tn(r, i).length), 0), 0)));
function rn(e, t, n, r) {
	let i = nt(r, nn(e, t, n)), a = Fe[n];
	return {
		...e,
		modules: e.modules.map((e) => {
			if (e.id !== t) return e;
			let n = { ...e };
			return i.length ? n[a] = i : delete n[a], n;
		})
	};
}
function an(e, t, n) {
	let r = e.modules.find((e) => e.id === t);
	return r ? B.reduce((e, i) => n[i]?.length ? rn(e, t, i, $e(tn(r, i), n[i], C(r.params.length))) : e, e) : e;
}
var on = {
	monarch: ["bend", "mod"],
	oracle: ["bend", "mod"],
	aurora: ["bend", "mod"],
	prism: ["bend", "mod"],
	velvet: ["sustain", "expression"],
	reed: ["sustain", "expression"],
	planet: ["sustain", "expression"],
	strut: ["expression"],
	drawbar: ["mod", "expression"]
}, sn = (e) => on[e] ?? [];
function cn(e, t, n) {
	let r = e.modules.find((e) => e.id === t), i = (e) => n ? sn(e).includes(n) : sn(e).length > 0;
	if (!r) return [];
	if (sn(r.type).length) return i(r.type) ? [r.id] : [];
	if (!Bn(r.type)) return [];
	let a = new Set(e.cables.filter((t) => t.from.moduleId === r.id && hn(e, t.from)?.kind === "gate").map((e) => e.to.moduleId));
	return e.modules.filter((e) => a.has(e.id) && i(e.type)).map((e) => e.id);
}
function ln(e, t) {
	let n = new Set(cn(e, t).flatMap((t) => sn(e.modules.find((e) => e.id === t).type)));
	return B.filter((e) => n.has(e));
}
var un = (e) => Z[e].ports.some((e) => e.id === "trig" && e.direction === "in");
function dn(e, t, n) {
	let r = un(e.modules.find((e) => e.id === n).type), i = [
		{
			moduleId: t,
			portId: "pitch"
		},
		{
			moduleId: t,
			portId: "gate"
		},
		{
			moduleId: n,
			portId: r ? "trig" : "pitch"
		},
		...r ? [] : [{
			moduleId: n,
			portId: "gate"
		}]
	], a = {
		...e,
		cables: e.cables.filter((e) => !i.some((t) => gn(e.from, t) || gn(e.to, t)))
	};
	return r ? bn(a, i[1], i[2]) : bn(bn(a, i[0], i[2]), i[1], i[3]);
}
function fn(e, t) {
	let n = vn(e, {
		moduleId: t,
		portId: "pitch"
	}), r = vn(e, {
		moduleId: t,
		portId: "gate"
	});
	return !n && !r ? null : !n && r?.to.portId === "trig" || n && r && n.to.moduleId === r.to.moduleId && n.to.portId === "pitch" && r.to.portId === "gate" ? r.to.moduleId : "";
}
function pn(e, t) {
	let n = e.cables.filter((n) => n.from.moduleId === t && hn(e, n.from)?.kind === "gate").map((t) => e.modules.find((e) => e.id === t.to.moduleId));
	return n.length && n.every((e) => e && un(e.type)) ? n[0] : null;
}
var mn = (e) => Math.max(16, ...e.modules.filter((e) => e.type === "dictator").map((e) => w(e.params.length))), hn = (e, t) => {
	let n = e.modules.find((e) => e.id === t.moduleId);
	return n && Z[n.type].ports.find((e) => e.id === t.portId);
}, gn = (e, t) => e.moduleId === t.moduleId && e.portId === t.portId;
function _n(e, t) {
	let n = e.filter((e) => (e.copyOf ?? e.id) === (t.copyOf ?? t.id));
	return n.length > 1 ? n.indexOf(t) + 1 : null;
}
var vn = (e, t) => e.cables.find((e) => gn(e.from, t) || gn(e.to, t));
function yn(e, t, n) {
	let r = hn(e, t), i = hn(e, n);
	if (!r || !i) return "That socket no longer exists.";
	if (r.direction !== "out" || i.direction !== "in") return "Connect an output to an input.";
	if (r.kind !== i.kind) return `A ${r.kind.toUpperCase()} output needs a ${r.kind.toUpperCase()} input.`;
	if (e.cables.some((e) => gn(e.to, n))) return "That input already has a cable. Pull its plug out first.";
	if (e.cables.some((e) => gn(e.from, t))) return "That output jack already has a cable. Use its spare jack, or pull the plug out first.";
	let a = /* @__PURE__ */ new Set(), o = (n) => n === t.moduleId || !a.has(n) && (a.add(n), e.cables.filter((e) => e.from.moduleId === n).some((e) => o(e.to.moduleId)));
	return o(n.moduleId) ? "External feedback loops are not supported. Use ECHO’s feedback control." : null;
}
function bn(e, t, n, r = 1) {
	let i = yn(e, t, n);
	if (i) throw Error(i);
	return {
		...e,
		cables: [...e.cables, {
			id: Ht("cable"),
			from: t,
			to: n,
			amount: r
		}]
	};
}
function xn(e, t, n) {
	let r = hn(e, t), i = hn(e, n);
	return !r || !i || r.direction === i.direction ? null : r.direction === "out" ? {
		from: t,
		to: n
	} : {
		from: n,
		to: t
	};
}
function Sn(e, t, n, r = null) {
	if (!hn(e, t) || !hn(e, n)) return "That socket no longer exists.";
	let i = xn(e, t, n);
	return i ? yn(r ? {
		...e,
		cables: e.cables.filter((e) => e.id !== r)
	} : e, i.from, i.to) : "Connect an output to an input.";
}
function Cn(e, t, n, r) {
	if (!e.cables.find((e) => e.id === t)) throw Error("That cable no longer exists.");
	let i = Sn(e, n, r, t);
	if (i) throw Error(i);
	let a = xn(e, n, r);
	return {
		...e,
		cables: e.cables.map((e) => e.id === t ? {
			...e,
			...a
		} : e)
	};
}
function wn(e, t) {
	return Kt(e, t) || !e.modules.some((e) => e.id === t) ? e : Yt(e, e.modules.filter((e) => e.id !== t), e.cables.filter((e) => e.from.moduleId !== t && e.to.moduleId !== t));
}
function Tn(e, t, n) {
	let r = [...e.modules], i = r.findIndex((e) => e.id === t), a = i + n;
	return i < 0 || a < 0 || a >= r.length - 1 || Kt(e, t) ? e : ([r[i], r[a]] = [r[a], r[i]], Yt(e, r));
}
var En = (e, t) => (e >> t & 1) == 1;
function Dn(e, t, n = 0) {
	let r = Math.max(1, Math.min(16, Math.round(e))), i = Math.max(0, Math.min(r, Math.round(t))), a = Math.round(n);
	return Array.from({ length: r }, (e, t) => ((t - a) % r + r) % r * i % r < i);
}
function On(e, t, n) {
	let r = e.params;
	return [...Et].reverse().find((e) => En(r[Dt(t, e)] ?? 0, n)) ?? 1;
}
var kn = (e, t) => An(e, t).map((n) => [n, On(e, n, t % 16)]);
function An(e, t) {
	let n = Z[e.type].drum, r = e.params;
	return n ? n.voices.filter(({ id: i }) => {
		if (n.mode === "steps") return En(r[`${i}Pattern`], t % 16);
		let a = jn(e, i);
		return a[t % a.length];
	}).map((e) => e.id) : [];
}
function jn(e, t) {
	let n = e.params, r = n[`${t}Steps`];
	return n[`${t}Custom`] ? Array.from({ length: r }, (e, r) => En(n[`${t}Pattern`], r)) : Dn(r, n[`${t}Hits`], n[`${t}Shift`]);
}
function Mn(e, t, n) {
	let r = e.params[`${t}Custom`] ? e.params[`${t}Pattern`] : jn(e, t).reduce((e, t, n) => e | (t ? 1 << n : 0), 0);
	return {
		...e.params,
		[`${t}Custom`]: 1,
		[`${t}Pattern`]: r ^ 1 << n
	};
}
function Nn(e, t) {
	let n = e.params;
	if (n[`${t}Hits`]) return { [`${t}Custom`]: 0 };
	let r = n[`${t}Custom`] ? jn(e, t).filter(Boolean).length : 0;
	return {
		[`${t}Custom`]: 0,
		[`${t}Hits`]: r || Math.max(1, Math.round(n[`${t}Steps`] * 3 / 8))
	};
}
var Pn = (e, t) => !!e.params[`${t}Custom`] || !e.params[`${t}Hits`];
function Fn(e, t) {
	let n = Z[t.type].drum;
	return t.type === "performance" ? qt(e, t.id).some((e) => e.enabled) : t.type === "dictator" ? !!t.notes?.length || B.some((e) => tn(t, e).length) : n?.mode === "euclid" ? n.voices.some(({ id: e }) => jn(t, e).some(Boolean)) : Z[t.type].params.some((e) => e.pattern && t.params[e.id]);
}
function In(e, t) {
	let n = e.modules.find((e) => e.id === t);
	if (!n) return e;
	if (n.type === "performance") return Jt(e, t, qt(e, t).map((e) => ({
		...e,
		enabled: !1
	})));
	if (n.type === "dictator") return B.reduce((e, n) => rn(e, t, n, []), $t(e, t, []));
	let r = Z[n.type].drum;
	if (!r) return e;
	let i = Object.fromEntries(Z[n.type].params.filter((e) => e.pattern).map((e) => [e.id, 0]));
	if (r.mode === "euclid") for (let { id: e } of r.voices) Object.assign(i, {
		[`${e}Hits`]: 0,
		[`${e}Custom`]: 0
	});
	return {
		...e,
		modules: e.modules.map((e) => e.id === t ? {
			...e,
			params: {
				...e.params,
				...i
			}
		} : e)
	};
}
var Ln = (e) => [
	"performance",
	"dictator",
	"oscillator",
	"monarch",
	"oracle",
	"aurora",
	"prism",
	...vt,
	"strike",
	"noise",
	"boom",
	"punch",
	"orbit",
	"forge"
].includes(e), Rn = (e) => [
	"oracle",
	"aurora",
	"prism",
	...vt
].includes(e), zn = (e) => Bn(e) || !!Z[e].drum, Bn = (e) => e === "performance" || e === "dictator";
function Vn(e, t) {
	let n = /* @__PURE__ */ new Set([t]);
	for (let t of n) for (let r of e.cables) r.from.moduleId === t && hn(e, r.from)?.kind === "audio" && n.add(r.to.moduleId);
	return n;
}
function Hn(e, t) {
	let n = e.modules.find((e) => e.id === t);
	if (n && (Bn(n.type) || n.type === "skitter")) {
		let n = /* @__PURE__ */ new Set([t]);
		for (let t of n) for (let r of e.cables) r.from.moduleId === t && hn(e, r.from)?.kind !== "audio" && n.add(r.to.moduleId);
		return [...n].some((n) => n !== t && Hn(e, n));
	}
	let r = Vn(e, t);
	return e.modules.some((e) => e.type === "output" && r.has(e.id));
}
function Un(e, t, n, r = null) {
	let i = xn(e, t, n);
	if (!i) throw Error("Connect an output to an input.");
	if (!r) return bn(e, i.from, i.to);
	let a = e.cables.find((e) => e.id === r);
	return a && gn(a.from, i.from) && gn(a.to, i.to) ? e : Cn(e, r, i.from, i.to);
}
var Wn = {
	muted: /* @__PURE__ */ new Set(),
	soloed: /* @__PURE__ */ new Set()
}, Gn = (e, t) => `${e}:${t}`, Kn = (e, t) => `${e}:step:${t}`, qn = /* @__PURE__ */ new Set([
	"oscillator",
	"noise",
	"boom",
	"punch",
	"orbit",
	"monarch",
	"oracle",
	"aurora",
	"prism",
	...vt,
	"strike",
	"forge"
]), Jn = (e) => qn.has(e);
function Yn(e, t) {
	let n = /* @__PURE__ */ new Set([t]);
	for (let t of n) for (let r of e.cables) r.from.moduleId === t && hn(e, r.from)?.kind !== "audio" && n.add(r.to.moduleId);
	return n.delete(t), e.modules.filter((t) => qn.has(t.type) && [...Vn(e, t.id)].some((e) => n.has(e))).map((e) => e.id);
}
function Xn(e, t) {
	let n = new Set(e.modules.map((e) => e.id)), r = new Set([...t.soloed].filter((e) => n.has(e)));
	for (let t of r) for (let n of e.cables) n.from.moduleId === t && hn(e, n.from)?.kind !== "audio" && r.add(n.to.moduleId);
	let i = (t, n = /* @__PURE__ */ new Set()) => r.has(t) ? !0 : !n.has(t) && (n.add(t), e.cables.some((e) => e.from.moduleId === t && e.to.portId !== "chain" && i(e.to.moduleId, n)));
	return Object.fromEntries(e.modules.filter((e) => e.type !== "output").map((e) => [e.id, !t.muted.has(e.id) && (!r.size || !qn.has(e.type) || i(e.id))]));
}
var Zn = (e) => Z[e].drum?.voices.map((e) => e.id) ?? (e === "mixer" ? xt : []);
function Qn(e, t, n) {
	let r = Zn(e.type).some((t) => n.soloed.has(Gn(e.id, t)));
	return !n.muted.has(Gn(e.id, t)) && (!r || n.soloed.has(Gn(e.id, t)));
}
function $n(e, t, n) {
	return !n.muted.has(Kn(e, t)) && (!Array.from({ length: 16 }, (t, n) => Kn(e, n)).some((e) => n.soloed.has(e)) || n.soloed.has(Kn(e, t)));
}
function er(e, t, n) {
	let r = [], i = vn(e, {
		moduleId: t,
		portId: n
	});
	for (; i;) {
		let t = e.modules.find((e) => e.id === i.from.moduleId);
		if (!t || r.includes(t) || (r.unshift(t), qn.has(t.type) || t.type === "mixer")) break;
		let n = Z[t.type].ports.filter((e) => e.direction === "in" && e.kind === "audio");
		i = n.length === 1 ? vn(e, {
			moduleId: t.id,
			portId: n[0].id
		}) : void 0;
	}
	return r;
}
function tr(e, t) {
	let n = Z[t.type].name;
	return e.modules.filter((e) => e.type === t.type).length > 1 ? `${n} #${e.modules.findIndex((e) => e.id === t.id) + 1}` : n;
}
function nr(e, t) {
	return t.label ?? tr(e, t);
}
var rr = (e) => e.replace(/\s+/g, " ").trim();
function ir(e, t, n) {
	let r = rr(n).slice(0, 40).trimEnd() || void 0, i = e.modules.find((e) => e.id === t);
	return !i || i.label === r ? e : {
		...e,
		modules: e.modules.map((e) => {
			if (e.id !== t) return e;
			let n = { ...e };
			return r ? n.label = r : delete n.label, n;
		})
	};
}
function ar(e, t) {
	let n = [t], r = vn(e, {
		moduleId: t.id,
		portId: "chain"
	});
	for (; r;) {
		let t = e.modules.find((e) => e.id === r.from.moduleId);
		if (!t || n.includes(t)) break;
		n.unshift(t), r = vn(e, {
			moduleId: t.id,
			portId: "chain"
		});
	}
	return [...e.modules.filter((t) => (Bn(t.type) || t.type === "skitter") && Yn(e, t.id).some((e) => n.some((t) => t.id === e))), ...n.slice(0, -1)].filter((e) => e.label);
}
function or(e, t, n) {
	let r = er(e, t, n), i = n.toUpperCase(), a = r.length ? [...ar(e, r[0]), ...r] : r, o = a.filter((e) => e.label).at(-1);
	return {
		source: o?.label ?? (r.length ? tr(e, r[0]) : `Channel ${i}`),
		tooltip: a.map((t) => nr(e, t)).join(" → "),
		connected: r.length > 0,
		named: !!o,
		deviceId: (o ?? r[0])?.id
	};
}
function sr(e, t, n) {
	let r = new Set(e.muted), i = new Set(e.soloed), [a, o] = n === "muted" ? [r, i] : [i, r];
	return a.delete(t) || (a.add(t), o.delete(t)), {
		muted: r,
		soloed: i
	};
}
function cr(e, t) {
	return e.muted.has(t) ? sr(e, t, "soloed") : e.soloed.has(t) ? sr(e, t, "muted") : e;
}
var lr = (e, t) => t === e.id || t.startsWith(`${e.id}:`), ur = (e, t) => [...t.muted, ...t.soloed].some((t) => lr(e, t));
function dr(e, t) {
	return ur(t, e) ? {
		muted: new Set([...e.muted].filter((e) => !lr(t, e))),
		soloed: new Set([...e.soloed].filter((e) => !lr(t, e)))
	} : e;
}
var fr = [
	"Vintage Bass",
	"Vintage Lead",
	"Boom Bap",
	"Late Night Hip-Hop",
	"Roots Reggae",
	"Dub Session",
	"Positive Zions",
	"Recuerdos",
	"Trap Soul",
	"Broken Beat",
	"Orbit Percussion"
], pr = [
	"Neon Skyline",
	"Digital Boogie",
	"Midnight Ballad",
	"New Wave Motion",
	"Glass Arcade",
	"Analog Sunrise"
], mr = [
	"French Touch",
	"Distortion Disco",
	"Electro Pogo",
	"Electroclash"
], hr = [
	"High Dive",
	"Undertow",
	"Deep End"
], gr = [
	"Rust Machine",
	"Black Mass",
	"Bone Orchard"
], _r = [
	["EDM / House", [
		"House",
		"French Touch",
		"Distortion Disco",
		"Electro Pogo",
		"Electroclash"
	]],
	["Funk / Soul", [
		"Groove",
		"Digital Boogie",
		"Midnight Ballad",
		"Broken Beat"
	]],
	["Industrial / Rock", gr],
	["Reggae", [
		"Roots Reggae",
		"Dub Session",
		"Positive Zions",
		"Recuerdos"
	]],
	["Synthwave / 80s", [
		"Neon Skyline",
		"Vintage Lead",
		"New Wave Motion",
		"Glass Arcade",
		"Analog Sunrise"
	]],
	["Trap / Hip-Hop", [
		...hr,
		"Trap Soul",
		"Late Night Hip-Hop",
		"Boom Bap",
		"Vintage Bass"
	]],
	["Miscellaneous", ["Orbit Percussion"]]
];
_r.flatMap(([, e]) => e);
var vr = "Bone Orchard", yr = (e, t) => e.includes(t);
function br(e = vr) {
	if (yr(hr, e)) return Ae(e);
	if (yr(gr, e)) return Me(e);
	if (yr(mr, e)) return Se(e);
	if (yr(pr, e)) return be(e);
	if (yr(fr, e)) return _e(e);
	let t = e === "Groove" ? ["boom", "orbit"] : ["punch"], n = [
		"performance",
		"oscillator",
		"filter",
		"amplifier",
		"equalizer",
		"envelope",
		"lfo",
		"delay",
		...t,
		"output"
	].map((e) => Ut(e, e)), r = (e) => n.find((t) => t.type === e);
	e === "Groove" ? (r("oscillator").params.level = .85, Object.assign(r("envelope").params, {
		decay: .16,
		sustain: .3
	}), Object.assign(r("equalizer").params, {
		hpf: 35,
		lfGain: 1.5,
		lfFreq: 80,
		lfBell: 1,
		lmfGain: -5,
		lmfFreq: 250,
		lmfQ: .8,
		hmfGain: 4,
		hmfFreq: 1200,
		hmfQ: 1.1,
		lpf: 7e3,
		output: 3
	}), Object.assign(r("delay").params, {
		time: .319,
		feedback: .2,
		mix: .08
	}), Object.assign(r("boom").params, {
		kickTune: 46,
		kickDecay: .5,
		kickLevel: 1.3,
		snareTone: .6,
		snappy: .8,
		snareLevel: 1.3,
		snareLag: 12,
		hatPan: .3,
		hatLag: -5,
		bellPan: -.3,
		level: 1
	}), Object.assign(r("orbit").params, {
		level: .55,
		skinTone: .6,
		skinPan: -.35,
		woodPan: .4,
		sandPan: .25
	}), r("output").params.volume = .75) : (r("oscillator").params.wave = 3, Object.assign(r("filter").params, {
		cutoff: 900,
		resonance: 5
	}), Object.assign(r("envelope").params, {
		attack: .002,
		decay: .14,
		sustain: 0,
		release: .08
	}), Object.assign(r("equalizer").params, {
		hpf: 40,
		lfGain: 2,
		lfFreq: 70,
		lfBell: 1,
		lmfGain: -3,
		lmfFreq: 300,
		hmfGain: 2,
		hmfFreq: 2e3,
		lpf: 12e3
	}), r("delay").params.mix = .12);
	let i = [
		36,
		36,
		43,
		36,
		48,
		36,
		46,
		43,
		36,
		36,
		43,
		48,
		46,
		43,
		38,
		43
	], a = (t) => e === "House" ? t % 4 != 0 : t !== 1 && t !== 9, o = {
		version: 1,
		name: e,
		modules: n,
		cables: [],
		sequencer: {
			bpm: e === "Groove" ? 94 : 124,
			swing: e === "Groove" ? .12 : 0,
			steps: i.map((e, t) => ({
				enabled: a(t),
				note: e,
				velocity: t % 4 == 0 ? 1 : .75,
				gate: .65
			}))
		}
	}, s = ["delay", ...t];
	for (let [e, n, r, i, a] of [
		[
			"oscillator",
			"out",
			"filter",
			"in",
			1
		],
		[
			"filter",
			"out",
			"amplifier",
			"in",
			1
		],
		[
			"amplifier",
			"out",
			"equalizer",
			"in",
			1
		],
		[
			"equalizer",
			"out",
			"delay",
			"in",
			1
		],
		...t.map((e, t) => [
			s[t],
			"out",
			e,
			"chain",
			1
		]),
		[
			s.at(-1),
			"out",
			"output",
			"in",
			1
		],
		[
			"performance",
			"pitch",
			"oscillator",
			"pitch",
			1
		],
		[
			"performance",
			"gate",
			"envelope",
			"gate",
			1
		],
		[
			"envelope",
			"out",
			"amplifier",
			"cv",
			1
		],
		[
			"lfo",
			"out",
			"filter",
			"cv",
			.12
		]
	]) o = bn(o, {
		moduleId: e,
		portId: n
	}, {
		moduleId: r,
		portId: i
	}, a);
	return o;
}
function xr(e) {
	let t = `@@note-${Math.random().toString(36).slice(2)}@@`, n = /* @__PURE__ */ new Set(["notes", ...Object.values(Fe)]);
	return JSON.stringify(e, (e, r) => n.has(e) && Array.isArray(r) ? r.map((e) => `${t}${e.join(",")}`) : r, 2).replaceAll(RegExp(`"${t}([-\\d,]+)"`, "g"), "[$1]");
}
function Sr(e) {
	let t = e.cables.map((e) => JSON.stringify([
		e.from.moduleId,
		e.from.portId,
		e.to.moduleId,
		e.to.portId,
		e.amount
	])).sort();
	return JSON.stringify({
		name: e.name,
		modules: e.modules,
		sequencer: e.sequencer,
		cables: t
	});
}
function Cr(e) {
	if (e.length > 1e6) throw Error("Patch files must be smaller than 1 MB.");
	let t = JSON.parse(e), n = (e) => typeof e == "object" && !!e && !Array.isArray(e), r = () => {
		throw Error("This is not a valid Rackloose v1 patch.");
	}, i = (e) => !Array.isArray(e) || e.length !== 16 ? r() : e.map((e) => !n(e) || typeof e.enabled != "boolean" || typeof e.note != "number" || !Number.isInteger(e.note) || e.note < 24 || e.note > 96 || typeof e.velocity != "number" || !Number.isFinite(e.velocity) || e.velocity < 0 || e.velocity > 1 || typeof e.gate != "number" || !Number.isFinite(e.gate) || e.gate < .1 || e.gate > .95 ? r() : {
		enabled: e.enabled,
		note: e.note,
		velocity: e.velocity,
		gate: e.gate
	}), a = (e) => e === void 0 ? [] : !Array.isArray(e) || e.length > 2048 ? r() : T(e.map((e) => {
		if (!Array.isArray(e) || e.length !== 4 || !e.every((e) => Number.isInteger(e))) return r();
		let [t, n, i, a] = e;
		return t < 0 || t >= v || n < 1 || n > v || i < 0 || i > 127 || a < 1 || a > 127 ? r() : [
			t,
			n,
			i,
			a
		];
	})), o = (e, t) => {
		if (e === void 0) return {};
		if (!Array.isArray(e) || e.length > 4096) return r();
		let { min: n, max: i } = Pe[t], a = We(e.map((e) => {
			if (!Array.isArray(e) || e.length !== 2 || !e.every((e) => Number.isInteger(e))) return r();
			let [t, a] = e;
			return t < 0 || t >= v || a < n || a > i ? r() : [t, a];
		}));
		return a.length ? { [Fe[t]]: a } : {};
	};
	if (!n(t) || t.version !== 1 || typeof t.name != "string" || t.name.length > 100 || !Array.isArray(t.modules) || !Array.isArray(t.cables) || !n(t.sequencer) || t.modules.length < 1 || t.modules.length > 32 || t.cables.length > 128) return r();
	let s = /* @__PURE__ */ new Set(), c = (e) => {
		if (e === void 0) return {};
		if (typeof e != "string") return r();
		let t = rr(e);
		return t.length > 40 ? r() : t ? { label: t } : {};
	}, l = t.modules.map((e, t) => {
		if (!n(e) || typeof e.id != "string" || !/^[\w-]{1,80}$/.test(e.id) || s.has(e.id) || typeof e.type != "string" || !Object.hasOwn(Z, e.type) || !n(e.params)) return r();
		s.add(e.id);
		let l = e.type, u = e.params, d = Object.fromEntries(Z[l].params.map((e) => {
			let t = u[e.id] === void 0 ? e.legacyFrom !== void 0 && u[e.legacyFrom] !== void 0 ? u[e.legacyFrom] : e.legacyDefault : u[e.id];
			return typeof t != "number" || !Number.isFinite(t) || t < e.min || t > e.max || (e.choices || e.pattern) && !Number.isInteger(t) ? r() : [e.id, t];
		})), f = c(e.label);
		return l === "dictator" ? {
			id: e.id,
			type: l,
			params: d,
			notes: a(e.notes),
			...Object.assign({}, ...B.map((t) => o(e[Fe[t]], t))),
			...f
		} : l === "performance" && t > 0 ? {
			id: e.id,
			type: l,
			params: d,
			steps: i(e.steps),
			...f
		} : {
			id: e.id,
			type: l,
			params: d,
			...f
		};
	});
	if (l.reduce((e, t) => e + (t.notes?.length ?? 0), 0) > 8192 || l.reduce((e, t) => e + B.reduce((e, n) => e + tn(t, n).length, 0), 0) > 16384 || l.filter((e) => e.type === "output").length !== 1 || l.at(-1)?.type !== "output") return r();
	let u = t.sequencer;
	if (typeof u.bpm != "number" || !Number.isFinite(u.bpm) || u.bpm < 40 || u.bpm > 240 || typeof u.swing != "number" || !Number.isFinite(u.swing) || u.swing < 0 || u.swing > .6) return r();
	let d = i(u.steps), f = {
		version: 1,
		name: t.name,
		modules: l,
		cables: [],
		sequencer: {
			bpm: u.bpm,
			swing: u.swing,
			steps: d
		}
	}, p = /* @__PURE__ */ new Set();
	for (let e of t.cables) {
		if (!n(e) || typeof e.id != "string" || !/^[\w-]{1,80}$/.test(e.id) || p.has(e.id) || !n(e.from) || !n(e.to) || typeof e.from.moduleId != "string" || typeof e.from.portId != "string" || typeof e.to.moduleId != "string" || typeof e.to.portId != "string" || typeof e.amount != "number" || !Number.isFinite(e.amount) || e.amount < -1 || e.amount > 1) return r();
		p.add(e.id);
		let t = {
			moduleId: e.from.moduleId,
			portId: e.from.portId
		}, i = {
			moduleId: e.to.moduleId,
			portId: e.to.portId
		}, a = hn(f, t);
		if (a && f.cables.some((e) => gn(e.from, t))) {
			let e = Z[f.modules.find((e) => e.id === t.moduleId).type].ports.find((e) => (e.copyOf ?? e.id) === (a.copyOf ?? a.id) && !f.cables.some((n) => gn(n.from, {
				moduleId: t.moduleId,
				portId: e.id
			})));
			if (!e) continue;
			t.portId = e.id;
		}
		if (yn(f, t, i) || hn(f, t)?.kind !== "cv" && e.amount !== 1) return r();
		f = {
			...f,
			cables: [...f.cables, {
				id: e.id,
				from: t,
				to: i,
				amount: e.amount
			}]
		};
	}
	return f;
}
function wr(e, t) {
	try {
		let n = e.getItem(t);
		return {
			patch: n ? Cr(n) : null,
			error: null
		};
	} catch {
		return {
			patch: null,
			error: "Saved patch unavailable. You can still play and export patch files."
		};
	}
}
function Tr(e, t, n) {
	try {
		return e.setItem(t, xr(n)), null;
	} catch {
		return "Local save unavailable. Export a patch file to keep your work.";
	}
}
var Er = (e, t) => e.logarithmic ? Math.log(t / e.min) / Math.log(e.max / e.min) : (t - e.min) / (e.max - e.min), Dr = [
	"C",
	"C♯",
	"D",
	"D♯",
	"E",
	"F",
	"F♯",
	"G",
	"G♯",
	"A",
	"A♯",
	"B"
], Or = (e) => `${Dr[e % 12]}${Math.floor(e / 12) - 1}`, kr = class {
	notes = /* @__PURE__ */ new Map();
	press(e, t) {
		return this.notes.delete(e), this.notes.set(e, t), this.current;
	}
	release(e) {
		return this.notes.delete(e), this.current;
	}
	clear() {
		this.notes.clear();
	}
	has(e) {
		return this.notes.has(e);
	}
	get current() {
		return [...this.notes.values()].at(-1) ?? null;
	}
	get entries() {
		return [...this.notes];
	}
}, Ar = (e, t, n) => 60 / e / 4 * (n % 2 == 0 ? 1 + t : 1 - t);
function jr(e, t, n = 0) {
	let r = [], i = n;
	for (let n = 0; n < t * mn(e); n++) {
		let t = n % 16, a = Ar(e.sequencer.bpm, e.sequencer.swing, t);
		r.push({
			step: e.sequencer.steps[t],
			index: t,
			time: i,
			duration: a
		}), i += a;
	}
	return {
		events: r,
		duration: i - n
	};
}
var Mr = (e) => [...e].map((e) => e.charCodeAt(0) & 127), Nr = (e) => [
	e >>> 24 & 255,
	e >>> 16 & 255,
	e >>> 8 & 255,
	e & 255
];
function Pr(e) {
	let t = [e & 127];
	for (let n = e >>> 7; n > 0; n >>>= 7) t.unshift(n & 127 | 128);
	return t;
}
var Fr = (e, t) => [
	...Mr(e),
	...Nr(t.length),
	...t
], Ir = (e, t) => [
	255,
	e,
	...Pr(t.length),
	...t
];
function Lr(e, t) {
	let n = Math.round(6e7 / t), r = [
		0,
		...Ir(81, [
			n >> 16 & 255,
			n >> 8 & 255,
			n & 255
		]),
		0,
		...Ir(88, [
			4,
			2,
			24,
			8
		]),
		0,
		...Ir(47, [])
	], i = e.map((e) => {
		let { name: t, notes: n, channel: r = 0 } = e, i = (e, t) => {
			let { cc: n } = Pe[e];
			if (n !== null) return [
				176 | r,
				n,
				t & 127
			];
			let i = t - Pe.bend.min;
			return [
				224 | r,
				i & 127,
				i >> 7 & 127
			];
		}, a = [...n.flatMap(([e, t, n, i]) => [{
			tick: e,
			data: [
				144 | r,
				n,
				i
			],
			order: 2
		}, {
			tick: e + t,
			data: [
				128 | r,
				n,
				64
			],
			order: 0
		}]), ...B.flatMap((t) => (e[Fe[t]] ?? []).map(([e, n]) => ({
			tick: e,
			data: i(t, n),
			order: 1
		})))].sort((e, t) => e.tick - t.tick || e.order - t.order), o = 0, s = [0, ...Ir(3, Mr(t.replace(/[^\x20-\x7e]/g, "-").slice(0, 100)))];
		for (let e of a) s.push(...Pr(e.tick - o), ...e.data), o = e.tick;
		return Fr("MTrk", [
			...s,
			0,
			...Ir(47, [])
		]);
	});
	return new Uint8Array([
		...Fr("MThd", [
			0,
			1,
			...[e.length + 1].flatMap((e) => [e >> 8, e & 255]),
			3,
			192
		]),
		...Fr("MTrk", r),
		...i.flat()
	]);
}
var Rr = () => {
	throw Error("This MIDI file is damaged or not a MIDI file.");
};
function zr(e) {
	if (e.length > 1e6) throw Error("MIDI files must be smaller than 1 MB.");
	let t = new DataView(e.buffer, e.byteOffset, e.byteLength), n = (t) => String.fromCharCode(...e.subarray(t, t + 4));
	if (e.length < 14 || n(0) !== "MThd") return Rr();
	let r = t.getUint32(4), i = t.getUint16(8), a = t.getUint16(10), o = t.getUint16(12);
	if (r < 6 || i > 1 || 8 + r > e.length) return Rr();
	if (o & 32768) throw Error("MIDI files timed in SMPTE frames are not supported.");
	if (!o || a > 256) return Rr();
	let s = (e) => Math.round(e * 960 / o), c = null, l = 8 + r, u = 0, d = [];
	for (; l + 8 <= e.length && u < a;) {
		let r = n(l), i = t.getUint32(l + 4), a = l + 8 + i;
		if (a > e.length) return Rr();
		if (r === "MTrk") {
			u++;
			let t = l + 8, n = 0, r = 0, i = "", o = /* @__PURE__ */ new Map(), f = /* @__PURE__ */ new Map(), p = /* @__PURE__ */ new Map(), m = (e, t, r) => {
				let i = p.get(e) ?? /* @__PURE__ */ new Map(), a = i.get(t) ?? [];
				a.push([s(n), r]), i.set(t, a), p.set(e, i);
			}, h = () => t < a ? e[t++] : Rr(), g = () => {
				let e = 0;
				for (let t = 0; t < 4; t++) {
					let t = h();
					if (e = e * 128 + (t & 127), !(t & 128)) return e;
				}
				return Rr();
			}, _ = (e, t, n) => {
				let r = o.get(e * 128 + t)?.shift();
				if (r) {
					let i = f.get(e) ?? [];
					i.push([
						r.tick,
						Math.max(1, n - r.tick),
						t,
						r.velocity
					]), f.set(e, i);
				}
			};
			for (; t < a;) {
				n += g();
				let l = h();
				if (l === 255) {
					let n = h(), r = g();
					if (t + r > a) return Rr();
					let o = e.subarray(t, t + r);
					t += r, n === 3 && !i && (i = String.fromCharCode(...o).replace(/[^\x20-\x7e]/g, "").trim().slice(0, 100));
					let s = o[0] << 16 | o[1] << 8 | o[2];
					if (n === 81 && r === 3 && s > 0 && c === null && (c = Math.round(6e7 / s * 100) / 100), n === 47) break;
					continue;
				}
				if (l === 240 || l === 247) {
					let e = g();
					if (t += e, t > a) return Rr();
					continue;
				}
				if (l < 128) {
					if (!r) return Rr();
					t--, l = r;
				} else r = l;
				let u = l & 240, d = l & 15, f = h(), p = u === 192 || u === 208 ? 0 : h();
				if (f > 127 || p > 127) return Rr();
				if (u === 144 && p > 0) {
					let e = d * 128 + f;
					o.set(e, [...o.get(e) ?? [], {
						tick: s(n),
						velocity: p
					}]);
				} else u === 128 || u === 144 ? _(d, f, s(n)) : u === 224 ? m("bend", d, (p << 7 | f) + Pe.bend.min) : u === 176 && Ie.has(f) && m(Ie.get(f), d, p);
			}
			for (let e of o.keys()) for (; o.get(e)?.length;) _(Math.floor(e / 128), e % 128, s(n));
			for (let [e, t] of [...f].sort(([e], [t]) => e - t)) {
				let n = {
					name: i || `Track ${u}`,
					channel: e,
					notes: t.sort((e, t) => e[0] - t[0] || e[2] - t[2])
				};
				for (let t of B) {
					let r = p.get(t)?.get(e);
					r && (n[Fe[t]] = Ge(We(r)));
				}
				d.push(n);
			}
		}
		l = a;
	}
	return u < Math.min(a, 1) ? Rr() : {
		bpm: c,
		tracks: d
	};
}
function Br(e, t, n = {}) {
	let r = B.flatMap((e) => (n[Fe[e]] ?? []).filter(([, t]) => t !== Pe[e].rest)), i = [...e, ...r].reduce((e, [t]) => Math.max(e, t), 0), a = _.findIndex((e) => i < e * g), o = a < 0 ? _.length - 1 : a, s = C(o), c = /* @__PURE__ */ new Set(), l = [];
	for (let [t, n, r, i] of T(e)) t < 0 || t >= s || c.has(t * 128 + r) || (c.add(t * 128 + r), l.push([
		t,
		Math.max(1, Math.min(n, s - t)),
		r,
		Math.max(1, Math.min(127, i))
	]));
	let u = l.slice(0, Math.max(0, Math.min(y, t))), d = Object.fromEntries(B.map((e) => [e, it(e, n[Fe[e]] ?? [], s)]));
	return {
		notes: u,
		length: o,
		dropped: e.length - u.length,
		lanes: d
	};
}
// src/midiInput.ts
var Vr = () => typeof navigator < "u" && typeof navigator.requestMIDIAccess == "function";
function Hr(e) {
	if (e.length < 3) return null;
	let t = e[0] & 240, n = e[1], r = e[2];
	return n > 127 || r > 127 ? null : t === 144 ? r ? {
		on: !0,
		note: n,
		velocity: r
	} : {
		on: !1,
		note: n,
		velocity: 0
	} : t === 128 ? {
		on: !1,
		note: n,
		velocity: 0
	} : null;
}
function Ur(e) {
	if (e.length < 3 || e[1] > 127 || e[2] > 127) return null;
	let t = e[0] & 240;
	if (t === 224) return {
		kind: "bend",
		value: (e[2] << 7 | e[1]) - 8192
	};
	let n = t === 176 ? Ie.get(e[1]) : void 0;
	return n ? {
		kind: n,
		value: e[2]
	} : null;
}
async function Wr(e, t = () => {}, n = () => {}) {
	let r = await navigator.requestMIDIAccess({ sysex: !1 }), i = !1, a = () => {
		for (let t of r.inputs.values()) t.onmidimessage = (r) => {
			if (!r.data || i) return;
			let a = Hr(r.data), o = a ? null : Ur(r.data);
			a ? e({
				...a,
				timeStamp: r.timeStamp,
				input: t.name ?? t.id
			}) : o && n({
				...o,
				timeStamp: r.timeStamp
			});
		};
		t([...r.inputs.values()].filter((e) => e.state !== "disconnected").map((e) => e.name || e.id));
	};
	return r.onstatechange = () => {
		i || a();
	}, a(), () => {
		i = !0, r.onstatechange = null;
		for (let e of r.inputs.values()) e.onmidimessage = null;
	};
}
var Gr = () => ({
	past: [],
	future: [],
	key: null,
	at: 0
});
function Kr(e, t, n, r) {
	return n !== null && n === e.key && r - e.at < 1e3 && !e.future.length ? {
		...e,
		at: r
	} : {
		past: [...e.past, t].slice(-50),
		future: [],
		key: n,
		at: r
	};
}
function qr(e, t) {
	let n = e.past.at(-1);
	return n === void 0 ? null : {
		state: n,
		history: {
			past: e.past.slice(0, -1),
			future: [t, ...e.future],
			key: null,
			at: 0
		}
	};
}
function Jr(e, t) {
	let [n, ...r] = e.future;
	return n === void 0 ? null : {
		state: n,
		history: {
			past: [...e.past, t].slice(-50),
			future: r,
			key: null,
			at: 0
		}
	};
}
var Yr = "This browser could not save to My Presets. Export a file to keep your work.", Xr = 100, Zr = (e, t) => e.trim().toLocaleLowerCase() === t.trim().toLocaleLowerCase(), Qr = (e, t) => e.patch.name.localeCompare(t.patch.name, void 0, {
	sensitivity: "base",
	numeric: !0
}) || e.savedAt - t.savedAt;
function $r(e, t) {
	try {
		let n = e.getItem(t);
		if (!n) return {
			presets: [],
			error: null
		};
		let r = JSON.parse(n);
		if (typeof r != "object" || !r || !("presets" in r) || !Array.isArray(r.presets)) throw Error("Not a preset list");
		let i = [], a = /* @__PURE__ */ new Set();
		for (let e of r.presets.slice(0, 200)) try {
			if (typeof e != "object" || !e) continue;
			let { id: t, savedAt: n, patch: r } = e;
			if (typeof t != "string" || !/^[\w-]{1,80}$/.test(t) || a.has(t) || typeof n != "number" || !Number.isFinite(n)) continue;
			let o = Cr(JSON.stringify(r));
			if (i.some((e) => Zr(e.patch.name, o.name))) continue;
			a.add(t), i.push({
				id: t,
				savedAt: n,
				patch: o
			});
		} catch {}
		return {
			presets: i.sort(Qr),
			error: null
		};
	} catch {
		return {
			presets: [],
			error: "My Presets could not be read. Export files to keep your presets."
		};
	}
}
function ei(e, t, n) {
	try {
		return e.setItem(t, JSON.stringify({
			version: 1,
			presets: n
		})), null;
	} catch {
		return Yr;
	}
}
function ti(e, t) {
	return [...e.filter((e) => e.id !== t.id && !Zr(e.patch.name, t.patch.name)), t].sort(Qr);
}
var ni = (e, t, n) => e.find((e) => e.id !== n && Zr(e.patch.name, t));
function ri(e, t) {
	for (let n = 1;; n++) {
		let r = n === 1 ? "" : ` (${n})`, i = `${t.slice(0, Xr - r.length).trimEnd()}${r}`;
		if (!ni(e, i)) return i;
	}
}
function ii(e) {
	return e.trim().toLowerCase().replace(/[^a-z0-9_-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80).replace(/-+$/, "") || "rackloose-patch";
}
function ai(e, t) {
	return e ? t ? t.error ? {
		state: "failed",
		text: "Edited · not saved",
		detail: t.error
	} : {
		state: "saved",
		text: "Edited · saved locally",
		detail: "Your edits are kept in this browser and come back after a reload. Save adds them to My Presets."
	} : {
		state: "edited",
		text: "Edited",
		detail: ""
	} : {
		state: "clean",
		text: "",
		detail: ""
	};
}
// src/audio/hold.ts
var oi = /* @__PURE__ */ new WeakMap(), si = 64;
function ci(e, t, n) {
	let r = () => t, i = 0;
	for (let t of e) if (t.type === "ramp") {
		if (t.time > n) {
			let e = r(i);
			return e + (t.value - e) * (n - i) / (t.time - i);
		}
		r = () => t.value, i = t.time;
	} else {
		if (t.time > n) break;
		let e = r(t.time), a = t.time;
		r = t.type === "set" ? () => t.value : (n) => t.value + (e - t.value) * Math.exp(-(n - a) / t.constant), i = t.time;
	}
	return r(n);
}
function li(e, t) {
	if (typeof e.cancelAndHoldAtTime == "function" || oi.has(e)) return e;
	let n = [], { setValueAtTime: r, linearRampToValueAtTime: i, setTargetAtTime: a, cancelScheduledValues: o } = e, s, c = (r) => {
		s ??= e.value;
		let i = n.length;
		for (; i && n[i - 1].time > r.time;) i--;
		if (n.splice(i, 0, r), t && n.length > si) {
			let e = -1;
			for (let r = 0; r < n.length && n[r].time <= t.currentTime - 1; r++) n[r].type !== "ramp" && (e = r);
			e > 0 && (s = ci(n.slice(0, e), s, n[e].time), n.splice(0, e));
		}
	};
	return Object.assign(e, {
		setValueAtTime(t, n) {
			return c({
				type: "set",
				time: n,
				value: t,
				constant: 0
			}), r.call(e, t, n);
		},
		linearRampToValueAtTime(t, n) {
			return c({
				type: "ramp",
				time: n,
				value: t,
				constant: 0
			}), i.call(e, t, n);
		},
		setTargetAtTime(t, n, r) {
			return c({
				type: "target",
				time: n,
				value: t,
				constant: r
			}), a.call(e, t, n, r);
		},
		cancelScheduledValues(t) {
			return n.splice(0, n.length, ...n.filter((e) => e.time < t)), o.call(e, t);
		}
	}), oi.set(e, {
		events: n,
		hold: (t) => {
			let r = ci(n, s ?? e.value, t), i = n.find((e) => e.time >= t);
			e.cancelScheduledValues(t), i?.type === "ramp" ? e.linearRampToValueAtTime(r, t) : e.setValueAtTime(r, t);
		}
	}), e;
}
function ui(e, t) {
	if (typeof e.cancelAndHoldAtTime == "function") {
		e.cancelAndHoldAtTime(t);
		return;
	}
	let n = oi.get(e)?.hold;
	if (n) n(t);
	else {
		let n = e.value;
		e.cancelScheduledValues(t), e.setValueAtTime(n, t);
	}
}
// src/audio/drums.ts
var di = [
	205.3,
	304.4,
	369.6,
	522.7,
	540,
	800
], fi = (e) => 2 ** (e / 12);
function pi(e, t, n, { keep: r, start: i, noise: a }) {
	let o = /* @__PURE__ */ new Set(), s = /* @__PURE__ */ new Map(), c = (t = 0, i = n) => {
		let a = r(e.createGain());
		return a.gain.value = t, a.connect(i), a;
	}, l = /* @__PURE__ */ new Set(), u = (e, t, n) => {
		l.add(e), e.setValueAtTime(t, n);
	}, d = /* @__PURE__ */ new Map(), f = (t) => {
		let n = d.get(t);
		return n || (n = r(e.createStereoPanner()), n.channelCount = 1, n.channelCountMode = "explicit", n.connect(c(Math.SQRT2)), d.set(t, n)), n;
	}, p = (t, n, i = .7) => {
		let a = r(e.createBiquadFilter());
		return a.type = t, a.frequency.value = n, a.Q.value = i, a;
	}, m = (...e) => (e.reduce((e, t) => e.connect(t)), e.at(-1)), h = null, g = () => (h || (h = i(e.createBufferSource()), h.buffer = a, h.loop = !0), h), _ = (t, n) => {
		let a = r(e.createGain());
		return a.gain.value = n, {
			sum: a,
			oscillators: t.map((t) => {
				let n = i(e.createOscillator());
				return n.type = "square", n.frequency.value = t, n.connect(a), n;
			})
		};
	}, v = (e, t, ...n) => {
		let r = c(0, f(e)), i = n.map((e) => e.frequency.value);
		return m(t, ...n, r), {
			gain: r.gain,
			tune: (e, t) => n.forEach((n, r) => u(n.frequency, i[r] * e, t))
		};
	}, y = /* @__PURE__ */ new Map(), b = (t, n, r, i, a = 5e-4) => {
		li(t, e);
		let o = y.get(t) ?? [], s = o.filter((t) => t.time < e.currentTime).at(-1);
		y.set(t, [
			...s ? [s] : [],
			...o.filter((t) => t.time >= e.currentTime),
			{
				time: n,
				peak: r,
				decay: i,
				rise: a
			}
		].sort((e, t) => e.time - t.time)), t.setTargetAtTime(r, n, a), t.setTargetAtTime(0, n + a * 5, i / 4.6);
	}, x = (e, t) => e.setTargetAtTime(0, t, .003);
	function S(e) {
		if (o.delete(e)) {
			for (let t of [
				...e.sources,
				...e.nodes,
				e.vca
			]) t.disconnect();
			s.get(e.voice) === e && s.delete(e.voice);
		}
	}
	function C(t, n, r, i, a, c = f(t)) {
		let l = e.createGain(), u = [];
		l.gain.value = 0, li(l.gain, e), l.connect(c);
		let d = {
			voice: t,
			vca: l,
			nodes: u,
			sources: a(l, u),
			start: n,
			end: n + i * 1.25 + .05,
			naturalEnd: n + i * 1.25 + .05,
			decay: i
		};
		l.gain.setValueAtTime(0, n), l.gain.linearRampToValueAtTime(r, n + .0015), l.gain.setTargetAtTime(0, n + .0015, i / 4.6);
		for (let e of d.sources) e.start(n), e.stop(d.end);
		d.sources[0].onended = () => S(d), o.add(d);
		let p = s.get(t), [m, h] = p && p.start > n ? [d, p] : [p, d];
		if (s.set(t, h), m && o.has(m) && m.end > h.start) {
			m.vca.gain.setTargetAtTime(0, h.start, .002), m.end = h.start + .03, m.chokeAt = h.start;
			for (let e of m.sources) e.stop(m.end);
		}
	}
	let w = (t, n, r, i, a = 1) => {
		let o = e.createOscillator();
		if (o.type = r, o.frequency.value = i, a === 1) o.connect(t);
		else {
			let r = e.createGain();
			r.gain.value = a, o.connect(r).connect(t), n.push(r);
		}
		return o;
	}, T = (e, t, n, r, i) => {
		e.frequency.setValueAtTime(n * r, t), e.frequency.exponentialRampToValueAtTime(n, t + i);
	}, E = () => {};
	if (t === "boom") {
		let e = v("snare", g(), p("highpass", 1800)), t = v("rim", g(), p("highpass", 5e3)), n = v("clap", g(), p("bandpass", 1e3, 1.4)), r = _(di, .5).sum, i = p("highpass", 5e3), a = v("hat", r, p("bandpass", 1e4, 1), p("highpass", 7e3)), o = v("open", r, p("bandpass", 1e4, 1), p("highpass", 7e3)), s = v("crash", r, p("bandpass", 7e3, .5), i);
		m(g(), c(.35, i));
		let l = v("ride", _(di.map((e) => e * 1.13), .5).sum, p("bandpass", 4800, 2.5), p("highpass", 3e3)), u = _([540, 800], .5), d = v("bell", u.sum, p("bandpass", 2640, 1.4)), f = (e, t, n, r, i) => C(e, t, .9 * i, r, (e, r) => {
			let i = w(e, r, "sine", n), a = w(e, r, "triangle", n * 1.5, .15);
			return T(i, t, n, 1.6, .06), T(a, t, n * 1.5, 1.6, .06), [i, a];
		});
		E = (r, i, c) => {
			let p = c[`${r}Level`] ?? 1;
			if (r === "kick") C("kick", i, p, c.kickDecay, (e) => {
				let t = w(e, [], "sine", c.kickTune);
				return T(t, i, c.kickTune, 2, .025), [t];
			});
			else if (r === "snare") {
				let t = c.snareTone, n = fi(c.snareTune);
				C("snare", i, .55 * p, .65 * c.snareDecay, (e, r) => [w(e, r, "sine", 185 * n, 1 - .6 * t), w(e, r, "sine", 330 * n, .35 + .65 * t)]), b(e.gain, i, .6 * c.snappy * p, c.snareDecay);
			} else if (r === "rim") {
				let e = fi(c.rimTune);
				C("rim", i, .7 * p, c.rimDecay, (t, n) => [w(t, n, "triangle", 455 * e, .6), w(t, n, "triangle", 1667 * e)]), b(t.gain, i, .5 * p, .008 / .03 * c.rimDecay);
			} else if (r === "clap") {
				n.tune(Lt(c.clapTone, 3), i);
				for (let e of [
					0,
					.01,
					.021
				]) b(n.gain, i + e, 1.4 * p, .016, 4e-4);
				b(n.gain, i + .032, 1.4 * p, c.clapDecay);
			} else if (r === "hat") x(o.gain, i), a.tune(Lt(c.hatTone, 2), i), b(a.gain, i, 1.25 * p, c.hatDecay);
			else if (r === "open") o.tune(Lt(c.openTone, 2), i), b(o.gain, i, p, c.openDecay);
			else if (r === "lowTom") f("lowTom", i, 95 * fi(c.tomTune), c.tomDecay, p);
			else if (r === "highTom") f("highTom", i, 145 * fi(c.highTomTune), c.highTomDecay * .85, p);
			else if (r === "crash") s.tune(Lt(c.crashTone, 2), i), b(s.gain, i, .75 * p, c.crashDecay, .002);
			else if (r === "ride") l.tune(Lt(c.rideTone, 2), i), b(l.gain, i, .8 * p, c.rideDecay, .001);
			else if (r === "bell") {
				let e = fi(c.bellTune);
				u.oscillators.forEach((t, n) => t.frequency.setValueAtTime([540, 800][n] * e, i)), b(d.gain, i, .9 * p, c.bellDecay);
			}
		};
	} else if (t === "punch") {
		let t = c(1, f("kick")), n = r(e.createWaveShaper()), i = c(1, n), a = c(0, i);
		n.curve = Float32Array.from({ length: 1025 }, (e, t) => Math.tanh(2.2 * (t / 512 - 1)) / Math.tanh(2.2)), n.oversample = "2x", n.connect(t), m(g(), p("lowpass", 4e3), a);
		let o = p("lowpass", 6e3), s = v("snare", g(), p("highpass", 1200), o), l = v("clap", g(), p("bandpass", 1100, 1.6)), d = r(e.createGain());
		m(_(di.map((e) => e * 1.5), .5).sum, d), m(g(), c(.35, d));
		let h = v("hat", d, p("highpass", 7500)), y = v("open", d, p("highpass", 7500));
		E = (e, n, r) => {
			let c = r[`${e}Level`] ?? 1;
			if (e === "kick") u(t.gain, c, n), C("kick", n, 1, r.kickDecay, (e) => {
				let t = w(e, [], "sine", r.kickTune), i = t.frequency;
				return i.setValueAtTime(r.kickTune * 5, n), i.exponentialRampToValueAtTime(r.kickTune * 1.3, n + .03), i.exponentialRampToValueAtTime(r.kickTune, n + .16), [t];
			}, i), b(a.gain, n, .7 * r.kickClick, .012);
			else if (e === "snare") {
				let e = fi(r.snareTune);
				C("snare", n, .5 * c, .11 / .18 * r.snareDecay, (t, r) => [180, 330].map((i, a) => {
					let o = w(t, r, "triangle", i * e, a ? .6 : 1);
					return T(o, n, i * e, 1.15, .02), o;
				})), u(o.frequency, 3e3 + 7e3 * r.snareTone, n), b(s.gain, n, .75 * r.snappy * c, r.snareDecay);
			} else if (e === "clap") {
				l.tune(Lt(r.clapTone, 3), n);
				for (let e of [
					0,
					.011,
					.022
				]) b(l.gain, n + e, 1.5 * c, .018, 4e-4);
				b(l.gain, n + .033, 1.5 * c, r.clapDecay);
			} else e === "hat" ? (x(y.gain, n), h.tune(Lt(r.hatTone, 2), n), b(h.gain, n, .9 * c, r.hatDecay)) : e === "open" && (y.tune(Lt(r.openTone, 2), n), b(y.gain, n, .75 * c, r.openDecay));
		};
	} else if (t === "orbit") {
		let e = p("bandpass", 6500, 1.2), t = c(0, f("sand")), n = p("highpass", 4500), r = c(0, f("shaker"));
		m(g(), e, p("highpass", 3e3), t), m(g(), n, r), E = (i, a, o) => {
			let s = fi(o.pitch + o[`${i}Tune`]), c = o[`${i}Decay`], l = o[`${i}Level`], d = o[`${i}Tone`];
			i === "skin" || i === "tom" ? C(i, a, (i === "skin" ? .8 : .95) * l, c, (e, t) => {
				let n = (i === "skin" ? 196 : 98) * s, r = w(e, t, "sine", n), o = w(e, t, "sine", n * (i === "skin" ? 311 / 196 : 1.5), d * .5);
				return T(r, a, n, i === "skin" ? 1.4 : 2.2, .035), T(o, a, n * (i === "skin" ? 311 / 196 : 1.5), 1.4, .035), [r, o];
			}) : i === "wood" ? C("wood", a, .6 * l, c, (e, t) => {
				let n = w(e, t, "sine", 1450 * s), r = w(e, t, "sine", 3915 * s, d * .6);
				return T(n, a, 1450 * s, 1.05, .005), [n, r];
			}) : i === "sand" ? (u(e.frequency, Math.min(18e3, 6500 * s * (.5 + d)), a), b(t.gain, a, .9 * l, c, .004)) : i === "shaker" ? (u(n.frequency, Math.min(16e3, (1500 + d * 6e3) * s), a), b(r.gain, a, .65 * l, c, .008)) : i === "metal" && C("metal", a, .3 * l, c, (e, t) => [
				440,
				623,
				1067,
				1573
			].map((n, r) => w(e, t, r ? "sine" : "triangle", n * s, r ? .15 + d * .7 : 1)));
		};
	}
	return {
		trigger(e, t, n, r = 1) {
			u(f(e).pan, n[`${e}Pan`] ?? 0, t), E(e, t, r === 1 ? n : {
				...n,
				[`${e}Level`]: (n[`${e}Level`] ?? 1) * r
			});
		},
		cancelScheduled(e) {
			for (let t of [...o]) if (t.start >= e) {
				for (let n of t.sources) n.stop(e);
				S(t);
			}
			s.clear();
			for (let t of o) {
				if (t.chokeAt !== void 0 && t.chokeAt >= e) {
					ui(t.vca.gain, e), t.vca.gain.setTargetAtTime(0, e, t.decay / 4.6), t.end = t.naturalEnd, t.chokeAt = void 0;
					for (let e of t.sources) e.stop(t.end);
				}
				(!s.has(t.voice) || s.get(t.voice).start < t.start) && s.set(t.voice, t);
			}
			for (let t of l) t.cancelScheduledValues(e);
			for (let [t, n] of y) {
				let r = n.filter((t) => t.time < e).at(-1);
				ui(t, e), r ? t.setTargetAtTime(0, Math.max(e, r.time + r.rise * 5), r.decay / 4.6) : t.setValueAtTime(0, e), y.set(t, r ? [r] : []);
			}
		},
		dispose() {
			for (let e of o) for (let t of e.sources) t.stop();
			for (let e of [...o]) S(e);
			s.clear();
		}
	};
}
// src/audio/strike.ts
var mi = 28e3, hi = /* @__PURE__ */ new Map();
function gi(e) {
	let t = hi.get(e);
	if (t) return t;
	let n = X.findIndex((t) => t.id === e);
	if (n < 0) throw Error(`Unknown STRIKE voice: ${e}`);
	let r = [
		"crash",
		"ride",
		"open"
	].includes(e), i = Math.ceil(mi * (r ? 3 : 1.5)), a = new Float32Array(i), o = 7103 + n * 197, s = 0, c = 0, l = 0, u = (e, t) => Math.sin(2 * Math.PI * e * t), d = {
		lowTom: 100,
		midTom: 142,
		highTom: 195,
		lowConga: 210,
		highConga: 310
	};
	for (let t = 0; t < i; t++) {
		o ^= o << 13, o ^= o >>> 17, o ^= o << 5;
		let n = (o >>> 0) / 2 ** 31 - 1, r = t / mi;
		s = .65 * s + .35 * n;
		let f = n - c;
		c = n;
		let p = 0;
		if (e === "kick") l += 2 * Math.PI * (54 + 120 * Math.exp(-r * 80)) / mi, p = Math.sin(l) * Math.exp(-r * 9) + .28 * s * Math.exp(-r * 170) + .1 * u(105, r) * Math.exp(-r * 25);
		else if (e === "snare") p = (.55 * u(185, r) + .28 * u(331, r)) * Math.exp(-r * 25) + .75 * (n - s) * Math.exp(-r * 15);
		else if (e === "rim") p = (u(420, r) + .65 * u(1750, r) + .35 * u(3100, r)) * Math.exp(-r * 85) + n * .25 * Math.exp(-r * 300);
		else if (e === "clap") {
			let e = [
				0,
				.011,
				.024
			].reduce((e, t) => e + (r >= t ? Math.exp(-(r - t) * 230) : 0), 0);
			p = (n - s) * (e + (r > .035 ? .65 * Math.exp(-(r - .035) * 16) : 0));
		} else if (e in d) {
			let t = d[e], n = e.includes("Conga");
			l += 2 * Math.PI * t * (1 + .55 * Math.exp(-r * 55)) / mi, p = (Math.sin(l) + .3 * u(t * (n ? 2.14 : 1.59), r)) * Math.exp(-r * (n ? 14 : 8)) + .22 * s * Math.exp(-r * 95);
		} else if (e === "bell") p = (u(540, r) + .65 * u(800, r) + .22 * u(1620, r)) * Math.exp(-r * 11);
		else {
			let t = [
				3421,
				4517,
				5683,
				7129,
				9181
			].reduce((t, n, i) => t + u(n * (e === "ride" ? .68 : 1), r) / (i + 2), 0), n = e === "hat" ? 34 : e === "open" ? 5 : e === "crash" ? 1.8 : e === "ride" ? 2.3 : e === "cabasa" ? 32 : 16;
			p = ((e === "cabasa" ? 0 : .4) * t + (e === "ride" ? .2 : .65) * f) * Math.exp(-r * n), e === "tambourine" && (p *= .65 + .35 * u(85, r)), e === "crash" && (p *= Math.min(1, r * 180));
		}
		let m = Math.tanh(p), h = Math.sign(m) * Math.log1p(255 * Math.abs(m)) / Math.log(256), g = Math.round(h * 127) / 127;
		a[t] = Math.sign(g) * Math.expm1(Math.abs(g) * Math.log(256)) / 255 * Math.min(1, t / 12) * Math.min(1, (i - 1 - t) / 128);
	}
	return hi.set(e, a), a;
}
var _i = {
	rate: mi,
	sample: gi,
	chokedBy: { open: ["hat"] }
}, vi = (e, t) => yi(e, t, _i);
function yi(e, t, { rate: n, sample: r, chokedBy: i = {}, peak: a = 1.6, tone: o = (e) => 700 * 20 ** e }) {
	let s = /* @__PURE__ */ new Map(), c = /* @__PURE__ */ new Set(), l = (e) => [e, ...i[e] ?? []], u = (e) => {
		if (c.delete(e)) for (let t of [
			e.source,
			e.gain,
			e.filter,
			e.pan
		]) t.disconnect();
	};
	function d(t) {
		let n = e.currentTime, r = /* @__PURE__ */ new Map();
		for (let e of c) {
			let t = r.get(e.voice) ?? [];
			t.push(e), r.set(e.voice, t);
		}
		for (let e of r.values()) e.sort((e, t) => e.start - t.start);
		for (let [e, i] of r) if (!t || l(e).includes(t)) for (let t of i) {
			let i = l(e).flatMap((e) => r.get(e) ?? []).filter((n) => n.start > t.start || n.voice !== e && n.start === t.start).reduce((e, t) => !e || t.start < e.start ? t : e, void 0)?.start ?? Infinity, a = t.gain.gain, o = (e) => t.peak * Math.min(1, Math.max(0, e - t.start) / .001) * Math.exp(-Math.max(0, e - t.start - .001) * 4.6 / t.decay);
			a.cancelScheduledValues(n), n < t.start + .001 ? (a.setValueAtTime(o(n), n), a.setValueAtTime(0, Math.max(n, t.start)), a.linearRampToValueAtTime(t.peak, t.start + .001)) : a.setValueAtTime(i < n ? o(i) * Math.max(0, 1 - (n - i) / .004) : o(n), n), a.setTargetAtTime(0, Math.max(n, t.start + .001), t.decay / 4.6), i >= n && i < t.end && (a.cancelScheduledValues(i), a.setValueAtTime(o(i), i), a.linearRampToValueAtTime(0, i + .004)), t.source.stop(Math.max(n, Math.min(t.end, i + .005)));
		}
	}
	return {
		trigger(i, l, f, p = 1) {
			let m = s.get(i);
			if (!m) {
				let t = r(i);
				m = e.createBuffer(1, t.length, n), m.copyToChannel(new Float32Array(t), 0), s.set(i, m);
			}
			let h = e.createBufferSource(), g = e.createGain(), _ = e.createBiquadFilter(), v = e.createStereoPanner();
			h.buffer = m, h.playbackRate.value = 2 ** (f[`${i}Tune`] / 12), _.type = "lowpass", _.frequency.value = Math.min(2e4, o(f[`${i}Tone`])), _.Q.value = -3.01, v.pan.value = f[`${i}Pan`], g.gain.value = 0, h.connect(_).connect(g).connect(v).connect(t);
			let y = {
				voice: i,
				start: l,
				end: l + Math.min(m.duration / h.playbackRate.value, f[`${i}Decay`] * 2) + .01,
				peak: f[`${i}Level`] * a * p,
				decay: f[`${i}Decay`],
				source: h,
				gain: g,
				filter: _,
				pan: v
			};
			h.onended = () => u(y), c.add(y), h.start(l), d(i);
		},
		cancelScheduled(e) {
			for (let t of [...c]) t.start >= e && (t.source.stop(e), u(t));
			d();
		},
		dispose() {
			for (let e of [...c]) e.source.stop(), u(e);
			s.clear();
		}
	};
}
// src/audio/poly.ts
var bi = .005;
function xi(e, t, n = (e) => e) {
	let r = () => {
		let n = t(e.createConstantSource());
		return n.offset.value = 0, li(n.offset, e), n;
	}, i = r(), a = r();
	return {
		bend: i,
		mod: a,
		move: (t, r, o, s = !1) => {
			if (t !== "bend" && t !== "mod") return;
			let c = (t === "bend" ? i : a).offset, l = Math.max(o, e.currentTime);
			s && ui(c, l), c.setTargetAtTime(t === "bend" ? Math.max(-1, Math.min(1, r)) : n(Math.max(0, Math.min(1, r))), l, bi);
		}
	};
}
function Si(e, t) {
	let n = !1, r;
	return (i, a) => {
		if (clearTimeout(r), r = void 0, i && !n) e.connect(t), n = !0;
		else if (!i && n) {
			let i = () => {
				r = void 0, n = !1;
				try {
					e.disconnect(t);
				} catch {}
			};
			a ? i() : r = setTimeout(i, 100);
		}
	};
}
var Ci = class {
	voices;
	constructor(e = 5) {
		this.voices = Array.from({ length: e }, () => ({
			key: null,
			start: -Infinity,
			releaseAt: -Infinity,
			freeAt: -Infinity
		}));
	}
	allocate(e, t = /* @__PURE__ */ new Set()) {
		let n = this.voices.map((e, t) => ({
			voice: e,
			index: t
		})).filter(({ index: e }) => !t.has(e)), r = (e, t) => e.reduce((e, n) => t(n.voice) < t(e.voice) ? n : e).index, i = n.filter(({ voice: t }) => t.freeAt <= e), a = n.filter(({ voice: t }) => t.releaseAt <= e);
		return i.length ? r(i, (e) => e.freeAt) : a.length ? r(a, (e) => e.releaseAt) : r(n, (e) => e.start);
	}
	start(e, t, n) {
		Object.assign(this.voices[e], {
			key: t,
			start: n,
			releaseAt: Infinity,
			freeAt: Infinity
		});
	}
	release(e, t, n) {
		return this.voices.flatMap((r, i) => {
			if (n !== void 0 && r.key !== n || r.releaseAt <= e) return [];
			let a = r.start > e;
			return Object.assign(r, {
				start: Math.min(r.start, e),
				releaseAt: e,
				freeAt: e + t
			}), [{
				index: i,
				pending: a
			}];
		});
	}
}, wi = (e, t) => Math.sin(2 * Math.PI * e * t);
function Ti(e, t, n) {
	let r = new Float32Array(Math.ceil(e * t));
	return {
		data: r,
		each(t) {
			let i = n, a = 0;
			for (let n = 0; n < r.length; n++) {
				i ^= i << 13, i ^= i >>> 17, i ^= i << 5;
				let o = (i >>> 0) / 2 ** 31 - 1;
				a = .7 * a + .3 * o, r[n] = t(n / e, {
					noise: o,
					low: a,
					high: o - a,
					sin: wi
				}) * Math.min(1, n / 8) * Math.min(1, (r.length - 1 - n) / 256);
			}
		}
	};
}
function Ei(e, t) {
	let n = 0;
	for (let t of e) n = Math.max(n, Math.abs(t));
	if (n > 0) for (let r = 0; r < e.length; r++) e[r] *= t / n;
}
// src/audio/forge.ts
var Di = 44100, Oi = /* @__PURE__ */ new Map();
function ki(e, t, n, r) {
	let i = r, a = () => (i = i * 16807 % 2147483647, i / 2147483647);
	return Array.from({ length: e }, () => ({
		frequency: t * (n / t) ** a(),
		level: .4 + a(),
		decay: .6 + a(),
		phase: a() * 2 * Math.PI
	}));
}
function Ai(e) {
	let t = Oi.get(e);
	if (t) return t;
	let n = Tt.findIndex((t) => t.id === e);
	if (n < 0) throw Error(`Unknown FORGE voice: ${e}`);
	let { data: r, each: i } = Ti(Di, {
		crash: 4,
		china: 3,
		ride: 4,
		open: 2,
		anvil: 2,
		lowTom: 1.6,
		highTom: 1.3,
		kick: 1.2,
		snare: 1
	}[e] ?? .5, 9241 + n * 173), a = {
		hat: [
			26,
			3e3,
			14e3
		],
		pedal: [
			26,
			3e3,
			14e3
		],
		open: [
			30,
			2600,
			13e3
		],
		crash: [
			44,
			1800,
			12500
		],
		china: [
			40,
			1100,
			9e3
		],
		ride: [
			28,
			2400,
			11e3
		]
	}[e], o = a ? ki(a[0], a[1], a[2], 77 + n * 31) : [], s = o.map((e) => Math.sin(e.phase)), c = o.map((e) => Math.cos(e.phase)), l, u = (e, t) => {
		l ??= o.map((e) => ({
			cos: Math.cos(2 * Math.PI * e.frequency / Di),
			sin: Math.sin(2 * Math.PI * e.frequency / Di),
			fall: Math.exp(-t * e.decay / Di)
		}));
		let n = 0;
		for (let e = 0; e < o.length; e++) {
			let { cos: t, sin: r, fall: i } = l[e], a = s[e], u = c[e];
			n += o[e].level * a, s[e] = (a * t + u * r) * i, c[e] = (u * t - a * r) * i;
		}
		return n / o.length;
	}, d = 0, f = 0;
	return i((t, { noise: n, high: r, sin: i }) => {
		if (f = .55 * f + .45 * r, e === "kick") {
			d += 2 * Math.PI * (52 + 88 * Math.exp(-t * 35)) / Di;
			let e = Math.sin(d) * Math.exp(-t * 6.5), n = r * Math.exp(-t * 600) + .5 * i(3200, t) * Math.exp(-t * 300);
			return Math.tanh(2.6 * (e + .55 * n));
		}
		if (e === "snare") {
			let e = i(190, t) * Math.exp(-t * 22) + .6 * i(287, t) * Math.exp(-t * 28) + .35 * i(412, t) * Math.exp(-t * 35), r = f * Math.exp(-t * 10), a = n * Math.exp(-t * 220);
			return Math.tanh(1.9 * (.7 * e + 1.1 * r + .6 * a));
		}
		return e === "lowTom" || e === "highTom" ? (d += 2 * Math.PI * (e === "lowTom" ? 82 : 132) * (1 + .3 * Math.exp(-t * 30)) / Di, Math.tanh(1.5 * ((Math.sin(d) + .25 * Math.sin(1.52 * d)) * Math.exp(-t * (e === "lowTom" ? 4.5 : 5.5)) + .4 * r * Math.exp(-t * 300)))) : e === "anvil" ? [
			[1, 4],
			[2.76, 6],
			[5.4, 9],
			[8.93, 13]
		].reduce((e, [n, r], a) => e + i(520 * n, t) * Math.exp(-t * r) / (a + 1), 0) + .6 * r * Math.exp(-t * 500) : e === "hat" ? .7 * u(t, 40) + .55 * f * Math.exp(-t * 55) + .5 * r * Math.exp(-t * 900) : e === "pedal" ? (.6 * u(t, 30) + .4 * f * Math.exp(-t * 35)) * Math.min(1, t * 400) : e === "open" ? .7 * u(t, 3.2) + .45 * f * Math.exp(-t * 4.5) + .4 * r * Math.exp(-t * 700) : e === "crash" ? (.8 * u(t, 1.3) + .6 * f * Math.exp(-t * 2.2)) * Math.min(1, t * 250) : e === "china" ? (.8 * u(t, 2.2) * (1 + .6 * i(370, t)) + .6 * f * Math.exp(-t * 3)) * Math.min(1, t * 300) : .55 * u(t, 1.1) + (.5 * i(3150, t) + .35 * i(4270, t)) * Math.exp(-t * 4) + .15 * f * Math.exp(-t * 2) + .4 * r * Math.exp(-t * 800);
	}), Ei(r, .9), Oi.set(e, r), r;
}
function ji(e) {
	let t = e.createBuffer(2, Math.ceil(e.sampleRate * .34), e.sampleRate), n = 31337;
	for (let r = 0; r < 2; r++) {
		let i = t.getChannelData(r);
		for (let t = 0; t < i.length; t++) {
			n ^= n << 13, n ^= n >>> 17, n ^= n << 5;
			let r = t / e.sampleRate;
			i[t] = ((n >>> 0) / 2 ** 31 - 1) * Math.exp(-r * 3) * Math.min(1, (i.length - 1 - t) / 64) * .35;
		}
	}
	return t;
}
var Mi = {
	rate: Di,
	sample: Ai,
	chokedBy: { open: ["hat", "pedal"] },
	peak: 1.4,
	tone: (e) => 1200 * 16 ** e
};
function Ni(e, t, n) {
	let r = n(e.createGain()), i = n(e.createGain()), a = n(e.createWaveShaper()), o = n(e.createGain()), s = n(e.createConvolver()), c = n(e.createGain());
	a.curve = Float32Array.from({ length: 2049 }, (e, t) => {
		let n = (t / 1024 - 1) * 6;
		return Math.max(-1, Math.min(1, n > 0 ? Math.tanh(n) : Math.tanh(1.4 * n) * .9));
	}), a.oversample = "2x", r.connect(i).connect(t), a.connect(o).connect(t), s.buffer = ji(e), s.connect(c).connect(t);
	let l = Si(r, a), u = Si(i, s), d = 0, f, p = () => {
		d < Tt.length && (Ai(Tt[d++].id), f = setTimeout(p, 0));
	};
	f = setTimeout(p, 0);
	let m = !1;
	return {
		input: r,
		classic: () => yi(e, r, Mi),
		dispose() {
			clearTimeout(f);
		},
		apply(t) {
			let n = (t, n) => {
				m ? t.setTargetAtTime(n, e.currentTime, .01) : t.value = n;
			};
			l(t.drive > 0, !m), u(t.room > 0, !m), n(i.gain, 1 - .45 * t.drive), n(o.gain, .75 * t.drive), n(c.gain, t.room * .9), m = !0;
		}
	};
}
// src/audio/prism-processor.js?raw
var Pi = "/** Self-contained phase-modulation DSP, imported directly by tests and as inline source by the worklet loader. */\nexport const ALGORITHMS = [\n  {inputs: [[1], [], [3], [], [5], []], carriers: [0, 2, 4]},\n  {inputs: [[1], [2], [], [4], [5], []], carriers: [0, 3]},\n  {inputs: [[1], [2], [3], [4], [5], []], carriers: [0]},\n  {inputs: [[3], [3], [3], [4, 5], [], []], carriers: [0, 1, 2]},\n  {inputs: [[1, 2], [3], [4], [], [5], []], carriers: [0]},\n  {inputs: [[], [], [], [], [], []], carriers: [0, 1, 2, 3, 4, 5]},\n];\nconst TAU = 2 * Math.PI, QUANTUM = 128;\n/** Blocks a voice's ladder keeps running after the voice ends, so its tail rings out (about 23 ms). */\nconst FILTER_TAIL = 8;\n/** The gain that matches the Ladder filter's level to Off at PRISM's default settings. */\nexport const FILTER_LEVEL = 1.02;\n/** How far the mod wheel lifts Brightness at full Mod range on EG bias, and how deep its tremolo goes on Amp. */\nexport const EG_BIAS = 1.5, TREMOLO = 0.5;\n/**\n * `makeFilter`, when given, makes one Rust ladder (a LadderDSP) per voice for the Filter section; without it PRISM plays\n * unfiltered, as it did before the section existed.\n */\nexport class PrismDSP {\n  constructor(rate, makeFilter) {\n    this.rate = rate; this.events = []; this.params = {}; this.level = 0; this.disposed = false;\n    this.makeFilter = makeFilter; this.filters = []; this.wet = 0; this.fade = 1 - Math.exp(-1 / (0.008 * rate));\n    if (makeFilter) {\n      this.voiceOut = Array.from({length: 16}, () => new Float32Array(QUANTUM));\n      this.voiceDetune = Array.from({length: 16}, () => new Float32Array(QUANTUM));\n      this.used = new Uint8Array(16); this.tails = new Uint8Array(16);\n      this.dry = new Float32Array(QUANTUM); this.wets = new Float32Array(QUANTUM); this.levels = new Float32Array(QUANTUM);\n    }\n    this.voices = Array.from({length: 16}, () => ({key: null, start: -Infinity, released: -Infinity, free: -Infinity,\n      phase: new Float64Array(6), env: new Float64Array(6), stage: new Uint8Array(6), attackStep: new Float64Array(6), releaseStep: new Float64Array(6), values: new Float64Array(6), frequency: 0, velocity: 1, feedback: 0, lastFeedback: 0}));\n  }\n  enqueue(event) {\n    if (event.type === 'off') this.events = this.events.filter(e => !(e.time >= event.time && (event.key === undefined || e.key === event.key) && (e.type === 'on' || e.type === 'off')));\n    this.events.push(event); this.events.sort((a, b) => a.time - b.time);\n  }\n  release(time, key) {\n    for (const v of this.voices) if (v.key !== null && (key === undefined || v.key === key) && v.released === Infinity) {\n      v.released = time; v.free = time + Math.max(...this.ops.map(o => o.release));\n      for (let i = 0; i < 6; i++) {v.stage[i] = 3; v.releaseStep[i] = v.env[i] / (this.ops[i].release * this.rate);}\n    }\n  }\n  apply(event) {\n    if (event.type === 'params') {\n      this.params = event.params;\n      this.ops = Array.from({length: 6}, (_, i) => {const id = `op${i + 1}`, p = this.params; return {\n        ratio: p[`${id}Ratio`] * 2 ** (p[`${id}Detune`] / 1200), level: p[`${id}Level`], attack: p[`${id}Attack`],\n        decay: Math.exp(-1 / (p[`${id}Decay`] * this.rate / 4)), sustain: p[`${id}Sustain`], release: p[`${id}Release`],\n      };});\n    } else if (event.type === 'off') this.release(event.time, event.key);\n    else if (event.type === 'on' && this.ops) {\n      this.release(event.time, event.key);\n      const taken = new Set();\n      for (const note of event.notes) {\n        const available = this.voices.filter(v => !taken.has(v));\n        const silent = available.filter(v => v.free <= event.time), released = available.filter(v => v.released <= event.time);\n        const candidates = silent.length ? silent : released.length ? released : available;\n        const field = silent.length ? 'free' : released.length ? 'released' : 'start';\n        const v = candidates.reduce((a, b) => b[field] < a[field] ? b : a);\n        taken.add(v);\n        if (v.free <= event.time) {v.phase.fill(0); v.env.fill(0); v.feedback = 0; v.lastFeedback = 0;}\n        v.key = event.key; v.start = event.time; v.free = Infinity; v.released = Infinity;\n        v.frequency = 440 * 2 ** ((note - 69) / 12); v.cents = (note - 60) * 100; v.velocity = event.velocity;\n        for (let i = 0; i < 6; i++) {v.stage[i] = 0; v.attackStep[i] = (1 - v.env[i]) / (this.ops[i].attack * this.rate);}\n      }\n    }\n  }\n  /**\n   * `pitch` is the bend in cents, `brightness` the Brightness CV, and `wheel` the mod wheel from 0 to 1, which goes\n   * where wheelAssign says, as a DX7's wheel does: deeper vibrato, tremolo, or EG bias, which brightens the sound.\n   */\n  render(output, startFrame, pitch, brightness, wheel) {\n    if (this.disposed) {output.fill(0); return;}\n    // The per-voice filter buffers hold one render quantum, so longer renders (tests) go a quantum at a time.\n    if (this.makeFilter && output.length > QUANTUM) {\n      for (let i = 0; i < output.length; i += QUANTUM) this.render(output.subarray(i, i + QUANTUM), startFrame + i, pitch?.subarray(i, i + QUANTUM), brightness?.subarray(i, i + QUANTUM), wheel?.subarray(i, i + QUANTUM));\n      return;\n    }\n    // The Filter section crossfades in and out over 8 ms. While it is fully off, the original unfiltered path runs.\n    const filtering = !!this.makeFilter && (this.params.filterModel === 1 || this.wet > 0);\n    if (filtering) for (let i = 0; i < 16; i++) {this.voiceOut[i].fill(0); this.voiceDetune[i].fill(this.voiceDetune[i][QUANTUM - 1]);}\n    for (let n = 0; n < output.length; n++) {\n      const time = (startFrame + n) / this.rate;\n      while (this.events.length && this.events[0].time <= time) this.apply(this.events.shift());\n      if (!this.ops) {output[n] = 0; continue;}\n      const p = this.params, algorithm = ALGORITHMS[p.algorithm];\n      const mod = (wheel?.[n] ?? 0) * (p.wheelRange ?? 0), assign = p.wheelAssign ?? 0, lfo = Math.sin(TAU * p.lfoRate * time);\n      const bend = Math.max(-9600, Math.min(9600, (pitch?.[n] ?? 0) + lfo * (p.lfoDepth + (assign === 0 ? mod : 0)) * 100));\n      const tune = 2 ** (bend / 1200);\n      const color = Math.max(0, Math.min(4, p.brightness + (brightness?.[n] ?? 0) + (assign === 2 ? mod * EG_BIAS : 0)));\n      const tremolo = assign === 1 ? 1 - mod * TREMOLO * (1 + lfo) : 1;\n      let sum = 0;\n      for (let index = 0; index < this.voices.length; index++) {\n        const v = this.voices[index];\n        if (v.free <= time) continue;\n        const touch = 1 - p.velocity + p.velocity * v.velocity;\n        for (let i = 5; i >= 0; i--) {\n          const op = this.ops[i];\n          if (v.stage[i] === 0) {v.env[i] = Math.min(1, v.env[i] + v.attackStep[i]); if (v.env[i] >= 1) v.stage[i] = 1;}\n          else if (v.stage[i] === 1) v.env[i] = op.sustain + (v.env[i] - op.sustain) * op.decay;\n          else v.env[i] = Math.max(0, v.env[i] - v.releaseStep[i]);\n          const frequency = Math.min(this.rate * 0.45, v.frequency * tune * op.ratio);\n          // The step is under half a turn, so subtracting a turn wraps exactly as the remainder would.\n          v.phase[i] += TAU * frequency / this.rate; if (v.phase[i] >= TAU) v.phase[i] -= TAU;\n          // A released operator at zero contributes nothing, so its sine is skipped.\n          if (v.env[i] === 0) {v.values[i] = 0; continue;}\n          let modulation = i === 5 ? (v.feedback + v.lastFeedback) * 0.5 * p.feedback * 3.5 : 0;\n          const inputs = algorithm.inputs[i];\n          for (let k = 0; k < inputs.length; k++) modulation += v.values[inputs[k]] * 5 * color * touch;\n          v.values[i] = Math.sin(v.phase[i] + modulation) * v.env[i] * op.level;\n        }\n        v.lastFeedback = v.feedback; v.feedback = v.values[5];\n        let voice = 0;\n        for (let k = 0; k < algorithm.carriers.length; k++) voice += v.values[algorithm.carriers[k]];\n        voice = voice / Math.sqrt(algorithm.carriers.length) * v.velocity;\n        sum += voice;\n        if (filtering) {\n          // Each voice's ladder follows its first carrier's envelope and its note, including bends.\n          this.voiceOut[index][n] = voice; this.used[index] = 1;\n          this.voiceDetune[index][n] = p.filterEnv * 4800 * v.env[0] + p.filterTrack * (v.cents + bend);\n        }\n      }\n      this.level += (p.level - this.level) * 0.003;\n      if (!filtering) {output[n] = sum * this.level * tremolo * 0.18; continue;}\n      this.wet += ((p.filterModel === 1 ? 1 : 0) - this.wet) * this.fade;\n      if (this.wet < 1e-5 && p.filterModel !== 1) this.wet = 0;\n      this.dry[n] = sum; this.wets[n] = this.wet; this.levels[n] = this.level * tremolo;\n    }\n    if (filtering) this.mixFiltered(output);\n  }\n\n  /** Runs each sounding voice (and each ringing tail) through its ladder and crossfades the result with the dry mix. */\n  mixFiltered(output) {\n    const p = this.params, n = output.length;\n    output.fill(0);\n    for (let i = 0; i < 16; i++) {\n      if (this.used[i]) this.tails[i] = FILTER_TAIL;\n      if (!this.tails[i]) continue;\n      const filter = (this.filters[i] ??= this.makeFilter()), buffer = this.voiceOut[i];\n      filter.render(buffer, buffer, p.filterCutoff, p.filterResonance, p.filterDrive, this.voiceDetune[i], 0);\n      for (let k = 0; k < n; k++) output[k] += buffer[k];\n      if (!this.used[i]) this.tails[i]--;\n      this.used[i] = 0;\n    }\n    for (let k = 0; k < n; k++) output[k] = (this.dry[k] * (1 - this.wets[k]) + output[k] * FILTER_LEVEL * this.wets[k]) * this.levels[k] * 0.18;\n  }\n\n  dispose() {\n    this.disposed = true; this.events = [];\n    for (const filter of this.filters) filter?.dispose();\n    this.filters = [];\n  }\n}\n// The guard lets unit tests import the exact processor DSP without an audio environment.\nif (typeof registerProcessor !== 'undefined') {\n  class PrismProcessor extends AudioWorkletProcessor {\n    constructor(options) {\n      // dsp-processor.js shares its ladder through the global scope; without the Rust DSP, PRISM plays unfiltered.\n      const module = options?.processorOptions?.module, Ladder = globalThis.RacklooseDSP?.LadderDSP;\n      super(); this.dsp = new PrismDSP(sampleRate, module && Ladder ? () => new Ladder(module, sampleRate) : undefined);\n      this.port.onmessage = ({data}) => {\n        if (data.type === 'flush') this.port.postMessage({id: data.id});\n        else if (data.type === 'dispose') this.dsp.dispose();\n        else this.dsp.enqueue(data);\n      };\n    }\n    process(inputs, outputs) {\n      this.dsp.render(outputs[0][0], currentFrame, inputs[0]?.[0], inputs[1]?.[0], inputs[2]?.[0]);\n      return !this.dsp.disposed;\n    }\n  }\n  registerProcessor('rackloose-prism-v1', PrismProcessor);\n}\n", Fi = "/** Original behavioral models, not measured circuit replicas. See docs/studio-processors.md for calibration and sources. */\nexport const COHERE_ATTACKS = [0.0001, 0.0003, 0.001, 0.003, 0.01, 0.03];\nexport const COHERE_RELEASES = [0.1, 0.3, 0.6, 1.2];\nexport const TALON_RATIOS = [1, 2, 3, 4, 6, 10, 20, 100];\nexport const BRIT_LOW = [35, 60, 110, 220];\nexport const BRIT_MID = [360, 700, 1600, 3200, 4800, 7200];\nexport const BRIT_HP = [0, 50, 80, 160, 300];\nconst db = x => 10 ** (x / 20);\nconst unity = [1, 0, 0, 0, 0];\n\n/** Normalized biquads and one pole filters. A third-order Butterworth HP is a first order plus a Q=1 biquad. */\nexport function coefficients(type, frequency, gain, Q, rate) {\n  if (!frequency) return unity.slice();\n  const w = 2 * Math.PI * Math.min(frequency, rate * 0.45) / rate, c = Math.cos(w), s = Math.sin(w);\n  const A = 10 ** (gain / 40), alpha = s / (2 * Q), shelf = s * Math.sqrt(2 * A);\n  let b0, b1, b2, a0, a1, a2;\n  if (type === 'pole') {\n    const k = Math.tan(w / 2); return [1 / (1 + k), -1 / (1 + k), 0, (k - 1) / (k + 1), 0];\n  } else if (type === 'highpass') {\n    [b0, b1, b2, a0, a1, a2] = [(1 + c) / 2, -(1 + c), (1 + c) / 2, 1 + alpha, -2 * c, 1 - alpha];\n  } else if (type === 'bell') {\n    [b0, b1, b2, a0, a1, a2] = [1 + alpha * A, -2 * c, 1 - alpha * A, 1 + alpha / A, -2 * c, 1 - alpha / A];\n  } else if (type === 'low') {\n    [b0, b1, b2, a0, a1, a2] = [A * (A + 1 - (A - 1) * c + shelf), 2 * A * (A - 1 - (A + 1) * c), A * (A + 1 - (A - 1) * c - shelf), A + 1 + (A - 1) * c + shelf, -2 * (A - 1 + (A + 1) * c), A + 1 + (A - 1) * c - shelf];\n  } else {\n    [b0, b1, b2, a0, a1, a2] = [A * (A + 1 + (A - 1) * c + shelf), -2 * A * (A - 1 + (A + 1) * c), A * (A + 1 + (A - 1) * c - shelf), A + 1 - (A - 1) * c + shelf, 2 * (A - 1 - (A + 1) * c), A + 1 - (A - 1) * c - shelf];\n  }\n  return [b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0];\n}\nexport function britFilters(p, rate) {\n  const hp = BRIT_HP[p.hpf] ?? 0;\n  return [coefficients('pole', hp, 0, 1, rate), coefficients('highpass', hp, 0, 1, rate),\n    coefficients('low', BRIT_LOW[p.lfFreq] ?? 110, p.lfGain, 0.7, rate),\n    coefficients('bell', BRIT_MID[p.midFreq] ?? 1600, p.midGain, 0.75, rate), coefficients('high', 12000, p.hfGain, 0.7, rate)];\n}\nexport function britResponse(p, frequency, rate = 48000) {\n  if (p.active) return 0;\n  const w = 2 * Math.PI * frequency / rate;\n  const magnitude = (a, b, c) => Math.hypot(a + b * Math.cos(w) + c * Math.cos(2 * w), b * Math.sin(w) + c * Math.sin(2 * w));\n  return britFilters(p, rate).reduce((sum, [b0, b1, b2, a1, a2]) => sum + 20 * Math.log10(magnitude(b0, b1, b2) / magnitude(1, a1, a2)), 0);\n}\n\n/** Each TALON mode has its own threshold and knee; Input drives a fixed characteristic instead of moving a threshold. */\nfunction curveSettings(type, p) {\n  let ratio, threshold, knee;\n  if (type === 'cohere') {\n    ratio = [2, 4, 10][p.ratio] ?? 4;\n    threshold = p.threshold + [-3, 0, 2][p.ratio]; knee = [9, 6, 3][p.ratio];\n  } else {\n    ratio = TALON_RATIOS[p.ratio] ?? 6;\n    threshold = [-18, -26, -24, -22, -20, -18, -16, -18][p.ratio];\n    knee = [0, 15, 12, 9, 6, 4, 2, 3][p.ratio];\n    if (p.fierce) {ratio = Math.max(12, ratio * 2); threshold -= 3; knee = 2;}\n  }\n  return [1 - 1 / ratio, threshold, knee];\n}\nfunction curveGain(level, slope, threshold, knee) {\n  if (!slope) return 0;\n  const over = level - threshold;\n  return over <= -knee / 2 ? 0 : over >= knee / 2 ? -over * slope : -slope * (over + knee / 2) ** 2 / (2 * knee);\n}\nexport function compressionCurve(type, level, p) {return curveGain(level, ...curveSettings(type, p));}\n\nclass Filter {\n  constructor(rate) {this.c = unity.slice(); this.target = unity.slice(); this.z1 = 0; this.z2 = 0; this.smooth = 1 - Math.exp(-1 / (rate * 0.008));}\n  set(c, initial) {this.target = c; if (initial) this.c = c.slice();}\n  run(x) {\n    const c = this.c;\n    for (let i = 0; i < 5; i++) c[i] += (this.target[i] - c[i]) * this.smooth;\n    const y = c[0] * x + this.z1;\n    this.z1 = c[1] * x - c[3] * y + this.z2; this.z2 = c[2] * x - c[4] * y;\n    return y;\n  }\n}\n\n// 4x interpolation/decimation of the nonlinear residual only: linear audio keeps its full bandwidth.\n// Two symmetric 49-tap Blackman-windowed sinc FIRs give exactly 12 base-rate samples of delay.\nexport const FIR = Float64Array.from({length: 49}, (_, i) => {\n  const n = i - 24, cutoff = 0.1125;\n  return (n ? Math.sin(2 * Math.PI * cutoff * n) / (Math.PI * n) : 2 * cutoff) * (0.42 - 0.5 * Math.cos(2 * Math.PI * i / 48) + 0.08 * Math.cos(4 * Math.PI * i / 48));\n});\nconst total = FIR.reduce((sum, x) => sum + x, 0); for (let i = 0; i < FIR.length; i++) FIR[i] /= total;\nclass Fir {\n  constructor() {this.buffer = new Float64Array(49); this.index = 0;}\n  /** Stores `x` without computing an output, for decimation steps whose output is discarded. */\n  push(x) {this.buffer[this.index] = x; this.index = (this.index + 1) % 49;}\n  run(x) {\n    this.buffer[this.index] = x; let sum = 0, at = this.index;\n    for (let i = 0; i < 49; i++) {sum += FIR[i] * this.buffer[at]; if (--at < 0) at = 48;}\n    this.index = (this.index + 1) % 49; return sum;\n  }\n}\n/**\n * The FIR over a 4x zero-stuffed signal, computed polyphase: phase `i` reads only the taps that meet a real sample,\n * in the same order, so it matches the full filter exactly at a quarter of the work.\n */\nclass Interpolator {\n  constructor() {this.buffer = new Float64Array(13); this.index = 0;}\n  push(x) {this.index = this.index ? this.index - 1 : 12; this.buffer[this.index] = x;}\n  run(phase) {\n    let sum = 0, at = this.index;\n    for (let k = phase; k < 49; k += 4) {sum += FIR[k] * this.buffer[at]; if (++at > 12) at = 0;}\n    return sum;\n  }\n}\nexport const STUDIO_LATENCY = 12;\nclass Delay {\n  constructor() {this.buffer = new Float64Array(STUDIO_LATENCY); this.index = 0;}\n  run(x) {const y = this.buffer[this.index]; this.buffer[this.index] = x; this.index = (this.index + 1) % this.buffer.length; return y;}\n}\nexport class Color {\n  constructor(rate) {this.up = new Interpolator(); this.down = new Fir(); this.clean = new Delay(); this.previous = 0; this.blocked = 0; this.dc = Math.exp(-2 * Math.PI * 5 / rate);}\n  run(x, amount, bias) {\n    let residual = 0;\n    const offset = Math.tanh(bias), slope = amount * (1 - offset * offset);\n    this.up.push(x * 4);\n    for (let i = 0; i < 4; i++) {\n      const up = this.up.run(i);\n      const shaped = (Math.tanh(amount * up + bias) - offset) / slope;\n      // Only every fourth decimated sample is kept, so the others are stored without being filtered.\n      if (i === 0) residual = this.down.run(shaped - up); else this.down.push(shaped - up);\n    }\n    // AC coupling of the nonlinear residual removes the DC generated by asymmetric coloration.\n    this.blocked = residual - this.previous + this.dc * this.blocked; this.previous = residual;\n    return this.clean.run(x) + this.blocked;\n  }\n}\n\nexport class StudioDSP {\n  constructor(type, rate) {\n    this.type = type; this.rate = rate; this.params = null; this.events = []; this.disposed = false; this.reduction = 0;\n    this.gain = [0, 0]; this.memory = [0, 0]; this.input = 1; this.output = 1; this.wet = 1; this.drive = 0;\n    this.smooth = 1 - Math.exp(-1 / (rate * 0.008));\n    this.channels = Array.from({length: 2}, () => ({filters: Array.from({length: 5}, () => new Filter(rate)),\n      hp: new Filter(rate), emphasis: new Filter(rate), audioPole: new Filter(rate), audioHp: new Filter(rate), color: new Color(rate), dry: new Delay(), clean: new Delay(), amount: 0.15, bias: 0}));\n  }\n  enqueue(event) {this.events.push(event); this.events.sort((a, b) => a.time - b.time);}\n  configure(p) {\n    const initial = !this.params; this.params = {...p};\n    this.inputTarget = db(this.type === 'talon' ? p.input : 0); this.outputTarget = db(p.output);\n    this.wetTarget = p.active ? 0 : 1; this.driveTarget = p.drive ?? 0;\n    if (initial) {this.input = this.inputTarget; this.output = this.outputTarget; this.wet = this.wetTarget; this.drive = this.driveTarget;}\n    if (this.type !== 'brit') {\n      this.curveTarget = curveSettings(this.type, p); this.linkTarget = this.type === 'cohere' ? 1 : p.link;\n      this.attackTarget = this.type === 'cohere' ? COHERE_ATTACKS[p.attack] : p.attack;\n      this.releaseTarget = this.type === 'cohere' ? COHERE_RELEASES[p.release] ?? 0.3 : p.release;\n      if (initial) {this.curve = this.curveTarget.slice(); this.link = this.linkTarget; this.attack = this.attackTarget; this.release = this.releaseTarget;}\n    }\n    for (const channel of this.channels) {\n      if (this.type === 'brit') britFilters(p, this.rate).forEach((c, i) => channel.filters[i].set(c, initial));\n      const hp = this.type === 'cohere' ? [0, 30, 60, 106, 125, 185][p.scHpf] : p.detectorHp ? 80 : 0;\n      channel.hp.set(coefficients('highpass', hp, 0, Math.SQRT1_2, this.rate), initial);\n      channel.emphasis.set(coefficients('bell', 6000, p.detectorBand ? 10 : 0, 1, this.rate), initial);\n      // Third-order Bessel HP, normalized to -3 dB at 65 Hz. Distinct from the detector filter.\n      channel.audioPole.set(coefficients('pole', p.audioHp ? 65 * 0.754 : 0, 0, 1, this.rate), initial);\n      channel.audioHp.set(coefficients('highpass', p.audioHp ? 65 * 0.691 : 0, 0, 0.691, this.rate), initial);\n      if (initial && this.type === 'talon') {channel.amount = [0.15, 0.8, 1.5][p.color]; channel.bias = p.color === 1 ? 0.3 : 0;}\n    }\n  }\n  envelope(level, channel) {\n    const p = this.params, target = curveGain(level, this.curve[0], this.curve[1], this.curve[2]), current = this.gain[channel];\n    // A slow reservoir makes Auto and Opto depend on both the depth and duration of preceding compression.\n    this.memory[channel] += (Math.max(0, -current) - this.memory[channel]) * (1 - Math.exp(-1 / (this.rate * 0.6)));\n    let release = this.release;\n    if (this.type === 'cohere' && p.release === 4) release = 0.1 + Math.min(1.1, this.memory[channel] * 0.09);\n    if (this.type === 'talon') {\n      if (p.ratio === 5) release = Math.min(20, this.release * (1 + this.memory[channel] * 0.9));\n      else if (p.ratio === 7) release *= 0.45 + Math.min(1.5, Math.max(0, -current) / 15);\n      else release *= [1, 1.15, 1.05, 1, 0.9, 1, 0.8, 1][p.ratio];\n      if (p.ratio !== 5) release = Math.min(3.5, release);\n      if (p.fierce) release *= 0.65;\n    }\n    const seconds = target < current ? this.attack : release;\n    this.gain[channel] += (target - current) * (1 - Math.exp(-1 / (seconds * this.rate)));\n    return db(this.gain[channel]);\n  }\n  render(inputs, outputs, startFrame = 0) {\n    if (this.disposed) {outputs.forEach(out => out.fill(0)); return;}\n    const frames = outputs[0].length;\n    for (let n = 0; n < frames; n++) {\n      const time = (startFrame + n) / this.rate;\n      while (this.events.length && this.events[0].time <= time) this.configure(this.events.shift().params);\n      if (!this.params) {outputs.forEach(out => {out[n] = 0;}); continue;}\n      const p = this.params;\n      this.input += (this.inputTarget - this.input) * this.smooth; this.output += (this.outputTarget - this.output) * this.smooth;\n      this.wet += (this.wetTarget - this.wet) * this.smooth; this.drive += (this.driveTarget - this.drive) * this.smooth;\n      const left = inputs[0]?.[n] ?? 0, right = inputs[1]?.[n] ?? left;\n      const l = left * this.input, r = right * this.input;\n      let gainL = 1, gainR = 1;\n      if (this.type !== 'brit') {\n        for (let i = 0; i < 3; i++) this.curve[i] += (this.curveTarget[i] - this.curve[i]) * this.smooth;\n        this.link += (this.linkTarget - this.link) * this.smooth;\n        this.attack += (this.attackTarget - this.attack) * this.smooth; this.release += (this.releaseTarget - this.release) * this.smooth;\n        const a = this.channels[0], b = this.channels[1];\n        const levelL = 20 * Math.log10(Math.max(1e-12, Math.abs(a.emphasis.run(a.hp.run(l)))));\n        const levelR = 20 * Math.log10(Math.max(1e-12, Math.abs(b.emphasis.run(b.hp.run(r)))));\n        const dominant = Math.max(levelL, levelR);\n        this.envelope(levelL + this.link * (dominant - levelL), 0); this.envelope(levelR + this.link * (dominant - levelR), 1);\n        // Converge existing independent histories continuously when linking, never copy one channel's gain instantly.\n        const commonGain = Math.min(this.gain[0], this.gain[1]), commonMemory = Math.max(this.memory[0], this.memory[1]), coupling = this.link * this.smooth;\n        for (let i = 0; i < 2; i++) {this.gain[i] += (commonGain - this.gain[i]) * coupling; this.memory[i] += (commonMemory - this.memory[i]) * coupling;}\n        gainL = db(this.gain[0]); gainR = db(this.gain[1]);\n        this.reduction = Math.min(this.gain[0], this.gain[1]) * this.wet;\n      }\n      for (let i = 0; i < outputs.length; i++) {\n        const channel = this.channels[i], raw = i === 0 ? left : right;\n        let wet = i === 0 ? l : r;\n        if (this.type === 'brit') {\n          for (const filter of channel.filters) wet = filter.run(wet);\n          wet = channel.color.run(wet, 0.22 * db(this.drive), 0.12);\n        } else if (this.type === 'talon') {\n          wet = channel.audioHp.run(channel.audioPole.run(wet * (i === 0 ? gainL : gainR)));\n          const amount = [0.15, 0.8, 1.5][p.color] * (1 + Math.min(2, -this.gain[i] / 20));\n          channel.amount += (amount - channel.amount) * this.smooth; channel.bias += ((p.color === 1 ? 0.3 : 0) - channel.bias) * this.smooth;\n          wet = channel.color.run(wet, channel.amount, channel.bias);\n        } else wet = channel.clean.run(wet * (i === 0 ? gainL : gainR));\n        const dry = channel.dry.run(raw);\n        outputs[i][n] = dry + this.wet * (wet * this.output - dry);\n      }\n    }\n  }\n}\n\nif (typeof registerProcessor !== 'undefined') {\n  class StudioProcessor extends AudioWorkletProcessor {\n    constructor(options) {\n      super(); this.dsp = new StudioDSP(options.processorOptions.type, sampleRate); this.meterFrames = 0;\n      this.port.onmessage = ({data}) => {\n        if (data.type === 'flush') this.port.postMessage({id: data.id});\n        else if (data.type === 'dispose') {this.dsp.disposed = true; this.dsp.events = [];}\n        else this.dsp.enqueue(data);\n      };\n    }\n    process(inputs, outputs) {\n      this.dsp.render(inputs[0] ?? [], outputs[0], currentFrame);\n      this.meterFrames += outputs[0][0].length;\n      if (this.meterFrames >= sampleRate / 25) {this.meterFrames = 0; this.port.postMessage({reduction: this.dsp.reduction});}\n      return !this.dsp.disposed;\n    }\n  }\n  registerProcessor('rackloose-studio-v1', StudioProcessor);\n}\n", Ii = "/**\n * Hosts Rackloose's Rust DSP (crates/rackloose-dsp, compiled to WebAssembly): the zero-delay-feedback ladder filter\n * for MONARCH, ORACLE, AURORA and SIEVE, the modeled drum engine for BOOM, PUNCH, ORBIT, STRIKE and FORGE, and the\n * Analog engines of VELVET, REED, DRAWBAR, PLANET and STRUT. PRISM reaches the ladder, and the keyboards their engines, through\n * `globalThis.RacklooseDSP`. Imported directly by tests and as inline source by the worklet loader.\n *\n * Audio moves through fixed buffers in Wasm linear memory, so nothing allocates per block. Every processor in a context\n * shares one instance of the module, and every view is rebuilt when an allocation grows that memory.\n */\nconst RENDER_QUANTUM = 128, DRUM_PARAMS = 8, KEYS_PARAMS = 24;\n/** The keyboards as `keys_new` numbers them. */\nconst KEYS_KIND = {velvet: 0, reed: 1, drawbar: 2, planet: 3, strut: 4};\n/** The slots each keyboard's Analog engine reads its params from: every param but Engine, in the device's order. */\nexport const KEYS_PARAM_ORDER = {\n  velvet: ['model', 'hardness', 'bark', 'bell', 'decay', 'damper', 'drive', 'bass', 'treble', 'tremRate', 'tremDepth', 'level'],\n  reed: ['hardness', 'bark', 'decay', 'damper', 'drive', 'tremRate', 'tremDepth', 'speaker', 'level'],\n  drawbar: [...Array.from({length: 9}, (_, i) => `drawbar${i + 1}`), 'percussion', 'percHarmonic', 'percDecay', 'percVolume', 'vibrato', 'click', 'leakage', 'drive', 'rotary', 'balance', 'level'],\n  planet: ['model', 'pluck', 'decay', 'damper', 'bark', 'drive', 'tone', 'tremRate', 'tremDepth', 'level'],\n  strut: ['pickupAB', 'pickupCD', 'brilliant', 'treble', 'medium', 'soft', 'mute', 'hardness', 'decay', 'release', 'drive', 'level'],\n};\n/** The controllers as `keys_control` numbers them; DRAWBAR's rotary switch is its mod wheel. */\nconst KEYS_CONTROL = {sustain: 0, expression: 1, mod: 2, rotary: 2};\nlet shared = null;\n\n/**\n * The context's one instance of the module. Every AudioWorkletNode receives its own structured clone of `module`, so the\n * instance belongs to the worklet scope (one per audio context) rather than to a module object: an instance per\n * processor would reserve a Wasm memory each, and enough of them exhaust the browser's Wasm address space. It needs no\n * imports, so instantiating is synchronous.\n */\nexport function wasmFor(module) {\n  shared ??= new WebAssembly.Instance(module, {}).exports;\n  return shared;\n}\n\n/** One ladder: cutoff, resonance and drive are smoothed in Rust; detune (cents) applies sample-exact. */\nexport class LadderDSP {\n  constructor(module, sampleRate) {\n    this.wasm = wasmFor(module);\n    this.ptr = this.wasm.ladder_new(sampleRate);\n    this.last = {cutoff: NaN, resonance: NaN, drive: NaN, mode: NaN};\n    this.fresh = true;\n    this.buffer = null;\n  }\n\n  views() {\n    const {memory, ladder_input_ptr, ladder_detune_ptr, ladder_output_ptr} = this.wasm;\n    this.buffer = memory.buffer;\n    this.input = new Float32Array(this.buffer, ladder_input_ptr(this.ptr), RENDER_QUANTUM);\n    this.detune = new Float32Array(this.buffer, ladder_detune_ptr(this.ptr), RENDER_QUANTUM);\n    this.output = new Float32Array(this.buffer, ladder_output_ptr(this.ptr), RENDER_QUANTUM);\n  }\n\n  /**\n   * Filters `input` (missing means silence) into `output`. `detune` holds one value for the block or one per sample;\n   * `mode` is 0 24 dB low-pass, 1 12 dB low-pass, 2 band-pass, 3 high-pass.\n   */\n  render(input, output, cutoff, resonance, drive, detune, mode = 0) {\n    if (!this.ptr) {output.fill(0); return;}\n    if (this.wasm.memory.buffer !== this.buffer) this.views();\n    const n = Math.min(output.length, RENDER_QUANTUM);\n    if (input) this.input.set(input.length > n ? input.subarray(0, n) : input); else this.input.fill(0, 0, n);\n    if (detune.length === 1) this.detune.fill(detune[0], 0, n); else this.detune.set(detune.length > n ? detune.subarray(0, n) : detune);\n    const {last, wasm, ptr} = this;\n    if (cutoff !== last.cutoff) wasm.ladder_set_cutoff(ptr, (last.cutoff = cutoff));\n    if (resonance !== last.resonance) wasm.ladder_set_resonance(ptr, (last.resonance = resonance));\n    if (drive !== last.drive) wasm.ladder_set_drive(ptr, (last.drive = drive));\n    if (mode !== last.mode) wasm.ladder_set_mode(ptr, (last.mode = mode));\n    // The first block starts on its settings instead of gliding from Rust's defaults.\n    if (this.fresh) {wasm.ladder_reset(ptr); this.fresh = false;}\n    wasm.ladder_process(ptr, n);\n    output.set(n === RENDER_QUANTUM ? this.output : this.output.subarray(0, n));\n  }\n\n  dispose() {\n    if (!this.ptr) return;\n    this.wasm.ladder_free(this.ptr);\n    this.ptr = 0;\n    this.input = this.detune = this.output = null;\n  }\n}\n\n/**\n * One drum machine. Hits arrive ahead of time as {time, voice, velocity, params} and start sample-accurately inside\n * the block that contains them; a late hit starts at the next block. `chokes` lists [voice, by] pairs.\n */\nexport class DrumsDSP {\n  constructor(module, sampleRate, kit, chokes = []) {\n    this.wasm = wasmFor(module);\n    this.rate = sampleRate;\n    this.ptr = this.wasm.drums_new(sampleRate, kit);\n    for (const [voice, by] of chokes) this.wasm.drums_choke(this.ptr, voice, by);\n    this.events = [];\n    this.buffer = null;\n  }\n\n  views() {\n    const {memory, drums_params_ptr, drums_output_ptr} = this.wasm;\n    this.buffer = memory.buffer;\n    this.params = new Float32Array(this.buffer, drums_params_ptr(this.ptr), DRUM_PARAMS);\n    this.left = new Float32Array(this.buffer, drums_output_ptr(this.ptr, 0), RENDER_QUANTUM);\n    this.right = new Float32Array(this.buffer, drums_output_ptr(this.ptr, 1), RENDER_QUANTUM);\n  }\n\n  /** Copies a sampled kit's one-shot for `voice` into Wasm memory. */\n  load(voice, pcm) {\n    if (!this.ptr) return;\n    const at = this.wasm.drums_load_sample(this.ptr, voice, pcm.length);\n    if (at) new Float32Array(this.wasm.memory.buffer, at, pcm.length).set(pcm);\n  }\n\n  enqueue(event) {\n    let i = this.events.length;\n    while (i > 0 && this.events[i - 1].time > event.time) i--;\n    this.events.splice(i, 0, event);\n  }\n\n  /** Drops hits scheduled at or after `time`. Hits already sounding keep their natural tails. */\n  cancel(time) {this.events = this.events.filter(event => event.time < time);}\n\n  render(left, right, startFrame) {\n    if (!this.ptr) {left.fill(0); right?.fill(0); return;}\n    if (this.wasm.memory.buffer !== this.buffer) this.views();\n    const n = Math.min(left.length, RENDER_QUANTUM), end = startFrame + n;\n    while (this.events.length && this.events[0].time * this.rate < end) {\n      const event = this.events.shift(), offset = Math.max(0, Math.floor(event.time * this.rate) - startFrame);\n      this.params.fill(0); this.params.set(event.params.slice(0, DRUM_PARAMS));\n      this.wasm.drums_trigger(this.ptr, event.voice, Math.min(offset, n - 1), event.velocity);\n    }\n    this.wasm.drums_process(this.ptr, n);\n    if (this.wasm.memory.buffer !== this.buffer) this.views();\n    left.set(n === RENDER_QUANTUM ? this.left : this.left.subarray(0, n));\n    right?.set(n === RENDER_QUANTUM ? this.right : this.right.subarray(0, n));\n  }\n\n  dispose() {\n    if (!this.ptr) return;\n    this.wasm.drums_free(this.ptr);\n    this.ptr = 0;\n    this.events = [];\n  }\n}\n\n/**\n * A keyboard's Analog engine, with the same calls as its Digital one in keys-processor.js: the processor splits each block\n * at its events, so every note, pedal and param lands on its own sample. Keys arrive as any value the host uses; each\n * gets a small integer id for as long as it is held.\n */\nexport class AnalogKeys {\n  constructor(module, sampleRate, kind) {\n    this.wasm = wasmFor(module);\n    this.ptr = this.wasm.keys_new(sampleRate, KEYS_KIND[kind] ?? 255);\n    this.order = KEYS_PARAM_ORDER[kind] ?? [];\n    this.ids = new Map(); this.next = 0;\n    this.buffer = null;\n  }\n\n  views() {\n    const {memory, keys_params_ptr, keys_output_ptr} = this.wasm;\n    this.buffer = memory.buffer;\n    this.params = new Float32Array(this.buffer, keys_params_ptr(this.ptr), KEYS_PARAMS);\n    this.left = new Float32Array(this.buffer, keys_output_ptr(this.ptr, 0), RENDER_QUANTUM);\n    this.right = new Float32Array(this.buffer, keys_output_ptr(this.ptr, 1), RENDER_QUANTUM);\n  }\n\n  ready() {\n    if (!this.ptr) return false;\n    if (this.wasm.memory.buffer !== this.buffer) this.views();\n    return true;\n  }\n\n  configure(params) {\n    if (!this.ready()) return;\n    this.params.fill(0);\n    this.order.forEach((name, i) => {this.params[i] = Number(params?.[name]) || 0;});\n    this.wasm.keys_configure(this.ptr);\n  }\n\n  noteOn(note, velocity, key, cv = 0) {\n    if (!this.ready()) return;\n    let id = this.ids.get(key);\n    if (id === undefined) {id = this.next; this.next = (this.next + 1) % 0x7fffffff; this.ids.set(key, id);}\n    this.wasm.keys_note_on(this.ptr, note, velocity, id, cv || 0);\n  }\n\n  /** Lets `key` go, or every key for `undefined`. */\n  noteOff(key) {\n    if (!this.ready()) return;\n    if (key === undefined) {this.wasm.keys_release_all(this.ptr); this.ids.clear(); return;}\n    const id = this.ids.get(key);\n    if (id === undefined) return;\n    this.ids.delete(key);\n    this.wasm.keys_note_off(this.ptr, id);\n  }\n\n  control(kind, level) {\n    const index = KEYS_CONTROL[kind];\n    if (index !== undefined && this.ready()) this.wasm.keys_control(this.ptr, index, level);\n  }\n\n  /** Adds `n` samples (at most one quantum) into `left` and `right` from `offset`. */\n  render(left, right, offset, n, cents = 0, cv = 0) {\n    if (!this.ready() || n <= 0) return;\n    this.wasm.keys_process(this.ptr, n, cents || 0, cv || 0);\n    if (this.wasm.memory.buffer !== this.buffer) this.views();\n    for (let k = 0; k < n; k++) {left[offset + k] += this.left[k]; right[offset + k] += this.right[k];}\n  }\n\n  get busy() {return this.ptr ? this.wasm.keys_busy(this.ptr) === 1 : false;}\n\n  clear() {\n    if (!this.ptr) return;\n    this.wasm.keys_clear(this.ptr);\n    this.ids.clear();\n  }\n\n  dispose() {\n    if (!this.ptr) return;\n    this.wasm.keys_free(this.ptr);\n    this.ptr = 0;\n    this.ids.clear();\n  }\n}\n\n// The guard lets unit tests import the exact processor DSP without an audio environment.\nif (typeof registerProcessor !== 'undefined') {\n  globalThis.RacklooseDSP = {LadderDSP, AnalogKeys, wasmFor};\n\n  class LadderProcessor extends AudioWorkletProcessor {\n    static get parameterDescriptors() {\n      return [\n        {name: 'cutoff', defaultValue: 1000, minValue: 20, maxValue: 20000, automationRate: 'k-rate'},\n        {name: 'resonance', defaultValue: 0, minValue: 0, maxValue: 1, automationRate: 'k-rate'},\n        {name: 'drive', defaultValue: 0, minValue: 0, maxValue: 1, automationRate: 'k-rate'},\n        {name: 'mode', defaultValue: 0, minValue: 0, maxValue: 3, automationRate: 'k-rate'},\n        // Cents, like BiquadFilterNode.detune, with its unbounded range. Rust clamps the resulting cutoff.\n        {name: 'detune', defaultValue: 0, automationRate: 'a-rate'},\n      ];\n    }\n    constructor({processorOptions}) {\n      super(); this.dsp = new LadderDSP(processorOptions.module, sampleRate);\n      this.port.onmessage = ({data}) => {\n        if (data.type === 'flush') this.port.postMessage({id: data.id});\n        else if (data.type === 'dispose') this.dsp.dispose();\n      };\n    }\n    process(inputs, outputs, parameters) {\n      if (!this.dsp.ptr) return false;\n      const {cutoff, resonance, drive, mode, detune} = parameters;\n      this.dsp.render(inputs[0]?.[0], outputs[0][0], cutoff[0], resonance[0], drive[0], detune, Math.round(mode[0]));\n      return true;\n    }\n  }\n  registerProcessor('rackloose-ladder-v1', LadderProcessor);\n\n  class DrumsProcessor extends AudioWorkletProcessor {\n    constructor({processorOptions: {module, kit, chokes}}) {\n      super(); this.dsp = new DrumsDSP(module, sampleRate, kit, chokes);\n      this.port.onmessage = ({data}) => {\n        if (data.type === 'hit') this.dsp.enqueue(data);\n        else if (data.type === 'sample') this.dsp.load(data.voice, data.pcm);\n        else if (data.type === 'cancel') this.dsp.cancel(data.time);\n        else if (data.type === 'flush') this.port.postMessage({id: data.id});\n        else if (data.type === 'dispose') this.dsp.dispose();\n      };\n    }\n    process(inputs, outputs) {\n      if (!this.dsp.ptr) return false;\n      const [left, right] = outputs[0];\n      this.dsp.render(left, right, currentFrame);\n      return true;\n    }\n  }\n  registerProcessor('rackloose-drums-v1', DrumsProcessor);\n}\n", Li = "/**\n * VELVET, REED, PLANET, STRUT and DRAWBAR, Rackloose's modeled keyboards. This file holds their Digital engines, plain JS that plays\n * everywhere, and the processor that runs them, or their Analog engines from the Rust DSP when it is available.\n * Imported directly by tests and as inline source by the worklet loader.\n *\n * Every engine plays one tine, reed, string or key per note, as the instrument does: a note struck again while it still\n * sounds strikes the same tine, and its damper stays up while any key or the pedal holds it.\n */\nconst TAU = 2 * Math.PI, QUANTUM = 128;\n/** How long, in seconds, a switch between Digital and Analog crossfades. */\nconst FADE = 0.008;\n/** Below this amplitude, about −110 dB, a partial stops being rendered. */\nconst FLOOR = 3e-6;\n/** A post chain whose output stays below this for a block, with nothing sounding, goes idle and outputs exact silence. */\nconst IDLE = 1e-7;\nexport const KEYS_KINDS = ['velvet', 'reed', 'planet', 'strut', 'drawbar'];\n/** Where each controller rests: the sustain pedal up, the swell open, the rotary slow. */\nexport const CONTROLS_AT_REST = {bend: 0, mod: 0, sustain: 0, expression: 1};\nexport const mtof = note => 440 * 2 ** ((note - 69) / 12);\nconst clamp = (value, low, high) => value < low ? low : value > high ? high : value;\nconst db = gain => 10 ** (gain / 20);\n\n/** An RBJ biquad on one channel. */\nexport class Biquad {\n  constructor() {this.b0 = 1; this.b1 = this.b2 = this.a1 = this.a2 = 0; this.reset();}\n  reset() {this.x1 = this.x2 = this.y1 = this.y2 = 0;}\n  set(type, rate, frequency, q = Math.SQRT1_2, gain = 0) {\n    const w = TAU * clamp(frequency, 5, rate * 0.45) / rate, cos = Math.cos(w), alpha = Math.sin(w) / (2 * q), A = 10 ** (gain / 40);\n    let b0, b1, b2, a0, a1, a2;\n    if (type === 'lowpass') {b0 = (1 - cos) / 2; b1 = 1 - cos; b2 = b0; a0 = 1 + alpha; a1 = -2 * cos; a2 = 1 - alpha;}\n    else if (type === 'highpass') {b0 = (1 + cos) / 2; b1 = -(1 + cos); b2 = b0; a0 = 1 + alpha; a1 = -2 * cos; a2 = 1 - alpha;}\n    else if (type === 'bandpass') {b0 = alpha; b1 = 0; b2 = -alpha; a0 = 1 + alpha; a1 = -2 * cos; a2 = 1 - alpha;}\n    else if (type === 'peak') {b0 = 1 + alpha * A; b1 = -2 * cos; b2 = 1 - alpha * A; a0 = 1 + alpha / A; a1 = -2 * cos; a2 = 1 - alpha / A;}\n    else {\n      const s = 2 * Math.sqrt(A) * alpha, sign = type === 'lowshelf' ? 1 : -1;\n      b0 = A * ((A + 1) - sign * (A - 1) * cos + s); b1 = sign * 2 * A * ((A - 1) - sign * (A + 1) * cos); b2 = A * ((A + 1) - sign * (A - 1) * cos - s);\n      a0 = (A + 1) + sign * (A - 1) * cos + s; a1 = -sign * 2 * ((A - 1) + sign * (A + 1) * cos); a2 = (A + 1) + sign * (A - 1) * cos - s;\n    }\n    this.b0 = b0 / a0; this.b1 = b1 / a0; this.b2 = b2 / a0; this.a1 = a1 / a0; this.a2 = a2 / a0;\n    return this;\n  }\n  process(x) {\n    let y = this.b0 * x + this.b1 * this.x1 + this.b2 * this.x2 - this.a1 * this.y1 - this.a2 * this.y2;\n    if (y > -1e-20 && y < 1e-20) y = 0;\n    this.x2 = this.x1; this.x1 = x; this.y2 = this.y1; this.y1 = y;\n    return y;\n  }\n}\n\n/** A one-pole low-pass, for noise colour and smoothing. */\nconst onePole = (rate, frequency) => 1 - Math.exp(-TAU * frequency / rate);\n\n/**\n * Short noises: a hammer's thump, a key bottoming out, dampers landing, a pedal's swish. Each is filtered noise with an\n * optional low sine, decaying from its start; they are rare and brief, so a handful at a time is plenty.\n */\nclass Noises {\n  constructor(rate) {this.rate = rate; this.list = []; this.seed = 22222;}\n  random() {this.seed = (this.seed * 1664525 + 1013904223) >>> 0; return this.seed / 2147483648 - 1;}\n  add({amount, decay, tone, sine = 0, sineAmount = 0, pan = 0, delay = 0}) {\n    if (amount < 1e-6 || this.list.length >= 24) return;\n    const angle = (clamp(pan, -1, 1) + 1) * Math.PI / 4;\n    this.list.push({amount, fall: Math.exp(-1 / (decay * this.rate)), lp: onePole(this.rate, tone), state: 0, sine: TAU * sine / this.rate, phase: 0,\n      sineAmount, left: Math.cos(angle) * Math.SQRT2, right: Math.sin(angle) * Math.SQRT2, wait: Math.round(delay * this.rate)});\n  }\n  render(left, right, offset, n) {\n    for (let i = this.list.length - 1; i >= 0; i--) {\n      const noise = this.list[i];\n      for (let k = offset; k < offset + n; k++) {\n        if (noise.wait > 0) {noise.wait--; continue;}\n        noise.state += noise.lp * (this.random() - noise.state);\n        noise.phase += noise.sine;\n        const x = noise.amount * (noise.state + noise.sineAmount * Math.sin(noise.phase));\n        left[k] += x * noise.left; right[k] += x * noise.right; noise.amount *= noise.fall;\n      }\n      if (noise.amount < 1e-6 && noise.wait <= 0) this.list.splice(i, 1);\n    }\n  }\n  get busy() {return this.list.length > 0;}\n  clear() {this.list = [];}\n}\n\n/**\n * One struck note's decaying sinusoids, each a rotating phasor whose decay may change: a tine's or a reed's modes. A\n * partial decays at `prompt` until it falls to `knee` times its strike, then at `after`, as a tine's swing dies into its\n * tonebar's long sustain; dampers add `damp` times how far they are down.\n */\nclass Partials {\n  constructor(size) {\n    this.size = size; this.count = 0;\n    for (const field of ['re', 'im', 'cr', 'ci', 'freq', 'prompt', 'after', 'knee', 'damp']) this[field] = new Float64Array(size);\n    this.late = new Uint8Array(size); this.on = new Uint8Array(size);\n  }\n  reset() {this.count = 0; this.re.fill(0); this.im.fill(0); this.on.fill(0); this.late.fill(0);}\n  /**\n   * Adds a fresh sinusoid of `amount` at `phase` to partial `j`, so a restrike sounds over what still rings, and starts\n   * its prompt decay.\n   */\n  strike(j, amount, phase = 0) {\n    this.re[j] += amount * Math.cos(phase); this.im[j] += amount * Math.sin(phase);\n    const level = Math.hypot(this.re[j], this.im[j]);\n    this.knee[j] = this.knee[j] > 0 ? level * this.kneeRatio(j) : 0; this.late[j] = this.knee[j] > 0 ? 0 : 1; this.on[j] = 1;\n  }\n  kneeRatio(j) {return this.ratios ? this.ratios[j] : 0;}\n  /** Sets partial `j`'s rotation for `tune` (a frequency ratio) and `damping` (0 dampers off to 1 fully down). */\n  rotate(j, rate, tune, damping) {\n    const w = TAU * this.freq[j] * tune / rate;\n    if (w >= Math.PI * 0.94 || !this.on[j]) {this.on[j] = 0; this.cr[j] = this.ci[j] = 0; return;}\n    const r = Math.exp(-((this.late[j] ? this.after[j] : this.prompt[j]) + damping * this.damp[j]) / rate);\n    this.cr[j] = r * Math.cos(w); this.ci[j] = r * Math.sin(w);\n  }\n}\n\n/** A note's voice: its partials, where it sits in the stereo field, and how far its dampers are down. */\nclass Voice {\n  constructor(size) {this.partials = new Partials(size); this.note = -1; this.live = false; this.fresh = false; this.ramp = 0; this.damping = 0; this.energy = 0; this.left = 1; this.right = 1; this.age = 0; this.drive = 0;}\n}\n/** How long, in seconds, a newly struck voice fades in, so partials that start away from zero don't click. */\nconst ONSET = 0.0012;\n\n/**\n * What every struck keyboard shares: keys, the notes they hold, the pedals, and the voices. A subclass strikes a voice\n * (`excite`), says how a voice's dampers sit (`dampers`), renders its voices and runs its post chain.\n */\nclass Struck {\n  constructor(rate, voices, size) {\n    this.rate = rate; this.pool = Array.from({length: voices}, () => new Voice(size));\n    this.byNote = new Map(); this.keys = new Map(); this.down = new Map();\n    this.controls = {...CONTROLS_AT_REST}; this.p = null; this.tune = 1; this.cents = 0; this.clock = 0;\n    this.buffer = new Float64Array(QUANTUM); this.idle = true; this.noises = new Noises(rate);\n  }\n  configure(params) {const first = !this.p; this.p = params; this.configured(first); for (const voice of this.byNote.values()) this.retune(voice);}\n  configured() {}\n  noteOn(note, velocity, key, cv = 0) {\n    if (!this.p) return;\n    if (this.keys.has(key)) this.noteOff(key);\n    this.keys.set(key, note); this.down.set(note, (this.down.get(note) ?? 0) + 1);\n    let voice = this.byNote.get(note);\n    const fresh = !voice?.live;\n    if (fresh) {voice = this.allocate(); voice.note = note; voice.partials.reset(); voice.energy = 1; voice.ramp = 0; this.byNote.set(note, voice); voice.live = true;}\n    voice.fresh = fresh; voice.age = ++this.clock; this.idle = false;\n    this.excite(voice, clamp(velocity, 0, 1), cv);\n    voice.damping = this.dampers(voice); this.retune(voice);\n  }\n  noteOff(key) {\n    for (const k of key === undefined ? [...this.keys.keys()] : this.keys.has(key) ? [key] : []) {\n      const note = this.keys.get(k), left = (this.down.get(note) ?? 1) - 1;\n      this.keys.delete(k);\n      if (left > 0) {this.down.set(note, left); continue;}\n      this.down.delete(note);\n      const voice = this.byNote.get(note);\n      if (voice) {this.released(voice); this.damp(voice);}\n    }\n  }\n  released() {}\n  control(kind, level) {\n    const before = this.controls[kind]; this.controls[kind] = level;\n    if (kind === 'sustain') for (const voice of this.byNote.values()) this.damp(voice);\n    this.controlled(kind, level, before);\n  }\n  controlled() {}\n  /** How far a voice's dampers are down, 0 to 1: up while its key or the sustain pedal holds them. */\n  dampers(voice) {\n    if (this.down.has(voice.note)) return 0;\n    // Half-pedal: the felts brush the bars, damping the upper modes (whose damp rates are higher) far more.\n    return (1 - clamp(this.controls.sustain, 0, 1)) ** 2;\n  }\n  damp(voice) {const damping = this.dampers(voice); if (damping !== voice.damping) {voice.damping = damping; this.retune(voice);}}\n  retune(voice) {const partials = voice.partials; for (let j = 0; j < partials.count; j++) partials.rotate(j, this.rate, this.tune, voice.damping);}\n  /** A silent voice if there is one, or else the quietest, preferring those whose keys are up. */\n  allocate() {\n    const free = this.pool.find(v => !v.live);\n    if (free) return free;\n    let victim = this.pool[0];\n    for (const voice of this.pool) {\n      const held = this.down.has(voice.note), victimHeld = this.down.has(victim.note);\n      if ((victimHeld && !held) || (held === victimHeld && voice.energy < victim.energy)) victim = voice;\n    }\n    this.byNote.delete(victim.note); victim.live = false;\n    return victim;\n  }\n  setPitch(cents) {\n    if (Math.abs(cents - this.cents) < 0.01) return;\n    this.cents = cents; this.tune = 2 ** (cents / 1200);\n    for (const voice of this.byNote.values()) this.retune(voice);\n  }\n  /** Renders the voices' phasors into `buffer`, one partial at a time, and drops partials and voices that have died away. */\n  renderPartials(voice, n) {\n    const buffer = this.buffer, partials = voice.partials, {re, im, cr, ci, on, late, knee} = partials;\n    let energy = 0;\n    for (let j = 0; j < partials.count; j++) {\n      if (!on[j]) continue;\n      let a = re[j], b = im[j];\n      const c = cr[j], s = ci[j];\n      for (let k = 0; k < n; k++) {const t = c * a - s * b; b = s * a + c * b; a = t; buffer[k] += b;}\n      re[j] = a; im[j] = b;\n      const level = a * a + b * b;\n      if (!late[j] && level < knee[j] * knee[j]) {late[j] = 1; partials.rotate(j, this.rate, this.tune, voice.damping);}\n      if (level < FLOOR * FLOOR) {on[j] = 0; re[j] = im[j] = 0;} else energy += level;\n    }\n    return energy;\n  }\n  render(left, right, offset, n, cents, cv) {\n    this.setPitch(cents); this.cv = cv;\n    let sounding = false;\n    for (const voice of this.byNote.values()) {\n      if (!voice.live) continue;\n      this.buffer.fill(0, 0, n);\n      voice.energy = this.renderVoice(voice, n);\n      if (voice.energy <= 0) {voice.live = false; this.byNote.delete(voice.note); continue;}\n      sounding = true;\n      const buffer = this.buffer, l = voice.left, r = voice.right, onset = ONSET * this.rate;\n      for (let k = 0; k < n && voice.ramp < onset; k++) buffer[k] *= 0.5 - 0.5 * Math.cos(Math.PI * voice.ramp++ / onset);\n      for (let k = 0; k < n; k++) {left[offset + k] += buffer[k] * l; right[offset + k] += buffer[k] * r;}\n    }\n    if (this.idle && !sounding && !this.noises.busy) return;\n    this.noises.render(left, right, offset, n);\n    const peak = this.post(left, right, offset, n);\n    if (!sounding && !this.noises.busy && peak < IDLE) {this.idle = true; this.quiet(); for (let k = offset; k < offset + n; k++) left[k] = right[k] = 0;}\n  }\n  renderVoice(voice, n) {return this.renderPartials(voice, n);}\n  /** Moves partials past their knee and drops those that have died, and returns the voice's energy. */\n  settle(voice) {\n    const partials = voice.partials, {re, im, on, late, knee} = partials;\n    let energy = 0;\n    for (let j = 0; j < partials.count; j++) {\n      if (!on[j]) continue;\n      const level = re[j] * re[j] + im[j] * im[j];\n      if (!late[j] && level < knee[j] * knee[j]) {late[j] = 1; partials.rotate(j, this.rate, this.tune, voice.damping);}\n      if (level < FLOOR * FLOOR) {on[j] = 0; re[j] = im[j] = 0;} else energy += level;\n    }\n    return energy;\n  }\n  /** The instrument's body, amp or cabinet, in place over `left` and `right`; returns the block's peak. */\n  post() {return 0;}\n  /** Clears the post chain's state once everything has died away, so idle is exact silence. */\n  quiet() {}\n  clear() {for (const voice of this.pool) {voice.live = false; voice.partials.reset();} this.byNote.clear(); this.noises.clear(); this.quiet(); this.idle = true;}\n  get busy() {return !this.idle;}\n  /** Places a voice by pitch: low notes left and high notes right, as a player hears them, `width` wide. */\n  place(voice, width) {\n    const pan = clamp((voice.note - 64) / 44, -1, 1) * clamp(width, -1, 1), angle = (pan + 1) * Math.PI / 4;\n    voice.left = Math.cos(angle) * Math.SQRT2; voice.right = Math.sin(angle) * Math.SQRT2;\n  }\n}\n\n/** A tine's or a reed's note: its fundamental with a two-stage decay, and its upper modes. */\nfunction setMode(partials, j, frequency, t60, amount, {after = 0, t60After = t60, damp = 0}) {\n  partials.freq[j] = frequency; partials.prompt[j] = 6.91 / t60; partials.after[j] = 6.91 / t60After; partials.damp[j] = damp;\n  partials.ratios ??= new Float64Array(partials.size);\n  partials.knee[j] = after > 0 ? 1 : 0; partials.ratios[j] = after;\n  partials.strike(j, amount);\n}\n\n/**\n * VELVET's pianos: how much closer each one's pickups sit (Bark), how much brighter its bell rings, whether its own\n * Suitcase amp plays it, the low cut of the amp it plays into, and a trim that keeps it as loud as the others. Suitcase\n * Mk I, Stage Mk I and Stage Mk II.\n */\nconst VELVET_MODELS = [\n  {bark: 1, bell: 1, suitcase: true, lowCut: 30, trim: 1},\n  {bark: 1.3, bell: 1, suitcase: false, lowCut: 40, trim: 1.23},\n  {bark: 1.12, bell: 1.6, suitcase: false, lowCut: 62, trim: 1.23},\n];\nconst velvetModel = p => VELVET_MODELS[clamp(Math.round(p.model ?? 0), 0, VELVET_MODELS.length - 1)];\n\n/**\n * VELVET's Digital engine: each note a tine, its fundamental and its bell-like second mode, struck by a neoprene hammer\n * and read by an electromagnetic pickup whose asymmetric response barks as the tine swings wider. The Suitcase's\n * preamp, its bass and treble, and its stereo tremolo follow; a Stage plays into a guitar amp, with its tone stack's mid\n * scoop, mono tremolo and open-backed 2×12, and the Mk II rings a brighter bell over a tighter bass.\n */\nexport class TineDSP extends Struck {\n  constructor(rate) {\n    super(rate, 40, 2);\n    this.bass = [new Biquad(), new Biquad()]; this.treble = [new Biquad(), new Biquad()]; this.cab = [new Biquad(), new Biquad()]; this.dc = [new Biquad(), new Biquad()];\n    this.mid = [new Biquad(), new Biquad()]; this.presence = [new Biquad(), new Biquad()];\n    this.phase = 0; this.swell = 1;\n  }\n  configured() {\n    const p = this.p, rate = this.rate, model = velvetModel(p);\n    for (const c of [0, 1]) {\n      this.bass[c].set('lowshelf', rate, 180, 0.7, p.bass); this.treble[c].set('highshelf', rate, 3200, 0.7, p.treble);\n      this.dc[c].set('highpass', rate, model.lowCut, 0.6);\n      if (model.suitcase) this.cab[c].set('lowpass', rate, 7500, 0.6);\n      else {\n        // The guitar amp's tone stack scoops the mids, and its open-backed 2×12 has a presence peak.\n        this.mid[c].set('peak', rate, 550, 0.8, -3.5); this.cab[c].set('lowpass', rate, 5200, 0.7); this.presence[c].set('peak', rate, 2200, 1, 2.5);\n      }\n    }\n  }\n  excite(voice, velocity, cv) {\n    const p = this.p, n = clamp(voice.note, 28, 103), f = mtof(voice.note), partials = voice.partials;\n    const t60 = 10 * 2 ** (-(n - 36) / 27.5) * p.decay, damp = 6.91 / ((0.32 * 2 ** ((0.5 - p.damper) * 2.2)) * (1 + Math.max(0, 60 - n) / 40));\n    partials.count = 2;\n    const swing = velocity ** 1.5;\n    setMode(partials, 0, f, t60 / 3, swing, {after: 0.55, t60After: t60, damp});\n    const model = velvetModel(p), ratio = clamp(6.27 + (60 - n) * 0.03, 4.5, 7.5), bell = p.bell * (0.15 + 0.85 * p.hardness) * (0.3 + 0.7 * velocity) * 0.45 * model.bell;\n    setMode(partials, 1, f * ratio, 0.9 * 2 ** (-(n - 36) / 40), swing * bell, {damp: damp * 2});\n    // The pickup barks harder the further a tine swings: velocity and Bark, plus the Brightness CV; a Stage's sit closer.\n    voice.drive = (0.6 + 2.6 * clamp(p.bark + cv * 0.5, 0, 1.5)) * model.bark;\n    this.place(voice, 0);\n    this.noises.add({amount: 0.004 * velocity * velocity * (0.3 + p.hardness), decay: 0.003, tone: 3000});\n  }\n  renderVoice(voice, n) {\n    const buffer = this.buffer, {re, im, cr, ci, on} = voice.partials, drive = voice.drive, a = 0.35;\n    const zero = a / Math.sqrt(1 + a * a), gain = (1 + a * a) ** 1.5 / drive;\n    let a0 = re[0], b0 = im[0], a1 = re[1], b1 = im[1];\n    const c0 = cr[0], s0 = ci[0], c1 = on[1] ? cr[1] : 0, s1 = on[1] ? ci[1] : 0;\n    for (let k = 0; k < n; k++) {\n      let t = c0 * a0 - s0 * b0; b0 = s0 * a0 + c0 * b0; a0 = t;\n      t = c1 * a1 - s1 * b1; b1 = s1 * a1 + c1 * b1; a1 = t;\n      const u = (b0 + b1) * drive + a;\n      buffer[k] = (u / Math.sqrt(1 + u * u) - zero) * gain;\n    }\n    re[0] = a0; im[0] = b0; re[1] = a1; im[1] = b1;\n    return this.settle(voice);\n  }\n  post(left, right, offset, n) {\n    const p = this.p, model = velvetModel(p), step = TAU * p.tremRate / this.rate, depth = p.tremDepth, drive = 1 + 5 * p.drive, makeup = 0.55 / drive ** 0.6 * model.trim;\n    const target = clamp(this.controls.expression, 0, 1) ** 1.6, smooth = 1 - Math.exp(-1 / (0.02 * this.rate));\n    let peak = 0;\n    for (let k = offset; k < offset + n; k++) {\n      this.swell += (target - this.swell) * smooth;\n      this.phase += step; if (this.phase > TAU) this.phase -= TAU;\n      const pan = Math.sin(this.phase) * 0.5, x = Math.tanh((left[k] + right[k]) * 0.5 * drive) * makeup * p.level * this.swell;\n      let l = this.bass[0].process(x), r;\n      if (model.suitcase) {\n        // The Suitcase pans between its two amps.\n        r = this.bass[1].process(x);\n        l = this.dc[0].process(this.cab[0].process(this.treble[0].process(l))) * (1 - depth * (0.5 + pan)); r = this.dc[1].process(this.cab[1].process(this.treble[1].process(r))) * (1 - depth * (0.5 - pan));\n      } else {\n        // A guitar amp is mono, and its tremolo pulses the level.\n        l = r = this.dc[0].process(this.presence[0].process(this.cab[0].process(this.mid[0].process(this.treble[0].process(l))))) * (1 - depth * (0.5 + pan));\n      }\n      left[k] = l; right[k] = r;\n      const a = Math.max(Math.abs(l), Math.abs(r)); if (a > peak) peak = a;\n    }\n    return peak;\n  }\n  quiet() {for (const c of [0, 1]) [this.bass, this.treble, this.cab, this.dc, this.mid, this.presence].forEach(f => f[c].reset());}\n}\n\n/**\n * REED's Digital engine: each note a steel reed, its fundamental and the cantilever's upper modes (6.27 and 17.55 times\n * it), read by an electrostatic pickup whose 1/(d − x) response grows asymmetric, and barks, as the reed swings closer.\n * The amp's preamp, mono tremolo and small speakers follow.\n */\nexport class ReedDSP extends TineDSP {\n  constructor(rate) {super(rate); this.pool = Array.from({length: 40}, () => new Voice(3)); this.speaker = [new Biquad(), new Biquad(), new Biquad()]; this.lift = new Biquad();}\n  configured() {\n    const p = this.p, rate = this.rate;\n    // The 200A's own speakers: no deep bass, a forward midrange and a soft top. Line out is flat.\n    if (p.speaker === 1) {this.speaker[0].set('highpass', rate, 30, 0.6); this.speaker[1].set('peak', rate, 1000, 1, 0); this.speaker[2].set('lowpass', rate, 12000, 0.6);}\n    else {this.speaker[0].set('highpass', rate, 110, 0.8); this.speaker[1].set('peak', rate, 1150, 1.1, 3.5); this.speaker[2].set('lowpass', rate, 5200, 0.8);}\n    this.lift.set('highpass', rate, 25, 0.6);\n  }\n  excite(voice, velocity, cv) {\n    const p = this.p, n = clamp(voice.note, 28, 103), f = mtof(voice.note), partials = voice.partials;\n    const t60 = 4.5 * 2 ** (-(n - 40) / 24) * p.decay, damp = 6.91 / (0.13 * 2 ** ((0.5 - p.damper) * 2.2));\n    partials.count = 3;\n    setMode(partials, 0, f, t60 / 2.5, velocity ** 1.4, {after: 0.6, t60After: t60, damp});\n    setMode(partials, 1, f * 6.27, 0.25, velocity * velocity * 0.22 * (0.4 + 0.6 * p.hardness), {damp: damp * 2});\n    setMode(partials, 2, f * 17.55, 0.06, velocity * velocity * 0.07 * p.hardness, {damp: damp * 3});\n    voice.drive = clamp(0.15 + 0.7 * clamp(p.bark + cv * 0.5, 0, 1.2) * velocity, 0, 0.85);\n    this.place(voice, 0);\n    this.noises.add({amount: 0.003 * velocity * velocity * (0.3 + p.hardness), decay: 0.003, tone: 2500});\n  }\n  renderVoice(voice, n) {\n    const buffer = this.buffer, {re, im, cr, ci, on} = voice.partials, c = voice.drive;\n    let a0 = re[0], b0 = im[0], a1 = re[1], b1 = im[1], a2 = re[2], b2 = im[2];\n    const c0 = cr[0], s0 = ci[0], c1 = on[1] ? cr[1] : 0, s1 = on[1] ? ci[1] : 0, c2 = on[2] ? cr[2] : 0, s2 = on[2] ? ci[2] : 0;\n    for (let k = 0; k < n; k++) {\n      let t = c0 * a0 - s0 * b0; b0 = s0 * a0 + c0 * b0; a0 = t;\n      t = c1 * a1 - s1 * b1; b1 = s1 * a1 + c1 * b1; a1 = t;\n      t = c2 * a2 - s2 * b2; b2 = s2 * a2 + c2 * b2; a2 = t;\n      const x = b0 + b1 + b2;\n      buffer[k] = x / Math.max(0.08, 1 - c * x);\n    }\n    re[0] = a0; im[0] = b0; re[1] = a1; im[1] = b1; re[2] = a2; im[2] = b2;\n    return this.settle(voice);\n  }\n  post(left, right, offset, n) {\n    const p = this.p, step = TAU * p.tremRate / this.rate, depth = p.tremDepth, drive = 1 + 6 * p.drive, makeup = 0.6 / drive ** 0.6;\n    const target = clamp(this.controls.expression, 0, 1) ** 1.6, smooth = 1 - Math.exp(-1 / (0.02 * this.rate));\n    let peak = 0;\n    for (let k = offset; k < offset + n; k++) {\n      this.swell += (target - this.swell) * smooth;\n      this.phase += step; if (this.phase > TAU) this.phase -= TAU;\n      // The 200A's tremolo is a mono swell in level.\n      const tremolo = 1 - depth * (0.5 + 0.5 * Math.sin(this.phase));\n      let x = this.lift.process((left[k] + right[k]) * 0.5);\n      x = Math.tanh(x * drive) * makeup;\n      for (const f of this.speaker) x = f.process(x);\n      x *= tremolo * p.level * this.swell;\n      left[k] = right[k] = x;\n      if (Math.abs(x) > peak) peak = Math.abs(x);\n    }\n    return peak;\n  }\n  quiet() {this.speaker.forEach(f => f.reset()); this.lift.reset();}\n}\n\n/** A Pianet reed's cantilever modes against its fundamental. */\nconst PLANET_RATIOS = [1, 6.27, 17.55];\n/** Where the N's reed rests below the middle of its pickup's field, and how far off the T's coil sits, in pickup gaps. */\nconst PLANET_REST = -0.5, PLANET_OFFSET = 0.25;\n/** The N's electrostatic pickup, the capacitance with the reed `u` gaps from rest; the T's coil, the flux through it. */\nconst capacitance = u => 1 / (1 + (u - PLANET_REST) ** 2);\nconst flux = u => 1 / Math.sqrt((u + PLANET_OFFSET) ** 2 + 1);\n/** Each pickup's slope at rest, which a reading divides out so Bark changes the tone and not the level. */\nconst pickupSlope = coil => coil ? PLANET_OFFSET / (PLANET_OFFSET ** 2 + 1) ** 1.5 : -2 * PLANET_REST / (1 + PLANET_REST ** 2) ** 2;\n\n/**\n * A pluck, as the Analog engine plucks: how far the pad bends the reed before it lets go (1 at full velocity and middle\n * grip), how long it takes to lift it there, and how long to peel away, in seconds, for a reed at `f` Hz with `grip`\n * (Pluck) on the N's pads or, `soft`, the T's.\n */\nexport function planetPluck(f, velocity, grip, soft) {\n  velocity = clamp(velocity, 0, 1); grip = clamp(grip, 0, 1);\n  const bend = (0.25 + 0.75 * velocity) * (0.75 + 0.5 * grip), rise = 0.006 - 0.0035 * velocity;\n  const peel = Math.min(0.0016 * 2 ** (-(grip - 0.5) * 2.5) * (soft ? 2.2 : 1) * (1 - 0.35 * velocity), 0.004, 0.45 / f);\n  return {bend, rise, peel};\n}\n\n/** How much of a held bend a mode keeps ringing when the grip peels away over a raised cosine `x` of its periods long. */\nfunction reach(x) {\n  const d = 1 - 4 * x * x;\n  return Math.abs(d) < 1e-4 ? Math.PI / 4 : Math.abs(Math.cos(Math.PI * x) / d);\n}\n\n/** Where a lifting pad has carried its reed's tip, `left` samples before it lets go. */\nconst carried = lift => lift.from + (lift.height - lift.from) * (0.5 - 0.5 * Math.cos(Math.PI * (lift.n - lift.left) / lift.n));\n\n/**\n * PLANET's Digital engine: each key's sticky pad lifts its steel reed, holding the tip, then peels away, and the reed\n * rings from that bend, mostly in its fundamental, its upper modes as far as the peel is quick against their periods.\n * The N reads it with an electrostatic pickup that barks as the reed swings wide, the T with a coil that rounds it off.\n * Both pickups give the reading's rate of change, as the real ones do. Letting a key up lays the pad back on the reed\n * with a soft thud. A small amp follows, with Drive, Tone and a mono tremolo.\n */\nexport class PlanetDSP extends Struck {\n  constructor(rate) {\n    super(rate, 40, 3);\n    this.input = new Biquad(); this.top = new Biquad(); this.tone = new Biquad(); this.amp = [new Biquad(), new Biquad()];\n    this.coil = false; this.phase = 0; this.swell = 1;\n  }\n  configured() {\n    const p = this.p, rate = this.rate, coil = Math.round(p.model ?? 0) === 1;\n    if (coil !== this.coil) {\n      // The other pickup reads the reeds afresh, at their own pitch's gain.\n      this.coil = coil;\n      for (const voice of this.byNote.values()) {voice.last = NaN; voice.norm = 1 / (pickupSlope(coil) * voice.drive * Math.max(TAU * mtof(voice.note) / rate, 1e-4));}\n    }\n    this.input.set('highpass', rate, 25, 0.6);\n    // The T's coils against the cable: a soft peak, then the top rolls away.\n    this.top.set('lowpass', rate, coil ? 1500 : 9000, coil ? 0.9 : 0.7);\n    this.tone.set('highshelf', rate, 2000, 0.7, p.tone ?? 0);\n    // A small combo: no deep bass and a little forward.\n    this.amp[0].set('highpass', rate, 70, 0.7); this.amp[1].set('peak', rate, 1200, 1, 1.5);\n  }\n  excite(voice, velocity, cv) {\n    const p = this.p, rate = this.rate, coil = this.coil, n = clamp(voice.note, 28, 103), f = mtof(voice.note), partials = voice.partials;\n    // A pad grabbing a reed it is still lifting carries it on from where it is.\n    const from = !voice.fresh && voice.lift?.left > 0 ? carried(voice.lift) : 0;\n    if (voice.fresh) voice.last = NaN;\n    const t60 = 3 * 2 ** (-(n - 36) / 25) * Math.max(p.decay, 0.05), damp = 6.91 / (0.05 * 2 ** ((0.5 - p.damper) * 2.2));\n    const grip = p.pluck, {bend, rise, peel} = planetPluck(f, velocity, grip, coil);\n    const bark = clamp(p.bark + cv * 0.5, 0, 1.3), drive = coil ? 0.12 + 0.45 * bark : 0.5 + 1.6 * bark, w0 = TAU * f / rate;\n    partials.count = Math.max(1, PLANET_RATIOS.filter(r => f * r < 0.42 * rate).length);\n    const lives = [t60, 0.3, 0.08], amounts = [];\n    let height = 0;\n    for (let m = 0; m < partials.count; m++) {\n      const ratio = PLANET_RATIOS[m];\n      partials.freq[m] = f * ratio; partials.prompt[m] = partials.after[m] = 6.91 / lives[m]; partials.damp[m] = damp * (1 + m);\n      partials.knee[m] = 0; partials.late[m] = 1;\n      // Held, the bend sits in each mode as its static give; it rings on as far as the peel is quick against its period.\n      const give = bend * Math.tan(w0 / 2) / (ratio * Math.tan(Math.min(w0 * ratio, Math.PI * 0.94) / 2));\n      amounts.push(give * reach(f * ratio * peel)); height += amounts[m];\n    }\n    const lift = Math.max(1, Math.floor(rise * rate));\n    voice.lift = {left: lift, n: lift, from, height, amounts};\n    voice.drive = drive; voice.norm = 1 / (pickupSlope(coil) * drive * Math.max(w0, 1e-4));\n    this.place(voice, 0);\n    // The key bottoming out, and the N's pad ticking as it lets go.\n    this.noises.add({amount: 0.0015 * velocity * velocity, decay: 0.004, tone: 900});\n    this.noises.add({amount: (coil ? 0.0006 : 0.0025) * bend * (0.5 + grip), decay: 0.0012, tone: 5000, delay: rise});\n  }\n  /** The pad lets go: the reed rings from the bend it held. */\n  letGo(voice) {\n    const partials = voice.partials, amounts = voice.lift.amounts;\n    for (let j = 0; j < partials.count; j++) {partials.strike(j, amounts[j], Math.PI / 2); partials.rotate(j, this.rate, this.tune, voice.damping);}\n  }\n  released(voice) {\n    // The pad lands back on a ringing reed.\n    if (this.dampers(voice) > 0.5 && voice.energy > 1e-6) this.noises.add({amount: 0.002, decay: 0.006, tone: 700});\n  }\n  renderVoice(voice, n) {\n    const buffer = this.buffer, partials = voice.partials, {re, im, cr, ci, on} = partials, count = partials.count, lift = voice.lift;\n    const read = this.coil ? flux : capacitance, drive = voice.drive, norm = voice.norm;\n    let last = voice.last, k = 0;\n    while (k < n) {\n      // Up to the moment the pad lets go, then on from there.\n      const end = lift.left > 0 ? Math.min(n, k + lift.left) : n;\n      const live = j => j < count && on[j];\n      let a0 = re[0], b0 = im[0], a1 = re[1], b1 = im[1], a2 = re[2], b2 = im[2];\n      const c0 = live(0) ? cr[0] : 0, s0 = live(0) ? ci[0] : 0, c1 = live(1) ? cr[1] : 0, s1 = live(1) ? ci[1] : 0, c2 = live(2) ? cr[2] : 0, s2 = live(2) ? ci[2] : 0;\n      for (; k < end; k++) {\n        let t = c0 * a0 - s0 * b0; b0 = s0 * a0 + c0 * b0; a0 = t;\n        t = c1 * a1 - s1 * b1; b1 = s1 * a1 + c1 * b1; a1 = t;\n        t = c2 * a2 - s2 * b2; b2 = s2 * a2 + c2 * b2; a2 = t;\n        let x = b0 + b1 + b2;\n        if (lift.left > 0) {lift.left--; x += carried(lift);}\n        const reading = read(x * drive);\n        // A fresh reading starts from where the reed is, without a step.\n        if (last !== last) last = reading;\n        buffer[k] = (reading - last) * norm; last = reading;\n      }\n      re[0] = a0; im[0] = b0; re[1] = a1; im[1] = b1; re[2] = a2; im[2] = b2;\n      if (lift.left === 0 && lift.amounts) {this.letGo(voice); lift.amounts = null;}\n    }\n    voice.last = last;\n    const energy = this.settle(voice);\n    // A reed still being lifted sounds, though nothing in it rings yet.\n    return lift.amounts ? Math.max(energy, 1) : energy;\n  }\n  post(left, right, offset, n) {\n    const p = this.p, step = TAU * p.tremRate / this.rate, depth = p.tremDepth, drive = 1 + 6 * p.drive, makeup = 0.55 / drive ** 0.6;\n    const bias = this.coil ? 0.05 : 0.1, zero = Math.tanh(bias);\n    const target = clamp(this.controls.expression, 0, 1) ** 1.6, smooth = 1 - Math.exp(-1 / (0.02 * this.rate));\n    let peak = 0;\n    for (let k = offset; k < offset + n; k++) {\n      this.swell += (target - this.swell) * smooth;\n      this.phase += step; if (this.phase > TAU) this.phase -= TAU;\n      // A mono swell in level, as the Pianet's amps pulse it.\n      const tremolo = 1 - depth * (0.5 + 0.5 * Math.sin(this.phase));\n      let x = this.input.process((left[k] + right[k]) * 0.5);\n      x = (Math.tanh(x * drive + bias) - zero) * makeup;\n      x = this.amp[1].process(this.amp[0].process(this.tone.process(this.top.process(x))));\n      x *= tremolo * p.level * this.swell;\n      left[k] = right[k] = x;\n      if (Math.abs(x) > peak) peak = Math.abs(x);\n    }\n    return peak;\n  }\n  quiet() {this.input.reset(); this.top.reset(); this.tone.reset(); this.amp.forEach(f => f.reset());}\n  clear() {for (const voice of this.pool) voice.lift = null; super.clear();}\n}\n\n/**\n * A STRUT key's string, as the Analog engine strings it: where its upper and lower pickups sit as fractions of its\n * speaking length, its inharmonicity, and how long it rings held, in seconds, before Decay.\n */\nexport function strutString(note) {\n  const n = clamp(note, 24, 96), length = 0.9 * 2 ** (-(n - 29) / 20.3);\n  return {pu: Math.min(0.035 / length, 0.3), pl: Math.min(0.075 / length, 0.45), b: 2e-5 * 2 ** ((n - 29) / 14), t60: 5 * 2 ** (-(n - 29) / 22)};\n}\n/** How long, in seconds, the rubber tip takes to drive a string onto its anvil. */\nexport const strutContact = (note, velocity, hardness) =>\n  0.0003 * 2 ** (-(clamp(hardness, 0, 1) - 0.5) * 1.5) * (2 - 1.6 * clamp(velocity, 0, 1)) * 2 ** (-(clamp(note, 24, 96) - 60) / 60);\n/** Partial `k`'s frequency against the fundamental on a string of inharmonicity `b`. */\nconst stretched = (k, b) => k * Math.sqrt((1 + b * k * k) / (1 + b));\n/** The magnitude at `f` Hz of a half-sine push `tau` seconds long, against its area. */\nfunction pulseSpectrum(f, tau) {\n  const x = 2 * f * tau, d = 1 - x * x;\n  return Math.abs(d) < 1e-6 ? Math.PI / 4 : Math.abs(Math.cos(Math.PI * f * tau) / d);\n}\n/** The AB and CD rockers' pickups, lower, upper, both, or both out of phase, and each one's trim against both. */\nconst strutPickups = p => (Math.round(p.pickupCD ?? 1) === 1 ? 2 : 0) + (Math.round(p.pickupAB ?? 0) === 1 ? 1 : 0);\nconst PICKUP_TRIM = [1.45, 1.5, 1, 1.05];\n/** A partial `r` times the fundamental, as the chosen pickups read it from `pu` and `pl` of the string's length. */\nfunction pickupWeight(choice, r, pu, pl) {\n  const u = 2 * Math.sin(Math.PI * r * pu), l = 2 * Math.sin(Math.PI * r * pl);\n  return choice === 0 ? l : choice === 1 ? u : choice === 2 ? u + l : u - l;\n}\n/** The highest partial a STRUT string sounds. */\nconst strutTop = rate => Math.min(0.45 * rate, 12000);\n/** A string's level through `choice`, pushed for `tau` seconds: the root sum of its partials' squares. */\nfunction strutLoudness(rate, f0, b, tau, choice, pu, pl) {\n  let sum = 0;\n  for (let k = 1; k <= 80; k++) {\n    const r = stretched(k, b);\n    if (f0 * r > strutTop(rate)) break;\n    const a = pulseSpectrum(f0 * r, tau) * pickupWeight(choice, r, pu, pl);\n    sum += a * a;\n  }\n  return Math.max(Math.sqrt(sum), 1e-6);\n}\nconst rate60 = t60 => 6.907755 / Math.max(t60, 1e-4);\n/** A held string's losses per second at DC and at `fh`, with the mute `mute` of the way on and, `free`, the yarn holding it. */\nfunction strutLosses(f0, t60, mute, free) {\n  const fh = Math.min(10 * f0, 8000), air = 2 * (1e-4 * fh + 8e-8 * fh * fh);\n  let s0 = rate60(t60), sh = rate60(t60) + air;\n  s0 += mute * rate60(0.18); sh += mute * rate60(0.03);\n  if (free) {s0 += rate60(0.06); sh += rate60(0.02);}\n  return {s0, sh, fh};\n}\n/** The decay per second at `f` Hz of the Analog string's one-pole loss filter, which loses `s0` at DC and `sh` at `fh`. */\nfunction decayAt(rate, f0, {s0, sh, fh}, f) {\n  const m0 = Math.exp(-s0 / f0), m = clamp(Math.exp(-sh / f0) / m0, 0, 1), k = 1 - m * m, wh = TAU * Math.min(fh, rate * 0.45) / rate;\n  let pole = 0;\n  if (k >= 1e-9) {const b = 1 - m * m * Math.cos(wh); pole = clamp((-b + Math.sqrt(Math.max(b * b - k * k, 0))) / k, -0.95, 0);}\n  const w = TAU * f / rate, mag = m0 * (1 + pole) / Math.hypot(1 + pole * Math.cos(w), pole * Math.sin(w));\n  return -f0 * Math.log(mag);\n}\n\n/**\n * STRUT's Digital engine: each key's string as its partials, stretched by the string's stiffness. The rubber tip's push\n * gives every partial its share, the more and higher the briefer it is, and each decays as the Analog string's loss\n * filter decays it, faster under the mute and the yarn. The pickups read each partial by where they lie along the\n * string, as the Analog engine's combs do, and the tone rockers, the amp's drive and the swell follow.\n */\nexport class StrutDSP extends Struck {\n  constructor(rate) {\n    super(rate, 24, 80);\n    for (const voice of this.pool) voice.weights = new Float64Array(80);\n    this.dc = new Biquad(); this.brilliant = new Biquad(); this.treble = new Biquad(); this.medium = new Biquad(); this.soft = new Biquad();\n    this.gain = 1; this.swell = 1; this.choice = -1; this.losses = '';\n  }\n  configured() {\n    const p = this.p, rate = this.rate;\n    this.dc.set('highpass', rate, 30, 0.6);\n    // The D6's tone rockers: Brilliant and Treble take the bass out, Medium and Soft the top.\n    this.brilliant.set('highpass', rate, 1400, 0.55); this.treble.set('highpass', rate, 500, 0.5);\n    this.medium.set('lowpass', rate, 2400, 0.6); this.soft.set('lowpass', rate, 900, 0.55);\n    this.tone = [p.brilliant, p.treble, p.medium, p.soft].map(on => Math.round(on ?? 0) === 1);\n    this.gain = db([6, 2.5, 1, 3].reduce((sum, makeup, i) => sum + (this.tone[i] ? makeup : 0), 0));\n    const choice = strutPickups(p), losses = `${p.mute}:${p.decay}`;\n    if (choice !== this.choice) {this.choice = choice; for (const voice of this.byNote.values()) this.weigh(voice);}\n    if (losses !== this.losses) {this.losses = losses; for (const voice of this.byNote.values()) this.decays(voice);}\n  }\n  control(kind, level) {\n    // A clavinet has no sustain pedal: the yarn always damps a string whose key is up.\n    if (kind === 'expression') super.control(kind, level);\n  }\n  dampers(voice) {return this.down.has(voice.note) ? 0 : 1;}\n  /** Each partial as the chosen pickups read it, at the level that makes every key as loud as the next. */\n  weigh(voice) {\n    const {pu, pl} = voice.string, trim = PICKUP_TRIM[this.choice] * voice.norm, partials = voice.partials;\n    for (let j = 0; j < partials.count; j++) voice.weights[j] = pickupWeight(this.choice, partials.freq[j] / voice.f0, pu, pl) * trim;\n  }\n  /** Each partial's decay held, and how much faster the yarn takes it once the key is up. */\n  decays(voice) {\n    const p = this.p, partials = voice.partials, mute = clamp(p.mute ?? 0, 0, 1), t60 = voice.string.t60 * Math.max(p.decay ?? 1, 0.05);\n    const held = strutLosses(voice.f0, t60, mute, false), free = strutLosses(voice.f0, t60, mute, true);\n    for (let j = 0; j < partials.count; j++) {\n      const f = partials.freq[j], sigma = decayAt(this.rate, voice.f0, held, f);\n      partials.prompt[j] = partials.after[j] = sigma; partials.damp[j] = Math.max(decayAt(this.rate, voice.f0, free, f) - sigma, 0);\n    }\n    this.retune(voice);\n  }\n  excite(voice, velocity, cv) {\n    const p = this.p, rate = this.rate, partials = voice.partials, f0 = mtof(voice.note), string = strutString(voice.note);\n    const hardness = clamp((p.hardness ?? 0.5) + cv * 0.5, 0, 1);\n    // The tip's push, as many whole samples long as the Analog engine's.\n    const tau = clamp(Math.floor(strutContact(voice.note, velocity, hardness) * rate), 2, Math.floor(rate * 0.004) + 1) / rate;\n    if (voice.fresh) {\n      voice.f0 = f0; voice.string = string;\n      voice.norm = 0.22 / strutLoudness(rate, f0, string.b, strutContact(voice.note, 0.8, 0.5), 2, string.pu, string.pl);\n      let count = 0;\n      while (count < 80 && f0 * stretched(count + 1, string.b) <= strutTop(rate)) {partials.freq[count] = f0 * stretched(count + 1, string.b); partials.knee[count] = 0; partials.late[count] = 1; count++;}\n      partials.count = Math.max(count, 1);\n      this.weigh(voice); this.decays(voice);\n      // The voice speaks from its first pulse, which arrives a little after the press; no fade-in.\n      voice.ramp = Infinity;\n    }\n    // A pulse train in the string, each partial `velocity` times the push's spectrum there, read as the pickups' combs\n    // read it: the push centred half its length in, the pickups' reading half the lower one's reach after that. The\n    // Analog string hears its push after one trip round the loop, and so one period's loss.\n    const delay = tau * rate / 2 + string.pl * rate / f0 / 2;\n    for (let j = 0; j < partials.count; j++) {\n      const f = partials.freq[j];\n      partials.strike(j, velocity * pulseSpectrum(f, tau) * Math.exp(-partials.prompt[j] / voice.f0), Math.PI - TAU * f * this.tune / rate * delay);\n    }\n    voice.level = 0;\n    // The tip meeting the string on the anvil.\n    this.noises.add({amount: 0.004 * velocity * velocity * (0.5 + hardness), decay: 0.0025, tone: 3500});\n  }\n  released(voice) {\n    if (!voice.live) return;\n    // The string lifts off the anvil, and its whole length, yarn and all, plunks.\n    const p = this.p;\n    this.noises.add({amount: (p.release ?? 0.5) * (0.004 + 0.3 * voice.level), decay: 0.045, tone: 1200, sine: voice.f0 * this.tune * 0.79, sineAmount: 4});\n  }\n  renderVoice(voice, n) {\n    const buffer = this.buffer, partials = voice.partials, {re, im, cr, ci, on} = partials, weights = voice.weights;\n    let energy = 0;\n    for (let j = 0; j < partials.count; j++) {\n      if (!on[j]) continue;\n      let a = re[j], b = im[j];\n      const c = cr[j], s = ci[j], w = weights[j];\n      for (let k = 0; k < n; k++) {const t = c * a - s * b; b = s * a + c * b; a = t; buffer[k] += w * b;}\n      re[j] = a; im[j] = b;\n      const level = a * a + b * b;\n      if (level < FLOOR * FLOOR) {on[j] = 0; re[j] = im[j] = 0;} else energy += level;\n    }\n    let level = 0;\n    for (let k = 0; k < n; k++) level = Math.max(level, Math.abs(buffer[k]));\n    voice.level = level;\n    return energy;\n  }\n  post(left, right, offset, n) {\n    const p = this.p, drive = 1 + 5 * p.drive, makeup = 0.9 / drive ** 0.6, gain = this.gain, [brilliant, treble, medium, soft] = this.tone;\n    const target = clamp(this.controls.expression, 0, 1) ** 1.6, smooth = 1 - Math.exp(-1 / (0.02 * this.rate));\n    let peak = 0;\n    for (let k = offset; k < offset + n; k++) {\n      this.swell += (target - this.swell) * smooth;\n      let x = this.dc.process((left[k] + right[k]) * 0.5);\n      if (brilliant) x = this.brilliant.process(x);\n      if (treble) x = this.treble.process(x);\n      if (medium) x = this.medium.process(x);\n      if (soft) x = this.soft.process(x);\n      // The amp it plays into, a little pushed: the clavinet's own bark.\n      x = Math.tanh(x * gain * drive) * makeup * p.level * this.swell;\n      left[k] = right[k] = x;\n      if (Math.abs(x) > peak) peak = Math.abs(x);\n    }\n    return peak;\n  }\n  quiet() {[this.dc, this.brilliant, this.treble, this.medium, this.soft].forEach(f => f.reset());}\n}\n\n/** The drawbars' pitches in semitones from the key: 16′, 5⅓′, 8′, 4′, 2⅔′, 2′, 1⅗′, 1⅓′ and 1′. */\nexport const DRAWBAR_PITCHES = [-12, 7, 0, 12, 19, 24, 28, 31, 36];\n/** The tonewheels: 91 wheels from C1 (MIDI 24) to F♯8 (114). A drawbar's pitch above or below them folds back an octave. */\nexport const WHEEL_LOW = 24, WHEEL_HIGH = 114;\nexport const wheelOf = (note, pitch) => {let m = note + pitch; while (m > WHEEL_HIGH) m -= 12; while (m < WHEEL_LOW) m += 12; return m;};\n/** A drawbar's level: 8 is full, and each step down is 3 dB quieter, 0 off. */\nexport const drawbarLevel = value => value > 0 ? db(-(8 - Math.round(value)) * 3) : 0;\n/** The tonewheels' gears tune them a little off equal temperament: a fixed cent or so, wheel by wheel. */\nconst wheelCents = wheel => 0.9 * Math.sin(wheel * 1.73) + 0.4 * Math.sin(wheel * 0.61);\nconst TABLE = (() => {const t = new Float64Array(4097); for (let i = 0; i <= 4096; i++) t[i] = Math.sin(TAU * i / 4096); return t;})();\n/** Scanner vibrato and chorus: the peak delay swing in ms of V1, V2 and V3, and whether the dry signal mixes in. */\nconst SCANNER = [null, [0.09, false], [0.19, false], [0.32, false], [0.09, true], [0.19, true], [0.32, true]];\n/**\n * Percussion: its peak on Normal against a full drawbar on the same key, so it rings out over the registration (Soft is\n * 6 dB down), and its capacitor's time constants in seconds: Fast is gone in about half a second, Slow in two and a half.\n */\nconst PERC_PEAK = 2.2, PERC_FAST = 0.15, PERC_SLOW = 0.55;\n/**\n * Balance tilts the cabinet: toward either end the other rotor falls 12 dB, never to nothing, and the favoured one\n * rises, the horn 6 dB and the drum 1.5, since the horn carries less of the organ. Both are whole at 0.5. Returns\n * [horn, drum].\n */\nconst BALANCE_CUT = 12, HORN_LIFT = 6, DRUM_LIFT = 1.5;\nexport function balanceGains(balance) {\n  const tilt = clamp(balance, 0, 1) * 2 - 1;\n  return tilt >= 0 ? [db(HORN_LIFT * tilt), db(-BALANCE_CUT * tilt)] : [db(BALANCE_CUT * tilt), db(-DRUM_LIFT * tilt)];\n}\n\n/**\n * DRAWBAR's Digital engine, a tonewheel organ: 91 always-turning wheels, each a sine, keyed through the drawbars, so\n * keys that share a wheel share its phase as on the real thing. Single-trigger percussion on the second or third\n * harmonic, key click, leakage, the scanner vibrato and chorus, the swell pedal, the preamp and a rotary speaker whose\n * horn and drum speed up and slow down with their own inertia.\n */\nexport class OrganDSP {\n  constructor(rate) {\n    this.rate = rate; this.p = null; this.controls = {...CONTROLS_AT_REST}; this.tune = 1; this.cents = 0;\n    const wheels = WHEEL_HIGH + 1;\n    this.phase = new Float64Array(wheels); this.amp = new Float64Array(wheels); this.target = new Float64Array(wheels);\n    this.percAmp = new Float64Array(wheels); this.percTarget = new Float64Array(wheels); this.step = new Float64Array(wheels);\n    for (let w = WHEEL_LOW; w <= WHEEL_HIGH; w++) this.phase[w] = (w * 0.618) % 1;\n    this.keys = new Map(); this.percEnv = 0; this.percAt = -1; this.time = 0; this.active = [];\n    this.dry = new Float64Array(QUANTUM); this.clicks = [new Float64Array(QUANTUM), new Float64Array(QUANTUM)]; this.noises = new Noises(rate); this.idle = true;\n    this.scan = new Float64Array(2048); this.scanAt = 0; this.scanPhase = 0;\n    this.swellShelf = new Biquad(); this.swell = 1; this.swellSet = -1;\n    this.crossLow = [new Biquad(), new Biquad()]; this.crossHigh = [new Biquad(), new Biquad()];\n    this.horn = new Float64Array(2048); this.drum = new Float64Array(2048); this.rotorAt = 0;\n    this.hornAngle = 0; this.drumAngle = Math.PI / 3; this.hornSpeed = 0.8; this.drumSpeed = 0.7;\n    this.dc = [new Biquad(), new Biquad()];\n  }\n  configure(params) {\n    const first = !this.p; this.p = params;\n    if (first) {\n      for (const f of this.crossLow) f.set('lowpass', this.rate, 800, Math.SQRT1_2);\n      for (const f of this.crossHigh) f.set('highpass', this.rate, 800, Math.SQRT1_2);\n      for (const f of this.dc) f.set('highpass', this.rate, 20, 0.6);\n    }\n    this.retarget();\n  }\n  setPitch(cents) {\n    if (Math.abs(cents - this.cents) < 0.01 && this.step[WHEEL_LOW]) return;\n    this.cents = cents; this.tune = 2 ** (cents / 1200);\n    for (let w = WHEEL_LOW; w <= WHEEL_HIGH; w++) this.step[w] = mtof(w) * 2 ** (wheelCents(w) / 1200) * this.tune / this.rate;\n  }\n  /** Each wheel's level from the keys held and the drawbars, and each percussion wheel's. */\n  retarget() {\n    const p = this.p; if (!p) return;\n    this.target.fill(0); this.percTarget.fill(0);\n    const perc = p.percussion === 1, normal = perc && p.percVolume === 0, levels = DRAWBAR_PITCHES.map((_, d) => drawbarLevel(p[`drawbar${d + 1}`]) * (normal ? 0.71 : 1));\n    // Percussion takes the 1′ drawbar's keying, as on the B-3.\n    if (perc) levels[8] = 0;\n    const leak = p.leakage;\n    for (const key of this.keys.values()) {\n      DRAWBAR_PITCHES.forEach((pitch, d) => {\n        if (!levels[d]) return;\n        const w = wheelOf(key.note, pitch); this.target[w] += levels[d];\n        // Leakage: a wheel bleeds faintly into its shaft partner four octaves up and its neighbour a fifth away.\n        if (leak > 0) {if (w + 48 <= WHEEL_HIGH) this.target[w + 48] += levels[d] * leak * 0.012; if (w + 7 <= WHEEL_HIGH) this.target[w + 7] += levels[d] * leak * 0.006;}\n      });\n      if (perc && key.percussion) this.percTarget[wheelOf(key.note, p.percHarmonic === 0 ? 12 : 19)] += PERC_PEAK * (p.percVolume === 0 ? 1 : 0.5);\n    }\n    this.active = [];\n    for (let w = WHEEL_LOW; w <= WHEEL_HIGH; w++) if (this.target[w] || this.amp[w] > 1e-7 || this.percTarget[w] || this.percAmp[w] > 1e-7) this.active.push(w);\n  }\n  noteOn(note, velocity, key) {\n    if (!this.p) return;\n    if (this.keys.has(key)) this.noteOff(key);\n    // Single trigger: percussion sounds only for keys pressed once every key is up, or in the same moment as one that did.\n    const percussion = this.keys.size === 0 || this.time - this.percAt < 0.006;\n    if (this.keys.size === 0) {this.percEnv = 1; this.percAt = this.time;}\n    this.keys.set(key, {note, percussion}); this.idle = false;\n    this.click(note);\n    this.retarget();\n  }\n  noteOff(key) {\n    const keys = key === undefined ? [...this.keys.keys()] : this.keys.has(key) ? [key] : [];\n    for (const k of keys) {this.click(this.keys.get(k).note, 0.5); this.keys.delete(k);}\n    if (keys.length) this.retarget();\n  }\n  click(note, amount = 1) {\n    const p = this.p; if (!p || p.click <= 0) return;\n    this.noises.add({amount: p.click * 0.018 * amount, decay: 0.0025 + Math.random() * 0.001, tone: 3200 + (note % 12) * 120});\n  }\n  control(kind, level) {this.controls[kind] = level;}\n  render(left, right, offset, n, cents, cv) {\n    const p = this.p;\n    if (!p) return;\n    this.setPitch(cents);\n    if (this.idle && !this.keys.size && !this.noises.busy) return;\n    const dry = this.dry, contact = 1 - Math.exp(-1 / (0.0004 * this.rate)), percFall = Math.exp(-1 / ((p.percDecay === 0 ? PERC_FAST : PERC_SLOW) * this.rate));\n    dry.fill(0, 0, n);\n    // The wheels that sound, each a table sine at its own phase: shared by every key and drawbar that reaches it.\n    for (const w of this.active) {\n      let phase = this.phase[w], amp = this.amp[w], perc = this.percAmp[w];\n      const step = this.step[w], target = this.target[w], percTarget = this.percTarget[w];\n      let env = this.percEnv;\n      for (let k = 0; k < n; k++) {\n        amp += (target - amp) * contact; perc += (percTarget - perc) * contact;\n        const x = phase * 4096, i = x | 0, s = TABLE[i] + (TABLE[i + 1] - TABLE[i]) * (x - i);\n        dry[k] += s * (amp + perc * env);\n        env *= percFall;\n        phase += step; if (phase >= 1) phase -= 1;\n      }\n      this.phase[w] = phase; this.amp[w] = amp < 1e-9 && !target ? 0 : amp; this.percAmp[w] = perc < 1e-9 && !percTarget ? 0 : perc;\n    }\n    this.percEnv *= percFall ** n; this.time += n / this.rate;\n    if (this.active.some(w => !this.target[w] && !this.percTarget[w] && !this.amp[w] && !this.percAmp[w])) this.retarget();\n    // Key click goes in before the scanner and the speaker, as it comes from the contacts.\n    const clicks = this.clicks; clicks[0].fill(0, 0, n); clicks[1].fill(0, 0, n);\n    this.noises.render(clicks[0], clicks[1], 0, n);\n    for (let k = 0; k < n; k++) dry[k] = dry[k] * 0.12 + clicks[0][k] * 0.5 + clicks[1][k] * 0.5;\n    this.vibrato(dry, n);\n    const peak = this.speaker(dry, left, right, offset, n, cv);\n    if (!this.keys.size && !this.noises.busy && peak < IDLE && this.active.length === 0) {this.idle = true; this.quiet(); for (let k = offset; k < offset + n; k++) left[k] = right[k] = 0;}\n  }\n  /** The scanner: a delay line swept at about 6.9 Hz, alone for vibrato or mixed with the dry signal for chorus. */\n  vibrato(dry, n) {\n    const mode = SCANNER[this.p.vibrato]; if (!mode) return;\n    const [swing, chorus] = mode, mask = 2047, step = TAU * 6.86 / this.rate, base = 0.0006 * this.rate, depth = swing * 0.001 * this.rate;\n    for (let k = 0; k < n; k++) {\n      this.scan[this.scanAt] = dry[k];\n      this.scanPhase += step; if (this.scanPhase > TAU) this.scanPhase -= TAU;\n      const delay = base + depth * Math.sin(this.scanPhase), at = this.scanAt - delay, i = Math.floor(at), frac = at - i;\n      const wet = this.scan[i & mask] + (this.scan[(i + 1) & mask] - this.scan[i & mask]) * frac;\n      dry[k] = chorus ? (dry[k] + wet) * 0.6 : wet;\n      this.scanAt = (this.scanAt + 1) & mask;\n    }\n  }\n  /** The swell pedal, the preamp and the rotary speaker: horn above 800 Hz and drum below, each with its own inertia. */\n  speaker(dry, left, right, offset, n, cv) {\n    const p = this.p, rate = this.rate;\n    // The swell keeps some bass as it closes, as the B-3's expression network does.\n    const swell = clamp(clamp(this.controls.expression, 0, 1) + cv, 0, 1);\n    this.swell += (swell - this.swell) * (1 - Math.exp(-n / (0.02 * rate)));\n    if (Math.abs(this.swell - this.swellSet) > 0.01) {this.swellSet = this.swell; this.swellShelf.set('lowshelf', rate, 180, 0.7, (1 - this.swell) * 9);}\n    const gain = 0.01 + 0.99 * this.swell ** 1.7, drive = 1 + 8 * p.drive, makeup = 1 / drive ** 0.65, bias = 0.15, zero = Math.tanh(bias);\n    const fast = this.controls.mod >= 0.5, rotating = p.rotary === 1, mask = 2047;\n    const hornGoal = fast ? 6.8 : 0.8, drumGoal = fast ? 5.9 : 0.7;\n    const hornRate = 1 - Math.exp(-1 / ((hornGoal > this.hornSpeed ? 0.45 : 0.6) * rate)), drumRate = 1 - Math.exp(-1 / ((drumGoal > this.drumSpeed ? 1.6 : 2) * rate));\n    if (p.balance !== this.balanceSet) {this.balanceSet = p.balance; this.gains = balanceGains(p.balance);}\n    const [hornGain, drumGain] = this.gains, level = p.level * 0.9;\n    const hornSwing = 0.00044 * rate, drumSwing = 0.0003 * rate, base = 0.002 * rate;\n    let peak = 0;\n    for (let k = 0; k < n; k++) {\n      let x = this.swellShelf.process(dry[k]) * gain;\n      x = (Math.tanh(x * drive + bias) - zero) * makeup;\n      const low = this.crossLow[1].process(this.crossLow[0].process(x)), high = this.crossHigh[1].process(this.crossHigh[0].process(x));\n      let l, r;\n      if (rotating) {\n        this.hornSpeed += (hornGoal - this.hornSpeed) * hornRate; this.drumSpeed += (drumGoal - this.drumSpeed) * drumRate;\n        this.hornAngle += TAU * this.hornSpeed / rate; if (this.hornAngle > TAU) this.hornAngle -= TAU;\n        this.drumAngle += TAU * this.drumSpeed / rate; if (this.drumAngle > TAU) this.drumAngle -= TAU;\n        this.horn[this.rotorAt] = high; this.drum[this.rotorAt] = low;\n        // Two mics on opposite sides of the cabinet: each hears the horn and the drum come and go, and the horn's Doppler.\n        const read = (line, delay) => {const at = this.rotorAt - delay, i = Math.floor(at), frac = at - i; return line[i & mask] + (line[(i + 1) & mask] - line[i & mask]) * frac;};\n        const hl = Math.cos(this.hornAngle), hr = Math.cos(this.hornAngle - Math.PI * 0.75), dl = Math.cos(this.drumAngle), dr = Math.cos(this.drumAngle - Math.PI * 0.75);\n        l = read(this.horn, base - hornSwing * Math.sin(this.hornAngle)) * (0.6 + 0.4 * hl) * hornGain + read(this.drum, base - drumSwing * Math.sin(this.drumAngle)) * (0.78 + 0.22 * dl) * drumGain;\n        r = read(this.horn, base - hornSwing * Math.sin(this.hornAngle - Math.PI * 0.75)) * (0.6 + 0.4 * hr) * hornGain + read(this.drum, base - drumSwing * Math.sin(this.drumAngle - Math.PI * 0.75)) * (0.78 + 0.22 * dr) * drumGain;\n        this.rotorAt = (this.rotorAt + 1) & mask;\n      } else l = r = high * hornGain * 0.8 + low * drumGain * 0.8;\n      l = this.dc[0].process(l) * level; r = this.dc[1].process(r) * level;\n      left[offset + k] += l; right[offset + k] += r;\n      const a = Math.max(Math.abs(l), Math.abs(r)); if (a > peak) peak = a;\n    }\n    return peak;\n  }\n  quiet() {\n    this.scan.fill(0); this.horn.fill(0); this.drum.fill(0); this.swellShelf.reset();\n    [...this.crossLow, ...this.crossHigh, ...this.dc].forEach(f => f.reset());\n  }\n  clear() {this.keys.clear(); this.amp.fill(0); this.percAmp.fill(0); this.noises.clear(); this.retarget(); this.quiet(); this.idle = true;}\n  get busy() {return !this.idle;}\n}\n\nexport const DIGITAL = {velvet: TineDSP, reed: ReedDSP, planet: PlanetDSP, strut: StrutDSP, drawbar: OrganDSP};\n\n/**\n * One keyboard: its events in time order, its Digital engine and, when the Rust DSP gives it one, its Analog engine.\n * Events are {type: 'params' | 'on' | 'off' | 'control', time, ...}; each lands on its own sample. Changing Engine\n * crossfades from the old engine, which then falls silent, to the new one over 8 ms.\n */\nexport class KeysDSP {\n  constructor(rate, kind, makeAnalog) {\n    this.rate = rate; this.kind = kind; this.makeAnalog = makeAnalog; this.events = []; this.disposed = false;\n    this.digital = new DIGITAL[kind](rate); this.analog = null; this.engine = this.digital; this.fading = null; this.fade = 0;\n    this.params = null; this.controls = {...CONTROLS_AT_REST};\n    this.scratch = [new Float32Array(QUANTUM), new Float32Array(QUANTUM)];\n  }\n  enqueue(event) {\n    if (event.type === 'control' && event.cancel) this.events = this.events.filter(e => !(e.type === 'control' && e.kind === event.kind && e.time >= event.time));\n    if (event.type === 'off') this.events = this.events.filter(e => !(e.type === 'on' && e.time >= event.time && (event.key === undefined || e.key === event.key)));\n    let i = this.events.length;\n    while (i > 0 && this.events[i - 1].time > event.time) i--;\n    this.events.splice(i, 0, event);\n  }\n  apply(event) {\n    if (event.type === 'params') {\n      this.params = event.params;\n      const wanted = event.params.engine === 1 && this.makeAnalog ? 'analog' : 'digital';\n      if (wanted === 'analog' && !this.analog) this.analog = this.makeAnalog();\n      const next = wanted === 'analog' && this.analog ? this.analog : this.digital;\n      if (next !== this.engine) {\n        if (this.fading) this.fading.clear();\n        this.fading = this.engine; this.fade = 1; this.engine = next;\n        for (const [kind, level] of Object.entries(this.controls)) next.control(kind, level);\n      }\n      this.engine.configure(event.params);\n      this.fading?.configure(event.params);\n    } else if (event.type === 'on') this.engine.noteOn(event.note, event.velocity, event.key, this.cv);\n    else if (event.type === 'off') {this.engine.noteOff(event.key); this.fading?.noteOff(event.key);}\n    else if (event.type === 'control') {this.controls[event.kind] = event.level; this.engine.control(event.kind, event.level); this.fading?.control(event.kind, event.level);}\n  }\n  /** Renders a block into `left` and `right`, applying each event on its sample. `pitch` is in cents and `cv` is the CV input. */\n  render(left, right, startFrame, pitch, cv) {\n    // The engines' buffers hold one render quantum, so longer renders (tests) go a quantum at a time.\n    if (left.length > QUANTUM) {\n      for (let i = 0; i < left.length; i += QUANTUM) this.render(left.subarray(i, i + QUANTUM), right.subarray(i, i + QUANTUM), startFrame + i, pitch?.subarray(i, i + QUANTUM), cv?.subarray(i, i + QUANTUM));\n      return;\n    }\n    left.fill(0); right.fill(0);\n    if (this.disposed) return;\n    const n = left.length;\n    let i = 0;\n    while (i < n) {\n      this.cv = cv?.[i] ?? 0;\n      while (this.events.length && this.events[0].time * this.rate <= startFrame + i) this.apply(this.events.shift());\n      let j = n;\n      if (this.events.length) j = clamp(Math.ceil(this.events[0].time * this.rate - startFrame), i + 1, n);\n      this.segment(left, right, i, j - i, pitch?.[i] ?? 0, this.cv);\n      i = j;\n    }\n  }\n  segment(left, right, offset, n, cents, cv) {\n    this.engine.render(left, right, offset, n, cents, cv);\n    if (!this.fading) return;\n    // The old engine fades out over FADE as the new one takes over.\n    const [l, r] = this.scratch, step = 1 / (FADE * this.rate);\n    for (let start = 0; start < n; start += QUANTUM) {\n      const m = Math.min(QUANTUM, n - start);\n      l.fill(0, 0, m); r.fill(0, 0, m);\n      this.fading.render(l, r, 0, m, cents, cv);\n      for (let k = 0; k < m; k++) {this.fade = Math.max(0, this.fade - step); left[offset + start + k] += l[k] * this.fade; right[offset + start + k] += r[k] * this.fade;}\n    }\n    if (this.fade <= 0) {this.fading.clear(); this.fading = null;}\n  }\n  dispose() {this.disposed = true; this.events = []; this.digital.clear(); this.analog?.dispose?.(); this.analog = null;}\n}\n\n// The guard lets unit tests import the exact processor DSP without an audio environment.\nif (typeof registerProcessor !== 'undefined') {\n  class KeysProcessor extends AudioWorkletProcessor {\n    constructor(options) {\n      // dsp-processor.js shares the Rust engines through the global scope; without them, every keyboard plays Digital.\n      const {kind, module} = options?.processorOptions ?? {}, Analog = globalThis.RacklooseDSP?.AnalogKeys;\n      super(); this.dsp = new KeysDSP(sampleRate, kind, module && Analog ? () => new Analog(module, sampleRate, kind) : undefined);\n      this.port.onmessage = ({data}) => {\n        if (data.type === 'flush') this.port.postMessage({id: data.id});\n        else if (data.type === 'dispose') this.dsp.dispose();\n        else this.dsp.enqueue(data);\n      };\n    }\n    process(inputs, outputs) {\n      const [left, right] = outputs[0];\n      this.dsp.render(left, right ?? new Float32Array(left.length), currentFrame, inputs[0]?.[0], inputs[1]?.[0]);\n      return !this.dsp.disposed;\n    }\n  }\n  registerProcessor('rackloose-keys-v1', KeysProcessor);\n}\n", Ri = "data:application/wasm;base64,AGFzbQEAAAABpgIqYAF9AX1gAn9/AX9gA39/fwF/YAF/AX9gAX8AYAJ/fwBgA39/fQBgA39/fwBgBX99fX99AGAHf39/f399fQBgA398fABgAn98AGAAAGAEf39/fwBgBH9/fX8Bf2AFf39/f38AYAR/f39/AX9gBX9/fHx8AGAHf398fHx8fAF/YAV/f39/fwF/YAJ9fwF/YAR/f399AGAEf399fQBgAX0Bf2ACf30AYAZ/f39/f38AYAZ/fn9/f38AYAl/f39/f39+fn4AYAN/fX8Bf2AEf31/fwF/YAN/fH8Bf2AEf3x/fwF/YAZ/f39/f38Bf2ABfAF8YAN+f34BfmACfHwBfGACfH8BfGACfX8BfWAFf35+fn4AYAR/fn5/AGADfHx/AXxgAn19AX0D0AHOAQQEBwQEBAQEAQcDCgEFBwUFCwMFDAUNDgcHBQUPBA0NEAQFEQAAEgMECQYIBwEFAwQJBggHBQMECQYIBwUBEwMECQgHBQMECQYIBwUHBAIUAQMFBBUDBAQGBBQFCAEDFgQDBAMXAwUEGBgFGAUFBQUBAQQQEwUBAgEMBBkaGw8BBwcBAhwcHR4eHw0MBQUFBAQEAQUFBw0EBQIBAgEFBQUFBQAAIAshISEhIQAAACIjIyEhJCUjIyYmJyEoISYAAAAAAAAhISkpJyYhISEhBAUBcAFAQAUDAQARBgkBfwFBgIDAAAsHlAQhBm1lbW9yeQIAC2RydW1zX2Nob2tlAEwKZHJ1bXNfZnJlZQBNEWRydW1zX2xvYWRfc2FtcGxlAE4JZHJ1bXNfbmV3AE8QZHJ1bXNfb3V0cHV0X3B0cgBQEGRydW1zX3BhcmFtc19wdHIAUQ1kcnVtc19wcm9jZXNzAFILZHJ1bXNfcmVzZXQAUw1kcnVtc190cmlnZ2VyAFQJa2V5c19idXN5AFUKa2V5c19jbGVhcgBWDmtleXNfY29uZmlndXJlAFcMa2V5c19jb250cm9sAFgJa2V5c19mcmVlAFkIa2V5c19uZXcAWg1rZXlzX25vdGVfb2ZmAFsMa2V5c19ub3RlX29uAFwPa2V5c19vdXRwdXRfcHRyAF0Pa2V5c19wYXJhbXNfcHRyAF4Ma2V5c19wcm9jZXNzAF8Qa2V5c19yZWxlYXNlX2FsbABgEWxhZGRlcl9kZXR1bmVfcHRyAGELbGFkZGVyX2ZyZWUAYhBsYWRkZXJfaW5wdXRfcHRyAGMKbGFkZGVyX25ldwBkEWxhZGRlcl9vdXRwdXRfcHRyAGUObGFkZGVyX3Byb2Nlc3MAZgxsYWRkZXJfcmVzZXQAZxFsYWRkZXJfc2V0X2N1dG9mZgBoEGxhZGRlcl9zZXRfZHJpdmUAaQ9sYWRkZXJfc2V0X21vZGUAahRsYWRkZXJfc2V0X3Jlc29uYW5jZQBrCVQBAEEBCz8IDD0lJC1wcQRLSUpIR0ZFA0RCQypBQD8GPDo7OTg3NgUuKywpKCcANTM0MjEwL3aXAZkBmgGbAZwBnQGeAZ8BkQGSAZMBlAGMAY0BmAEKkrYMzgHDAwEHfyAAKALULiEBAkACQAJAAkACQAJAAkAgACgC2C4iAkUNACABQdQBaiEDA0ACQCADQVhqKAIAIgRFDQAgA0FcaigCACIFQXxqKAIAIgZBeHEiB0EEQQggBkEDcSIGGyAEQQJ0IgRqSQ0DAkAgBkUNACAHIARBJ2pLDQULIAUQgYCAgAALAkAgA0F8aigCACIERQ0AIAMoAgAiBUF8aigCACIGQXhxIgdBBEEIIAZBA3EiBhsgBEECdCIEakkNBQJAIAZFDQAgByAEQSdqSw0HCyAFEIGAgIAACyADQeABaiEDIAJBf2oiAg0ACwsCQCAAKALQLiIDRQ0AIAFBfGooAgAiAkF4cSIEQQRBCCACQQNxIgIbIANB4AFsIgNySQ0FAkAgAkUNACAEIANBJ2pLDQcLIAEQgYCAgAALDwtBgLPAgABBLkGws8CAABCCgICAAAALQcCzwIAAQS5B8LPAgAAQgoCAgAAAC0GAs8CAAEEuQbCzwIAAEIKAgIAAAAtBwLPAgABBLkHws8CAABCCgICAAAALQYCzwIAAQS5BsLPAgAAQgoCAgAAAC0HAs8CAAEEuQfCzwIAAEIKAgIAAAAvdCQEFfyAAQXhqIgEgAEF8aigCACICQXhxIgBqIQMCQAJAAkAgAkEBcQ0AIAJBAnFFDQEgASgCACICIABqIQACQCABIAJrIgFBACgCoN3AgABHDQAgAygCBEEDcUEDRw0BQQAgADYCmN3AgAAgAyADKAIEQX5xNgIEIAEgAEEBcjYCBCADIAA2AgAPCyABIAIQ7ICAgAALAkACQAJAAkACQAJAAkACQAJAIAMoAgQiAkECcQ0AIANBACgCpN3AgABGDQIgA0EAKAKg3cCAAEYNBSADIAJBeHEiAhDsgICAACABIAIgAGoiAEEBcjYCBCABIABqIAA2AgAgAUEAKAKg3cCAAEcNAUEAIAA2ApjdwIAADwsgAyACQX5xNgIEIAEgAEEBcjYCBCABIABqIAA2AgALIABBgAJJDQJBHyEDIABBgICACEkNAQwGC0EAIAE2AqTdwIAAQQBBACgCnN3AgAAgAGoiADYCnN3AgAAgASAAQQFyNgIEAkAgAUEAKAKg3cCAAEcNAEEAQQA2ApjdwIAAQQBBADYCoN3AgAALIABBACgCsN3AgAAiAk0NBkFQQQAoArzdwIAAIgFrQXdxQQNGDQZBACgCpN3AgAAiAEUNBkEAKAKc3cCAACIEQSlJDQQgAUUNA0H42sCAACEBA0ACQCABKAIAIgMgAEsNACAAIAMgASgCBGpJDQYLIAEoAgghAQwACwsgAEEmIABBCHZnIgNrdkEBcSADQQF0ckE+cyEDDAQLAkACQEEAKAKQ3cCAACIDQQEgAEEDdnQiAnENAEEAIAMgAnI2ApDdwIAAIABB+AFxQYjbwIAAaiIAIQMMAQsgAEH4AXEiAEGI28CAAGohAyAAQZDbwIAAaigCACEACyADIAE2AgggACABNgIMIAEgAzYCDCABIAA2AggPC0EAIAE2AqDdwIAAQQBBACgCmN3AgAAgAGoiADYCmN3AgAAgASAAQQFyNgIEIAEgAGogADYCAA8LQYC0wIAAEPqAgIAAAAtBACEBAkBBACgCgNvAgAAiAEUNAEEAIQEDQCABQQFqIQEgACgCCCIADQALC0EAQQAoAsDdwIAAIgAgASAAIAFLG0F/IAAbNgK43cCAACAEIAJNDQFBAEF/NgKw3cCAAA8LIAFCADcCECABIAM2AhwgA0ECdEH42cCAAGohAgJAAkBBACgClN3AgABBASADdCIEcQ0AIAIgATYCACABIAI2AhggASABNgIMIAEgATYCCEEAQQAoApTdwIAAIARyNgKU3cCAAAwBCwJAAkACQCACKAIAIgQoAgRBeHEgAEcNACAEIQMMAQsgAEEAQRkgA0EBdmsgA0EfRht0IQIDQCAEIAJBHXZBBHFqIgUoAhAiA0UNAiACQQF0IQIgAyEEIAMoAgRBeHEgAEcNAAsLIAMoAggiACABNgIMIAMgATYCCCABQQA2AhggASADNgIMIAEgADYCCAwBCyAFQRBqIAE2AgAgASAENgIYIAEgATYCDCABIAE2AggLQQAhAUEAQQAoArjdwIAAQX9qIgA2ArjdwIAAIABFDQELDwsCQEEAKAKA28CAACIARQ0AQQAhAQNAIAFBAWohASAAKAIIIgANAAsLQQBBACgCwN3AgAAiACABIAAgAUsbQX8gABs2ArjdwIAACxUAIAAgAUEBdEEBciACEImAgIAAAAu7AgEHfyAAKAKsESEBAkACQAJAAkACQCAAKAKwESICRQ0AIAFB3AFqIQMDQAJAIANBfGooAgAiBEUNACADKAIAIgVBfGooAgAiBkF4cSIHQQRBCCAGQQNxIgYbIARBAnQiBGpJDQMCQCAGRQ0AIAcgBEEnaksNBQsgBRCBgICAAAsgA0HoAWohAyACQX9qIgINAAsLAkAgACgCqBEiA0UNACABQXxqKAIAIgJBeHEiBEEEQQggAkEDcSICGyADQegBbCIDakkNAwJAIAJFDQAgBCADQSdqSw0FCyABEIGAgIAACw8LQYCzwIAAQS5BsLPAgAAQgoCAgAAAC0HAs8CAAEEuQfCzwIAAEIKAgIAAAAtBgLPAgABBLkGws8CAABCCgICAAAALQcCzwIAAQS5B8LPAgAAQgoCAgAAAC7sCAQd/IAAoAqwRIQECQAJAAkACQAJAIAAoArARIgJFDQAgAUHcAWohAwNAAkAgA0F8aigCACIERQ0AIAMoAgAiBUF8aigCACIGQXhxIgdBBEEIIAZBA3EiBhsgBEECdCIEakkNAwJAIAZFDQAgByAEQSdqSw0FCyAFEIGAgIAACyADQegBaiEDIAJBf2oiAg0ACwsCQCAAKAKoESIDRQ0AIAFBfGooAgAiAkF4cSIEQQRBCCACQQNxIgIbIANB6AFsIgNqSQ0DAkAgAkUNACAEIANBJ2pLDQULIAEQgYCAgAALDwtBgLPAgABBLkGws8CAABCCgICAAAALQcCzwIAAQS5B8LPAgAAQgoCAgAAAC0GAs8CAAEEuQbCzwIAAEIKAgIAAAAtBwLPAgABBLkHws8CAABCCgICAAAALvwMBB38gACgCrBEhAQJAAkACQAJAAkACQAJAIAAoArARIgJFDQAgAUHcAWohAwNAAkAgA0F8aigCACIERQ0AIAMoAgAiBUF8aigCACIGQXhxIgdBBEEIIAZBA3EiBhsgBEECdCIEakkNAwJAIAZFDQAgByAEQSdqSw0FCyAFEIGAgIAACyADQegBaiEDIAJBf2oiAg0ACwsCQCAAKAKoESIDRQ0AIAFBfGooAgAiAkF4cSIEQQRBCCACQQNxIgIbIANB6AFsIgNqSQ0DAkAgAkUNACAEIANBJ2pLDQULIAEQgYCAgAALAkAgACgC4CIiA0UNACAAKALkIiIEQXxqKAIAIgJBeHEiBkEEQQggAkEDcSICGyADQQV0IgNySQ0FAkAgAkUNACAGIANBJ2pLDQcLIAQQgYCAgAALDwtBgLPAgABBLkGws8CAABCCgICAAAALQcCzwIAAQS5B8LPAgAAQgoCAgAAAC0GAs8CAAEEuQbCzwIAAEIKAgIAAAAtBwLPAgABBLkHws8CAABCCgICAAAALQYCzwIAAQS5BsLPAgAAQgoCAgAAAC0HAs8CAAEEuQfCzwIAAEIKAgIAAAAudBQEEfwJAAkACQAJAAkACQAJAAkACQAJAAkAgACgCmMQBIgFFDQAgACgCnMQBIgJBfGooAgAiA0F4cSIEQQRBCCADQQNxIgMbIAFBAnQiAWpJDQECQCADRQ0AIAQgAUEnaksNAwsgAhCBgICAAAsCQCAAKAKkxAEiAUUNACAAKAKoxAEiAkF8aigCACIDQXhxIgRBBEEIIANBA3EiAxsgAUECdCIBakkNAwJAIANFDQAgBCABQSdqSw0FCyACEIGAgIAACwJAIAAoApANIgFFDQAgACgClA0iAkF8aigCACIDQXhxIgRBBEEIIANBA3EiAxsgAUECdCIBakkNBQJAIANFDQAgBCABQSdqSw0HCyACEIGAgIAACwJAIAAoApwNIgFFDQAgACgCoA0iAkF8aigCACIDQXhxIgRBBEEIIANBA3EiAxsgAUECdCIBakkNBwJAIANFDQAgBCABQSdqSw0JCyACEIGAgIAACwJAIAAoAqgNIgFFDQAgACgCrA0iA0F8aigCACIAQXhxIgJBBEEIIABBA3EiABsgAUECdCIBakkNCQJAIABFDQAgAiABQSdqSw0LCyADEIGAgIAACw8LQYCzwIAAQS5BsLPAgAAQgoCAgAAAC0HAs8CAAEEuQfCzwIAAEIKAgIAAAAtBgLPAgABBLkGws8CAABCCgICAAAALQcCzwIAAQS5B8LPAgAAQgoCAgAAAC0GAs8CAAEEuQbCzwIAAEIKAgIAAAAtBwLPAgABBLkHws8CAABCCgICAAAALQYCzwIAAQS5BsLPAgAAQgoCAgAAAC0HAs8CAAEEuQfCzwIAAEIKAgIAAAAtBgLPAgABBLkGws8CAABCCgICAAAALQcCzwIAAQS5B8LPAgAAQgoCAgAAAC9cDBAF/AX0BfgJ9I4CAgIAAQSBrIgEkgICAgAACQCAAKgLcDiICQwAAoEFgDQAgAUGAgICNBDYCCCABIAI4AgwgAUGBgICAAK1CIIYiAyABQQxqrYQ3AxggASADIAFBCGqthDcDEEHtgcCAACABQRBqQdiKwIAAEImAgIAAAAsgAEMAAIA/IAJDAACgQSAAKgKwDSAAKgKoDUOaaxc6lJIQo4GAgAAiBCAEQwAAoEFdGyIEIAQgAl4bQ9sPSUCUIAAqAtgOlRDDgYCAACICQwAAgD+SlSIEOAKADyAAIAIgBJQiAjgC8A4gACACIAKUIgQ4AvQOIAAgBCAElCIFOAL8DiAAIAIgBJQ4AvgOIABDAACAP0MAAAAAIAAqArwNIgIgAkMAAAAAXRsiAiACQwAAgD9eG0MAAIBAlCICOAKEDyAAQwAAgD9DAAAAACAAKgLIDSIEIARDAAAAAF0bIgQgBEMAAIA/XhtDAABAQJQQwYGAgAAiBDgCkA8gAEMAAIA/IASVOAKUDyAAQwAAgD8gBSAClEMAAIA/kpU4AowPIAAgAkMAAAA/lEMAAIA/kkMAAIA/IAAtAJwPQQJJGzgCiA8gACAEkYs4ApgPIAFBIGokgICAgAALgQECAn8CfSABKAIIIgJBgICAAXEhAyAAKgIAIQQCQCACQYCAgIABcQ0AAkAgBIsiBUPKGw5aYA0AIARDAAAAAFwgBUMXt9E4XXENACABIAQgA0EARxCEgYCAAA8LIAEgBCADQQBHEIWBgIAADwsgASAEIANBAEcgAS8BDhCGgYCAAAtHAQF/I4CAgIAAQSBrIgMkgICAgAAgAyABNgIQIAMgADYCDCADQQE7ARwgAyACNgIYIAMgA0EMajYCFCADQRRqEPKAgIAAAAuRBAEBf0EAIQECQCAAKAIAQQF0Qf///3dLDQAgACgCBEEBdEH///93Sw0AIAAoAghBAXRB////d0sNACAAKAIMQQF0Qf///3dLDQAgACgCEEEBdEH///93Sw0AIAAoAhRBAXRB////d0sNACAAKAIYQQF0Qf///3dLDQAgACgCHEEBdEH///93Sw0AIAAoAiBBAXRB////d0sNACAAKAIkQQF0Qf///3dLDQAgACgCKEEBdEH///93Sw0AIAAoAixBAXRB////d0sNACAAKAIwQQF0Qf///3dLDQAgACgCNEEBdEH///93Sw0AIAAoAjhBAXRB////d0sNACAAKAI8QQF0Qf///3dLDQAgACgCQEEBdEH///93Sw0AIAAoAkRBAXRB////d0sNACAAKAJIQQF0Qf///3dLDQAgACgCTEEBdEH///93Sw0AIAAoAlBBAXRB////d0sNACAAKAJUQQF0Qf///3dLDQAgACgCWEEBdEH///93Sw0AIAAoAlxBAXRB////d0sNACAAKAJgQQF0Qf///3dLDQAgACgCZEEBdEH///93Sw0AIAAoAmhBAXRB////d0sNACAAKAJsQQF0Qf///3dLDQAgACgCcEEBdEH///93Sw0AIAAoAnRBAXRB////d0sNACAAKAJ4QQF0Qf///3dLDQAgACgCfEEBdEH///93Sw0AQQEhAQsgAQvQBAYCfwN8AX0BfwJ8AX4jgICAgABBIGsiAySAgICAAAJAAkAgASAAKAJQQX5qIgS4IgWjIgYgAUQAAAAAAAAUQKMiB2VFDQAgACoCbCEIIAcgBiACIAIgBmMbIgYgBiAHZBtEGC1EVPshGUCiIAGjIgEQp4GAgAAhBiABEKmBgIAAIQcgACgCaCEJIAYgCLsiAqIgByACokQAAAAAAADwP6CjEM2BgIAAIQogBiAAKgJ0uyICoiAHIAKiRAAAAAAAAPA/oKMQzYGAgAAhAiAERQ0BIAAgBUQAAAAAAADwPyACIAGjRBgtRFT7IRlAIAGjIgJEAAAAAAAAAMAgAaMgCqJEAAAAAAAA8D+gIAm4oqGgIgpEAAAAAAAA4L+gnCILIAtEAAAAAAAA8D9jGyILIAsgBWQbIgX8AzYCWCABIAUgCqFEAAAAAAAA8D+gokQAAAAAAADgP6IQvIGAgAAhASAAIAI5A0ggAESuR+F6FK7vP0SuR+F6FK7vvyABIAYgByABoqGjIgEgAUSuR+F6FK7vv2MbIgEgAUSuR+F6FK7vP2QbtjgCXCADQSBqJICAgIAADwsgAyAGOQMAIAMgBzkDCCADQYKAgIAArUIghiIMIANBCGqthDcDGCADIAwgA62ENwMQQe2BwIAAIANBEGpB6IrAgAAQiYCAgAAACyADQoCAgICAgID4PzcDACADIAU5AwggA0GCgICAAK1CIIYiDCADQQhqrYQ3AxggAyAMIAOthDcDEEHtgcCAACADQRBqQeiKwIAAEImAgIAAAAuNAQICfwJ8IAEoAggiAkGAgIABcSEDIAArAwAhBAJAIAJBgICAgAFxDQACQCAEmSIFRACA4Dd5w0FDZg0AIAREAAAAAAAAAABiIAVELUMc6+I2Gj9jcQ0AIAEgBCADQQBHEIeBgIAADwsgASAEIANBAEcQiIGAgAAPCyABIAQgA0EARyABLwEOEImBgIAAC5IHBAF/AnwBfQd8AkAgASAAKALYLiICTw0AIAArA9ArIQMgACsD0CEhBCAAKgKIKyEFRAAAAAAAAFhARAAAAAAAADhAIAAoAtQuIAFB4AFsaiIBLQDcAbgiBiAGRAAAAAAAADhAYxsiBiAGRAAAAAAAAFhAZBtEAAAAAAAAPcCgRAAAAAAAADbAoxDFgYCAACEHRAAAAAAAAAAAIQhEAAAAAAAA8D9EAAAAAAAAAAAgACoCgCu7IgYgBkQAAAAAAAAAAGMbIgYgBkQAAAAAAADwP2QbIglEV4Dcay4wQ0CiRDYf14aKoRtARC1DHOviNho/RJqZmZmZmak/IAW7IgYgBiAGYhsiBkSamZmZmZmpPyAGRJqZmZmZmak/ZBsgB0QAAAAAAAAUQKKiIgYgBiAGYhsiBkQtQxzr4jYaPyAGRC1DHOviNho/ZBujIgqgIgZEg8DKoUXIXECgIAYgAS0A3gEiABuaRAAAAAAAAPA/IAErA3AiBiAGIAZiGyIHRAAAAAAAAPA/IAdEAAAAAAAA8D9kGyILoxCygYCAACEMAkBEAAAAAAAA8D9EAAAAAAAA8D8gCUSDwMqhRchsQKJEAAAAAABAv0AgBkQAAAAAAAAkQKIiByAHIAdiGyIHRAAAAAAAQL9AIAdEAAAAAABAv0BjGyIHRC1DHOviNho/oiAHIAdEOoww4o55dT6ioqAiCSAJoCAKoKAiCURiEFg5NJZ1QKAgCSAAG5ogC6MQsoGAgAAgDKMiCSAJRAAAAAAAAPA/ZBsiCSAJoiIKoSIJRJXWJugLLhE+Yw0ARAAAAAAAAAAARGZmZmZmZu6/RAAAAAAAAAAARAAAAAAAAPA/IAREzczMzMzM3D+iIgggByAHIAdiGyIHIAcgCCAIIAhiGyIIIAcgCGMbRBgtRFT7IRlAoiAEoxCpgYCAACAKoqEiByAHoiAJIAmioSIIIAggCGIbIghEAAAAAAAAAAAgCEQAAAAAAAAAAGQbnyAHoSAJoyIHIAdEZmZmZmZm7r9jGyIHIAdEAAAAAAAAAABkGyEICyABIAi2OAKkASABIAwgCEQAAAAAAADwP6CitjgCoAEgAUEwaiAEIAMgBqIQi4CAgAAgASABKwN4IgYgASsDECIHojkDGCABIAYgASsDCCIIojkDICABIAYgByAIoUQAAAAAAADgP6KiOQMoDwsgASACQdyNwIAAEI6AgIAAAAtfAgF/AX4jgICAgABBIGsiAySAgICAACADIAE2AgwgAyAANgIIIANBg4CAgACtQiCGIgQgA0EIaq2ENwMYIAMgBCADQQxqrYQ3AxBBqIDAgAAgA0EQaiACEImAgIAAAAu3AgMCfwJ9AnwjgICAgABBwABrIgIkgICAgAACQAJAIAAgAUH/AXFBA3RqIgEoAgBBAUcNACABKAIEIgEgACgC2C4iA08NASAAKALULiABQeABbGoiAy0A3QFFDQAgAy0A3gENACADQQE6AN4BIAAgARCNgICAACAAKgKMKyEEIAMqAswBIQUgACsD0CshBiADKwNwIQcgAkIANwMwIAJCgICAgICAgIjAADcDKCACQoCAgICAgLDJwAA3AxggAkKKro+F18fC0z83AxAgAkIANwM4IAIgByAGokRI4XoUrkfpP6I5AyAgAiAFu0QzMzMzMzPTP6JE/Knx0k1icD+gIAS7ojkDCCAAQYAUaiACQQhqEJCAgIAACyACQcAAaiSAgICAAA8LIAEgA0H8jsCAABCOgICAAAALyQcDAXwBfwF8AkAgASsDACICIAJiDQAgAkSN7bWg98awPmUNACAAIQMCQCAALQBEQQFHDQACQCAALQCMAUEBRg0AIABByABqIQMMAQsCQCAALQDUAUEBRg0AIABBkAFqIQMMAQsCQCAALQCcAkEBRg0AIABB2AFqIQMMAQsCQCAALQDkAkEBRg0AIABBoAJqIQMMAQsCQCAALQCsA0EBRg0AIABB6AJqIQMMAQsCQCAALQD0A0EBRg0AIABBsANqIQMMAQsCQCAALQC8BEEBRg0AIABB+ANqIQMMAQsCQCAALQCEBUEBRg0AIABBwARqIQMMAQsCQCAALQDMBUEBRg0AIABBiAVqIQMMAQsCQCAALQCUBkEBRg0AIABB0AVqIQMMAQsCQCAALQDcBkEBRg0AIABBmAZqIQMMAQsCQCAALQCkB0EBRg0AIABB4AZqIQMMAQsCQCAALQDsB0EBRg0AIABBqAdqIQMMAQsCQCAALQC0CEEBRg0AIABB8AdqIQMMAQsCQCAALQD8CEEBRg0AIABBuAhqIQMMAQsCQCAALQDECUEBRg0AIABBgAlqIQMMAQsCQCAALQCMCkEBRg0AIABByAlqIQMMAQsCQCAALQDUCkEBRg0AIABBkApqIQMMAQsCQCAALQCcC0EBRg0AIABB2ApqIQMMAQsCQCAALQDkC0EBRg0AIABBoAtqIQMMAQsCQCAALQCsDEEBRg0AIABB6AtqIQMMAQsCQCAALQD0DEEBRg0AIABBsAxqIQMMAQsgAC0AvA0NASAAQfgMaiEDCyADIAI5AwAgACsDwA0hAiADQQE6AEQgAyABKwMgOQMwIANCADcDKCADQgA3AxggAyABKwMYRBgtRFT7IRlAoiACozkDICADRAAAAAAAAPA/IAErAxBEGC1EVPshGcCiIAKjELKBgIAAoTkDECADRAAAAAAAAAAAIAIgASsDMKIQqoGAgAAiBCAEIARiGyIERAAAAAAAAAAAIAREAAAAAAAAAABkG/wDNgJAIANEAAAAAAAA8L8gAkQtQxzr4jYaPyABKwMIIgQgBCAEYhsiBEQtQxzr4jYaPyAERC1DHOviNho/ZBuioxCygYCAADkDCCADRAAAAAAAAPA/RAAAAAAAAPC/IAErAygiAiACRAAAAAAAAPC/YxsiAiACRAAAAAAAAPA/ZBtEAAAAAAAA8D+gRBgtRFT7IQlAokQAAAAAAADQP6IiAhCngYCAAETNO39mnqD2P6K2OAI8IAMgAhCpgYCAAETNO39mnqD2P6K2OAI4Cwu9CgEJfyOAgICAAEGAEWsiAiSAgICAAEEAIQMDQCACQYAJaiADaiIEQQA2AgAgBEEcakEAOgAAIARBGGpBADYCACAEQRRqQQA6AAAgBEEQakEANgIAIARBDGpBADoAACAEQQhqQQA2AgAgBEEEakEAOgAAIANBIGoiA0GACEcNAAsgAkGACGpBAEGAAfwLACACIAJBgAlqQYAI/AoAAAJAAkACQAJAAkACQEHAyAAQkoCAgAAiBUUNACABRPp+arx0k4g/ovwDQQFqIgZB/////wNLDQIgBkECdCIHQf3///8HTw0CAkAgBw0AIAJB+AlqIQMgAkHACWohCEEAIQkDQCAIQgA3AwAgCEIANwMIIAhCADcDECAIQgA3AxggCEIANwMgIAhCADcDKCAIQQA2AjAgA0IANwMAIANCADcDCCADQgA3AxAgA0IANwMYIANCADcDICADQgA3AyggA0EANgIwIAJBADYCuAkgAkIANwOwCSACQgA3A6gJIAJCADcDoAkgAkIANwOYCSACQgA3A5AJIAJCADcDiAkgAkIANwOACSAFIAlqIgQgAkGACWpBsAH8CgAAIARBwAFqQgA3AwAgBEG4AWpCADcDACAEQbABakIANwMAIARB5AFqQQA7AQAgBEHgAWogBjYCACAEQdgBakKAgICAwAA3AwAgBEHQAWpCgICA/AM3AwAgBEHIAWpCgICA/AM3AwAgCUHoAWoiCUHAyABHDQAMBwsLIAcQkoCAgAAiCQ0BQQAhCUEAIQMMAwtBCEHAyAAQk4CAgAAAC0EAIQMgCUF8ai0AAEEDcUUNAUEAIQQMAgsQlICAgAAAC0EBIQQLA0ACQAJAIAQOAgABAQsCQCAHRQ0AIAlBACAH/AsAC0EBIQQMAQsgA0EBaiEKIAUgA0HoAWxqIQQgAkH4CWohAyACQcAJaiEIA0ACQAJAAkAgCUUNACAIQgA3AwAgCEIANwMIIAhCADcDECAIQgA3AxggCEIANwMgIAhCADcDKCAIQQA2AjAgA0IANwMAIANCADcDCCADQgA3AxAgA0IANwMYIANCADcDICADQgA3AyggA0EANgIwIAJBADYCuAkgAkIANwOwCSACQgA3A6gJIAJCADcDoAkgAkIANwOYCSACQgA3A5AJIAJCADcDiAkgAkIANwOACSAEIAJBgAlqQbAB/AoAACAEQcABakIANwMAIARBuAFqQgA3AwAgBEGwAWpCADcDACAEQeQBakEAOwEAIARB4AFqIAY2AgAgBEHcAWogCTYCACAEQdgBaiAGNgIAIARB0AFqQoCAgPwDNwMAIARByAFqQoCAgPwDNwMAIApBKEYNBQJAIAcQkoCAgAAiCQ0AQQAhCQwDCyAJQXxqLQAAQQNxRQ0CIAohAwwBC0EEIAcQk4CAgAAAC0EAIQQMAgsgBEHoAWohBCAKQQFqIQoMAAsLC0EAIQMDQCACQYAJaiADaiIEQQA2AgAgBEE4akEANgIAIARBMGpBADYCACAEQShqQQA2AgAgBEEgakEANgIAIARBGGpBADYCACAEQRBqQQA2AgAgBEEIakEANgIAIANBwABqIgNBgAhHDQALIAAgATkDgAggAEGICGogAkGACfwKAAAgAEEANgKIESAAQSg2ArARIAAgBTYCrBEgAEEoNgKoESAAQQApAtCNwIAANwKMESAAQQAoAtiNwIAANgKUESAAIAJBgAlqQYAI/AoAACAAQQA2ArQRIABCgICAgICAgPg/NwOgESAAQgA3A5gRIAJBgBFqJICAgIAAC9QoAgh/AX4CQAJAAkACQCAAQfUBSQ0AQQAhASAAQVBBACgCvN3AgABrQXdxQX1qIgJBQCACQUBJG08NAyAAQQtqIgFBeHEhAkEAKAKU3cCAACIDRQ0CQR8hBCAAQfX//wdPDQEgAkEmIAFBCHZnIgBrdkEBcSAAQQF0ckE+cyEEDAELAkACQAJAAkACQAJAQQAoApDdwIAAIgVBECAAQQtqQfgDcSAAQQtJGyICQQN2IgF2IgBBA3FFDQAgAEF/c0EBcSABaiIGQQN0IgBBiNvAgABqIgIgAEGQ28CAAGooAgAiASgCCCIHRg0BIAcgAjYCDCACIAc2AggMAgsgAkEAKAKY3cCAAE0NBgJAIAANAEEAKAKU3cCAACIARQ0HIABoQQJ0QfjZwIAAaigCACIHKAIEQXhxIAJrIQEgByEFAkADQAJAIAcoAhAiAA0AIAcoAhQiAEUNAgsgACgCBEF4cSACayIHIAEgByABSSIHGyEBIAAgBSAHGyEFIAAhBwwACwsgBSgCGCEEAkACQAJAIAUoAgwiACAFRw0AIAVBFEEQIAUoAhQiABtqKAIAIgcNAUEAIQAMAgsgBSgCCCIHIAA2AgwgACAHNgIIDAELIAVBFGogBUEQaiAAGyEGA0AgBiEIIAciAEEUaiAAQRBqIAAoAhQiBxshBiAAQRRBECAHG2ooAgAiBw0ACyAIQQA2AgALIARFDQUCQAJAIAUgBSgCHEECdEH42cCAAGoiBygCAEYNAAJAIAQoAhAgBUYNACAEIAA2AhQgAA0CDAgLIAQgADYCECAADQEMBwsgByAANgIAIABFDQULIAAgBDYCGAJAIAUoAhAiB0UNACAAIAc2AhAgByAANgIYCyAFKAIUIgdFDQUgACAHNgIUIAcgADYCGAwFCwJAAkAgACABdEECIAF0IgBBACAAa3JxaCIIQQN0IgFBiNvAgABqIgcgAUGQ28CAAGooAgAiACgCCCIGRg0AIAYgBzYCDCAHIAY2AggMAQtBACAFQX4gCHdxNgKQ3cCAAAsgACACQQNyNgIEIAAgAWogASACayIHNgIAIAAgAmoiBSAHQQFyNgIEQQAoApjdwIAAIgJFDQJBACgCoN3AgAAhAQJAAkBBACgCkN3AgAAiBkEBIAJBA3Z0IghxDQBBACAGIAhyNgKQ3cCAACACQXhxQYjbwIAAaiICIQYMAQsgAkF4cSICQYjbwIAAaiEGIAJBkNvAgABqKAIAIQILIAYgATYCCCACIAE2AgwgASAGNgIMIAEgAjYCCAwCC0EAIAVBfiAGd3E2ApDdwIAACyABIABBA3I2AgQgASAAaiIAIAAoAgRBAXI2AgQgAUEIag8LQQAgBTYCoN3AgABBACAHNgKY3cCAACAAQQhqDwtBAEEAKAKU3cCAAEF+IAUoAhx3cTYClN3AgAALAkACQAJAIAFBEEkNACAFIAJBA3I2AgQgBSACaiIHIAFBAXI2AgQgByABaiABNgIAQQAoApjdwIAAIgZFDQFBACgCoN3AgAAhAAJAAkBBACgCkN3AgAAiCEEBIAZBA3Z0IgRxDQBBACAIIARyNgKQ3cCAACAGQXhxQYjbwIAAaiIGIQgMAQsgBkF4cSIGQYjbwIAAaiEIIAZBkNvAgABqKAIAIQYLIAggADYCCCAGIAA2AgwgACAINgIMIAAgBjYCCAwBCyAFIAEgAmoiAEEDcjYCBCAFIABqIgAgACgCBEEBcjYCBAwBC0EAIAc2AqDdwIAAQQAgATYCmN3AgAALIAVBCGoiAUUNAQwCC0EAIAJrIQECQAJAAkACQCAEQQJ0QfjZwIAAaigCACIFDQBBACEHQQAhAAwBC0EAIQcgAkEAQRkgBEEBdmsgBEEfRht0IQZBACEAA0ACQCAFIgUoAgRBeHEiCCACSQ0AIAggAmsiCCABTw0AIAUhByAIIQEgCA0AQQAhASAFIQAgBSEHDAMLIAUoAhQiCCAAIAggBSAGQR12QQRxaigCECIFRxsgACAIGyEAIAZBAXQhBiAFDQALCwJAIAAgB3INAEEAIQdBAiAEdCIAQQAgAGtyIANxIgBFDQMgAGhBAnRB+NnAgABqKAIAIQALIABFDQELA0AgACgCBEF4cSIGIAJrIgUgASAFIAFJGyEIIAYgAkkhBiAHIAAgBSABTxshBAJAIAAoAhAiBQ0AIAAoAhQhBQsgASAIIAYbIQEgByAEIAYbIQcgBSEAIAUNAAsLIAdFDQACQEEAKAKY3cCAACIAIAJJDQAgASAAIAJrTw0BCyAHKAIYIQQCQAJAAkAgBygCDCIAIAdHDQAgB0EUQRAgBygCFCIAG2ooAgAiBQ0BQQAhAAwCCyAHKAIIIgUgADYCDCAAIAU2AggMAQsgB0EUaiAHQRBqIAAbIQYDQCAGIQggBSIAQRRqIABBEGogACgCFCIFGyEGIABBFEEQIAUbaigCACIFDQALIAhBADYCAAsCQCAERQ0AAkACQAJAIAcgBygCHEECdEH42cCAAGoiBSgCAEYNAAJAIAQoAhAgB0YNACAEIAA2AhQgAA0CDAQLIAQgADYCECAADQEMAwsgBSAANgIAIABFDQELIAAgBDYCGAJAIAcoAhAiBUUNACAAIAU2AhAgBSAANgIYCyAHKAIUIgVFDQEgACAFNgIUIAUgADYCGAwBC0EAQQAoApTdwIAAQX4gBygCHHdxNgKU3cCAAAsCQAJAIAFBEEkNACAHIAJBA3I2AgQgByACaiIAIAFBAXI2AgQgACABaiABNgIAAkAgAUGAAkkNACAAIAEQoIGAgAAMAgsCQAJAQQAoApDdwIAAIgVBASABQQN2dCIGcQ0AQQAgBSAGcjYCkN3AgAAgAUH4AXFBiNvAgABqIgEhBQwBCyABQfgBcSIBQYjbwIAAaiEFIAFBkNvAgABqKAIAIQELIAUgADYCCCABIAA2AgwgACAFNgIMIAAgATYCCAwBCyAHIAEgAmoiAEEDcjYCBCAHIABqIgAgACgCBEEBcjYCBAsgB0EIaiIBDQELAkACQAJAQQAoApjdwIAAIgAgAk8NAAJAQQAoApzdwIAAIgAgAksNAEEAIQEgAkEAKAK83cCAACIAakEvakEAIABrcSIARQ0CQQAtAMTdwIAAIQdBAEEBOgDE3cCAAEHg3cCAACEFQYCAxIAAQeDdwIAATQ0CIABBgIDEgABB4N3AgABrSw0CIAdB/wFxDQJBgIDEgABB4N3AgABrIQgMAwtBACAAIAJrIgE2ApzdwIAAQQBBACgCpN3AgAAiACACaiIHNgKk3cCAACAHIAFBAXI2AgQgACACQQNyNgIEIABBCGohAQwDC0EAKAKg3cCAACEBAkACQCAAIAJrIgdBD0sNAEEAQQA2AqDdwIAAQQBBADYCmN3AgAAgASAAQQNyNgIEIAEgAGoiACAAKAIEQQFyNgIEDAELQQAgBzYCmN3AgABBACABIAJqIgU2AqDdwIAAIAUgB0EBcjYCBCABIABqIAc2AgAgASACQQNyNgIECyABQQhqDwsgAEEQdiAAQf//A3FBAEdqIgdAACIAQX9GDQFBACEBIABBEHQiBUUNASAHQRB0IgBBcGogACAFQQAgAGtGGyEIC0EAQQAoAqjdwIAAIAhqIgA2AqjdwIAAQQAgAEEAKAKs3cCAACIBIAAgAUsbNgKs3cCAAAJAAkACQAJAAkACQAJAAkACQAJAQQAoAqTdwIAAIgFFDQBB+NrAgAAhAANAIAUgACgCACIHIAAoAgQiBmpGDQIgACgCCCIADQAMAwsLQQAoArTdwIAAIgBFDQUgBSAASQ0FDAcLIAEgBU8NACAHIAFLDQAgACgCDEUNAQtBAEEAKAK03cCAACIAIAUgACAFSRs2ArTdwIAAIAUgCGohB0H42sCAACEAAkACQAJAAkADQCAAKAIAIgYgB0YNASAAKAIIIgANAAwCCwsgACgCDEUNAQtB+NrAgAAhAANAAkAgACgCACIHIAFLDQAgASAHIAAoAgRqIgdJDQMLIAAoAgghAAwACwsgACAFNgIAIAAgACgCBCAIajYCBCAFQQ9qQXhxQXhqIgUgAkEDcjYCBCAGQQ9qQXhxQXhqIgcgBSACaiIAayEBIAdBACgCpN3AgABGDQIgB0EAKAKg3cCAAEYNAwJAIAcoAgQiAkEDcUEBRw0AIAcgAkF4cSICEOyAgIAAIAIgAWohASAHIAJqIgcoAgQhAgsgByACQX5xNgIEIAAgAUEBcjYCBCAAIAFqIAE2AgACQCABQYACSQ0AIAAgARCggYCAAAwGCwJAAkBBACgCkN3AgAAiAkEBIAFBA3Z0IgdxDQBBACACIAdyNgKQ3cCAACABQfgBcUGI28CAAGoiASECDAELIAFB+AFxIgFBiNvAgABqIQIgAUGQ28CAAGooAgAhAQsgAiAANgIIIAEgADYCDCAAIAI2AgwgACABNgIIDAULQQAgBUEPakF4cSIAQXhqIgY2AqTdwIAAQQAgBSAAayAIQVhqIgBqQQhqIgQ2ApzdwIAAIAYgBEEBcjYCBCAFIABqQSg2AgRBAEGAgIABNgKw3cCAACABIAdBYGpBeHFBeGoiACAAIAFBEGpJGyIGQRs2AgRBACkC+NrAgAAhCSAGQRBqQQApAoDbwIAANwIAIAZBCGoiACAJNwIAQQAgCDYC/NrAgABBACAFNgL42sCAAEEAIAA2AoDbwIAAQQBBADYChNvAgAAgBkEcaiEAA0AgAEEHNgIAIABBBGoiACAHSQ0ACyAGIAFGDQYgBiAGKAIEQX5xNgIEIAEgBiABayIAQQFyNgIEIAYgADYCAAJAIABBgAJJDQAgASAAEKCBgIAADAcLAkACQEEAKAKQ3cCAACIHQQEgAEEDdnQiBXENAEEAIAcgBXI2ApDdwIAAIABB+AFxQYjbwIAAaiIAIQcMAQsgAEH4AXEiAEGI28CAAGohByAAQZDbwIAAaigCACEACyAHIAE2AgggACABNgIMIAEgBzYCDCABIAA2AggMBgsgACAGIAhqNgIEQQBBACgCpN3AgAAiAEEPakF4cSIBQXhqIgc2AqTdwIAAQQAgACABa0EAKAKc3cCAACAIaiIBakEIaiIFNgKc3cCAACAHIAVBAXI2AgQgACABakEoNgIEQQBBgICAATYCsN3AgAAMBQtBACAANgKk3cCAAEEAQQAoApzdwIAAIAFqIgE2ApzdwIAAIAAgAUEBcjYCBAwCC0EAIAA2AqDdwIAAQQBBACgCmN3AgAAgAWoiATYCmN3AgAAgACABQQFyNgIEIAAgAWogATYCAAwBC0EAIAU2ArTdwIAADAELIAVBCGoPC0EAIAg2AvzawIAAQQAgBTYC+NrAgABBAEGI28CAADYClNvAgABBAEGQ28CAADYCnNvAgABBAEGI28CAADYCkNvAgABBAEGY28CAADYCpNvAgABBAEGQ28CAADYCmNvAgABBAEGg28CAADYCrNvAgABBAEGY28CAADYCoNvAgABBAEGo28CAADYCtNvAgABBAEGg28CAADYCqNvAgABBAEGw28CAADYCvNvAgABBAEGo28CAADYCsNvAgABBAEG428CAADYCxNvAgABBAEGw28CAADYCuNvAgABBAEHA28CAADYCzNvAgABBAEG428CAADYCwNvAgABBAEEAKALA3cCAACIAQX8gABs2ArjdwIAAQQBBADYChNvAgABBAEHI28CAADYC1NvAgABBAEHA28CAADYCyNvAgABBAEHI28CAADYC0NvAgABBAEHQ28CAADYC3NvAgABBAEHQ28CAADYC2NvAgABBAEHY28CAADYC5NvAgABBAEHY28CAADYC4NvAgABBAEHg28CAADYC7NvAgABBAEHg28CAADYC6NvAgABBAEHo28CAADYC9NvAgABBAEHo28CAADYC8NvAgABBAEHw28CAADYC/NvAgABBAEHw28CAADYC+NvAgABBAEH428CAADYChNzAgABBAEGA3MCAADYCjNzAgABBAEH428CAADYCgNzAgABBAEGA3MCAADYCiNzAgABBAEGI3MCAADYClNzAgABBAEGQ3MCAADYCnNzAgABBAEGI3MCAADYCkNzAgABBAEGQ3MCAADYCmNzAgABBAEGY3MCAADYCpNzAgABBAEGY3MCAADYCoNzAgABBAEGg3MCAADYCrNzAgABBAEGg3MCAADYCqNzAgABBAEGo3MCAADYCtNzAgABBAEGo3MCAADYCsNzAgABBAEGw3MCAADYCvNzAgABBAEGw3MCAADYCuNzAgABBAEG43MCAADYCxNzAgABBAEG43MCAADYCwNzAgABBAEHA3MCAADYCzNzAgABBAEHA3MCAADYCyNzAgABBAEHI3MCAADYC1NzAgABBAEHI3MCAADYC0NzAgABBAEHQ3MCAADYC3NzAgABBAEHY3MCAADYC5NzAgABBAEHQ3MCAADYC2NzAgABBAEHg3MCAADYC7NzAgABBAEHY3MCAADYC4NzAgABBAEHo3MCAADYC9NzAgABBAEHg3MCAADYC6NzAgABBAEHw3MCAADYC/NzAgABBAEHo3MCAADYC8NzAgABBAEH43MCAADYChN3AgABBAEHw3MCAADYC+NzAgABBAEGA3cCAADYCjN3AgABBAEH43MCAADYCgN3AgABBACAFQQ9qQXhxIgBBeGoiATYCpN3AgABBAEGA3cCAADYCiN3AgABBACAFIABrIAhBWGoiAGpBCGoiBzYCnN3AgAAgASAHQQFyNgIEIAUgAGpBKDYCBEEAQYCAgAE2ArDdwIAAC0EAIQFBACgCnN3AgAAiACACTQ0AQQAgACACayIBNgKc3cCAAEEAQQAoAqTdwIAAIgAgAmoiBzYCpN3AgAAgByABQQFyNgIEIAAgAkEDcjYCBCAAQQhqDwsgAQscAAJAIABFDQAgACABEJqAgIAAAAsQlICAgAAACxcAQfWawIAAQSNBiJvAgAAQiYCAgAAAC6MFBAJ/AXwBfQR8AkACQCABIAAoArARIgJPDQAgACgCrBEgAUHoAWxqIgEsAOQBIgJB/wFxIQMCQCACQQBIDQBEAAAAAAAAAAAhBAJAIAAgA2otAIgQDQBDAACAP0MAAIA/QwAAAAAgACoCjBEiBSAFQwAAAABdGyIFIAVDAACAP14bkyIFIAWUuyEECyABIAQ5A7ABIAEoArgBIgJBBE8NAgJAIAJFDQAgACsDoBEhBiABIAErAxAgBCABKwMYoqCaIAArA4AIIgejELKBgIAAIgggCJqitjgCLCABRApe2lxI4AdAIAYgASsDCEQYLURU+yEZQKKiIAejIgkgCSAJYhsiCUQKXtpcSOAHQCAJRApe2lxI4AdAYxsiCRCpgYCAACAIIAigorY4AiggASABKwMgIAkQp4GAgACitjgCMCACQQFGDQAgASABKwNIIAQgASsDUKKgmiAHoxCygYCAACIIIAiaorY4AmQgAUQKXtpcSOAHQCAGIAErA0BEGC1EVPshGUCioiAHoyIJIAkgCWIbIglECl7aXEjgB0AgCUQKXtpcSOAHQGMbIgkQqYGAgAAgCCAIoKK2OAJgIAEgASsDWCAJEKeBgIAAorY4AmggAkECRg0AIAEgASsDgAEgBCABKwOIAaKgmiAHoxCygYCAACIEIASaorY4ApwBIAFECl7aXEjgB0AgBiABKwN4RBgtRFT7IRlAoqIgB6MiCCAIIAhiGyIIRApe2lxI4AdAIAhECl7aXEjgB0BjGyIIEKmBgIAAIAQgBKCitjgCmAEgASABKwOQASAIEKeBgIAAorY4AqABCw8LIANBgAFB3JDAgAAQjoCAgAAACyABIAJBjI/AgAAQjoCAgAAAC0EAIAJBA0Gcj8CAABCWgICAAAALzQICAX8BfiOAgICAAEEgayIEJICAgIAAAkACQAJAIAAgAksNACABIAJLDQFBg4CAgACtQiCGIQUgACABTQ0CIAQgADYCCCAEIAE2AgwgBCAFIARBDGqthDcDGCAEIAUgBEEIaq2ENwMQQYCAwIAAIARBEGogAxCJgICAAAALIAQgADYCCCAEIAI2AgwgBEGDgICAAK1CIIYiBSAEQQxqrYQ3AxggBCAFIARBCGqthDcDEEHfgMCAACAEQRBqIAMQiYCAgAAACyAEIAE2AgggBCACNgIMIARBg4CAgACtQiCGIgUgBEEMaq2ENwMYIAQgBSAEQQhqrYQ3AxBBmIHAgAAgBEEQaiADEImAgIAAAAsgBCABNgIIIAQgAjYCDCAEIAUgBEEMaq2ENwMYIAQgBSAEQQhqrYQ3AxBBmIHAgAAgBEEQaiADEImAgIAAAAv+AgIBfwJ8AkACQAJAIAEgACgCsBEiBE8NACAAKwOACCEFIAAoAqwRIAFB6AFsaiIBIAI4AsQBAkAgASoCNItDYEKiDV1FDQAgAUEANgI0CwJAIAEqAjiLQ2BCog1dRQ0AIAFBADYCOAsCQCABKgJsi0NgQqINXUUNACABQQA2AmwLAkAgASoCcItDYEKiDV1FDQAgAUEANgJwCwJAIAEqAqQBi0NgQqINXUUNACABQQA2AqQBCwJAIAEqAqgBi0NgQqINXUUNACABQQA2AqgBCyACQ703hjVdRQ0BIAEoAsABIAEoArwBSQ0BIAEgASgC1AEgA2oiAzYC1AEgA7ghBgwCCyABIARBvI/AgAAQjoCAgAAACyABQQA2AtQBRAAAAAAAAAAAIQYLAkACQCAFRHsUrkfhepQ/oiAGYyIDRQ0AIAFBADoA5QEgAS0A5AEiAcBBf0wNASAAIAFBA3RqQQA2AgALIANBAXMPCyABQYABQcyPwIAAEI6AgIAAAAuqBQEMfyACQf8BcSEDAkACQCACwEEASA0AAkACQAJAAkACQAJAAkACQAJAAkAgASADQQN0aiIEKAIARQ0AIAQoAgQiAyABKAKwESIFTw0LQQAhBiABKAKsESIHIANB6AFsai0A5QENAiAHIAVB6AFsaiEIDAELIAEoArARIgVFDQUgASgCrBEiByAFQegBbGohCAtBACEDIAchCQJAA0AgCUHlAWotAABBAUcNASADQQFqIQMgCUHoAWoiCSAIRw0ACyABQYgQaiEKQQAhBiAHIQlBACEDA0AgCUHkAWosAAAiC0H/AXEhDCALQX9MDQMgAyAFTw0EIAcgA0HoAWxqIg0sAOQBIgtB/wFxIQ4gC0F/TA0FIAogDmotAAAhCwJAAkACQCAKIAxqLQAAQf8BcSIMDQAgC0H/AXENAQsgDEEARyALQf8BcUEAR3MNASAJQcQBaioCACANKgLEAV1FDQELIAYhAwsgBkEBaiEGIAlB6AFqIgkgCEcNAAsgAyAFTw0GIAcgA0HoAWxqLADkASIJQf8BcSEGIAlBf0wNByABIAZBA3RqQQA2AgALIAMgBU8NByAEIAM2AgRBASEGIARBATYCACAHIANB6AFsaiIJIAI6AOQBIAlBAToA5QEgCUEANgLMASAJQgA3AqQBIAlCADcCbCAJQgA3AjQLIAAgBjoABCAAIAM2AgAPCyAMQYABQfyPwIAAEI6AgIAAAAsgAyAFQYyQwIAAEI6AgIAAAAsgDkGAAUGckMCAABCOgICAAAALQQAhA0EAIQULIAMgBUGskMCAABCOgICAAAALIAZBgAFBvJDAgAAQjoCAgAAACyADIAVBzJDAgAAQjoCAgAAACyADQYABQdyPwIAAEI6AgIAAAAsgAyAFQeyPwIAAEI6AgIAAAAuLBgEJfwJAAkACQAJAAkACQAJAAkAgAUEBRw0AQQQhA0EEEJKAgIAAIgRFDQcgBCACNgIADAELIAAoAogRIgVBgQFPDQUgBUUNASAFQQJ0IgEQkoCAgAAiBEUNBCAFQQNxIQZBACEHAkACQCAFQQRJDQAgBUECdkE/cSIBQQJ0IQcgAUEFdCEIQQAhCSAEIQEDQCABIAAgCWoiAkGICGooAgA2AgAgAUEEaiACQZAIaigCADYCACABQQhqIAJBmAhqKAIANgIAIAFBDGogAkGgCGooAgA2AgAgAUEQaiEBIAggCUEgaiIJRw0ACyAGRQ0BCyAEIAdBAnRqIQEgB0EDdCAAakGICGohAgNAIAEgAigCADYCACACQQhqIQIgAUEEaiEBIAZBf2oiBg0ACwsgBUECdCEDCyAAQYgQaiEKIABBiAhqIQsgBCADaiEHIAQhBQNAAkACQAJAIAAoAogRIghBgQFPDQAgCEUNAiAFKAIAIQYgCEEDdCEJQQAhAUEAIQICQANAIAAgAWpBiAhqKAIAIAZGDQEgAkEBaiECIAkgAUEIaiIBRw0ADAQLCyALIAJBA3RqIgYsAAQhAQJAIAggAkEBaiICa0EDdCIJRQ0AIAYgCyACQQN0aiAJ/AoAAAsgACAAKAKIEUF/ajYCiBEgAUH/AXEhAiABQX9MDQEgCiACaiIBIAEtAAAiASABQQBHazoAACABQQJPDQIgACACQQN0aiIBKAIAQQFHDQIgACABKAIEEJWAgIAADAILQQAgCEGAAUGAk8CAABCWgICAAAALIAJBgAFB8JLAgAAQjoCAgAAACyAFQQRqIgUgB0cNAAsgBEF8aigCACIBQXhxIgJBBEEIIAFBA3EiARsgA2pJDQECQCABRQ0AIAIgA0EnaksNAwsgBBCBgICAAAsPC0GAs8CAAEEuQbCzwIAAEIKAgIAAAAtBwLPAgABBLkHws8CAABCCgICAAAALQQQgARCTgICAAAALQQAgBUGAAUGwksCAABCWgICAAAALQQRBBBCagICAAAALDQAgASAAEO6AgIAAAAviBgUEfwN8AX8CfAN/I4CAgIAAQcAAayICJICAgIAAAkACQCAAIAFB/wFxQQN0aiIDKAIAQQFHDQAgAygCBCIDQS9LDQEgACADQfgCbGoiBC0A/R1FDQAgBEGIG2oiBS0A9gJBAUcNAEQAAAAAAADwP0QAAAAAAAAAACAAKgLIqAG7IgYgBkQAAAAAAAAAAGMbIgYgBkQAAAAAAADwP2QbIgdEMzMzMzMz4z+iIQggACADQfgCbGohCSABQf8BcbhEXynLEMf6KUCiIQogACsDiKgBIQZBmH0hA0EJIQQDQCAAIAAoAtDSASIBQQ10IAFzIgFBEXYgAXMiAUEFdCABcyIBNgLQ0gEgAkIANwIMIAIgBiAKIAS4RPT91HjpjlNAoqAQp4GAgABECtejcNFd5UCiIgsgC5yhRPyp8dJNYlA/okQtQxzr4jYqP6CiIgv8AzYCCEEBIQwCQCABuEQAAAAAAAAAPqJEAAAAAAAA8L+gRAAAAAAAAPA/oEQAAAAAAADgP6IgCGNFDQAgACABQQ10IAFzIgFBEXYgAXMiAUEFdCABcyIBQQ10IAFzIgxBEXYgDHMiDEEFdCAMcyIMNgLQ0gEgAiALIAYgAbhEAAAAAAAAAD6iRAAAAAAAAPC/oEQAAAAAAADwP6BEAAAAAAAA4D+iRGEyVTAqqSM/okQtQxzr4jYKP6CiRAAAAAAAAPA/oKAiC/wDNgIMIAIgCyAGIAy4RAAAAAAAAAA+okQAAAAAAADwv6BEAAAAAAAA8D+gRAAAAAAAAOA/okQtQxzr4jYqP6JELUMc6+I2Gj+gokQAAAAAAADwP6Cg/AM2AhBBAyEMCwJAIAxBACAJIANqIgFBoh5qLQAAIg0bIgxBAnQiDkUNACABQfwdaiACQQhqQQQgDRsgDvwKAAALIAFBoR5qQQA6AAAgAUGgHmogDDoAACAEQQFqIQQgA0EoaiIDDQALIAVBADYCCCAFQQA6APYCIAJCADcDICACQoCAgICAgPjSwAA3AxggAkLh5NSCo6XqqT83AxAgAiAHRPp+arx0k2g/ojkDCCACQgA3AyggAkIANwMwIAJCADcDOCAAQbgNaiACQQhqEJCAgIAACyACQcAAaiSAgICAAA8LIANBMEGgkcCAABCOgICAAAALswQDBX8EfAF9AkACQCAEIAIgBCACSRsiBUUNAEEAIQYDQCAGQcANRg0CIAAgBmohAiAGQcgAaiIHIQYgBSEIIAMhBCABIQkgAi0AREEBRw0AA0ACQAJAIAIoAkAiBkUNACACIAZBf2o2AkAMAQsgAisDECEKIAAgACgCyA0iBkENdCAGcyIGQRF2IAZzIgZBBXQgBnMiBjYCyA0gAiACKwMgIAIrAyigIgs5AyggAiACKwMIIAIrAwAiDKI5AwAgAiACKwMYIg0gCiAGuEQAAAAAAAAAPqJEAAAAAAAA8L+gIA2hoqAiCjkDGCACKwMwIQ0gCxCngYCAACELIAkgCSoCACACKgI4IAwgCyANoiAKoKK2Ig6UkjgCACAEIAQqAgAgAioCPCAOlJI4AgALIARBBGohBCAJQQRqIQkgCEF/aiIIDQALAkAgAisDKCIKRJHUqFPs91dBZEUNACACIApEGC1EVPshGUAQsIGAgAA5AygLIAchBiACKwMARI3ttaD3xrA+Y0UNACAHIQYgAigCQA0AIAJBADoARCAHIQYMAAsLQQAhAgNAIAJBwA1GDQECQCAAIAJqIgRBxABqIgktAABFDQACQCAEQShqIggrAwAiCkSR1KhT7PdXQWRFDQAgCCAKRBgtRFT7IRlAELCBgIAAOQMACyAEKwMARI3ttaD3xrA+Y0UNACAEQcAAaigCAA0AIAlBADoAACACQcgAaiECDAELIAJByABqIQIMAAsLC3sBA38jgICAgABBEGsiASSAgICAACABQQRqIAAoAgAiAiAAKAIEIAJBAXQiAkEEIAJBBEsbIgIQnoCAgAACQCABKAIEQQFHDQAgASgCCCABKAIMEJOAgIAAAAsgASgCCCEDIAAgAjYCACAAIAM2AgQgAUEQaiSAgICAAAuTAQEBf0EBIQQCQAJAIANBrvSiF00NAEEAIQNBBCEBDAELIANBLGwhAwJAAkACQAJAIAFFDQAgAiABQSxsQQQgAxCggICAACEBDAELAkAgAw0AQQQhAQwCCyADEJKAgIAAIQELIAENACAAQQQ2AgQMAQsgACABNgIEQQAhBAtBCCEBCyAAIAFqIAM2AgAgACAENgIAC74DAQR/AkACQAJAAkACQCABKAKACSIEQYABRg0AQQAhBQwBCyABKAIAIQRBACEGQQAhBQJAAkACQAJAA0AgASAFaiIHKAIAIARGDQQgB0EIaigCACAERg0DIAdBEGooAgAgBEYNAiAHQRhqKAIAIARGDQEgBkEEaiEGIAVBIGoiBUGACEcNAAtBgAEhBAwHCyAGQQNyIQYMAgsgBkECciEGDAELIAZBAXIhBgsgASAGQQN0IgdqIgUtAAQhBAJAQfgHIAdrIgdFDQAgBSAFQQhqIAf8CgAACyABIAEoAoAJQX9qNgKACSAEwCIHQQBIDQEgASAEaiIEIAQtAIAIIgQgBEEAR2s6AIAIIARBAkkhBSABKAKACSEECyAEQf8ASw0CIAEgBEEDdGoiBCACNgIAIAQgAzoABCABIAEoAoAJQQFqNgKACSADQf8BcSEEIAPAQX9KDQEgBEGAAUHgksCAABCOgICAAAALIARBgAFB8JLAgAAQjoCAgAAACyABIARqIgQgBC0AgAhBAWoiBEH/ASAEQf8BSRs6AIAIIAAgBzoAASAAIAU6AAAPCyAEQYABQdCSwIAAEI6AgIAAAAuvBgEHfwJAAkACQAJAAkACQCAAQXxqIgQoAgAiBUF4cSIGQQRBCCAFQQNxIgcbIAFqSQ0AAkAgB0UNACAGIAFBJ2pLDQILQQAhAUFQQQAoArzdwIAAIghrQXdxQX1qIANNDQVBECADQQtqQXhxIANBC0kbIQkgAEF4aiEKAkACQAJAAkACQCAHRQ0AIAogBmohByAGIAlPDQMgB0EAKAKk3cCAAEYNBCAHQQAoAqDdwIAARg0CIAcoAgQiBUECcQ0JIAVBeHEiBSAGaiIGIAlJDQkgByAFEOyAgIAAIAYgCWsiB0EQSQ0BIAQgCSAEKAIAQQFxckECcjYCACAKIAlqIgUgB0EDcjYCBCAKIAZqIgYgBigCBEEBcjYCBCAFIAcQ7YCAgAAMCAsgCUGAAkkNCCAGIAlNDQggCkUNCCAGIAlrIAhBAXRLDQggAA8LIAQgBiAEKAIAQQFxckECcjYCACAKIAZqIgYgBigCBEEBcjYCBAwGC0EAKAKY3cCAACAGaiIGIAlJDQYCQAJAIAYgCWsiB0EPSw0AIAQgBUEBcSAGckECcjYCACAKIAZqIgYgBigCBEEBcjYCBEEAIQdBACEFDAELIAQgCSAFQQFxckECcjYCACAKIAlqIgUgB0EBcjYCBCAKIAZqIgYgBzYCACAGIAYoAgRBfnE2AgQLQQAgBTYCoN3AgABBACAHNgKY3cCAAAwFCyAGIAlrIgZBD00NBCAEIAkgBUEBcXJBAnI2AgAgCiAJaiIFIAZBA3I2AgQgByAHKAIEQQFyNgIEIAUgBhDtgICAAAwEC0EAKAKc3cCAACAGaiIGIAlLDQIMBAtBgLPAgABBLkGws8CAABCCgICAAAALQcCzwIAAQS5B8LPAgAAQgoCAgAAACyAEIAkgBUEBcXJBAnI2AgAgCiAJaiIHIAYgCWsiBkEBcjYCBEEAIAY2ApzdwIAAQQAgBzYCpN3AgAALIApFDQAgAA8LIAMQkoCAgAAiBkUNAAJAIANBfEF4IAQoAgAiAUEDcRsgAUF4cWoiASADIAFJGyIDRQ0AIAYgACAD/AoAAAsgABCBgICAACAGIQELIAELyhkBHX8jgICAgABB8AxrIgEkgICAgAACQCAAKAIIIgJFDQAgACgCBCIDIAJB0BJsaiEEIAFBoAxqQTxqIQIgAUGgDGpBKGohBSABQaAMakEUaiEGIAFB0AtqQTxqIQcgAUHQC2pBKGohCCABQdALakEUaiEJIAFBgAtqQTxqIQogAUGAC2pBKGohCyABQYALakEUaiEMIAFBsApqQTxqIQ0gAUGwCmpBKGohDiABQbAKakEUaiEPIAFB4AlqQTxqIRAgAUHgCWpBKGohESABQeAJakEUaiESIAFB0AhqQewAaiETIAFB0AhqQcgAaiEUIAFB0AhqQSRqIRUgAUHQCGpBPGohFiABQdAIakEoaiEXIAFB0AhqQRRqIRggAUHIBWpB7ABqIRkgAUHIBWpByABqIRogAUHIBWpBJGohGyABQcgFakEDaiEcIAFBpQFqQQNqIR0DQCAbQgA3AgAgG0IANwIIIBtCADcCECAbQgA3AhggG0EAOwEgIBpCADcCACAaQgA3AgggGkIANwIQIBpCADcCGCAaQQA7ASAgGUIANwIAIBlCADcCCCAZQgA3AhAgGUIANwIYIBlBADsBICABQQA7AegFIAFCADcD4AUgAUIANwPYBSABQgA3A9AFIAFCADcDyAUgD0IANwIAIA9CADcCCCAPQQA6ABAgDkIANwIAIA5CADcCCCAOQQA6ABAgDUIANwIAIA1CADcCCCANQQA6ABAgDEIANwIAIAxCADcCCCAMQQA6ABAgAUEAOgDACiABQgA3A7gKIAFCADcDsAogAUIANwOACyABQgA3A4gLIAFBADoAkAsgC0EAOgAQIAtCADcCCCALQgA3AgAgCkEAOgAQIApCADcCCCAKQgA3AgAgCUEAOgAQIAlCADcCCCAJQgA3AgAgCEEAOgAQIAhCADcCCCAIQgA3AgAgB0IANwIAIAdCADcCCCAHQQA6ABAgAUEAOgDgCyABQgA3A9gLIAFCADcD0AsgAUEAOgCwDCABQgA3A6gMIAFCADcDoAwgBkEAOgAQIAZCADcCCCAGQgA3AgAgBUEAOgAQIAVCADcCCCAFQgA3AgAgAkEAOgAQIAJCADcCCCACQgA3AgAgAUEAOgDgCCABQgA3A9gIIAFCADcD0AggGEEAOgAQIBhCADcCCCAYQgA3AgAgF0EAOgAQIBdCADcCCCAXQgA3AgAgFkEAOgAQIBZCADcCCCAWQgA3AgAgHSABQcgFakGQAfwKAAAgASABQbAKakHQAPwKAAAgAUGIA2ogAUGAC2pB0AD8CgAAIAFBuAJqIAFB0AtqQdAA/AoAACABQdAAaiABQaAMakHQAPwKAAAgAUHYA2ogAUHQCGpB0AD8CgAAIBVCADcCACAVQgA3AgggFUIANwIQIBVCADcCGCAVQQA7ASAgFEIANwIAIBRCADcCCCAUQgA3AhAgFEIANwIYIBRBADsBICATQgA3AgAgE0IANwIIIBNCADcCECATQgA3AhggE0EAOwEgIAFBADsB8AggAUIANwPoCCABQgA3A+AIIAFCADcD2AggAUIANwPQCCASQgA3AgAgEkIANwIIIBJBADoAECARQgA3AgAgEUIANwIIIBFBADoAECAQQgA3AgAgEEIANwIIIBBBADoAECAPQgA3AgAgD0IANwIIIA9BADoAECABQQA6APAJIAFCADcD6AkgAUIANwPgCSABQgA3A7AKIAFCADcDuAogAUEAOgDACiAOQQA6ABAgDkIANwIIIA5CADcCACANQQA6ABAgDUIANwIIIA1CADcCACAMQQA6ABAgDEIANwIIIAxCADcCACALQQA6ABAgC0IANwIIIAtCADcCACAKQgA3AgAgCkIANwIIIApBADoAECABQQA6AJALIAFCADcDiAsgAUIANwOACyABQQA6AOALIAFCADcD2AsgAUIANwPQCyAJQQA6ABAgCUIANwIIIAlCADcCACAIQQA6ABAgCEIANwIIIAhCADcCACAHQQA6ABAgB0IANwIIIAdCADcCACABQQA6ALAMIAFCADcDqAwgAUIANwOgDCAGQQA6ABAgBkIANwIIIAZCADcCACAFQQA6ABAgBUIANwIIIAVCADcCACACQQA6ABAgAkIANwIIIAJCADcCACAcIAFB0AhqQZAB/AoAACABQagEaiABQeAJakHQAPwKAAAgAUGwB2ogAUGwCmpB0AD8CgAAIAFB4AZqIAFBgAtqQdAA/AoAACABQfgEaiABQdALakHQAPwKAAAgAUGACGogAUGgDGpB0AD8CgAAIANCADcDGCADQgA3AxAgA0IANwMIIANCADcDACADQegAakIANwAAIANB5ABqQf8BOgAAIANB8ABqQgA3AAAgA0H4AGpCADcAACADQYABakIANwAAIANBiAFqIAFB2ANqQdAA/AoAACADQdwBakEAOgAAIANB2AFqQQA7AQAgA0HgAWpBAEHNAPwLACADQdQCakIANwAAIANB0AJqQf8BOgAAIANB3AJqQgA3AAAgA0HkAmpCADcAACADQewCakIANwAAIANB9AJqQQA6AAAgA0H4AmpCADcAACADQYADakIANwAAIANBiANqQgA3AAAgA0GQA2pBADYAACADQZQDaiABQYgDakHQAPwKAAAgA0GQBGpCADcAACADQYwEakH/AToAACADQegDakEAOgAAIANB5ANqQQA7AQAgA0GYBGpCADcAACADQaAEakIANwAAIANBqARqQgA3AAAgA0GwBGpBADoAACADQbQEakIANwAAIANBvARqQgA3AAAgA0HEBGpCADcAACADQcwEakEANgAAIANB0ARqIAFBuAJqQdAA/AoAACADQaQFakEAOgAAIANBoAVqQQA7AQAgA0GlBWogAUGlAWpBkwH8CgAAIANB8AZqQQA2AgAgA0HoBmpCADcDACADQeAGakIANwMAIANB2AZqQgA3AwAgA0HQBmpCADcDACADQcgGakIANwMAIANBwAZqQgA3AwAgA0G4BmpCADcDACADQbwHakIANwAAIANBuAdqQf8BOgAAIANBlAdqQf8BOgAAIANBxAdqQgA3AAAgA0HMB2pCADcAACADQdQHakEANgAAIANB2AdqIAFB0ABqQdAA/AoAACADQbAIakIANwAAIANBrAhqQQA6AAAgA0GoCGpBADsBACADQbgIakIANwAAIANBwAhqQgA3AAAgA0HICGpBADYAACADQcwIaiABQdAA/AoAACADQagJakIANwMAIANBoAlqQQA6AAAgA0GcCWpBADsBACADQbAJakIANwMAIANBuAlqQgA3AwAgA0HACWpCADcDACADQZAKakIANwAAIANBjApqQf8BOgAAIANBmApqQgA3AAAgA0GgCmpCADcAACADQagKakIANwAAIANBsApqIAFBgAhqQdAA/AoAACADQYQLakEAOgAAIANBgAtqQQA7AQAgA0GIC2pBAEHNAPwLACADQfwLakIANwAAIANB+AtqQf8BOgAAIANBhAxqQgA3AAAgA0GMDGpCADcAACADQZQMakIANwAAIANBnAxqQQA6AAAgA0GgDGpCADcAACADQagMakIANwAAIANBsAxqQgA3AAAgA0G4DGpBADYAACADQbwMaiABQbAHakHQAPwKAAAgA0G4DWpCADcAACADQbQNakH/AToAACADQZANakEAOgAAIANBjA1qQQA7AQAgA0HADWpCADcAACADQcgNakIANwAAIANB0A1qQgA3AAAgA0HYDWpBADoAACADQdwNakIANwAAIANB5A1qQgA3AAAgA0HsDWpCADcAACADQfQNakEANgAAIANB+A1qIAFB4AZqQdAA/AoAACADQcwOakEAOgAAIANByA5qQQA7AQAgA0HNDmogAUHIBWpBkwH8CgAAIANBmBBqQQA2AgAgA0GQEGpCADcDACADQYgQakIANwMAIANBgBBqQgA3AwAgA0H4D2pCADcDACADQfAPakIANwMAIANB6A9qQgA3AwAgA0HgD2pCADcDACADQeQQakIANwAAIANB4BBqQf8BOgAAIANBvBBqQf8BOgAAIANB7BBqQgA3AAAgA0H0EGpCADcAACADQfwQakEANgAAIANBgBFqIAFB+ARqQdAA/AoAACADQdgRakIANwAAIANB1BFqQQA6AAAgA0HQEWpBADsBACADQeARakIANwAAIANB6BFqQgA3AAAgA0HwEWpBADYAACADQfQRaiABQagEakHQAPwKAAAgA0HIEmpBADoAACADQcQSakEAOwEAIANB0BJqIgMgBEcNAAsLIABBADYCOCAAQeAIakEAQdAC/AsAIABBfzYCsCMgAUHwDGokgICAgAALkIICKgl/AX4BfwR+Jn8JfQF/An0FfxJ9AnwBfwV9AX8BfQF/Bn0BfwN9AX8CfQJ/An0BfwJ9An8EfQF/BH0CfwR9A38DfQF/An0BfwF9An8KfQF/An0BfCOAgICAAEHgCmsiAiSAgICAACAAKAI4IQNBACEEIABBADYCOCAAKAI0IQUgACgCMCEGIABCgICAgMAANwIwIAFBgAFJIQcCQCADQQJJDQBBASEIA0AgCEEBaiEIIAQhCQJAA0AgBSAJaiIKQSRqKAIAIApB0ABqKAIATQ0BIAopAgAhCyAKIApBLGoiDCkCADcCACAKKQIIIQ0gCiAMKQIINwIIIAopAhAhDiAKIAwpAhA3AhAgCikCGCEPIAogDCkCGDcCGCAKKQIgIRAgCiAMKQIgNwIgIAooAighESAKIAwoAig2AiggAiARNgLoAyACIBA3A+ADIAIgDzcD2AMgAiAONwPQAyACIA03A8gDIAIgCzcDwAMgDCACKQPAAzcCACAMIAIoAugDNgIoIAwgAikD4AM3AiAgDCACKQPYAzcCGCAMIAIpA9ADNwIQIAwgAikDyAM3AgggCUFUaiIJQVRHDQALCyAEQSxqIQQgCCADRw0ACwsgAUGAASAHGyESAkACQAJAAkACQAJAAkACQAJAAkAgAUUNACAAQbAbaiETIABBsBNqIRQgAEGwC2ohFSACQaMJakEraiEWIAJBowlqQRdqIRcgAkGjCWpBA2ohGCACQcADakEraiEZIAJBwANqQRdqIRogAkHAA2pBA2ohGyACQaEKakEraiEcIAJBoQpqQRdqIR0gAkGhCmpBA2ohHiACQeIJakEraiEfIAJB4glqQRdqISAgAkHiCWpBA2ohISACQStqISIgAkEXaiEjIAJBA2ohJCACQfAAakEraiElIAJB8ABqQRdqISYgAkHwAGpBA2ohJyACQeQIakEraiEoIAJB5AhqQRdqISkgAkHkCGpBA2ohKiACQY0HakEDaiErIAJBrAdqQQNqISwgAkH8A2ohLSACQegDaiEuIAJBwANqQRRqIS8gAkHgBGohMCACQeQCaiExIAJBHGohMkEAITNBACE0QQAhNQNAIBIhNgJAIDQgA08NAAJAA0ACQCAFIDRBLGxqIgooAiQiDCAzTQ0AIAwgEiAMIBJJGyE2DAMLAkAgCioCACI3vEEBdEH///93Sw0AIAoqAgQiOLxBAXRB////d0sNACAKKgIIIjm8QQF0Qf///3dLDQAgCioCDCI6vEEBdEH///93Sw0AIAoqAhAiO7xBAXRB////d0sNACAKKAIUQQF0Qf///3dLDQAgCigCGEEBdEH///93Sw0AIAoqAhwiPLxBAXRB////d0sNACAKKgIoIT0gCigCICEEIAAqAjwiPiA+kiE/AkAgACgCICIKRQ0AIApBAnQhESAAKAIcIQlBASAEdCEIIAAoAgRByBJqIQwgACgCCCEHQQAhCkMAAIC/ID9DpptEO5SVEKOBgIAAIT4DQAJAIAQgCkYNACAJKAIAIAhxRQ0AAkACQCAKIAdPDQAgDEHYdmotAABFDQEgDEG4b2oiQCA+IEAqAgAiQSBBIEFcGyJBIEEgPiA+ID5cGyJCIEEgQl0bOAIADAELIAogB0Gwk8CAABCOgICAAAALIAwtAABBAUcNACAMQeB4aiJAID4gQCoCACJBIEEgQVwbIkEgQSA+ID4gPlwbIkIgQSBCXRs4AgALIAlBBGohCSAKQQFqIQogDEHQEmohDCARQXxqIhENAAsLAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAIAQgACgCFCIKTw0AIAQgACgCCCIKTw0BIAAoAhAgBEECdGoiDCgCACIKQQJPDQICQCAAKAIEIARB0BJsIkNqIApBqAlsaiIJLQCgCUUNACAJKgKAAiE+IAlDAACAvyA/Q28SAzuUlRCjgYCAACJBID4gPiA+XBsiPiA+IEEgQSBBXBsiQSA+IEFdGzgCgAILIAwgCkEBcyJENgIAIAAgACgCtCMiCkENdCAKcyIKQRF2IApzIgpBBXQgCnMiCkENdCAKcyIMQRF2IAxzIgxBBXQgDHMiDEENdCAMcyIJQRF2IAlzIglBBXQgCXMiCUENdCAJcyIRQRF2IBFzIhFBBXQgEXMiEUENdCARcyIIQRF2IAhzIghBBXQgCHMiCEENdCAIcyIHQRF2IAdzIgdBBXQgB3MiB0ENdCAHcyJAQRF2IEBzIkBBBXQgQHMiRTYCtCMgAC0AuCMiQC0A3LTAgAAiRkF/aiJHIAQgRyAESRsiRyBGTw0gIEWzQwAAgC+UIj4gPpJDAACAv5JDAAAAP5RDAAAAP5IhSCAHs0MAAIAvlCI+ID6SQwAAgL+SQwAAAD+UQwAAAD+SIUkgCLNDAACAL5QiPiA+kkMAAIC/kkMAAAA/lEMAAAA/kiFKIBGzQwAAgC+UIj4gPpJDAACAv5JDAAAAP5RDAAAAP5IhSyAJs0MAAIAvlCI+ID6SQwAAgL+SQwAAAD+UQwAAAD+SIUwgDLNDAACAL5QiPiA+kkMAAIC/kkMAAAA/lEMAAAA/kiFNIAqzQwAAgC+UIj4gPpJDAACAv5JDpptEO5RDAACAP5IhPiBAQQJ0KALktMCAACBHQQJ0aioCACFBIB5BADoAECAeQgA3AAggHkIANwAAIB1CADcAACAdQgA3AAggHUEAOgAQIBxCADcAACAcQgA3AAggHEEAOgAQIC9CADcCACAvQgA3AgggL0EAOgAQIC5CADcCACAuQgA3AgggLkEAOgAQIAJCADcDwAMgAkIANwPIAyACQQA6ANADIC1BADoAECAtQgA3AgggLUIANwIAICRCADcAACAkQgA3AAggJEEAOgAQICNCADcAACAjQgA3AAggI0EAOgAQICJCADcAACAiQgA3AAggIkEAOgAQICdCADcAACAnQgA3AAggJ0EAOgAQICZCADcAACAmQgA3AAggJkEAOgAQICVBADoAECAlQgA3AAggJUIANwAAIAJCADcDiAYgAkIANwOABiACQgA3A/gFIAIgAikA2Ao3AO8FIAIgAikA0Qo3A+gFIAIgAikAyQo3A+AFIAIgAikAwQo3A9gFIAIgAikAuQo3A9AFIAIgAikAsQo3A8gFIAIgAikAqQo3A8AFIAIgAikAoQo3A7gFIAJBgAJqIAJBwANqQdAA/AoAACACIAIpADc3AMcGIAIgAikAMDcDwAYgAiACKQAoNwO4BiACIAIpACA3A7AGIAIgAikAGDcDqAYgAiACKQAQNwOgBiACIAIpAAg3A5gGIAIgAikAADcDkAYgAiACKQBwNwOICCACIAIpAHg3A5AIIAIgAikAgAE3A5gIIAIgAikAiAE3A6AIIAIgAikAkAE3A6gIIAIgAikAmAE3A7AIIAIgAikAoAE3A7gIIAIgAikApwE3AL8IICxCADcAACAsQgA3AAggLEIANwAQICxCADcAGCAsQQA6ACAgK0IANwAAICtCADcACCArQgA3ABAgK0EANgAYIAJCADcD0AcgAkIANwPYByACQgA3A+AHIAJCADcD0AYgAkIANwPYBiACQgA3A+AGIAJCADcD2AggAkIANwPQCCACQgA3A8gIIAJCADcDgAggAkIANwP4B0MAACBBIEFDAACgwZUQx4GAgAAhTiBADgUDBAUGBgMLIAQgCkHAk8CAABCOgICAAAALIAQgCkHQk8CAABCOgICAAAALIApBAkHgk8CAABCOgICAAAALQwAAoD8hTyAEDgoEBQYHDAsICAkKAwtDZmZmPyFPIAQOBA4PEBIRCyA3ID6UIT4gBA4GExYXEhgUEgsgP0MAAAA/lCJBQ2Zm5j6UIlBDAACgQWBFDRogUEMAAHpEIFBDAAB6RF0bQ9sPSUCUIEEgQZIiUZUQw4GAgAAaQQAhRiBQQwAAoEEgOSA5QwAAoEFdGyJBIEEgUF4bQ9sPSUCUIFGVEMOBgIAAIUEgKkEAOgAQQgAhCyAqQgA3AAggKkIANwAAIClCADcAACApQgA3AAggKUEAOgAQIChCADcAACAoQgA3AAggKEEAOgAQIAJCADcDwAMgAkIANwPIAyACQgA3A8gIIAJCADcD0AggAkIANwPYCCACIAIpAOQINwOICCACIAIpAOwINwOQCCACIAIpAPQINwOYCCACIAIpAPwINwOgCCACIAIpAIQJNwOoCCACIAIpAIwJNwOwCCACIAIpAJQJNwO4CCACIAIpAJsJNwC/CCBBQwAAgD8gQUMAAIA/kpUiUpQiUyBTIFOUIlSUIVVDAACAPyA/Q28SgzqUIkEgQSBBXBsiQUMAAIA/IEFDAACAP14bIVZDAACAPyBUIFSUIldDzcxMPpRDAACAP5KVIVhDAAAAACFZIDtDAAAAAJcgNyA+lCI+lLshWiA+uyA/u6MhWyA/QwAAAACU/AEhR0EBIQlB/wEhXEMzM5PAQ28SgzogOCA4IDhcGyI+Q28SgzogPkNvEoM6XhsgP5SVEKOBgIAAIV1DAAAAACFeQwAAAAAhX0MAAAAAIWBDAAAAACFhQQAhYkMAAAAAIWNBACFkQwAAAAAhTUMAAAAAIUxDAAAAACFLQwAAAAAhSkMAAAAAIUlDAAAAACFIQwAAAAAhZUMAAAAAIWZDAAAAACFnQwAAAAAhaEMAAAAAIWlDAAAAACFqQQAha0MAAAAAIWxDAAAAACFtQwAAAAAhbkMAAAAAITtBACFAQQAhb0EAIRFDAAAAACFwQwAAAAAhcUMAAAAAIU9BACFyQf8BIXNDAAAAACF0QwAAAAAhdUEAIXZBACEIQwAAAAAhN0MAAAAAIXdDAAAAACF4QQAheUEAIXpDAAAAACF7QwAAAAAhfEMAAAAAIX1CACENQwAAAAAhfkEAIX9BACE2QwAAAAAhgAFDAAAAACGBAUMAAAAAIYIBQwAAAAAhgwFBACGEAUH/ASGFAUMAAAAAIYYBQwAAAAAhhwFBACEHQQAhDEMAAAAAIYgBQwAAAAAhiQFDAAAAACFBQQAhigFDAAAAACFCQwAAAAAhOUEAIYsBQQAhjAFDAAAAACGNAUMAAAAAIY4BQwAAAAAhjwFBACGQAUMAAAAAIZEBQwAAAAAhkgFDAAAAACE+QQAhkwFDAAAAACGUAUEBIZUBIAQhlgEMNAsgGEEAOgAQIBhCADcACCAYQgA3AAAgF0IANwAAIBdCADcACCAXQQA6ABAgFkIANwAAIBZCADcACCAWQQA6ABAgAkIANwPQBiACQgA3A9gGIAJCADcD4AYgAiACKQCjCTcDkAYgAiACKQCrCTcDmAYgAiACKQCzCTcDoAYgAiACKQC7CTcDqAYgAiACKQDDCTcDsAYgAiACKQDLCTcDuAYgAiACKQDTCTcDwAYgAiACKQDaCTcAxwYgP0NI4fo+lCJBQwAAIEFgRQ0aQgAhCyBBQwAAJUUgQUMAACVFXRtD2w9JQJQgP5UQw4GAgAAhQSACQgA3A4AHIAJCADcD+AZDAACAPyA/Q28SAzqUIkIgQiBCXBsiQkMAAIA/IEJDAACAP14bIXFDbts2PyGXASBBIEFDAACAPyBBIEFDbts2P5KUQwAAgD+SlSKYAZQimQGUIZoBIDcgPpQiPkMAAAdElCA/lSFlID5DAABIRJQgP5UhZkMAAAAAIVkgP0MAAAAAlPwBIXJEAAAAAAAAAAAhWkNmZqY/IT5BAiF2QwAAAD8hdUH/ASFcQ2ZmZj8hT0EBIWtBACFGQzMzk8BDbxKDOiA4IDggOFwbIkFDbxKDOiBBQ28SgzpeGyA/lJUQo4GAgAAhcEMAAAAAIV5DAAAAACFfQwAAAAAhYEMAAAAAIWFBACFiQwAAAAAhY0EAIWRDAAAAACFnQwAAAAAhaEMAAAAAIWlDAAAAACFqQwAAAAAhbEMAAAAAIW1DAAAAACFuQwAAAAAhO0EAIUBBACFvQQEhEUEBIXNDAAAAACF0DC0LIBtBADoAECAbQgA3AAggG0IANwAAIBpCADcAACAaQgA3AAggGkEAOgAQIBlCADcAACAZQgA3AAggGUEAOgAQIAJCADcD+AUgAkIANwOABiACQgA3A4gGIAIgAikAwAM3A7gFIAIgAikAyAM3A8AFIAIgAikA0AM3A8gFIAIgAikA2AM3A9AFIAIgAikA4AM3A9gFIAIgAikA6AM3A+AFIAIgAikA8AM3A+gFIAIgAikA9wM3AO8FID9DSOH6PpQiQUMAACBBYEUNGkIAIQsgQUMAwFpFIEFDAMBaRV0bQ9sPSUCUID+VEMOBgIAAIUEgAkIANwOACCACQgA3A/gHQwAAgD8hO0MAAIA/ID9DppvEOpQiQiBCIEJcGyJCQwAAgD8gQkMAAIA/XhshbkNu27Y/IZIBIEEgQUMAAIA/IEEgQUNu27Y/kpRDAACAP5KVIpEBlCKHAZQhhgEgNyA+lCA/lSGCASA/Qxe30TmU/AEhkwFDAAAAACFZID9DAAAAAJT8ASFAQwAAQMAgP0PNzMw8lJUQo4GAgAC8IWREAAAAAAAAAAAhWkMAAIA+IZQBQ83MzD8hPkGAgID8AyGEAUOPwnU9IYABQQEhb0H/ASFcQQAhRkMzM5PAQ28SgzogOCA4IDhcGyJBQ28SgzogQUNvEoM6XhsgP5SVEKOBgIAAIW1DAAAAACFeQwAAAAAhX0MAAAAAIWBDAAAAACFhQQAhYkMAAAAAIWNDAAAAACFNQwAAAAAhTEMAAAAAIUtDAAAAACFKQwAAAAAhSUMAAAAAIUhDAAAAACFlQwAAAAAhZkMAAAAAIWdDAAAAACFoQwAAAAAhaUMAAAAAIWpBACFrQwAAAAAhbEEAIRFDAAAAACFwQwAAAAAhcUMAAAAAIU9BACFyQf8BIXNDAAAAACF0QwAAAAAhdUEAIXZBACEIQwAAAAAhN0MAAAAAIXdDAAAAACF4QQAheUEAIXpDAAAAACF7QwAAAAAhfEMAAAAAIX1CACENQwAAAAAhfkEAIX9BASE2QwAAgD8hgQFDAAAAACGDAUH/ASGFAUEAIQdBACEMQwAAAAAhiAFDAAAAACGJAUMAAAAAIUFBACGKAUMAAAAAIUJDAAAAACE5QQAhiwFBACGMAUMAAAAAIY0BQwAAAAAhjgFDAAAAACGPAUEAIZABDDELIBtBADoAECAbQgA3AAggG0IANwAAIBpCADcAACAaQgA3AAggGkEAOgAQIBlCADcAACAZQgA3AAggGUEAOgAQIAJCADcD+AUgAkIANwOABiACQgA3A4gGIAIgAikAwAM3A7gFIAIgAikAyAM3A8AFIAIgAikA0AM3A8gFIAIgAikA2AM3A9AFIAIgAikA4AM3A9gFIAIgAikA6AM3A+AFIAIgAikA8AM3A+gFIAIgAikA9wM3AO8FID9DSOH6PpQiQUMAACBBYEUNGkIAIQsgQUMAAOFEIEFDAADhRF0bQ9sPSUCUID+VEMOBgIAAIUEgAkIANwPgByACQgA3A9gHIAJCADcD0AdDAACAPyA/Q28SAzqUIkIgQiBCXBsiQkMAAIA/IEJDAACAP14bIY4BQwAAgD8gP0Omm8Q6lCJCIEIgQlwbIkJDAACAPyBCQwAAgD9eGyFuQ6uqqj8hbCBBIEFDAACAPyBBIEFDq6qqP5KUQwAAgD+SlSJZlCJelCFfIDhDmpkZP5QhjwFDAACAPyA3Q5qZGT+UkyGBASA3Q2ZmJj+UQzMzsz6SIXwgOSA+lCI+QwAAOUOUID+VIYIBID5DAAClQ5QgP5UhfUMAAAAAIWAgP0MAAAAAlPwBIUBDAABAwCA/QwrXIzyUlRCjgYCAALwiZK0hDUQAAAAAAAAAACFaQ2Zmpj8hPkGQro/tAyGEAUMQ16M9IX5DCtejPCF7QQEhYkH/ASFcQQAha0PNzAw/ITtBAiFGQzMzk8AgOkNvEoM6lyA/lJUQo4GAgAAhjQFDMzOTwCA6Q2ZmJj+UQ28SgzqXID+UlRCjgYCAACFtQwAAAAAhYUMAAAAAIWNDAAAAACFNQwAAAAAhTEMAAAAAIUtDAAAAACFKQwAAAAAhSUMAAAAAIUhDAAAAACFlQwAAAAAhZkMAAAAAIWdDAAAAACFoQwAAAAAhaUMAAAAAIWpBASFvQQAhEUMAAAAAIXBDAAAAACFxQwAAAAAhT0EAIXJB/wEhc0MAAAAAIXRDAAAAACF1QQAhdkEAIQhDAAAAACE3QwAAAAAhd0MAAAAAIXhBACF5QQEhekEAIX9BASE2QwrXozwhgAEMKAsgG0EAOgAQIBtCADcACCAbQgA3AAAgGkIANwAAIBpCADcACCAaQQA6ABAgGUIANwAAIBlCADcACCAZQQA6ABAgAkIANwP4BSACQgA3A4AGIAJCADcDiAYgAiACKQDAAzcDuAUgAiACKQDIAzcDwAUgAiACKQDQAzcDyAUgAiACKQDYAzcD0AUgAiACKQDgAzcD2AUgAiACKQDoAzcD4AUgAiACKQDwAzcD6AUgAiACKQD3AzcA7wUgP0NI4fo+lCJBQwAAIEFgRQ0aQgAhCyBBQwBAnEUgQUMAQJxFXRtD2w9JQJQgP5UQw4GAgAAhQSACQgA3A+AHIAJCADcD2AcgAkIANwPQB0MAAIA/IXxDAACAPyA/Q28SAzqUIkIgQiBCXBsiQkMAAIA/IEJDAACAP14bIY4BQwAAgD8gP0Omm8Q6lCJCIEIgQlwbIkJDAACAPyBCQwAAgD9eGyFuQ6uqqj8hbCBBIEFDAACAPyBBIEFDq6qqP5KUQwAAgD+SlSJZlCJelCFfIDcgPpQiPkMAgONDlCA/lSGCASA+QwBg0ESUID+VIX1DAAAAACFgID9DAAAAAJT8ASFAQwAAQMAgP0NvEoM6lJUQo4GAgAC8ImStIQ1EAAAAAAAAAAAhWkMAAABAIT5DAAAAPyGPAUOamRk/IYEBQQEhYkH/ASFcQQAha0MzMzM/ITtBAiFGQzMzk8BDbxKDOiA4IDggOFwbIkFDbxKDOiBBQ28SgzpeGyA/lJUQo4GAgAAhbUMzM5PAQ28SgzogOEOJiIg+lCJBIEEgQVwbIkFDbxKDOiBBQ28SgzpeGyA/lJUQo4GAgAAhjQFDAAAAACFhQwAAAAAhY0MAAAAAIU1DAAAAACFMQwAAAAAhS0MAAAAAIUpDAAAAACFJQwAAAAAhSEMAAAAAIWVDAAAAACFmQwAAAAAhZ0MAAAAAIWhDAAAAACFpQwAAAAAhakEBIW9BACERQwAAAAAhcEMAAAAAIXFDAAAAACFPQQAhckH/ASFzQwAAAAAhdEMAAAAAIXVBACF2QQAhCEMAAAAAITdDAAAAACF3QwAAAAAheEEBIXlBASF6QwAAAAAhe0MAAAAAIX5BASF/QQEhNkMAAAAAIYABQwAAAAAhgwFBACGEAQwoCyA/Q0jh+j6UIj5DAAAgQWBFDRpCACELID5DAAAgQSA3QwAAekSUIkEgQUMAACBBXRsiQSBBID5eG0PbD0lAlCA/lRDDgYCAACE+IAJCADcD4AcgAkIANwPYByACQgA3A9AHQ27bNj8hbCA+ID5DAACAPyA+ID5Dbts2P5KUQwAAgD+SlSJZlCJelCFfQwAAgD8gP0NvEgM6lCI+ID4gPlwbIj5DAACAPyA+QwAAgD9eGyGJASA/Q28SAz2U/AEhigEgP0MxCKw8lPwBIYsBID9DCtcjPJT8ASGMAUMAAAAAIWMgP0MAAAAAlPwBIZABRAAAAAAAAAAAIVpDmpmZPyE+QzMzsz8hQUH/ASFcQQAhZEEEIWJBASFGQ6uqKj8hYUMAAMA/IWBDMzOTwCA/Q28SgzyUlRCjgYCAACFCQzMzk8BDbxKDOiA4IDggOFwbIjhDbxKDOiA4Q28SgzpeGyA/lJUQo4GAgAAhiAFDAAAAACFNQwAAAAAhTEMAAAAAIUtDAAAAACFKQwAAAAAhSUMAAAAAIUhDAAAAACFlQwAAAAAhZkMAAAAAIWdDAAAAACFoQwAAAAAhaUMAAAAAIWpBACFrQwAAAAAhbUMAAAAAIW5DAAAAACE7QQAhQEEAIW9BACERQwAAAAAhcEMAAAAAIXFDAAAAACFPQQAhckH/ASFzQwAAAAAhdEMAAAAAIXVBACF2QQAhCEMAAAAAITdDAAAAACF3QwAAAAAheEEAIXlBACF6QwAAAAAhe0MAAAAAIXxDAAAAACF9QgAhDUMAAAAAIX5BACF/QQAhNkMAAAAAIYABQwAAAAAhgQFDAAAAACGCAUMAAAAAIYMBQQAhhAFB/wEhhQFDAAAAACGGAUMAAAAAIYcBQQEhB0EBIQwgQiGNAUMAAIA/ID9DF7fROZQiOCA4IDhcGyI4QwAAgD8gOEMAAIA/XhsiOSGOAUMzM7M/IY8BDC0LIBtBADoAECAbQgA3AAggG0IANwAAIBpCADcAACAaQgA3AAggGkEAOgAQIBlCADcAACAZQgA3AAggGUEAOgAQIAJCADcD+AUgAkIANwOABiACQgA3A4gGIAIgAikAwAM3A7gFIAIgAikAyAM3A8AFIAIgAikA0AM3A8gFIAIgAikA2AM3A9AFIAIgAikA4AM3A9gFIAIgAikA6AM3A+AFIAIgAikA8AM3A+gFIAIgAikA9wM3AO8FID9DSOH6PpQiQUMAACBBYEUNGkIAIQsgQUMAgDtFIEFDAIA7RV0bQ9sPSUCUID+VEMOBgIAAIUEgAkIANwPgByACQgA3A9gHIAJCADcD0AdDAACAPyGBAUMAAIA/ID9DUkmdOZQiQiBCIEJcGyJCQwAAgD8gQkMAAIA/XhshjgFDAACAPyA/Q6abxDqUIkIgQiBCXBsiQkMAAIA/IEJDAACAP14bIW5Dq6qqPyFsIEEgQUMAAIA/IEEgQUOrqqo/kpRDAACAP5KVIlmUIl6UIV8gNyA+lCI+ID+VIYIBID5DAADAP5QgP5UhfUMAAAAAIWBDAABAwCA/Q4/CdT2UlRCjgYCAALwiZK0hDUQAAAAAAAAAACFaQ2Zmpj8hPkGas+b4AyGEAUPNzEw9IYABQ5qZGT8hfkOamRk+IXxBASFiQf8BIVxBACFrQ2ZmZj8hO0ECIUZDMzOTwCA/QwrXIzyUlRCjgYCAACGNAUMzM5PAQ28SgzogOCA4IDhcGyJBQ28SgzogQUNvEoM6XhsgP5SVEKOBgIAAIW1DAAAAACFhQwAAAAAhY0MAAAAAIU1DAAAAACFMQwAAAAAhS0MAAAAAIUpDAAAAACFJQwAAAAAhSEMAAAAAIWVDAAAAACFmQwAAAAAhZ0MAAAAAIWhDAAAAACFpQwAAAAAhakEBIW9BACERQwAAAAAhcEMAAAAAIXFDAAAAACFPQQAhckH/ASFzQwAAAAAhdEMAAAAAIXVBACF2QQAhCEMAAAAAITdDAAAAACF3QwAAAAAheEEBIXlBASF6QwAAAAAhe0EAIX9BASE2QwAAAAAhgwFB/wEhhQFDAAAAACGGAUMAAAAAIYcBQQEhB0EAIQxDAAAAACGIAUMAAAAAIYkBQwAAAAAhQUEAIYoBQwAAAAAhQkMAAAAAITlBACGLAUEAIYwBQ5qZGT4hjwEgP0MAAAAAlPwBIkAhkAEMLAsgIUEAOgAQICFCADcACCAhQgA3AAAgIEIANwAAICBCADcACCAgQQA6ABAgH0IANwAAIB9CADcACCAfQQA6ABAgAkIANwPQBiACQgA3A9gGIAJCADcD4AYgAiACKQDiCTcDkAYgAiACKQDqCTcDmAYgAiACKQDyCTcDoAYgAiACKQD6CTcDqAYgAiACKQCCCjcDsAYgAiACKQCKCjcDuAYgAiACKQCSCjcDwAYgAiACKQCZCjcAxwYgP0NI4fo+lCJBQwAAIEFgRQ0aQgAhCyBBQwAAIEEgOEMAwNpFlCJCIEJDAAAgQV0bIkIgQiBBXhtD2w9JQJQgP5UQw4GAgAAhQiACQgA3A4AHIAJCADcD+AYgQUMAACBBIDhDAECcRZQiOCA4QwAAIEFdGyI4IDggQV4bQ9sPSUCUID+VEMOBgIAAIUEgAkIANwPwBiACQgA3A+gGQwAAAEAhlwEgQiBCQwAAgD8gQiBCQwAAAECSlEMAAIA/kpUimAGUIpkBlCGaASBBIEFDAACAPyBBIEFDq6qqP5KUQwAAgD+SlSKbAZQinAGUIZ0BQwAAgD8gP0NvEgM7lCJBIEEgQVwbIkFDAACAPyBBQwAAgD9eGyFxID5DzUxNQ5QgP5UhZSA+QzMzmEOUID+VIWYgPkPNzLhDlCA/lSFnID5DzawCRJQgP5UhaCA+QwAAB0SUID+VIWkgPkMAAEhElCA/lSFqQwAAAAAhWSA/QwAAAACU/AEhckQAAAAAAAAAACFaQ5qZmT8hPkH/ASGFAUEGIXZDAAAAPyF1QzMzsz4hdEECIVxDAABAPyFPQQEha0EAIUZDMzOTwENvEoM6IDcgNyA3XBsiQUNvEoM6IEFDbxKDOl4bID+UlRCjgYCAACFwQwAAAAAhXkMAAAAAIV9DAAAAACFgQwAAAAAhYUEAIWJDAAAAACFjQQAhZEMAAAAAIWxDAAAAACFtQwAAAAAhbkMAAAAAITtBACFAQQAhb0EBIRFBASFzDAQLIB5BADoAECAeQgA3AAggHkIANwAAIB1CADcAACAdQgA3AAggHUEAOgAQIBxCADcAACAcQgA3AAggHEEAOgAQIAJCADcD0AYgAkIANwPYBiACQgA3A+AGIAIgAikAoQo3A5AGIAIgAikAqQo3A5gGIAIgAikAsQo3A6AGIAIgAikAuQo3A6gGIAIgAikAwQo3A7AGIAIgAikAyQo3A7gGIAIgAikA0Qo3A8AGIAIgAikA2Ao3AMcGID9DSOH6PpQiQUMAACBBYEUNGkIAIQsgQUMAACBBIDhDAACWRZQiQiBCQwAAIEFdGyJCIEIgQV4bQ9sPSUCUID+VEMOBgIAAIUIgAkIANwOAByACQgA3A/gGIEFDAAAgQSA4QwCAO0WUIjggOEMAACBBXRsiOCA4IEFeG0PbD0lAlCA/lRDDgYCAACFBIAJCADcD8AYgAkIANwPoBkPNzMw+IZcBIEIgQkMAAIA/IEIgQkPNzMw+kpRDAACAP5KVIpgBlCKZAZQhmgEgQSBBQwAAgD8gQSBBQ6uqqj+SlEMAAIA/kpUimwGUIpwBlCGdAUMAAIA/ID9DbxKDOpQiQSBBIEFcGyJBQwAAgD8gQUMAAIA/XhshcSA+Q9ejkD+UIj5DzUxNQ5QgP5UhZSA+QzMzmEOUID+VIWYgPkPNzLhDlCA/lSFnID5DzawCRJQgP5UhaCA+QwAAB0SUID+VIWkgPkMAAEhElCA/lSFqQwAAAAAhWSA/QwAAAACU/AEhckQAAAAAAAAAACFaQ5qZmT8hPkH/ASGFAUEGIXZDAAAAPyF1QQIhXEPNzEw/IU9BASFrQQAhRkMzM5PAQ28SgzogNyA3IDdcGyJBQ28SgzogQUNvEoM6XhsgP5SVEKOBgIAAIXAMAgtDAACAPyFPCyAkQQA6ABAgJEIANwAIICRCADcAACAjQgA3AAAgI0IANwAIICNBADoAECAiQgA3AAAgIkIANwAIICJBADoAECACQgA3A9AGIAJCADcD2AYgAkIANwPgBiACIAIpAAA3A5AGIAIgAikACDcDmAYgAiACKQAQNwOgBiACIAIpABg3A6gGIAIgAikAIDcDsAYgAiACKQAoNwO4BiACIAIpADA3A8AGIAIgAikANzcAxwYgP0NI4fo+lCJBQwAAIEFgRQ0ZQgAhCyBBQwAAIEEgOEMAQBxGlCJCIEJDAAAgQV0bIkIgQiBBXhtD2w9JQJQgP5UQw4GAgAAhQiACQgA3A4AHIAJCADcD+AYgQUMAACBBIDhDAMDaRZQiOCA4QwAAIEFdGyI4IDggQV4bQ9sPSUCUID+VEMOBgIAAIUEgAkIANwPwBiACQgA3A+gGQwAAgD8hlwEgQiBCQwAAgD8gQiBCQwAAgD+SlEMAAIA/kpUimAGUIpkBlCGaASBBIEFDAACAPyBBIEFDq6qqP5KUQwAAgD+SlSKbAZQinAGUIZ0BQwAAgD8gP0NvEgM6lCJBIEEgQVwbIkFDAACAPyBBQwAAgD9eGyFxID5DzUxNQ5QgP5UhZSA+QzMzmEOUID+VIWYgPkPNzLhDlCA/lSFnID5DzawCRJQgP5UhaCA+QwAAB0SUID+VIWkgPkMAAEhElCA/lSFqQwAAAAAhWSA/QwAAAACU/AEhckQAAAAAAAAAACFaQ5qZmT8hPkH/ASGFAUEGIXZDAAAAPyF1QQIhXEEBIWtBACFGQzMzk8BDbxKDOiA3IDcgN1wbIkFDbxKDOiBBQ28SgzpeGyA/lJUQo4GAgAAhcAtDAAAAACFeQwAAAAAhX0MAAAAAIWBDAAAAACFhQQAhYkMAAAAAIWNBACFkQwAAAAAhbEMAAAAAIW1DAAAAACFuQwAAAAAhO0EAIUBBACFvQQEhEUEBIXNDAAAAACF0C0EAIQhDAAAAACE3QwAAAAAhd0MAAAAAIXhBACF5QQAhekMAAAAAIXtDAAAAACF8QwAAAAAhfUIAIQ1DAAAAACF+QQAhf0EAITZDAAAAACGAAUMAAAAAIYEBQwAAAAAhggFDAAAAACGDAUEAIYQBDCULIBtBADoAECAbQgA3AAggG0IANwAAIBpCADcAACAaQgA3AAggGkEAOgAQIBlCADcAACAZQgA3AAggGUEAOgAQIAJCADcD+AUgAkIANwOABiACQgA3A4gGIAIgAikAwAM3A7gFIAIgAikAyAM3A8AFIAIgAikA0AM3A8gFIAIgAikA2AM3A9AFIAIgAikA4AM3A9gFIAIgAikA6AM3A+AFIAIgAikA8AM3A+gFIAIgAikA9wM3AO8FID9DSOH6PpQiQUMAACBBYEUNF0IAIQsgQUMAAHpFIEFDAAB6RV0bQ9sPSUCUID+VEMOBgIAAIUEgAkIANwPgByACQgA3A9gHIAJCADcD0AdDAACAPyE7QwAAgD8gP0NvEgM6lCJCIEIgQlwbIkJDAACAPyBCQwAAgD9eGyGOAUMAAIA/ID9DppvEOpQiQiBCIEJcGyJCQwAAgD8gQkMAAIA/XhshbkOrqqo/IWwgQSBBQwAAgD8gQSBBQ6uqqj+SlEMAAIA/kpUiWZQiXpQhXyA5QzMzMz+UIY8BIDcgPpQgP5UhggFDAAAAACFgID9DAAAAAJT8ASFAQwAAQMAgP0MxCKw8lJUQo4GAgAC8IWREAAAAAAAAAAAhWkPNzAxAIT5BgICAhAQhhAFDmpmZPiGDAUOPwvU8IYABQQEhYkH/ASFcQQAhRkMzM5PAID9DpptEPJSVEKOBgIAAIY0BQwAAgL8gP0PNzEw9lJUQo4GAgAAhY0MzM5PAQ28SgzogOCA4IDhcGyJBQ28SgzogQUNvEoM6XhsgP5SVEKOBgIAAIW1DAAAAACFhQwAAAAAhTUMAAAAAIUxDAAAAACFLQwAAAAAhSkMAAAAAIUlDAAAAACFIQwAAAAAhZUMAAAAAIWZDAAAAACFnQwAAAAAhaEMAAAAAIWlDAAAAACFqQQAha0EBIW9BACERQwAAAAAhcEMAAAAAIXFDAAAAACFPQQAhckH/ASFzQwAAAAAhdEMAAAAAIXVBACF2QQAhCEMAAAAAITdDAAAAACF3QwAAAAAheEEAIXlBACF6QwAAAAAhe0MAAAAAIXxDAAAAACF9QgAhDUMAAAAAIX5BACF/QQEhNkMAAIA/IYEBDB8LIBtBADoAECAbQgA3AAggG0IANwAAIBpCADcAACAaQgA3AAggGkEAOgAQIBlCADcAACAZQgA3AAggGUEAOgAQIAJCADcD+AUgAkIANwOABiACQgA3A4gGIAIgAikAwAM3A7gFIAIgAikAyAM3A8AFIAIgAikA0AM3A8gFIAIgAikA2AM3A9AFIAIgAikA4AM3A9gFIAIgAikA6AM3A+AFIAIgAikA8AM3A+gFIAIgAikA9wM3AO8FID9DSOH6PpQiQUMAACBBYEUNF0IAIQsgQUMAAJZEIEFDAACWRF0bQ9sPSUCUID+VEMOBgIAAIUIgQUMAACBBIDdDAMDaRZRDAIA7RZIiNyA3QwAAIEFdGyI3IDcgQV4bQ9sPSUCUID+VEMOBgIAAIUEgAkIANwPwByACQgA3A+gHIAJCADcD0AcgAkIANwPYByACQgA3A+AHQ6uqqj8hbEMAAIA/IYEBIEEgQUMAAIA/IEEgQUOrqqo/kpRDAACAP5KVIp4BlCKfAZQhoAFDAACAPyA/Q28SAzqUIkEgQSBBXBsiQUMAAIA/IEFDAACAP14bIY4BQwAAgD8gP0Omm8Q6lCJBIEEgQVwbIkFDAACAPyBBQwAAgD9eGyFuIEIgQkMAAIA/IEIgQkOrqqo/kpRDAACAP5KVIlmUIl6UIV8gOEMAAEA/lCGPASA5ID6UIj5DAAA0Q5QgP5UhggEgPkMAAKVDlCA/lSF9QwAAAAAhYCA/QwAAAACU/AEhQEMK16M8IXtDAABAwCA/QwrXozyUlRCjgYCAALwiZK0hDUQAAAAAAAAAACFaQ2Zmpj8hPkGYs+bwAyGEAUOYmRk+IX5DmpkZPyF8QQEhYkH/ASFcQQAha0MAAAA/ITtBAiFGQzMzk8AgOkNvEoM6lyA/lJUQo4GAgAAhjQFDMzOTwCA6Q8dxHD+UQ28SgzqXID+UlRCjgYCAACFtQwAAAAAhYUMAAAAAIWNDAAAAACFNQwAAAAAhTEMAAAAAIUtDAAAAACFKQwAAAAAhSUMAAAAAIUhDAAAAACFlQwAAAAAhZkMAAAAAIWdDAAAAACFoQwAAAAAhaUMAAAAAIWpBASFvQQAhEUMAAAAAIXBDAAAAACFxQwAAAAAhT0EAIXJB/wEhc0MAAAAAIXRDAAAAACF1QQAhdkEAIQhDAAAAACE3QwAAAAAhd0MAAAAAIXhBASF5QQEhekEBIX9BASE2QwrXozwhgAFDAAAAACGDAUEAIYUBDB8LID9DSOH6PpQiPkMAACBBYEUNF0IAIQsgPkMAACBBIDdDAICJRJQiQSBBQwAAIEFdGyJBIEEgPl4bQ9sPSUCUID+VEMOBgIAAIT4gAkIANwPgByACQgA3A9gHIAJCADcD0AdDAAAgPyFsID4gPkMAAIA/ID4gPkMAACA/kpRDAACAP5KVIlmUIl6UIV9DAACAPyA/Q28SAzqUIj4gPiA+XBsiPkMAAIA/ID5DAACAP14bIYkBID9DAisHPZT8ASGKASA/Q1g5tDyU/AEhiwEgP0NYOTQ8lPwBIYwBQwAAAAAhYyA/QwAAAACU/AEhkAFEAAAAAAAAAAAhWkOamZk/IT5B/wEhXEEAIWRBBCFiQQEhRkOrqio/IWFDAADAPyFgQzMzk8AgP0O8dJM8lJUQo4GAgAAhQkMzM5PAQ28SgzogOCA4IDhcGyJBQ28SgzogQUNvEoM6XhsgP5SVEKOBgIAAIYgBQwAAAAAhTUMAAAAAIUxDAAAAACFLQwAAAAAhSkMAAAAAIUlDAAAAACFIQwAAAAAhZUMAAAAAIWZDAAAAACFnQwAAAAAhaEMAAAAAIWlDAAAAACFqQQAha0MAAAAAIW1DAAAAACFuQwAAAAAhO0EAIUBBACFvQQAhEUMAAAAAIXBDAAAAACFxQwAAAAAhT0EAIXJB/wEhc0MAAAAAIXRDAAAAACF1QQAhdkEAIQhDAAAAACE3QwAAAAAhd0MAAAAAIXhBACF5QQAhekMAAAAAIXtDAAAAACF8QwAAAAAhfUIAIQ1DAAAAACF+QQAhf0EAITZDAAAAACGAAUMAAAAAIYEBQwAAAAAhggFDAAAAACGDAUEAIYQBQf8BIYUBQwAAAAAhhgFDAAAAACGHAUEBIQdBASEMQwAAwD8hQSBCIY0BQwAAgD8gP0MXt9E5lCI4IDggOFwbIjhDAACAPyA4QwAAgD9eGyI5IY4BQwAAwD8hjwEMIwtDAABAPyFPCyAnQQA6ABAgJ0IANwAIICdCADcAACAmQgA3AAAgJkIANwAIICZBADoAECAlQgA3AAAgJUIANwAIICVBADoAECACQgA3A9AGIAJCADcD2AYgAkIANwPgBiACIAIpAHA3A5AGIAIgAikAeDcDmAYgAiACKQCAATcDoAYgAiACKQCIATcDqAYgAiACKQCQATcDsAYgAiACKQCYATcDuAYgAiACKQCgATcDwAYgAiACKQCnATcAxwYgP0NI4fo+lCJBQwAAIEFgRQ0WQgAhCyBBQwAAIEEgOEMAYOpFlCJCIEJDAAAgQV0bIkIgQiBBXhtD2w9JQJQgP5UQw4GAgAAhQSACQgA3A/AGIAJCADcD6AYgQSBBQwAAgD8gQSBBQ6uqqj+SlEMAAIA/kpUimwGUIpwBlCGdAUMAAIA/ID9DbxIDOpQiQSBBIEFcGyJBQwAAgD8gQUMAAIA/XhshcSA+Q5r5mUOUID+VIWUgPkPMTORDlCA/lSFmID5DmpkKRJQgP5UhZyA+QzQDRESUID+VIWggPkMAgEpElCA/lSFpID5DAACWRJQgP5UhakMAAAAAIVkgP0MAAAAAlPwBIXJEAAAAAAAAAAAhWkOamZk/IT5BBiF2QwAAAD8hdUMzM7M+IXRB/wEhc0ECIVxBASFrQQAhRkMzM5PAQ28SgzogNyA3IDdcGyJBQ28SgzogQUNvEoM6XhsgP5SVEKOBgIAAIXBDAAAAACFeQwAAAAAhX0MAAAAAIWBDAAAAACFhQQAhYkMAAAAAIWNBACFkQwAAAAAhbEMAAAAAIW1DAAAAACFuQwAAAAAhO0EAIUBBACFvQQEhEQwdC0EAIUYgG0EAOgAQIBtCADcACCAbQgA3AAAgGkIANwAAIBpCADcACCAaQQA6ABAgGUIANwAAIBlCADcACCAZQQA6ABAgAkIANwP4BSACQgA3A4AGIAJCADcDiAYgAiACKQDAAzcDuAUgAiACKQDIAzcDwAUgAiACKQDQAzcDyAUgAiACKQDYAzcD0AUgAiACKQDgAzcD2AUgAiACKQDoAzcD4AUgAiACKQDwAzcD6AUgAiACKQD3AzcA7wVDAACAPyGBAUMAAIA/ID9DppvEOpQiQSBBIEFcGyJBQwAAgD8gQUMAAIA/XhshbiA5Q5qZmT6UITsgPkMAoMRElCA/lSF3ID5DAGCFRJQgP5UheCA+QwDAG0SUID+VIX0gPkMAANxDlCA/lSGCAUMAAAAAIVkgP0MAAAAAlPwBIUBDAABAwCA/Q28SgzqUlRCjgYCAACFBRAAAAAAAAAAAIVpDzcyMPyE+QQEhb0H/ASFcQzMzk8BDbxKDOiA4IDggOFwbIkJDbxKDOiBCQ28SgzpeGyA/lJUQo4GAgAAhbUMAAAAAIV5DAAAAACFfQwAAAAAhYEMAAAAAIWFBACFiQwAAAAAhY0MAAAAAIU1DAAAAACFMQwAAAAAhS0MAAAAAIUpDAAAAACFJQwAAAAAhSEMAAAAAIWVDAAAAACFmQwAAAAAhZ0MAAAAAIWhDAAAAACFpQwAAAAAhakEAIWtDAAAAACFsQQAhEUMAAAAAIXBDAAAAACFxQwAAAAAhT0EAIXJB/wEhc0MAAAAAIXRDAAAAACF1QQAhdkEBIQhBACF5QQEhekMAAAAAIXsgOkMzMzM/lEOamRk+kiI3IXwgQbwiZK0iCyENQwAAAAAhfkEBIX9BASE2QwAAAAAhgAEMHQtBACFGIBtBADoAEEIAIQsgG0IANwAIIBtCADcAACAaQgA3AAAgGkIANwAIIBpBADoAECAZQgA3AAAgGUIANwAIIBlBADoAECACQgA3A/gFIAJCADcDgAYgAkIANwOIBiACIAIpAMADNwO4BSACIAIpAMgDNwPABSACIAIpANADNwPIBSACIAIpANgDNwPQBSACIAIpAOADNwPYBSACIAIpAOgDNwPgBSACIAIpAPADNwPoBSACIAIpAPcDNwDvBUMAAIA/IYEBQwAAgD8gP0Omm8Q6lCJBIEEgQVwbIkFDAACAPyBBQwAAgD9eGyFuIDlDzcxMP5QhOyA6QwAAAD+UIXwgPkMAAERDlCI+ID+VIYIBID5DAICbQ5RDAABEQ5UgP5UhfUMAAAAAIVkgP0MAAAAAlPwBIUBDAABAwCA/QylcDz2UlRCjgYCAALwiZK0hDUQAAAAAAAAAACFaQ5qZmT8hPkHMmbP2AyGEAUMK1yM9IYABQ8zMzD4hfkEBIW9B/wEhXEMzM5PAQ28SgzogOCA4IDhcGyJBQ28SgzogQUNvEoM6XhsgP5SVEKOBgIAAIW0MAQtBACFGIBtBADoAEEIAIQsgG0IANwAIIBtCADcAACAaQgA3AAAgGkIANwAIIBpBADoAECAZQgA3AAAgGUIANwAIIBlBADoAECACQgA3A/gFIAJCADcDgAYgAkIANwOIBiACIAIpAMADNwO4BSACIAIpAMgDNwPABSACIAIpANADNwPIBSACIAIpANgDNwPQBSACIAIpAOADNwPYBSACIAIpAOgDNwPgBSACIAIpAPADNwPoBSACIAIpAPcDNwDvBUMAAIA/IYEBQwAAgD8gP0Omm8Q6lCJBIEEgQVwbIkFDAACAPyBBQwAAgD9eGyFuIDlDMzNzP5QhOyA6QwAAAD+UIXwgPkMAAMRClCI+ID+VIYIBID5DAADAP5QgP5UhfUMAAAAAIVkgP0MAAAAAlPwBIUBDAABAwCA/QylcDz2UlRCjgYCAALwiZK0hDUQAAAAAAAAAACFaQ2Zmpj8hPkGas+b8AyGEAUPNzEw9IYABQ8zMzD4hfkEBIW9B/wEhXEMzM5PAQ28SgzogOCA4IDhcGyJBQ28SgzogQUNvEoM6XhsgP5SVEKOBgIAAIW0LQwAAAAAhXkMAAAAAIV9DAAAAACFgQwAAAAAhYUEAIWJDAAAAACFjQwAAAAAhTUMAAAAAIUxDAAAAACFLQwAAAAAhSkMAAAAAIUlDAAAAACFIQwAAAAAhZUMAAAAAIWZDAAAAACFnQwAAAAAhaEMAAAAAIWlDAAAAACFqQQAha0MAAAAAIWxBACERQwAAAAAhcEMAAAAAIXFDAAAAACFPQQAhckH/ASFzQwAAAAAhdEMAAAAAIXVBACF2QQAhCEMAAAAAITdDAAAAACF3QwAAAAAheEEAIXlBASF6QwAAAAAhe0EAIX9BASE2QwAAAAAhgwEMGwsgG0EAOgAQIBtCADcACCAbQgA3AAAgGkIANwAAIBpCADcACCAaQQA6ABAgGUIANwAAIBlCADcACCAZQQA6ABAgAkIANwP4BSACQgA3A4AGIAJCADcDiAYgAiACKQDAAzcDuAUgAiACKQDIAzcDwAUgAiACKQDQAzcDyAUgAiACKQDYAzcD0AUgAiACKQDgAzcD2AUgAiACKQDoAzcD4AUgAiACKQDwAzcD6AUgAiACKQD3AzcA7wUgP0NI4fo+lCJBQwAAIEFgRQ0SQgAhCyBBQwAAekUgQUMAAHpFXRtD2w9JQJQgP5UQw4GAgAAhQSACQgA3A+AHIAJCADcD2AcgAkIANwPQB0MAAIA/IYEBQwAAgD8gP0MXt1E5lCJCIEIgQlwbIkJDAACAPyBCQwAAgD9eGyGOAUMAAIA/ID9DppvEOpQiQiBCIEJcGyJCQwAAgD8gQkMAAIA/XhshbkOrqqo/IWwgQSBBQwAAgD8gQSBBQ6uqqj+SlEMAAIA/kpUiWZQiXpQhXyA5Q83MzD2UIY8BIDpDmpkZP5QhfCA5Q5qZGT+UITsgPkMAQLVElCA/lSGCASA+QwCwdEWUID+VIX1DAAAAACFgID9DAAAAAJT8ASFAQwAAQMAgP0MK16M7lJUQo4GAgAC8IWRDAABAwCA/Q28SgzqUlRCjgYCAALytIQ1EAAAAAAAAAAAhWkMzM7M/IT5BwJmz6gMhhAFBASFiQf8BIVxBACFrQQIhRkMzM5PAID9DbxKDO5SVEKOBgIAAIY0BQzMzk8BDbxKDOiA4IDggOFwbIkFDbxKDOiBBQ28SgzpeGyA/lJUQo4GAgAAhbUMAAAAAIWFDAAAAACFjQwAAAAAhTUMAAAAAIUxDAAAAACFLQwAAAAAhSkMAAAAAIUlDAAAAACFIQwAAAAAhZUMAAAAAIWZDAAAAACFnQwAAAAAhaEMAAAAAIWlDAAAAACFqQQEhb0EAIRFDAAAAACFwQwAAAAAhcUMAAAAAIU9BACFyQf8BIXNDAAAAACF0QwAAAAAhdUEAIXZBACEIQwAAAAAhN0MAAAAAIXdDAAAAACF4QQAheUEBIXpDAAAAACF7QwAAAAAhfkEAIX9BASE2QwAAAAAhgAEMFQsgP0NI4fo+lCJBQwAAIEFgRQ0SQgAhCyBBQwAAIEFDAKCMRiA6QwAAAD+SID5DACDLRZSUIj4gPiA+XBsiPkMAoIxGID5DAKCMRl0bIj4gPkMAACBBXRsiPiA+IEFeG0PbD0lAlCA/lRDDgYCAACE+IEFDAIA7RSBBQwCAO0VdG0PbD0lAlCA/lRDDgYCAACFBIAJCADcD8AcgAkIANwPoByACQgA3A9AHIAJCADcD2AcgAkIANwPgB0NVVVU/IWwgPiA+QwAAgD8gPiA+Q1VVVT+SlEMAAIA/kpUiWZQiXpQhX0MAAIA/ID9DbxKDO5QiPiA+ID5cGyI+QwAAgD8gPkMAAIA/XhshjgEgQSBBQwAAgD8gQSBBQ6uqqj+SlEMAAIA/kpUingGUIp8BlCGgASA5Q2ZmZj+UIY8BQwAAAAAhYCA/QwAAAACU/AEhkAFEAAAAAAAAAAAhWkOamZk/IT5BAiGFAUH/ASFcQQAhZEEBIUZDMzOTwENvEoM6IDggOCA4XBsiQUNvEoM6IEFDbxKDOl4bID+UlRCjgYCAACGNAUMAAAAAIWFBASFiQwAAAAAhY0MAAAAAIU1DAAAAACFMQwAAAAAhS0MAAAAAIUpDAAAAACFJQwAAAAAhSEMAAAAAIWVDAAAAACFmQwAAAAAhZ0MAAAAAIWhDAAAAACFpQwAAAAAhakEAIWtDAAAAACFtQwAAAAAhbkMAAAAAITtBACFAQQAhb0EAIRFDAAAAACFwQwAAAAAhcUMAAAAAIU9BACFyQf8BIXNDAAAAACF0QwAAAAAhdUEAIXZBACEIQwAAAAAhN0MAAAAAIXdDAAAAACF4QQAheUEAIXpDAAAAACF7QwAAAAAhfEMAAAAAIX1CACENQwAAAAAhfkEAIX9BACE2QwAAAAAhgAFDAAAAACGBAUMAAAAAIYIBQwAAAAAhgwFBACGEAUMAAAAAIYYBQwAAAAAhhwFBASEHDAELID9DSOH6PpQiQUMAACBBYEUNEkIAIQsgQUMAACBBQwAAekYgOkMAgLtFlEMAgLtEkiA+lCI+ID4gPlwbIj5DAAB6RiA+QwAAekZdGyI+ID5DAAAgQV0bIj4gPiBBXhtD2w9JQJQgP5UQw4GAgAAhPiACQgA3A+AHIAJCADcD2AcgAkIANwPQB0Orqqo/IWwgPiA+QwAAgD8gPiA+Q6uqqj+SlEMAAIA/kpUiWZQiXpQhX0MAAIA/ID9DbxIDPJQiPiA+ID5cGyI+QwAAgD8gPkMAAIA/XhshjgEgOUNmZiY/lCGPAUMAAAAAITcgP0MAAAAAlPwBIZABRAAAAAAAAAAAIVpDmpmZPyE+QQEhB0H/ASFcQQAhQEECIUZDMzOTwENvEoM6IDggOCA4XBsiQUNvEoM6IEFDbxKDOl4bID+UlRCjgYCAACGNAUMAAAAAIWBDAAAAACFhQQEhYkMAAAAAIWNBACFkQwAAAAAhTUMAAAAAIUxDAAAAACFLQwAAAAAhSkMAAAAAIUlDAAAAACFIQwAAAAAhZUMAAAAAIWZDAAAAACFnQwAAAAAhaEMAAAAAIWlDAAAAACFqQQAha0MAAAAAIW1DAAAAACFuQwAAAAAhO0EAIW9BACERQwAAAAAhcEMAAAAAIXFDAAAAACFPQQAhckH/ASFzQwAAAAAhdEMAAAAAIXVBACF2QQAhCEMAAAAAIXdDAAAAACF4QQAheUEAIXpDAAAAACF7QwAAAAAhfEMAAAAAIX1CACENQwAAAAAhfkEAIX9BACE2QwAAAAAhgAFDAAAAACGBAUMAAAAAIYIBQwAAAAAhgwFBACGEAUH/ASGFAUMAAAAAIYYBQwAAAAAhhwELQQAhDEMAAAAAIYgBQwAAAAAhiQFDAAAAACFBQQAhigFDAAAAACFCQwAAAAAhOUEAIYsBQQAhjAEMGQsgRyBGQaiXwIAAEI6AgIAAAAsgAkGAgICNBDYC+AYgAiBQOALoByACQYGAgIAArUIghiILIAJB6AdqrYQ3A8gDIAIgCyACQfgGaq2ENwPAA0HtgcCAACACQcADakHYisCAABCJgICAAAALIAJBgICAiQQ2AvgGIAIgQTgC6AcgAkGBgICAAK1CIIYiCyACQegHaq2ENwPIAyACIAsgAkH4BmqthDcDwANB7YHAgAAgAkHAA2pB2IrAgAAQiYCAgAAACyACQYCAgIkENgL4BiACIEE4AugHIAJBgYCAgACtQiCGIgsgAkHoB2qthDcDyAMgAiALIAJB+AZqrYQ3A8ADQe2BwIAAIAJBwANqQdiKwIAAEImAgIAAAAsgAkGAgICJBDYC+AYgAiBBOALoByACQYGAgIAArUIghiILIAJB6AdqrYQ3A8gDIAIgCyACQfgGaq2ENwPAA0HtgcCAACACQcADakHYisCAABCJgICAAAALIAJBgICAiQQ2AvgGIAIgQTgC6AcgAkGBgICAAK1CIIYiCyACQegHaq2ENwPIAyACIAsgAkH4BmqthDcDwANB7YHAgAAgAkHAA2pB2IrAgAAQiYCAgAAACyACQYCAgIkENgL4BiACID44AugHIAJBgYCAgACtQiCGIgsgAkHoB2qthDcDyAMgAiALIAJB+AZqrYQ3A8ADQe2BwIAAIAJBwANqQdiKwIAAEImAgIAAAAsgAkGAgICJBDYC+AYgAiBBOALoByACQYGAgIAArUIghiILIAJB6AdqrYQ3A8gDIAIgCyACQfgGaq2ENwPAA0HtgcCAACACQcADakHYisCAABCJgICAAAALIAJBgICAiQQ2AvgGIAIgQTgC6AcgAkGBgICAAK1CIIYiCyACQegHaq2ENwPIAyACIAsgAkH4BmqthDcDwANB7YHAgAAgAkHAA2pB2IrAgAAQiYCAgAAACyACQYCAgIkENgL4BiACIEE4AugHIAJBgYCAgACtQiCGIgsgAkHoB2qthDcDyAMgAiALIAJB+AZqrYQ3A8ADQe2BwIAAIAJBwANqQdiKwIAAEImAgIAAAAsgAkGAgICJBDYC+AYgAiBBOALoByACQYGAgIAArUIghiILIAJB6AdqrYQ3A8gDIAIgCyACQfgGaq2ENwPAA0HtgcCAACACQcADakHYisCAABCJgICAAAALIAJBgICAiQQ2AvgGIAIgQTgC6AcgAkGBgICAAK1CIIYiCyACQegHaq2ENwPIAyACIAsgAkH4BmqthDcDwANB7YHAgAAgAkHAA2pB2IrAgAAQiYCAgAAACyACQYCAgIkENgL4BiACIEE4AugHIAJBgYCAgACtQiCGIgsgAkHoB2qthDcDyAMgAiALIAJB+AZqrYQ3A8ADQe2BwIAAIAJBwANqQdiKwIAAEImAgIAAAAsgAkGAgICJBDYC+AYgAiA+OALoByACQYGAgIAArUIghiILIAJB6AdqrYQ3A8gDIAIgCyACQfgGaq2ENwPAA0HtgcCAACACQcADakHYisCAABCJgICAAAALIAJBgICAiQQ2AvgGIAIgQTgC6AcgAkGBgICAAK1CIIYiCyACQegHaq2ENwPIAyACIAsgAkH4BmqthDcDwANB7YHAgAAgAkHAA2pB2IrAgAAQiYCAgAAACyACQYCAgIkENgL4BiACIEE4AugHIAJBgYCAgACtQiCGIgsgAkHoB2qthDcDyAMgAiALIAJB+AZqrYQ3A8ADQe2BwIAAIAJBwANqQdiKwIAAEImAgIAAAAsgAkGAgICJBDYC+AYgAiBBOALoByACQYGAgIAArUIghiILIAJB6AdqrYQ3A8gDIAIgCyACQfgGaq2ENwPAA0HtgcCAACACQcADakHYisCAABCJgICAAAALIAJBgICAiQQ2AvgGIAIgQTgC6AcgAkGBgICAAK1CIIYiCyACQegHaq2ENwPIAyACIAsgAkH4BmqthDcDwANB7YHAgAAgAkHAA2pB2IrAgAAQiYCAgAAAC0MAAAAAIYMBC0H/ASGFAQtDAAAAACGGAUMAAAAAIYcBQQEhB0EAIQxDAAAAACGIAUMAAAAAIYkBQwAAAAAhQUEAIYoBQwAAAAAhQkMAAAAAITlBACGLAUEAIYwBIEAhkAEMBAtBACEIQwAAAAAhN0MAAAAAIXdDAAAAACF4QQAheUEAIXpDAAAAACF7QwAAAAAhfEMAAAAAIX1CACENQwAAAAAhfkEAIX9BACE2QwAAAAAhgAFDAAAAACGBAUMAAAAAIYIBC0MAAAAAIYMBQQAhhAELQf8BIYUBC0MAAAAAIYYBQwAAAAAhhwFBACEHQQAhDEMAAAAAIYgBQwAAAAAhiQFDAAAAACFBQQAhigFDAAAAACFCQwAAAAAhOUEAIYsBQQAhjAFDAAAAACGNAUMAAAAAIY4BQwAAAAAhjwFBACGQAQtDAAAAACGRAUMAAAAAIZIBQQAhkwFDAAAAACGUAQtBACEJQwAAAAAhXUMAAAAAIVZDAAAAACE6QQAhR0H/ASGVAUEAIZYBRAAAAAAAAAAAIVsLIAAtALgjIaEBQwAAgD9DAACAvyA8IDxDAACAv10bIjggOEMAAIA/XhtDAACAP5JD2w9JQJRDAACAPpQiOBDAgYCAACE8IDgQrIGAgAAhogFDAACAPyE4AkAgPkMAAAAAXkUNAEMAAIA/QwAAgD9DAACAvyA+ID4gPpQiOCA4IDhDAAC9Q5KUQwBah0aSlEPA9wNIkpQgOCA4IDhDAADgQZRDAOBERZKUQwCic0eSlEPA9wNIkpUiOCA4QwAAgL9dGyI4IDhDAACAP14blSE4CyAEIAAoAggiCk8NAiAAKAIEIENqIERBqAlsaiIKIFA4AiQgCiBROAIgIAogWjkDGCAKIFs5AxAgCkIANwMIIAogPEMAAIA/Q/MEtT8goQFBAksbIqMBlDgCBCAKIKIBIKMBlDgCACAKIAIpA8ADNwMoIAogAikDyAM3AzAgCiAJNgJsIAoglgE2AmggCiCVAToAZCAKQf601vwDNgJgIApC6LS7/ZPl2Z0/NwNYIAogWDgCVCAKQs2Zs/LTmbPGPzcCTCAKIFI4AkggCiBXOAJEIAogVTgCQCAKIFQ4AjwgCiBTOAI4IAogRzYCiAEgCiA6OAKMASAKIFY4ApABIAogXTgClAEgCkEAOgCYASAKIAIpA9gINwOAASAKIAIpA9AINwN4IAogAikDyAg3A3AgCiACKQOICDcAmQEgCiACKQOQCDcAoQEgCiACKQOYCDcAqQEgCiACKQOgCDcAsQEgCiACKQOoCDcAuQEgCiACKQOwCDcAwQEgCiACKQO4CDcAyQEgCiACKQC/CDcA0AEgCiCGATgCmAIgCiCHATgClAIgCiCRATgCkAIgCiCSATgCjAIgCiA/OAKIAiAKIEVBAXJBte/J5AJsNgKEAiAKQoCAgPyDgIDAPzcC/AEgCkMAAIBAQwAAAAAgPSA9QwAAAABdGyI/ID9DAACAQF4bIE6UOAL4ASAKIDg4AvQBIAogPjgC8AEgCiCTATYC7AEgCiCUATgC6AEgCiA7OALkASAKQQA2AuABIAogCToA3AEgCkEAOwHYASAKIAIpA/gHNwKcAiAKIAIpA4AINwKkAiAKIKABOAK8AiAKIJ8BOAK4AiAKIJ4BOAK0AiAKQavVqv0DNgKwAiAKQQA6AKwCIAogAikD8Ac3A8gCIAogAikD6Ac3A8ACIAogYjYC+AIgCiBGOgD0AiAKQgA3AuwCIAogYTgC6AIgCiBgOALkAiAKIF84AuACIAogXjgC3AIgCiBZOALYAiAKIGw4AtQCIAoghQE6ANACIAogAikD4Ac3AowDIAogAikD2Ac3AoQDIAogAikD0Ac3AvwCIApB/wE6AIwEIAogBzoA6AMgCkEAOwHkAyAKIAw6AOADIAogiAE4AtwDIAogiQE4AtgDIAogQTgC1AMgCiCKATYC0AMgCiAMOgDMAyAKIEI4AsgDIAogOTgCxAMgCiBBOALAAyAKIIsBNgK8AyAKIAw6ALgDIAogQjgCtAMgCiA5OAKwAyAKIEE4AqwDIAogjAE2AqgDIAogBzoApAMgCiCNATgCoAMgCiCOATgCnAMgCiCPATgCmAMgCiCQATYClAMgCiACKADMBzYArQQgCiACKQDEBzcApQQgCiACKQC8BzcAnQQgCiACKQC0BzcAlQQgCiACKQCsBzcAjQQgCiACKQCNBzcAsQQgCiACKQCVBzcAuQQgCiACKQCdBzcAwQQgCiACKQCkBzcAyAQgCkHQBGogAkGAAmpB0AD8CgAAIAogmgE4AoAHIAogmQE4AvwGIAogmAE4AvgGIAoglwE4AvQGIAogdDgC8AYgCiB1OALsBiAKIHY2AugGIAogajgC5AYgCiBpOALgBiAKIGg4AtwGIAogZzgC2AYgCiBmOALUBiAKIGU4AtAGIAogSDgCzAYgCiBJOALIBiAKIEo4AsQGIAogSzgCwAYgCiBMOAK8BiAKIE04ArgGIApBADoAtQYgCiAIOgC0BiAKQQA2ArAGIAogNzgCrAYgCiB3OAKoBiAKQQA2AqQGIAogCzcCnAYgCkIANwKUBiAKQQA6AJEGIAogCDoAkAYgCkEANgKMBiAKIDc4AogGIAogeDgChAYgCkEANgKABiAKIAs3A/gFIApCADcD8AUgCiB5OgDtBSAKIHo6AOwFIAogezgC6AUgCiB8OALkBSAKIH04AuAFIApBADYC3AUgCiANNwLUBSAKQQA2AtAFIAogfjgCzAUgCiB/OgDJBSAKIDY6AMgFIAoggAE4AsQFIAoggQE4AsAFIAogggE4ArwFIApBADYCuAUgCiBjOAK0BSAKIGQ2ArAFIAoggwE4AqwFIAoghAE2AqgFIApBADoApAUgCkEAOwGgBSAKIJsBOAKcByAKIJwBOAKgByAKIJ0BOAKkByAKQavVqv0DNgKYByAKIHM6AJQHIAogazYCvAcgCiBcOgC4ByAKIAIpA4AHNwKMByAKIAIpA/gGNwKEByAKIAIpA+gGNwOoByAKIAIpA/AGNwOwByAKIAIpA9AGNwPAByAKIAIpA9gGNwPIByAKIAIpA+AGNwPQByAKIBE6AOgHIAogcDgC5AcgCiBxOALgByAKIE84AtwHIAogcjYC2AcgCiACKQOQBjcA6QcgCiACKQOYBjcA8QcgCiACKQOgBjcA+QcgCiACKQOoBjcAgQggCiACKQOwBjcAiQggCiACKQO4BjcAkQggCiACKQPABjcAmQggCiACKQDHBjcAoAggCiBvNgKwCCAKIBE6AKwIIApBADsBqAggCiACKQOIBjcCxAggCiACKQOABjcCvAggCiACKQP4BTcCtAggCkEAOgDcCCAKIG04AtgIIAogbjgC1AggCiA7OALQCCAKIEA2AswIIAogAikA7wU3AJQJIAogAikD6AU3AI0JIAogAikD4AU3AIUJIAogAikD2AU3AP0IIAogAikD0AU3APUIIAogAikDyAU3AO0IIAogAikDwAU3AOUIIAogAikDuAU3AN0IIApBAToAoAkgCkEAOwGcCQsgNEEBaiI0IANHDQALIAMhNCASITYMAQsgBCAKQfCTwIAAEI6AgIAAAAsCQAJAAkACQCA2QQF0IgogM0EBdCIMSQ0AIAogDGsif0ECdCF2IDNBA3QhbwJAIAogDEYiaw0AIAAgb2ohCgJAIHZFIgwNACAKQbALakEAIHb8CwALIAwNACAKQbATakEAIHb8CwALIBMgdmoheSAAKAIEImIgACgCCEHQEmxqIXJBACF6QQANAgwBCyAMIApBgAJBgJTAgAAQloCAgAAAC0EBIQoMAQtBACEKCwJAAkACQAJAAkACQAJAA0ACQAJAAkACQAJAAkACQCAKDgIAAQELIHogYkYNBSB6QaAJaiEKIHpBqAlqIgwheiAKLQAADQEMBAsgYiFDA0AgQyByRg0NIENB0BJqIWIgQ0GgCWotAAANAiBDQcgSaiEKIGIhQyAKLQAARQ0ACyBiQbBtakGoCWohQyBiIXoMAgsgDEHYdmohQyAMIXoMAQsgQ0GoCWohegsgACgCLCGEASAAKAIoIYUBAkAgaw0AIHZFDQAgE0EAIHb8CwALIEMoAuABIXMCQCBDLQDIBUEBRw0AIENBqAVqIUYgAiBDQbAIaiJHQfAA/AoAAAJAAkAgQy0A7AVBAUYNAEEkIQoMAQsCQCBDLQCQBkEBRg0AQcgAIQoMAQtBkAFB7AAgQy0AtAYbIQoLIEMqAuQBIT4gAkHwAGogRkGQAfwKAAACQCBrDQBDAACAPyA+lUMAAAAAID5DAAAAAF4bITkgAkHwAGogCmohCUEAIQggAi0AbCEHIAItAG0hQCACKAIUITMgAioCDCE8IAIqAgghOiACKgIYIT0gAioCECE3IAIoAgQhBCACKAIAIUUgEyERA0ACQAJAAkACQAJAAkAgBCBFTw0AIARBA0sNAyAIIHNqIDIgBEEUbGoiCigCAEkNACACIAotABAiDDoAbSACQQE6AGwgBEEBaiEEIAoqAgwhPSAKKgIIIT4gCioCBCE3IAwNASA3IDqTID6VITxBACFADAQLAkAgByBAcUEBcUUNACAzIQoMAgsgB0EBcQ0DQwAAAAAgOiA9lCI+ID6LQwjlPB5dGyE6QQAhBwwEC0MAAIA/QwAAgL8gPpUQo4GAgACTITwgPkMAAKBAlPwBIQoLIAogCkEAR2shMyA6IDcgOpMgPJSSITpBASFAAkAgCkEBTQ0AQQEhBwwDC0EAIQcgAkEAOgBsDAILIARBBEHYlcCAABCOgICAAAALIDogPJIhOgJAAkAgPEMAAAAAYEUNACA6IDdgDQELQQEhByA8QwAAAABdRQ0BIDogN19FDQELQQAhByACQQA6AGwgNyE6CyA5IDqUITggAkHwAGohCkMAAAAAIT8DQCAKQwAAAAAgCioCACI+IApBCGoqAgCUIkEgQYtDCOU8Hl0bOAIAIApBBGoiDEMAAAAAIAwqAgAiQSAKQQxqKgIAlCJCIEKLQwjlPB5dGzgCACAKQRBqIgwgDCoCAENmZuY+IEEgPkMAAIA/kpIgOCAKQRxqKgIAlEMAAIA/kpQgCkEUaioCAJQiPiA+ID5cGyI+Q2Zm5j4gPkNmZuY+XRuSIj5DAACAv5IgPiA+QwAAgD9gGyI+OAIAIApBGGoqAgAhQQJAAkAgCkEhai0AAA0AAkACQCA+Q9sPyUCUIj5D2w/JwJIgPiA+Q9sPSUBeGyI+Q9sPyT9eDQAgPkPbD8m/XUUNAUPbD0nAID6TIT4MAQtD2w9JQCA+kyE+CyA+QwAAgD8gPiA+lCJCQ6uqKj4gQiBCQwCAncWVQ4mICDySlJOUk5QhPgwBCyA+QwAAAL+Si0MAAIDAlEMAAIA/kiE+CyA/IEEgPpSSIT8gCkEkaiIKIAlHDQALIBEgOiA/lCARKgIAkjgCACAIQQFqIQggEUEEaiIRIHlHDQALIAIgPTgCGCACIDc4AhAgAiAzNgIUIAIgPDgCDCACIDo4AgggAiAENgIECyBHIAJB8AD8CgAAIEYgAkHwAGpBkAH8CgAACyBDQbACaiFkIEMoAoQCIQxBACEKQQEhRANAAkAgZCAKQbwBbGoiXC0AuAFBAUcNACACQYACaiBcQbwB/AoAAAJAIGsNACACLQC0AyEEIAItALUDIUUgAigC3AIhRyACKgLUAiFIIAIqAtACIT8gAioC4AIhXyACKgLYAiFKIAIoAswCIQkgAioCmAIhOSACKgKcAiE9IAIqArwCIUEgAioCwAIhQiACKALIAiEzIAIqAoACIWAgAioCjAIhWSACKgKUAiFhIAIqApACIU4gAioCiAIhSyACKgKEAiFdIAItAKACIUAgAioCpAIhViACLQDEAiFGIAIqArACIU0gAioCuAIhXiACKgK0AiFJIAIqAqwCITsgAioCqAIhTyBzIREgdiEHIBMhCANAIAghCiBPIEGUIDsgDEENdCAMcyIMQRF2IAxzIgxBBXQgDHMiDLNDAACAL5QiPiA+kkMAAIC/kiI6IEKTIjiUkiE+AkAgSUMAAAAAXkUNACBeQwAAgD9DAACAv0MAAKBAQwAAoMAgSSA+lCI+ID5DAACgwF0bIj4gPkMAAKBAXhsiPiA+ID6UIj4gPiA+QwAAvUOSlEMAWodGkpRDwPcDSJKUID4gPiA+QwAA4EGUQwDgREWSlEMAonNHkpRDwPcDSJKVIj4gPkMAAIC/XRsiPiA+QwAAgD9eG5QhPgsgQiA7IEGUkiBNIDiUkiI4ITcCQAJAAkAgRg4DAgEAAgsgOiBWID6UkyA4kyE3DAELIFYgPpQhNwsCQAJAIEBB/wFHDQAgNyE6DAELIF0gOZQgSyA3ID2TIkyUkiE8AkAgTkMAAAAAXkUNACBhQwAAgD9DAACAv0MAAKBAQwAAoMAgTiA8lCI6IDpDAACgwF0bIjogOkMAAKBAXhsiOiA6IDqUIjogOiA6QwAAvUOSlEMAWodGkpRDwPcDSJKUIDogOiA6QwAA4EGUQwDgREWSlEMAonNHkpRDwPcDSJKVIjogOkMAAIC/XRsiOiA6QwAAgD9eG5QhPAtDAAAAACA9IEsgOZSSIFkgTJSSIjogOpIgPZMiPSA9i0MI5TweXRshPUMAAAAAIDwgPJIgOZMiOSA5i0MI5TweXRshOQJAAkAgQA4DAgEAAgsgNyBgIDyUkyA6kyE6DAELIGAgPJQhOgsCQAJAAkACQAJAAkAgCSAzTw0AIAlBA0sNAyARIDEgCUEUbGoiCCgCAEkNACACIAgtABAiBDoAtQMgAkEBOgC0AyAJQQFqIQkgCCoCDCFfIAgqAgghPCAIKgIEIUogBA0BIEogP5MgPJUhSEEAIUUMBAsCQCAEIEVxQQFxRQ0AIEchBAwCCyAEQQFxDQNDAAAAACA/IF+UIj8gP4tDCOU8Hl0bIT9BACEEDAQLQwAAgD9DAACAvyA8lRCjgYCAAJMhSCA8QwAAoECU/AEhBAsgBCAEQQBHayFHID8gSiA/kyBIlJIhP0EBIUUCQCAEQQFNDQBBASEEDAMLQQAhBCACQQA6ALQDDAILIAlBBEHYlcCAABCOgICAAAALID8gSJIhPwJAAkAgSEMAAAAAYEUNACA/IEpgDQELQQEhBCBIQwAAAABdRQ0BID8gSl9FDQELQQAhBCACQQA6ALQDIEohPwsgCkEEaiEIQwAAAAAgOCA4kiBCkyJCIEKLQwjlPB5dGyFCQwAAAAAgPiA+kiBBkyI+ID6LQwjlPB5dGyFBIAogCioCACA6ID+UkjgCACARQQFqIREgB0F8aiIHDQALIAIgQTgCvAIgAiBCOALAAiACID04ApwCIAIgXzgC4AIgAiBKOALYAiACIAk2AswCIAIgOTgCmAIgAiBHNgLcAiACIEg4AtQCIAIgPzgC0AILIFwgAkGAAmpBvAH8CgAAC0EBIQogREEBcSEJQQAhRCAJDQALAkAgQy0ArAhBAUcNACACQcADaiBDQbgGaiJcQfgB/AoAAAJAIGsNAEMAAIA/IAIqAuwDIniTIX1DAACAPyACKgLoAyJ0kyF8QwAAgD8gAioC5AMibJMhe0MAAIA/IAIqAuADIl+TIXVDAACAPyACKgLcAyJLkyFtQwAAgD8gAioC2AMiOJMhYCACLQCwBSEIIAItALEFIUYgAigC2AQhRCACKgLQBCFJIAIqAswEIT4gAioC3AQhaCACKgLUBCFKIAIoAsgEIQkgAigCxAQhRyACKgKgBCFpIAIqAqwEIWEgAioCtAQhbiACKgKwBCFdIAIqAqgEIUwgAioCpAQhYyACLQDABCFFIAIqAvgDIVYgAioC/AMhaiACKgKIBCFlIAIqApAEIXAgAioCjAQhXiACKgKEBCFNIAIqAoAEIWYgAi0AnAQhMyACKgL0AyFZIAIqArgEITogAioCvAQhPCACKgKUBCE3IAIqApgEITkgAioC1AMhdyACKgLQAyFxIAIqAswDIWcgAioCyAMhTiACKgLEAyE7IAIqAsADIT8gAigC8AMiBEEGRyFkIHYhQCBzIREgEyEHA0AgByEKAkACQAJAAkACQAJAIAQNAEMAAAAAIUEMAQsgP0MAAAA/QwAAAL8gP0MAAAA/XSIHG5IhQQJAAkAgPyA4XQ0AQwAAAAAhQiA/IGBeRQ0BID9DAACAv5IgOJUiQiBCIEIgQpSSkkMAAIA/kiFCDAELID8gOJUiQiBCkiBCIEKUk0MAAIC/kiFCCwJAAkAgQSA4XQ0AQwAAAAAhPSBBIGBeRQ0BIEFDAACAv5IgOJUiQSBBIEEgQZSSkkMAAIA/kiE9DAELIEEgOJUiQSBBkiBBIEGUk0MAAIC/kiE9CyA4ID+SIj9DAACAv5IgPyA/QwAAgD9gGyE/QwAAgD9DAACAvyAHGyBCkiA9kyFBIARBAUYNACA7QwAAAD9DAAAAvyA7QwAAAD9dIgcbkiFCAkACQCA7IEtdDQBDAAAAACE9IDsgbV5FDQEgO0MAAIC/kiBLlSI9ID0gPSA9lJKSQwAAgD+SIT0MAQsgOyBLlSI9ID2SID0gPZSTQwAAgL+SIT0LAkACQCBCIEtdDQBDAAAAACFIIEIgbV5FDQEgQkMAAIC/kiBLlSJCIEIgQiBClJKSQwAAgD+SIUgMAQsgQiBLlSJCIEKSIEIgQpSTQwAAgL+SIUgLIEsgO5IiQkMAAIC/kiBCIEJDAACAP2AbITsgQUMAAIA/QwAAgL8gBxsgPZIgSJOSIUEgBEECRg0AIE5DAAAAP0MAAAC/IE5DAAAAP10iBxuSIUICQAJAIE4gX10NAEMAAAAAIT0gTiB1XkUNASBOQwAAgL+SIF+VIj0gPSA9ID2UkpJDAACAP5IhPQwBCyBOIF+VIj0gPZIgPSA9lJNDAACAv5IhPQsCQAJAIEIgX10NAEMAAAAAIUggQiB1XkUNASBCQwAAgL+SIF+VIkIgQiBCIEKUkpJDAACAP5IhSAwBCyBCIF+VIkIgQpIgQiBClJNDAACAv5IhSAsgXyBOkiJCQwAAgL+SIEIgQkMAAIA/YBshTiBBQwAAgD9DAACAvyAHGyA9kiBIk5IhQSAEQQNGDQAgZ0MAAAA/QwAAAL8gZ0MAAAA/XSIHG5IhQgJAAkAgZyBsXQ0AQwAAAAAhPSBnIHteRQ0BIGdDAACAv5IgbJUiPSA9ID0gPZSSkkMAAIA/kiE9DAELIGcgbJUiPSA9kiA9ID2Uk0MAAIC/kiE9CwJAAkAgQiBsXQ0AQwAAAAAhSCBCIHteRQ0BIEJDAACAv5IgbJUiQiBCIEIgQpSSkkMAAIA/kiFIDAELIEIgbJUiQiBCkiBCIEKUk0MAAIC/kiFICyBsIGeSIkJDAACAv5IgQiBCQwAAgD9gGyFnIEFDAACAP0MAAIC/IAcbID2SIEiTkiFBIARBBEYNACBxQwAAAD9DAAAAvyBxQwAAAD9dIgcbkiFCAkACQCBxIHRdDQBDAAAAACE9IHEgfF5FDQEgcUMAAIC/kiB0lSI9ID0gPSA9lJKSQwAAgD+SIT0MAQsgcSB0lSI9ID2SID0gPZSTQwAAgL+SIT0LAkACQCBCIHRdDQBDAAAAACFIIEIgfF5FDQEgQkMAAIC/kiB0lSJCIEIgQiBClJKSQwAAgD+SIUgMAQsgQiB0lSJCIEKSIEIgQpSTQwAAgL+SIUgLIHQgcZIiQkMAAIC/kiBCIEJDAACAP2AbIXEgQUMAAIA/QwAAgL8gBxsgPZIgSJOSIUEgBEEFRg0AIHdDAAAAP0MAAAC/IHdDAAAAP10iBxuSIUICQAJAIHcgeF0NAEMAAAAAIT0gdyB9XkUNASB3QwAAgL+SIHiVIj0gPSA9ID2UkpJDAACAP5IhPQwBCyB3IHiVIj0gPZIgPSA9lJNDAACAv5IhPQsCQAJAIEIgeF0NAEMAAAAAIUggQiB9XkUNASBCQwAAgL+SIHiVIkIgQiBCIEKUkpJDAACAP5IhSAwBCyBCIHiVIkIgQpIgQiBClJNDAACAv5IhSAsgeCB3kiJCQwAAgL+SIEIgQkMAAIA/YBshdyBkDQEgQUMAAIA/QwAAgL8gBxsgPZIgSJOSIUELIAxBDXQgDHMiDEERdiAMcyIMQQV0IAxzIgyzQwAAgC+UIkIgQpJDAACAv5IhSCBZIEGUIT0CQAJAIDNB/wFHDQAgPSFBDAELIGYgN5QgTSA9IDmTIk+UkiFCAkAgXkMAAAAAXkUNACBwQwAAgD9DAACAv0MAAKBAQwAAoMAgXiBClCJBIEFDAACgwF0bIkEgQUMAAKBAXhsiQSBBIEGUIkEgQSBBQwAAvUOSlEMAWodGkpRDwPcDSJKUIEEgQSBBQwAA4EGUQwDgREWSlEMAonNHkpRDwPcDSJKVIkEgQUMAAIC/XRsiQSBBQwAAgD9eG5QhQgtDAAAAACA5IE0gN5SSIGUgT5SSIkEgQZIgOZMiOSA5i0MI5TweXRshOUMAAAAAIEIgQpIgN5MiNyA3i0MI5TweXRshNwJAAkAgMw4DAgEAAgsgPSBqIEKUkyBBkyFBDAELIGogQpQhQQsgViBIlCBBkiE9AkACQCBFQf8BRw0AID0hQQwBCyBjIDqUIEwgPSA8kyJIlJIhQgJAIF1DAAAAAF5FDQAgbkMAAIA/QwAAgL9DAACgQEMAAKDAIF0gQpQiQSBBQwAAoMBdGyJBIEFDAACgQF4bIkEgQSBBlCJBIEEgQUMAAL1DkpRDAFqHRpKUQ8D3A0iSlCBBIEEgQUMAAOBBlEMA4ERFkpRDAKJzR5KUQ8D3A0iSlSJBIEFDAACAv10bIkEgQUMAAIA/XhuUIUILQwAAAAAgPCBMIDqUkiBhIEiUkiJBIEGSIDyTIjwgPItDCOU8Hl0bITxDAAAAACBCIEKSIDqTIjogOotDCOU8Hl0bIToCQAJAIEUOAwIBAAILID0gaSBClJMgQZMhQQwBCyBpIEKUIUELAkACQAJAIAkgR08NACAJQQNLDQQgESAwIAlBFGxqIgcoAgBJDQAgAiAHLQAQIgg6ALEFIAJBAToAsAUgCUEBaiEJIAcqAgwhaCAHKgIIIUIgByoCBCFKIAgNASBKID6TIEKVIUlBACFGDAULAkAgCCBGcUEBcUUNACBEIQgMAgsgCEEBcQ0EQwAAAAAgPiBolCI+ID6LQwjlPB5dGyE+QQAhCAwFC0MAAIA/QwAAgL8gQpUQo4GAgACTIUkgQkMAAKBAlPwBIQgLIAggCEEAR2shRCA+IEogPpMgSZSSIT5BASFGAkAgCEEBTQ0AQQEhCAwEC0EAIQggAkEAOgCwBQwDCyACIGg4AtwEIAIgSjgC1AQgAiAJNgLIBCACIEQ2AtgEIAIgSTgC0AQgAiA+OALMBCACIDk4ApgEIAIgdzgC1AMgAiBxOALQAyACIGc4AswDIAIgTjgCyAMgAiA7OALEAyACID84AsADIAIgPDgCvAQgAiA3OAKUBCACIDo4ArgEQQZBBkGAksCAABCOgICAAAALIAIgaDgC3AQgAiBKOALUBCACIAk2AsgEIAIgRDYC2AQgAiBJOALQBCACID44AswEIAIgOTgCmAQgAiB3OALUAyACIHE4AtADIAIgZzgCzAMgAiBOOALIAyACIDs4AsQDIAIgPzgCwAMgAiA8OAK8BCACIDc4ApQEIAIgOjgCuAQgCUEEQdiVwIAAEI6AgIAAAAsgPiBJkiE+AkACQCBJQwAAAABgRQ0AID4gSmANAQtBASEIIElDAAAAAF1FDQEgPiBKX0UNAQtBACEIIAJBADoAsAUgSiE+CyAKQQRqIQcgCiAKKgIAIEEgPpSSOAIAIBFBAWohESBAQXxqIkANAAsgAiBoOALcBCACIEo4AtQEIAIgCTYCyAQgAiBENgLYBCACIEk4AtAEIAIgPjgCzAQgAiA5OAKYBCACIHc4AtQDIAIgcTgC0AMgAiBnOALMAyACIE44AsgDIAIgOzgCxAMgAiA/OALAAyACIDw4ArwEIAIgNzgClAQgAiA6OAK4BAsgXCACQcADakH4AfwKAAALIEMgDDYChAICQCBDKgLoASI3QwAAAABbDQAgQygC7AEhByBDKgKoAiE/IEMqAqQCIUECQCBrDQAgQy0ArAIhQCBDKgKgAiFIIEMqApwCITogQyoCmAIhOSBDKgKUAiE4IEMqApACIT0gQyoCjAIhOyB2IQkgcyEMIBMhEQNAIBEhCiA9IEGUIDggN0MAAAAAIAwgB0kbIjwgP5MiQpSSIT4CQCA6QwAAAABeRQ0AIEhDAACAP0MAAIC/QwAAoEBDAACgwCA6ID6UIj4gPkMAAKDAXRsiPiA+QwAAoEBeGyI+ID4gPpQiPiA+ID5DAAC9Q5KUQwBah0aSlEPA9wNIkpQgPiA+ID5DAADgQZRDAOBERZKUQwCic0eSlEPA9wNIkpUiPiA+QwAAgL9dGyI+ID5DAACAP14blCE+CyA/IDggQZSSIDkgQpSSIkIgQpIgP5MiP4tDCOU8Hl0hBCA+ID6SIEGTIkGLQwjlPB5dIQgCQAJAAkAgQA4DAgEAAgsgPCA7ID6UkyBCkyFCDAELIDsgPpQhQgsgCkEEaiERQwAAAAAgPyAEGyE/QwAAAAAgQSAIGyFBIAogQiAKKgIAkjgCACAMQQFqIQwgCUF8aiIJDQALCyBDID84AqgCIEMgQTgCpAIgcyB/aiBDKgKIAkNvEgM7lPwBIAdqTQ0AIENBADYC6AELAkAgQy0A3AFBAUcNACBDKAJoIgoghAFPDQQgaw0AIENBiAFqIUcghQEgCkEMbGoiDCgCCCIRQX9qIQogDCgCBCEHIEMrAxghpAEgQysDCCFaIHYhCCBzIQQgEyEMA0ACQAJAIBFBBEkNACBaIKQBZg0AQQAgWvwDIglBf2oiQCAKIEAgCkkbIEBBAEgbIkUgEU8NCEEAIAkgCiAJIApJGyAJQQBIGyIzIBFPDQlBACAJQQFqIkAgCiBAIApJGyBAQQBIGyJGIBFPDQpBACAJQQJqIkAgCiBAIApJGyBAQQBIGyJAIBFPDQsgWiAJuKEhWyAHIEVBAnRqKgIAIT4gByAzQQJ0aioCACE/IEMgWiBDKwMQoCJaOQMIID8gW7YiQUMAAAA/lCAHIEZBAnRqKgIAIkIgPpMgPiA+kiA/QwAAoMCUkiBCQwAAgECUkiAHIEBBAnRqKgIAIjiTIDggPyBCk0MAAEBAlJIgPpMgQZSSIEGUkpSSIT4CQCBDLQBkIglB/wFGDQAgQ0MAAAAAIEMqAjgiPyBDKgJcQwAAgD9DAACAv0MAAKBAQwAAoMAgQyoCWCBDKgJUID4gQyoCUJQgQyoCTCBDKgJIIEMqAjQiQSBDKgIoIkIgQyoCQJQgQyoCLCI4IEMqAjyUkiA/IEMqAjAiOpSSkpSUk5SUIj4gPkMAAKDAXRsiPiA+QwAAoEBeGyI+ID4gPpQiPiA+ID5DAAC9Q5KUQwBah0aSlEPA9wNIkpQgPiA+ID5DAADgQZRDAOBERZKUQwCic0eSlEPA9wNIkpUiPiA+QwAAgL9dGyI+ID5DAACAP14blCI3IEKTlCI+IEIgPpIiPJIiPiA+i0MI5TweXRs4AiggQ0MAAAAAID8gPCA4k5QiPiA4ID6SIkKSIj4gPotDCOU8Hl0bOAIsIENDAAAAACA/IEIgOpOUIj4gOiA+kiI4kiI+ID6LQwjlPB5dGzgCMCBDQwAAAAAgPyA4IEGTlCI+IEEgPpIiPpIiPyA/i0MI5TweXRs4AjQCQAJAAkACQCAJDgQDAgEAAwsgNyA8QwAAgECUkyBCQwAAwECUkiA4QwAAgECUkyA+kiE+DAILIEIgOCA4kpMgPpJDAACAQJQhPgwBCyBCIT4LID4gQyoCYJQhPgsCQCBDKAJwIgkgQygCbE8NACAJQQNLDQ0gBCBHIAlBFGxqIkAoAgBJDQAgQ0EBOgDYASBDIEAtABAiRToA2QEgQyBAKgIMOAKEASBDIEAqAgQiQTgCfCBDIAlBAWo2AnAgQCoCCCE/AkAgRQ0AIEMgQSBDKgJ0kyA/lTgCeAwBCyBDID9DAACgQJT8ATYCgAEgQ0MAAIA/QwAAgL8gP5UQo4GAgACTOAJ4CwJAAkACQCBDLQDYASIJQQFHDQAgQy0A2QFBAXENAQsCQCAJDQAgQ0MAAAAAIEMqAnQgQyoChAGUIj8gP4tDCOU8Hl0bIj84AnQgPiA/lCE+DAQLIEMgQyoCeCJCIEMqAnSSIj84AnQgQyoCfCFBAkACQCBCQwAAAABgRQ0AID8gQWANAQsgQkMAAAAAXUUNAiA/IEFfRQ0CCyBDQQA6ANgBIEMgQTgCdCA+IEGUIT4MAwsgQyBDKgJ0Ij8gQyoCfCA/kyBDKgJ4lJIiPzgCdCBDIEMoAoABIgkgCUEAR2s2AoABIAlBAUsNACBDQQA6ANgBCyA+ID+UIT4MAQsgQ0EAOgDcAUMAAAAAIT4LIAwgPiAMKgIAkjgCACAEQQFqIQQgDEEEaiEMIAhBfGoiCA0ACwsgQyoC/AEhPgJAIGsNACBDKgKAAiFCIEMqAgQhOCBDKgIAITogQyoC+AEhPCBDKgL0ASE3IEMqAvABIUEgfyERIBMhCgNAIAogb2oiCUGAeGohDCAJQYBwaiEJIAoqAgAhPwJAIEFDAAAAAF5FDQAgN0MAAIA/QwAAgL9DAACgQEMAAKDAIEEgP5QiPyA/QwAAoMBdGyI/ID9DAACgQF4bIj8gPyA/lCI/ID8gP0MAAL1DkpRDAFqHRpKUQ8D3A0iSlCA/ID8gP0MAAOBBlEMA4ERFkpRDAKJzR5KUQ8D3A0iSlSI/ID9DAACAv10bIj8gP0MAAIA/XhuUIT8LIAkgCSoCACA6IDwgPpQgP5QiP5SSOAIAIAwgOCA/lCAMKgIAkjgCACAKQQRqIQogQiA+lCE+IBFBf2oiEQ0ACwsgQyA+OAL8ASBDIHMgf2o2AuABAkACQCA+Q6zFJzddDQBBASEKAkAgQy0AyAVBAUcNAEEAIQogQygCtAggQygCsAhJDQAgQy0AnAlBAXENACBDKgK4CItDrMUnN10hCgsCQAJAIEMtAOgDQQFHDQBBACEJIEMoAvwCIEMoAvgCSQ0BIEMtAOQDQQFxDQEgQyoCgAOLQ6zFJzddRQ0BCwJAIEMtAKQFQQFHDQBBACEJIEMoArgEIEMoArQESQ0BIEMtAKAFQQFxDQEgQyoCvASLQ6zFJzddRQ0BC0EBIQkLQQEhDAJAIEMtAKwIQQFHDQBBACEMIEMoAsAHIEMoArwHSQ0AIEMtAKgIQQFxDQAgQyoCxAeLQ6zFJzddIQwLAkACQCBDLQDcAQ0AIAogCXEgDHENAQwDCyBDKAJwIEMoAmxJDQIgQy0A2AFBAXENAiAMIAkgCiBDKgJ0i0OsxSc3XXFxcUEBRw0CCyBDKgLoAUMAAAAAXA0BCyBDQQA6AKAJC0EBITUgekUNAQtBACEKDAELQQEhCgwACwsgCiCEAUGgksCAABCOgICAAAALIEUgEUGQksCAABCOgICAAAALIDMgEUGQksCAABCOgICAAAALIEYgEUGQksCAABCOgICAAAALIEAgEUGQksCAABCOgICAAAALIAlBBEHYlcCAABCOgICAAAALIDYhMyA2IBJJDQALAkACQCA1QQFxRQ0AIABBADYCsCMMAQsgAEF/IAAoArAjIgogEmoiDCAMIApJGyIKNgKwIyAKQT9JDQACQCASQQJ0IgpFIgwNACAAQeAAakEAIAr8CwALIAwNASAAQeAEakEAIAr8CwAMAQsgAEGACWohDCAAQeAIaiEHIABB4ABqIQkgEkECdCIIIREDQCAVQQRqKgIAIT8gFSoCACE+IAAgACgCgAoiCkF/aiIEQQ8gChsiCjYCgAogCkEfSw0HIAwgCkECdGogPjgCACAAKAKACkEQaiIKQSBPDQogDCAKQQJ0aiA+OAIAIAAoAoQKIgpBB0sNAiAHIApBAnRqIgoqAgAhPiAKID84AgAgACAAKAKECkEBakEHcTYChAogACgCgAoiCkERTw0DIAkgPkMAAAA/lCAMIApBAnRqIgoqAgAgCioCPJJD2fCluJRDAAAAAJIgCioCBCAKKgI4kkMDtFg6lJIgCioCCCAKKgI0kkNXdlK7lJIgCioCDCAKKgIwkkPGRRE8lJIgCioCECAKKgIskkPO56a8lJIgCioCFCAKKgIokkM9Ey89lJIgCioCGCAKKgIkkkNYuLy9lJIgCioCHCAKKgIgkkPvcqA+lJKSOAIAIBVBCGohFSAJQQRqIQkgEUF8aiIRDQALIABBqApqIQwgAEGICmohESAAQeAEaiEJA0AgFEEEaioCACE/IBQqAgAhPiAAIAAoAqgLIgpBf2oiBEEPIAobIgo2AqgLIApBH0sNByAMIApBAnRqID44AgAgACgCqAtBEGoiCkEfSw0KIAwgCkECdGogPjgCACAAKAKsCyIKQQdLDQIgESAKQQJ0aiIKKgIAIT4gCiA/OAIAIAAgACgCrAtBAWpBB3E2AqwLIAAoAqgLIgpBEEsNAyAJID5DAAAAP5QgDCAKQQJ0aiIKKgIAIAoqAjySQ9nwpbiUQwAAAACSIAoqAgQgCioCOJJDA7RYOpSSIAoqAgggCioCNJJDV3ZSu5SSIAoqAgwgCioCMJJDxkURPJSSIAoqAhAgCioCLJJDzuemvJSSIAoqAhQgCioCKJJDPRMvPZSSIAoqAhggCioCJJJDWLi8vZSSIAoqAhwgCioCIJJD73KgPpSSkjgCACAUQQhqIRQgCUEEaiEJIAhBfGoiCA0ACwsCQCAAKAIwIgpFDQAgACgCNCIJQXxqKAIAIgxBeHEiEUEEQQggDEEDcSIMGyAKQSxsIgpqSQ0DAkAgDEUNACARIApBJ2pLDQULIAkQgYCAgAALQQAhDCAAQQA2AjggACAFNgI0IAAgBjYCMCAAQeAEaiEJIABB4ABqIREDQCAAIAxqIgpB4ABqKAIAQQF0QYCAgHhPDQcgCkHkAGooAgBBAXRB////d0sNByAKQegAaigCAEEBdEH///93Sw0HIApB7ABqKAIAQQF0Qf///3dLDQcgDEEQaiIMQYAERw0AC0EAIQwMBAsgCkEIQfCRwIAAEI6AgIAAAAsgCiAKQRBqQSBBwI3AgAAQloCAgAAAC0GAs8CAAEEuQbCzwIAAEIKAgIAAAAtBwLPAgABBLkHws8CAABCCgICAAAALA0AgACAMaiIKQeAEaigCAEEBdEH///93Sw0CIApB5ARqKAIAQQF0Qf///3dLDQIgCkHoBGooAgBBAXRB////d0sNAiAKQewEaigCAEEBdEH///93Sw0CIAxBEGoiDEGABEcNAAwDCwsgBEEgQfiKwIAAEI6AgIAAAAsgABChgICAACABRQ0AAkAgEkECdCIKRSIMDQAgEUEAIAr8CwALIAwNACAJQQAgCvwLAAsgAkHgCmokgICAgAAPCyAKQSBBiIvAgAAQjoCAgAAAC7IDBAF/AXwBfgV8I4CAgIAAQSBrIgUkgICAgAACQCACRM3MzMzMzNw/oiIGRAAAAAAAABRAZg0AIAVCgICAgICAgIrAADcDACAFIAY5AwggBUGCgICAAK1CIIYiByAFQQhqrYQ3AxggBSAHIAWthDcDEEHtgcCAACAFQRBqQeiKwIAAEImAgIAAAAsgAEQAAAAAAAAkQCAERAAAAAAAAERAoxC2gYCAACIERAAAAAAAAPA/oCIIRAAAAAAAAPA/RAAAAAAAAPC/IAFB/wFxQQNGGyIJIAREAAAAAAAA8L+gIgqiIAZEAAAAAAAAFEAgAyADRAAAAAAAABRAYxsiAyADIAZkG0QYLURU+yEZQKIgAqMiAhCpgYCAACIDoiILoCIMIASfIgYgBqAgAhCngYCAAERmZmZmZmb2P6OiIgahIAwgBqAiAqM5AyAgACAJRAAAAAAAAADAoiAKIAMgCSAIoqIiA6CiIAKjOQMYIAAgBCAJIAmgoiAKIAOhoiACozkDCCAAIAQgCCALoSIJIAahoiACozkDECAAIAQgCSAGoKIgAqM5AwAgBUEgaiSAgICAAAsbAEMAAIA/IABDAAAAP5IiACAAlEMAAIA/kpULHABDAACAPyAAQwAAgD6SIgAgAJRDAACAP5KRlQuJCAcDfAF/AXwCfwR8AX0Bf0R7FK5H4XqEPyADIAMgA2IbIgNEexSuR+F6hD8gA0R7FK5H4XqEP2QbIQcgBUQAAAAAAADwP6AiAyADoCIIIAigIAQgBKBEmpmZmZmZBUCjIAMQtoGAgAAiAyADoKMhCSABQQJ0IQpEAAAAAAAA8D8gAkQAAAAAAAAQQKKjIQMgBCAGRAAAAAAAANA/oqIhC0EAIQxBACENRAAAAAAAAAAAIQJEAAAAAAAAAAAhDkQAAAAAAAAAACEIRAAAAAAAAAAAIQ8CQANAAkAgCiANRw0AIAEhDAwCC0QAAAAAAAAAACEERAAAAAAAAAAAIQYCQCAPIAihIhBEAAAAAAAAAABkRQ0AIAkgECAFELaBgIAAoiEGCyAGRAAAAAAAAAAAoCEQAkAgDyADIAcgAyAGoqEiB6KgIg8gCCADIAsgBqJEAAAAAAAA4D+ioqAiEaEiBkQAAAAAAAAAAGRFDQAgCSAGIAUQtoGAgACiIQQLRAAAAAAAAAAAIQYgECAEoCEQRAAAAAAAAAAAIQgCQCAPIAMgByADIASioSIHoqAiDyARIAMgCyAEokQAAAAAAADgP6KioCIEoSIRRAAAAAAAAAAAZEUNACAJIBEgBRC2gYCAAKIhCAsgECAIoCEQAkAgDyADIAcgAyAIoqEiB6KgIg8gBCADIAsgCKJEAAAAAAAA4D+ioqAiCKEiBEQAAAAAAAAAAGRFDQAgCSAEIAUQtoGAgACiIQYLIAAgDWogECAGoEQAAAAAAADQP6IiBLY4AgAgDUEEaiENIAxBAWohDCAOIASgIQ4gCCADIAsgBqJEAAAAAAAA4D+ioqAhCCAPIAMgByADIAaioSIHoqAhDyAEIAIgAiACYhsiAiACIAQgBCAEYhsiBiACIAZkGyICRAAAAAAAAAAAZEUNACAEIAJELUMc6+I2Gj+iY0UNAAsLAkAgDkQAAAAAAAAAAGRFDQACQCAMIAFNDQBBACAMIAFBuJfAgAAQloCAgAAACyAMRQ0ARAAAAAAAAPA/IA6jtiESIAAhDQJAIAxBAnQiE0F8aiIBQQJ2QQFqQQdxIgpFDQAgCkECdCEKIAAhDQNAIA0gDSoCACASlDgCACANQQRqIQ0gCkF8aiIKDQALCyABQRxJDQAgACATaiEKA0AgDSANKgIAIBKUOAIAIA1BBGoiACAAKgIAIBKUOAIAIA1BCGoiACAAKgIAIBKUOAIAIA1BDGoiACAAKgIAIBKUOAIAIA1BEGoiACAAKgIAIBKUOAIAIA1BFGoiACAAKgIAIBKUOAIAIA1BGGoiACAAKgIAIBKUOAIAIA1BHGoiACAAKgIAIBKUOAIAIA1BIGoiDSAKRw0ACwsgDAsOACAALQDuIkF/c0EBcQuOCgEGfwJAIAAoArARIgFFDQAgACgCrBEiAiEDAkAgAUHoAWwiBEGYfmoiBUHoAW5BAWpBA3EiAUUNACABQegBbCEGQQAhAQNAIAIgAWoiA0GkAWpCADcCACADQewAakIANwIAIANBNGpCADcCACADQeUBakEAOgAAIAYgAUHoAWoiAUcNAAsgAiABaiEDCyAFQbgFSQ0AIAIgBGohAQNAIANBzQNqQQA6AAAgA0GkAWpCADcCACADQewAakIANwIAIANBNGpCADcCACADQeUBakEAOgAAIANBtQVqQQA6AAAgA0GMA2pCADcCACADQdQCakIANwIAIANBnAJqQgA3AgAgA0GdB2pBADoAACADQfQEakIANwIAIANBvARqQgA3AgAgA0GEBGpCADcCACADQdwGakIANwIAIANBpAZqQgA3AgAgA0HsBWpCADcCACADQaAHaiIDIAFHDQALC0GAeCEBA0AgACABaiIDQbgIakEANgIAIANBsAhqQQA2AgAgA0GoCGpBADYCACADQaAIakEANgIAIANBmAhqQQA2AgAgA0GQCGpBADYCACADQYgIakEANgIAIANBgAhqQQA2AgAgAUHAAGoiAQ0ACwJAIAAoAugiIgFFDQAgACgC5CIiAiEDAkAgAUEFdCIFQWBqIgZBBXZBAWpBB3EiAUUNACABQQV0IQEgAiEDA0AgA0EANgIYIANCADcDECADQgA3AwggA0IANwMAIANBIGohAyABQWBqIgENAAsLIAZB4AFJDQAgAiAFaiEBA0AgA0EANgIYIANCADcDECADQgA3AwggA0IANwMAIANBIGpCADcDACADQShqQgA3AwAgA0EwakIANwMAIANBOGpBADYCACADQcAAakIANwMAIANByABqQgA3AwAgA0HQAGpCADcDACADQdgAakEANgIAIANB4ABqQgA3AwAgA0HoAGpCADcDACADQfAAakIANwMAIANB+ABqQQA2AgAgA0GYAWpBADYCACADQZABakIANwMAIANBiAFqQgA3AwAgA0GAAWpCADcDACADQbgBakEANgIAIANBsAFqQgA3AwAgA0GoAWpCADcDACADQaABakIANwMAIANBwAFqQgA3AwAgA0HIAWpCADcDACADQdABakIANwMAIANB2AFqQQA2AgAgA0HgAWpCADcDACADQegBakIANwMAIANB8AFqQgA3AwAgA0H4AWpBADYCACADQYACaiIDIAFHDQALCyAAQQA6APQeIABBADoArB4gAEEAOgDkHSAAQQA6AJwdIABBADoA1BwgAEEAOgCMHCAAQQA6AMQbIABBADoA/BogAEEAOgC0GiAAQQA6AOwZIABBADoApBkgAEEAOgDcGCAAQQA6AJQYIABBADoAzBcgAEEAOgCEFyAAQQA6ALwWIABBADoA9BUgAEEAOgCsFSAAQQA6AOQUIABBADoAnBQgAEEAOgDUEyAAQQA6AIwTIABBADoAxBIgAEEAOgD8ESAAQgA3A4AiIABCADcD+CEgAEIANwPwISAAQgA3A+ghIABCADcDsCIgAEIANwO4IiAAQgA3A8AiIABCADcDyCIgAEIANwOQICAAQgA3A5ggIABCADcDoCAgAEIANwOoICAAQgA3A9ggIABCADcD4CAgAEIANwPoICAAQgA3A/AgIABCADcDuCEgAEIANwOwISAAQgA3A6ghIABCADcDoCEgAEEBOgDuIgvrHgMQfwd9QnwjgICAgABBgAhrIgckgICAgAACQCACRQ0AIAJBAnQiCEUNACABQQAgCPwLAAsCQCAERQ0AIARBAnQiCEUNACADQQAgCPwLAAsCQCAALQDsIkEBRw0AAkAgBSAAKgK0EZOLQwrXIzxdDQAgACAFOAK0ESAAIAW7RAAAAAAAwJJAoxDFgYCAADkDoBEgACgCsBEiCUUNACAAKAKsEUHlAWohCEEAIQoDQAJAIAgtAABBAUcNACAAIAoQlYCAgAALIAhB6AFqIQggCSAKQQFqIgpHDQALC0GEgICAAEGFgICAACAALQDtIhshCyABIAJBAnQiDGohDSAAKAKwESIOIQ9BACEIQQAhEANAIAhBf2ohESAAKAKsESAIQegBbGoiCUEoaiEKQQAgCCAOIAggDksbayESQQAgCCAPIAggD0sbIhNrIRQgCUHlAWohCQJAAkACQANAIAkhCCAKIRUCQCASIBEiFmpBf0cNACAALQDuIkF/cyAQckEBcQ0EIAAtAPwRDQQgAC0AxBJBAXENBCAALQCME0EBcQ0EIAAtANQTQQFxDQQgAC0AnBRBAXENBCAALQDkFEEBcQ0EIAAtAKwVQQFxDQQgAC0A9BVBAXENBCAALQC8FkEBcQ0EIAAtAIQXQQFxDQQgAC0AzBdBAXENBCAALQCUGEEBcQ0EIAAtANwYQQFxDQQgAC0ApBlBAXENBCAALQDsGUEBcQ0EIAAtALQaQQFxDQQgAC0A/BpBAXENBCAALQDEG0EBcQ0EIAAtAIwcQQFxDQQgAC0A1BxBAXENBCAALQCcHUEBcQ0EIAAtAOQdQQFxDQQgAC0ArB5BAXENBCAALQD0HkEBcQ0EDAYLIBQgFmpBf0YNASAVQegBaiEKIAhB6AFqIQkgFkEBaiERIAgtAABFDQALAkACQCARIAAoAugiIgpPDQAgAg0BIAAgEUMAAAAAQQAQl4CAgAAhCgwDCyARIApB+JfAgAAQjoCAgAAACyAAKALkIiARQQV0aiEUIAhBm35qIgoqAtABIRcgCioCyAEhGCAKKgLMASEFQwAAAAAhGSABIQgDQCAIIQ8gBSEaQwAAAAAhBQJAAkACQAJAAkAgCigCwAEiCCAKKAK8AU8NACAIIAooAuABIglPDQEgCiAIQQFqNgLAASAKKALcASAIQQJ0aioCACEFCyAKKAK4ASIIQQRPDQECQAJAIAgNAEMAAAAAIRsMAQsgCioCOCEbIAogCioCNCIcOAI4IAogHCAKKgIolCAbIAoqAiyUkiAFIAoqAjCUkiIbOAI0IBtDAAAAAJIhGyAIQQFGDQAgCioCcCEcIAogCioCbCIdOAJwIAogHSAKKgJglCAcIAoqAmSUkiAFIAoqAmiUkiIcOAJsIBsgHJIhGyAIQQJGDQAgCioCqAEhHCAKIAoqAqQBIh04AqgBIAogHSAKKgKYAZQgHCAKKgKcAZSSIAUgCioCoAGUkiIFOAKkASAbIAWSIRsLIBQoAggiCEUNAyAUIAhBf2oiCDYCCCAbIBQqAhAiBSAUKgIUIhwgBZNEAAAAAAAA4D8gFCgCDCIJIAhruEQYLURU+yEJQKIgCbijEKmBgIAARAAAAAAAAOA/oqG2lJKSIRsgCA0DIAooArgBIghBBE8NAgJAAkAgCA0ARAAAAAAAAACAIR4MAQsgFCsDACIfIAoqAjC7okQAAAAAAADwPyAKKgIou6EgCioCLLuhoyEeIAhBAUYNACAeIB8gCioCaLuiRAAAAAAAAPA/IAoqAmC7oSAKKgJku6GjoCEeIAhBAkYNACAeIB8gCioCoAG7okQAAAAAAADwPyAKKgKYAbuhIAoqApwBu6GjoCEeC0QAAAAAAAAAACEfAkAgHplEEeotgZmXcT1kRQ0AIBy7IB6jIR8LAkAgCEUNACAIQThsIQkgFSEIA0AgCEEMaiISIBIqAgAgHyAUKwMAIAhBCGoqAgC7okQAAAAAAADwPyAIKgIAu6EgCEEEaioCALuho6K2IgWSOAIAIAhBEGoiEiASKgIAIAWSOAIAIAhBOGohCCAJQUhqIgkNAAsLIApBADYCwAEgCiAUKAIYNgK8AQwDCyAIIAlBqJbAgAAQjoCAgAAAC0EAIAhBA0G4lsCAABCWgICAAAALQQAgCEEDQYiYwIAAEJaAgIAAAAsgGCAblCALEYCAgIAAgICAgAAhBSAPIA8qAgAgFyAFIAUgGiAaIBpcG5OUkjgCACAbiyIbIBkgGSAZXBsiGSAZIBsgGyAbXBsiGyAZIBteGyEZIA9BBGoiCCANRw0ACyAKIAU4AswBIAAgESAZIAIQl4CAgAAhCgwBCyATIA9B6JfAgAAQjoCAgAAACyAWQQJqIQggCiAQciEQIAAoArARIQ8MAQsLQQAhCCAHQYAEakEAQYAE/AsAIAdBAEGABPwLAAJAIAJBgQFJDQBBACACQYABQdiXwIAAEJaAgIAAAAsgAEG4EWogByACIAdBgARqIAIQnICAgAAgACoCqB8hGiAAKgKcHyEZIAArA4AIIR8gACoCpB8hHESamZmZmZmpP0SamZmZmZm5PyAALQDtIhsiIBDLgYCAACEhIAAqApARIRtDAAAAACEFRAAAAAAAAPC/IB9EexSuR+F6lD+ioxCygYCAACEeIBm7RAAAAAAAABhAokQAAAAAAADwP6AiIkQzMzMzMzPjPxC2gYCAACEjIAAqAqwfIRlDAACAP0MAAAAAIBsgG0MAAAAAXRsiGyAbQwAAgD9eG7tEmpmZmZmZ+T8QtoGAgAAhJAJAAkAgAkUNACAcu0QYLURU+yEZQKIgH6MhJUQAAAAAAADwPyAeoSEmRJqZmZmZmeE/ICOjIScgGrshKCAZuyEpIAArA8giISogACsDwCIhKyAAKwO4IiEsIAArA7AiIR8gACsDgCIhLSAAKwP4ISEuIAArA/AhIS8gACsD6CEhHiAAKwPwICEwIAArA+ggISMgACsD4CAhMSAAKwPYICEyIAArA6ggITMgACsDoCAhNCAAKwOYICE1IAArA5AgITYgACsD0CIhNyAAKwOoIiE4IAArA6AiITkgACsDmCIhOiAAKwOQIiE7IAArA4giITwgACsD4CEhPSAAKwPYISE+IAArA9AhIT8gACsDyCEhQCAAKwPAISFBIAArA4ghIUIgACsDgCEhQyAAKwP4ICFEIAArA9AgIUUgACsDyCAhRiAAKwPAICFHIAArA7ggIUggACsDsCAhSSAAKwOIICFKIAArA4AgIUsgACsD+B8hTCAAKwPwHyFNIAArA+gfIU4gACsDuCEhTyAAKwOYISFQIAArA7AhIVEgACsDkCEhUiAAKwOoISFTIAArA6AhIVQgACsD2CIhVUEAIQogB0GABGohCSAHIRIgASEIIAMhFANAIDIhViAeIVcgHyFYICAgIkQAAAAAAAAAACBNIDYiWaIgTiAIKgIAIBIqAgAgCSoCAJJDAAAAP5SSuyI2oqAgTCA1oqAgSyA0IlqioSBKIDOioSIfIB+ZRCNCkgyhnMc7YxsiNKKgEMuBgIAAIR4gCEQAAAAAAADwPyAlIDegIh9EGC1EVPshGcCgIB8gH0QYLURU+yEZQGQbIjcQp4GAgABEAAAAAAAA4D+iRAAAAAAAAOA/oCAooqFEAAAAAAAAAABEAAAAAAAAAABEAAAAAAAAAABEAAAAAAAAAAAgSSAnIB4gIaGiIjKiIEggVqKgIEcgMaKgIEYgIyJboqEgRSAwoqEiHyAfmUQjQpIMoZzHO2MbIiMgRKIgQyBUIlyioCBCIFOioCBSIFEiXaKhIFAgT6KhIh8gH5lEI0KSDKGcxztjGyIeIEGiIEAgV6KgID8gL6KgID4gLiJeoqEgPSAtoqEiHyAfmUQjQpIMoZzHO2MbIh8gPKIgOyBYoqAgOiAsoqAgOSArIl+ioSA4ICqioSIrICuZRCNCkgyhnMc7YxsiK6IgKaIgVSAmICQgVaGioCJVorYiGzgCACAEIApGDQIgFCAbOAIAIBuLIhsgBSAFIAVcGyIFIAUgGyAbIBtcGyIbIAUgG14bIQUgEkEEaiESIAlBBGohCSAIQQRqIQggFEEEaiEUIF8hKiBYISwgXiEtIB8hLiBXIS8gWyEwIFYhMSBaITMgWSE1IF0hTyAeIVEgXCFTICMhVCACIApBAWoiCkcNAAsgACA3OQPQIiAAIFU5A9giIAAgXDkDqCEgACBbOQPwICAAICM5A+ggIAAgVjkD4CAgACAyOQPYICAAIFo5A6ggIAAgNDkDoCAgACBZOQOYICAAIDY5A5AgIAAgXTkDuCEgACAjOQOgISAAIF85A8giIAAgKzkDwCIgACBYOQO4IiAAIB85A7AiIAAgXjkDgCIgACAfOQP4ISAAIFc5A/AhIAAgHjkD6CEgACAeOQOwISAFQ5W/1jNdQQFzIQgLIBBBAXENASAALQD8ESAALQDEEnIgAC0AjBNyIAAtANQTciAALQCcFHIgAC0A5BRyIAAtAKwVciAALQD0FXIgAC0AvBZyIAAtAIQXciAALQDMF3IgAC0AlBhyIAAtANwYciAALQCkGXIgAC0A7BlyIAAtALQaciAALQD8GnIgAC0AxBtyIAAtAIwcciAALQDUHHIgAC0AnB1yIAAtAOQdciAALQCsHnIgAC0A9B5yIAhyQQFxDQEgAEIANwPoISAAQQE6AO4iIABCADcD8CEgAEIANwP4ISAAQgA3A4AiIABCADcDsCIgAEIANwO4IiAAQgA3A8AiIABCADcDyCIgAEIANwOQICAAQgA3A5ggIABCADcDoCAgAEIANwOoICAAQgA3A9ggIABCADcD4CAgAEIANwPoICAAQgA3A/AgIABCADcDuCEgAEIANwOwISAAQgA3A6ghIABCADcDoCECQCACRQ0AIAxFDQAgAUEAIAz8CwALIARFDQEgBEECdCIIRQ0BIANBACAI/AsADAELIAAgNzkD0CIgACBVOQPYIiAAIFw5A6ghIAAgWzkD8CAgACAjOQPoICAAIFY5A+AgIAAgMjkD2CAgACBaOQOoICAAIDQ5A6AgIAAgWTkDmCAgACA2OQOQICAAIF05A7ghIAAgIzkDoCEgACBfOQPIIiAAICs5A8AiIAAgWDkDuCIgACAfOQOwIiAAIF45A4AiIAAgHzkD+CEgACBXOQPwISAAIB45A+ghIAAgHjkDsCEgBCAEQciXwIAAEI6AgIAAAAsgB0GACGokgICAgAALiAEBAn8CQCABQQJLDQAgACABQQJ0akGMEWohAwJAIAK8QQF0Qf///3dNDQAgAyoCACECCyADIAI4AgAgAQ0AIAAoArARIgRFDQAgACgCrBFB5QFqIQFBACEDA0ACQCABLQAAQQFHDQAgACADEJWAgIAACyABQegBaiEBIAQgA0EBaiIDRw0ACwsLkBYKBX8BfQF8AX4BfAF9B3wBfwJ8An8jgICAgABB0ABrIgUkgICAgAACQAJAAkACQCAAKAKIESIGQYEBTw0AIABBiAhqIQcgBkEDdCEIQQAhBgJAA0AgCCAGRg0BIAAgBmohCSAGQQhqIQYgCUGICGooAgAgA0cNAAsgAEEBIAMQrICAgAALQTwhBgJAIAG8IglBAXRB////d0sNAEEAQwAA/kJDAAAAACABEK2BgIAAIgogCkMAAAAAXRsiCiAKQwAA/kJeGyIKQwAAAACXQwAAf0OW/AEgCiAKXBshBgsgBUEIaiAHIAMgBhCfgICAAAJAIAUtAAhFDQAgACAFLQAJQf8BcUEDdGoiBigCAEEBRw0AIAAgBigCBBCVgICAAAtBPCEGAkAgCUEBdEH///93Sw0AQQBDAAD+QkMAAAAAIAEQrYGAgAAiCiAKQwAAAABdGyIKIApDAAD+Ql4bIgpDAAAAAJdDAAB/Q5b8ASAKIApcGyEGCyAAKwOACCELIAAqAogfIQogBSAAIAYQmICAgAAgBS0ABCEIIAUoAgAhByAAIAApA5gRQgF8Igw3A5gRQwAA/kJDAAAAACABIAFDAAAAAF0bIgEgAUMAAP5CXhu7RAAAAAAAQFHAoEQAAAAAAAAoQKMQxYGAgAAhDSAAKAKwESEJIAoQrYGAgAAhCiAHIAlPDQEgACgCrBEgB0HoAWxqIgNBADYC1AEgAyAMNwMAAkACQAJAIAhBAXENACAHIAAoAugiIglPDQUgACgC5CIgB0EFdGoiCSgCCCIIRQ0BIAkqAhAiASAJKgIUIAGTRAAAAAAAAOA/IAkoAgwiCSAIa7hEGC1EVPshCUCiIAm4oxCpgYCAAEQAAAAAAADgP6KhtpSSIQ4MAgsgA0GAgID+BzYCzAELQwAAAAAhDgsgA0KAgICAgICA+D83AyAgAyANRAAAAAAAgHtAoiINOQMIIAMgDSALROF6FK5H4do/oiIPYyANRBSuR+F6FBlAoiIQIA9jaiANRM3MzMzMjDFAoiIRIA9jaiIJQQEgCUEBSyIIGzYCuAEgA0Q2H9eGiqEbQEQtQxzr4jYaP0QAAAAAAADgPyAAKgKUH7uhRJqZmZmZmQFAohDFgYCAAESamZmZmZmpP6IiDyAPIA9iGyIPRC1DHOviNho/IA9ELUMc6+I2Gj9kG6MiEjkDGCAAKgKQHyEBIANENh/XhoqhG0BELUMc6+I2Gj9EAAAAAADAWUBEAAAAAAAAPEAgBkH/AXG4Ig8gD0QAAAAAAAA8QGMbIg8gD0QAAAAAAMBZQGQbRAAAAAAAAELAoEQAAAAAAAA5wKMQxYGAgABEAAAAAAAACECiRJqZmZmZmak/IAG7Ig8gDyAPYhsiD0SamZmZmZmpPyAPRJqZmZmZmak/ZBuiIg8gDyAPYhsiD0QtQxzr4jYaPyAPRC1DHOviNho/ZBujOQMQRAAAAAAAAPA/RAAAAAAAAAAAIAAqAowfuyITIBNEAAAAAAAAAABjGyIPIA9EAAAAAAAA8D9kGyIPRAAAAAAAAOC/oEQAAAAAAAAEwKIQxYGAgAAhFCAAKgKYHyEBIA1EGC1EVPshGUCiIAujIRUgCEUNAyADQt3ekJqAxZriPzcDWCADQoO0otjh08GbwAA3A0ggAyAQOQNAIAMgEiASoDkDUCAJQQJGDQMgA0LIpYeU14/L1j83A5ABIANC4qDgysPG5arAADcDgAEgAyAROQN4IAMgEkQAAAAAAAAIQKI5A4gBDAMLQQAgBkGAAUHAksCAABCWgICAAAALIAcgCUGsj8CAABCOgICAAAALIAcgCUHolcCAABCOgICAAAALIBVEAAAAAAAA4D+iELyBgIAAIRICQAJAIAMoAuABIgZFDQBEzczMzMzM9D9EAAAAAAAAAAAgBLtEAAAAAAAA4D+iIAG7oCIQIBBEAAAAAAAAAABjGyIQIBBEzczMzMzM9D9kGyIQRM3MzMzMzNw/okS4HoXrUbi+P6AgEESamZmZmZn5P6JEAAAAAAAA4D+gIAr8ACIWQQFGIgkbIRFEAAAAAAAA8D9DAACAP0MAAAAAIAIgAkMAAAAAXRsiASABQwAAgD9eG7siECAQRAAAAAAAAPA/ZBsiF0QAAAAAAADoP6JEAAAAAAAA0D+gIA9EAAAAAAAA4D+iRAAAAAAAAOg/oKIiGCAYoCASoiEPAkAgC0T8qfHSTWJwPyAXRGZmZmZmZta/okQAAAAAAADwP6BEmpmZmZmZAUBEAAAAAAAA8D8gCRsgFEQtQxzr4jZaP6KioiISIBIgEmIbIhJE/Knx0k1icD8gEkT8qfHSTWJwP2MbIhIgEkTNzMzMzMzcPyANoyINIA0gDWIbIg0gEiANYxui/AMiCSAGIAkgBkkbQQEgCRsiGUUNACADKALcASEGIBm4IRICQAJAIBlB/////wNqIhpB/////wNxIgkNAEEAIQkMAQsgCUEBakH+////B3EhCEEAIQlEAAAAAAAAAAAhDQNAIAYgDyANRBgtRFT7IQlAoiASoxCpgYCAAEQAAAAAAADgP6JEAAAAAAAA4D+gorY4AgAgBkEEaiAPIAlBAWq4RBgtRFT7IQlAoiASoxCpgYCAAEQAAAAAAADgP6JEAAAAAAAA4D+gorY4AgAgBkEIaiEGIA1EAAAAAAAAAECgIQ0gCCAJQQJqIglHDQALIBpBAXENAQsgBiAPIAm4RBgtRFT7IQlAoiASoxCpgYCAAEQAAAAAAADgP6JEAAAAAAAA4D+gorY4AgALIANCADcCvAEgAyARtjgCyAEgA0QAAAAAAADwP0QtQxzr4jYaPyAVIBUgFWIbIg1ELUMc6+I2Gj8gDUQtQxzr4jYaP2QbRAAAAKDpN80/RAAAAEDheuQ/IBZBAUYbIBGioqO2OALQASAAIAcQlYCAgAAgAygCuAEiBkEETw0BAkACQCAGDQBDAAAAgCEBDAELIA8gAyoCMLuiRAAAAAAAAPA/IAMqAii7oSADKgIsu6GjIQ0CQCAGQQFGDQAgDSAPIAMqAmi7okQAAAAAAADwPyADKgJgu6EgAyoCZLuho6AhDSAGQQJGDQAgDSAPIAMqAqABu6JEAAAAAAAA8D8gAyoCmAG7oSADKgKcAbuho6AhDQsgDbYhAQsCQCAHIAAoAugiIgZJDQAgByAGQYiWwIAAEI6AgIAAAAsgAEEAOgDuIiAAKALkIiAHQQV0aiIGIBk2AhggBiABOAIUIAYgDjgCECAGIA85AwAgBiAXRHnpJjEIrGy/okT6fmq8dJN4P6AiDSALovwDIglBASAJQQFLGyIJNgIMIAYgCTYCCCAFQgA3AyggBUKAgICAgICIxsAANwMgIAVC/NPGl93JmLg/NwMYIAUgEET6fmq8dJNYP6IgEKI5AxAgBUIANwMwIAVCADcDOCAFQgA3A0AgAEG4EWoiBiAFQRBqEJCAgIAAIAVCADcDKCAFQoCAgICAgOLZwAA3AyAgBULh5NSCo6XqqT83AxggBSATRAAAAAAAAOA/oERhMlUwKqlDP0R7FK5H4XpkPyAWQQFGGyAYoqI5AxAgBUIANwMwIAVCADcDOCAFIA05A0AgBiAFQRBqEJCAgIAAIAVB0ABqJICAgIAADwsgBUEBNgJIIAVBADYCTCAFQYaAgIAArUIghiIMIAVBzABqrYQ3AxggBSAMIAVByABqrYQ3AxBBz4HAgAAgBUEQakH4lcCAABCJgICAAAALQQAgBkEDQZiWwIAAEJaAgIAAAAuPCAIMfwF9I4CAgIAAQcAAayIDJICAgIAAAkACQAJAAkACQAJAAkACQCABQQFHDQBBBCEEQQQQkoCAgAAiBUUNByAFIAI2AgAMAQsgACgCiBEiBkGBAU8NBSAGRQ0BIAZBAnQiARCSgICAACIFRQ0EIAZBA3EhB0EAIQgCQAJAIAZBBEkNACAGQQJ2QT9xIgFBAnQhCCABQQV0IQlBACEKIAUhAQNAIAEgACAKaiICQYgIaigCADYCACABQQRqIAJBkAhqKAIANgIAIAFBCGogAkGYCGooAgA2AgAgAUEMaiACQaAIaigCADYCACABQRBqIQEgCSAKQSBqIgpHDQALIAdFDQELIAUgCEECdGohASAIQQN0IABqQYgIaiECA0AgASACKAIANgIAIAJBCGohAiABQQRqIQEgB0F/aiIHDQALCyAGQQJ0IQQLIABBuBFqIQsgAEGIEGohDCAAQYgIaiENIAUgBGohCCADQSBqIQ4gBSEGA0ACQAJAAkACQCAAKAKIESIJQYEBTw0AIAlFDQMgBigCACEHIAlBA3QhCkEAIQFBACECAkADQCAAIAFqQYgIaigCACAHRg0BIAJBAWohAiAKIAFBCGoiAUcNAAwFCwsgDSACQQN0aiIHLAAEIQECQCAJIAJBAWoiAmtBA3QiCkUNACAHIA0gAkEDdGogCvwKAAALIAAgACgCiBFBf2o2AogRIAFB/wFxIQIgAUF/TA0BIAwgAmoiByAHLQAAIgEgAUEAR2s6AAAgAUECTw0DIAAgAkEDdGoiASgCAEEBRw0DIAAgASgCBCIBEJWAgIAAIActAAANA0MAAIA/QwAAgD9DAAAAACAAKgKMESIPIA9DAAAAAF0bIg8gD0MAAIA/XhuTIg8gD5RDAAAAP15FDQMgASAAKAKwESICTw0CIAAoAqwRIAFB6AFsaioCxAFDbxKDOl5FDQMgDkIANwMAIA5CADcDCCAOQgA3AxAgDkIANwMYIANCgICAgICA+MLAADcDGCADQvr9qePL7qS8PzcDECADQvzTxpfdyZiwPzcDCCALIANBCGoQkICAgAAMAwtBACAJQYABQYCTwIAAEJaAgIAAAAsgAkGAAUHwksCAABCOgICAAAALIAEgAkGYmMCAABCOgICAAAALIAZBBGoiBiAIRw0ACyAFQXxqKAIAIgFBeHEiAkEEQQggAUEDcSIBGyAEakkNAQJAIAFFDQAgAiAEQSdqSw0DCyAFEIGAgIAACyADQcAAaiSAgICAAA8LQYCzwIAAQS5BsLPAgAAQgoCAgAAAC0HAs8CAAEEuQfCzwIAAEIKAgIAAAAtBBCABEJOAgIAAAAtBACAGQYABQbCSwIAAEJaAgIAAAAtBBEEEEJqAgIAAAAuIAgECfyOAgICAAEEQayICJICAgIAAAkACQAJAIAEoAggiA0GAgIAQcQ0AIANBgICAIHENASAAIAEQvYCAgAAhAAwCCyAAKAIAIQNBCSEAA0AgAkEIaiAAakF+aiADQQ9xLQCYm8CAADoAACAAQX9qIQAgA0EEdiIDDQALIAFB/LHAgABBAiACQQhqIABqQX9qQQkgAGsQvoCAgAAhAAwBCyAAKAIAIQNBCSEAA0AgAkEIaiAAakF+aiADQQ9xLQD+scCAADoAACAAQX9qIQAgA0EEdiIDDQALIAFB/LHAgABBAiACQQhqIABqQX9qQQkgAGsQvoCAgAAhAAsgAkEQaiSAgICAACAAC6IKCAF/AX0BfAF/AXwCfwN8AX4jgICAgABBIGsiAiSAgICAACAAQYgfaiABQeAA/AoAACAAQQE6AOwiIAAqAogfEK2BgIAAIQMgACsDgAghBAJAIAP8ACIFQQFGIgEgAC0A7SJGDQAgACABOgDtIkQAAACg6TfNP0QAAABA4XrkPyABGyEGIAAoArARQegBbCEHIAAoAqwRIghB5AFqIQEDQCAHRQ0BAkAgCC0A5QFFDQAgAUFoakGAgID+BzYCACABLQAAuEQAAAAAAEBRwKBEAAAAAAAAKECjEMWBgIAAIQkgAUFsakQAAAAAAADwPyAGIAFBZGoqAgC7okQtQxzr4jYaPyAJRAAAAAAAgHtAokQYLURU+yEZQKIgBKMiCSAJIAliGyIJRC1DHOviNho/IAlELUMc6+I2Gj9kG6KjtjgCAAsgCEHoAWohCCAHQZh+aiEHIAFB6AFqIQEMAAsLAkAgBETNzMzMzMzcP6IiCUQAAAAAAAAUQGZFDQAgAEQAAAAAAADwPyAJRAAAAAAAADlAIAlEAAAAAAAAOUBjG0QYLURU+yEZQKIgBKMiChCngYCAAEQzMzMzMzPzP6MiBqEgBkQAAAAAAADwP6AiBqM5A4ggIAAgChCpgYCAACIKRAAAAAAAAADAoiAGozkDgCAgACAKRAAAAAAAAPA/oCIKRAAAAAAAAOA/oiAGoyILOQP4HyAAIAqaIAajOQPwHyAAIAs5A+gfIABEAAAAAAAA8D8gCUQAAAAAAHCXQEQAAAAAAJTBQCAFQQFGIgEbIgYgCSAGYxtEGC1EVPshGUCiIASjIgoQp4GAgABEzczMzMzM/D9EZmZmZmZm9j8gARujIgahIAZEAAAAAAAA8D+gIgajOQPQICAAIAoQqYGAgAAiCkQAAAAAAAAAwKIgBqM5A8ggIABEAAAAAAAA8D8gCqEiCkQAAAAAAADgP6IgBqMiCzkDwCAgACAKIAajOQO4ICAAIAs5A7AgIABB+CBqQQQgBEQAAAAAAECfQCAAKgKgH7sQo4CAgAAgAEQAAAAAAADwPyAJRAAAAAAAwJJAIAlEAAAAAADAkkBjG0QYLURU+yEZQKIgBKMiChCngYCAAEQAAAAAAADgP6IiC0RiaFZLZXHxP6MiBqEgBkQAAAAAAADwP6AiBqM5A6giIAAgChCpgYCAAEQAAAAAAAAAwKIgBqMiCjkDoCIgAEQAAAAAAADwPyALRGJoVktlcfE/oiILoSAGozkDmCIgACAKOQOQIiAAIAtEAAAAAAAA8D+gIAajOQOIIiAARAAAAAAAAPA/IAlEAAAAAACAUUAgCUQAAAAAAIBRQGMbRBgtRFT7IRlAoiAEoyIEEKeBgIAARGZmZmZmZvY/oyIJoSAJRAAAAAAAAPA/oCIJozkD4CEgACAEEKmBgIAAIgREAAAAAAAAAMCiIAmjOQPYISAAIAREAAAAAAAA8D+gIgREAAAAAAAA4D+iIAmjIgY5A9AhIAAgBJogCaM5A8ghIAAgBjkDwCECQCAAKAKwESIIRQ0AIAAoAqwRQeUBaiEBQQAhBwNAAkAgAS0AAEEBRw0AIAAgBxCVgICAAAsgAUHoAWohASAIIAdBAWoiB0cNAAsLIAJBIGokgICAgAAPCyACQoCAgICAgICKwAA3AwAgAiAJOQMIIAJBgoCAgACtQiCGIgwgAkEIaq2ENwMYIAIgDCACrYQ3AxBB7YHAgAAgAkEQakHoisCAABCJgICAAAALDgAgAC0A4S5Bf3NBAXEL8wcBBX8CQCAAKALYLiIBRQ0AIAAoAtQuIgIhAwJAIAFB4AFsIgRBoH5qIgVB4AFuQQFxDQAgAkEAOgDdASACQTBqIQECQCACKAK0ASIDRQ0AIANBAnQiA0UNACACKAKwAUEAIAP8CwALIAJB4AFqIQMgAkEANgKoASACQgA3A5ABIAJBADYChAEgAUIANwMAIAFCADcDCCABQgA3AxAgAUIANwMYIAFCADcDICABQgA3AyggAUIANwMwIAFCADcDOAsgBUHgAUkNACACIARqIQEDQCADQd0BakEAOgAAAkAgA0G0AWooAgAiAkUNACACQQJ0IgJFDQAgA0GwAWooAgBBACAC/AsACyADQTBqIgJCADcDACACQgA3AwggAkIANwMQIAJCADcDGCACQgA3AyAgAkIANwMoIAJCADcDMCACQgA3AzggA0GoAWpBADYCACADQZABakIANwMAIANBhAFqQQA2AgAgA0G9A2pBADoAAAJAIANBlANqKAIAIgJFDQAgAkECdCICRQ0AIANBkANqKAIAQQAgAvwLAAsgA0GQAmoiAkIANwMAIAJCADcDCCACQgA3AxAgAkIANwMYIAJCADcDICACQgA3AyggAkIANwMwIAJCADcDOCADQYgDakEANgIAIANB8AJqQgA3AwAgA0HkAmpBADYCACADQcADaiICIQMgAiABRw0ACwtBgHghAgNAIAAgAmoiA0G4CGpBADYCACADQbAIakEANgIAIANBqAhqQQA2AgAgA0GgCGpBADYCACADQZgIakEANgIAIANBkAhqQQA2AgAgA0GICGpBADYCACADQYAIakEANgIAIAJBwABqIgINAAsgAEEAOgC8ISAAQQA6APQgIABBADoArCAgAEEAOgDkHyAAQQA6AJwfIABBADoA1B4gAEEAOgCMHiAAQQA6AMQdIABBADoA/BwgAEEAOgC0HCAAQQA6AOwbIABBADoApBsgAEEAOgDcGiAAQQA6AJQaIABBADoAzBkgAEEAOgCEGSAAQQA6ALwYIABBADoA9BcgAEEAOgCsFyAAQQA6AOQWIABBADoAnBYgAEEAOgDUFSAAQQA6AIwVIABBADoAxBQgAEIANwOYLCAAQgA3A5AsIABCADcDiCwgAEIANwOALCAAQgA3A8gsIABCADcD0CwgAEIANwPYLCAAQgA3A+AsIABCADcDkC0gAEIANwOYLSAAQgA3A6AtIABCADcDqC0gAEIANwPYLSAAQgA3A+AtIABCADcD6C0gAEIANwPwLSAAQgA3A7guIABCADcDsC4gAEIANwOoLiAAQgA3A6AuIABB2ClqQQBBhAH8CwAgAEEBOgDhLgvsJRACfwF8AX8BfAN/A3wBfwF9BH8EfQN/An0DfwJ9A38yfCOAgICAAEGACGsiBySAgICAAAJAIAJFDQAgAkECdCIIRQ0AIAFBACAI/AsACwJAIARFDQAgBEECdCIIRQ0AIANBACAI/AsACwJAIAAtAOAuQQFHDQACQCAFIAAqAtwuk4tDCtcjPF0NACAAIAU4AtwuIAAgBbtEAAAAAADAkkCjEMWBgIAAIgk5A9ArIAAoAtguQeABbCEKIAArA9AhIQtBACEMIAAoAtQuIg0hDgNAIAogDEYNAQJAIA4tAN0BRQ0AIA0gDGoiCEEwaiALIAkgCEHwAGorAwCiEIuAgIAAIAhBGGogCEH4AGorAwAiDyAIQRBqKwMAIhCiOQMAIAhBIGogDyAIQQhqKwMAIhGiOQMAIAhBKGogDyAQIBGhRAAAAAAAAOA/oqI5AwALIA5B4AFqIQ4gDEHgAWohDAwACwtBA0ECIAAqAugqEK2BgIAA/ABBAUYiCBsgCCAAKgLsKhCtgYCAAPwAQQFGIgwbIRJDZmaGP0MAAIA/IAgbQwAAwD9Dmpm5PyAIGyAMGyETIAJBAnQhFCAAKALULiIVIAAoAtguQeABbGohFiACQQF0uCERQQEhFwNAAkACQAJAAkAgFSIIIBZGDQAgCEHgAWohFSAILQDdAUEBRw0EIAINAUMAAAAAIRhDAAAAACEZDAMLIBcgAC0A4S5xQQFxRQ0BIAAtAMQUDQEgAC0AjBVBAXENASAALQDUFUEBcQ0BIAAtAJwWQQFxDQEgAC0A5BZBAXENASAALQCsF0EBcQ0BIAAtAPQXQQFxDQEgAC0AvBhBAXENASAALQCEGUEBcQ0BIAAtAMwZQQFxDQEgAC0AlBpBAXENASAALQDcGkEBcQ0BIAAtAKQbQQFxDQEgAC0A7BtBAXENASAALQC0HEEBcQ0BIAAtAPwcQQFxDQEgAC0AxB1BAXENASAALQCMHkEBcQ0BIAAtANQeQQFxDQEgAC0AnB9BAXENASAALQDkH0EBcQ0BIAAtAKwgQQFxDQEgAC0A9CBBAXENASAALQC8IUEBcQ0BDAQLIBMgCCoCwAGUIRogCCsDICAIKwMoIg+gIhAgEPwDIgy4obYhGyAP/AMiDkF/cyEcIAgrAxgiEPwDIgpBf3MhHSAMQX9zIR4gDyAOuKG2IR8gECAKuKG2ISBDAAAAACEZIBQhIUMAAAAAIRggASEMAkACQAJAAkACQANAIAwhDQJAIAgoArwBIgwgCCgCuAFPDQACQCAMIAgoAtgBIg5JDQAgDCAOQciYwIAAEI6AgIAAAAsCQCAIKAKEASAIKAKIAWsgCCgCgAFxIg4gCCgCtAEiCk8NACAIKAKwASAOQQJ0aiIOIAgoAtQBIAxBAnRqKgIAIA4qAgCSOAIAIAggCCgCvAFBAWo2ArwBDAELIA4gCkGgjcCAABCOgICAAAALAkACQCAIKAKEASIMIAgoAogBayAIKAKAASIicSIOIAgoArQBIgpPDQAgCCoCkAEhBSAIIAgoArABIiMgDkECdGoqAgAiJDgCkAEgCCAFICQgCCoCjAEiJZSSICUgCCoClAGUkyIFOAKUASAIKAKYASIORQ0BIAgqApwBISQgCCoCMCElIAggBTgCMCAIICUgBSAklJIgJCAIKgJQlJMiBTgCUCAOQQFGDQEgCCoCNCElIAggBTgCNCAIICUgJCAFlJIgJCAIKgJUlJMiBTgCVCAOQQJGDQEgCCoCOCElIAggBTgCOCAIICUgJCAFlJIgJCAIKgJYlJMiBTgCWCAOQQNGDQEgCCoCPCElIAggBTgCPCAIICUgJCAFlJIgJCAIKgJclJMiBTgCXCAOQQRGDQEgCCoCQCElIAggBTgCQCAIICUgJCAFlJIgJCAIKgJglJMiBTgCYCAOQQVGDQEgCCoCRCElIAggBTgCRCAIICUgJCAFlJIgJCAIKgJklJMiBTgCZCAOQQZGDQEgCCoCSCElIAggBTgCSCAIICUgJCAFlJIgJCAIKgJolJMiBTgCaCAOQQdGDQEgCCoCTCElIAggBTgCTCAIICUgJCAFlJIgJCAIKgJslJMiBTgCbCAOQQhGDQFBCEEIQZCNwIAAEI6AgIAAAAsgDiAKQfCMwIAAEI6AgIAAAAsgCCAFIAgqAqABlCAIKgKkASAIKgKoAZSTIgU4AqgBAkAgDCAKSQ0AIAwgCkGAjcCAABCOgICAAAALICMgDEECdGogBTgCACAIICIgDEEBanEiCjYChAECQCAIKAKAASIOIAogHWpxIiIgCCgCtAEiDE8NACAiQX9qIA5xIiYgDE8NAiAOIAogHGpxIiMgDE8NAyAjQX9qIA5xIicgDE8NBCAOIAogHmpxIgogDE8NBSAKQX9qIA5xIg4gDE8NBiAFiyIkIBkgGSAZXBsiGSAZICQgJCAkXBsiJF4hKCAFIAgoArABIgwgIkECdGoqAgAiJSAMICZBAnRqKgIAICWTICCUkpMhBSAMICNBAnRqKgIAIiUgDCAnQQJ0aioCACAlkyAflJIgDCAKQQJ0aioCACIlIAwgDkECdGoqAgAgJZMgG5SSkyElAkACQAJAAkAgEg4EAwABAgMLICUhBQwCCyAFICWSIQUMAQsgJSAFkyEFCyANQQRqIQwgGSAkICgbIRkgDSANKgIAIBogBZQiBZI4AgAgBYsiBSAYIBggGFwbIhggGCAFIAUgBVwbIgUgGCAFXhshGCAhQXxqIiFFDQgMAQsLICIgDEHQjMCAABCOgICAAAALICYgDEHgjMCAABCOgICAAAALICMgDEHQjMCAABCOgICAAAALICcgDEHgjMCAABCOgICAAAALIAogDEHQjMCAABCOgICAAAALIA4gDEHgjMCAABCOgICAAAALQQAhCCAHQYAEakEAQYAE/AsAIAdBAEGABPwLAAJAIAJBgQFJDQBBACACQYABQbiYwIAAEJaAgIAAAAsgAEGAFGogByACIAdBgARqIAIQnICAgAAgACoC4CohGUMAAAAAIQVEAAAAAAAA8L8gACsD0CFEexSuR+F6lD+ioxCygYCAACEPIAAqApAru0QAAAAAAAAUQKJEAAAAAAAA8D+gIilEMzMzMzMz4z8QtoGAgAAhECAAKwPALiEqIAAqApQrIRggACoC/CoQrYGAgAAhJCAAKgL4KhCtgYCAACElIAAqAvQqEK2BgIAAIRogACoC8CoQrYGAgAAhG0MAAIA/QwAAAAAgGSAZQwAAAABdGyIZIBlDAACAP14bu0SamZmZmZn5PxC2gYCAACErAkAgAkUNAEQAAAAAAADwPyAPoSEsRM3MzMzMzOw/IBCjIS0gGLshLiAAKwO4LiEvIAArA7AuITAgACsDqC4hMSAAKwOgLiEyIAArA/AtITMgACsD6C0hNCAAKwPgLSE1IAArA9gtITYgACsDqC0hNyAAKwOgLSE4IAArA5gtITkgACsDkC0hOiAAKwPgLCE7IAArA9gsITwgACsD0CwhPSAAKwPILCE+IAArA5gsIREgACsDkCwhECAAKwOILCEJIAArA4AsIQsgACsDyC4hDyAAKwOYLiE/IAArA5AuIUAgACsDiC4hQSAAKwOALiFCIAArA/gtIUMgACsD0C0hRCAAKwPILSFFIAArA8AtIUYgACsDuC0hRyAAKwOwLSFIIAArA4gtIUkgACsDgC0hSiAAKwP4LCFLIAArA/AsIUwgACsD6CwhTSAAKwPALCFOIAArA7gsIU8gACsDsCwhUCAAKwOoLCFRIAArA6AsIVIgACsD+CshUyAAKwPwKyFUIAArA+grIVUgACsD4CshViAAKwPYKyFXQQAhDCAHQYAEaiEOIAchCiAb/ABBAUYhIiAa/ABBAUYhIyAl/ABBAUYhISAk/ABBAUYhJiABIQggAyENAkADQEQAAAAAAAAAACBWIAsiWKIgVyAIKgIAIAoqAgAgDioCAJJDAAAAP5SSuyILoqAgVSAJoqAgVCAQIlmioSBTIBGioSIQIBCZRCNCkgyhnMc7YxshEAJAAkAgIg0AIBAhEQwBCyAAIDw5A+AsIAAgEDkDyCwgACA+OQPQLCAARAAAAAAAAAAAIBAgUqIgUSA+oqAgUCA9oqAgTyA8oqEgTiA7oqEiESARmUQjQpIMoZzHO2MbIhE5A9gsIDwhOyARITwgPiE9IBAhPgsCQAJAICMNACARIQkMAQsgACA4OQOoLSAAIBE5A5AtIAAgOjkDmC0gAEQAAAAAAAAAACARIE2iIEwgOqKgIEsgOaKgIEogOKKhIEkgN6KhIgkgCZlEI0KSDKGcxztjGyIJOQOgLSA4ITcgCSE4IDohOSARIToLICwgKyAPoaIhWgJAAkAgIQ0AIAkhEQwBCyAAIDQ5A/AtIAAgCTkD2C0gACA2OQPgLSAARAAAAAAAAAAAIAkgSKIgRyA2oqAgRiA1oqAgRSA0oqEgRCAzoqEiESARmUQjQpIMoZzHO2MbIhE5A+gtIDQhMyARITQgNiE1IAkhNgsgDyBaoCEPAkACQCAmDQAgESEJDAELIAAgMDkDuC4gACAROQOgLiAAIDI5A6guIABEAAAAAAAAAAAgESBDoiBCIDKioCBBIDGioCBAIDCioSA/IC+ioSIJIAmZRCNCkgyhnMc7YxsiCTkDsC4gMCEvIAkhMCAyITEgESEyCyAIIA8gLSApICogCaKiEMuBgIAAoiAuoqK2Ihk4AgACQCAEIAxGDQAgDSAZOAIAIBmLIhkgBSAFIAVcGyIFIAUgGSAZIBlcGyIZIAUgGV4bIQUgCkEEaiEKIA5BBGohDiAIQQRqIQggDUEEaiENIFkhESBYIQkgAiAMQQFqIgxGDQIMAQsLIAAgWTkDmCwgACAQOQOQLCAAIFg5A4gsIAAgCzkDgCwgACAPOQPILiAEIARBqJjAgAAQjoCAgAAACyAAIFk5A5gsIAAgEDkDkCwgACBYOQOILCAAIAs5A4AsIAAgDzkDyC4gBUOVv9YzXUEBcyEICyAXQQFxRQ0CIAAtAMQUIAAtAIwVciAALQDUFXIgAC0AnBZyIAAtAOQWciAALQCsF3IgAC0A9BdyIAAtALwYciAALQCEGXIgAC0AzBlyIAAtAJQaciAALQDcGnIgAC0ApBtyIAAtAOwbciAALQC0HHIgAC0A/BxyIAAtAMQdciAALQCMHnIgAC0A1B5yIAAtAJwfciAALQDkH3IgAC0ArCByIAAtAPQgciAALQC8IXIgCHJBAXENAiAAQgA3A4AsIABBAToA4S4gAEIANwOILCAAQgA3A5AsIABCADcDmCwgAEIANwPILCAAQgA3A9AsIABCADcD2CwgAEIANwPgLCAAQgA3A5AtIABCADcDmC0gAEIANwOgLSAAQgA3A6gtIABCADcD2C0gAEIANwPgLSAAQgA3A+gtIABCADcD8C0gAEIANwO4LiAAQgA3A7AuIABCADcDqC4gAEIANwOgLgJAIAJFDQAgFEUNACABQQAgFPwLAAsgBEUNAiAEQQJ0IghFDQIgA0EAIAj8CwAMAgsCQCAIKgKQAYtDYEKiDV1FDQAgCEEANgKQAQsCQCAIKgKUAYtDYEKiDV1FDQAgCEEANgKUAQsCQCAIKgKoAYtDYEKiDV1FDQAgCEEANgKoAQsCQCAIKgIwi0NgQqINXUUNACAIQQA2AjALAkAgCCoCNItDYEKiDV1FDQAgCEEANgI0CwJAIAgqAjiLQ2BCog1dRQ0AIAhBADYCOAsCQCAIKgI8i0NgQqINXUUNACAIQQA2AjwLAkAgCCoCQItDYEKiDV1FDQAgCEEANgJACwJAIAgqAkSLQ2BCog1dRQ0AIAhBADYCRAsCQCAIKgJIi0NgQqINXUUNACAIQQA2AkgLAkAgCCoCTItDYEKiDV1FDQAgCEEANgJMCwJAIAgqAlCLQ2BCog1dRQ0AIAhBADYCUAsCQCAIKgJUi0NgQqINXUUNACAIQQA2AlQLAkAgCCoCWItDYEKiDV1FDQAgCEEANgJYCwJAIAgqAlyLQ2BCog1dRQ0AIAhBADYCXAsCQCAIKgJgi0NgQqINXUUNACAIQQA2AmALAkAgCCoCZItDYEKiDV1FDQAgCEEANgJkCwJAIAgqAmiLQ2BCog1dRQ0AIAhBADYCaAsCQCAIKgJsi0NgQqINXUUNACAIQQA2AmwLIAggGDgCzAEgCCAZOALIAQJAAkACQCAZQ703hjVdRQ0AIAgoArwBIAgoArgBTw0BCyAIQQA2AsQBRAAAAAAAAAAAIQ8MAQsgCCAIKALEASACaiIMNgLEASAMuCEPCwJAIAgrA3ggEaAgD2MNAEEAIRcMAQsgCEEAOgDdAQJAIAgtANwBIgjAQQBIDQAgACAIQQN0akEANgIADAELCyAIQYABQdiYwIAAEI6AgIAAAAsgB0GACGokgICAgAALJwACQCABQQFHDQAgACACIAAqAuAqIAK8QQF0QYCAgHhJGzgC4CoLC+sbCAV/AX0Cfwd8AX8PfAZ/AX4jgICAgABB0ABrIgUkgICAgAACQAJAAkACQCAAKALYKiIGQYEBTw0AIABB2CFqIQcgBkEDdCEIQQAhBgJAA0AgCCAGRg0BIAAgBmohCSAGQQhqIQYgCUHYIWooAgAgA0cNAAsgAEEBIAMQtICAgAALQTwhBgJAIAG8IglBAXRB////d0sNAEEAQwAA/kJDAAAAACABEK2BgIAAIgogCkMAAAAAXRsiCiAKQwAA/kJeGyIKQwAAAACXQwAAf0OW/AEgCiAKXBshBgsgBUEIaiAHIAMgBhCfgICAAAJAIAUtAAhFDQAgACAFLQAJEI+AgIAAC0E8IQsCQCAJQQF0Qf///3dLDQBBAEMAAP5CQwAAAAAgARCtgYCAACIKIApDAAAAAF0bIgogCkMAAP5CXhsiCkMAAAAAl0MAAH9DlvwBIAogClwbIQsLRAAAAAAAAFhARAAAAAAAADhAIAtB/wFxIgy4Ig0gDUQAAAAAAAA4QGMbIg0gDUQAAAAAAABYQGQbIg5EAAAAAAAAPcCgIg1EzczMzMxMNMCjEMWBgIAAIQ8gDUQAAAAAAAAsQKMQxYGAgAAhDUMAAP5CQwAAAAAgASABQwAAAABdGyIBIAFDAAD+Ql4bu0QAAAAAAEBRwKBEAAAAAAAAKECjEMWBgIAAIRACQAJAAkAgC8BBAEgNACANRPFo44i1+PQ+oiERIBBEAAAAAACAe0CiIRIgACsD0CEhEyAAIAxBDGxqIgZBgAhqIQcgBigCgAhFDQEgBygCBCEUIAcqAgghCgwCCyAMQYABQeyNwIAAEI6AgIAAAAtEAAAAAAAAKEBEAAAAAACIs0AgE0SamZmZmZnZP6IiDSANIA1iGyINRAAAAAAAiLNAIA1EAAAAAACIs0BjGyASo5wiDSANIA1iGyINRAAAAAAAAChAIA1EAAAAAAAAKEBjGyENAkACQCASRAAAAAAAAE5AY0UNAEEIIQgMAQsCQCASRAAAAAAAAF5AY0UNAEEGIQgMAQsCQCASRAAAAAAAQG9AY0UNAEEEIQgMAQsCQCASRAAAAAAAQH9AY0UNAEEDIQgMAQsCQCASRAAAAAAAQI9AY0UNAEECIQgMAQsgEkQAAAAAACCcQGMhCAtDAAAAACEKQQAhFAJAIA1EAAAAAAAAAEBjDQAgEUQAAAAAAAAAAGUNACAIRQ0AIA0gDSANIBGiokQAAAAAAADwP6AgEUQAAAAAAADwP6Cjn6IhFSANRBgtRFT7IRlAoiEWRAAAAAAAAABAIBJEGC1EVPshGUCiIBOjIhejIRhEGC1EVPshGUAgF6MiGUQAAAAAAAAIwKAhGiAXIA1EAAAAAAAA4D+ioiEbIBcQqYGAgAAhHCAXEKeBgIAAIR0CQANAIAi4IR5BACEDRAAAAAAAAAAAIR9EZmZmZmZm7r8hIANAIBlEAAAAAAAA8D8gGCAdICAgH6BEAAAAAAAA4D+iIiGiIBwgIaJEAAAAAAAA8D+goxDNgYCAAKKhIB6ioSEiRDyK1jqMGwlAIRBBMCEGIBshIwNAIBAgI6BEAAAAAAAA4D+iIQ0gDSAQIA0gIiAhIA0Qp4GAgACiICEgDRCpgYCAAKJEAAAAAAAA8D+goxDNgYCAAEQAAAAAAAAAwCANo6JEAAAAAAAA8D+gIB6ioKIgFmQiCRshECAjIA0gCRshIyAGQX9qIgYNAAsgICAhICMgEKBEAAAAAAAA4D+iIBejIBVjIgYbISAgISAfIAYbIR8gA0EBaiIDQShHDQALAkBEAAAAAAAA8D8gGCAdIB8gIKBEAAAAAAAA4D+iIg2iIBwgDaJEAAAAAAAA8D+goxDNgYCAAKKhIB6iIBpjRQ0AIAghFAwCCyAIQX9qIggNAAtEAAAAAAAAAAAhDUEAIRQLIA22IQoLIAcgCjgCCCAHIBQ2AgQgB0EBNgIACwJAAkACQAJAAkACQAJAIAAgDEEDdGoiJCgCAEEBRw0AICQoAgQiBiAAKALYLiIlTw0IQQAhCSAAKALULiImIAZB4AFsai0A3QENBiAmICVB4AFsaiEHDAELIAAoAtguIiVFDQEgACgC1C4iJiAlQeABbGohBwtBACEGICYhCQNAIAlB3QFqLQAAQQFHDQQgBkEBaiEGIAlB4AFqIgkgB0cNAAsgAEHYKWohDEEAIQZBACEDICYhCQJAAkACQANAIAlB3AFqLAAAIghB/wFxIScgCEF/TA0BIAYgJU8NAiAmIAZB4AFsaiIoLADcASIIQf8BcSEpIAhBf0wNAyAMIClqLQAAIQgCQAJAAkAgDCAnai0AAEH/AXEiJw0AIAhB/wFxDQELICdBAEcgCEH/AXFBAEdzDQEgCUHIAWoqAgAgKCoCyAFdRQ0BCyADIQYLIANBAWohAyAJQeABaiIJIAdHDQALIAYgJU8NBCAmIAZB4AFsaiIILADcASIDQf8BcSEJIANBf0oNBSAJQYABQeyOwIAAEI6AgIAAAAsgJ0GAAUGsjsCAABCOgICAAAALIAYgJUG8jsCAABCOgICAAAALIClBgAFBzI7AgAAQjoCAgAAAC0EAIQZBACElCyAGICVB3I7AgAAQjoCAgAAACyAIQQA6AN0BIAAgCUEDdGpBADYCAAsgJCAGNgIEQQEhCSAkQQE2AgALIAAgACkDyCtCAXwiKjcDyCtEAAAAAAAA8D9EAAAAAAAAAAAgBLtEAAAAAAAA4D+iIAAqAoQru6AiDSANRAAAAAAAAAAAYxsiDSANRAAAAAAAAPA/ZBsiHUQAAAAAAADgv6BEAAAAAAAA+L+iEMWBgIAAISMgDkQAAAAAAABOwKBEAAAAAAAATsCjEMWBgIAAIQ0gBiAlTw0CRM3MzMzMzNw/RDMzMzMzM7M/IA9EzczMzMzM7D+iIiGjIhAgECAQYhsiEETNzMzMzMzcPyAQRM3MzMzMzNw/YxshFkQzMzMzMzPTP0TsUbgeheuhPyAhoyIQIBAgEGIbIhBEMzMzMzMz0z8gEEQzMzMzMzPTP2MbIR9EAAAAAAAA8D9DAACAP0MAAAAAIAIgAkMAAAAAXRsiASABQwAAgD9eG7siHCAcRAAAAAAAAPA/ZBtEmpmZmZmZ+b+iRAAAAAAAAABAoCAjRGEyVTAqqTM/oqIhECAmIAZB4AFsaiEIIAlFDQMgCCALOgDcASAIQQE6AN0BIAhBMGohCQJAIAgoArQBIgNFDQAgA0ECdCIDRQ0AIAgoArABQQAgA/wLAAsgCEEANgKoASAIQgA3A5ABIAhBADYChAEgCUIANwMAIAlCADcDCCAJQgA3AxAgCUIANwMYIAlCADcDICAJQgA3AyggCUIANwMwIAlCADcDOCAIIAo4ApwBIAggFDYCmAEgCCASOQNwDAMLQQAgBkGAAUHAksCAABCWgICAAAALIAYgJUH8jcCAABCOgICAAAALIAYgJUGMjsCAABCOgICAAAALIA0gEKIhFyANRNsAM9/BTyw/oiEiIAhBADoA3gEgCEEANgLEASAIICo3AwAgCCAWOQMQIAggHzkDCEQAAAAAAHDHQCATRM3MzMzMzNw/oiINIA0gDWIbIg1EAAAAAABwx0AgDUQAAAAAAHDHQGMbISAgEUQAAAAAAADwP6AhGEQAAAAAAAAAACEjQQEhCQJAA0AgEiARIAm4Ig2iIA2iRAAAAAAAAPA/oCAYo58gDaIiIaIiDSAgZA0BRBgtRFT7Iek/IRACQEQAAAAAAADwPyAiIA0gDaCiIh4gHqKhIh6ZRI3ttaD3xrA+Yw0AICIgDUQYLURU+yEJQKKiEKmBgIAAIB6jmSEQCyAWICFEGC1EVPshCUCiIiGiEKeBgIAAIQ0gIyAfICGiEKeBgIAAIiEgIaAgDSANoKAgEKIiDSANoqAhIyAJQQFqIglB0QBHDQALCyAIRClcj8L1KMw/RI3ttaD3xrA+ICOfIg0gDSANYhsiDUSN7bWg98awPiANRI3ttaD3xrA+ZBujtjgCwAECQCAIKALYASIJQQFLDQAgBUECNgJIIAUgCTYCTCAFQYaAgIAArUIghiIqIAVBzABqrYQ3AxggBSAqIAVByABqrYQ3AxBBz4HAgAAgBUEQakGcjsCAABCJgICAAAALAkBBAiATIBei/AMiAyAJIAMgCUkbIANBAkkbIgxFDQAgHEQYLURU+yEJQKIgEyASo6IgDEECdCIDuKMhECAMuCEjIAgoAtQBIQkCQAJAIANBfGoiJw0AQQAhAwwBCyAnQQJ2QQFqQf7///8HcSEHQQAhA0QAAAAAAAAAACENA0AgCSAQIA1EAAAAAAAA4D+gRBgtRFT7IQlAoiAjoxCngYCAAKK2OAIAIAlBBGogECADQQFquEQAAAAAAADgP6BEGC1EVPshCUCiICOjEKeBgIAAorY4AgAgCUEIaiEJIA1EAAAAAAAAAECgIQ0gByADQQJqIgNHDQALICdBBHENAQsgCSAQIAO4RAAAAAAAAOA/oEQYLURU+yEJQKIgI6MQp4GAgACitjgCAAsgCEEANgK8ASAIIAw2ArgBIABBADoA4S4gACAGEI2AgIAAIAVCADcDKCAFQoCAgICAgNbVwAA3AyAgBUL7qLi9lNyesj83AxggBSAcRPyp8dJNYnA/oiAcoiAdRAAAAAAAAOA/oKI5AxAgBUIANwMwIAVCADcDOCAFQgA3A0AgAEGAFGogBUEQahCQgICAACAFQdAAaiSAgICAAAvxBQEJfwJAAkACQAJAAkACQAJAAkAgAUEBRw0AQQQhA0EEEJKAgIAAIgRFDQcgBCACNgIADAELIAAoAtgqIgVBgQFPDQUgBUUNASAFQQJ0IgEQkoCAgAAiBEUNBCAFQQNxIQZBACEHAkACQCAFQQRJDQAgBUECdkE/cSIBQQJ0IQcgAUEFdCEIQQAhCSAEIQEDQCABIAAgCWoiAkHYIWooAgA2AgAgAUEEaiACQeAhaigCADYCACABQQhqIAJB6CFqKAIANgIAIAFBDGogAkHwIWooAgA2AgAgAUEQaiEBIAggCUEgaiIJRw0ACyAGRQ0BCyAEIAdBAnRqIQEgB0EDdCAAakHYIWohAgNAIAEgAigCADYCACACQQhqIQIgAUEEaiEBIAZBf2oiBg0ACwsgBUECdCEDCyAAQdgpaiEKIABB2CFqIQsgBCADaiEHIAQhBQNAAkACQAJAIAAoAtgqIghBgQFPDQAgCEUNAiAFKAIAIQYgCEEDdCEJQQAhAUEAIQICQANAIAAgAWpB2CFqKAIAIAZGDQEgAkEBaiECIAkgAUEIaiIBRw0ADAQLCyALIAJBA3RqIgYtAAQhAQJAIAggAkEBaiICa0EDdCIJRQ0AIAYgCyACQQN0aiAJ/AoAAAsgACAAKALYKkF/ajYC2CogAcAiAkF/TA0BIAogAWoiASABLQAAIgEgAUEAR2s6AAAgAUECTw0CIAAgAhCPgICAAAwCC0EAIAhBgAFBgJPAgAAQloCAgAAACyABQYABQfCSwIAAEI6AgIAAAAsgBUEEaiIFIAdHDQALIARBfGooAgAiAUF4cSICQQRBCCABQQNxIgEbIANqSQ0BAkAgAUUNACACIANBJ2pLDQMLIAQQgYCAgAALDwtBgLPAgABBLkGws8CAABCCgICAAAALQcCzwIAAQS5B8LPAgAAQgoCAgAAAC0EEIAEQk4CAgAAAC0EAIAVBgAFBsJLAgAAQloCAgAAAC0EEQQQQmoCAgAAAC9UQBgF/BH0HfAF9An8BfiOAgICAAEEgayICJICAgIAAIAAqAogrIQMgASoCICEEIAAqAoArIQUgASoCGCEGIABB6CpqIAFB4AD8CgAAIAAtAOAuIQEgAEEBOgDgLgJAAkAgACsD0CEiB0TNzMzMzMzcP6IiCEQAAAAAAAAUQGZFDQAgAEQAAAAAAADwPyAIRAAAAAAAQH9AIAhEAAAAAABAf0BjG0QYLURU+yEZQKIgB6MiCRCngYCAACIKoSAKRAAAAAAAAPA/oCIKozkDiC0gACAJEKmBgIAAIgtEAAAAAAAAAMCiIAqjOQOALSAARAAAAAAAAPA/IAhEAAAAAAAgjEAgCEQAAAAAACCMQGMbRBgtRFT7IRlAoiAHoyIMEKeBgIAARJqZmZmZmfE/oyIJoSAJRAAAAAAAAPA/oCIJozkDmC4gACAMEKmBgIAAIgxEAAAAAAAAAMCiIAmjOQOQLiAARAAAAAAAAPA/IAyhIgxEAAAAAAAA4D+iIAmjIg05A4guIAAgDCAJozkDgC4gACANOQP4LSAARAAAAAAAAPA/IAhEAAAAAADAokAgCEQAAAAAAMCiQGMbRBgtRFT7IRlAoiAHoyIMEKeBgIAARDMzMzMzM/M/oyIJoSAJRAAAAAAAAPA/oCIJozkD0C0gACAMEKmBgIAAIgxEAAAAAAAAAMCiIAmjOQPILSAARAAAAAAAAPA/IAyhIgxEAAAAAAAA4D+iIAmjIg05A8AtIAAgDCAJozkDuC0gACANOQOwLSAAIAtEAAAAAAAA8D+gIglEAAAAAAAA4D+iIAqjIgs5A/gsIAAgCZogCqM5A/AsIAAgCzkD6CwgAEQAAAAAAADwPyAIRAAAAAAA4JVAIAhEAAAAAADglUBjG0QYLURU+yEZQKIgB6MiCRCngYCAAESamZmZmZnxP6MiCqEgCkQAAAAAAADwP6AiCqM5A8AsIAAgCRCpgYCAACIJRAAAAAAAAADAoiAKozkDuCwgACAJRAAAAAAAAPA/oCIJRAAAAAAAAOA/oiAKoyILOQOwLCAAIAmaIAqjOQOoLCAAIAs5A6AsIABEAAAAAAAA8D8gCEQAAAAAAAA+QCAIRAAAAAAAAD5AYxtEGC1EVPshGUCiIAejIgcQp4GAgABEMzMzMzMz8z+jIgihIAhEAAAAAAAA8D+gIgijOQP4KyAAIAcQqYGAgAAiB0QAAAAAAAAAwKIgCKM5A/ArIAAgB0QAAAAAAADwP6AiB0QAAAAAAADgP6IgCKMiCjkD6CsgACAHmiAIozkD4CsgACAKOQPYKyAAKgL0KhCtgYCAACEOIABEAAAAAAAAJEBEAAAAAAAAGEBEAAAAAAAAAAAgACoC8CoQrYGAgAD8AEEBRhsiCEQAAAAAAAAEQKAgCCAO/ABBAUYbIghEAAAAAAAA8D+gIAggACoC+CoQrYGAgAD8AEEBRhsiCEQAAAAAAAAIQKAgCCAAKgL8KhCtgYCAAPwAQQFGG0QAAAAAAAA0QKMQtoGAgAA5A8AuAkAgBiAFXCAEIANcckEBRw0AIAFBAXFFDQACQCAAKALYLiIBDQBBACEPDAMLAkAgACgC1C4iEC0A3QFFDQAgAEEAEI2AgIAAC0EBIQ8gAUEBRg0CAkAgEC0AvQNBAUcNACAAQQEQjYCAgAALQQIhDyABQQJGDQICQCAQLQCdBUEBRw0AIABBAhCNgICAAAtBAyEPIAFBA0YNAgJAIBAtAP0GQQFHDQAgAEEDEI2AgIAAC0EEIQ8gAUEERg0CAkAgEC0A3QhBAUcNACAAQQQQjYCAgAALQQUhDyABQQVGDQICQCAQLQC9CkEBRw0AIABBBRCNgICAAAtBBiEPIAFBBkYNAgJAIBAtAJ0MQQFHDQAgAEEGEI2AgIAAC0EHIQ8gAUEHRg0CAkAgEC0A/Q1BAUcNACAAQQcQjYCAgAALQQghDyABQQhGDQICQCAQLQDdD0EBRw0AIABBCBCNgICAAAtBCSEPIAFBCUYNAgJAIBAtAL0RQQFHDQAgAEEJEI2AgIAAC0EKIQ8gAUEKRg0CAkAgEC0AnRNBAUcNACAAQQoQjYCAgAALQQshDyABQQtGDQICQCAQLQD9FEEBRw0AIABBCxCNgICAAAtBDCEPIAFBDEYNAgJAIBAtAN0WQQFHDQAgAEEMEI2AgIAAC0ENIQ8gAUENRg0CAkAgEC0AvRhBAUcNACAAQQ0QjYCAgAALQQ4hDyABQQ5GDQICQCAQLQCdGkEBRw0AIABBDhCNgICAAAtBDyEPIAFBD0YNAgJAIBAtAP0bQQFHDQAgAEEPEI2AgIAAC0EQIQ8gAUEQRg0CAkAgEC0A3R1BAUcNACAAQRAQjYCAgAALQREhDyABQRFGDQICQCAQLQC9H0EBRw0AIABBERCNgICAAAtBEiEPIAFBEkYNAgJAIBAtAJ0hQQFHDQAgAEESEI2AgIAAC0ETIQ8gAUETRg0CAkAgEC0A/SJBAUcNACAAQRMQjYCAgAALQRQhDyABQRRGDQICQCAQLQDdJEEBRw0AIABBFBCNgICAAAtBFSEPIAFBFUYNAgJAIBAtAL0mQQFHDQAgAEEVEI2AgIAAC0EWIQ8gAUEWRg0CAkAgEC0AnShBAUcNACAAQRYQjYCAgAALQRchDyABQRdGDQIgEC0A/SlBAUcNACAAQRcQjYCAgAALIAJBIGokgICAgAAPCyACQoCAgICAgICKwAA3AwAgAiAIOQMIIAJBgoCAgACtQiCGIhEgAkEIaq2ENwMYIAIgESACrYQ3AxBB7YHAgAAgAkEQakHoisCAABCJgICAAAALIA8gAUHomMCAABCOgICAAAALDwAgAC0AsdMBQX9zQQFxC5gKAQJ/IABBADoAhagBIABBADoAjaUBIABBADoAlaIBIABBADoAnZ8BIABBADoApZwBIABBADoArZkBIABBADoAtZYBIABBADoAvZMBIABBADoAxZABIABBADoAzY0BIABBADoA1YoBIABBADoA3YcBIABBADoA5YQBIABBADoA7YEBIABBADoA9X4gAEEAOgD9eyAAQQA6AIV5IABBADoAjXYgAEEAOgCVcyAAQQA6AJ1wIABBADoApW0gAEEAOgCtaiAAQQA6ALVnIABBADoAvWQgAEEAOgDFYSAAQQA6AM1eIABBADoA1VsgAEEAOgDdWCAAQQA6AOVVIABBADoA7VIgAEEAOgD1TyAAQQA6AP1MIABBADoAhUogAEEAOgCNRyAAQQA6AJVEIABBADoAnUEgAEEAOgClPiAAQQA6AK07IABBADoAtTggAEEAOgC9NSAAQQA6AMUyIABBADoAzS8gAEEAOgDVLCAAQQA6AN0pIABBADoA5SYgAEEAOgDtIyAAQQA6APUgIABBADoA/R0gAEHwsAFqQQBBhAH8CwBBgHghAQNAIAAgAWoiAkG4CGpBADYCACACQbAIakEANgIAIAJBqAhqQQA2AgAgAkGgCGpBADYCACACQZgIakEANgIAIAJBkAhqQQA2AgAgAkGICGpBADYCACACQYAIakEANgIAIAFBwABqIgENAAsgAEKAgICAgICA+D83A7i9ASAAQQA6APQaIABBADoArBogAEEAOgDkGSAAQQA6AJwZIABBADoA1BggAEEAOgCMGCAAQQA6AMQXIABBADoA/BYgAEEAOgC0FiAAQQA6AOwVIABBADoApBUgAEEAOgDcFCAAQQA6AJQUIABBADoAzBMgAEEAOgCEEyAAQQA6ALwSIABBADoA9BEgAEEAOgCsESAAQQA6AOQQIABBADoAnBAgAEEAOgDUDyAAQQA6AIwPIABBADoAxA4gAEEAOgD8DSAAQei/AWpBAEGYAfwLACAAQgA3A+gIIABCADcDkMEBIABCADcD8AggAEIANwP4CCAAQgA3A4AJIABCADcDsAkgAEIANwO4CSAAQgA3A8AJIABCADcDyAkgAEIANwP4CSAAQgA3A4AKIABCADcDiAogAEIANwOQCiAAQgA3A8AKIABCADcDyAogAEIANwPQCiAAQgA3A9gKIABCADcDoAsgAEIANwOYCyAAQgA3A5ALIABCADcDiAsgAEIANwPoCyAAQgA3A+ALIABCADcD2AsgAEIANwPQCyAAQgA3A7AMIABCADcDuAwgAEIANwPADCAAQgA3A8gMIABBwL0BakEAQaAC/AsAIABCADcD2MEBIABCADcD0MEBIABCADcDyMEBIABCADcDwMEBIABCADcDoMIBIABCADcDqMIBIABCADcDsMIBIABCADcDuMIBIABCADcD6MIBIABCADcD8MIBIABCADcD+MIBIABCADcDgMMBAkAgACgCmA0iAkUNACACQQJ0IgJFDQAgACgClA1BACAC/AsACwJAIAAoAqQNIgJFDQAgAkECdCICRQ0AIAAoAqANQQAgAvwLAAsgAEIANwOYCCAAQgA3A5AIIABCADcDiAggAEIANwOACCAAQgA3A7DDASAAQgA3A7jDASAAQgA3A8DDASAAQgA3A8jDASAAQgA3A/jDASAAQgA3A4DEASAAQgA3A4jEASAAQgA3A5DEASAAQQE6ALHTASAAQgA3A/DBAQvzdRECfwJ9AX8EfAF/BHwBfwF9AnwIfwF9DX8CfQZ/A30DfxF8I4CAgIAAQeAQayIHJICAgIAAAkAgAkUNACACQQJ0IghFDQAgAUEAIAj8CwALAkAgBEUNACAEQQJ0IghFDQAgA0EAIAj8CwALIAAtANTSASEIIAAqAvyxASEJIAAqAtSoARCtgYCAACEKAkAgCEEBRw0AAkAgBSAAKgKIygGTi0MK1yM8XQ0AIAAgBTgCiMoBIABB4LcBaiELIAArA4ioASEMQRghCCAFu0QAAAAAAMCSQKMQxYGAgAAhDQNAIAi4Ig5EhetRuB6F4z+iEKeBgIAAIQ8gDkSuR+F6FK77P6IQp4GAgAAhDiALIA0gCEG7f2q3RAAAAAAAAChAoxDFgYCAAEQAAAAAAIB7QKIgDkTNzMzMzMzsP6IgD0SamZmZmZnZP6KgRAAAAAAAwJJAoxDFgYCAAKKiIAyjOQMAIAtBCGohCyAIQQFqIghB8wBHDQALCyAK/AAhEAJAIAAtAP0dDQAgAC0A9SBBAXENACAALQDtI0EBcQ0AIAAtAOUmQQFxDQAgAC0A3SlBAXENACAALQDVLEEBcQ0AIAAtAM0vQQFxDQAgAC0AxTJBAXENACAALQC9NUEBcQ0AIAAtALU4QQFxDQAgAC0ArTtBAXENACAALQClPkEBcQ0AIAAtAJ1BQQFxDQAgAC0AlURBAXENACAALQCNR0EBcQ0AIAAtAIVKQQFxDQAgAC0A/UxBAXENACAALQD1T0EBcQ0AIAAtAO1SQQFxDQAgAC0A5VVBAXENACAALQDdWEEBcQ0AIAAtANVbQQFxDQAgAC0AzV5BAXENACAALQDFYUEBcQ0AIAAtAL1kQQFxDQAgAC0AtWdBAXENACAALQCtakEBcQ0AIAAtAKVtQQFxDQAgAC0AnXBBAXENACAALQCVc0EBcQ0AIAAtAI12QQFxDQAgAC0AhXlBAXENACAALQD9e0EBcQ0AIAAtAPV+QQFxDQAgAC0A7YEBQQFxDQAgAC0A5YQBQQFxDQAgAC0A3YcBQQFxDQAgAC0A1YoBQQFxDQAgAC0AzY0BQQFxDQAgAC0AxZABQQFxDQAgAC0AvZMBQQFxDQAgAC0AtZYBQQFxDQAgAC0ArZkBQQFxDQAgAC0ApZwBQQFxDQAgAC0AnZ8BQQFxDQAgAC0AlaIBQQFxDQAgAC0AjaUBQQFxDQAgAC0AhagBQQFxDQAgAC0AsdMBQQFxRQ0AIAAtAPwNDQAgAC0AxA5BAXENACAALQCMD0EBcQ0AIAAtANQPQQFxDQAgAC0AnBBBAXENACAALQDkEEEBcQ0AIAAtAKwRQQFxDQAgAC0A9BFBAXENACAALQC8EkEBcQ0AIAAtAIQTQQFxDQAgAC0AzBNBAXENACAALQCUFEEBcQ0AIAAtANwUQQFxDQAgAC0ApBVBAXENACAALQDsFUEBcQ0AIAAtALQWQQFxDQAgAC0A/BZBAXENACAALQDEF0EBcQ0AIAAtAIwYQQFxDQAgAC0A1BhBAXENACAALQCcGUEBcQ0AIAAtAOQZQQFxDQAgAC0ArBpBAXENACAALQD0GkEBcQ0ARM3MzMzMzBZARHE9CtejcOU/IAlDAAAAP2AiCBtEAAAAAAAAAAAgEEEBRiILGyEOIAAgDiAAKwPoDCIMIA6hIAK4Ig2aIhEgACsDgAwiD0TNzMzMzMz8P0TNzMzMzMwEQCAOIAxkG6KjELKBgIAAoqAiEjkD6AxEAAAAAAAAG0BEj8L1KFyP6j8gCBtEAAAAAAAAAAAgCxshDiAAIA4gACsD4AwiEyAOoSARIA9EZmZmZmZm1j9EmpmZmZmZ4T8gDiATZBuioxCygYCAAKKgIg45A+AMIAAgACsD0AwgEyAOoEQYLURU+yEJQKIgDaIgD6OgRBgtRFT7IRlAELCBgIAAOQPQDCAAIAArA9gMIAwgEqBEGC1EVPshCUCiIA2iIA+joEQYLURU+yEZQBCwgYCAADkD2AwMAQsgACsDiKgBIRQCQAJAAkAgACoCtKgBEK2BgIAA/AAiFUEBRw0AIAAqAsCoASIWEK2BgIAA/ABFDQELRAAAAAAAAAAAIQ5EAAAAAAAAAAAhDwJAQwAAAEFDAAAAACAAKgKQqAEQrYGAgAAiBSAFQwAAAABdGyIFIAVDAAAAQV4bIgVDAAAAAF5FDQBEAAAAAAAAJEBEAAAAAAAAIEAgBbuhRAAAAAAAAAjAokQAAAAAAAA0QKMQtoGAgAAhDwsCQEMAAABBQwAAAAAgACoClKgBEK2BgIAAIgUgBUMAAAAAXRsiBSAFQwAAAEFeGyIFQwAAAABeRQ0ARAAAAAAAACRARAAAAAAAACBAIAW7oUQAAAAAAAAIwKJEAAAAAAAANECjELaBgIAAIQ4LRAAAAAAAAAAAIQxEAAAAAAAAAAAhDQJAQwAAAEFDAAAAACAAKgKYqAEQrYGAgAAiBSAFQwAAAABdGyIFIAVDAAAAQV4bIgVDAAAAAF5FDQBEAAAAAAAAJEBEAAAAAAAAIEAgBbuhRAAAAAAAAAjAokQAAAAAAAA0QKMQtoGAgAAhDQsCQEMAAABBQwAAAAAgACoCnKgBEK2BgIAAIgUgBUMAAAAAXRsiBSAFQwAAAEFeGyIFQwAAAABeRQ0ARAAAAAAAACRARAAAAAAAACBAIAW7oUQAAAAAAAAIwKJEAAAAAAAANECjELaBgIAAIQwLRAAAAAAAAAAAIRNEAAAAAAAAAAAhEgJAQwAAAEFDAAAAACAAKgKgqAEQrYGAgAAiBSAFQwAAAABdGyIFIAVDAAAAQV4bIgVDAAAAAF5FDQBEAAAAAAAAJEBEAAAAAAAAIEAgBbuhRAAAAAAAAAjAokQAAAAAAAA0QKMQtoGAgAAhEgsCQEMAAABBQwAAAAAgACoCpKgBEK2BgIAAIgUgBUMAAAAAXRsiBSAFQwAAAEFeGyIFQwAAAABeRQ0ARAAAAAAAACRARAAAAAAAACBAIAW7oUQAAAAAAAAIwKJEAAAAAAAANECjELaBgIAAIRMLRAAAAAAAAAAAIRdEAAAAAAAAAAAhGAJAQwAAAEFDAAAAACAAKgKoqAEQrYGAgAAiBSAFQwAAAABdGyIFIAVDAAAAQV4bIgVDAAAAAF5FDQBEAAAAAAAAJEBEAAAAAAAAIEAgBbuhRAAAAAAAAAjAokQAAAAAAAA0QKMQtoGAgAAhGAsCQEMAAABBQwAAAAAgACoCrKgBEK2BgIAAIgUgBUMAAAAAXRsiBSAFQwAAAEFeGyIFQwAAAABeRQ0ARAAAAAAAACRARAAAAAAAACBAIAW7oUQAAAAAAAAIwKJEAAAAAAAANECjELaBgIAAIRcLRAAAAAAAAAAAIRECQEMAAABBQwAAAAAgACoCsKgBEK2BgIAAIgUgBUMAAAAAXRsiBSAFQwAAAEFeGyIFQwAAAABeRQ0ARAAAAAAAACRARAAAAAAAACBAIAW7oUQAAAAAAAAIwKJEAAAAAAAANECjELaBgIAAIRELIBFEAAAAAAAAAAAgFUEBRxshESAAKgLAqAEhFgwBC0QAAAAAAAAAACEORAAAAAAAAAAAIQ8CQEMAAABBQwAAAAAgACoCkKgBEK2BgIAAIgUgBUMAAAAAXRsiBSAFQwAAAEFeGyIFQwAAAABeRQ0ARAAAAAAAACRARAAAAAAAACBAIAW7oUQAAAAAAAAIwKJEAAAAAAAANECjELaBgIAARLgehetRuOY/oiEPCwJAQwAAAEFDAAAAACAAKgKUqAEQrYGAgAAiBSAFQwAAAABdGyIFIAVDAAAAQV4bIgVDAAAAAF5FDQBEAAAAAAAAJEBEAAAAAAAAIEAgBbuhRAAAAAAAAAjAokQAAAAAAAA0QKMQtoGAgABEuB6F61G45j+iIQ4LRAAAAAAAAAAAIQxEAAAAAAAAAAAhDQJAQwAAAEFDAAAAACAAKgKYqAEQrYGAgAAiBSAFQwAAAABdGyIFIAVDAAAAQV4bIgVDAAAAAF5FDQBEAAAAAAAAJEBEAAAAAAAAIEAgBbuhRAAAAAAAAAjAokQAAAAAAAA0QKMQtoGAgABEuB6F61G45j+iIQ0LAkBDAAAAQUMAAAAAIAAqApyoARCtgYCAACIFIAVDAAAAAF0bIgUgBUMAAABBXhsiBUMAAAAAXkUNAEQAAAAAAAAkQEQAAAAAAAAgQCAFu6FEAAAAAAAACMCiRAAAAAAAADRAoxC2gYCAAES4HoXrUbjmP6IhDAtEAAAAAAAAAAAhE0QAAAAAAAAAACESAkBDAAAAQUMAAAAAIAAqAqCoARCtgYCAACIFIAVDAAAAAF0bIgUgBUMAAABBXhsiBUMAAAAAXkUNAEQAAAAAAAAkQEQAAAAAAAAgQCAFu6FEAAAAAAAACMCiRAAAAAAAADRAoxC2gYCAAES4HoXrUbjmP6IhEgsCQEMAAABBQwAAAAAgACoCpKgBEK2BgIAAIgUgBUMAAAAAXRsiBSAFQwAAAEFeGyIFQwAAAABeRQ0ARAAAAAAAACRARAAAAAAAACBAIAW7oUQAAAAAAAAIwKJEAAAAAAAANECjELaBgIAARLgehetRuOY/oiETC0QAAAAAAAAAACERRAAAAAAAAAAAIRgCQEMAAABBQwAAAAAgACoCqKgBEK2BgIAAIgUgBUMAAAAAXRsiBSAFQwAAAEFeGyIFQwAAAABeRQ0ARAAAAAAAACRARAAAAAAAACBAIAW7oUQAAAAAAAAIwKJEAAAAAAAANECjELaBgIAARLgehetRuOY/oiEYCwJAQwAAAEFDAAAAACAAKgKsqAEQrYGAgAAiBSAFQwAAAABdGyIFIAVDAAAAQV4bIgVDAAAAAF4NAEQAAAAAAAAAACEXDAELRAAAAAAAACRARAAAAAAAACBAIAW7oUQAAAAAAAAIwKJEAAAAAAAANECjELaBgIAARLgehetRuOY/oiEXCyAAQYgbaiEZIAcgETkDSCAHIBc5A0AgByAYOQM4IAcgEzkDMCAHIBI5AyggByAMOQMgIAcgDTkDGCAHIA45AxAgByAPOQMIIAAqArioASEFIAAqAsyoASEKIABB1tIBaiIaQQBB2wD8CwAgAEGMygFqIhtBAEHsAvwLAEQAAAAAAADwP0QAAAAAAAAAACAKuyIOIA5EAAAAAAAAAABjGyIOIA5EAAAAAAAA8D9kGyEPQRNBDCAFEK2BgIAA/AAbIhxBC2ohHUGIGyEeIBVBAUchHyAAISADQAJAIB5BiKgBRw0AQ2Zmpj9DZmYmQCAWEK2BgIAA/AAbISEgAkECdCEiIABBnMcBaiEjIABBsMQBaiEkIABBiLIBaiEeIABB4LcBaiElIAK4IRhBACEmA0AgJSAmQQN0IghqKwMAIQ0CQAJAIBogJmotAAANACAeIAhqIgggDSAYoiAIKwMAoCIOIA6doSAOpjkDAAwBCwJAAkACQAJAAkACQAJAICZBB3QiCyACaiInIAAoAqzEASIoSw0AIB4gCGoiKSsDACEOIAJFDQUgJCAmQQJ0IghqKgIAQwAAAAAgGyAIaioCAEMAAIC/kiIFIAUgBVwbIgVDAAAAACAFQwAAAABeG0OPwvU8lEMAAIA/kpUhBSAAKAKoxAEgC0ECdGohCyAAKAKgxAEhJyAAKAKcxAEhKCAjIAhqKgIAIhZDAAAAAF4NASAiIR8DQCAORAAAAAAAALBAoiIM/AMiCEH/HyAIQf8fSRsiCCAnTw0DIAhBAWoiKiAnTw0HIAsgBSAoIAhBAnRqKgIAIgogKCAqQQJ0aioCACAKkyAMIAi4obaUkpQ4AgAgDSAOoCIORAAAAAAAAPC/oCAOIA5EAAAAAAAA8D9mGyEOIAtBBGohCyAfQXxqIh8NAAwGCwsgCyAnIChB7JDAgAAQloCAgAAACyAiISADQCAORAAAAAAAALBAoiIT/AMiCEH/HyAIQf8fSRsiCCAnTw0BIAhBAWoiKiAnTw0FIA5EAAAAAAAACECiIgwgDJ2hIAymRAAAAAAAALBAoiIM/AMiH0H/HyAfQf8fSRsiHyAnTw0CIB9BAWoiKyAnTw0DIAsgBSAoIAhBAnRqKgIAIgogKCAqQQJ0aioCACAKkyATIAi4obaUkiAWICggH0ECdGoqAgAiCiAoICtBAnRqKgIAIAqTIAwgH7ihtpSSlJKUOAIAIA0gDqAiDkQAAAAAAADwv6AgDiAORAAAAAAAAPA/ZhshDiALQQRqIQsgIEF8aiIgDQAMBAsLIAggJ0GQk8CAABCOgICAAAALIB8gJ0GQk8CAABCOgICAAAALICsgJ0Ggk8CAABCOgICAAAALICkgDjkDAAwBCyAqICdBoJPAgAAQjoCAgAAACyAmQQFqIiZB2wBHDQALIAAqAryoASEFIAdB0ABqQQBBgAT8CwAgBRCtgYCAACEFRAAAAAAAAPC/IBREexSuR+F6hD+ioxCygYCAACEOIAAoAvCxASELRAAAAAAAAPC/IBREmpmZmZmZ4T9EMzMzMzMzwz8gBfwAG6KjELKBgIAAIQwCQCACQYEBSQ0AQQAgAkGAAUHwmcCAABCWgICAAAALAkAgAkUNAEQAAAAAAADwPyAOoSENIAArA7i9ASEOAkACQCAiQXxqIihBAnZBAWpBA3EiCA0AIAdB0ABqIQgMAQsgCEECdCEnIAdB0ABqIQgDQCAIIA62OAIAIAwgDqIgDiANRAAAAAAAAPA/IA6hoqAgCxshDiAIQQRqIQggJ0F8aiInDQALCwJAIChBDEkNACAHQdAAaiAiaiEnA0AgCCAOtjgCACAIQQRqIAwgDqIiEyAOIA1EAAAAAAAA8D8gDqGioCIOIAsbIhK2OAIAIAhBCGogDCAToiITIA4gDUQAAAAAAADwPyASoaKgIg4gCxsiErY4AgAgCEEMaiAMIBOiIhMgDiANRAAAAAAAAPA/IBKhoqAiDiALGyIStjgCACAMIBOiIA4gDUQAAAAAAADwPyASoaKgIAsbIQ4gCEEQaiIIICdHDQALCyAAIA45A7i9AQsgACoCyKgBIQUgB0HQBGpBAEGABPwLACAAQfjMAWoiLEEAQdgF/AsARAAAAAAAAPA/RAAAAAAAAPC/IBREAAAAAAAA8D9EAAAAAAAA8D9EAAAAAAAAAAAgBbsiDiAORAAAAAAAAAAAYxsiDiAORAAAAAAAAPA/ZBuhIg4gDkRhMlUwKqlTP6KiRC1DHOviNvo+oKKjELKBgIAAobYhFiAAQZQbaiEtIABB5M8BaiEuIA9E+n5qvHSTeD+itiEvIA9E+n5qvHSTiD+itiEwQQAhMQNAAkAgGSAxQfgCbGoiMi0A9QJFDQAgHCAyLQD0AiIzaiIIIAggHSAzaiAIQfIAIAhB8gBJG2siCyALQQxwayILayIIQRggCEEYShsgCCAIQRhIIidqa0EMbiAnakEMbGogC2shNCAyQQxqITUgM0ELaiE2IDIoAgghJUEAIR4gLSEmAkACQANAAkACQAJAIB5BCEcNAEEBISlBACEkIBEhDiA0IQggISE3QQAhIyAVQQFHDQEMAgsgB0EIaiAeQQN0aisDACEOCyAeQQJ0KAL8kMCAACILIDNqIgggCCA2IAtqIAhB8gAgCEHyAEgbayILIAtBDHBrIgtrIghBGCAIQRhKGyAIIAhBGEgiJ2prQQxuICdqQQxsaiALayEIIA62ITdBACEpAkAgD0QAAAAAAAAAAGQNAEEAISRBACEjDAELIAhB7ABIISQgCEFvaiEnIAhBGGohKCAIQcMASSEjCyA3IC+UITggNyAwlCE5IAhBaGohKgJAAkACQAJAAkAgNSAeQShsaiIILQAmIgtBAUcNACAILQAlIAgtACRJDQAgCCoCIEMAAIA/Ww0BCyA3QwAAAABfRQ0BIAJFDQIgCC0AJCEaIAgtACUhKEEAIRsCQANAAkACQCAoQf8BcSInIBpJDQAgCyEfDAELIBsgJWohKyAnQQggJ0EISxshICAmICdBAnRqISoDQCALIR8gICAnRg0DAkAgKyAqKAIATw0AIB8hCwwCCyAIICdBAWoiKDoAJSAIIB9BAXMiCzoAJiAqQQRqISogKCEnIBogKEcNAAsgH0H/AXFBAUchHyAaISgLQwAAAAAhCiAIIAgqAiAiBUMAAIA/QwAAAAAgH0EBcSInGyAFkyAWlJIiBTgCIAJAAkACQCAnDQAgBUO9N4Y1XQ0BC0MAAIA/IQogH0F/cyAFQ+//fz9eQX9zckEBcQ0BCyAIIAo4AiALIBtBAWoiGyACRw0ADAQLCyAgQQhBsI3AgAAQjoCAgAAACyA3QwAAAABeRQ0BIC4gLCApGyAqQQJ0aiIIIDcgCCoCAJI4AgACQCAjRQ0AICwgKEECdGoiCCA5IAgqAgCSOAIACyAkRQ0BICwgJ0ECdGoiCCA4IAgqAgCSOAIADAELIAJFDQAgJ0EHdCE6IChBB3QhOyAqQQd0ITwgCC0AJCEaIAgtACUhKEEAIRsDQAJAAkACQAJAAkAgKEH/AXEiJyAaSQ0AIAshHwwBCyAbICVqISsgJ0EIICdBCEsbISAgJiAnQQJ0aiEqA0AgCyEfICAgJ0YNAgJAICsgKigCAE8NACAfIQsMAgsgCCAnQQFqIig6ACUgCCAfQQFzIgs6ACYgKkEEaiEqICghJyAaIChHDQALIB9B/wFxQQFHIR8gGiEoC0MAAAAAIQogCCAIKgIgIgVDAACAP0MAAAAAIB9BAXEiJxsgBZMgFpSSIgU4AiACQAJAAkAgJw0AIAVDvTeGNV0NAQtDAACAPyEKIB9Bf3MgBUPv/38/XkF/c3JBAXENAQsgCCAKOAIgIAohBQsgBUMAAAAAWw0CAkACQCAbIDxqIiogACgCrMQBIidPDQAgNyAAKAKoxAEiHyAqQQJ0aioCAJQhCiApDQEMAwsgKiAnQcCZwIAAEI6AgIAAAAsgCiAHQdAAaiAbQQJ0aioCAJQhCgwBCyAgQQhBsI3AgAAQjoCAgAAACwJAICNFDQAgGyA7aiIqICdPDQQgCiA5IB8gKkECdGoqAgCUkiEKCwJAICRFDQAgGyA6aiIqICdPDQYgCiA4IB8gKkECdGoqAgCUkiEKCyAHQdAEaiAbQQJ0aiInICcqAgAgBSAKlJI4AgALIBtBAWoiGyACRw0ACwsgJkEoaiEmIB5BAWoiHkEJRg0DDAELCyAqICdB0JnAgAAQjoCAgAAACyAqICdB4JnAgAAQjoCAgAAACyAyICUgAmo2AgggMi0A9gINACAyLQAyDQAgMi0AMSAyLQAwSQ0AIDIqAixDAAAAAFwNACAyLQBaDQAgMi0AWSAyLQBYSQ0AIDIqAlRDAAAAAFwNACAyLQCCAQ0AIDItAIEBIDItAIABSQ0AIDIqAnxDAAAAAFwNACAyLQCqAQ0AIDItAKkBIDItAKgBSQ0AIDIqAqQBQwAAAABcDQAgMi0A0gENACAyLQDRASAyLQDQAUkNACAyKgLMAUMAAAAAXA0AIDItAPoBDQAgMi0A+QEgMi0A+AFJDQAgMioC9AFDAAAAAFwNACAyLQCiAg0AIDItAKECIDItAKACSQ0AIDIqApwCQwAAAABcDQAgMi0AygINACAyLQDJAiAyLQDIAkkNACAyKgLEAkMAAAAAXA0AIDItAPICDQAgMi0A8QIgMi0A8AJJDQAgMioC7AJDAAAAAFwNACAyQQA6APUCAkAgMi0A9AIiCMBBAEgNACAAIAhBA3RqIggoAgBFDQEgCCgCBCAxRw0BIAhBADYCAAwBCyAIQYABQbCZwIAAEI6AgIAAAAsgLUH4AmohLSAxQQFqIjFBMEcNAAsgAkH+AXEhHyACQQFxISUgACgCrMQBIRtBACEaIAAoAqjEASImISADQCAuIBpBAnQiCGoqAgAhBQJAAkAgLCAIaioCACIKQwAAAABcDQAgBUMAAAAAWw0BCwJAAkACQCAaQQd0IisgAmoiCCAbSw0AIAJFDQNBACEoIAJBAUYNAkEAISggB0HQAGohCyAHQdAEaiEIICAhJwNAIAggCCoCACAnKgIAIAogBSALKgIAlJKUkjgCACAIQQRqIiogKioCACAnQQRqKgIAIAogBSALQQRqKgIAlJKUkjgCACAIQQhqIQggC0EIaiELICdBCGohJyAfIChBAmoiKEcNAAwCCwsgKyAIIBtBoJnAgAAQloCAgAAACyAlRQ0BCyAHQdAEaiAoQQJ0IghqIgsgCyoCACAmICtBAnRqIAhqKgIAIAogBSAHQdAAaiAIaioCAJSSlJI4AgALICBBgARqISAgGkEBaiIaQdsARw0ACyAHQdAMakEAQYAE/AsAIAdB0AhqQQBBgAT8CwAgAEG4DWogB0HQCGogAiAHQdAMaiACEJyAgIAAIAAqAvixASEFIAAgACsD6MEBIg5EAAAAAAAA8D8gGCAURHsUrkfhepS/oqMQsoGAgAChRAAAAAAAAPA/RAAAAAAAAAAAIAa7IAW7oCIPIA9EAAAAAAAAAABjGyIPIA9EAAAAAAAA8D9kGyAOoaKgIg45A+jBAQJAIA4gACsD4MEBoZlEexSuR+F6hD9kRQ0AIAAgDjkD4MEBIABBmMEBakEDIBREAAAAAACAZkBEAAAAAAAA8D8gDqFEAAAAAAAAIkCiEKOAgIAAIAArA+jBASEOCyAORDMzMzMzM/s/ELaBgIAAIQ8CQAJAAkAgACoCxKgBEK2BgIAA/AAiC0F8aiIIQXxNDQBBeCEnDAELAkAgCEECTQ0AQQAhO0EAITMMAgtBYCEnCyAIQX1JITMgC0EDdCAnakH4mMCAAGorAwAhPUEBITsLIAAqAtioASEFRAAAAAAAAPA/RAAAAAAAAAAAIAAqAtCoAbsiDiAORAAAAAAAAAAAYxsiDiAORAAAAAAAAPA/ZBtEAAAAAAAAIECiRAAAAAAAAPA/oCI+RM3MzMzMzOQ/ELaBgIAAIQ4gACoC3KgBIQpEAAAAAAAA8L8gFES4HoXrUbiuP6KjELKBgIAAIQwCQAJAIAINAEEAIQgMAQsgD0SuR+F6FK7vP6JEexSuR+F6hD+gIT9EAAAAAAAA8D8gDqMhQERxPQrXo3AbQCAUoyFBIAq7RM3MzMzMzOw/oiFCRAAAAAAAAPA/IAyhIUNEzczMzMzMFkBEcT0K16Nw5T8gCUMAAAA/YCIIG0QAAAAAAAAAACAQQQFGIgsbIUREAAAAAAAAG0BEj8L1KFyP6j8gCBtEAAAAAAAAAAAgCxshRSAAQYgIaiE1IABBoAhqITwgAEHovwFqITpDAAAAACEvQQAhI0QAAAAAAAAkQEQAAAAAAADwP0QAAAAAAAAAACAFuyIOIA5EAAAAAAAAAABjGyIOIA5EAAAAAAAA8D9kGyJGIEagRAAAAAAAAPC/oCIORAAAAAAAACjARAAAAAAAAPi/IA5EAAAAAAAAAABmIggbokQAAAAAAAA0QKMQtoGAgAAhR0QAAAAAAAAkQCAORAAAAAAAABhARAAAAAAAAChAIAgbokQAAAAAAAA0QKMQtoGAgAAhSAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkADQCAHQdAEaiAjQQJ0IilqKgIAu0S4HoXrUbi+P6IgB0HQCGogKWoqAgAgB0HQDGogKWoqAgCSu0QAAAAAAADgP6KgIQ0CQCA7RQ0AIDogDTkDAEEAIQggDSEOA0AgACAIaiILQcC9AWoiJysDACEMIAArA+C/ASEPICcgDjkDACALQfC/AWpEAAAAAAAAAAAgDCAOIA+ioCAPIAtB0L4BaiILKwMAoqEiDiAOmUQjQpIMoZzHO2MbIg45AwAgCyAOOQMAIAhBCGoiCEGQAUcNAAsgACBBIAArA4DBAaAiDkQAAAAAAADwv6AgDiAORAAAAAAAAPA/ZhsiDjkDgMEBIAAgACsDkMEBIg8gACsDiMEBIDogPUQAAAAAAADwPyAOIA6gRAAAAAAAAPC/oJmhoiIO/AMiCEERIAhBEUkbIghBA3RqIgsrAwAiDCALKwMIIAyhIA4gCLihoqAgD6GioCIOOQOQwQEgDSAOoEQzMzMzMzPjP6IgDiAzGyENCyAAKwPIwQEhDiAAIAArA8DBASIPOQPIwQEgACsD2MEBIQwgACAAKwPQwQEiEzkD2MEBIAAgDTkDwMEBIABEAAAAAAAAAAAgDSAAKwOYwQGiIA8gACsDoMEBoqAgDiAAKwOowQGioCATIAArA7DBAaKhIAwgACsDuMEBoqEiDiAOmUQjQpIMoZzHO2MbIg45A9DBASA+ID8gDqKiRAAAAAAAAPA/IAArA/DBASIOIA4gDmIbIg9EAAAAAAAA8D8gD0QAAAAAAADwP2MbRJqZmZmZmcm/okQzMzMzMzPDP6AiD6AQy4GAgAAhDCAPEMuBgIAAIQ8gACsDqMIBIQ0gACAAKwOgwgEiEzkDqMIBIAArA7jCASERIAAgACsDsMIBIhI5A7jCASAAIEAgDCAPoaIiDzkDoMIBIAAgDiBDIA+ZIA6hoqA5A/DBASAARAAAAAAAAAAAIA8gACsD+MEBoiATIAArA4DCAaKgIA0gACsDiMIBoqAgEiAAKwOQwgGioSARIAArA5jCAaKhIg4gDplEI0KSDKGcxztjGyIOOQOwwgEgACsD4MIBIQ0gACsDgMMBIRMgACsD2MIBIREgACsD0MIBIRIgACsD8MIBIRggACsDyMIBIRQgACsDwMIBIRcgACsD+MIBIQ8gACsD6MIBIQwgACAOOQPowgEgACAMOQPwwgEgACAPOQOAwwEgACsD8AghSSAAIAArA+gIIko5A/AIIAArA4AJIUsgACAAKwP4CCJMOQOACSAARAAAAAAAAAAAIA4gF6IgFCAMoqAgEiAYoqAgESAPoqEgDSAToqEiDiAOmUQjQpIMoZzHO2MbIg45A/jCASAAIA45A+gIIABEAAAAAAAAAAAgDiAAKwPACKIgSiAAKwPICKKgIEkgACsD0AiioCBMIAArA9gIoqEgSyAAKwPgCKKhIg8gD5lEI0KSDKGcxztjGyIPOQP4CCAAKwPICSENIAArA6gJIRMgACsDoAkhESAAKwO4CSESIAArA5gJIRggACsDkAkhFCAAKwOICSEXIAArA7AJIQwgACAAKwPACSJJOQPICSAAIAw5A7gJIAAgDzkDsAkgACsDyAwhSiAAIAArA8AMIks5A8gMIAArA7gMIUwgACAAKwOwDCJNOQO4DCAARAAAAAAAAAAAIA8gF6IgFCAMoqAgGCASoqAgESBJoqEgEyANoqEiDyAPmUQjQpIMoZzHO2MbIg85A8AJIAAgDzkDsAwgAEQAAAAAAAAAACAPIAArA4gMoiBNIAArA5AMoqAgTCAAKwOYDKKgIEsgACsDoAyioSBKIAArA6gMoqEiDyAPmUQjQpIMoZzHO2MbIkk5A8AMIAArA5AKIQwgACsD8AkhDSAAKwPoCSETIAArA4AKIREgACsD4AkhEiAAKwPYCSEYIAArA9AJIRQgACsDiAohDyAAIAArA/gJIhc5A4AKIAAgDzkDkAogACAOOQP4CSAARAAAAAAAAAAAIA4gFKIgGCAXoqAgEiARoqAgEyAPoqEgDSAMoqEiDiAOmUQjQpIMoZzHO2MbIg45A4gKIAArA9gKIQwgACsDuAohDSAAKwOwCiETIAArA8gKIREgACsDqAohEiAAKwOgCiEYIAArA5gKIRQgACsD0AohDyAAIAArA8AKIhc5A8gKIAAgDzkD2AogACAOOQPACiAARAAAAAAAAAAAIA4gFKIgGCAXoqAgEiARoqAgEyAPoqEgDSAMoqEiDiAOmUQjQpIMoZzHO2MbIg45A9AKIAArA6ALIQwgACsDgAshDSAAKwP4CiETIAArA5ALIREgACsD8AohEiAAKwPoCiEYIAArA+AKIRQgACsDmAshDyAAIAArA4gLIhc5A5ALIAAgDzkDoAsgACAOOQOICyAARAAAAAAAAAAAIA4gFKIgGCAXoqAgEiARoqAgEyAPoqEgDSAMoqEiDiAOmUQjQpIMoZzHO2MbIg45A5gLIAArA+gLIQwgACsDyAshDSAAKwPACyETIAArA9gLIREgACsDuAshEiAAKwOwCyEYIAArA6gLIRQgACsD4AshDyAAIAArA9ALIhc5A9gLIAAgDzkD6AsgACAOOQPQCyAARAAAAAAAAAAAIA4gFKIgGCAXoqAgEiARoqAgEyAPoqEgDSAMoqEiDiAOmUQjQpIMoZzHO2MbIg05A+ALIAAgACsD4AwiDiBFIA6hIDwgRSAOZEEBc0EDdGorAwCioCIPOQPgDCAAIAArA+gMIg4gRCAOoSA8QRBBGCBEIA5kG2orAwCioCIMOQPoDCAAIAArA9AMIA9EGC1EVPshGUCiIAArA4AMIg6joCIPRBgtRFT7IRnAoCAPIA9EGC1EVPshGUBmGzkD0AwgACAMRBgtRFT7IRlAoiAOoyAAKwPYDKAiD0QYLURU+yEZwKAgDyAPRBgtRFT7IRlAZhs5A9gMIAAoAowNIgsgACgCmA0iCE8NASAAKAKIDSEIIAAoApQNIAtBAnRqIA22OAIAAkACQAJAIAAoAowNIgsgACgCpA0iJ08NACAAKAKgDSALQQJ0aiBJtjgCACAORJT2Bl+YTFU/oiEPIA5E/Knx0k1icD+iIQ0gRiAAKwOADWINASAAKwP4CyFLIAArA/ALIUwMAgsgCyAnQbCMwIAAEI6AgIAAAAsgACBHOQP4CyAAIEg5A/ALIAAgRjkDgA0gRyFLIEghTAsgI0EBaiEkIAdCADcD2BAgB0IANwPQECAOROTY4Q1RGzM/oiFKIA5EVsXSlPmoPD+iIRcgDSAPoCFJQQAhKCA1IScDQCAAKwPQDCAoQcCMwIAAaisDACIPoUQYLURU+yEZQKNEAAAAAAAA0D+gIg4gDp2hIA6mIg5EAAAAAAAA8D+gIA4gDkQAAAAAAAAAAGMbRAAAAAAAALBAoiIM/AMiC0H/HyALQf8fSRsiKiAAKAKwDSILTw0DICpBAWoiKyALTw0EIAArA9gMIA+hRBgtRFT7IRlAo0QAAAAAAADQP6AiDiAOnaEgDqYiDkQAAAAAAADwP6AgDiAORAAAAAAAAAAAYxtEAAAAAAAAsECiIhH8AyIfQf8fIB9B/x9JGyIaIAtPDQUgGkEBaiIeIAtPDQYgACgCjA0iIEQAAAAAAADwPyANIBcgACgCrA0iHyAqQQJ0aioCACIFIB8gK0ECdGoqAgAgBZMgDCAquKG2lJK7Ig+iIhOhIg4gDiAOYhsiDkQAAAAAAADwPyAORAAAAAAAAPA/ZBsiDpz8AyIlayImQQFqIAhxIiogACgCmA0iC08NByAmIAhxIisgC08NCCAgICVBf3NqIAhxIhsgC08NCSAmQX5qIAhxIiYgC08NDiAfIBpBAnRqKgIAITcgHyAeQQJ0aioCACE4ICdBeGoiHyAfKwMAIhIgACsD8AwiGCAPRAAAAAAAAPA/oEQAAAAAAADgP6IiDCAAKwP4DCIUIBihoqAgACgClA0iHyArQQJ0aioCACIKIB8gG0ECdGoqAgAiBSAfICpBAnRqKgIAIhaTQwAAAD+UIBYgCkMAACDAlJIgBSAFkpIgHyAmQQJ0aioCACI5QwAAAD+UkyAKIAWTQwAAwD+UIDkgFpNDAAAAP5SSIA4gJbihtiIFlJIgBZSSIAWUkrsgEqGioCISOQMAICBEAAAAAAAA8D8gSSAToCIOIA4gDmIbIg5EAAAAAAAA8D8gDkQAAAAAAADwP2QbIg6c/AMiJWsiH0EBaiAIcSIqIAtPDQcgHyAIcSIrIAtPDQggICAlQX9zaiAIcSIbIAtPDQkgH0F+aiAIcSImIAtPDQ4gJyAnKwMAIhMgACsD8AwiGEQAAAAAAADwPyAPoUQAAAAAAADgP6IiDyAUIBihoqAgACgClA0iCyArQQJ0aioCACIKIAsgG0ECdGoqAgAiBSALICpBAnRqKgIAIhaTQwAAAD+UIBYgCkMAACDAlJIgBSAFkpIgCyAmQQJ0aioCACI5QwAAAD+UkyAKIAWTQwAAwD+UIDkgFpNDAAAAP5SSIA4gJbihtiIFlJIgBZSSIAWUkrsgE6GioCITOQMAIAAoAowNIiBEAAAAAAAA8D8gDSBKIDcgOCA3kyARIBq4obaUkrsiEaKhIg4gDiAOYhsiDkQAAAAAAADwPyAORAAAAAAAAPA/ZBsiDpz8AyIfayIqQQFqIAhxIhogACgCpA0iC08NDSAqIAhxIisgC08NDCAgIB9Bf3NqIAhxIhsgC08NCyAqQX5qIAhxIiogC08NCiAHQdAQaiAoaiBMIAxEAAAAAAAA6D+iIAyfokQAAAAAAADQP6AgEqJEAAAAAAAAAACgIA9EAAAAAAAA6D+iIA+fokQAAAAAAADQP6AgE6JEexSuR+F61D+ioKIgSyARRAAAAAAAAPA/oETNzMzMzMzMP6JEmpmZmZmZ4T+gIAAoAqANIgsgK0ECdGoqAgAiCiALIBtBAnRqKgIAIgUgCyAaQQJ0aioCACIWk0MAAAA/lCAWIApDAAAgwJSSIAUgBZKSIAsgKkECdGoqAgAiN0MAAAA/lJMgCiAFk0MAAMA/lCA3IBaTQwAAAD+UkiAOIB+4obYiBZSSIAWUkiAFlJK7oqKgOQMAICdBEGohJyAoQQhqIgshKCALQRBHDQALIAAgIEEBaiAIcTYCjA0gBysD2BAhDiAHKwPQECEPIAArA7jDASEMIAAgACsDsMMBIg05A7jDASAAKwPIwwEhEyAAIAArA8DDASIROQPIwwEgACAPOQOwwwEgAEQAAAAAAAAAACAPIAArA4jDAaIgDSAAKwOQwwGioCAMIAArA5jDAaKgIBEgACsDoMMBoqEgEyAAKwOowwGioSIPIA+ZRCNCkgyhnMc7YxsiDDkDwMMBIAArA/DDASENIAArA5DEASETIAArA+jDASERIAArA+DDASESIAArA4DEASEYIAArA9DDASEUIAArA9jDASEXIAArA/jDASEPIAAgACsDiMQBIkk5A5DEASAAIA85A4DEASAAIA45A/jDASAARAAAAAAAAAAAIA4gFKIgFyAPoqAgEiAYoqAgESBJoqEgDSAToqEiDiAOmUQjQpIMoZzHO2MbIg45A4jEASABIClqIEIgDKK2Igo4AgACQCAjIARGDQAgAyApaiBCIA6itiIFOAIAIAWLIgUgCosiCiAvIC8gL1wbIhYgFiAKIAogClwbIgogFiAKXhsiCiAKIApcGyIKIAogBSAFIAVcGyIFIAogBV4bIS8gJCEjICQgAkYNDwwBCwsgBCAEQZCZwIAAEI6AgIAAAAsgCyAIQaCMwIAAEI6AgIAAAAsgKiALQZCTwIAAEI6AgIAAAAsgKyALQaCTwIAAEI6AgIAAAAsgGiALQZCTwIAAEI6AgIAAAAsgHiALQaCTwIAAEI6AgIAAAAsgKiALQZCMwIAAEI6AgIAAAAsgKyALQZCMwIAAEI6AgIAAAAsgGyALQZCMwIAAEI6AgIAAAAsgKiALQZCMwIAAEI6AgIAAAAsgGyALQZCMwIAAEI6AgIAAAAsgKyALQZCMwIAAEI6AgIAAAAsgGiALQZCMwIAAEI6AgIAAAAsgJiALQZCMwIAAEI6AgIAAAAsgL0OVv9YzXUEBcyEICyAALQD9HQ0CIAAtAPUgQQFxDQIgAC0A7SNBAXENAiAALQDlJkEBcQ0CIAAtAN0pQQFxDQIgAC0A1SxBAXENAiAALQDNL0EBcQ0CIAAtAMUyQQFxDQIgAC0AvTVBAXENAiAALQC1OEEBcQ0CIAAtAK07QQFxDQIgAC0ApT5BAXENAiAALQCdQUEBcQ0CIAAtAJVEQQFxDQIgAC0AjUdBAXENAiAALQCFSkEBcQ0CIAAtAP1MQQFxDQIgAC0A9U9BAXENAiAALQDtUkEBcQ0CIAAtAOVVQQFxDQIgAC0A3VhBAXENAiAALQDVW0EBcQ0CIAAtAM1eQQFxDQIgAC0AxWFBAXENAiAALQC9ZEEBcQ0CIAAtALVnQQFxDQIgAC0ArWpBAXENAiAALQClbUEBcQ0CIAAtAJ1wQQFxDQIgAC0AlXNBAXENAiAALQCNdkEBcQ0CIAAtAIV5QQFxDQIgAC0A/XtBAXENAiAALQD1fkEBcQ0CIAAtAO2BAUEBcQ0CIAAtAOWEAUEBcQ0CIAAtAN2HAUEBcQ0CIAAtANWKAUEBcQ0CIAAtAM2NAUEBcQ0CIAAtAMWQAUEBcQ0CIAAtAL2TAUEBcQ0CIAAtALWWAUEBcQ0CIAAtAK2ZAUEBcQ0CIAAtAKWcAUEBcQ0CIAAtAJ2fAUEBcQ0CIAAtAJWiAUEBcQ0CIAAtAI2lAUEBcQ0CIAAtAIWoAUEBcQ0CIAAtAPwNIAAtAMQOciAALQCMD3IgAC0A1A9yIAAtAJwQciAALQDkEHIgAC0ArBFyIAAtAPQRciAALQC8EnIgAC0AhBNyIAAtAMwTciAALQCUFHIgAC0A3BRyIAAtAKQVciAALQDsFXIgAC0AtBZyIAAtAPwWciAALQDEF3IgAC0AjBhyIAAtANQYciAALQCcGXIgAC0A5BlyIAAtAKwaciAALQD0GnIgCHJBAXENAiAAQQE6ALHTASAAQei/AWpBAEGYAfwLACAAQgA3A+gIIABCADcDkMEBIABCADcD8AggAEIANwP4CCAAQgA3A4AJIABCADcDsAkgAEIANwO4CSAAQgA3A8AJIABCADcDyAkgAEIANwP4CSAAQgA3A4AKIABCADcDiAogAEIANwOQCiAAQgA3A8AKIABCADcDyAogAEIANwPQCiAAQgA3A9gKIABCADcDoAsgAEIANwOYCyAAQgA3A5ALIABCADcDiAsgAEIANwPoCyAAQgA3A+ALIABCADcD2AsgAEIANwPQCyAAQgA3A7AMIABCADcDuAwgAEIANwPADCAAQgA3A8gMIABBwL0BakEAQaAC/AsAIABCADcD2MEBIABCADcD0MEBIABCADcDyMEBIABCADcDwMEBIABCADcDoMIBIABCADcDqMIBIABCADcDsMIBIABCADcDuMIBIABCADcD6MIBIABCADcD8MIBIABCADcD+MIBIABCADcDgMMBAkAgACgCmA0iCEUNACAIQQJ0IghFDQAgACgClA1BACAI/AsACwJAIAAoAqQNIghFDQAgCEECdCIIRQ0AIAAoAqANQQAgCPwLAAsgAEIANwOYCCAAQgA3A5AIIABCADcDiAggAEIANwOACCAAQgA3A7DDASAAQgA3A7jDASAAQgA3A8DDASAAQgA3A8jDASAAQgA3A/jDASAAQgA3A4DEASAAQgA3A4jEASAAQgA3A5DEASAAQgA3A/DBAQJAIAJFDQAgIkUNACABQQAgIvwLAAsgBEUNAiAEQQJ0IghFDQIgA0EAIAj8CwAMAgsCQCAAIB5qIggtAPUCRQ0AIB0gCC0A9AIiJmogHCAmaiIIQfIAIAhB8gBJG2siC0EMcCALayAIaiIIIAhBGCAIQRhKGyAIayAIQRhIIghrQQxuIAhqQQxsaiErICZBC2ohJSAHQQhqIQtBACEIQfyQwIAAIScDQCAfIAhBwAJHciEoAkACQCALKwMARAAAAAAAAAAAZUUNACAoDQELICshKgJAIChFDQAgJSAnKAIAIihqICggJmoiKEHyACAoQfIASBtrIipBDHAgKmsgKGoiKCAoQRggKEEYShsgKGsgKEEYSCIoa0EMbiAoakEMbGohKgsgGiAqQWhqIihqQQE6AAAgGyAoQQJ0aiIoICgqAgBDAACAP0MAAAAAICAgCGoiKEG6G2otAAAbIgUgKEG0G2oqAgAiCiAKIApcGyIKIAUgCiAFXhuSOAIAIA9EAAAAAAAAAABkRQ0AAkACQCAqQcMASQ0AICpB7ABPDQIMAQsgGiAqakEBOgAYCyAaICpqQW9qQQE6AAALICdBBGohJyALQQhqIQsgCEEoaiIIQegCRw0ACwsgHkH4AmohHiAgQfgCaiEgDAALCyAHQeAQaiSAgICAAAs6AAJAIAFBAksNACAAIAFBAnRqQfSxAWohAQJAIAK8QQF0Qf///3dNDQAgASoCACECCyABIAI4AgALC5IcAwp/CXwBfiOAgICAAEHwAmsiBSSAgICAAAJAIAAoAvCxASIGQYEBTw0AIABB8KgBaiEHIAZBA3QhCEEAIQYCQANAIAggBkYNASAAIAZqIQkgBkEIaiEGIAlB8KgBaigCACADRw0ACyAAQQEgAxC7gICAAAtBPCEGQTwhCgJAAkAgAbxBAXRB////d0sNAEEAQwAA/kJDAAAAACABEK2BgIAAIgEgAUMAAAAAXRsiASABQwAA/kJeGyIBQwAAAACXQwAAf0OW/AEgASABXBsiBsAiCkEASA0BCyAAIAZqLQDwsAEhCSAFIAcgAyAKEJ+AgIAAAkAgBS0AAEUNACAAIAUtAAEQm4CAgAALAkACQAJAIAlB/wFxDQACQAJAAkACQAJAIAAgBkEDdGoiCSgCAEEBRw0AIAkoAgQiC0EwTw0BIAAgC0H4AmxqLQD9HQ0ECyAAQYgbaiEGQQAhCyAALQD9HUEBRw0CQQEhCyAALQD1IEEBRw0CAkAgAC0A7SNBAUYNAEECIQsMAwsCQCAALQDlJkEBRg0AQQMhCwwDCwJAIAAtAN0pQQFGDQBBBCELDAMLAkAgAC0A1SxBAUYNAEEFIQsMAwsCQCAALQDNL0EBRg0AQQYhCwwDCwJAIAAtAMUyQQFGDQBBByELDAMLAkAgAC0AvTVBAUYNAEEIIQsMAwsCQCAALQC1OEEBRg0AQQkhCwwDCwJAIAAtAK07QQFGDQBBCiELDAMLAkAgAC0ApT5BAUYNAEELIQsMAwsCQCAALQCdQUEBRg0AQQwhCwwDCwJAIAAtAJVEQQFGDQBBDSELDAMLAkAgAC0AjUdBAUYNAEEOIQsMAwsCQCAALQCFSkEBRg0AQQ8hCwwDCwJAIAAtAP1MQQFGDQBBECELDAMLAkAgAC0A9U9BAUYNAEERIQsMAwsCQCAALQDtUkEBRg0AQRIhCwwDCwJAIAAtAOVVQQFGDQBBEyELDAMLAkAgAC0A3VhBAUYNAEEUIQsMAwsCQCAALQDVW0EBRg0AQRUhCwwDCwJAIAAtAM1eQQFGDQBBFiELDAMLAkAgAC0AxWFBAUYNAEEXIQsMAwsCQCAALQC9ZEEBRg0AQRghCwwDCwJAIAAtALVnQQFGDQBBGSELDAMLAkAgAC0ArWpBAUYNAEEaIQsMAwsCQCAALQClbUEBRg0AQRshCwwDCwJAIAAtAJ1wQQFGDQBBHCELDAMLAkAgAC0AlXNBAUYNAEEdIQsMAwsCQCAALQCNdkEBRg0AQR4hCwwDCwJAIAAtAIV5QQFGDQBBHyELDAMLAkAgAC0A/XtBAUYNAEEgIQsMAwsCQCAALQD1fkEBRg0AQSEhCwwDCwJAIAAtAO2BAUEBRg0AQSIhCwwDCwJAIAAtAOWEAUEBRg0AQSMhCwwDCwJAIAAtAN2HAUEBRg0AQSQhCwwDCwJAIAAtANWKAUEBRg0AQSUhCwwDCwJAIAAtAM2NAUEBRg0AQSYhCwwDCwJAIAAtAMWQAUEBRg0AQSchCwwDCwJAIAAtAL2TAUEBRg0AQSghCwwDCwJAIAAtALWWAUEBRg0AQSkhCwwDCwJAIAAtAK2ZAUEBRg0AQSohCwwDCwJAIAAtAKWcAUEBRg0AQSshCwwDCwJAIAAtAJ2fAUEBRg0AQSwhCwwDCwJAIAAtAJWiAUEBRg0AQS0hCwwDCwJAIAAtAI2lAUEBRg0AQS4hCwwDCyAALQCFqAFBAUYNAUEvIQsMAgsgC0EwQbCRwIAAEI6AgIAAAAtBACELQQAhA0EAIQcDQAJAAkACQCALIghBME8NACAAIANqIgxB/h1qLQAAIQ0CQAJAIAYgCEH4AmxqIg4tAPYCDQAgDUH/AXFFDQEgCCELDAQLIAchCyANQQFxRQ0DCyAIIQsgDEGIG2opAwAgDikDAFQNAQwCCyAIQTBBwJHAgAAQjoCAgAAACyAHIQsLIAdBAWohByADQfgCaiIDQYCNAUcNAAsgC0EwTw0EIAYgC0H4AmxqLAD0AiIIQf8BcSEDIAhBf0wNAyAAIANBA3RqQQA2AgALIAVCADcAJyAFQgA3AyAgBUIANwMYIAVCADcDECAFQgA3AwggBUIANwMwIAVCADcDOCAFQgA3A0AgBUIANwNIIAVCADcATyAFQgA3A1ggBUIANwNgIAVCADcDaCAFQgA3A3AgBUIANwB3IAVCADcDgAEgBUIANwOIASAFQgA3A5ABIAVCADcDmAEgBUIANwCfASAFQgA3AMcBIAVCADcDwAEgBUIANwO4ASAFQgA3A7ABIAVCADcDqAEgBUIANwDvASAFQgA3A+gBIAVCADcD4AEgBUIANwPYASAFQgA3A9ABIAVCADcAlwIgBUIANwOQAiAFQgA3A4gCIAVCADcDgAIgBUIANwP4ASAFQgA3AL8CIAVCADcDuAIgBUIANwOwAiAFQgA3A6gCIAVCADcDoAIgBUIANwDnAiAFQgA3A+ACIAVCADcD2AIgBUIANwPQAiAFQgA3A8gCIAYgC0H4AmxqIgZBADYCCCAGQgA3AwAgBkEMaiAFQQhqQegC/AoAACAGQQE7APUCIAYgCjoA9AIgCSALNgIEIAlBATYCAAtEAAAAAAAAAAAhD0QAAAAAAADwP0QAAAAAAAAAACAAKgLIqAG7IhAgEEQAAAAAAAAAAGMbIhAgEEQAAAAAAADwP2QbIhFEAAAAAAAACECiIRJEAAAAAAAA8D9EAAAAAAAA8D9EAAAAAAAAAAAgArsiECAQRAAAAAAAAAAAYxsiECAQRAAAAAAAAPA/ZBuhRMe6uI0G8GY/okRhMlUwKqlDP6AgACsDiKgBIhOiIRQgACALQfgCbGohDCAKQf8BcbhEXynLEMf6KUCiIRUgBUEMaiEJRP///////+9/IRZBACEIA0AgCUEANgIYIAlCADcCECAJQgA3AgggCUIANwIAIAAgACgC0NIBIgZBDXQgBnMiBkERdiAGcyIGQQV0IAZzIgZBDXQgBnMiA0ERdiADcyIDQQV0IANzIgM2AtDSASAFIBQgFSAPRPT91HjpjlNAoqAQp4GAgABECtejcNFd5UCiIhAgEJyhRGZmZmZmZuY/oiAGuEQAAAAAAAAAPqJEAAAAAAAA8L+gRAAAAAAAAPA/oEQAAAAAAADgP6JEMzMzMzMz0z+ioKIiEPwDNgIIIBAgFiAWIBZiGyIWIBAgECAQYhshF0EBIQYCQCASIBEgA7hEAAAAAAAAAD6iRAAAAAAAAPC/oEQAAAAAAADwP6BEAAAAAAAA4D+ioqCc/AMiB0UNACAFIBAgEyADQQ10IANzIgZBEXYgBnMiBkEFdCAGcyIGuEQAAAAAAAAAPqJEAAAAAAAA8L+gRAAAAAAAAPA/oEQAAAAAAADgP6JED9b/OcyXJz+iRPFo44i1+AQ/oKJEAAAAAAAA8D+goCIQ/AM2AgwgBSAQIBMgBkENdCAGcyIGQRF2IAZzIgZBBXQgBnMiA7hEAAAAAAAAAD6iRAAAAAAAAPC/oEQAAAAAAADwP6BEAAAAAAAA4D+iRGEyVTAqqTM/okQtQxzr4jYaP6CiRAAAAAAAAPA/oKAiEPwDNgIQQQMhBgJAIAdBAUYNAEEFIQYgBSAQIBMgA0ENdCADcyIDQRF2IANzIgNBBXQgA3MiA7hEAAAAAAAAAD6iRAAAAAAAAPC/oEQAAAAAAADwP6BEAAAAAAAA4D+iRA/W/znMlyc/okTxaOOItfgEP6CiRAAAAAAAAOA/okQAAAAAAADwP6CgIhD8AzYCFCAFIBAgEyADQQ10IANzIgNBEXYgA3MiA0EFdCADcyIDuEQAAAAAAAAAPqJEAAAAAAAA8L+gRAAAAAAAAPA/oEQAAAAAAADgP6JEYTJVMCqpMz+iRC1DHOviNho/oKJEAAAAAAAA4D+iRAAAAAAAAPA/oKAiEPwDNgIYIAdBAkYNACAFIBAgEyADQQ10IANzIgZBEXYgBnMiBkEFdCAGcyIGuEQAAAAAAAAAPqJEAAAAAAAA8L+gRAAAAAAAAPA/oEQAAAAAAADgP6JED9b/OcyXJz+iRPFo44i1+AQ/oKJEVVVVVVVV1T+iRAAAAAAAAPA/oKAiEPwDNgIcIAUgECATIAZBDXQgBnMiBkERdiAGcyIGQQV0IAZzIgO4RAAAAAAAAAA+okQAAAAAAADwv6BEAAAAAAAA8D+gRAAAAAAAAOA/okRhMlUwKqkzP6JELUMc6+I2Gj+gokRVVVVVVVXVP6JEAAAAAAAA8D+goPwDNgIgQQchBgsgACADNgLQ0gELIBYgF2MhByAMIAhqIgNBuhtqQQA6AAACQCAGQQJ0Ig1FDQAgA0GUG2ogBUEIaiAN/AoAAAsgFiAXIAcbIRYgD0QAAAAAAADwP6AhDyADQbkbakEAOgAAIANBuBtqIAY6AAAgCEEoaiIIQegCRw0ACyAAQQA6ALHTASAAIAtB+AJsaiIGQQE6AP4dIAAgACkDgLIBQgF8Ihg3A4CyASAGQQA2ApAbIAYgGDcDiBsgBUIANwMgIAVC+v2p48vupKw/NwMQIAUgEUT6fmq8dJN4P6I5AwggBUIANwMoIAVCADcDMCAFIBYgE6M5AzggBSAKQf8BcUEMcLhEAAAAAAAAXkCiRAAAAAAAAKlAoDkDGCAAQbgNaiAFQQhqEJCAgIAACyAFQfACaiSAgICAAA8LIANBgAFB4JHAgAAQjoCAgAAACyALQTBB0JHAgAAQjoCAgAAACyAGQYABQYCawIAAEI6AgIAAAAtBACAGQYABQcCSwIAAEJaAgIAAAAv9BQEJfwJAAkACQAJAAkACQAJAAkAgAUEBRw0AQQQhA0EEEJKAgIAAIgRFDQcgBCACNgIADAELIAAoAvCxASIFQYEBTw0FIAVFDQEgBUECdCIBEJKAgIAAIgRFDQQgBUEDcSEGQQAhBwJAAkAgBUEESQ0AIAVBAnZBP3EiAUECdCEHIAFBBXQhCEEAIQkgBCEBA0AgASAAIAlqIgJB8KgBaigCADYCACABQQRqIAJB+KgBaigCADYCACABQQhqIAJBgKkBaigCADYCACABQQxqIAJBiKkBaigCADYCACABQRBqIQEgCCAJQSBqIglHDQALIAZFDQELIAQgB0ECdGohASAHQQN0IABqQfCoAWohAgNAIAEgAigCADYCACACQQhqIQIgAUEEaiEBIAZBf2oiBg0ACwsgBUECdCEDCyAAQfCwAWohCiAAQfCoAWohCyAEIANqIQcgBCEFA0ACQAJAAkAgACgC8LEBIghBgQFPDQAgCEUNAiAFKAIAIQYgCEEDdCEJQQAhAUEAIQICQANAIAAgAWpB8KgBaigCACAGRg0BIAJBAWohAiAJIAFBCGoiAUcNAAwECwsgCyACQQN0aiIGLQAEIQECQCAIIAJBAWoiAmtBA3QiCUUNACAGIAsgAkEDdGogCfwKAAALIAAgACgC8LEBQX9qNgLwsQEgAcAiAkF/TA0BIAogAWoiASABLQAAIgEgAUEAR2s6AAAgAUECTw0CIAAgAhCbgICAAAwCC0EAIAhBgAFBgJPAgAAQloCAgAAACyABQYABQfCSwIAAEI6AgIAAAAsgBUEEaiIFIAdHDQALIARBfGooAgAiAUF4cSICQQRBCCABQQNxIgEbIANqSQ0BAkAgAUUNACACIANBJ2pLDQMLIAQQgYCAgAALDwtBgLPAgABBLkGws8CAABCCgICAAAALQcCzwIAAQS5B8LPAgAAQgoCAgAAAC0EEIAEQk4CAgAAAC0EAIAVBgAFBsJLAgAAQloCAgAAAC0EEQQQQmoCAgAAAC58BAQF/IABBkKgBaiABQeAA/AoAACAAQQE6ANTSAQJAIAAtANXSAQ0AIABBAToA1dIBIABEzczMzMzMFkBEcT0K16Nw5T8gACoC/LEBQwAAAD9gIgEbRAAAAAAAAAAAIAAqAtSoARCtgYCAAPwAQQFGIgIbOQPoDCAARAAAAAAAABtARI/C9Shcj+o/IAEbRAAAAAAAAAAAIAIbOQPgDAsLvQIBB38jgICAgABBEGsiAiSAgICAAEEKIQMgACgCACIEIQUCQCAEQegHSQ0AQQohAyAEIQUDQCACQQZqIANqIgZBfGogBSIAIABBkM4AbiIFQZDOAGxrIgdB//8DcUHkAG4iCEEBdC8As53AgAA7AAAgBkF+aiAHIAhB5ABsa0H//wNxQQF0LwCzncCAADsAACADQXxqIQMgAEH/rOIESw0ACwsCQAJAIAVBCUsNACAFIQAMAQsgAkEGaiADQX5qIgNqIAUgBUH//wNxQeQAbiIAQeQAbGtB//8DcUEBdC8As53AgAA7AAALAkACQCAERQ0AIABFDQELIAJBBmogA0F/aiIDaiAAQQF0LQC0ncCAADoAAAsgAUEBQQAgAkEGaiADakEKIANrEL6AgIAAIQMgAkEQaiSAgICAACADC/YEAgd/AX4gACgCCCIFQYCAgAFxIgZBFXYgBGohBwJAAkAgBUGAgIAEcQ0AQQAhAQwBCwJAAkAgAg0AQQAhCAwBCyABLAAAQb9/SiEIIAJBAUYNACAIIAEsAAFBv39KaiEICyAIIAdqIQcLQStBfyAGGyEJAkACQCAHIAAvAQwiCk8NAAJAAkACQCAFQYCAgAhxDQAgCiAHayEKQQAhBkEAIQsCQAJAAkAgBUEddkEDcQ4EAgABAAILIAohCwwBCyAKQf7/A3FBAXYhCwsgBUH///8AcSEIIAAoAgQhByAAKAIAIQADQCAGQf//A3EgC0H//wNxTw0CQQEhBSAGQQFqIQYgACAIIAcoAhARgYCAgACAgICAAEUNAAwFCwsgACAAKQIIIgynQYCAgP95cUGwgICAAnI2AghBASEFIAAoAgAiCCAAKAIEIgsgCSABIAIQ9ICAgAANA0EAIQYgCiAHa0H//wNxIQcDQCAGQf//A3EgB08NAkEBIQUgBkEBaiEGIAhBMCALKAIQEYGAgIAAgICAgABFDQAMBAsLQQEhBSAAIAcgCSABIAIQ9ICAgAANAiAAIAMgBCAHKAIMEYKAgIAAgICAgAANAiAKIAtrQf//A3EhC0EAIQYDQAJAIAZB//8DcSALSQ0AQQAPC0EBIQUgBkEBaiEGIAAgCCAHKAIQEYGAgIAAgICAgABFDQAMAwsLQQEhBSAIIAMgBCALKAIMEYKAgIAAgICAgAANASAAIAw3AghBAA8LQQEhBSAAKAIAIgYgACgCBCIAIAkgASACEPSAgIAADQAgBiADIAQgACgCDBGCgICAAICAgIAAIQULIAULDgAgAC0A6SJBf3NBAXELtAYBBn8CQCAAKAKwESIBRQ0AIAAoAqwRIgIhAwJAIAFB6AFsIgRBmH5qIgVB6AFuQQFqQQNxIgFFDQAgAUHoAWwhBkEAIQEDQCACIAFqIgNBpAFqQgA3AgAgA0HsAGpCADcCACADQTRqQgA3AgAgA0HlAWpBADoAACAGIAFB6AFqIgFHDQALIAIgAWohAwsgBUG4BUkNACACIARqIQEDQCADQc0DakEAOgAAIANBpAFqQgA3AgAgA0HsAGpCADcCACADQTRqQgA3AgAgA0HlAWpBADoAACADQbUFakEAOgAAIANBjANqQgA3AgAgA0HUAmpCADcCACADQZwCakIANwIAIANBnQdqQQA6AAAgA0H0BGpCADcCACADQbwEakIANwIAIANBhARqQgA3AgAgA0HcBmpCADcCACADQaQGakIANwIAIANB7AVqQgA3AgAgA0GgB2oiAyABRw0ACwtBgHghAQNAIAAgAWoiA0G4CGpBADYCACADQbAIakEANgIAIANBqAhqQQA2AgAgA0GgCGpBADYCACADQZgIakEANgIAIANBkAhqQQA2AgAgA0GICGpBADYCACADQYAIakEANgIAIAFBwABqIgENAAsgAEEAOgD0HiAAQQA6AKweIABBADoA5B0gAEEAOgCcHSAAQQA6ANQcIABBADoAjBwgAEEAOgDEGyAAQQA6APwaIABBADoAtBogAEEAOgDsGSAAQQA6AKQZIABBADoA3BggAEEAOgCUGCAAQQA6AMwXIABBADoAhBcgAEEAOgC8FiAAQQA6APQVIABBADoArBUgAEEAOgDkFCAAQQA6AJwUIABBADoA1BMgAEEAOgCMEyAAQQA6AMQSIABBADoA/BEgAEIANwPwICAAQgA3A+ggIABCADcD4CAgAEIANwPYICAAQgA3A6AhIABCADcDqCEgAEIANwOwISAAQgA3A7ghIABCADcD6CEgAEIANwPwISAAQgA3A/ghIABCADcDgCIgAEIANwOwIiAAQgA3A7giIABCADcDwCIgAEIANwPIIiAAQgA3A6ggIABCADcDoCAgAEIANwOYICAAQgA3A5AgIABBAToA6SILnBwDDX8HfUN8I4CAgIAAQYAIayIHJICAgIAAAkAgAkUNACACQQJ0IghFDQAgAUEAIAj8CwALAkAgBEUNACAEQQJ0IghFDQAgA0EAIAj8CwALAkAgAC0A6CJBAUcNAAJAIAUgACoCtBGTi0MK1yM8XQ0AIAAgBTgCtBEgACAFu0QAAAAAAMCSQKMQxYGAgAA5A6ARIAAoArARIglFDQAgACgCrBFB5QFqIQhBACEKA0ACQCAILQAAQQFHDQAgACAKEJWAgIAACyAIQegBaiEIIAkgCkEBaiIKRw0ACwsgAkECdCELIAAoArARIQwCQAJAAkAgAkUNACAMIQ1BACEOQQAhDwNAIA5Bf2ohEEEAIA4gDCAOIAxLG2shEUEAIA4gDSAOIA1LGyISayETIAAoAqwRIA5B6AFsakHlAWohCQNAIAkhCiARIBAiCGpBf0YNBCATIAhqQX9GDQMgCkHoAWohCSAIQQFqIRAgCi0AAEUNAAsgCEECaiEOIApBm35qIggoAsABIQkgCCoCzAEhFCAIKgLQASEVIAgqAsgBIRZDAAAAACEFIAshEyABIREDQCARIQogFCEXAkACQCAJIAgoArwBSQ0AQwAAAAAhFAwBCwJAIAkgCCgC4AEiEUkNACAJIBFBqJbAgAAQjoCAgAAACyAIIAlBAWoiETYCwAEgCCgC3AEgCUECdGoqAgAhFCARIQkLAkAgCCgCuAEiEUEESQ0AQQAgEUEDQbiWwIAAEJaAgIAAAAsCQAJAIBENAEMAAAAAIRgMAQsgCCoCOCEYIAggCCoCNCIZOAI4IAggGSAIKgIolCAYIAgqAiyUkiAUIAgqAjCUkiIYOAI0IBhDAAAAAJIhGCARQThsQQhqIhFBwABGDQAgCCoCcCEZIAggCCoCbCIaOAJwIAggGiAIKgJglCAZIAgqAmSUkiAUIAgqAmiUkiIZOAJsIBggGZIhGCARQfgARg0AIAgqAqgBIRkgCCAIKgKkASIaOAKoASAIIBogCCoCmAGUIBkgCCoCnAGUkiAUIAgqAqABlJIiFDgCpAEgGCAUkiEYCyAKQQRqIREgCiAKKgIAIBVDAACAPyAWIBiUQ5qZGT+SIhQgFJRDAACAP5KVIhQgF5OUkjgCACAYiyIYIAUgBSAFXBsiBSAFIBggGCAYXBsiGCAFIBheGyEFIBNBfGoiEw0ACyAIIBQ4AswBIAAgECAFIAIQl4CAgAAgD3IhDyAAKAKwESENDAALCyAMIQ1BACEJQQAhDwNAIAkgDCAJIAxLGyEQIAkgDSAJIA1LGyESIAAoAqwRIAlB6AFsakHlAWohCgNAIBAgCSIIRg0DIBIgCEYNAiAIQQFqIQkgCi0AACERIApB6AFqIQogEUEBRw0ACyAAIAhDAAAAAEEAEJeAgIAAIA9yIQ8gACgCsBEhDQwACwsgEiANQbCawIAAEI6AgIAAAAsCQCAALQDpIkEBRw0AIA9BAXENACAALQD8EQ0AIAAtAMQSQQFxDQAgAC0AjBNBAXENACAALQDUE0EBcQ0AIAAtAJwUQQFxDQAgAC0A5BRBAXENACAALQCsFUEBcQ0AIAAtAPQVQQFxDQAgAC0AvBZBAXENACAALQCEF0EBcQ0AIAAtAMwXQQFxDQAgAC0AlBhBAXENACAALQDcGEEBcQ0AIAAtAKQZQQFxDQAgAC0A7BlBAXENACAALQC0GkEBcQ0AIAAtAPwaQQFxDQAgAC0AxBtBAXENACAALQCMHEEBcQ0AIAAtANQcQQFxDQAgAC0AnB1BAXENACAALQDkHUEBcQ0AIAAtAKweQQFxDQAgAC0A9B5BAXFFDQELQQAhCCAHQYAEakEAQYAE/AsAIAdBAEGABPwLAAJAIAJBgQFJDQBBACACQYABQaCawIAAEJaAgIAAAAsgAEG4EWogByACIAdBgARqIAIQnICAgAAgACoCoB8hFyAAKgKYHyEUIAArA4AIIRsgACoCnB8hGUQK16NwPQrHPxDLgYCAABogACoCkBEhGEMAAAAAIQVEAAAAAAAA8L8gG0R7FK5H4XqUP6KjELKBgIAAIRwgFLtEAAAAAAAAGECiRAAAAAAAAPA/oCIdRDMzMzMzM+M/ELaBgIAAIR4gACoCqB8hFESrqqqqqqpAwCAboxCygYCAACEfRP//////P2/AIBujELKBgIAAISBDAACAP0MAAAAAIBggGEMAAAAAXRsiGCAYQwAAgD9eG7tEmpmZmZmZ+T8QtoGAgAAhIQJAAkAgAkUNACAZu0QYLURU+yEZQKIgG6MhIkQAAAAAAADwPyAcoSEjRFK4HoXrUeA/IB6jISQgF7shJSAUuyEmIAArA8giIScgACsDwCIhKCAAKwO4IiEpIAArA7AiIRwgACsDgCIhKiAAKwP4ISErIAArA/AhISwgACsD6CEhHiAAKwO4ISEtIAArA7AhIS4gACsDqCEhLyAAKwOgISEwIAArA/AgITEgACsD6CAhMiAAKwPgICEzIAArA9ggITQgACsDqCAhNSAAKwOgICE2IAArA5ggITcgACsDkCAhOCAAKwPYIiEbIAArA9AiITkgACsDqCIhOiAAKwOgIiE7IAArA5giITwgACsDkCIhPSAAKwOIIiE+IAArA+AhIT8gACsD2CEhQCAAKwPQISFBIAArA8ghIUIgACsDwCEhQyAAKwOYISFEIAArA5AhIUUgACsDiCEhRiAAKwOAISFHIAArA/ggIUggACsD0CAhSSAAKwPIICFKIAArA8AgIUsgACsDuCAhTCAAKwOwICFNIAArA4ggIU4gACsDgCAhTyAAKwP4HyFQIAArA/AfIVEgACsD6B8hUiAAKwPgIiFTQQAhCiAHQYAEaiEJIAchESABIQggAyEQA0AgNCFUIDAhVSAeIVYgHCFXIB1EAAAAAAAAAAAgUSA4IliiIFIgCCoCACARKgIAIAkqAgCSQwAAAD+UkrsiOKKgIFAgN6KgIE8gNiJZoqEgTiA1oqEiHCAcmUQjQpIMoZzHO2MbIjaiRArXo3A9Csc/oBDLgYCAACEeIAhEAAAAAAAA8D8gGyAiIDmgIhxEGC1EVPshGcCgIBwgHEQYLURU+yEZQGQbIjkQp4GAgABEAAAAAAAA4D+iRAAAAAAAAOA/oCIcIBuhRAAAAAAAAPA/ICAgHyAcIBtkG6GioCIbICWioUQAAAAAAAAAAEQAAAAAAAAAAEQAAAAAAAAAAEQAAAAAAAAAACAkIB5EdrlNmFrLxr+goiI0IE2iIEwgVKKgIEsgM6KgIEogMiJaoqEgSSAxoqEiHCAcmUQjQpIMoZzHO2MbIjAgSKIgRyBVoqAgRiAvoqAgRSAuIluioSBEIC2ioSIcIByZRCNCkgyhnMc7YxsiHiBDoiBCIFaioCBBICyioCBAICsiXKKhID8gKqKhIhwgHJlEI0KSDKGcxztjGyIcID6iID0gV6KgIDwgKaKgIDsgKCJdoqEgOiAnoqEiKCAomUQjQpIMoZzHO2MbIiiiICaiIFMgIyAhIFOhoqAiU6K2Ihg4AgAgBCAKRg0CIBAgGDgCACAYiyIYIAUgBSAFXBsiBSAFIBggGCAYXBsiGCAFIBheGyEFIBFBBGohESAJQQRqIQkgCEEEaiEIIBBBBGohECBdIScgVyEpIFwhKiAcISsgViEsIFshLSAeIS4gVSEvIFohMSAwITIgVCEzIFkhNSBYITcgAiAKQQFqIgpHDQALIAAgGzkD2CIgACA5OQPQIiAAIFM5A+AiIAAgXTkDyCIgACAoOQPAIiAAIFc5A7giIAAgHDkDsCIgACBcOQOAIiAAIBw5A/ghIAAgVjkD8CEgACAeOQPoISAAIFs5A7ghIAAgHjkDsCEgACBVOQOoISAAIDA5A6AhIAAgWjkD8CAgACAwOQPoICAAIFQ5A+AgIAAgNDkD2CAgACBZOQOoICAAIDY5A6AgIAAgWDkDmCAgACA4OQOQICAFQ5W/1jNdQQFzIQgLIA9BAXENASAALQD8ESAALQDEEnIgAC0AjBNyIAAtANQTciAALQCcFHIgAC0A5BRyIAAtAKwVciAALQD0FXIgAC0AvBZyIAAtAIQXciAALQDMF3IgAC0AlBhyIAAtANwYciAALQCkGXIgAC0A7BlyIAAtALQaciAALQD8GnIgAC0AxBtyIAAtAIwcciAALQDUHHIgAC0AnB1yIAAtAOQdciAALQCsHnIgAC0A9B5yIAhyQQFxDQEgAEIANwPYICAAQQE6AOkiIABCADcD4CAgAEIANwPoICAAQgA3A/AgIABCADcDoCEgAEIANwOoISAAQgA3A7AhIABCADcDuCEgAEIANwPoISAAQgA3A/AhIABCADcD+CEgAEIANwOAIiAAQgA3A7AiIABCADcDuCIgAEIANwPAIiAAQgA3A8giIABCADcDqCAgAEIANwOgICAAQgA3A5ggIABCADcDkCACQCACRQ0AIAtFDQAgAUEAIAv8CwALIARFDQEgBEECdCIIRQ0BIANBACAI/AsADAELIAAgGzkD2CIgACA5OQPQIiAAIFM5A+AiIAAgXTkDyCIgACAoOQPAIiAAIFc5A7giIAAgHDkDsCIgACBcOQOAIiAAIBw5A/ghIAAgVjkD8CEgACAeOQPoISAAIFs5A7ghIAAgHjkDsCEgACBVOQOoISAAIDA5A6AhIAAgWjkD8CAgACAwOQPoICAAIFQ5A+AgIAAgNDkD2CAgACBZOQOoICAAIDY5A6AgIAAgWDkDmCAgACA4OQOQICAEIARBkJrAgAAQjoCAgAAACyAHQYAIaiSAgICAAAvpDAUFfwF9AXwBfgZ8I4CAgIAAQdAAayIFJICAgIAAAkACQCAAKAKIESIGQYEBTw0AIABBiAhqIQcgBkEDdCEIQQAhBgJAA0AgCCAGRg0BIAAgBmohCSAGQQhqIQYgCUGICGooAgAgA0cNAAsgAEEBIAMQmYCAgAALQTwhBgJAIAG8IglBAXRB////d0sNAEEAQwAA/kJDAAAAACABEK2BgIAAIgogCkMAAAAAXRsiCiAKQwAA/kJeGyIKQwAAAACXQwAAf0OW/AEgCiAKXBshBgsgBUEQaiAHIAMgBhCfgICAAAJAIAUtABBFDQAgACAFLQARQf8BcUEDdGoiBigCAEEBRw0AIAAgBigCBBCVgICAAAtBPCEDAkAgCUEBdEH///93Sw0AQQBDAAD+QkMAAAAAIAEQrYGAgAAiCiAKQwAAAABdGyIKIApDAAD+Ql4bIgpDAAAAAJdDAAB/Q5b8ASAKIApcGyEDCyAAKwOACCELIAVBCGogACADEJiAgIAAIAUtAAwhCCAFKAIIIQkgACAAKQOYEUIBfCIMNwOYESAJIAAoArARIgZPDQEgACgCrBEgCUHoAWxqIgZBADYC1AEgBiAMNwMAAkAgCEEBcUUNACAGQbz48PkDNgLMAQsgBkEDNgK4ASAGQoOBq47aiLKuwAA3A4ABIAZCtr7ctqix6J3AADcDSCAGQwAAgD9DAAAAACACIAJDAAAAAF0bIgIgAkMAAIA/Xhu7Ig1EZmZmZmZm9j8QtoGAgAAiDjkDICAGIA5E/Knx0k1icD+iOQOQASAGIA5E7FG4HoXroT+iOQNYIAZDAAD+QkMAAAAAIAEgAUMAAAAAXRsiASABQwAA/kJeG7tEAAAAAABAUcCgRAAAAAAAAChAoxDFgYCAAEQAAAAAAIB7QKIiDjkDCCAGIA5EzczMzMyMMUCiOQN4IAYgDkQUrkfhehQZQKI5A0AgBkQ2H9eGiqEbQEQtQxzr4jYaP0QAAAAAAADgPyAAKgKUH7uhRJqZmZmZmQFAohDFgYCAAESkcD0K16PAP6IiDyAPIA9iGyIPRC1DHOviNho/IA9ELUMc6+I2Gj9kG6MiDzkDGCAGIA9EAAAAAAAACECiOQOIASAGIA8gD6A5A1AgACoCkB8hASAGRDYf14aKoRtARC1DHOviNho/RAAAAAAAwFlARAAAAAAAADxAIANB/wFxuCIPIA9EAAAAAAAAPEBjGyIPIA9EAAAAAADAWUBkGyIQRAAAAAAAAETAoEQAAAAAAAA4wKMQxYGAgABEAAAAAAAAEkCiRJqZmZmZmak/IAG7Ig8gDyAPYhsiD0SamZmZmZmpPyAPRJqZmZmZmak/ZBuiIg8gDyAPYhsiD0QtQxzr4jYaPyAPRC1DHOviNho/ZBujOQMQIBBEAAAAAAAATsCgRAAAAAAAAELAoxDFgYCAACEQIAAqAogfuyIRRAAAAAAAAOC/oETNzMzMzMz0v6IQxYGAgAAhEiAAKgKMHyEBIA1EMzMzMzMz8z8QtoGAgAAhDyAGKALcASAGKALgASALIA9EAAAAAAAAEkCiRDMzMzMzM9M/oCASRDMzMzMzM+M/IA6jIg8gEEQtQxzr4jZaP6IiECAQIBBiGyIQIBAgDyAPIA9iGyIPIBAgD2MbokRmZmZmZmYCQESamZmZmZnpPxCmgICAACEDIAZEAAAAAAAA8D9ELUMc6+I2Gj8gDkQYLURU+yEZQKIgC6MiDiAOIA5iGyIORC1DHOviNho/IA5ELUMc6+I2Gj9kG0TNzMzMzMz0P0QAAAAAAAAAACAEu0QAAAAAAADgP6IgAbugIg4gDkQAAAAAAAAAAGMbIg4gDkTNzMzMzMz0P2QbRGZmZmZmZvY/okQzMzMzMzPTP6AiDkQAAAAA4cLkP6Kio7Y4AtABIAYgDrY4AsgBIAZBADYCwAEgBiADNgK8ASAAIAkQlYCAgAAgAEEAOgDpIiAFQgA3AzAgBUKAgICAgIDi0cAANwMoIAVC+v2p48vupLQ/NwMgIAUgDUT6fmq8dJNoP6IgDaIgEUQzMzMzMzPTP6CiOQMYIAVCADcDOCAFQgA3A0AgBUIANwNIIABBuBFqIAVBGGoQkICAgAAgBUHQAGokgICAgAAPC0EAIAZBgAFBwJLAgAAQloCAgAAACyAJIAZBrI/AgAAQjoCAgAAACw4AIAAgASACEJmAgIAAC/cMBAF/CnwCfwF+I4CAgIAAQSBrIgIkgICAgAAgAEGIH2ogAUHgAPwKAAAgAEEBOgDoIgJAIAArA4AIIgNEzczMzMzM3D+iIgREAAAAAAAAFEBmRQ0ARDMzMzMzM/M/IQUgAEQAAAAAAADwPyAERAAAAAAAADZAIAREAAAAAAAANkBjG0QYLURU+yEZQKIgA6MiBhCngYCAAEQzMzMzMzPzP6MiB6EgB0QAAAAAAADwP6AiB6M5A4ggIAAgBhCpgYCAACIGRAAAAAAAAADAoiAHozkDgCAgACAGRAAAAAAAAPA/oCIGRAAAAAAAAOA/oiAHoyIIOQP4HyAAIAaaIAejOQPwHyAAIAg5A+gfAkACQCAAKgKkHxCtgYCAAPwAQQFHDQAgACAERAAAAAAAAHRAIAREAAAAAAAAdEBjG0QYLURU+yEZQKIgA6MiBxCpgYCAAEQAAAAAAAAAwKIgBxCngYCAAEQAAAAAAADgP6IiCUQAAAAAAADwP6AiBqMiCDkDyCEgACAGIAajOQPAISAARAAAAAAAAPA/IAREAAAAAABAj0AgBEQAAAAAAECPQGMbRBgtRFT7IRlAoiADoyIKEKeBgIAARAAAAAAAAOA/oiIHoSAHRAAAAAAAAPA/oCIHoyILOQOYISAAIAoQqYGAgABEAAAAAAAAAMCiIAejIgo5A5AhIAAgCzkDiCEgACAKOQOAISAAIAcgB6M5A/ggIABEAAAAAAAA8D8gBEQAAAAAAAA+QCAERAAAAAAAAD5AYxtEGC1EVPshGUCiIAOjIgoQp4GAgABEMzMzMzMz8z+jIgehIAdEAAAAAAAA8D+gIgejOQPQICAAIAoQqYGAgAAiCkQAAAAAAAAAwKIgB6M5A8ggIAAgCkQAAAAAAADwP6AiCkQAAAAAAADgP6IgB6MiCzkDwCAgACAKmiAHozkDuCAgACALOQOwIEQAAAAAAHDHQCEHRAAAAAAAAPA/IAmhIAajIgYhCQwBC0SamZmZmZn5PyEFIABEAAAAAAAA8D8gBEQAAAAAAIBbQCAERAAAAAAAgFtAYxtEGC1EVPshGUCiIAOjIgYQp4GAgABEmpmZmZmZ+T+jIgehIAdEAAAAAAAA8D+gIgejOQPQICAAIAYQqYGAgAAiBkQAAAAAAAAAwKIgB6M5A8ggIAAgBkQAAAAAAADwP6AiBkQAAAAAAADgP6IgB6MiCDkDwCAgACAGmiAHozkDuCAgACAIOQOwICAAIAREAAAAAAAAdEAgBEQAAAAAAAB0QGMbRBgtRFT7IRlAoiADoyIHEKmBgIAARAAAAAAAAADAoiAHEKeBgIAARGZmZmZmZgZAoyIGRDbEa5/J8/E/oyIJRAAAAAAAAPA/oCIHoyIIOQPIISAAIAZENsRrn8nz8T+iIgpEAAAAAAAA8D+gIAejOQPAISAARAAAAAAAAPA/IAREAAAAAAD4kUAgBEQAAAAAAPiRQGMbRBgtRFT7IRlAoiADoyILEKeBgIAARJqZmZmZmQFAoyIMRILcyKBBkvM/oyIGoSAGRAAAAAAAAPA/oCIGozkDmCEgACALEKmBgIAARAAAAAAAAADAoiAGoyILOQOQISAARAAAAAAAAPA/IAxEgtzIoEGS8z+iIgyhIAajOQOIISAAIAs5A4AhIAAgDEQAAAAAAADwP6AgBqM5A/ggRAAAAAAAAPA/IAmhIAejIQlEAAAAAAAA8D8gCqEgB6MhBkQAAAAAAFC0QCEHCyAAIAk5A+AhIAAgCDkD2CEgACAGOQPQISAARAAAAAAAAPA/IAQgByAEIAdjG0QYLURU+yEZQKIgA6MiAxCngYCAACAFoyIEoSAERAAAAAAAAPA/oCIEozkDqCIgACADEKmBgIAAIgNEAAAAAAAAAMCiIASjOQOgIiAARAAAAAAAAPA/IAOhIgNEAAAAAAAA4D+iIASjIgc5A5giIAAgAyAEozkDkCIgACAHOQOIIgJAIAAoArARIg1FDQAgACgCrBFB5QFqIQFBACEOA0ACQCABLQAAQQFHDQAgACAOEJWAgIAACyABQegBaiEBIA0gDkEBaiIORw0ACwsgAkEgaiSAgICAAA8LIAJCgICAgICAgIrAADcDACACIAQ5AwggAkGCgICAAK1CIIYiDyACQQhqrYQ3AxggAiAPIAKthDcDEEHtgcCAACACQRBqQeiKwIAAEImAgIAAAAsOACAALQDZJkF/c0EBcQuUCAEGfwJAIAAoArARIgFFDQAgACgCrBEiAiEDAkAgAUHoAWwiBEGYfmoiBUHoAW5BAWpBA3EiAUUNACABQegBbCEGQQAhAQNAIAIgAWoiA0GkAWpCADcCACADQewAakIANwIAIANBNGpCADcCACADQeUBakEAOgAAIAYgAUHoAWoiAUcNAAsgAiABaiEDCyAFQbgFSQ0AIAIgBGohAQNAIANBzQNqQQA6AAAgA0GkAWpCADcCACADQewAakIANwIAIANBNGpCADcCACADQeUBakEAOgAAIANBtQVqQQA6AAAgA0GMA2pCADcCACADQdQCakIANwIAIANBnAJqQgA3AgAgA0GdB2pBADoAACADQfQEakIANwIAIANBvARqQgA3AgAgA0GEBGpCADcCACADQdwGakIANwIAIANBpAZqQgA3AgAgA0HsBWpCADcCACADQaAHaiIDIAFHDQALC0GAeCEBA0AgACABaiIDQbgIakEANgIAIANBsAhqQQA2AgAgA0GoCGpBADYCACADQaAIakEANgIAIANBmAhqQQA2AgAgA0GQCGpBADYCACADQYgIakEANgIAIANBgAhqQQA2AgAgAUHAAGoiAQ0ACyAAQQE6ANkmIABBADoA9B4gAEEAOgCsHiAAQQA6AOQdIABBADoAnB0gAEEAOgDUHCAAQQA6AIwcIABBADoAxBsgAEEAOgD8GiAAQQA6ALQaIABBADoA7BkgAEEAOgCkGSAAQQA6ANwYIABBADoAlBggAEEAOgDMFyAAQQA6AIQXIABBADoAvBYgAEEAOgD0FSAAQQA6AKwVIABBADoA5BQgAEEAOgCcFCAAQQA6ANQTIABBADoAjBMgAEEAOgDEEiAAQQA6APwRIABCADcDqCAgAEIANwOgICAAQgA3A5ggIABCADcDkCAgAEIANwPYICAAQgA3A+AgIABCADcD6CAgAEIANwPwICAAQgA3A6AhIABCADcDqCEgAEIANwOwISAAQgA3A7ghIABCADcD6CEgAEIANwPwISAAQgA3A/ghIABCADcDgCIgAEIANwPIIiAAQgA3A8AiIABCADcDuCIgAEIANwOwIiAAQgA3A5AjIABCADcDiCMgAEIANwOAIyAAQgA3A/giIABCADcD2CMgAEIANwPQIyAAQgA3A8gjIABCADcDwCMgAEIANwOgJCAAQgA3A5gkIABCADcDkCQgAEIANwOIJCAAQgA3A+gkIABCADcD4CQgAEIANwPYJCAAQgA3A9AkIABCADcDsCUgAEIANwOoJSAAQgA3A6AlIABCADcDmCUgAEIANwP4JSAAQgA3A/AlIABCADcD6CUgAEIANwPgJSAAQgA3A8AmIABCADcDuCYgAEIANwOwJiAAQgA3A6gmC7AqAw1/B32LAXwjgICAgABBgAhrIgckgICAgAACQCACRQ0AIAJBAnQiCEUNACABQQAgCPwLAAsCQCAERQ0AIARBAnQiCEUNACADQQAgCPwLAAsCQCAALQDYJkEBRw0AAkAgBSAAKgK0EZOLQwrXIzxdDQAgACAFOAK0ESAAIAW7RAAAAAAAwJJAoxDFgYCAADkDoBEgACgCsBEiCUUNACAAKAKsEUHlAWohCEEAIQoDQAJAIAgtAABBAUcNACAAIAoQlYCAgAALIAhB6AFqIQggCSAKQQFqIgpHDQALCyACQQJ0IQsgACgCsBEhDAJAAkACQCACRQ0AIAwhDUEAIQ5BACEPA0AgDkF/aiEQQQAgDiAMIA4gDEsbayERQQAgDiANIA4gDUsbIhJrIRMgACgCrBEgDkHoAWxqQeUBaiEJA0AgCSEKIBEgECIIakF/Rg0EIBMgCGpBf0YNAyAKQegBaiEJIAhBAWohECAKLQAARQ0ACyAIQQJqIQ4gCkGbfmoiCCgCwAEhCSAIKgLMASEUIAgqAtABIRUgCCoCyAEhFkMAAAAAIQUgCyETIAEhEQNAIBEhCiAUIRcCQAJAIAkgCCgCvAFJDQBDAAAAACEUDAELAkAgCSAIKALgASIRSQ0AIAkgEUGolsCAABCOgICAAAALIAggCUEBaiIRNgLAASAIKALcASAJQQJ0aioCACEUIBEhCQsCQCAIKAK4ASIRQQRJDQBBACARQQNBuJbAgAAQloCAgAAACwJAAkAgEQ0AQwAAAAAhGAwBCyAIKgI4IRggCCAIKgI0Ihk4AjggCCAZIAgqAiiUIBggCCoCLJSSIBQgCCoCMJSSIhg4AjQgGEMAAAAAkiEYIBFBOGxBCGoiEUHAAEYNACAIKgJwIRkgCCAIKgJsIho4AnAgCCAaIAgqAmCUIBkgCCoCZJSSIBQgCCoCaJSSIhk4AmwgGCAZkiEYIBFB+ABGDQAgCCoCqAEhGSAIIAgqAqQBIho4AqgBIAggGiAIKgKYAZQgGSAIKgKcAZSSIBQgCCoCoAGUkiIUOAKkASAYIBSSIRgLIApBBGohESAKIAoqAgAgFUMAAIA/IBYgGJRDMzOzPpIiFCAUlEMAAIA/kpGVIhQgF5OUkjgCACAYiyIYIAUgBSAFXBsiBSAFIBggGCAYXBsiGCAFIBheGyEFIBNBfGoiEw0ACyAIIBQ4AswBIAAgECAFIAIQl4CAgAAgD3IhDyAAKAKwESENDAALCyAMIQ1BACEJQQAhDwNAIAkgDCAJIAxLGyEQIAkgDSAJIA1LGyESIAAoAqwRIAlB6AFsakHlAWohCgNAIBAgCSIIRg0DIBIgCEYNAiAIQQFqIQkgCi0AACERIApB6AFqIQogEUEBRw0ACyAAIAhDAAAAAEEAEJeAgIAAIA9yIQ8gACgCsBEhDQwACwsgEiANQeCawIAAEI6AgIAAAAsCQCAALQDZJkEBRw0AIA9BAXENACAALQD8EQ0AIAAtAMQSQQFxDQAgAC0AjBNBAXENACAALQDUE0EBcQ0AIAAtAJwUQQFxDQAgAC0A5BRBAXENACAALQCsFUEBcQ0AIAAtAPQVQQFxDQAgAC0AvBZBAXENACAALQCEF0EBcQ0AIAAtAMwXQQFxDQAgAC0AlBhBAXENACAALQDcGEEBcQ0AIAAtAKQZQQFxDQAgAC0A7BlBAXENACAALQC0GkEBcQ0AIAAtAPwaQQFxDQAgAC0AxBtBAXENACAALQCMHEEBcQ0AIAAtANQcQQFxDQAgAC0AnB1BAXENACAALQDkHUEBcQ0AIAAtAKweQQFxDQAgAC0A9B5BAXFFDQELQQAhCCAHQYAEakEAQYAE/AsAIAdBAEGABPwLAAJAIAJBgQFJDQBBACACQYABQdCawIAAEJaAgIAAAAsgAEG4EWogByACIAdBgARqIAIQnICAgAAgACoCiB8QrYGAgAD8ACIKQQAgCkEAShsiCkECIApBAkgbQShsIgorA7CLwIAAIRsgACoCoB+7RAAAAAAAABRAokQAAAAAAADwP6AiHEQzMzMzMzPjPxC2gYCAACEdIAAqArAfIRQgACsDgAghHiAAKgKsHyEXRLgehetRuL4/RHsUrkfheqQ/IAotALiLwIAAIhMbIh8Qy4GAgAAhICAAKgKQESEYQwAAAAAhBUQAAAAAAADwvyAeRHsUrkfhepQ/oqMQsoGAgAAhISAAKgK0HyEZQwAAgD9DAAAAACAYIBhDAAAAAF0bIhggGEMAAIA/Xhu7RJqZmZmZmfk/ELaBgIAAISICQCACRQ0AIBtEmpmZmZmZ4T8gHaOiISMgF7tEGC1EVPshGUCiIB6jISREAAAAAAAA8D8gIaEhJSAUuyEmIBm7IScgACsDoCYhKCAAKwOYJiEpIAArA5AmISogACsDiCYhKyAAKwOAJiEsIAArA8AmIS0gACsDuCYhLiAAKwOwJiEvIAArA6gmITAgACsDoCQhMSAAKwOYJCEyIAArA5AkITMgACsDiCQhNCAAKwOQIyE1IAArA4gjITYgACsDgCMhNyAAKwP4IiEhIAArA/glITggACsD8CUhOSAAKwPoJSE6IAArA+AlITsgACsD2CMhPCAAKwPQIyE9IAArA8gjIT4gACsDwCMhPyAAKwPIIiFAIAArA8AiIUEgACsDuCIhQiAAKwOwIiFDIAArA7AlIUQgACsDqCUhRSAAKwOgJSFGIAArA5glIUcgACsD6CQhSCAAKwPgJCFJIAArA9gkIUogACsD0CQhSyAAKwOAIiFMIAArA/ghIRsgACsD8CEhTSAAKwPoISFOIAArA7ghIU8gACsDsCEhHSAAKwOoISFQIAArA6AhIVEgACsD8CAhUiAAKwPoICFTIAArA+AgIVQgACsD2CAhHiAAKwOoICFVIAArA6AgIVYgACsDmCAhVyAAKwOQICFYIAArA8gmIVkgACsD0CYhWiAAKwOAJCFbIAArA/gjIVwgACsD8CMhXSAAKwPoIyFeIAArA+AjIV8gACsD8CIhYCAAKwPoIiFhIAArA+AiIWIgACsD2CIhYyAAKwPQIiFkIAArA9glIWUgACsD0CUhZiAAKwPIJSFnIAArA8AlIWggACsDuCUhaSAAKwO4IyFqIAArA7AjIWsgACsDqCMhbCAAKwOgIyFtIAArA5gjIW4gACsDqCIhbyAAKwOgIiFwIAArA5giIXEgACsDkCIhciAAKwOIIiFzIAArA5AlIXQgACsDiCUhdSAAKwOAJSF2IAArA/gkIXcgACsD8CQheCAAKwPIJCF5IAArA8AkIXogACsDuCQheyAAKwOwJCF8IAArA6gkIX0gACsD4CEhfiAAKwPYISF/IAArA9AhIYABIAArA8ghIYEBIAArA8AhIYIBIAArA5ghIYMBIAArA5AhIYQBIAArA4ghIYUBIAArA4AhIYYBIAArA/ggIYcBIAArA9AgIYgBIAArA8ggIYkBIAArA8AgIYoBIAArA7ggIYsBIAArA7AgIYwBIAArA4ggIY0BIAArA4AgIY4BIAArA/gfIY8BIAArA/AfIZABIAArA+gfIZEBQQAhCiAHQYAEaiEJIAchESABIQggAyEQAkADQCAeIZIBIFEhkwEgTiGUASBDIZUBIEEhlgEgPyGXASA9IZgBIDshmQEgOSGaASAhIZsBIDYhnAEgNCGdASAyIZ4BIDAhnwEgLiGgAUQAAAAAAADwPyAkIFmgIh5EGC1EVPshGcCgIB4gHkQYLURU+yEZQGQbIlkQp4GAgABEAAAAAAAA4D+iIjZEAAAAAAAA4D+gICaioSEyRAAAAAAAAAAARAAAAAAAAAAAIFogJSAiIFqhoqAiWiAjIB8gHCAIKgIAIBEqAgAgCSoCAJJDAAAAP5SSu6KgEMuBgIAAICChoiAnoqIiHiCMAaIgiwEgkgGioCCKASBUoqAgiQEgUyKhAaKhIIgBIFKioSIhICGZRCNCkgyhnMc7YxsiTiCCAaIggQEglAGioCCAASBNoqAgfyAbIqIBoqEgfiBMoqEiGyAbmUQjQpIMoZzHO2MbIRtEAAAAAAAAAABEAAAAAAAAAAAgkAEgWCKjAaIgkQEgHqKgII8BIFeioCCOASBWIqQBoqEgjQEgVaKhIiEgIZlEI0KSDKGcxztjGyJRIIcBoiCGASCTAaKgIIUBIFCioCCEASAdIqUBoqEggwEgT6KhIh0gHZlEI0KSDKGcxztjGyEdAkACQCATRQ0AIB0hQyAbISEMAQsgACBJOQPoJCAAIB05A9AkIAAgSzkD2CQgACBHOQOgJSAAIEU5A7AlIAAgGzkDmCUgAEQAAAAAAAAAACAdIH2iIHwgS6KgIHsgSqKgIHogSaKhIHkgSKKhIiEgIZlEI0KSDKGcxztjGyJDOQPgJCAARAAAAAAAAAAAIBsgeKIgdyBHoqAgdiBGoqAgdSBFoqEgdCBEoqEiISAhmUQjQpIMoZzHO2MbIiE5A6glIEUhRCAhIUUgRyFGIBshRyBJIUggQyFJIEshSiAdIUsLIAggMkQAAAAAAAAAAEQAAAAAAAAAAEQAAAAAAAAAACBDIHOiIHIglQGioCBxIEKioCBwIJYBoqEgbyBAoqEiMCAwmUQjQpIMoZzHO2MbIj8gbqIgbSCXAaKgIGwgPqKgIGsgmAGioSBqIDyioSIwIDCZRCNCkgyhnMc7YxsiOyBpoiBoIJkBoqAgZyA6oqAgZiCaAaKhIGUgOKKhIjAgMJlEI0KSDKGcxztjGyI5orYiFDgCAEQAAAAAAAAAAEQAAAAAAAAAAEQAAAAAAAAAACAhIGSiIGMgmwGioCBiIDeioCBhIJwBoqEgYCA1oqEiMCAwmUQjQpIMoZzHO2MbIjQgX6IgXiCdAaKgIF0gM6KgIFwgngGioSBbIDGioSIwIDCZRCNCkgyhnMc7YxsiMCAsoiArIJ8BoqAgKiAvoqAgKSCgAaKhICggLaKhIi4gLplEI0KSDKGcxztjGyEuAkAgBCAKRg0AIBBEAAAAAAAA8D9EAAAAAAAA4D8gNqEgJqKhIDIgExsgLqK2Ihg4AgAgGIsiGCAUiyIUIAUgBSAFXBsiBSAFIBQgFCAUXBsiFCAFIBReGyIFIAUgBVwbIgUgBSAYIBggGFwbIhggBSAYXhshBSARQQRqIREgCUEEaiEJIAhBBGohCCAQQQRqIRAgoAEhLSCfASEvIJ4BITEgMCEyIJ0BITMgnAEhNSA0ITYgmwEhNyCaASE4IJkBITogmAEhPCA7IT0glwEhPiCWASFAID8hQSCVASFCIKIBIUwglAEhTSClASFPIJMBIVAgoQEhUiBOIVMgkgEhVCCkASFVIFEhViCjASFXIB4hWCACIApBAWoiCkYNAgwBCwsgACBZOQPIJiAAIFo5A9AmIAAgmgE5A/glIAAgOTkD8CUgACCZATkD6CUgACA7OQPgJSAAIJgBOQPYIyAAIDs5A9AjIAAglwE5A8gjIAAgPzkDwCMgACCWATkDyCIgACA/OQPAIiAAIJUBOQO4IiAAIEM5A7AiIAAgogE5A4AiIAAgGzkD+CEgACCUATkD8CEgACBOOQPoISAAIKUBOQO4ISAAIB05A7AhIAAgkwE5A6ghIAAgUTkDoCEgACChATkD8CAgACBOOQPoICAAIJIBOQPgICAAIB45A9ggIAAgpAE5A6ggIAAgUTkDoCAgACCjATkDmCAgACAeOQOQICAAIKABOQPAJiAAIC45A7gmIAAgnwE5A7AmIAAgMDkDqCYgACCeATkDoCQgACAwOQOYJCAAIJ0BOQOQJCAAIDQ5A4gkIAAgnAE5A5AjIAAgNDkDiCMgACCbATkDgCMgACAhOQP4IiAEIARBwJrAgAAQjoCAgAAACyAAIFk5A8gmIAAgWjkD0CYgACCaATkD+CUgACA5OQPwJSAAIJkBOQPoJSAAIDs5A+AlIAAgmAE5A9gjIAAgOzkD0CMgACCXATkDyCMgACA/OQPAIyAAIJYBOQPIIiAAID85A8AiIAAglQE5A7giIAAgQzkDsCIgACCiATkDgCIgACAbOQP4ISAAIJQBOQPwISAAIE45A+ghIAAgpQE5A7ghIAAgHTkDsCEgACCTATkDqCEgACBROQOgISAAIKEBOQPwICAAIE45A+ggIAAgkgE5A+AgIAAgHjkD2CAgACCkATkDqCAgACBROQOgICAAIKMBOQOYICAAIB45A5AgIAAgoAE5A8AmIAAgLjkDuCYgACCfATkDsCYgACAwOQOoJiAAIJ4BOQOgJCAAIDA5A5gkIAAgnQE5A5AkIAAgNDkDiCQgACCcATkDkCMgACA0OQOIIyAAIJsBOQOAIyAAICE5A/giIAVDlb/WM11BAXMhCAsgD0EBcQ0AIAAtAPwRIAAtAMQSciAALQCME3IgAC0A1BNyIAAtAJwUciAALQDkFHIgAC0ArBVyIAAtAPQVciAALQC8FnIgAC0AhBdyIAAtAMwXciAALQCUGHIgAC0A3BhyIAAtAKQZciAALQDsGXIgAC0AtBpyIAAtAPwaciAALQDEG3IgAC0AjBxyIAAtANQcciAALQCcHXIgAC0A5B1yIAAtAKweciAALQD0HnIgCHJBAXENACAAQgA3A5AgIABBAToA2SYgAEIANwOYICAAQgA3A6AgIABCADcDqCAgAEIANwPYICAAQgA3A+AgIABCADcD6CAgAEIANwPwICAAQgA3A6AhIABCADcDqCEgAEIANwOwISAAQgA3A7ghIABCADcD6CEgAEIANwPwISAAQgA3A/ghIABCADcDgCIgAEIANwPIIiAAQgA3A8AiIABCADcDuCIgAEIANwOwIiAAQgA3A5AjIABCADcDiCMgAEIANwOAIyAAQgA3A/giIABCADcDwCMgAEIANwPIIyAAQgA3A9AjIABCADcD2CMgAEIANwOIJCAAQgA3A5AkIABCADcDmCQgAEIANwOgJCAAQgA3A9AkIABCADcD2CQgAEIANwPgJCAAQgA3A+gkIABCADcDsCUgAEIANwOoJSAAQgA3A6AlIABCADcDmCUgAEIANwP4JSAAQgA3A/AlIABCADcD6CUgAEIANwPgJSAAQgA3A8AmIABCADcDuCYgAEIANwOwJiAAQgA3A6gmAkAgAkUNACALRQ0AIAFBACAL/AsACyAERQ0AIARBAnQiCEUNACADQQAgCPwLAAsgB0GACGokgICAgAALiAEBAn8CQCABQQJLDQAgACABQQJ0akGMEWohAwJAIAK8QQF0Qf///3dNDQAgAyoCACECCyADIAI4AgAgAQ0AIAAoArARIgRFDQAgACgCrBFB5QFqIQFBACEDA0ACQCABLQAAQQFHDQAgACADEJWAgIAACyABQegBaiEBIAQgA0EBaiIDRw0ACwsL1Q8FBX8BfQF8AX4HfCOAgICAAEHQAGsiBSSAgICAAAJAAkAgACgCiBEiBkGBAU8NACAAQYgIaiEHIAZBA3QhCEEAIQYCQANAIAggBkYNASAAIAZqIQkgBkEIaiEGIAlBiAhqKAIAIANHDQALIABBASADEJmAgIAAC0E8IQYCQCABvCIJQQF0Qf///3dLDQBBAEMAAP5CQwAAAAAgARCtgYCAACIKIApDAAAAAF0bIgogCkMAAP5CXhsiCkMAAAAAl0MAAH9DlvwBIAogClwbIQYLIAVBEGogByADIAYQn4CAgAACQCAFLQAQRQ0AIAAgBS0AEUH/AXFBA3RqIgYoAgBBAUcNACAAIAYoAgQQlYCAgAALQTwhAwJAIAlBAXRB////d0sNAEEAQwAA/kJDAAAAACABEK2BgIAAIgogCkMAAAAAXRsiCiAKQwAA/kJeGyIKQwAAAACXQwAAf0OW/AEgCiAKXBshAwsgACsDgAghCyAFQQhqIAAgAxCYgICAACAFLQAMIQggBSgCCCEJIAAgACkDmBFCAXwiDDcDmBEgCSAAKAKwESIGTw0BIAAoAqwRIAlB6AFsaiIGQQA2AtQBIAYgDDcDAAJAIAhBAXFFDQAgBkGzwcb7AzYCzAELIAZBAzYCuAEgBkMAAIA/QwAAAAAgAiACQwAAAABdGyICIAJDAACAP14buyINRAAAAAAAAPg/ELaBgIAAIg5EmpmZmZmZ4T+iOQNYIAYgDkTNzMzMzMzcP6I5AyAgBiAOIAAqAogfEK2BgIAA/AAiCEEAIAhBAEobIghBAiAIQQJIG0EobCIIKwOgi8CAACAAKgKUH7tEKVyPwvUovD+ioqI5A5ABIAZDAAD+QkMAAAAAIAEgAUMAAAAAXRsiASABQwAA/kJeG7tEAAAAAABAUcCgRAAAAAAAAChAoxDFgYCAAEQAAAAAAIB7QKIiDkS4HoXrUbiuPyAOoyIPRAAAAAAAAPA/oKI5A0AgBiAORAAAAAAAAPA/IA+hojkDCCAGIA5EAAAAAAAAHkBEAAAAAAAAEkBEAAAAAAAATkBEAAAAAADAWUBEAAAAAAAAPEAgA0H/AXG4Ig8gD0QAAAAAAAA8QGMbIg8gD0QAAAAAAMBZQGQbIhChIg9EuB6F61G4nj+iRBSuR+F6FBlAoCIRIBFEAAAAAAAAEkBjGyIRIBFEAAAAAAAAHkBkG6I5A3ggBkQ2H9eGiqEbQEQtQxzr4jYaPyAQRAAAAAAAAELAoCISRAAAAAAAAETAoxDFgYCAAETNzMzMzMzsP6IiESARIBFiGyIRRC1DHOviNho/IBFELUMc6+I2Gj9kG6M5A4ABIAAqApgfIQEgBkQ2H9eGiqEbQEQtQxzr4jYaPyASRAAAAAAAgDvAoxDFgYCAAEQAAAAAAAAkQKJEmpmZmZmZqT8gAbsiESARIBFiGyIRRJqZmZmZmak/IBFEmpmZmZmZqT9kG6IiESARIBFiGyISRC1DHOviNho/IBJELUMc6+I2Gj9kG6M5A0ggBkQ2H9eGiqEbQEQtQxzr4jYaPyARRAAAAAAAAAhAoyIRIBEgEWIbIhFELUMc6+I2Gj8gEUQtQxzr4jYaP2QbozkDECAGRDYf14aKoRtARC1DHOviNho/RAAAAAAAAAAAIA8gDyAPYhsiD0QAAAAAAAAAACAPRAAAAAAAAAAAZBtEAAAAAAAARECjRAAAAAAAAPA/oEQAAAAAAADgPyAAKgKcH7uhRJqZmZmZmQFAohDFgYCAAER7FK5H4XrUP6KiIg8gDyAPYhsiD0QtQxzr4jYaPyAPRC1DHOviNho/ZBujIg85A1AgBiAPOQMYIAYgDyAPoDkDiAEgEEQAAAAAAABOwKBEAAAAAAAARMCjEMWBgIAAIREgACoCjB+7IhBEAAAAAAAA4L+gRGZmZmZmZva/ohDFgYCAACESIAAqApAfIQEgCCsDmIvAgAAhEyANRDMzMzMzM/M/ELaBgIAAIQ8gBigC3AEgBigC4AEgCyAPRM3MzMzMzBBAokQzMzMzMzPTP6AgEkQzMzMzMzPjPyAOoyIPIBFEYTJVMCqpYz+iIhEgESARYhsiESARIA8gDyAPYhsiDyARIA9jG6JEzczMzMzM/D9EMzMzMzMz4z8QpoCAgAAhAyAGRAAAAAAAAPA/RC1DHOviNho/IA5EGC1EVPshGUCiIAujIg4gDiAOYhsiDkQtQxzr4jYaPyAORC1DHOviNho/ZBsgE0QAAAAAAAD4P0QAAAAAAAAAACAEu0QAAAAAAADgP6IgAbugIg4gDkQAAAAAAAAAAGMbIg4gDkQAAAAAAAD4P2QbRM3MzMzMzARAokQzMzMzMzPjP6BEMzMzMzMz4z+ioiIORAAAAODK1dI/oqKjtjgC0AEgBiAOtjgCyAEgBkEANgLAASAGIAM2ArwBIAAgCRCVgICAACAAQQA6ANkmIAVCADcDMCAFQoCAgICAgNzTwAA3AyggBUL6/anjy+6ktD83AyAgBSANRPyp8dJNYnA/oiANoiAQRDMzMzMzM9M/oKI5AxggBUIANwM4IAVCADcDQCAFQgA3A0ggAEG4EWogBUEYahCQgICAACAFQdAAaiSAgICAAA8LQQAgBkGAAUHAksCAABCWgICAAAALIAkgBkGsj8CAABCOgICAAAALDgAgACABIAIQmYCAgAALgA8HAX8BfRh8AX8GfAF/AX4jgICAgABBIGsiAiSAgICAACAAQYgfaiABQeAA/AoAACAAQQE6ANgmIAAqAogfIQMgAEHoH2pBAyAAKwOACCIERAAAAAAAgGZAIAAqAqQfuxCjgICAACAAQfggakEEIAREAAAAAAAAqUAgACoCqB+7EKOAgIAARAAAAAAAAPA/IAREzczMzMzM3D+iIgVEAAAAAABkuUAgBUQAAAAAAGS5QGMbRBgtRFT7IRlAoiAEoyIGEKeBgIAARDMzMzMzM/M/oyIHoSAHRAAAAAAAAPA/oCIHoyEIIAYQqYGAgAAiBkQAAAAAAAAAwKIgB6MhCUQAAAAAAADwPyAGoSIGIAejIQogBkQAAAAAAADgP6IgB6MhBkQAAAAAAADwPyAFRAAAAAAAULRAIAVEAAAAAABQtEBjG0QYLURU+yEZQKIgBKMiCxCngYCAAERmZmZmZmb2P6MiB6EgB0QAAAAAAADwP6AiB6MhDCALEKmBgIAAIgtEAAAAAAAAAMCiIAejIQ1EAAAAAAAA8D8gC6EiCyAHoyEOIAtEAAAAAAAA4D+iIAejIQ9EAAAAAAAA8D8gBUQAAAAAAMBcQCAFRAAAAAAAwFxAYxtEGC1EVPshGUCiIASjIgsQp4GAgABEMzMzMzMzA0CjIhBEYmhWS2Vx8T+jIgehIAdEAAAAAAAA8D+gIgejIRFEAAAAAAAA8D8gEERiaFZLZXHxP6IiEqEgB6MhECALEKmBgIAARAAAAAAAAADAoiAHoyELIBJEAAAAAAAA8D+gIAejIRJEAAAAAAAA8D8gBUQAAAAAADChQCAFRAAAAAAAMKFAYxtEGC1EVPshGUCiIASjIhMQp4GAgABEAAAAAAAA4D+iIhRE5gSkrPx58j+jIgehIAdEAAAAAAAA8D+gIgejIRVEAAAAAAAA8D8gFETmBKSs/HnyP6IiFKEgB6MhFiATEKmBgIAARAAAAAAAAADAoiAHoyEXIBREAAAAAAAA8D+gIAejIRhEAAAAAAAA8D8gBUQAAAAAADCBQCAFRAAAAAAAMIFAYxtEGC1EVPshGUCiIASjIhMQp4GAgABEmpmZmZmZ+T+jIhREtDn2EiYp6j+jIgehIAdEAAAAAAAA8D+gIgejIRlEAAAAAAAA8D8gFES0OfYSJinqP6IiFKEgB6MhGiATEKmBgIAARAAAAAAAAADAoiAHoyETIBREAAAAAAAA8D+gIAejIRsCQAJAAkACQCADEK2BgIAA/AAiAUEAIAFBAEobIgFBAiABQQJIG0EobCIBLQC4i8CAACIcDQAgBUQAAAAAAAAUQGZFDQIgACAZOQPIJCAAIBM5A8AkIAAgGjkDuCQgACATOQOwJCAAIBs5A6gkIA8hByAOIR0gDSEeIAwhHyAYISAgFyEUIBYhISAVISIMAQsgBiEHIAohHSAJIR4gCCEfIBIhICALIRQgECEhIBEhIiAFRAAAAAAAABRAZkUNAgsgACAiOQO4IyAAIBQ5A7AjIAAgITkDqCMgACAUOQOgIyAAICA5A5gjIAAgHzkDqCIgACAeOQOgIiAAIAc5A5giIAAgHTkDkCIgACAHOQOIIiAARAAAAAAAAPA/IAVEAAAAAAAAFEAgAUGYi8CAAGorAxAiByAHRAAAAAAAABRAYxsiByAHIAVkG0QYLURU+yEZQKIgBKMiBxCngYCAAEQzMzMzMzPzP6MiBaEgBUQAAAAAAADwP6AiBaMiFDkD2CUgACAHEKmBgIAAIgdEAAAAAAAAAMCiIAWjIh05A9AlIAAgB0QAAAAAAADwP6AiHkQAAAAAAADgP6IgBaMiBzkDyCUgACAemiAFoyIFOQPAJSAAIAc5A7glIABBsCBqQQMgBEQAAAAAAIBmQCAAKgKkH7sQo4CAgAAgAEHAIWpBBCAERAAAAAAAAKlAIAAqAqgfuxCjgICAAAJAIBwNACAAIBk5A5AlIAAgEzkDiCUgACAaOQOAJSAAIBM5A/gkIAAgGzkD8CQgDyEGIA4hCiANIQkgDCEIIBghEiAXIQsgFiEQIBUhEQsgACAUOQOgJiAAIB05A5gmIAAgBzkDkCYgACAFOQOIJiAAIAc5A4AmIAAgETkDgCQgACALOQP4IyAAIBA5A/AjIAAgCzkD6CMgACASOQPgIyAAIAg5A/AiIAAgCTkD6CIgACAGOQPgIiAAIAo5A9giIAAgBjkD0CICQCAAKAKwESIjRQ0AIAAoAqwRQeUBaiEBQQAhHANAAkAgAS0AAEEBRw0AIAAgHBCVgICAAAsgAUHoAWohASAjIBxBAWoiHEcNAAsLIAJBIGokgICAgAAPCyACQoCAgICAgICKwAA3AwAgAiAFOQMIIAJBgoCAgACtQiCGIiQgAkEIaq2ENwMYIAIgJCACrYQ3AxBB7YHAgAAgAkEQakHoisCAABCJgICAAAALIAJCgICAgICAgIrAADcDACACIAU5AwggAkGCgICAAK1CIIYiJCACQQhqrYQ3AxggAiAkIAKthDcDEEHtgcCAACACQRBqQeiKwIAAEImAgIAAAAs6AQF/AkAgAEUNACABIAAoAiAiA08NACACIANPDQAgACgCHCABQQJ0aiIAIAAoAgBBASACdHI2AgALC6sHAQd/AkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAIABFDQACQCAAKAIAIgFFDQAgACgCBCICQXxqKAIAIgNBeHEiBEEEQQggA0EDcSIDGyABQdASbCIBckkNAgJAIANFDQAgBCABQSdqSw0ECyACEIGAgIAACwJAIAAoAgwiAUUNACAAKAIQIgJBfGooAgAiA0F4cSIEQQRBCCADQQNxIgMbIAFBAnQiAWpJDQQCQCADRQ0AIAQgAUEnaksNBgsgAhCBgICAAAsCQCAAKAIYIgFFDQAgACgCHCICQXxqKAIAIgNBeHEiBEEEQQggA0EDcSIDGyABQQJ0IgFqSQ0GAkAgA0UNACAEIAFBJ2pLDQgLIAIQgYCAgAALIAAoAighBQJAIAAoAiwiA0UNACAFIQEDQAJAIAEoAgAiAkUNACABQQRqKAIAIgZBfGooAgAiBEF4cSIHQQRBCCAEQQNxIgQbIAJBAnQiAmpJDQoCQCAERQ0AIAcgAkEnaksNDAsgBhCBgICAAAsgAUEMaiEBIANBf2oiAw0ACwsCQCAAKAIkIgFFDQAgBUF8aigCACIDQXhxIgJBBEEIIANBA3EiAxsgAUEMbCIBakkNCgJAIANFDQAgAiABQSdqSw0MCyAFEIGAgIAACwJAIAAoAjAiAUUNACAAKAI0IgJBfGooAgAiA0F4cSIEQQRBCCADQQNxIgMbIAFBLGwiAWpJDQwCQCADRQ0AIAQgAUEnaksNDgsgAhCBgICAAAsgAEF8aigCACIBQXhxIgNBwCNBxCMgAUEDcSIBG0kNDQJAIAFFDQAgA0HkI08NDwsgABCBgICAAAsPC0GAs8CAAEEuQbCzwIAAEIKAgIAAAAtBwLPAgABBLkHws8CAABCCgICAAAALQYCzwIAAQS5BsLPAgAAQgoCAgAAAC0HAs8CAAEEuQfCzwIAAEIKAgIAAAAtBgLPAgABBLkGws8CAABCCgICAAAALQcCzwIAAQS5B8LPAgAAQgoCAgAAAC0GAs8CAAEEuQbCzwIAAEIKAgIAAAAtBwLPAgABBLkHws8CAABCCgICAAAALQYCzwIAAQS5BsLPAgAAQgoCAgAAAC0HAs8CAAEEuQfCzwIAAEIKAgIAAAAtBgLPAgABBLkGws8CAABCCgICAAAALQcCzwIAAQS5B8LPAgAAQgoCAgAAAC0GAs8CAAEEuQbCzwIAAEIKAgIAAAAtBwLPAgABBLkHws8CAABCCgICAAAALwQIBBX9BACEDAkACQAJAAkACQCAARQ0AIAAtALgjQQNJDQAgASAAKAIsTw0AIAJB/////wNLDQEgAkECdCIEQf3///8HTw0BAkACQCAEDQBBBCEDQQAhBAwBCyAEEJKAgIAAIgNFDQMCQCADQXxqLQAAQQNxRQ0AIARFDQAgA0EAIAT8CwALIAIhBAsCQCAAKAIoIAFBDGxqIgAoAgAiAUUNACAAKAIEIgVBfGooAgAiBkF4cSIHQQRBCCAGQQNxIgYbIAFBAnQiAWpJDQQCQCAGRQ0AIAcgAUEnaksNBgsgBRCBgICAAAsgACACNgIIIAAgAzYCBCAAIAQ2AgALIAMPCxCUgICAAAALQQQgBBCTgICAAAALQYCzwIAAQS5BsLPAgAAQgoCAgAAAC0HAs8CAAEEuQfCzwIAAEIKAgIAAAAucMgIKfwR+I4CAgIAAQaAgayICJICAgIAAQQAhAwJAAkACQAJAAkACQAJAIAFBBEsNACACQgA3A7gIIAJCADcDsAggAkIANwOoCCACQgA3A6AIIAJBwAhqQQBBgAj8CwAgAkEAOwEgIAJCADcDGCACQgA3AxAgAkIANwMIIAJCADcDACACQgA3AiQgAkIANwIsIAJCADcCNCACQgA3AjwgAkEAOwFEIAJCADcDSCACQgA3A1AgAkIANwNYIAJCADcDYCACQQA7AWggAkIANwJsIAJCADcCdCACQgA3AnwgAkIANwKEASACQQA7AYwBIAJBADoAgBkgAkIANwP4GCACQgA3A/AYIAJCADcChBkgAkIANwKMGSACQQA6AJQZIAJCADcDmBkgAkIANwOgGSACQQA6AKgZIAJCADcCrBkgAkIANwK0GSACQQA6ALwZIAJCADcDsB0gAkIANwO4HSACQQA6AMAdIAJCADcCxB0gAkIANwLMHSACQQA6ANQdIAJBADoA6B0gAkIANwPgHSACQgA3A9gdIAJBADoA/B0gAkIANwL0HSACQgA3AuwdIAJBADoAqBwgAkIANwOgHCACQgA3A5gcIAJBADoAvBwgAkIANwK0HCACQgA3AqwcIAJBADoA0BwgAkIANwPIHCACQgA3A8AcIAJCADcC1BwgAkIANwLcHCACQQA6AOQcIAJBADoA8BkgAkIANwPoGSACQgA3A+AZIAJBADoAhBogAkIANwL8GSACQgA3AvQZIAJBADoAmBogAkIANwOQGiACQgA3A4gaIAJBADoArBogAkIANwKkGiACQgA3ApwaIAJBADoAoB8gAkIANwOYHyACQgA3A5AfIAJBADoAtB8gAkIANwKsHyACQgA3AqQfIAJBADoAyB8gAkIANwPAHyACQgA3A7gfIAJBADoA3B8gAkIANwLUHyACQgA3AswfIAJBhRtqQQNqIAJBkAH8CgAAIAJCADcD+BogAkIANwPwGiACQgA3A+gaIAJCADcD4BogAkIANwPYGiACQgA3A9AaIAJCADcDiCAgAkIANwOQICACQgA3A5ggIAJByB5qQQBBxQD8CwAgAkEAOwEgIAJCADcDGCACQgA3AxAgAkIANwMIIAJCADcDACACQgA3AiQgAkIANwIsIAJCADcCNCACQgA3AjwgAkEAOwFEIAJCADcDSCACQgA3A1AgAkIANwNYIAJCADcDYCACQQA7AWggAkIANwJsIAJCADcCdCACQgA3AnwgAkIANwKEASACQQA7AYwBIAJBADoA8BEgAkIANwPoESACQgA3A+ARIAJCADcC9BEgAkIANwL8ESACQQA6AIQSIAJCADcDiBIgAkIANwOQEiACQQA6AJgSIAJCADcCnBIgAkIANwKkEiACQQA6AKwSIAJCADcDgBYgAkIANwOIFiACQQA6AJAWIAJCADcClBYgAkIANwKcFiACQQA6AKQWIAJBADoAuBYgAkIANwOwFiACQgA3A6gWIAJBADoAzBYgAkIANwLEFiACQgA3ArwWIAJBADoA+BQgAkIANwPwFCACQgA3A+gUIAJBADoAjBUgAkIANwKEFSACQgA3AvwUIAJBADoAoBUgAkIANwOYFSACQgA3A5AVIAJCADcCpBUgAkIANwKsFSACQQA6ALQVIAJBADoAwBIgAkIANwO4EiACQgA3A7ASIAJBADoA1BIgAkIANwLMEiACQgA3AsQSIAJBADoA6BIgAkIANwPgEiACQgA3A9gSIAJBADoA/BIgAkIANwL0EiACQgA3AuwSIAJBADoA8BcgAkIANwPoFyACQgA3A+AXIAJBADoAhBggAkIANwL8FyACQgA3AvQXIAJBADoAmBggAkIANwOQGCACQgA3A4gYIAJBADoArBggAkIANwKkGCACQgA3ApwYIAJB1RNqQQNqIAJBkAH8CgAAIAJCADcDyBMgAkIANwPAEyACQgA3A7gTIAJCADcDsBMgAkIANwOoEyACQgA3A6ATIAJCADcD2BggAkIANwPgGCACQgA3A+gYIAJBmBdqQQBBxQD8CwAgAkIANwDoHyACQgA3APAfIAJCADcA+B8gAkIANwCAICACQgA3AKceIAJCADcArx4gAkIANwC3HiACQgA3AL8eIAJBADoAxx4gAkIANwCIHiACQgA3AJAeIAJCADcAmB4gAkEANgCgHiACQgA3AI8dIAJCADcAlx0gAkIANwCfHSACQgA3AKcdIAJBADoArx0gAkEANgCIHSACQgA3AIAdIAJCADcA+BwgAkIANwDwHCACQgA3ALQaIAJCADcAvBogAkIANwDEGiACQQA2AMwaIAJCADcAxBkgAkIANwDMGSACQgA3ANQZIAJBADYA3BkgAkIANwC4GCACQgA3AMAYIAJCADcAyBggAkIANwDQGCACQQA6AJcXIAJCADcAjxcgAkIANwCHFyACQgA3AP8WIAJCADcA9xYgAkEANgDwFiACQgA3AOgWIAJCADcA4BYgAkIANwDYFiACQQA6AP8VIAJCADcA9xUgAkIANwDvFSACQgA3AOcVIAJCADcA3xUgAkEANgDYFSACQgA3ANAVIAJCADcAyBUgAkIANwDAFSACQQA2AJwTIAJCADcAlBMgAkIANwCMEyACQgA3AIQTIAJBADYAGyACQgA3ABMgAkIANwALIAJCADcAAyABLQDwmsCAACIELQD4tMCAACIFQdASbCIDEJKAgIAAIgZFDQEgBUF/aiEHQQAhAQNAIAYgAWoiA0IANwMAIANBCGogAikDiCA3AwAgA0EQaiACKQOQIDcDACADQRhqIAIpA5ggNwMAIANB5ABqQf8BOgAAIANB5QBqIAIpAOUfNwAAIANB7QBqIAIpAO0fNwAAIANB9QBqIAIpAPUfNwAAIANB/QBqIAIpAP0fNwAAIANBhAFqIAIoAIQgNgAAIANBiAFqIAJBkB9qQdAA/AoAACADQeABakIANwMAIANB3AFqQQA6AAAgA0HYAWpBADsBACADQegBaiACQcgeakHFAPwKAAAgA0HQAmpB/wE6AAAgA0HRAmogAikApB43AAAgA0HZAmogAikArB43AAAgA0HhAmogAikAtB43AAAgA0HpAmogAikAvB43AAAgA0HxAmogAigAxB42AAAgA0H1AmogAikAhR43AAAgA0H9AmogAikAjR43AAAgA0GFA2ogAikAlR43AAAgA0GMA2ogAikAnB43AAAgA0GUA2ogAkGwHWpB0AD8CgAAIANBjARqQf8BOgAAIANB6ANqQQA6AAAgA0HkA2pBADsBACADQY0EaiACKQCMHTcAACADQZUEaiACKQCUHTcAACADQZ0EaiACKQCcHTcAACADQaUEaiACKQCkHTcAACADQa0EaiACKACsHTYAACADQbEEaiACKQDtHDcAACADQbkEaiACKQD1HDcAACADQcEEaiACKQD9HDcAACADQcgEaiACKQCEHTcAACADQdAEaiACQZgcakHQAPwKAAAgA0GkBWpBADoAACADQaAFakEAOwEAIANBpQVqIAJBhRtqQZMB/AoAACADQbgHakH/AToAACADQZQHakH/AToAACADQewGakIANwIAIANB6AZqQQA2AgAgA0HgBmogAikD+Bo3AwAgA0HYBmogAikD8Bo3AwAgA0HQBmogAikD6Bo3AwAgA0HIBmogAikD4Bo3AwAgA0HABmogAikD2Bo3AwAgA0G4BmogAikD0Bo3AwAgA0G5B2ogAikAsRo3AAAgA0HBB2ogAikAuRo3AAAgA0HJB2ogAikAwRo3AAAgA0HQB2ogAikAyBo3AAAgA0HYB2ogAkHgGWpB0AD8CgAAIANBrAhqQQA6AAAgA0GoCGpBADsBACADQa0IaiACKQDBGTcAACADQbUIaiACKQDJGTcAACADQb0IaiACKQDRGTcAACADQcQIaiACKQDYGTcAACADQcwIaiACQfAYakHQAPwKAAAgA0GoCWpCADcDACADQaAJakEAOgAAIANBnAlqQQA7AQAgA0GMCmpB/wE6AAAgA0GwCWogAikD2Bg3AwAgA0G4CWogAikD4Bg3AwAgA0HACWogAikD6Bg3AwAgA0GNCmogAikAtRg3AAAgA0GVCmogAikAvRg3AAAgA0GdCmogAikAxRg3AAAgA0GlCmogAikAzRg3AAAgA0GsCmogAigA1Bg2AAAgA0GwCmogAkHgF2pB0AD8CgAAIANBiAtqQgA3AwAgA0GEC2pBADoAACADQYALakEAOwEAIANBkAtqIAJBmBdqQcUA/AoAACADQfgLakH/AToAACADQfkLaiACKQD0FjcAACADQYEMaiACKQD8FjcAACADQYkMaiACKQCEFzcAACADQZEMaiACKQCMFzcAACADQZkMaiACKACUFzYAACADQZ0MaiACKQDVFjcAACADQaUMaiACKQDdFjcAACADQa0MaiACKQDlFjcAACADQbQMaiACKQDsFjcAACADQbwMaiACQYAWakHQAPwKAAAgA0G0DWpB/wE6AAAgA0GQDWpBADoAACADQYwNakEAOwEAIANBtQ1qIAIpANwVNwAAIANBvQ1qIAIpAOQVNwAAIANBxQ1qIAIpAOwVNwAAIANBzQ1qIAIpAPQVNwAAIANB1Q1qIAIoAPwVNgAAIANB2Q1qIAIpAL0VNwAAIANB4Q1qIAIpAMUVNwAAIANB6Q1qIAIpAM0VNwAAIANB8A1qIAIpANQVNwAAIANB+A1qIAJB6BRqQdAA/AoAACADQcwOakEAOgAAIANByA5qQQA7AQAgA0HNDmogAkHVE2pBkwH8CgAAIANB4BBqQf8BOgAAIANBvBBqQf8BOgAAIANBlBBqQgA3AgAgA0GQEGpBADYCACADQYgQaiACKQPIEzcDACADQYAQaiACKQPAEzcDACADQfgPaiACKQO4EzcDACADQfAPaiACKQOwEzcDACADQegPaiACKQOoEzcDACADQeAPaiACKQOgEzcDACADQeEQaiACKQCBEzcAACADQekQaiACKQCJEzcAACADQfEQaiACKQCREzcAACADQfgQaiACKQCYEzcAACADQYARaiACQbASakHQAPwKAAAgA0HUEWpBADoAACADQdARakEAOwEAIANB1RFqIAIpAAA3AAAgA0HdEWogAikACDcAACADQeURaiACKQAQNwAAIANB7BFqIAIpABc3AAAgA0H0EWogAkHgEWpB0AD8CgAAIANByBJqQQA6AAAgA0HEEmpBADsBACABQdASaiEBIAdBf2oiBw0ACyAGIAFqIgFBsG1qIgNBADYC1BIgAUEANgIAIAMgAikDiCA3A9gSIAMgAikDkCA3A+ASIAMgAikDmCA3A+gSIANB/wE6ALQTIAMgAikA5R83ALUTIAMgAikA7R83AL0TIAMgAikA9R83AMUTIAMgAikA/R83AM0TIAMgAigAhCA2ANQTIANB2BNqIAJBkB9qQdAA/AoAACADQgA3A7AUIANBADoArBQgA0EAOwGoFCADQbgUaiACQcgeakHFAPwKAAAgA0H/AToAoBUgAyACKQCkHjcAoRUgAyACKQCsHjcAqRUgAyACKQC0HjcAsRUgAyACKQC8HjcAuRUgAyACKADEHjYAwRUgAyACKQCFHjcAxRUgAyACKQCNHjcAzRUgAyACKQCVHjcA1RUgAyACKQCcHjcA3BUgA0HkFWogAkGwHWpB0AD8CgAAIANB/wE6ANwWIANBADoAuBYgA0EAOwG0FiADIAIpAIwdNwDdFiADIAIpAJQdNwDlFiADIAIpAJwdNwDtFiADIAIpAKQdNwD1FiADIAIoAKwdNgD9FiADIAIpAO0cNwCBFyADIAIpAPUcNwCJFyADIAIpAP0cNwCRFyADIAIpAIQdNwCYFyADQaAXaiACQZgcakHQAPwKAAAgA0EAOgD0FyADQQA7AfAXIANB9RdqIAJBhRtqQZMB/AoAACADQf8BOgCIGiADQf8BOgDkGSADQgA3ArwZIANBADYCuBkgAyACKQP4GjcDsBkgAyACKQPwGjcDqBkgAyACKQPoGjcDoBkgAyACKQPgGjcDmBkgAyACKQPYGjcDkBkgAyACKQPQGjcDiBkgAyACKQCxGjcAiRogAyACKQC5GjcAkRogAyACKQDBGjcAmRogAyACKQDIGjcAoBogA0GoGmogAkHgGWpB0AD8CgAAIANBADoA/BogA0EAOwH4GiADIAIpAMEZNwD9GiADIAIpAMkZNwCFGyADIAIpANEZNwCNGyADIAIpANgZNwCUGyADQZwbaiACQfAYakHQAPwKAAAgA0IANwP4GyADQQA6APAbIANBADsB7BsgA0H/AToA3BwgAyACKQPYGDcDgBwgAyACKQPgGDcDiBwgAyACKQPoGDcDkBwgAyACKQC1GDcA3RwgAyACKQC9GDcA5RwgAyACKQDFGDcA7RwgAyACKQDNGDcA9RwgAyACKADUGDYA/BwgA0GAHWogAkHgF2pB0AD8CgAAIANCADcD2B0gA0EAOgDUHSADQQA7AdAdIANB4B1qIAJBmBdqQcUA/AoAACADQf8BOgDIHiADIAIpAPQWNwDJHiADIAIpAPwWNwDRHiADIAIpAIQXNwDZHiADIAIpAIwXNwDhHiADIAIoAJQXNgDpHiADIAIpANUWNwDtHiADIAIpAN0WNwD1HiADIAIpAOUWNwD9HiADIAIpAOwWNwCEHyADQYwfaiACQYAWakHQAPwKAAAgA0H/AToAhCAgA0EAOgDgHyADQQA7AdwfIAMgAikA3BU3AIUgIAMgAikA5BU3AI0gIAMgAikA7BU3AJUgIAMgAikA9BU3AJ0gIAMgAigA/BU2AKUgIAMgAikAvRU3AKkgIAMgAikAxRU3ALEgIAMgAikAzRU3ALkgIAMgAikA1BU3AMAgIANByCBqIAJB6BRqQdAA/AoAACADQQA6AJwhIANBADsBmCEgA0GdIWogAkHVE2pBkwH8CgAAIANB/wE6ALAjIANB/wE6AIwjIANCADcC5CIgA0EANgLgIiADIAIpA8gTNwPYIiADIAIpA8ATNwPQIiADIAIpA7gTNwPIIiADIAIpA7ATNwPAIiADIAIpA6gTNwO4IiADIAIpA6ATNwOwIiADIAIpAIETNwCxIyADIAIpAIkTNwC5IyADIAIpAJETNwDBIyADIAIpAJgTNwDIIyADQdAjaiACQbASakHQAPwKAAAgA0EAOgCkJCADQQA7AaAkIAMgAikAADcApSQgAyACKQAINwCtJCADIAIpABA3ALUkIAMgAikAFzcAvCQgA0HEJGogAkHgEWpB0AD8CgAAIANBADoAmCUgA0EAOwGUJSAFQQJ0IgMQkoCAgAAiCEUNAgJAIAhBfGotAABBA3FFDQAgA0UNACAIQQAgA/wLAAsgAxCSgICAACIJRQ0DAkAgCUF8ai0AAEEDcUUNACADRQ0AIAlBACAD/AsACyAFQQxsIgMQkoCAgAAiCkUNBCAFQX9qIgtBA3EhASAKIQMCQAJAIAVBfmpB/wFxQQNJDQAgCkFQaiEHIAtBfHEhCwNAIAciA0HYAGpCBDcCACADQdAAakIANwIAIANByABqQoCAgIDAADcCACADQcAAakIENwIAIANBOGpCADcCACADQTBqIgdCgICAgMAANwIAIAtBfGoiCw0ACyADQeAAaiEDIAENACAHQSRqIQEMAQsDQCADQoCAgIDAADcCACADQQhqQQA2AgAgA0EMaiEDIAFBf2oiAQ0ACyADQXRqIQELIANBADYCACABQgQ3AhBBgBYQkoCAgAAiAUUNBSACQeAQakEAQYAB/AsAIAIgAikDuAgiDDcD2BAgAiACKQOwCCINNwPQECACIAIpA6gIIg43A8gQIAIgAikDoAgiDzcDwBAgAiAPNwOACCACIA43A4gIIAIgDTcDkAggAiAMNwOYCCACIAJBwAhqQYAI/AoAAEG8IxCSgICAACIDRQ0GIANBADYCOCADIAE2AjQgA0HAADYCMCADIAU2AiwgAyAKNgIoIAMgBTYCJCADIAU2AiAgAyAJNgIcIAMgBTYCGCADIAU2AhQgAyAINgIQIAMgBTYCDCADIAU2AgggAyAGNgIEIAMgBTYCACADIAIpA4AINwJAIAMgAikDiAg3AkggAyACKQOQCDcCUCADIAIpA5gINwJYIAMgAEMAgDtHIAAgALwiAUEASBtDAIA7RyABQf////8HcUGAgIB8akGAgID4B0kbIAFBf2pB////A0kbOAI8IANB4ABqIAJBgAj8CgAAIANB4AhqIAJBwBBqQaAB/AoAACADQgA3AoAKIANBiApqIAJBwBBqQaAB/AoAACADQagLakEAQYgY/AsAIAMgBDoAuCMgAyAEQbnz3fF5bEGR6ZeqAnM2ArQjIANBfzYCsCMLIAJBoCBqJICAgIAAIAMPC0EIIAMQk4CAgAAAC0EEIAMQk4CAgAAAC0EEIAMQk4CAgAAAC0EEIAMQk4CAgAAAC0EEQYAWEJOAgIAAAAtBBEG8IxCagICAAAALFgAgACABQQBHQQl0akHgAGpBACAAGwsNACAAQcAAakEAIAAbCxQAAkAgAEUNACAAIAEQooCAgAALCxIAAkAgAEUNACAAEKGAgIAACwvsAQECfyOAgICAAEEgayIEJICAgIAAAkAgAEUNACABIAAoAghPDQAgA7xBAXRB////d0sNACAAKAI4IgVBP0sNACAEIAApAlg3AxggBCAAKQJQNwMQIAQgACkCSDcDCCAEIAApAkA3AwAgAkH/ACACQf8ASRshAgJAIAUgACgCMEcNACAAQTBqEJ2AgIAACyAAIAVBAWo2AjggACgCNCAFQSxsaiIAIAQpAwA3AgAgACAEKQMINwIIIAAgBCkDEDcCECAAIAQpAxg3AhggACADOAIoIAAgAjYCJCAAIAE2AiALIARBIGokgICAgAALJwACQCAADQBBAA8LIAAoAgAgAEEEaigCACgCJBGDgICAAICAgIAACzAAAkAgAEUNACAAKAIAIAAoAgQoAiARhICAgACAgICAACAAQegAakEAQYAI/AsACwulBQEBfwJAIABFDQAgAEEIaiEBAkAgACgCCEEBdEGAgIB4SQ0AIAFBADYCAAsCQCAAKAIMQQF0QYCAgHhJDQAgAEEANgIMCwJAIAAoAhBBAXRBgICAeEkNACAAQQA2AhALAkAgACgCFEEBdEGAgIB4SQ0AIABBADYCFAsCQCAAKAIYQQF0QYCAgHhJDQAgAEEANgIYCwJAIAAoAhxBAXRBgICAeEkNACAAQQA2AhwLAkAgACgCIEEBdEGAgIB4SQ0AIABBADYCIAsCQCAAKAIkQQF0QYCAgHhJDQAgAEEANgIkCwJAIAAoAihBAXRBgICAeEkNACAAQQA2AigLAkAgACgCLEEBdEGAgIB4SQ0AIABBADYCLAsCQCAAKAIwQQF0QYCAgHhJDQAgAEEANgIwCwJAIAAoAjRBAXRBgICAeEkNACAAQQA2AjQLAkAgACgCOEEBdEGAgIB4SQ0AIABBADYCOAsCQCAAKAI8QQF0QYCAgHhJDQAgAEEANgI8CwJAIAAoAkBBAXRBgICAeEkNACAAQQA2AkALAkAgACgCREEBdEGAgIB4SQ0AIABBADYCRAsCQCAAKAJIQQF0QYCAgHhJDQAgAEEANgJICwJAIAAoAkxBAXRBgICAeEkNACAAQQA2AkwLAkAgACgCUEEBdEGAgIB4SQ0AIABBADYCUAsCQCAAKAJUQQF0QYCAgHhJDQAgAEEANgJUCwJAIAAoAlhBAXRBgICAeEkNACAAQQA2AlgLAkAgACgCXEEBdEGAgIB4SQ0AIABBADYCXAsCQCAAKAJgQQF0QYCAgHhJDQAgAEEANgJgCwJAIAAoAmRBAXRBgICAeEkNACAAQQA2AmQLIAAoAgAgASAAKAIEKAIMEYWAgIAAgICAgAAgAEEBOgDoCAsLPgACQCAARQ0AIAFBAksNACACvEEBdEGAgIB4Tw0AIAAoAgAgASACIABBBGooAgAoAhgRhoCAgACAgICAAAsLmAIBBH8CQAJAAkACQAJAIABFDQAgACgCACEBAkAgAEEEaigCACICKAIAIgNFDQAgASADEYSAgIAAgICAgAALAkAgAigCBCICRQ0AIAFBfGooAgAiA0F4cSIEQQRBCCADQQNxIgMbIAJqSQ0CAkAgA0UNACAEIAJBJ2pLDQQLIAEQgYCAgAALIABBfGooAgAiAUF4cSICQfAIQfQIIAFBA3EiARtJDQMCQCABRQ0AIAJBlAlPDQULIAAQgYCAgAALDwtBgLPAgABBLkGws8CAABCCgICAAAALQcCzwIAAQS5B8LPAgAAQgoCAgAAAC0GAs8CAAEEuQbCzwIAAEIKAgIAAAAtBwLPAgABBLkHws8CAABCCgICAAAALmmgKAn8BfAF/AnwBfwR8Bn8GfAJ/AX4jgICAgABB8N0DayICJICAgIAAQQAhAwJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQCABQQRLDQAgALtEAAAAAABw50AgALxBAXRBgICAeEkbRAAAAAAAcOdAIABDAAD6RWAbIQQCQAJAAkACQAJAAkAgAS0A8JrAgAAOBQABAgMEAAsgAkHw5wFqIAQQkYCAgAAgAkEIakEAQcUA/AsAIAJBCGpByABqQQBBxQD8CwAgAkGYAWpBAEHFAPwLACACQeABakEAQcUA/AsAIAJBqAJqQQBBxQD8CwAgAkHwAmpBAEHFAPwLACACQbgDakEAQcUA/AsAIAJBgARqQQBBxQD8CwAgAkHIBGpBAEHFAPwLACACQZAFakEAQcUA/AsAIAJB2AVqQQBBxQD8CwAgAkGgBmpBAEHFAPwLACACQegGakEAQcUA/AsAIAJBsAdqQQBBxQD8CwAgAkH4B2pBAEHFAPwLACACQcAIakEAQcUA/AsAIAJBiAlqQQBBxQD8CwAgAkHQCWpBAEHFAPwLACACQZgKakEAQcUA/AsAIAJB4ApqQQBBxQD8CwAgAkGoC2pBAEHFAPwLACACQfALakEAQcUA/AsAIAJBuAxqQQBBxQD8CwAgAkGADWpBAEHFAPwLACACQaj5AWogAkEIakHADfwKAABB4CYQkoCAgAAiAUUNBiABIAJB8OcBakH4HvwKAAAgAUHOrQE2AoAfIAEgBDkD+B4gAUGIH2pBAEHgAPwLACABQgA3A/AfIAFCgICAgICAgPg/NwPoHyABQgA3A/gfIAFCADcDgCAgAUIANwOIICABQgA3A5AgIAFCADcDmCAgAUIANwOgICABQgA3A6ggIAFCADcDuCAgAUKAgICAgICA+D83A7AgIAFCADcDwCAgAUIANwPIICABQgA3A9AgIAFCADcD2CAgAUIANwPgICABQgA3A+ggIAFCADcD8CAgAUIANwOAISABQoCAgICAgID4PzcD+CAgAUIANwOIISABQgA3A5AhIAFCADcDmCEgAUIANwOgISABQgA3A6ghIAFCADcDsCEgAUIANwO4ISABQgA3A8ghIAFCgICAgICAgPg/NwPAISABQgA3A9AhIAFCADcD2CEgAUIANwPgISABQgA3A+ghIAFCADcD8CEgAUIANwP4ISABQgA3A4AiIAFCgICAgICAgPg/NwOIIiABQgA3A8giIAFCADcDwCIgAUIANwO4IiABQgA3A7AiIAFCADcDqCIgAUIANwOgIiABQgA3A5giIAFCADcDkCIgAUKAgICAgICA+D83A9AiIAFCADcDkCMgAUIANwOIIyABQgA3A4AjIAFCADcD+CIgAUIANwPwIiABQgA3A+giIAFCADcD4CIgAUIANwPYIiABQoCAgICAgID4PzcDmCMgAUIANwPYIyABQgA3A9AjIAFCADcDyCMgAUIANwPAIyABQgA3A7gjIAFCADcDsCMgAUIANwOoIyABQgA3A6AjIAFCgICAgICAgPg/NwPgIyABQgA3A6AkIAFCADcDmCQgAUIANwOQJCABQgA3A4gkIAFCADcDgCQgAUIANwP4IyABQgA3A/AjIAFCADcD6CMgAUKAgICAgICA+D83A6gkIAFCADcD6CQgAUIANwPgJCABQgA3A9gkIAFCADcD0CQgAUIANwPIJCABQgA3A8AkIAFCADcDuCQgAUIANwOwJCABQoCAgICAgID4PzcD8CQgAUIANwOwJSABQgA3A6glIAFCADcDoCUgAUIANwOYJSABQgA3A5AlIAFCADcDiCUgAUIANwOAJSABQgA3A/gkIAFCgICAgICAgPg/NwO4JSABQgA3A/glIAFCADcD8CUgAUIANwPoJSABQgA3A+AlIAFCADcD2CUgAUIANwPQJSABQgA3A8glIAFCADcDwCUgAUKAgICAgICA+D83A4AmIAFBiCZqQQBByAD8CwAgAUGAAjsB2CYgAUKAgICAgICA+D83A9AmQZCUwIAAIQUMBAsgAkHw5wFqIAQQkYCAgAAgAkEIakEAQcUA/AsAIAJB0ABqQQBBxQD8CwAgAkGYAWpBAEHFAPwLACACQeABakEAQcUA/AsAIAJBqAJqQQBBxQD8CwAgAkHwAmpBAEHFAPwLACACQbgDakEAQcUA/AsAIAJBgARqQQBBxQD8CwAgAkHIBGpBAEHFAPwLACACQZAFakEAQcUA/AsAIAJB2AVqQQBBxQD8CwAgAkGgBmpBAEHFAPwLACACQegGakEAQcUA/AsAIAJBsAdqQQBBxQD8CwAgAkH4B2pBAEHFAPwLACACQcAIakEAQcUA/AsAIAJBiAlqQQBBxQD8CwAgAkHQCWpBAEHFAPwLACACQZgKakEAQcUA/AsAIAJB4ApqQQBBxQD8CwAgAkGoC2pBAEHFAPwLACACQfALakEAQcUA/AsAIAJBuAxqQQBBxQD8CwAgAkGADWpBAEHFAPwLACACQaj5AWogAkEIakHADfwKAABB8CIQkoCAgAAiAUUNBiABIAJB8OcBakH4HvwKAAAgAUHOrQE2AoAfIAEgBDkD+B4gAUGIH2pBAEHgAPwLACABQgA3A/AfIAFCgICAgICAgPg/NwPoHyABQgA3A/gfIAFCADcDgCAgAUIANwOIICABQgA3A5AgIAFCADcDmCAgAUIANwOgICABQgA3A6ggIAFCADcDuCAgAUKAgICAgICA+D83A7AgIAFCADcDwCAgAUIANwPIICABQgA3A9AgIAFCADcD2CAgAUIANwPgICABQgA3A+ggIAFCADcD8CAgAUIANwOAISABQoCAgICAgID4PzcD+CAgAUIANwOIISABQgA3A5AhIAFCADcDmCEgAUIANwOgISABQgA3A6ghIAFCADcDsCEgAUIANwO4ISABQgA3A8ghIAFCgICAgICAgPg/NwPAISABQgA3A9AhIAFCADcD2CEgAUIANwPgISABQgA3A+ghIAFCADcD8CEgAUIANwP4ISABQgA3A4AiIAFCgICAgICAgPg/NwOIIiABQZAiakEAQdAA/AsAIAFBgAI7AegiIAFCgICAgICAgPg/NwPgIkG4lMCAACEFDAMLQQAhAyACQcDcAWpBAEHYBfwLACACQYCAgPwDNgKA5QEgAkKAgID8g4CAwD83AvjkASACQoCAgPyDgIDAPzcC8OQBIAJCgICA/IOAgMA/NwLo5AEgAkKAgID8g4CAwD83AuDkASACQoCAgPyDgIDAPzcC2OQBIAJCgICA/IOAgMA/NwLQ5AEgAkKAgID8g4CAwD83AsjkASACQoCAgPyDgIDAPzcCwOQBIAJCgICA/IOAgMA/NwK45AEgAkKAgID8g4CAwD83ArDkASACQoCAgPyDgIDAPzcCqOQBIAJCgICA/IOAgMA/NwKg5AEgAkKAgID8g4CAwD83ApjkASACQoCAgPyDgIDAPzcCkOQBIAJCgICA/IOAgMA/NwKI5AEgAkKAgID8g4CAwD83AoDkASACQoCAgPyDgIDAPzcC+OMBIAJCgICA/IOAgMA/NwLw4wEgAkKAgID8g4CAwD83AujjASACQoCAgPyDgIDAPzcC4OMBIAJCgICA/IOAgMA/NwLY4wEgAkKAgID8g4CAwD83AtDjASACQoCAgPyDgIDAPzcCyOMBIAJCgICA/IOAgMA/NwLA4wEgAkKAgID8g4CAwD83ArjjASACQoCAgPyDgIDAPzcCsOMBIAJCgICA/IOAgMA/NwKo4wEgAkKAgID8g4CAwD83AqDjASACQoCAgPyDgIDAPzcCmOMBIAJCgICA/IOAgMA/NwKQ4wEgAkKAgID8g4CAwD83AojjASACQoCAgPyDgIDAPzcCgOMBIAJCgICA/IOAgMA/NwL44gEgAkKAgID8g4CAwD83AvDiASACQoCAgPyDgIDAPzcC6OIBIAJCgICA/IOAgMA/NwLg4gEgAkKAgID8g4CAwD83AtjiASACQoCAgPyDgIDAPzcC0OIBIAJCgICA/IOAgMA/NwLI4gEgAkKAgID8g4CAwD83AsDiASACQoCAgPyDgIDAPzcCuOIBIAJCgICA/IOAgMA/NwKw4gEgAkKAgID8g4CAwD83AqjiASACQoCAgPyDgIDAPzcCoOIBIAJCgICA/IOAgMA/NwKY4gEgAkGE5QFqQQBB7AL8CwAgBETNzMzMzMzcP6IhBkQAAAAAAAAAACEHIAJBwNwBaiEFQcgAIQhBACEBA0AgBSAHRC2yne+nxuM/oiIJIAmdoSAJpjkDAEQAAAAAAADwPyEJAkAgAUHIAE0NAEQAAAAAAAAkQCAIt0QAAAAAAADQP6JEAAAAAAAANECjELaBgIAAIQkLIAdEAAAAAAAA8D+gIQcgAkGE5QFqIANqQwAAAABDzcxMPkMK16M8IAFBDEkbIAFBU2q3RAAAAAAAAChAoxDFgYCAAEQAAAAAAIB7QKJEAAAAAAAACECiIAZkGzgCACACQZjiAWogA2ogAUEYarhEexSuR+F6AkCiEKeBgIAARJqZmZmZmbk/okQAAAAAAADwP6AgCaK2OAIAIAVBCGohBSADQQRqIQMgCEF/aiEIIAFBAWoiAUHbAEcNAAsgAkGouwNqQQBB4AD8CwBBACEDA0AgAkHw5wFqIANqIgFBADYCACABQRxqQQA6AAAgAUEYakEANgIAIAFBFGpBADoAACABQRBqQQA2AgAgAUEMakEAOgAAIAFBCGpBADYCACABQQRqQQA6AAAgA0EgaiIDQYAIRw0ACyACQfDMA2pBgAhqQQBBgAH8CwAgAkHwzANqIAJB8OcBakGACPwKAAAgAkIANwPIvAMgAkIANwPQvAMgAkIANwPYvAMgAkIANwPgvAMgAkIANwDnvAMgAkIANwPwvAMgAkIANwP4vAMgAkIANwOAvQMgAkIANwOIvQMgAkIANwCPvQMgAkIANwOYvQMgAkIANwOgvQMgAkIANwOovQMgAkIANwOwvQMgAkIANwC3vQMgAkIANwPAvQMgAkIANwPIvQMgAkIANwPQvQMgAkIANwPYvQMgAkIANwDfvQMgAkIANwCHvgMgAkIANwOAvgMgAkIANwP4vQMgAkIANwPwvQMgAkIANwPovQMgAkIANwCvvgMgAkIANwOovgMgAkIANwOgvgMgAkIANwOYvgMgAkIANwOQvgMgAkIANwDXvgMgAkIANwPQvgMgAkIANwPIvgMgAkIANwPAvgMgAkIANwO4vgMgAkIANwD/vgMgAkIANwP4vgMgAkIANwPwvgMgAkIANwPovgMgAkIANwPgvgMgAkIANwCnvwMgAkIANwOgvwMgAkIANwOYvwMgAkIANwOQvwMgAkIANwOIvwNBgPN+IQMDQCACQQhqIANqIgFBiI0BakEANgIAIAFBgI0BakIANwMAIAFBjI0BaiACQci8A2pB6AL8CgAAIAFBgJABakEANgIAIAFB+I8BakIANwMAIAFB9o8BakEAOgAAIAFB9I8BakEAOwEAIAFBhJABaiACQci8A2pB6AL8CgAAIAFB7pIBakEAOgAAIAFB7JIBakEAOwEAIANB8AVqIgMNAAtBACEDA0AgAkHA0wFqIANqIgFBADYCACABQThqQQA2AgAgAUEwakEANgIAIAFBKGpBADYCACABQSBqQQA2AgAgAUEYakEANgIAIAFBEGpBADYCACABQQhqQQA2AgAgA0HAAGoiA0GACEcNAAtBhIABEJKAgIAAIgVFDQZEAAAAAAAAAAAhB0EBIQMgBSEBA0AgASAHRBgtRFT7IRlAokQAAAAAAAAwP6IQp4GAgAC2OAIAIAFBBGogA7hEGC1EVPshGUCiRAAAAAAAADA/ohCngYCAALY4AgAgAUEIaiEBIAdEAAAAAAAAAECgIQcgA0ECaiIDQYEgRw0ACyAFQbLitKx6NgKAgAEgAkHw1QNqQQBB2AX8CwBBgOwCEJKAgIAAIghFDQcCQCAIQXxqLQAAQQNxRQ0AIAhBAEGA7AL8CwALIAJBsL8DakEAQcUA/AsAIAJB+L8DakEAQcUA/AsAIAJBwMADakEAQcUA/AsAIAJBiMEDakEAQcUA/AsAIAJB0MEDakEAQcUA/AsAIAJBmMIDakEAQcUA/AsAIAJB4MIDakEAQcUA/AsAIAJBqMMDakEAQcUA/AsAIAJB8MMDakEAQcUA/AsAIAJBuMQDakEAQcUA/AsAIAJBgMUDakEAQcUA/AsAIAJByMUDakEAQcUA/AsAIAJBkMYDakEAQcUA/AsAIAJB2MYDakEAQcUA/AsAIAJBoMcDakEAQcUA/AsAIAJB6McDakEAQcUA/AsAIAJBsMgDakEAQcUA/AsAIAJB+MgDakEAQcUA/AsAIAJBwMkDakEAQcUA/AsAIAJBiMoDakEAQcUA/AsAIAJB0MoDakEAQcUA/AsAIAJBmMsDakEAQcUA/AsAIAJB4MsDakEAQcUA/AsAIAJBqMwDakEAQcUA/AsARAmUSnAvi+jAIASjELKBgIAAIQogBkQAAAAAAAAUQGZFDQggBkQAAAAAAIjDQCAGRAAAAAAAiMNAYxtEGC1EVPshGUCiIASjIgcQp4GAgAAhCyAHEKmBgIAAIQkgBkQAAAAAAAA5QCAGRAAAAAAAADlAYxtEGC1EVPshGUCiIASjIgcQp4GAgAAhDCAHEKmBgIAAIQdBAEF/IAREexSuR+F6lD+i/AMiAUF/amd2IAFBAkkbIg1BAWoiDkH/////A0sNCSAOQQJ0IgFB/f///wdPDQkCQAJAIAENAEEAIQ9BBCEQQQQhEQwBCyABEJKAgIAAIhBFDQsCQCAQQXxqLQAAQQNxRQ0AIAFFDQAgEEEAIAH8CwALIAEQkoCAgAAiEUUNFAJAIBFBfGotAABBA3FFDQAgAUUNACARQQAgAfwLAAsgDiEPC0GEgAEQkoCAgAAiEkUNC0QAAAAAAADwPyAERPFo44i1+AQ/oiIToSATRAAAAAAAAPA/oKMhE0QAAAAAAADwPyAKoSEURAAAAAAAAPA/IAtEMzMzMzMz8z+jIgqhIApEAAAAAAAA8D+gIgqjIQsgCUQAAAAAAAAAwKIgCqMhFUQAAAAAAADwPyAJoSIJIAqjIRYgCUQAAAAAAADgP6IgCqMhCkQAAAAAAADwPyAMRDMzMzMzM/M/oyIJoSAJRAAAAAAAAPA/oCIJoyEMIAdEAAAAAAAAAMCiIAmjIRcgB0QAAAAAAADwP6AiB5ogCaMhGCAHRAAAAAAAAOA/oiAJoyEJRAAAAAAAAAAAIQdBASEDIBIhAQNAIAEgB0QYLURU+yEZQKJEAAAAAAAAMD+iEKeBgIAAtjgCACABQQRqIAO4RBgtRFT7IRlAokQAAAAAAAAwP6IQp4GAgAC2OAIAIAFBCGohASAHRAAAAAAAAABAoCEHIANBAmoiA0GBIEcNAAsgEkGy4rSsejYCgIABIAJCADcD2PABIAJCADcD4PABIAJCADcD6PABIAJCADcD8PABIAJCADcDoPEBIAJCADcDqPEBIAJCADcDsPEBIAJCADcDuPEBIAJCADcD6PEBIAJCADcD8PEBIAJCADcD+PEBIAJCADcDgPIBIAJCADcDsPIBIAJCADcDuPIBIAJCADcDwPIBIAJCADcDyPIBIAJCADcDkPMBIAJCADcDiPMBIAJCADcDgPMBIAJCADcD+PIBIAJCADcD2PMBIAJCADcD0PMBIAJCADcDyPMBIAJCADcDwPMBIAJCADcDoPQBIAJCADcDqPQBIAJCADcDsPQBIAJCADcDuPQBIAJCADcD8O8BIAJCADcD+O8BIAJCADcDgPABIAJCADcDiPABIAJCADcDqLwDIAJCADcDsLwDIAJCADcDuLwDIAJCADcDwLwDIAJCADcDiLwDIAJCADcDkLwDIAJCADcDmLwDIAJCADcDoLwDIAIgBDkD+I8DIAJBgJADaiACQai7A2pB4AD8CgAAIAJBADsBxLoDIAJB4JADaiACQfDMA2pBgAn8CgAAIAJBADYC4JkDIAJBACkC0I3AgAA3AuSZAyACQQAoAtiNwIAANgLsmQMgAkH4ggJqIAJBCGpBgI0B/AoAACACQfDnAWogAkHA0wFqQYAI/AoAACACQYEgNgKQrAMgAiAFNgKMrAMgAkGBIDYCiKwDIAJCADcD8JkDIAJB+JkDaiACQcDcAWpB2AX8CgAAIAJB0J8DaiIDIAJB8NUDakHYBfwKAAAgAkGgrANqIAJBmOIBakHsAvwKAAAgAkGMrwNqIAJBhOUBakHsAvwKAAAgAkGA2wA2ApysAyACIAg2ApisAyACQYDbADYClKwDIAJBgICA/gc2AvixAyACQca6A2pBAEHbAPwLACACQfyxA2pBAEHECPwLACACQYuetPcFNgLAugMgAkKAgICAgICA+D83A6ilAyACQaj1AWogAkGwvwNqQcAN/AoAACACQc6tATYC8IICIAIgBDkD6IICIAJBsKUDakEAQaAC/AsAIAIgEzkD0KcDIAJB2KcDakEAQaAB/AsAIAJCADcDkKkDIAJCgICAgICAgPg/NwOIqQMgAkIANwOAqQMgAiAUOQP4qAMgAkIANwOYqQMgAkIANwOgqQMgAkIANwOoqQMgAkIANwOwqQMgAkIANwO4qQMgAkIANwPAqQMgAkIANwPIqQMgAiAMOQOIqgMgAiAXOQOAqgMgAiAJOQP4qQMgAiAYOQPwqQMgAiAJOQPoqQMgAkIANwPgqQMgAkKAgICAgICA+D83A9ipAyACQoCAgICAgID4v383A9CpAyACQgA3A6iqAyACQgA3A6CqAyACQgA3A5iqAyACQgA3A5CqAyACIAo5A7CqAyACIBY5A7iqAyACIAo5A8CqAyACIBU5A8iqAyACIAs5A9CqAyACQgA3A9iqAyACQgA3A+CqAyACQgA3A+iqAyACQgA3A/CqAyACRAAAAAAAAPA/RAAAAAAAAPC/IAREZmZmZmZm1j+ioxCygYCAAKE5A5DwASACRAAAAAAAAPA/RAAAAAAAAPC/IAREmpmZmZmZ4T+ioxCygYCAAKE5A5jwASACRAAAAAAAAPA/RAAAAAAAAPC/IAREzczMzMzM/D+ioxCygYCAAKE5A6DwASACRAAAAAAAAPA/RAAAAAAAAPC/IAREzczMzMzMBECioxCygYCAAKE5A6jwASAGRAAAAAAAAIlAIAZEAAAAAAAAiUBjG0QYLURU+yEZQKIgBKMiBxCngYCAACEJIAJEAAAAAAAA8D8gBxCpgYCAACIMoSIKRAAAAAAAAOA/oiAJRM07f2aeoPY/oyILRAAAAAAAAPA/oCIHoyIJOQOw8AEgAiAKIAejIhM5A7jwASACIAk5A8DwASACIAxEAAAAAAAAAMCiIAejIgo5A8jwASACRAAAAAAAAPA/IAuhIAejIgs5A9DwASACIAk5A/jwASACIBM5A4DxASACIAk5A4jxASACIAo5A5DxASACIAs5A5jxASACIAxEAAAAAAAA8D+gIgxEAAAAAAAA4D+iIAejIgk5A8DxASACIAyaIAejIgc5A8jxASACIAk5A9DxASACIAo5A9jxASACIAs5A+DxASACIAk5A4jyASACIAc5A5DyASACIAk5A5jyASACIAo5A6DyASACIAs5A6jyASACIAZEAAAAAAAwoUAgBkQAAAAAADChQGMbRBgtRFT7IRlAoiAEoyIJEKeBgIAARDMzMzMzMwNAoyIHRNkKYekaBPM/oiIKRAAAAAAAAPA/oCAHRNkKYekaBPM/oyILRAAAAAAAAPA/oCIHozkD0PIBIAIgCRCpgYCAAEQAAAAAAAAAwKIgB6MiCTkD2PIBIAJEAAAAAAAA8D8gCqEgB6M5A+DyASACIAk5A+jyASACRAAAAAAAAPA/IAuhIAejOQPw8gEgBkQAAAAAAEy9QCAGRAAAAAAATL1AYxtEGC1EVPshGUCiIASjIgcQp4GAgAAhCSACRAAAAAAAAPA/IAcQqYGAgAAiCqEiC0QAAAAAAADgP6IgCURmZmZmZmb2P6MiCUQAAAAAAADwP6AiB6MiDDkDmPMBIAIgCyAHozkDoPMBIAIgDDkDqPMBIAIgCkQAAAAAAAAAwKIgB6M5A7DzASACRAAAAAAAAPA/IAmhIAejOQO48wEgAiAEOQPw8wEgAiAGRAAAAAAAQFVAIAZEAAAAAABAVUBjG0QYLURU+yEZQKIgBKMiCRCngYCAAEQAAAAAAADgP6IiB0Q2xGufyfPxP6IiCkQAAAAAAADwP6AgB0Q2xGufyfPxP6MiC0QAAAAAAADwP6AiB6M5A/jzASACIAkQqYGAgABEAAAAAAAAAMCiIAejIgk5A4D0ASACRAAAAAAAAPA/IAqhIAejOQOI9AEgAiAJOQOQ9AEgAkQAAAAAAADwPyALoSAHozkDmPQBIAJEAAAAAAAA8D9EDDldTPutzsAgBKMQsoGAgAChOQPg9AEgAkQAAAAAAADwP0RnmrUYCqTxwCAEoxCygYCAAKE5A+j0ASACIA02Avj0ASACQQA2Avz0ASACIA82AoD1ASACIBA2AoT1ASACIA42Aoj1ASACIA82Aoz1ASACIBE2ApD1ASACIA42ApT1ASACQYEgNgKY9QEgAiASNgKc9QEgAkGBIDYCoPUBIAZEAAAAAAAANEAgBkQAAAAAAAA0QGMbRBgtRFT7IRlAoiAEoyIHEKeBgIAAIQkgAiAHEKmBgIAAIgZEAAAAAAAA8D+gIgREAAAAAAAA4D+iIAlEMzMzMzMz8z+jIgpEAAAAAAAA8D+gIgejIgk5A/iqAyACIASaIAejIgQ5A4CrAyACIAk5A4irAyACIAZEAAAAAAAAAMCiIAejIgY5A5CrAyACRAAAAAAAAPA/IAqhIAejIgc5A5irAyACQoCAgICAgIDwPzcD8PQBIAJC8fqouL2U3PI/NwPY9AEgAkKPhdfHwuuj9T83A9D0ASACQuXmtcGjqrD4PzcDyPQBIAJCADcDwPQBIAJCgICAgICAgPg/NwPo8wEgAkKAgICAgICA+D83A+DzASACIAk5A8CrAyACIAQ5A8irAyACIAk5A9CrAyACIAY5A9irAyACIAc5A+CrAyACIAIpA8C8AzcDuKsDIAIgAikDuLwDNwOwqwMgAiACKQOwvAM3A6irAyACIAIpA6i8AzcDoKsDIAIgAikDiLwDNwPoqwMgAiACKQOQvAM3A/CrAyACIAIpA5i8AzcD+KsDIAIgAikDoLwDNwOArAMgAkEBOgChuwMCQCACKgL4sQOMi0MK1yM8XQ0AIAJBADYC+LEDQRghASACKwP4jwMhBgNAIAG4IgdEhetRuB6F4z+iEKeBgIAAIQkgB0SuR+F6FK77P6IQp4GAgAAhByADIAFBu39qt0QAAAAAAAAoQKMQxYGAgABEAAAAAACAe0CiIAdEzczMzMzM7D+iIAlEmpmZmZmZ2T+ioEQAAAAAAMCSQKMQxYGAgACiIAajOQMAIANBCGohAyABQQFqIgFB8wBHDQALCyACQQhqIAJB8OcBakG40wH8CgAAQbjTARCSgICAACIBRQ0MIAEgAkEIakG40wH8CgAAQeCUwIAAIQUMAgsgAkEIaiAEEJGAgIAAQYAKEJKAgIAAIgNFDQwgA0EANgIYIANCADcDECADQgA3AwggA0IANwMAIANCADcDICADQgA3AyggA0IANwMwIANBADYCOCADQgA3A0AgA0IANwNIIANCADcDUCADQQA2AlggA0IANwNgIANCADcDaCADQgA3A3AgA0EANgJ4IANBADYCmAEgA0IANwOQASADQgA3A4gBIANCADcDgAEgA0EANgK4ASADQgA3A7ABIANCADcDqAEgA0IANwOgASADQgA3A8ABIANCADcDyAEgA0IANwPQASADQQA2AtgBIANCADcD4AEgA0IANwPoASADQgA3A/ABIANBADYC+AEgA0IANwOAAiADQgA3A4gCIANCADcDkAIgA0EANgKYAiADQQA2ArgCIANCADcDsAIgA0IANwOoAiADQgA3A6ACIANBADYC2AIgA0IANwPQAiADQgA3A8gCIANCADcDwAIgA0EANgL4AiADQgA3A/ACIANCADcD6AIgA0IANwPgAiADQQA2ApgDIANCADcDkAMgA0IANwOIAyADQgA3A4ADIANBADYCuAMgA0IANwOwAyADQgA3A6gDIANCADcDoAMgA0EANgLYAyADQgA3A9ADIANCADcDyAMgA0IANwPAAyADQQA2AvgDIANCADcD8AMgA0IANwPoAyADQgA3A+ADIANBADYCmAQgA0IANwOQBCADQgA3A4gEIANCADcDgAQgA0EANgK4BCADQgA3A7AEIANCADcDqAQgA0IANwOgBCADQQA2AtgEIANCADcD0AQgA0IANwPIBCADQgA3A8AEIANBADYC+AQgA0IANwPwBCADQgA3A+gEIANCADcD4AQgA0EANgKYBSADQgA3A5AFIANCADcDiAUgA0IANwOABSADQQA2ArgFIANCADcDsAUgA0IANwOoBSADQgA3A6AFIANBADYC2AUgA0IANwPQBSADQgA3A8gFIANCADcDwAUgA0EANgL4BSADQgA3A/AFIANCADcD6AUgA0IANwPgBSADQQA2ApgGIANCADcDkAYgA0IANwOIBiADQgA3A4AGIANBADYCuAYgA0IANwOwBiADQgA3A6gGIANCADcDoAYgA0EANgLYBiADQgA3A9AGIANCADcDyAYgA0IANwPABiADQQA2AvgGIANCADcD8AYgA0IANwPoBiADQgA3A+AGIANBADYCmAcgA0IANwOQByADQgA3A4gHIANCADcDgAcgA0EANgK4ByADQgA3A7AHIANCADcDqAcgA0IANwOgByADQQA2AtgHIANCADcD0AcgA0IANwPIByADQgA3A8AHIANBADYC+AcgA0IANwPwByADQgA3A+gHIANCADcD4AcgA0EANgKYCCADQgA3A5AIIANCADcDiAggA0IANwOACCADQQA2ArgIIANCADcDsAggA0IANwOoCCADQgA3A6AIIANBADYC2AggA0IANwPQCCADQgA3A8gIIANCADcDwAggA0EANgL4CCADQgA3A/AIIANCADcD6AggA0IANwPgCCADQQA2ApgJIANCADcDkAkgA0IANwOICSADQgA3A4AJIANBADYCuAkgA0IANwOwCSADQgA3A6gJIANCADcDoAkgA0EANgLYCSADQgA3A9AJIANCADcDyAkgA0IANwPACSADQQA2AvgJIANCADcD8AkgA0IANwPoCSADQgA3A+AJIAJBsL8DakEAQcUA/AsAIAJBsL8DakHIAGpBAEHFAPwLACACQcDAA2pBAEHFAPwLACACQYjBA2pBAEHFAPwLACACQdDBA2pBAEHFAPwLACACQZjCA2pBAEHFAPwLACACQeDCA2pBAEHFAPwLACACQajDA2pBAEHFAPwLACACQfDDA2pBAEHFAPwLACACQbjEA2pBAEHFAPwLACACQYDFA2pBAEHFAPwLACACQcjFA2pBAEHFAPwLACACQZDGA2pBAEHFAPwLACACQdjGA2pBAEHFAPwLACACQaDHA2pBAEHFAPwLACACQejHA2pBAEHFAPwLACACQbDIA2pBAEHFAPwLACACQfjIA2pBAEHFAPwLACACQcDJA2pBAEHFAPwLACACQYjKA2pBAEHFAPwLACACQdDKA2pBAEHFAPwLACACQZjLA2pBAEHFAPwLACACQeDLA2pBAEHFAPwLACACQajMA2pBAEHFAPwLACACQfDnAWogAkEIakG4EfwKAAAgAkHw5wFqQbgRaiACQbC/A2pBwA38CgAAQfAiEJKAgIAAIgFFDQ0gASACQfDnAWpB+B78CgAAIAFBzq0BNgKAHyABIAQ5A/geIAFBiB9qQQBB4AD8CwAgAUIANwPwHyABQoCAgICAgID4PzcD6B8gAUIANwP4HyABQgA3A4AgIAFCADcDiCAgAUIANwOQICABQgA3A5ggIAFCADcDoCAgAUIANwOoICABQgA3A7ggIAFCgICAgICAgPg/NwOwICABQgA3A8AgIAFCADcDyCAgAUIANwPQICABQgA3A9ggIAFCADcD4CAgAUIANwPoICABQgA3A/AgIAFCADcDgCEgAUKAgICAgICA+D83A/ggIAFCADcDiCEgAUIANwOQISABQgA3A5ghIAFCADcDoCEgAUIANwOoISABQgA3A7AhIAFCADcDuCEgAUKAgICAgICA+D83A8AhIAFCADcDyCEgAUIANwPQISABQgA3A9ghIAFCADcD4CEgAUIANwPoISABQgA3A/AhIAFCADcD+CEgAUIANwOAIiABQoCAgICAgID4PzcDiCIgAUGQImpBAEHIAPwLACABQQE6AO4iIAFBADsB7CIgAUEoNgLoIiABIAM2AuQiIAFBKDYC4CIgAUKAgICAgICA+D83A9giQYiVwIAAIQUMAQtBACEDA0AgAkHw5wFqIANqIgFBADYCACABQRxqQQA6AAAgAUEYakEANgIAIAFBFGpBADoAACABQRBqQQA2AgAgAUEMakEAOgAAIAFBCGpBADYCACABQQRqQQA6AAAgA0EgaiIDQYAIRw0ACyACQfDMA2pBgAhqQQBBgAH8CwAgAkHwzANqIAJB8OcBakGACPwKAABBgCoQkoCAgAAiGUUNDUEBQX8gBEQAAAAAAAA5QKP8AyIBQQdqZ3ZBAWogAUF+cUF4RhsiEEH/////A0sNByAQQQJ0Ig1B/f///wdPDQcgBET8qfHSTWJwP6L8A0EBaiIRQQJ0IRJBACEBIBFB/////wNLDRIgEkH8////B0sNEiAQQX9qIRpBgFYhCANAQQQhBUEAIQ5BBCEDAkAgDUUNACANEJKAgIAAIgNFDRACQCADQXxqLQAAQQNxRQ0AIA1FDQAgA0EAIA38CwALIBAhDgsCQAJAIBINAEEAIQ8MAQsCQCASEJKAgIAAIgUNAEEEIQEMFQsCQCAFQXxqLQAAQQNxRQ0AIBJFDQAgBUEAIBL8CwALIBEhDwsgGSAIaiIBQaAqakKAgICAgICA+D83AwAgAUGYKmpCgICAgICAgPg/NwMAIAFBkCpqQpqz5syZs+bkPzcDACABQYgqakKas+bMmbPm3D83AwAgAUGAKmpCADcDACABQagqakEAQcgA/AsAIAFBjCtqQgA3AgAgAUGEK2pCgICAgBA3AgAgAUGAK2ogGjYCACABQfgqakKAgICAgIDArMAANwMAIAFB8CpqQoCAgICAgOC9wAA3AwAgAUGUK2pCADcCACABQZwrakIANwIAIAFBpCtqQgA3AgAgAUHeK2pBADoAACABQdwrakEAOwEAIAFB2CtqIBE2AgAgAUHUK2ogBTYCACABQdAraiAPNgIAIAFByCtqQgA3AwAgAUHAK2pCgICA/AM3AwAgAUG4K2pCADcDACABQbQraiAQNgIAIAFBsCtqIAM2AgAgAUGsK2ogDjYCACAIQeABaiIIDQALQQAhAwNAIAJB8NUDaiADaiIBQQA2AgAgAUE4akEANgIAIAFBMGpBADYCACABQShqQQA2AgAgAUEgakEANgIAIAFBGGpBADYCACABQRBqQQA2AgAgAUEIakEANgIAIANBwABqIgNBgAhHDQALQQAhAwNAIAJBsL8DaiADaiIBQQA2AgAgAUHUAGpBADYCACABQcgAakEANgIAIAFBPGpBADYCACABQTBqQQA2AgAgAUEkakEANgIAIAFBGGpBADYCACABQQxqQQA2AgAgA0HgAGoiA0GADEcNAAsgAkEIakEAQcUA/AsAIAJB0ABqQQBBxQD8CwAgAkGYAWpBAEHFAPwLACACQeABakEAQcUA/AsAIAJBqAJqQQBBxQD8CwAgAkHwAmpBAEHFAPwLACACQbgDakEAQcUA/AsAIAJBgARqQQBBxQD8CwAgAkHIBGpBAEHFAPwLACACQZAFakEAQcUA/AsAIAJB2AVqQQBBxQD8CwAgAkGgBmpBAEHFAPwLACACQegGakEAQcUA/AsAIAJBsAdqQQBBxQD8CwAgAkH4B2pBAEHFAPwLACACQcAIakEAQcUA/AsAIAJBCGpBgAlqQQBBxQD8CwAgAkHQCWpBAEHFAPwLACACQZgKakEAQcUA/AsAIAJB4ApqQQBBxQD8CwAgAkGoC2pBAEHFAPwLACACQfALakEAQcUA/AsAIAJBuAxqQQBBxQD8CwAgAkGADWpBAEHFAPwLACACQcDTAWogAkHwzANqQYAJ/AoAACACQfDnAWogAkHw1QNqQYAI/AoAACACQfDnAWpBgAhqIAJBsL8DakGADPwKAAAgAkHw+wFqIAJBCGpBwA38CgAAQeguEJKAgIAAIgFFDQ8gASACQfDnAWpBwCH8CgAAIAEgBDkD0CEgAUHOrQE2AsghIAEgBDkDwCEgAUHYIWogAkHA0wFqQYAJ/AoAACABQQA2AtgqIAFBACkC0I3AgAA3AtwqIAFBACgC2I3AgAA2AuQqIAFB6CpqQQBB6AD8CwAgAUIANwPgKyABQoCAgICAgID4PzcD2CsgAUKAgICAgICA+D83A9ArIAFCADcD6CsgAUIANwPwKyABQgA3A/grIAFCADcDgCwgAUIANwOILCABQgA3A5AsIAFCADcDmCwgAUIANwOoLCABQoCAgICAgID4PzcDoCwgAUIANwOwLCABQgA3A7gsIAFCADcDwCwgAUIANwPILCABQgA3A9AsIAFCADcD2CwgAUIANwPgLCABQgA3A/AsIAFCgICAgICAgPg/NwPoLCABQgA3A/gsIAFCADcDgC0gAUIANwOILSABQgA3A5AtIAFCADcDmC0gAUIANwOgLSABQgA3A6gtIAFCADcDuC0gAUKAgICAgICA+D83A7AtIAFCADcDwC0gAUIANwPILSABQgA3A9AtIAFCADcD2C0gAUIANwPgLSABQgA3A+gtIAFCADcD8C0gAUKAgICAgICA+D83A/gtIAFCADcDuC4gAUIANwOwLiABQgA3A6guIAFCADcDoC4gAUIANwOYLiABQgA3A5AuIAFCADcDiC4gAUIANwOALiABQYACOwHgLiABQhg3A9guIAEgGTYC1C4gAUEYNgLQLiABQoCAgICAgID4PzcDyC4gAUKAgICAgICA+D83A8AuQbCVwIAAIQULQewIEJKAgIAAIgNFDQ8gAyAFNgIEIAMgATYCACADQQhqQQBB4Qj8CwALIAJB8N0DaiSAgICAACADDwtBCEHgJhCagICAAAALQQhB8CIQmoCAgAAAC0EEQYSAARCTgICAAAALQQRBgOwCEJOAgIAAAAsgAkKAgICAgICAisAANwOIvAMgAiAGOQOovAMgAkGCgICAAK1CIIYiGyACQai8A2qthDcD+OcBIAIgGyACQYi8A2qthDcD8OcBQe2BwIAAIAJB8OcBakHoisCAABCJgICAAAALEJSAgIAAAAtBBCABEJOAgIAAAAtBBEGEgAEQk4CAgAAAC0EIQbjTARCagICAAAALQQhBgAoQk4CAgAAAC0EIQfAiEJqAgIAAAAtBCEGAKhCTgICAAAALQQQgDRCTgICAAAALQQhB6C4QmoCAgAAAC0EEQewIEJqAgIAAAAtBBCABEJOAgIAAAAsgASASEJOAgIAAAAspAAJAIABFDQAgACgCAEEBIAEgAEEEaigCACgCFBGHgICAAICAgIAACwtkAAJAIABFDQAgArxBAXRB////d0sNACABvEEBdEGAgIB4Tw0AIAAtAOgIQQFxRQ0AIAAoAgAgASACIAMgBEMAAAAAIAS8QQF0QYCAgHhJGyAAKAIEKAIQEYiAgIAAgICAgAALCyAAAkAgAA0AQQAPCwJAIAENACAAQegAag8LIABB6ARqCwwAIABBCGpBACAAGwugAgMDfwF9An8CQCAARQ0AIAAoAgAgAEHoAGoiBCABQYABIAFBgAFJGyIFIABB6ARqIgYgBUMAAJZFQwAAlsUgAiACQwAAlsVdGyIHIAdDAACWRV4bQwAAAAAgArxBAXRBgICAeEkbIANDAAAAACADvEEBdEGAgIB4SRsgACgCBCgCHBGJgICAAICAgIAAIAVBAnQhCEEAIQECQANAAkAgCCABRw0AIAVBAnQhAQNAIAFFDQQgAUF8aiEBIAYoAgAhCSAGQQRqIQYgCUEBdEGAgIB4SQ0ADAMLCyAAIAFqIQkgAUEEaiEBIAlB6ABqKAIAQQF0Qf///3dNDQALCyAEQQBBgAj8CwAgACgCACAAKAIEKAIgEYSAgIAAgICAgAALCykAAkAgAEUNACAAKAIAQQAgACAAQQRqKAIAKAIUEYeAgIAAgICAgAALCw0AIABBgARqQQAgABsLcwECfwJAAkACQCAARQ0AIABBfGooAgAiAUF4cUGkD0GoDyABQQNxIgIbSQ0BAkAgAkUNACABQcgPTw0DCyAAEIGAgIAACw8LQYCzwIAAQS5BsLPAgAAQgoCAgAAAC0HAs8CAAEEuQfCzwIAAEIKAgIAAAAsEACAAC/kEAwJ/A30BfiOAgICAAEHAD2siASSAgICAAAJAAkAgAEMAgDtHIAAgALwiAkEASBtDAIA7RyACQf////8HcUGAgIB8akGAgID4B0kbIAJBf2pB////A0kbIgNDZmbmPpQiAEMAAKBBYEUNACAAQwAAekQgAEMAAHpEXRtD2w9JQJQgAyADkiIElRDDgYCAACEFIAFCADcC8A4gAUIANwLoDiABQQA2ArANIAFBCGpBAEGADPwLACABQwAAgD9DAACAvyADQwrXIzyUlRCjgYCAAJMiAzgC2A0gAULNmbPy05mzpj43AtANIAEgAzgCzA0gAUIANwLEDSABIAM4AsANIAFC1Zj0htSKw+7AADcCuA0gASAAOAK0DSABQdwNakEAQYQB/AsAIAFBCGpBgAxqQQBBqAH8CwAgAUEAOgCkDyABQYCAgPwDNgKgDyABQoCAgPyDgIDAPzcCmA8gAUKAgICAgICAwD83AowPIAEgADgC5A4gASAEOALgDiABQwAAgD8gBUMAAIA/kpUiADgCiA8gASAFIACUIgA4AvgOIAEgACAAlCIDOAL8DiABIAAgA5Q4AoAPIAEgAyADlCIAOAKEDyABQwAAgD8gAEMAAAAAlEMAAIA/kpU4ApQPIAFBCGoQh4CAgABBoA8QkoCAgAAiAkUNASACIAFBCGpBoA/8CgAAIAFBwA9qJICAgIAAIAIPCyABQYCAgI0ENgKoDyABIAA4AqwPIAFBgYCAgACtQiCGIgYgAUGsD2qthDcDuA8gASAGIAFBqA9qrYQ3A7APQe2BwIAAIAFBsA9qQdiKwIAAEImAgIAAAAtBBEGgDxCagICAAAALDQAgAEGACGpBACAAGwv6FgUHfwR9AX4Bfw99I4CAgIAAQbABayICJICAgIAAAkAgAEUNACABQYABIAFBgAFJGyEDAkAgAUUNACAAQaAMaiEEIABBgAxqIQUgAEHUDWohBiADIQcgACEIAkACQAJAAkACQAJAA0AgCEGABGoqAgAiCUMAAAAAIAm8QQF0QYCAgHhJGyEKAkACQAJAIAAqArANIgkgACoCtA0iC1wNACAKIAAqAqgNXA0BDAILAkAgCSALIAmTIAAqArgNlJIiDCAJXA0AIAAgCyIJOAKwDQwBCyAMIQkCQCALIAyTi0O9N4Y1XQ0AIAAgCTgCsA0MAQsgACALIgk4ArANCyAAIAo4AqgNAkAgACoC3A4iC0MAAKBBYEUNACAAQwAAgD8gC0MAAKBBIApDmmsXOpQgCZIQo4GAgAAiCSAJQwAAoEFdGyIJIAkgC14bQ9sPSUCUIAAqAtgOlRDDgYCAACIJQwAAgD+SlSIKOAKADyAAIAkgCpQiCTgC8A4gACAJIAmUIgo4AvQOIAAgCiAKlCILOAL8DiAAIAkgCpQ4AvgOIABDAACAPyALIAAqAoQPlEMAAIA/kpU4AowPDAELIAJBgICAjQQ2AqgBIAIgCzgCrAEgAkGBgICAAK1CIIYiDSACQawBaq2ENwMQIAIgDSACQagBaq2ENwMIQe2BwIAAIAJBCGpB2IrAgAAQiYCAgAAACwJAIAAqArwNIgogACoCwA0iC1sNAAJAAkAgCiALIAqTIAAqAsQNlJIiCSAKXA0AIAshCQwBCyALIAmTi0O9N4Y1XUUNACALIQkLIAAgCTgCvA0gAEMAAIA/QwAAAAAgCSAJQwAAAABdGyIJIAlDAACAP14bQwAAgECUIgk4AoQPIAAgCUMAAAA/lEMAAIA/kkMAAIA/IAAtAJwPQQJJGzgCiA8gAEMAAIA/IAkgACoC/A6UQwAAgD+SlTgCjA8LAkAgACoCyA0iCiAAKgLMDSILWw0AAkACQCAKIAsgCpMgACoC0A2UkiIJIApcDQAgCyEJDAELIAsgCZOLQ703hjVdRQ0AIAshCQsgACAJOALIDSAAQwAAgD9DAAAAACAJIAlDAAAAAF0bIgkgCUMAAIA/XhtDAABAQJQQwYGAgAAiCTgCkA8gAEMAAIA/IAmVOAKUDyAAIAmRizgCmA8LIAgqAgAhCSAAIAAoAtQOIg5Bf2pBDyAOGyIONgLUDgJAIA5BH0sNACAGIA5BAnRqQwAAAAAgCSAJi0MI5TweXRsiCTgCACAAKALUDkEQaiIOQSBPDQIgBiAOQQJ0aiAJOAIAIAAoAtQOIg5BEU8NA0MAAAAAIAAqAvAOIgkgACoClA8iD0MAAIA/QwAAgL9DAACgQEMAAKDAIAAqApAPIhAgACoCjA8iESAAKgKIDyISIAYgDkECdGoiDioCACAOKgI8kkPZ8KW4lEMAAAAAkiAOKgIEIA4qAjiSQwO0WDqUkiAOKgIIIA4qAjSSQ1d2UruUkiAOKgIMIA4qAjCSQ8ZFETyUkiAOKgIQIA4qAiySQ87npryUkiAOKgIUIA4qAiiSQz0TLz2UkiAOKgIYIA4qAiSSQ1i4vL2UkiAOKgIcIhMgDioCIJJD73KgPpSSIgogCpKUIAAqAoQPIhQgACoCgA8iFSAAKgLsDiIWIAAqAvgOIhcgACoC4A4iC5QgACoC9A4iGCAAKgLkDiIMlJIgCSAAKgLoDiIZlJKSlJSTlJQiCiAKQwAAoMBdGyIKIApDAACgQF4bIgogCiAKlCIKIAogCkMAAL1DkpRDAFqHRpKUQ8D3A0iSlCAKIAogCkMAAOBBlEMA4ERFkpRDAKJzR5KUQ8D3A0iSlSIKIApDAACAv10bIgogCkMAAIA/XhuUIhogC5OUIgogCyAKkiIbkiIKIAqLQwjlPB5dGyELQwAAAAAgCSAbIAyTlCIKIAwgCpIiCpIiDCAMi0MI5TweXRshDEMAAAAAIAkgCiAZk5QiHCAZIBySIh2SIhkgGYtDCOU8Hl0bIRlDAAAAACAJIB0gFpOUIhwgFiAckiIckiIWIBaLQwjlPB5dGyEWAkACQAJAAkAgAC0AnA8iDg4EAwABAgMLIAohHAwCCyAKIB0gHZKTIBySQwAAgECUIRwMAQsgGiAbQwAAgECUkyAKQwAAwECUkiAdQwAAgECUkyAckiEcC0MAAAAAIAkgD0MAAIA/QwAAgL9DAACgQEMAAKDAIBAgESATIBKUIBQgFSAXIAuUIBggDJSSIAkgGZSSIBaSlJSTlJQiCiAKQwAAoMBdGyIKIApDAACgQF4bIgogCiAKlCIKIAogCkMAAL1DkpRDAFqHRpKUQ8D3A0iSlCAKIAogCkMAAOBBlEMA4ERFkpRDAKJzR5KUQ8D3A0iSlSIKIApDAACAv10bIgogCkMAAIA/XhuUIg8gC5OUIgogCyAKkiIdkiIKIAqLQwjlPB5dGyEbQwAAAAAgCSAdIAyTlCIKIAwgCpIiCpIiCyALi0MI5TweXRshDEMAAAAAIAkgCiAZk5QiCyAZIAuSIguSIhkgGYtDCOU8Hl0bIRlDAAAAACAJIAsgFpOUIgkgFiAJkiIJkiIWIBaLQwjlPB5dGyEWAkACQAJAAkAgDg4EAwIBAAMLIA8gHUMAAIBAlJMgCkMAAMBAlJIgC0MAAIBAlJMgCZIhCQwCCyAKIAsgC5KTIAmSQwAAgECUIQkMAQsgCiEJCyAAKgKYDyEKIAAgFjgC7A4gACAZOALoDiAAIAw4AuQOIAAgGzgC4A4gACAAKAKgDSIOQX9qQQ8gDhsiDjYCoA0gDkEfSw0EIAQgDkECdGogCiAclCILOAIAIAAoAqANQRBqIg5BIE8NBSAEIA5BAnRqIAs4AgAgACgCpA0iDkEHSw0GIAUgDkECdGoiDioCACELIA4gCiAJlDgCACAAIAAoAqQNQQFqQQdxNgKkDSAAKAKgDSIOQRFPDQcgCEGACGogC0MAAAA/lCAEIA5BAnRqIg4qAgAgDioCPJJD2fCluJRDAAAAAJIgDioCBCAOKgI4kkMDtFg6lJIgDioCCCAOKgI0kkNXdlK7lJIgDioCDCAOKgIwkkPGRRE8lJIgDioCECAOKgIskkPO56a8lJIgDioCFCAOKgIokkM9Ey89lJIgDioCGCAOKgIkkkNYuLy9lJIgDioCHCAOKgIgkkPvcqA+lJKSOAIAIAhBBGohCCAHQX9qIgcNAQwICwsgDkEgQfiKwIAAEI6AgIAAAAsgDkEgQYiLwIAAEI6AgIAAAAsgDiAOQRBqQSBBwI3AgAAQloCAgAAACyAOQSBB+IrAgAAQjoCAgAAACyAOQSBBiIvAgAAQjoCAgAAACyAOQQhB8JHAgAAQjoCAgAAACyAOIA5BEGpBIEHAjcCAABCWgICAAAALAkAgACgC4A5BAXRB////d0sNACAAKALkDkEBdEH///93Sw0AIAAoAugOQQF0Qf///3dLDQAgACgC7A5BAXRB////d0sNACAAQdQNahCKgICAAEUNACAAQaAMahCKgICAAEUNACAAKAKADEEBdEH///93Sw0AIAAoAoQMQQF0Qf///3dLDQAgACgCiAxBAXRB////d0sNACAAKAKMDEEBdEH///93Sw0AIAAoApAMQQF0Qf///3dLDQAgACgClAxBAXRB////d0sNACAAKAKYDEEBdEH///93Sw0AIAAoApwMQQF0Qf///3dNDQELIABB4A5qIg5CADcCCCAOQgA3AgAgAkEoakEAQYAB/AsAIABB1A1qQQBBhAH8CwAgAkIANwMgIAJCADcDGCACQgA3AxAgAkIANwMIIABBgAxqIAJBCGpBoAH8CgAAIABCADcCoA0gAUUNACADQQJ0Ig5FDQAgAEGACGpBACAO/AsACyACQbABaiSAgICAAAu0AQEBfyOAgICAAEGgAWsiASSAgICAAAJAIABFDQAgACAAKgK0DTgCsA0gACAAKgLADTgCvA0gACAAKgLMDTgCyA0gABCHgICAACAAQgA3AugOIABCADcC4A4gAUEgakEAQYAB/AsAIABB1A1qQQBBhAH8CwAgAUIANwMYIAFCADcDECABQgA3AwggAUIANwMAIABBgAxqIAFBoAH8CgAAIABCADcCoA0LIAFBoAFqJICAgIAAC8UBAwF/AX0BfiOAgICAAEEgayICJICAgIAAAkACQCAARQ0AIAG8QQF0Qf///3dLDQAgACoCrA0iA0MAAKBBYEUNASAAIANDAACgQSABIAFDAACgQV0bIgEgASADXhsQvoGAgAA4ArQNCyACQSBqJICAgIAADwsgAkGAgICNBDYCCCACIAM4AgwgAkGBgICAAK1CIIYiBCACQQxqrYQ3AxggAiAEIAJBCGqthDcDEEHtgcCAACACQRBqQdiKwIAAEImAgIAAAAs+AAJAIABFDQAgAbxBAXRB////d0sNACAAQwAAgD9DAAAAACABIAFDAAAAAF0bIgEgAUMAAIA/Xhs4AswNCwttAgJ/AX0CQCAARQ0AQQIhAkEAIQMCQAJAAkACQAJAIAFBf2oOAwIBAAMLQQMhAgsgACACOgCcD0MAAIA/IQQMAgtBASEDCyAAIAM6AJwPIAAqAoQPQwAAAD+UQwAAgD+SIQQLIAAgBDgCiA8LCz4AAkAgAEUNACABvEEBdEH///93Sw0AIABDAACAP0MAAAAAIAEgAUMAAAAAXRsiASABQwAAgD9eGzgCwA0LC5IDAQR/IAAoAgwhAgJAAkACQAJAIAFBgAJJDQAgACgCGCEDAkACQAJAIAIgAEcNACAAQRRBECAAKAIUIgIbaigCACIBDQFBACECDAILIAAoAggiASACNgIMIAIgATYCCAwBCyAAQRRqIABBEGogAhshBANAIAQhBSABIgJBFGogAkEQaiACKAIUIgEbIQQgAkEUQRAgARtqKAIAIgENAAsgBUEANgIACyADRQ0CAkACQCAAIAAoAhxBAnRB+NnAgABqIgEoAgBGDQAgAygCECAARg0BIAMgAjYCFCACDQMMBAsgASACNgIAIAJFDQQMAgsgAyACNgIQIAINAQwCCwJAIAIgACgCCCIERg0AIAQgAjYCDCACIAQ2AggPC0EAQQAoApDdwIAAQX4gAUEDdndxNgKQ3cCAAA8LIAIgAzYCGAJAIAAoAhAiAUUNACACIAE2AhAgASACNgIYCyAAKAIUIgFFDQAgAiABNgIUIAEgAjYCGA8LDwtBAEEAKAKU3cCAAEF+IAAoAhx3cTYClN3AgAAL7gYBBH8gACABaiECAkACQAJAAkACQCAAKAIEIgNBAXENACADQQJxRQ0BIAAoAgAiAyABaiEBAkAgACADayIAQQAoAqDdwIAARw0AIAIoAgRBA3FBA0cNAUEAIAE2ApjdwIAAIAIgAigCBEF+cTYCBCAAIAFBAXI2AgQgAiABNgIADwsgACADEOyAgIAACwJAAkACQCACKAIEIgNBAnENACACQQAoAqTdwIAARg0CIAJBACgCoN3AgABGDQQgAiADQXhxIgMQ7ICAgAAgACADIAFqIgFBAXI2AgQgACABaiABNgIAIABBACgCoN3AgABHDQFBACABNgKY3cCAAA8LIAIgA0F+cTYCBCAAIAFBAXI2AgQgACABaiABNgIACwJAIAFBgAJJDQBBHyECIAFBgICACEkNBAwFCwJAAkBBACgCkN3AgAAiAkEBIAFBA3Z0IgNxDQBBACACIANyNgKQ3cCAACABQfgBcUGI28CAAGoiASECDAELIAFB+AFxIgFBiNvAgABqIQIgAUGQ28CAAGooAgAhAQsgAiAANgIIIAEgADYCDCAAIAI2AgwgACABNgIIDwtBACAANgKk3cCAAEEAQQAoApzdwIAAIAFqIgE2ApzdwIAAIAAgAUEBcjYCBCAAQQAoAqDdwIAARw0AQQBBADYCmN3AgABBAEEANgKg3cCAAAsPC0EAIAA2AqDdwIAAQQBBACgCmN3AgAAgAWoiATYCmN3AgAAgACABQQFyNgIEIAAgAWogATYCAA8LIAFBJiABQQh2ZyICa3ZBAXEgAkEBdHJBPnMhAgsgAEIANwIQIAAgAjYCHCACQQJ0QfjZwIAAaiEDAkBBACgClN3AgABBASACdCIEcQ0AIAMgADYCACAAIAM2AhggACAANgIMIAAgADYCCEEAQQAoApTdwIAAIARyNgKU3cCAAA8LAkACQAJAIAMoAgAiBCgCBEF4cSABRw0AIAQhAgwBCyABQQBBGSACQQF2ayACQR9GG3QhAwNAIAQgA0EddkEEcWoiBSgCECICRQ0CIANBAXQhAyACIQQgAigCBEF4cSABRw0ACwsgAigCCCIBIAA2AgwgAiAANgIIIABBADYCGCAAIAI2AgwgACABNgIIDwsgBUEQaiAANgIAIAAgBDYCGCAAIAA2AgwgACAANgIICw0AIAEgABChgYCAAAALngECAX8BfiOAgICAAEEwayICJICAgIAAIAJBqJvAgAA2AgQgAiAANgIAIAJBqJvAgAA2AgwgAiABNgIIIAJBAjYCFCACQbGdwIAANgIQIAJBh4CAgACtQiCGIgMgAkEIaq2ENwMoIAIgAyACrYQ3AyAgAkGIgICAAK1CIIYgAkEQaq2ENwMYQZ6CwIAAIAJBGGpB/JvAgAAQiYCAgAAACxwAIAAoAgAgASAAKAIEKAIMEYGAgIAAgICAgAALwQoBDH8gACgCBCECIAAoAgAhAwJAAkAgASgCCCIEQYCAgMABcUUNAAJAAkAgBEGAgICAAXENAAJAIAJBEEkNACACIAMgA0EDakF8cSIFayIGaiIHQQNxIQhBACEJQQAhAAJAIAMgBUYNAEEAIQpBACEAAkAgBkF8Sw0AQQAhCkEAIQADQCAAIAMgCmoiCywAAEG/f0pqIAtBAWosAABBv39KaiALQQJqLAAAQb9/SmogC0EDaiwAAEG/f0pqIQAgCkEEaiIKDQALCyADIApqIQsDQCAAIAssAABBv39KaiEAIAtBAWohCyAGQQFqIgYNAAsLAkAgCEUNACAFIAdB/P///wdxaiILLAAAQb9/SiEJIAhBAUYNACAJIAssAAFBv39KaiEJIAhBAkYNACAJIAssAAJBv39KaiEJCyAHQQJ2IQggCSAAaiEKA0AgBSEJIAhFDQMgCEHAASAIQcABSRsiB0EDcSEMAkACQCAHQQJ0Ig1B8AdxIgANAEEAIQsMAQsgCSAAaiEGQQAhCyAJIQADQCAAQQxqKAIAIgVBf3NBB3YgBUEGdnJBgYKECHEgAEEIaigCACIFQX9zQQd2IAVBBnZyQYGChAhxIABBBGooAgAiBUF/c0EHdiAFQQZ2ckGBgoQIcSAAKAIAIgVBf3NBB3YgBUEGdnJBgYKECHEgC2pqamohCyAAQRBqIgAgBkcNAAsLIAggB2shCCAJIA1qIQUgC0EIdkH/gfwHcSALQf+B/AdxakGBgARsQRB2IApqIQogDEUNAAsgCSAHQfwBcUECdGoiCygCACIAQX9zQQd2IABBBnZyQYGChAhxIQACQCAMQQFGDQAgCygCBCIFQX9zQQd2IAVBBnZyQYGChAhxIABqIQAgDEECRg0AIAsoAggiC0F/c0EHdiALQQZ2ckGBgoQIcSAAaiEACyAAQQh2Qf+BHHEgAEH/gfwHcWpBgYAEbEEQdiAKaiEKDAILAkAgAg0AQQAhCgwCCyACQQNxIQtBACEFQQAhCgJAIAJBBEkNACACQQxxIQZBACEKQQAhBQNAIAogAyAFaiIALAAAQb9/SmogAEEBaiwAAEG/f0pqIABBAmosAABBv39KaiAAQQNqLAAAQb9/SmohCiAGIAVBBGoiBUcNAAsgC0UNAgsgAyAFaiEAA0AgCiAALAAAQb9/SmohCiAAQQFqIQAgC0F/aiILDQAMAgsLAkACQAJAIAEvAQ4iCg0AQQAhAgwBCyADIAJqIQZBACECIAMhCyAKIQUDQCALIgAgBkYNAgJAAkAgACwAACILQX9MDQAgAEEBaiELDAELAkAgC0FgTw0AIABBAmohCwwBCyAAQQRBAyALQW9LG2ohCwsgCyAAayACaiECIAVBf2oiBQ0ACwtBACEFCyAKIAVrIQoLIAogAS8BDCIASQ0BCyABKAIAIAMgAiABKAIEKAIMEYKAgIAAgICAgAAPCyAAIAprIQlBACEAQQAhCAJAAkACQCAEQR12QQNxDgQCAAECAgsgCSEIDAELIAlB/v8DcUEBdiEICyAEQf///wBxIQogASgCBCELIAEoAgAhBQJAAkADQCAAQf//A3EgCEH//wNxTw0BQQEhBiAAQQFqIQAgBSAKIAsoAhARgYCAgACAgICAAEUNAAwCCwtBASEGIAUgAyACIAsoAgwRgoCAgACAgICAAA0AIAkgCGtB//8DcSEIQQAhAANAAkAgAEH//wNxIAhJDQBBAA8LQQEhBiAAQQFqIQAgBSAKIAsoAhARgYCAgACAgICAAEUNAAsLIAYLOAIBfwF+I4CAgIAAQRBrIgEkgICAgAAgACkCACECIAEgADYCDCABIAI3AgQgAUEEahCPgYCAAAAL9AQBCH8jgICAgABBEGsiBCSAgICAAAJAAkACQCADQQFxDQAgAi0AACIFDQFBACEFDAILIAAgAiADQQF2IAEoAgwRgoCAgACAgICAACEFDAELIAEoAgwhBkEAIQcDQCACQQFqIQgCQAJAAkACQAJAIAXAQX9KDQAgBUH/AXEiCUGAAUYNASAJQcABRw0DIAQgATYCBCAEIAA2AgAgBEKggICABjcCCCADIAdBA3RqIgUoAgAgBCAFKAIEEYGAgIAAgICAgABFDQJBASEFDAYLAkAgACAIIAVB/wFxIgUgBhGCgICAAICAgIAADQAgCCAFaiECDAQLQQEhBQwFCwJAIAAgAkEDaiIFIAIvAAEiAiAGEYKAgIAAgICAgAANACAFIAJqIQIMAwtBASEFDAQLIAdBAWohByAIIQIMAQtBoICAgAYhCgJAIAVBAXFFDQAgAkEFaiEIIAIoAAEhCgtBACEJAkACQCAFQQJxDQBBACELIAghAgwBCyAIQQJqIQIgCC8AACELCwJAAkAgBUEEcQ0AIAIhCAwBCyACQQJqIQggAi8AACEJCwJAAkAgBUEIcQ0AIAghAgwBCyAIQQJqIQIgCC8AACEHCwJAIAVBEHFFDQAgAyALQf//A3FBA3RqLwEEIQsLAkAgBUEgcUUNACADIAlB//8DcUEDdGovAQQhCQsgBCAJOwEOIAQgCzsBDCAEIAo2AgggBCABNgIEIAQgADYCAAJAIAMgB0EDdGoiBSgCACAEIAUoAgQRgYCAgACAgICAAEUNAEEBIQUMAwsgB0EBaiEHCyACLQAAIgUNAAtBACEFCyAEQRBqJICAgIAAIAULRgACQCACQX9GDQAgACACIAEoAhARgYCAgACAgICAAEUNAEEBDwsCQCADDQBBAA8LIAAgAyAEIAEoAgwRgoCAgACAgICAAAs0AQF/I4CAgIAAQRBrIgIkgICAgAAgAiABNgIMIAIgADYCCCACQQhqIAJBDGoQ74CAgAAAC6sEAwJ/A34CfyOAgICAAEEgayICJICAgIAAIAAoAgAhAwJAAkACQCABKAIIIgBBgICAEHENACAAQYCAgCBxDQFBFCEAIAMpAwAiBCEFAkAgBELoB1QNAEEUIQAgBCEFA0AgAkEMaiAAaiIDQXxqIAUiBiAGQpDOAIAiBUKQzgB+faciB0H//wNxQeQAbiIIQQF0LwCzncCAADsAACADQX5qIAcgCEHkAGxrQf//A3FBAXQvALOdwIAAOwAAIABBfGohACAGQv+s4gRWDQALCwJAIAVCCVgNACACQQxqIABBfmoiAGogBaciAyADQf//A3FB5ABuIgNB5ABsa0H//wNxQQF0LwCzncCAADsAACADrSEFCwJAAkAgBFANACAFUA0BCyACQQxqIABBf2oiAGogBadBAXQtALSdwIAAOgAACyABQQFBACACQQxqIABqQRQgAGsQvoCAgAAhAAwCCyADKQMAIQZBESEAA0AgAkEMaiAAakF+aiAGp0EPcS0AmJvAgAA6AAAgAEF/aiEAIAZCBIgiBkIAUg0ACyABQfyxwIAAQQIgAkEMaiAAakF/akERIABrEL6AgIAAIQAMAQsgAykDACEGQREhAANAIAJBDGogAGpBfmogBqdBD3EtAP6xwIAAOgAAIABBf2ohACAGQgSIIgZCAFINAAsgAUH8scCAAEECIAJBDGogAGpBf2pBESAAaxC+gICAACEACyACQSBqJICAgIAAIAALxgUCDH8CfiOAgICAAEGgAWsiAySAgICAAEEAIQQgA0EAQaAB/AsAAkACQAJAIAAoAqABIgUgAkkNACAFQSlPDQIgBUEBaiEGIAVBAnQhByABIAJBAnRqIQhBACEJQQAhCgJAA0AgAyAJQQJ0aiELA0AgCSEEIAshDCABIAhGDQQgDEEEaiELIARBAWohCSABKAIAIQ0gAUEEaiIOIQEgDUUNAAsgDa0hD0IAIRAgByENIAQhASAAIQsDQCABQShPDQIgDCAQIAw1AgB8IAs1AgAgD358IhA+AgAgEEIgiCEQIAxBBGohDCABQQFqIQEgC0EEaiELIA1BfGoiDQ0ACyAFIQwCQAJAIBBQDQAgBCAFaiIMQShPDQEgAyAMQQJ0aiAQpzYCACAGIQwLIAogDCAEaiIMIAogDEsbIQogDiEBDAELCyAMQShBxJzAgAAQjoCAgAAACyABQShBxJzAgAAQjoCAgAAACyACQQFqIQYgAkECdCEHIAAgBUECdGohDiAAIQtBACEKAkADQCADIARBAnRqIQkDQCAEIQ0gCSEMIAsgDkYNAyAMQQRqIQkgDUEBaiEEIAsoAgAhCCALQQRqIgUhCyAIRQ0ACyAIrSEPQgAhECAHIQggDSELIAEhCQNAIAtBKE8NAiAMIBAgDDUCAHwgCTUCACAPfnwiED4CACAQQiCIIRAgDEEEaiEMIAtBAWohCyAJQQRqIQkgCEF8aiIIDQALIAIhDAJAAkAgEFANACANIAJqIgxBKE8NASADIAxBAnRqIBCnNgIAIAYhDAsgCiAMIA1qIgwgCiAMSxshCiAFIQsMAQsLIAxBKEHEnMCAABCOgICAAAALIAtBKEHEnMCAABCOgICAAAALIAAgA0GgAfwKAAAgACAKNgKgASADQaABaiSAgICAACAADwtBACAFQShBxJzAgAAQloCAgAAAC8IEAQl/AkACQAJAIAFBgApPDQAgAUEFdiECAkACQAJAIAAoAqABIgNFDQAgA0F/aiEEIANBAnQgAGpBfGohBSADIAJqQQJ0IABqQXxqIQYgA0EpSSEDA0AgA0UNAiACIARqIgdBKE8NAyAGIAUoAgA2AgAgBkF8aiEGIAVBfGohBSAEQX9qIgRBf0cNAAsLIAFBH3EhBQJAIAJFDQAgAkECdCIERQ0AIABBACAE/AsACyAAKAKgASIHIAJqIQQCQCAFDQAgACAENgKgASAADwsgBEF/aiIGQSdLDQMgBCEIIAAgBkECdGooAgBBICAFayIGdiIDRQ0EAkAgBEEnSw0AIAAgBEECdGogAzYCACAEQQFqIQgMBQsgBEEoQcScwIAAEI6AgIAAAAsgBEEoQcScwIAAEI6AgIAAAAsgB0EoQcScwIAAEI6AgIAAAAtB1JzAgABBHUHEnMCAABCCgICAAAALIAZBKEHEnMCAABCOgICAAAALAkAgAkEBaiIJIARPDQACQAJAIAdBAXFFDQAgBCEDDAELIAAgBEF/aiIDQQJ0aiIBIAAgBEECdGpBeGooAgAgBnYgASgCACAFdHI2AgALIAdBAkYNACADQQJ0IABqQXRqIQQDQCAEQQhqIgcgBEEEaiIBKAIAIgogBnYgBygCACAFdHI2AgAgASAEKAIAIAZ2IAogBXRyNgIAIARBeGohBCAJIANBfmoiA0kNAAsLIAAgAkECdGoiBCAEKAIAIAV0NgIAIAAgCDYCoAEgAAtSAQF/I4CAgIAAQRBrIgAkgICAgAAgAEEcNgIEIABBkLTAgAA2AgAgAEGIgICAAK1CIIYgAK2ENwMIQdOCwIAAIABBCGpBrLTAgAAQiYCAgAAACxMAQfyewIAAQTMgABCJgICAAAALhAMBAX8CQAJAIAJFDQAgAS0AAEEwTQ0BIAVBAjsBAAJAAkACQAJAAkAgA8EiBkEBSA0AIAUgATYCBCACIANB//8DcSIDSw0CIAVBADsBDCAFIAI2AgggBSADIAJrNgIQIAQNAUECIQEMBAsgBSACNgIgIAUgATYCHCAFQQI7ARggBUEAOwEMIAVBAjYCCCAFQcGbwIAANgIEIAVBACAGayIDNgIQQQMhASAEIAJNDQMgBCACayICIANNDQMgAiAGaiEEDAILIAVBATYCICAFQfuewIAANgIcIAVBAjsBGAwBCyAFQQI7ARggBUEBNgIUIAVB+57AgAA2AhAgBUECOwEMIAUgAzYCCCAFIAIgA2siAjYCICAFIAEgA2o2AhwCQCAEIAJLDQBBAyEBDAILIAQgAmshBAsgBSAENgIoIAVBADsBJEEEIQELIAAgATYCBCAAIAU2AgAPC0GVn8CAAEEhQbifwIAAEIKAgIAAAAtByJ/AgABBH0Hon8CAABCCgICAAAALsAYGAX8BfgF/A34HfwF+I4CAgIAAQRBrIgYkgICAgAACQAJAAkACQAJAIAFCAFENAEGgfyACIAF5IgenayIIa8FB0ABsQbCnBWpBzhBtIgJB0ABLDQEgBiACQQR0IgIpA6CgwIAAQgAgASAHhkIAEL2BgIAAAkBCAUFAIAggAi8BqKDAgABqayIIrSIJhiIKQn98IgsgBikDAEI/iCAGKQMIfCIBgyIHUA0AIAIvAaqgwIAAIQwgCEE/cSENAkAgASAJiKciDkGQzgBJDQAgDkHAhD1JDQQCQCAOQYDC1y9JDQBBCEEJIA5BgJTr3ANJIgIbIQ9BgMLXL0GAlOvcAyACGyECDAYLQQZBByAOQYCt4gRJIgIbIQ9BwIQ9QYCt4gQgAhshAgwFCwJAIA5B5ABJDQBBAkEDIA5B6AdJIgIbIQ9B5ABB6AcgAhshAgwFC0EKQQEgDkEJSyIPGyECDAQLIABBADYCAAwEC0GwqsCAAEEcQcyqwIAAEIKAgIAAAAsgAkHRAEHcqsCAABCOgICAAAALQQRBBSAOQaCNBkkiAhshD0GQzgBBoI0GIAIbIQILIA2tIQkCQAJAAkACQCAPIAxrQQFqwSIQIAXBIgxMDQAgCEH//wNxIREgECAFa8EgBCAQIAxrIARJGyISQX9qIQ1BACEIA0AgAyAIaiAOIAJuIgxBMGo6AAAgDiAMIAJsayEOIA0gCEYNAyAPIAhGDQIgCEEBaiEIIAJBCkkhDCACQQpuIQIgDEUNAAtB7KrAgAAQ+oCAgAAACyAAIAMgBEEAIBAgBSABQgqAIAKtIAmGIAoQ/YCAgAAMAwsgCEEBaiECIBFBf2pBP3GtIRNCASEBA0ACQCABIBOIUA0AIABBADYCAAwECyAEIAJGDQIgAyACaiAHQgp+IgcgCYinQTBqOgAAIAFCCn4hASAHIAuDIQcgEiACQQFqIgJHDQALIAAgAyAEIBIgECAFIAcgCiABEP2AgIAADAILIAAgAyAEIBIgECAFIA6tIAmGIAd8IAKtIAmGIAoQ/YCAgAAMAQsgBCAEQfyqwIAAEI6AgIAAAAsgBkEQaiSAgICAAAv9AgEEfwJAAkACQAJAAkACQAJAAkAgByAIWA0AIAcgCH0gCFgNBAJAIAcgBn0gBlgNACAHIAZCAYZ9IAhCAYZaDQQLIAYgCFgNByAHIAYgCH0iCH0gCFYNByADIAJLDQUgASADaiEJIAMhCgNAIAoiC0UNAiALQX9qIgogAWoiDC0AAEE5Rg0ACyAMIAwtAABBAWo6AAAgAyALayIKRQ0CIAEgC2pBMCAK/AsADAILIABBADYCAA8LAkACQCADDQBBMSEKDAELIAFBMToAAEEwIQogA0F/aiILRQ0AIAFBAWpBMCAL/AsACyAEQQFqwSIEIAXBTA0AIAMgAk8NACAJIAo6AAAgA0EBaiEDCyADIAJNDQNBACADIAJBzLHAgAAQloCAgAAACyADIAJNDQJBACADIAJB7LHAgAAQloCAgAAACyAAQQA2AgAPC0EAIAMgAkHcscCAABCWgICAAAALIAAgBDsBCCAAIAM2AgQgACABNgIADwsgAEEANgIAC6InAwF/A34bfyOAgICAAEHABmsiBSSAgICAAAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkAgASkDACIGQgBRDQAgASkDCCIHQgBRDQEgASkDECIIQgBRDQIgCCAGQn+FVg0DIAYgB1QNBCABLgEYIQEgBSAGNwMIIAVBAUECIAZCgICAgBBUGzYCqAEgBUEQakEAQZgB/AsAIAVBtAFqQQBBnAH8CwAgBUEBNgKwASAFQQE2AtACIAGsIAZCf3x5fULCmsHoBH5CgKHNoLQCfEIgiKciCcEhCgJAAkAgAUEASA0AIAVBCGogARD4gICAABoMAQsgBUGwAWpBACABa8EQ+ICAgAAaCwJAAkAgCkF/Sg0AIAVBCGpBACAKa0H//wNxEP+AgIAAGgwBCyAFQbABaiAJQf//AXEQ/4CAgAAaCyAFQZwFaiAFQbABakGkAfwKAAAgBUGcBWpBeGohCyADIQwDQAJAAkACQAJAIAUoArwGIgFBKEsNACABRQ0DIAFBAnQiAUF8aiINDQEgBUGcBWogAWohAUIAIQYMAgtBACABQShBxJzAgAAQloCAgAAACyALIAFqIQkgDUECdkEBakH+////B3EhDkIAIQYDQCAJIgFBBGoiCSAGQiCGIAk1AgCEIgZCgJTr3AOAIgc+AgAgASAGIAdCgJTr3AN+fUIghiABNQIAhCIGQoCU69wDgCIHPgIAIAYgB0KAlOvcA359IQYgAUF4aiEJIA5BfmoiDg0ACyANQQRxDQELIAFBfGoiASAGQiCGIAE1AgCEQoCU69wDgD4CAAsgDEF3aiIMQQlLDQALIAxBAnQoAoiwwIAAQQF0IglFDQUCQAJAAkACQAJAIAUoArwGIgFBKEsNAAJAIAENAEEAIQEMBQsgCa0hBiABQQJ0IgFBfGoiDA0BIAVBnAVqIAFqIQFCACEHDAILQQAgAUEoQcScwIAAEJaAgIAAAAsgDEECdkEBakH+////B3EhCSABIAVBnAVqakF4aiEOQgAhBwNAIA4iAUEEaiIOIAdCIIYgDjUCAIQiByAGgCIIPgIAIAEgByAIIAZ+fUIghiABNQIAhCIHIAaAIgg+AgAgByAIIAZ+fSEHIAFBeGohDiAJQX5qIgkNAAsgDEEEcQ0BCyABQXxqIgEgB0IghiABNQIAhCAGgD4CAAsgBSgCvAYhAQsgBSgCqAEiDyABIA8gAUsbIhBBKEsNBgJAAkAgEA0AQQAhEAwBC0EAIQxBACENAkACQAJAIBBBAUYNACAQQQFxIREgEEE+cSESQQAhDCAFQZwFaiEBIAVBCGohCUEAIQ0DQCABIAkoAgAiCyABKAIAaiIOIAxBAXFqIhM2AgAgAUEEaiIMIAlBBGooAgAiFCAMKAIAaiIMIA4gC0kgEyAOSXJqIg42AgAgDCAUSSAOIAxJciEMIAlBCGohCSABQQhqIQEgEiANQQJqIg1HDQALIBFFDQELIAVBnAVqIA1BAnQiAWoiCSAFQQhqIAFqKAIAIg4gCSgCAGoiASAMaiIJNgIAIAEgDkkNASAJIAFJDQEMAgsgDEUNAQsgEEEoRg0IIAVBnAVqIBBBAnRqQQE2AgAgEEEBaiEQCyAFIBA2ArwGIAUoAtACIhUgECAVIBBLGyIBQSlPDQggAUECdCEBIAVBnAVqQXxqIQkCQAJAA0AgAUUNASAJIAFqKAIAIg4gAUF8aiIBIAVBsAFqaigCACIMRg0ACyAOIAxPDQACQCAPDQBBACEPIAVBADYCqAEMAgsgD0ECdCINQXxqIgFBAnZBAWoiCUEDcSEMAkACQAJAIAFBDE8NAEIAIQYgBUEIaiEBDAELIAlB/P///wdxIQlCACEGIAVBCGohAQNAIAEgATUCAEIKfiAGfCIGPgIAIAFBBGoiDiAONQIAQgp+IAZCIIh8IgY+AgAgAUEIaiIOIA41AgBCCn4gBkIgiHwiBj4CACABQQxqIg4gDjUCAEIKfiAGQiCIfCIGPgIAIAZCIIghBiABQRBqIQEgCUF8aiIJDQALIAxFDQELIAxBAnQhCQNAIAEgATUCAEIKfiAGfCIGPgIAIAFBBGohASAGQiCIIQYgCUF8aiIJDQALCwJAIAZQDQAgD0EoRg0MIAVBCGogDWogBqc2AgAgD0EBaiEPCyAFIA82AqgBDAELIApBAWohCgtBACEWQQEhCwJAAkAgCsEiASAEwSIJSCIXDQAgCiAEa8EgAyABIAlrIANJGyIYDQELQQAhGAwWCyAFQdQCaiAFQbABakGkAfwKAAAgBUHUAmpBARD4gICAACEZIAVB+ANqIAVBsAFqQaQB/AoAACAFQfgDakECEPiAgIAAIRogBUGcBWogBUGwAWpBpAH8CgAAIAVBsAFqQXxqIREgBUHUAmpBfGohBCAFQfgDakF8aiEQIAVBnAVqQXxqIRIgBUGcBWpBAxD4gICAACEbIBkoAqABIRwgGigCoAEhHSAbKAKgASEeQQAhHwJAAkADQCAfISAgD0EpTw0NICBBAWohHyAPQQJ0IQ5BACEBA0AgDiABRg0DIAVBCGogAWohCSABQQRqIQEgCSgCAEUNAAsgHiAPIB4gD0sbIiFBKU8NDiAhQQJ0IQECQAJAA0AgAUUNASASIAFqIQkgAUF8aiIBIAVBCGpqKAIAIg4gCSgCACIJRg0AC0EAISIgDiAJSQ0BC0EBIQxBACENAkACQAJAICFBAUYNACAhQQFxISMgIUE+cSEPQQAhDUEBIQwgBUEIaiEBIAVBnAVqIQkDQCABIAEoAgAiCyAJKAIAQX9zaiIOIAxBAXFqIhM2AgAgAUEEaiIMIAwoAgAiFCAJQQRqKAIAQX9zaiIMIA4gC0kgEyAOSXJqIg42AgAgDCAUSSAOIAxJciEMIAlBCGohCSABQQhqIQEgDyANQQJqIg1HDQALICNFDQELIAVBCGogDUECdCIBaiIJIAkoAgAiCSAbIAFqKAIAQX9zaiIBIAxqIg42AgAgASAJSQ0BIA4gAUkNAQwaCyAMRQ0ZCyAFICE2AqgBQQghIiAhIQ8LIB0gDyAdIA9LGyIhQSlPDQ8gIUECdCEBAkACQANAIAFFDQEgECABaiEJIAFBfGoiASAFQQhqaigCACIOIAkoAgAiCUYNAAsgDiAJTw0AIA8hIQwBCwJAICFFDQBBASEMQQAhDQJAAkAgIUEBRg0AICFBAXEhIyAhQT5xIQ9BACENQQEhDCAFQQhqIQEgBUH4A2ohCQNAIAEgASgCACILIAkoAgBBf3NqIg4gDEEBcWoiEzYCACABQQRqIgwgDCgCACIUIAlBBGooAgBBf3NqIgwgDiALSSATIA5JcmoiDjYCACAMIBRJIA4gDElyIQwgCUEIaiEJIAFBCGohASAPIA1BAmoiDUcNAAsgI0UNAQsgBUEIaiANQQJ0IgFqIgkgCSgCACIJIBogAWooAgBBf3NqIgEgDGoiDjYCACABIAlJDQEgDiABSQ0BDBkLIAxFDRgLIAUgITYCqAEgIkEEciEiCyAcICEgHCAhSxsiI0EpTw0QICNBAnQhAQJAAkADQCABRQ0BIAQgAWohCSABQXxqIgEgBUEIamooAgAiDiAJKAIAIglGDQALIA4gCU8NACAhISMMAQsCQCAjRQ0AQQEhDEEAIQ0CQAJAICNBAUYNACAjQQFxISEgI0E+cSEPQQAhDUEBIQwgBUEIaiEBIAVB1AJqIQkDQCABIAEoAgAiCyAJKAIAQX9zaiIOIAxBAXFqIhM2AgAgAUEEaiIMIAwoAgAiFCAJQQRqKAIAQX9zaiIMIA4gC0kgEyAOSXJqIg42AgAgDCAUSSAOIAxJciEMIAlBCGohCSABQQhqIQEgDyANQQJqIg1HDQALICFFDQELIAVBCGogDUECdCIBaiIJIAkoAgAiCSAZIAFqKAIAQX9zaiIBIAxqIg42AgAgASAJSQ0BIA4gAUkNAQwYCyAMRQ0XCyAFICM2AqgBICJBAmohIgsgFSAjIBUgI0sbIg9BKU8NESAPQQJ0IQECQAJAA0AgAUUNASARIAFqIQkgAUF8aiIBIAVBCGpqKAIAIg4gCSgCACIJRg0ACyAOIAlPDQAgIyEPDAELAkAgD0UNAEEBIQxBACENAkACQCAPQQFGDQAgD0EBcSEjIA9BPnEhIUEAIQ1BASEMIAVBCGohASAFQbABaiEJA0AgASABKAIAIgsgCSgCAEF/c2oiDiAMQQFxaiITNgIAIAFBBGoiDCAMKAIAIhQgCUEEaigCAEF/c2oiDCAOIAtJIBMgDklyaiIONgIAIAwgFEkgDiAMSXIhDCAJQQhqIQkgAUEIaiEBICEgDUECaiINRw0ACyAjRQ0BCyAFQQhqIA1BAnQiAWoiCSAJKAIAIgkgBUGwAWogAWooAgBBf3NqIgEgDGoiDjYCACABIAlJDQEgDiABSQ0BDBcLIAxFDRYLIAUgDzYCqAEgIkEBaiEiCyAgIANGDQEgAiAgaiAiQTBqOgAAAkACQCAPDQBBACEPDAELIA9BAnQiDUF8aiIBQQJ2QQFqIglBA3EhDAJAAkACQCABQQxPDQBCACEGIAVBCGohAQwBCyAJQfz///8HcSEJQgAhBiAFQQhqIQEDQCABIAE1AgBCCn4gBnwiBj4CACABQQRqIg4gDjUCAEIKfiAGQiCIfCIGPgIAIAFBCGoiDiAONQIAQgp+IAZCIIh8IgY+AgAgAUEMaiIOIA41AgBCCn4gBkIgiHwiBj4CACAGQiCIIQYgAUEQaiEBIAlBfGoiCQ0ACyAMRQ0BCyAMQQJ0IQkDQCABIAE1AgBCCn4gBnwiBj4CACABQQRqIQEgBkIgiCEGIAlBfGoiCQ0ACwsgBlANACAPQShGDRMgBUEIaiANaiAGpzYCACAPQQFqIQ8LIAUgDzYCqAEgHyAYRw0AC0EAIQsMFwsgAyADQciuwIAAEI6AgIAAAAsgGCADSw0QAkAgGCAgRg0AIBggIGsiAUUNACACICBqQTAgAfwLAAsgACAKOwEIIAAgGDYCBAwWC0GwqsCAAEEcQeitwIAAEIKAgIAAAAtBnKvAgABBHUH4rcCAABCCgICAAAALQcyrwIAAQRxBiK7AgAAQgoCAgAAAC0GgrcCAAEE2QfiuwIAAEIKAgIAAAAtB2KzAgABBN0HorsCAABCCgICAAAALQYycwIAAQRtBxJzAgAAQgoCAgAAAC0EAIBBBKEHEnMCAABCWgICAAAALQShBKEHEnMCAABCOgICAAAALQQAgAUEoQcScwIAAEJaAgIAAAAtBKEEoQcScwIAAEI6AgIAAAAtBACAPQShBxJzAgAAQloCAgAAAC0EAICFBKEHEnMCAABCWgICAAAALQQAgIUEoQcScwIAAEJaAgIAAAAtBACAjQShBxJzAgAAQloCAgAAAC0EAIA9BKEHEnMCAABCWgICAAAALQShBKEHEnMCAABCOgICAAAALICAgGCADQdiuwIAAEJaAgIAAAAtBp5zAgABBGkHEnMCAABCCgICAAAALQaecwIAAQRpBxJzAgAAQgoCAgAAAC0GnnMCAAEEaQcScwIAAEIKAgIAAAAtBp5zAgABBGkHEnMCAABCCgICAAAALAkACQAJAAkACQAJAAkACQCAVRQ0AIBVBAnQiDUF8aiIBQQJ2QQFqIglBA3EhDAJAAkACQCABQQxPDQBCACEGIAVBsAFqIQEMAQsgCUH8////B3EhCUIAIQYgBUGwAWohAQNAIAEgATUCAEIFfiAGfCIGPgIAIAFBBGoiDiAONQIAQgV+IAZCIIh8IgY+AgAgAUEIaiIOIA41AgBCBX4gBkIgiHwiBj4CACABQQxqIg4gDjUCAEIFfiAGQiCIfCIGPgIAIAZCIIghBiABQRBqIQEgCUF8aiIJDQALIAxFDQELIAxBAnQhCQNAIAEgATUCAEIFfiAGfCIGPgIAIAFBBGohASAGQiCIIQYgCUF8aiIJDQALCwJAIAZQRQ0AIBUhFgwBCyAVQShGDQEgBUGwAWogDWogBqc2AgAgFUEBaiEWCyAFIBY2AtACIBYgDyAWIA9LGyIBQSlPDQEgAUECdCEBIAVBCGpBfGohDCAFQbABakF8aiENAkACQANAIAFFDQEgDSABaiEJIAwgAWohDiABQXxqIQEgDigCACIOIAkoAgAiCUYNAAsgDiAJSyAOIAlJa0H/AXEOAgABBgtBACEBIAsNBiAYQX9qIgEgA08NAyACIAFqLQAAQQFxRQ0FCyAYIANLDQMgAiAYaiEMIBghAQJAA0AgASIJRQ0BIAlBf2oiASACaiIOLQAAQTlGDQALIA4gDi0AAEEBajoAACAYIAlrIgFFDQUgAiAJakEwIAH8CwAMBQtBMSEBAkAgCw0AIAJBMToAAEEwIQEgGEF/aiIJRQ0AIAJBAWpBMCAJ/AsACyAKQQFqIQogFw0EIBggA08NBCAMIAE6AAAgGEEBaiEYDAQLQShBKEHEnMCAABCOgICAAAALQQAgAUEoQcScwIAAEJaAgIAAAAsgASADQZiuwIAAEI6AgIAAAAtBACAYIANBqK7AgAAQloCAgAAACyAYIANLDQEgGCEBCyAAIAo7AQggACABNgIEDAELQQAgGCADQbiuwIAAEJaAgIAAAAsgACACNgIAIAVBwAZqJICAgIAAC50KAgZ/An4CQAJAAkACQAJAAkAgAUEISQ0AIAFBB3EiAkUNBSAAKAKgASIDQShLDQECQCADDQAgAEEANgKgAQwGCyADQQJ0IgRBfGoiBUECdkEBaiIGQQNxIQcgAkECdCgCiLDAgAAgAnatIQhCACEJIAAhAgJAAkAgBUEMSQ0AIAZB/P///wdxIQVCACEJIAAhAgNAIAIgAjUCACAIfiAJfCIJPgIAIAJBBGoiBiAGNQIAIAh+IAlCIIh8Igk+AgAgAkEIaiIGIAY1AgAgCH4gCUIgiHwiCT4CACACQQxqIgYgBjUCACAIfiAJQiCIfCIJPgIAIAlCIIghCSACQRBqIQIgBUF8aiIFDQALIAdFDQELIAdBAnQhBQNAIAIgAjUCACAIfiAJfCIJPgIAIAJBBGohAiAJQiCIIQkgBUF8aiIFDQALCwJAIAlQDQAgA0EoRg0DIAAgBGogCac2AgAgA0EBaiEDCyAAIAM2AqABDAULIAAoAqABIgZBKEsNAgJAIAYNACAAQQA2AqABIAAPCyABQQJ0NQKIsMCAACEIIAZBAnQiB0F8aiIFQQJ2QQFqIgFBA3EhA0IAIQkgACECAkACQCAFQQxJDQAgAUH8////B3EhBUIAIQkgACECA0AgAiACNQIAIAh+IAl8Igk+AgAgAkEEaiIBIAE1AgAgCH4gCUIgiHwiCT4CACACQQhqIgEgATUCACAIfiAJQiCIfCIJPgIAIAJBDGoiASABNQIAIAh+IAlCIIh8Igk+AgAgCUIgiCEJIAJBEGohAiAFQXxqIgUNAAsgA0UNAQsgA0ECdCEFA0AgAiACNQIAIAh+IAl8Igk+AgAgAkEEaiECIAlCIIghCSAFQXxqIgUNAAsLAkAgCVANACAGQShGDQQgACAHaiAJpzYCACAGQQFqIQYLIAAgBjYCoAEgAA8LQQAgA0EoQcScwIAAEJaAgIAAAAtBKEEoQcScwIAAEI6AgIAAAAtBACAGQShBxJzAgAAQloCAgAAAC0EoQShBxJzAgAAQjoCAgAAACwJAAkACQCABQQhxRQ0AIAAoAqABIgNBKEsNAQJAAkAgAw0AQQAhAwwBCyADQQJ0IgRBfGoiBUECdkEBaiIGQQNxIQdCACEIIAAhAgJAAkAgBUEMSQ0AIAZB/P///wdxIQVCACEIIAAhAgNAIAIgAjUCAELh6xd+IAh8Igg+AgAgAkEEaiIGIAY1AgBC4esXfiAIQiCIfCIIPgIAIAJBCGoiBiAGNQIAQuHrF34gCEIgiHwiCD4CACACQQxqIgYgBjUCAELh6xd+IAhCIIh8Igg+AgAgCEIgiCEIIAJBEGohAiAFQXxqIgUNAAsgB0UNAQsgB0ECdCEFA0AgAiACNQIAQuHrF34gCHwiCD4CACACQQRqIQIgCEIgiCEIIAVBfGoiBQ0ACwsgCFANACADQShGDQMgACAEaiAIpzYCACADQQFqIQMLIAAgAzYCoAELAkAgAUEQcUUNACAAQbCwwIAAQQIQ94CAgAAaCwJAIAFBIHFFDQAgAEG4sMCAAEEDEPeAgIAAGgsCQCABQcAAcUUNACAAQcSwwIAAQQUQ94CAgAAaCwJAIAFBgAFxRQ0AIABB2LDAgABBChD3gICAABoLAkAgAUGAAnFFDQAgAEGAscCAAEETEPeAgIAAGgsgACABEPiAgIAAGiAADwtBACADQShBxJzAgAAQloCAgAAAC0EoQShBxJzAgAAQjoCAgAAAC5gNCgF/Bn4BfwR+AX8FfgJ/AX4EfwJ+I4CAgIAAQdAAayIDJICAgIAAAkACQAJAAkACQAJAAkACQAJAAkACQCABKQMAIgRCAFENACABKQMIIgVCAFENASABKQMQIgZCAFENAiAGIAR8IgcgBlQNAyAEIAVUDQQgB0KAgICAgICAgCBaDQUgAyABLwEYIgE7AUAgAyAEIAV9IgU3AzggAyAFIAd5IgaGIgggBogiCTcDSCAJIAVSDQYgAyABOwFAIAMgBDcDOCADIAQgBoYiCSAGiCIFNwNIIAUgBFINB0GgfyABIAanayIKa8FB0ABsQbCnBWpBzhBtIgFB0ABLDQkgA0EgaiABQQR0IgEpA6CgwIAAIgRCACAHIAaGQgAQvYGAgAAgA0EQaiAEQgAgCEIAEL2BgIAAIAMgBEIAIAlCABC9gYCAAEIBQQAgCiABLwGooMCAAGprIgqtIgSGIghCf3whCyADKQMQQj+HIQwgAykDAEI/iCENIAMpAwghDiABLwGqoMCAACEBIApBP3EhDyADKQMYIRACQCADKQMoIhEgAykDIEI/iCISfCITQgF8IhQgBIinIhVBkM4ASQ0AIBVBwIQ9SQ0JAkAgFUGAwtcvSQ0AQQhBCSAVQYCU69wDSSIKGyEWQYDC1y9BgJTr3AMgChshCgwMC0EGQQcgFUGAreIESSIKGyEWQcCEPUGAreIEIAobIQoMCwsCQCAVQeQASQ0AQQJBAyAVQegHSSIKGyEWQeQAQegHIAobIQoMCwtBCkEBIBVBCUsiFhshCgwKC0GwqsCAAEEcQYyrwIAAEIKAgIAAAAtBnKvAgABBHUG8q8CAABCCgICAAAALQcyrwIAAQRxB6KvAgAAQgoCAgAAAC0GgrcCAAEE2QditwIAAEIKAgIAAAAtB2KzAgABBN0GQrcCAABCCgICAAAALQfirwIAAQS1BqKzAgAAQgoCAgAAACyADQcgAaiADQThqEPWAgIAAAAsgA0HIAGogA0E4ahD1gICAAAALQQRBBSAVQaCNBkkiChshFkGQzgBBoI0GIAobIQoMAQsgAUHRAEHcqsCAABCOgICAAAALIBQgC4MhBCANIA58IRcgD60hBiAWIAFrQQFqIRggDCAQfSAUfEIBfCIJIAuDIQVBACEBAkACQAJAAkACQAJAAkACQAJAA0AgAiABaiIZIBUgCm4iD0EwaiIaOgAAIAFBAWohGyAJIBUgDyAKbGsiFa0gBoYiHCAEfCIHVg0CAkAgFiABRw0AQgEhBwNAIAchCSABIgpBEEYNBSACIApqQQFqIARCCn4iBCAGiKdBMGoiFToAACAJQgp+IQcgCkEBaiEBIAVCCn4iBSAEIAuDIgRYDQALIAUgBH0iHCAIVCEPIAcgFCAXfX4iBiAHfCENIAQgBiAHfSILWg0HIBwgCFoNAgwHCyAKQQpJIQ8gCkEKbiEKIBshASAPRQ0AC0G4rMCAABD6gICAAAALIAIgAWohASAFIAh9IRQgCCALfSEMQgAgBH0hBgNAAkAgBCAIfCIHIAtUDQAgCyAGfCAMIAR8Wg0AQQAhDwwGCyABIBVBf2oiFToAACAUIAZ8IhwgCFQhDyAHIAtaDQYgBiAIfSEGIAchBCAcIAhUDQYMAAsLIAkgB30iCCAKrSAGhiIGVCEBIBQgF30iBUIBfCEdIAcgBUJ/fCILWg0BIAggBlQNASATIAx8IBB9IAQgBnwiBCAcfH1CAnwhFCATIBd9IAd9IQwgBCANfCAOfCASfSARfSAcfCEIQgAhBANAAkAgByAGfCIFIAtUDQAgDCAEfCAIWg0AQQAhAQwDCyAZIBpBf2oiGjoAACAUIAR8IhwgBlQhASAFIAtaDQMgCCAGfCEIIAQgBn0hBCAFIQcgHCAGVA0DDAALC0ERQRFByKzAgAAQjoCAgAAACyAHIQULAkAgHSAFWA0AIAENAAJAIAUgBnwiBCAdVA0AIB0gBX0gBCAdfVQNAQsgAEEANgIADAQLAkACQCAFQgJUDQAgBSAJQnx8WA0BCyAAQQA2AgAMBAsgACAYOwEIIAAgGzYCBAwCCyAEIQcLAkAgDSAHWA0AIA8NAAJAIAcgCHwiBCANVA0AIA0gB30gBCANfVQNAQsgAEEANgIADAILAkACQCAJQhR+IAdWDQAgByAFIAlCWH58WA0BCyAAQQA2AgAMAgsgACAYOwEIIAAgCkECajYCBAsgACACNgIACyADQdAAaiSAgICAAAvYLwMBfwR+Hn8jgICAgABBsAprIgMkgICAgAACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkAgASkDACIEQgBRDQAgASkDCCIFQgBRDQEgASkDECIGQgBRDQIgBiAEfCIHIAZUDQMgBCAFVA0EIAEsABohCCABLgEYIQEgAyAENwMIIANBAUECIARCgICAgBBUGzYCqAEgA0EIakEIakEAQZgB/AsAIAMgBTcDsAEgA0EBQQIgBUKAgICAEFQbNgLQAiADQbABakEIakEAQZgB/AsAIAMgBjcD2AIgA0EBQQIgBkKAgICAEFQbNgL4AyADQdgCakEIakEAQZgB/AsAIANBgARqQQBBnAH8CwAgA0EBNgL8AyADQQE2ApwFIAGsIAdCf3x5fULCmsHoBH5CgKHNoLQCfEIgiKciCcEhCgJAAkAgAUEASA0AIANBCGogARD4gICAABogA0GwAWogARD4gICAABogA0HYAmogARD4gICAABoMAQsgA0H8A2pBACABa8EQ+ICAgAAaCwJAAkAgCkF/Sg0AIANBCGpBACAKa0H//wNxIgEQ/4CAgAAaIANBsAFqIAEQ/4CAgAAaIANB2AJqIAEQ/4CAgAAaDAELIANB/ANqIAlB//8BcRD/gICAABoLIANBjAlqIANBCGpBpAH8CgAAIAMoAvgDIgsgAygCrAoiASALIAFLGyIMQShLDQUCQAJAIAwNAEEAIQwMAQtBACENQQAhDgJAAkACQCAMQQFGDQAgDEEBcSEPIAxBPnEhEEEAIQ0gA0GMCWohASADQdgCaiEJQQAhDgNAIAEgCSgCACIRIAEoAgBqIhIgDUEBcWoiEzYCACABQQRqIg0gCUEEaigCACIUIA0oAgBqIg0gEiARSSATIBJJcmoiEjYCACANIBRJIBIgDUlyIQ0gCUEIaiEJIAFBCGohASAQIA5BAmoiDkcNAAsgD0UNAQsgA0GMCWogDkECdCIBaiIJIANB2AJqIAFqKAIAIhIgCSgCAGoiASANaiIJNgIAIAEgEkkNASAJIAFJDQEMAgsgDUUNAQsgDEEoRg0HIANBjAlqIAxBAnRqQQE2AgAgDEEBaiEMCyADIAw2AqwKIAwgAygCnAUiFSAMIBVLGyIBQSlPDQcgAUECdCEBIANBjAlqQXxqIRICQANAAkAgAQ0AQQAhAQwCCyASIAFqIQkgAUF8aiIBIANB/ANqaigCACINIAkoAgAiCUYNAAsgDSAJSyANIAlJayEBCwJAAkAgASAISA0AAkACQAJAAkACQCADKAKoASINQShLDQACQCANDQBBACENDAULIA1BAnQiEUF8aiIBQQJ2QQFqIglBA3EhDiABQQxPDQFCACEEIANBCGohAQwCC0EAIA1BKEHEnMCAABCWgICAAAALIAlB/P///wdxIQlCACEEIANBCGohAQNAIAEgATUCAEIKfiAEfCIEPgIAIAFBBGoiEiASNQIAQgp+IARCIIh8IgQ+AgAgAUEIaiISIBI1AgBCCn4gBEIgiHwiBD4CACABQQxqIhIgEjUCAEIKfiAEQiCIfCIEPgIAIARCIIghBCABQRBqIQEgCUF8aiIJDQALIA5FDQELIA5BAnQhCQNAIAEgATUCAEIKfiAEfCIEPgIAIAFBBGohASAEQiCIIQQgCUF8aiIJDQALCyAEUA0AIA1BKEYNCyADQQhqIBFqIASnNgIAIA1BAWohDQsgAyANNgKoAQJAAkACQAJAAkAgAygC0AIiDkEoSw0AQQAhFkEAIQEgDkUNBCAOQQJ0IhNBfGoiAUECdkEBaiIJQQNxIREgAUEMTw0BQgAhBCADQbABaiEBDAILQQAgDkEoQcScwIAAEJaAgIAAAAsgCUH8////B3EhCUIAIQQgA0GwAWohAQNAIAEgATUCAEIKfiAEfCIEPgIAIAFBBGoiEiASNQIAQgp+IARCIIh8IgQ+AgAgAUEIaiISIBI1AgBCCn4gBEIgiHwiBD4CACABQQxqIhIgEjUCAEIKfiAEQiCIfCIEPgIAIARCIIghBCABQRBqIQEgCUF8aiIJDQALIBFFDQELIBFBAnQhCQNAIAEgATUCAEIKfiAEfCIEPgIAIAFBBGohASAEQiCIIQQgCUF8aiIJDQALCwJAIARQRQ0AIA4hAQwBCyAOQShGDQwgA0GwAWogE2ogBKc2AgAgDkEBaiEBCyADIAE2AtACAkAgC0UNACALQQJ0IhFBfGoiAUECdkEBaiIJQQNxIQ4CQAJAAkAgAUEMTw0AQgAhBCADQdgCaiEBDAELIAlB/P///wdxIQlCACEEIANB2AJqIQEDQCABIAE1AgBCCn4gBHwiBD4CACABQQRqIhIgEjUCAEIKfiAEQiCIfCIEPgIAIAFBCGoiEiASNQIAQgp+IARCIIh8IgQ+AgAgAUEMaiISIBI1AgBCCn4gBEIgiHwiBD4CACAEQiCIIQQgAUEQaiEBIAlBfGoiCQ0ACyAORQ0BCyAOQQJ0IQkDQCABIAE1AgBCCn4gBHwiBD4CACABQQRqIQEgBEIgiCEEIAlBfGoiCQ0ACwsCQCAEUEUNACADIAsiFjYC+AMMAwsgC0EoRg0NIANB2AJqIBFqIASnNgIAIAtBAWohFgsgAyAWNgL4AwwBCyAKQQFqIQogAygCqAEhDSALIRYLIANBoAVqIANB/ANqQaQB/AoAACADQaAFakEBEPiAgIAAIRcgA0HEBmogA0H8A2pBpAH8CgAAIANBxAZqQQIQ+ICAgAAhGCADQegHaiADQfwDakGkAfwKAAACQAJAAkAgA0HoB2pBAxD4gICAACIZKAKgASIaIA0gGiANSxsiG0EoSw0AIANB/ANqQXxqIQ8gA0GMCWpBfGohHCADQaAFakF8aiELIANBxAZqQXxqIQwgA0HoB2pBfGohECAXKAKgASEdIBgoAqABIR5BACEfA0AgHyEgIBtBAnQhAQJAAkADQCABRQ0BIBAgAWohCSABQXxqIgEgA0EIamooAgAiEiAJKAIAIglGDQALQQAhISASIAlJDQELAkAgG0UNAEEBIQ1BACEOAkACQCAbQQFGDQAgG0EBcSEiIBtBPnEhI0EAIQ5BASENIANBCGohASADQegHaiEJA0AgASABKAIAIhEgCSgCAEF/c2oiEiANQQFxaiITNgIAIAFBBGoiDSANKAIAIhQgCUEEaigCAEF/c2oiDSASIBFJIBMgEklyaiISNgIAIA0gFEkgEiANSXIhDSAJQQhqIQkgAUEIaiEBICMgDkECaiIORw0ACyAiRQ0BCyADQQhqIA5BAnQiAWoiCSAJKAIAIgkgGSABaigCAEF/c2oiASANaiISNgIAIAEgCUkNASASIAFJDQEMJAsgDUUNIwsgAyAbNgKoAUEIISEgGyENCyAeIA0gHiANSxsiG0EpTw0PIBtBAnQhAQJAAkADQCABRQ0BIAwgAWohCSABQXxqIgEgA0EIamooAgAiEiAJKAIAIglGDQALIBIgCU8NACANIRsMAQsCQCAbRQ0AQQEhDUEAIQ4CQAJAIBtBAUYNACAbQQFxISIgG0E+cSEjQQAhDkEBIQ0gA0EIaiEBIANBxAZqIQkDQCABIAEoAgAiESAJKAIAQX9zaiISIA1BAXFqIhM2AgAgAUEEaiINIA0oAgAiFCAJQQRqKAIAQX9zaiINIBIgEUkgEyASSXJqIhI2AgAgDSAUSSASIA1JciENIAlBCGohCSABQQhqIQEgIyAOQQJqIg5HDQALICJFDQELIANBCGogDkECdCIBaiIJIAkoAgAiCSAYIAFqKAIAQX9zaiIBIA1qIhI2AgAgASAJSQ0BIBIgAUkNAQwjCyANRQ0iCyADIBs2AqgBICFBBHIhIQsgHSAbIB0gG0sbIiJBKU8NECAiQQJ0IQECQAJAA0AgAUUNASALIAFqIQkgAUF8aiIBIANBCGpqKAIAIhIgCSgCACIJRg0ACyASIAlPDQAgGyEiDAELAkAgIkUNAEEBIQ1BACEOAkACQCAiQQFGDQAgIkEBcSEbICJBPnEhI0EAIQ5BASENIANBCGohASADQaAFaiEJA0AgASABKAIAIhEgCSgCAEF/c2oiEiANQQFxaiITNgIAIAFBBGoiDSANKAIAIhQgCUEEaigCAEF/c2oiDSASIBFJIBMgEklyaiISNgIAIA0gFEkgEiANSXIhDSAJQQhqIQkgAUEIaiEBICMgDkECaiIORw0ACyAbRQ0BCyADQQhqIA5BAnQiAWoiCSAJKAIAIgkgFyABaigCAEF/c2oiASANaiISNgIAIAEgCUkNASASIAFJDQEMIgsgDUUNIQsgAyAiNgKoASAhQQJqISELIBUgIiAVICJLGyIbQSlPDREgG0ECdCEBAkACQANAIAFFDQEgAUF8aiIBIANBCGpqKAIAIgkgASADQfwDamooAgAiEkYNAAsgCSASTw0AICIhGwwBCwJAIBtFDQBBASENQQAhDgJAAkAgG0EBRg0AIBtBAXEhIiAbQT5xISNBACEOQQEhDSADQQhqIQEgA0H8A2ohCQNAIAEgASgCACIRIAkoAgBBf3NqIhIgDUEBcWoiEzYCACABQQRqIg0gDSgCACIUIAlBBGooAgBBf3NqIg0gEiARSSATIBJJcmoiEjYCACANIBRJIBIgDUlyIQ0gCUEIaiEJIAFBCGohASAjIA5BAmoiDkcNAAsgIkUNAQsgA0EIaiAOQQJ0IgFqIgkgCSgCACIJIANB/ANqIAFqKAIAQX9zaiIBIA1qIhI2AgAgASAJSQ0BIBIgAUkNAQwhCyANRQ0gCyADIBs2AqgBICFBAWohIQsgIEERRg0WIAIgIGogIUEwajoAACADKALQAiIhIBsgISAbSxsiAUEpTw0SICBBAWohHyABQQJ0IQECQANAAkAgAQ0AQQAhJAwCCyABQXxqIgEgA0EIamooAgAiCSABIANBsAFqaigCACISRg0ACyAJIBJLIAkgEklrISQLIANBjAlqIANBCGpBpAH8CgAAIBYgAygCrAoiASAWIAFLGyIiQShLDRMCQAJAICINAEEAISIMAQtBACENQQAhDgJAAkACQCAiQQFGDQAgIkEBcSElICJBPnEhI0EAIQ0gA0GMCWohASADQdgCaiEJQQAhDgNAIAEgCSgCACIRIAEoAgBqIhIgDUEBcWoiEzYCACABQQRqIg0gCUEEaigCACIUIA0oAgBqIg0gEiARSSATIBJJcmoiEjYCACANIBRJIBIgDUlyIQ0gCUEIaiEJIAFBCGohASAjIA5BAmoiDkcNAAsgJUUNAQsgA0GMCWogDkECdCIBaiIJIANB2AJqIAFqKAIAIhIgCSgCAGoiASANaiIJNgIAIAEgEkkNASAJIAFJDQEMAgsgDUUNAQsgIkEoRg0VIANBjAlqICJBAnRqQQE2AgAgIkEBaiEiCyADICI2AqwKICIgFSAiIBVLGyIBQSlPDRUgAUECdCEBAkADQAJAIAENAEEAIQEMAgsgHCABaiEJIA8gAWohEiABQXxqIQEgEigCACISIAkoAgAiCUYNAAsgEiAJSyASIAlJayEBCyAkIAhIDQIgASAISA0DQQAhDkEAIQ0CQCAbRQ0AIBtBAnQiEUF8aiIBQQJ2QQFqIglBA3EhDQJAAkACQCABQQxPDQBCACEEIANBCGohAQwBCyAJQfz///8HcSEJQgAhBCADQQhqIQEDQCABIAE1AgBCCn4gBHwiBD4CACABQQRqIhIgEjUCAEIKfiAEQiCIfCIEPgIAIAFBCGoiEiASNQIAQgp+IARCIIh8IgQ+AgAgAUEMaiISIBI1AgBCCn4gBEIgiHwiBD4CACAEQiCIIQQgAUEQaiEBIAlBfGoiCQ0ACyANRQ0BCyANQQJ0IQkDQCABIAE1AgBCCn4gBHwiBD4CACABQQRqIQEgBEIgiCEEIAlBfGoiCQ0ACwsCQCAEUEUNACAbIQ0MAQsgG0EoRg0YIANBCGogEWogBKc2AgAgG0EBaiENCyADIA02AqgBAkAgIUUNACAhQQJ0IhFBfGoiAUECdkEBaiIJQQNxIQ4CQAJAAkAgAUEMTw0AQgAhBCADQbABaiEBDAELIAlB/P///wdxIQlCACEEIANBsAFqIQEDQCABIAE1AgBCCn4gBHwiBD4CACABQQRqIhIgEjUCAEIKfiAEQiCIfCIEPgIAIAFBCGoiEiASNQIAQgp+IARCIIh8IgQ+AgAgAUEMaiISIBI1AgBCCn4gBEIgiHwiBD4CACAEQiCIIQQgAUEQaiEBIAlBfGoiCQ0ACyAORQ0BCyAOQQJ0IQkDQCABIAE1AgBCCn4gBHwiBD4CACABQQRqIQEgBEIgiCEEIAlBfGoiCQ0ACwsCQCAEUEUNACAhIQ4MAQsgIUEoRg0ZIANBsAFqIBFqIASnNgIAICFBAWohDgsgAyAONgLQAgJAAkAgFg0AQQAhFgwBCyAWQQJ0IhFBfGoiAUECdkEBaiIJQQNxIQ4CQAJAAkAgAUEMTw0AQgAhBCADQdgCaiEBDAELIAlB/P///wdxIQlCACEEIANB2AJqIQEDQCABIAE1AgBCCn4gBHwiBD4CACABQQRqIhIgEjUCAEIKfiAEQiCIfCIEPgIAIAFBCGoiEiASNQIAQgp+IARCIIh8IgQ+AgAgAUEMaiISIBI1AgBCCn4gBEIgiHwiBD4CACAEQiCIIQQgAUEQaiEBIAlBfGoiCQ0ACyAORQ0BCyAOQQJ0IQkDQCABIAE1AgBCCn4gBHwiBD4CACABQQRqIQEgBEIgiCEEIAlBfGoiCQ0ACwsgBFANACAWQShGDRogA0HYAmogEWogBKc2AgAgFkEBaiEWCyADIBY2AvgDIBogDSAaIA1LGyIbQSlJDQALC0EAIBtBKEHEnMCAABCWgICAAAALIAEgCE4NGSADQQhqQQEQ+ICAgAAaIBUgAygCqAEiASAVIAFLGyIBQSlPDRcgAUECdCEBIANBCGpBfGohDSADQfwDakF8aiEOA0AgAUUNASAOIAFqIQkgDSABaiESIAFBfGohASASKAIAIhIgCSgCACIJRg0ACyASIAlJDRkLIAIgH2ohDSAfIQECQANAIAEiCUUNASAJQX9qIgEgAmoiEi0AAEE5Rg0ACyASIBItAABBAWo6AAAgHyAJayIBRQ0ZIAIgCWpBMCAB/AsADBkLIAJBMToAAAJAICBFDQAgAkEBakEwICD8CwALICBBD0sNFyANQTA6AAAgCkEBaiEKICBBAmohHwwZC0GwqsCAAEEcQYivwIAAEIKAgIAAAAtBnKvAgABBHUGYr8CAABCCgICAAAALQcyrwIAAQRxBqK/AgAAQgoCAgAAAC0GgrcCAAEE2QfivwIAAEIKAgIAAAAtB2KzAgABBN0Hor8CAABCCgICAAAALQQAgDEEoQcScwIAAEJaAgIAAAAtBKEEoQcScwIAAEI6AgIAAAAtBACABQShBxJzAgAAQloCAgAAAC0EoQShBxJzAgAAQjoCAgAAAC0EoQShBxJzAgAAQjoCAgAAAC0EoQShBxJzAgAAQjoCAgAAAC0EAIBtBKEHEnMCAABCWgICAAAALQQAgIkEoQcScwIAAEJaAgIAAAAtBACAbQShBxJzAgAAQloCAgAAAC0EAIAFBKEHEnMCAABCWgICAAAALQQAgIkEoQcScwIAAEJaAgIAAAAtBKEEoQcScwIAAEI6AgIAAAAtBACABQShBxJzAgAAQloCAgAAAC0ERQRFBuK/AgAAQjoCAgAAAC0EoQShBxJzAgAAQjoCAgAAAC0EoQShBxJzAgAAQjoCAgAAAC0EoQShBxJzAgAAQjoCAgAAAC0EAIAFBKEHEnMCAABCWgICAAAALIB9BEUHIr8CAABCOgICAAAALICBBEE0NAEEAIB9BEUHYr8CAABCWgICAAAALIAAgCjsBCCAAIB82AgQgACACNgIAIANBsApqJICAgIAADwtBp5zAgABBGkHEnMCAABCCgICAAAALQaecwIAAQRpBxJzAgAAQgoCAgAAAC0GnnMCAAEEaQcScwIAAEIKAgIAAAAtBp5zAgABBGkHEnMCAABCCgICAAAALmgUDBX8BfgJ/I4CAgIAAQRBrIgIkgICAgAACQAJAIAAvAQwiAw0AIAAoAgAgACgCBCABEIOBgIAAIQQMAQsgAiABKAIMIgU2AgwgAiABKAIIIgQ2AgggAiABKAIEIgY2AgQgAiABKAIAIgE2AgACQAJAIAApAggiB6ciCEGAgIAIcUUNACAAKAIAIAEgBiAAKAIEKAIMEYKAgIAAgICAgAANASAAIAhBgICA/3lxQbCAgIACciIINgIIIAJCATcCACAGQf//A3EhAUEAIQZBACADIAFrIgEgASADSxshAwsCQCAFRQ0AA0ACQAJAAkACQAJAIAQvAQAOAwABAgALIARBBGooAgAhAQwDCyAEQQJqLwEAIgENAUEBIQEMAgsgBEEIaigCACEBDAELIAFB9v8XaiABQZz/H2pxIAFBmPg3aiABQfCxH2pxc0ERdkEBaiEBC0F/IAYgAWoiASABIAZJGyEGIARBDGohBCAFQX9qIgUNAAsLAkACQCAGIANB//8DcUkNACAAKAIAIAAoAgQgAhCDgYCAACEEDAELIAMgBmshCUEAIQRBACEDAkACQAJAIAhBHXZBA3EOBAIAAQACCyAJIQMMAQsgCUH+/wNxQQF2IQMLIAhB////AHEhASAAKAIEIQYgACgCACEFAkADQCAEQf//A3EgA0H//wNxTw0BIARBAWohBCAFIAEgBigCEBGBgICAAICAgIAARQ0ADAMLCyAFIAYgAhCDgYCAAA0BIAkgA2tB//8DcSEIQQAhAwNAAkAgA0H//wNxIAhJDQBBACEEDAILQQEhBCADQQFqIQMgBSABIAYoAhARgYCAgACAgICAAEUNAAsLIAAgBzcCCAwBC0EBIQQLIAJBEGokgICAgAAgBAvCBAEHfyOAgICAAEEQayIDJICAgIAAAkACQCACKAIEIgRFDQAgACACKAIAIAQgASgCDBGCgICAAICAgIAARQ0AQQEhAgwBCwJAIAIoAgwiBUUNACACKAIIIgQgBUEMbGohBgNAAkACQAJAAkAgBC8BAA4DAAIBAAsCQAJAIAQoAgQiAkHBAEkNACABQQxqKAIAIQUDQAJAIABB8ZzAgABBwAAgBRGCgICAAICAgIAARQ0AQQEhAgwJCyACQUBqIgJBwABLDQAMAgsLIAJFDQMgAUEMaigCACEFCyAAQfGcwIAAIAIgBRGCgICAAICAgIAARQ0CQQEhAgwFCyAAIAQoAgQgBCgCCCABQQxqKAIAEYKAgIAAgICAgABFDQFBASECDAQLIAQvAQIhAiADQQA6AAwgA0EANgIIAkACQCACDQAgAyACQTByOgAIQQEhBQwBCyADQQhqIAJB9v8XaiACQZz/H2pxIAJBmPg3aiACQfCxH2pxc0ERdiIHaiIIIAIgAkEKbiIJQQpsa0EwcjoAACAHQQFqIQUgB0UNACAIQX9qIAlBCnBBMHI6AAAgBUECRg0AIAhBfmogAkHkAG5BCnBBMHI6AAAgBUEDRg0AIAhBfWogAkHoB25BCnBBMHI6AAAgBUEERg0AIAhBfGogAkGQzgBuQTByOgAACyAAIANBCGogBSABQQxqKAIAEYKAgIAAgICAgABFDQBBASECDAMLIARBDGoiBCAGRw0ACwtBACECCyADQRBqJICAgIAAIAIL2AUEBX8CfgJ/AX4jgICAgABBgAFrIgMkgICAgAAgAbwiBEH///8DcSIFQYCAgARyIARBAXRB/v//B3EgBEEXdkH/AXEiBhsiB60iCEIBgyEJQQIhCgJAAkACQAJAAkAgBUVBBEEDQQIgBRsgBEGAgID8B3EiBRsgBUGAgID8B0YbDgUEAAECAwQLQQMhCgwDC0EEIQoMAgsgBkHqfmohCyAJp0EBcyEKQgEhDAwBC0KAgIAQIAhCAYYgB0GAgIAERiIFGyEIQgJCASAFGyEMIAmnQQFzIQpB6H5B6X4gBRsgBmohCwsgAyALOwF4IAMgDDcDcCADQgE3A2ggAyAINwNgIAMgCjoAegJAAkACQAJAAkACQCAKQf8BcUEBSw0AQbibwIAAQQEgBEEASCIKGyEFQbibwIAAQbmbwIAAIAobIQogBEEfdiEEIANBIGogA0HgAGogA0EPahCAgYCAACADKAIgRQ0BIAMgAygCKDYCWCADIAMpAiA3A1AMAgsgCkF+akH/AXEiC0UNAkEBIQpBuJvAgABBuZvAgAAgBEEASCIFG0G4m8CAAEEBIAUbIAIbIQVBASAEQR92IAIbIQQgA0ECOwEgIAtBAkYNAyADQQM2AiggA0G9m8CAADYCJCADQSBqIQsMBAsgA0HQAGogA0HgAGogA0EPahCBgYCAAAsgCiAFIAIbIQVBASAEIAIbIQQgAyADKAJQIAMoAlQgAy8BWEEBIANBIGoQ+4CAgAAgAygCBCEKIAMoAgAhCwwCCyADQQM2AiggA0G6m8CAADYCJCADQQI7ASBBASEFIANBIGohC0EAIQRBASEKDAELIANBATYCMCADQQA7ASwgA0ECNgIoIANBwZvAgAA2AiQgA0EgaiELQQIhCgsgAyAKNgJcIAMgCzYCWCADIAQ2AlQgAyAFNgJQIAAgA0HQAGoQgoGAgAAhBCADQYABaiSAgICAACAEC5wHBQV/An4CfwF+AX8jgICAgABBoAFrIgMkgICAgAAgAbwiBEH///8DcSIFQYCAgARyIARBAXRB/v//B3EgBEEXdkH/AXEiBhsiB60iCEIBgyEJQQIhCgJAAkACQAJAAkAgBUVBBEEDQQIgBRsgBEGAgID8B3EiBRsgBUGAgID8B0YbDgUEAAECAwQLQQMhCgwDC0EEIQoMAgsgBkHqfmohCyAJp0EBcyEKQgEhDAwBC0KAgIAQIAhCAYYgB0GAgIAERiIFGyEIQgJCASAFGyEMIAmnQQFzIQpB6H5B6X4gBRsgBmohCwsgAyALOwGIASADIAw3A4ABIANCATcDeCADIAg3A3AgAyAKOgCKAQJAAkACQAJAAkACQAJAAkACQCAKQf8BcUEBSw0AIANB4ABqIANB8ABqIANBB2oQgIGAgAAgAygCYEUNASADIAMoAmg2ApgBIAMgAykCYDcDkAEMAgsgCkF+akH/AXEiBkUNAkEBIQpBuJvAgABBuZvAgAAgBEEASCIFG0G4m8CAAEEBIAUbIAIbIQVBASAEQR92IAIbIQsgA0ECOwEYIAZBAkYNAyADQQM2AiAgA0G9m8CAADYCHAwHCyADQZABaiADQfAAaiADQQdqEIGBgIAACyADKAKUASIFRQ0CIAMoApABIgotAABBME0NA0G4m8CAAEEBIARBAEgiCxshB0G4m8CAAEG5m8CAACALGyELIARBH3YhDSADLgGYASEGIANBATYCICADIAo2AhwgA0ECOwEYAkAgBUF/aiIFDQAgA0EkaiEEQQMhCgwFCyADQTxqIQQgAyAFNgI4IANBAjsBMCADQfuewIAANgIoIANBAjsBJCADQQE2AiwgAyAKQQFqNgI0QQUhCgwECyADQQM2AiAgA0G6m8CAADYCHCADQQI7ARhBASEFQQAhC0EBIQoMBAsgA0EDNgIgIANBw5vAgAA2AhwMAwtBlZ/AgABBIUH4n8CAABCCgICAAAALQcifwIAAQR9BiKDAgAAQgoCAgAAACyALIAcgAhshBUEBIA0gAhshCyAEQQE7AQwgBEECOwEAIARBAkEBIAZBAUgiAhs2AgggBEGZoMCAAEGYoMCAACACGzYCBCAEIAZBf2oiAiACQR91IgJzIAJrOwEOCyADIAo2AmwgAyALNgJkIAMgBTYCYCADIANBGGo2AmggACADQeAAahCCgYCAACEEIANBoAFqJICAgIAAIAQLhAgFBX8CfgJ/AX4BfyOAgICAAEHwCGsiBCSAgICAACABvCIFQf///wNxIgZBgICABHIgBUEBdEH+//8HcSAFQRd2Qf8BcSIHGyIIrSIJQgGDIQpBAiELAkACQAJAAkACQCAGRUEEQQNBAiAGGyAFQYCAgPwHcSIGGyAGQYCAgPwHRhsOBQQAAQIDBAtBAyELDAMLQQQhCwwCCyAHQep+aiEMIAqnQQFzIQtCASENDAELQoCAgBAgCUIBhiAIQYCAgARGIgwbIQlCAkIBIAwbIQ0gCqdBAXMhC0HofkHpfiAMGyAHaiEMCyADQf//A3EhBiAEIAw7AegIIAQgDTcD4AggBEIBNwPYCCAEIAk3A9AIIAQgCzoA6ggCQAJAAkAgC0H/AXFBAUsNAEF0QQUgDMEiC0EASBsgC2wiC0HA/QBJDQFBxpvAgABBJUHsm8CAABCCgICAAAALAkACQAJAIAtBfmpB/wFxIgdFDQBBASELQbibwIAAQbmbwIAAIAVBAEgiDBtBuJvAgABBASAMGyACGyEMQQEgBUEfdiACGyEFIAdBAkcNASAEQQI7AZAIIANB//8DcQ0CQQEhCyAEQQE2ApgIIARBwJvAgAA2ApQIIARBkAhqIQMMBAsgBEEDNgKYCCAEQbqbwIAANgKUCCAEQQI7AZAIQQEhDCAEQZAIaiEDQQAhBUEBIQsMAwsgBEEDNgKYCCAEQb2bwIAANgKUCCAEQQI7AZAIIARBkAhqIQMMAgsgBCAGNgKgCCAEQQA7AZwIQQIhCyAEQQI2ApgIIARBwZvAgAA2ApQIIARBkAhqIQMMAQtBuJvAgABBASAFQQBIIgcbIQhBuJvAgABBuZvAgAAgBxshByAFQR92IQUgBEGQCGogCSAMIARBEGogC0EEdkEVaiIOQQAgA2tBgIB+IAPBQX9KGyILEPyAgIAAIAvBIQsCQAJAIAQoApAIRQ0AIAQgBCgCmAg2AsgIIAQgBCkCkAg3A8AIDAELIARBwAhqIARB0AhqIARBEGogDiALEP6AgIAACyAHIAggAhshDEEBIAUgAhshBQJAIAQuAcgIIgIgC0wNACAEQQhqIAQoAsAIIAQoAsQIIAIgBiAEQZAIahD7gICAACAEKAIMIQsgBCgCCCEDDAELQQIhCyAEQQI7AZAIAkAgA0H//wNxDQBBASELIARBATYCmAggBEHAm8CAADYClAggBEGQCGohAwwBCyAEIAY2AqAIIARBADsBnAggBEECNgKYCCAEQcGbwIAANgKUCCAEQZAIaiEDCyAEIAs2AswIIAQgAzYCyAggBCAFNgLECCAEIAw2AsAIIAAgBEHACGoQgoGAgAAhBSAEQfAIaiSAgICAACAFC4EGBgF/An4BfwJ+A38BfiOAgICAAEGAAWsiAySAgICAACABvSIEQv////////8HgyIFQoCAgICAgIAIhCAEQgGGQv7///////8PgyAEQjSIp0H/D3EiBhsiB0IBgyEIQQIhCQJAAkACQAJAAkAgBVAiCkECQQMgChtBBCAEQoCAgICAgID4/wCDIgVQGyAFQoCAgICAgID4/wBRGw4FBAABAgMEC0EDIQkMAwtBBCEJDAILIAZBzXdqIQsgCKdBAXMhCUIBIQwMAQtCgICAgICAgCAgB0IBhiAHQoCAgICAgIAIUSILGyEHQgJCASALGyEMIAinQQFzIQlBy3dBzHcgCxsgBmohCwsgAyALOwF4IAMgDDcDcCADQgE3A2ggAyAHNwNgIAMgCToAegJAAkACQAJAAkACQCAJQf8BcUEBSw0AQbibwIAAQQEgBEIAUyIJGyELQbibwIAAQbmbwIAAIAkbIQkgBEI/iKchCiADQSBqIANB4ABqIANBD2oQgIGAgAAgAygCIEUNASADIAMoAig2AlggAyADKQIgNwNQDAILIAlBfmoiCkH/AXFFDQJBASEJQbibwIAAQbmbwIAAIARCAFMiCxtBuJvAgABBASALGyACGyELQQEgBEI/iKcgAhshAiADQQI7ASAgCkH/AXFBAkYNAyADQQM2AiggA0G9m8CAADYCJCADQSBqIQoMBAsgA0HQAGogA0HgAGogA0EPahCBgYCAAAsgCSALIAIbIQtBASAKIAIbIQIgAyADKAJQIAMoAlQgAy8BWEEBIANBIGoQ+4CAgAAgAygCBCEJIAMoAgAhCgwCCyADQQM2AiggA0G6m8CAADYCJCADQQI7ASBBASELIANBIGohCkEAIQJBASEJDAELIANBATYCMCADQQA7ASwgA0ECNgIoIANBwZvAgAA2AiQgA0EgaiEKQQIhCQsgAyAJNgJcIAMgCjYCWCADIAI2AlQgAyALNgJQIAAgA0HQAGoQgoGAgAAhCSADQYABaiSAgICAACAJC8UHBwF/An4BfwJ+A38BfgN/I4CAgIAAQaABayIDJICAgIAAIAG9IgRC/////////weDIgVCgICAgICAgAiEIARCAYZC/v///////w+DIARCNIinQf8PcSIGGyIHQgGDIQhBAiEJAkACQAJAAkACQCAFUCIKQQJBAyAKG0EEIARCgICAgICAgPj/AIMiBVAbIAVCgICAgICAgPj/AFEbDgUEAAECAwQLQQMhCQwDC0EEIQkMAgsgBkHNd2ohCyAIp0EBcyEJQgEhDAwBC0KAgICAgICAICAHQgGGIAdCgICAgICAgAhRIgsbIQdCAkIBIAsbIQwgCKdBAXMhCUHLd0HMdyALGyAGaiELCyADIAs7AYgBIAMgDDcDgAEgA0IBNwN4IAMgBzcDcCADIAk6AIoBAkACQAJAAkACQAJAAkACQAJAIAlB/wFxQQFLDQAgA0HgAGogA0HwAGogA0EHahCAgYCAACADKAJgRQ0BIAMgAygCaDYCmAEgAyADKQJgNwOQAQwCCyAJQX5qIglB/wFxRQ0CQQEhC0G4m8CAAEG5m8CAACAEQgBTIgobQbibwIAAQQEgChsgAhshCkEBIARCP4inIAIbIQIgA0ECOwEYIAlB/wFxQQJGDQMgA0EDNgIgIANBvZvAgAA2AhwMBwsgA0GQAWogA0HwAGogA0EHahCBgYCAAAsgAygClAEiCUUNAiADKAKQASILLQAAQTBNDQNBuJvAgABBASAEQgBTIgobIQ1BuJvAgABBuZvAgAAgChshCiAEQj+IpyEOIAMuAZgBIQYgA0EBNgIgIAMgCzYCHCADQQI7ARgCQCAJQX9qIg8NACADQSRqIQlBAyELDAULIANBPGohCSADIA82AjggA0ECOwEwIANB+57AgAA2AiggA0ECOwEkIANBATYCLCADIAtBAWo2AjRBBSELDAQLIANBAzYCICADQbqbwIAANgIcIANBAjsBGEEBIQpBACECQQEhCwwECyADQQM2AiAgA0HDm8CAADYCHAwDC0GVn8CAAEEhQfifwIAAEIKAgIAAAAtByJ/AgABBH0GIoMCAABCCgICAAAALIAogDSACGyEKQQEgDiACGyECIAlBATsBDCAJQQI7AQAgCUECQQEgBkEBSCINGzYCCCAJQZmgwIAAQZigwIAAIA0bNgIEIAkgBkF/aiIGIAZBH3UiBnMgBms7AQ4LIAMgCzYCbCADIAI2AmQgAyAKNgJgIAMgA0EYajYCaCAAIANB4ABqEIKBgIAAIQkgA0GgAWokgICAgAAgCQutCAcBfwJ+AX8CfgN/AX4DfyOAgICAAEHwCGsiBCSAgICAACABvSIFQv////////8HgyIGQoCAgICAgIAIhCAFQgGGQv7///////8PgyAFQjSIp0H/D3EiBxsiCEIBgyEJQQIhCgJAAkACQAJAAkAgBlAiC0ECQQMgCxtBBCAFQoCAgICAgID4/wCDIgZQGyAGQoCAgICAgID4/wBRGw4FBAABAgMEC0EDIQoMAwtBBCEKDAILIAdBzXdqIQwgCadBAXMhCkIBIQ0MAQtCgICAgICAgCAgCEIBhiAIQoCAgICAgIAIUSIMGyEIQgJCASAMGyENIAmnQQFzIQpBy3dBzHcgDBsgB2ohDAsgA0H//wNxIQsgBCAMOwHoCCAEIA03A+AIIARCATcD2AggBCAINwPQCCAEIAo6AOoIAkACQAJAIApB/wFxQQFLDQBBdEEFIAzBIgpBAEgbIApsIgpBwP0ASQ0BQcabwIAAQSVB7JvAgAAQgoCAgAAACwJAAkACQCAKQX5qIgdB/wFxRQ0AQQEhCkG4m8CAAEG5m8CAACAFQgBTIgwbQbibwIAAQQEgDBsgAhshDEEBIAVCP4inIAIbIQIgB0H/AXFBAkcNASAEQQI7AZAIIANB//8DcQ0CQQEhCiAEQQE2ApgIIARBwJvAgAA2ApQIIARBkAhqIQMMBAsgBEEDNgKYCCAEQbqbwIAANgKUCCAEQQI7AZAIQQEhDCAEQZAIaiEDQQAhAkEBIQoMAwsgBEEDNgKYCCAEQb2bwIAANgKUCCAEQQI7AZAIIARBkAhqIQMMAgsgBCALNgKgCCAEQQA7AZwIQQIhCiAEQQI2ApgIIARBwZvAgAA2ApQIIARBkAhqIQMMAQtBuJvAgABBASAFQgBTIgcbIQ5BuJvAgABBuZvAgAAgBxshByAFQj+IpyEPIARBkAhqIAggDCAEQRBqIApBBHZBFWoiEEEAIANrQYCAfiADwUF/ShsiChD8gICAACAKwSEKAkACQCAEKAKQCEUNACAEIAQoApgINgLICCAEIAQpApAINwPACAwBCyAEQcAIaiAEQdAIaiAEQRBqIBAgChD+gICAAAsgByAOIAIbIQxBASAPIAIbIQICQCAELgHICCIHIApMDQAgBEEIaiAEKALACCAEKALECCAHIAsgBEGQCGoQ+4CAgAAgBCgCDCEKIAQoAgghAwwBC0ECIQogBEECOwGQCAJAIANB//8DcQ0AQQEhCiAEQQE2ApgIIARBwJvAgAA2ApQIIARBkAhqIQMMAQsgBCALNgKgCCAEQQA7AZwIIARBAjYCmAggBEHBm8CAADYClAggBEGQCGohAwsgBCAKNgLMCCAEIAM2AsgIIAQgAjYCxAggBCAMNgLACCAAIARBwAhqEIKBgIAAIQogBEHwCGokgICAgAAgCgvJAQECfyOAgICAAEEQayIEJICAgIAAQQBBACgC1N3AgAAiBUEBajYC1N3AgAACQCAFQQBIDQACQAJAQQAtAMzdwIAADQBBAEEBOgDM3cCAAEEAQQAoAsjdwIAAQQFqNgLI3cCAAEEAKALQ3cCAACIFQX9MDQIgBUEBaiIBIAVODQEQ+YCAgAAACyAEQQhqIAAgASgCGBGFgICAAICAgIAADAELQQAgAUF/ajYC0N3AgABBAEEAOgDM3cCAACACRQ0AEIuBgIAAAAsACwMAAAsJACAAQQA2AgALHgAgAEEAKQLossCAADcCCCAAQQApAuCywIAANwIACw4AQQBBAToA2N3AgAAACwsAIAAQkIGAgAAAC4wBAQN/I4CAgIAAQRBrIgEkgICAgAACQCAAKAIAIgIoAgQiA0EBcUUNACACKAIAIQIgASADQQF2NgIEIAEgAjYCACABQaiywIAAIAAoAggiAC0ACCAALQAJEIqBgIAAAAsgAUF/NgIAIAEgADYCDCABQcSywIAAIAAoAggiAC0ACCAALQAJEIqBgIAAAAuEAQEDfwJAAkACQCAAKAIAIgFBAUgNACAAKAIEIgJBfGooAgAiAEF4cSIDQQRBCCAAQQNxIgAbIAFqSQ0BAkAgAEUNACADIAFBJ2pLDQMLIAIQgYCAgAALDwtBgLPAgABBLkGws8CAABCCgICAAAALQcCzwIAAQS5B8LPAgAAQgoCAgAAAC1QAAkAgACgCAEF/Rg0AIAEoAgAgACgCBCAAKAIIIAEoAgQoAgwRgoCAgACAgICAAA8LIAEoAgAgASgCBCAAKAIMKAIAIgAoAgAgACgCBBDzgICAAAv9AQICfwF+I4CAgIAAQSBrIgIkgICAgAACQCABKAIAQX9HDQAgASgCDCEDIAJBADYCGCACQoCAgIAQNwIQIAJBEGpBkLLAgAAgAygCACIDKAIAIAMoAgQQ84CAgAAaIAIgAigCGCIDNgIIIAIgAikCECIENwMAIAEgAzYCCCABIAQ3AgALIAEoAgghAyABQQA2AgggASkCACEEIAFCgICAgBA3AgAgAiADNgIYIAIgBDcDEAJAQQwQkoCAgAAiAQ0AQQRBDBCagICAAAALIAEgAigCGDYCCCABIAIpAxA3AgAgAEHMtMCAADYCBCAAIAE2AgAgAkEgaiSAgICAAAuhAQICfwF+I4CAgIAAQSBrIgIkgICAgAACQCABKAIAQX9HDQAgASgCDCEDIAJBADYCHCACQoCAgIAQNwIUIAJBFGpBkLLAgAAgAygCACIDKAIAIAMoAgQQ84CAgAAaIAIgAigCHCIDNgIQIAIgAikCFCIENwMIIAEgAzYCCCABIAQ3AgALIABBzLTAgAA2AgQgACABNgIAIAJBIGokgICAgAALnwEBAX8jgICAgABBEGsiAySAgICAAAJAIAIgAWoiASACTw0AQQBBABCTgICAAAALIANBBGogACgCACICIAAoAgQgASACQQF0IgIgASACSxsiAkEIIAJBCEsbIgIQloGAgAACQCADKAIEQQFHDQAgAygCCCADKAIMEJOAgIAAAAsgAygCCCEBIAAgAjYCACAAIAE2AgQgA0EQaiSAgICAAAuBAQEBf0EAIQQCQAJAIANBAE4NAEEBIQFBBCECDAELAkACQCABRQ0AIAIgAUEBIAMQoICAgAAhBAwBCyADEJKAgIAAIQQLAkACQCAEDQBBASEBIABBATYCBAwBCyAAIAQ2AgRBACEBC0EIIQIgAyEECyAAIAJqIAQ2AgAgACABNgIAC4IBAQN/AkACQAJAIAAoAgAiAUUNACAAKAIEIgJBfGooAgAiAEF4cSIDQQRBCCAAQQNxIgAbIAFqSQ0BAkAgAEUNACADIAFBJ2pLDQMLIAIQgYCAgAALDwtBgLPAgABBLkGws8CAABCCgICAAAALQcCzwIAAQS5B8LPAgAAQgoCAgAAACx4AIABBACkC+LLAgAA3AgggAEEAKQLwssCAADcCAAtaAQF/AkACQAJAIAIgACgCACAAKAIIIgNrTQ0AIAAgAyACEJWBgIAAIAAoAgghAwwBCyACRQ0BCyACRQ0AIAAoAgQgA2ogASAC/AoAAAsgACADIAJqNgIIQQALmgIBBn8gACgCCCECAkACQCABQYABTw0AQQEhAwwBCwJAIAFBgBBPDQBBAiEDDAELQQNBBCABQYCABEkbIQMLAkAgAyAAKAIAIAJrTQ0AIAAgAiADEJWBgIAACyAAKAIEIAJqIQQCQAJAIAFBgAFJDQAgAUE/cUGAf3IhBSABQQZ2IQYCQCABQYAQTw0AIAQgBToAASAEIAZBwAFyOgAADAILIAFBDHYhByAGQT9xQYB/ciEGAkAgAUH//wNLDQAgBCAFOgACIAQgBjoAASAEIAdB4AFyOgAADAILIAQgBToAAyAEIAY6AAIgBCAHQT9xQYB/cjoAASAEIAFBEnZBcHI6AAAMAQsgBCABOgAACyAAIAMgAmo2AghBAAsUACAAQZCywIAAIAEgAhDzgICAAAskACABKAIAIAAoAgAgACgCBCABKAIEKAIMEYKAgIAAgICAgAALTAECfyABKAIEIQIgASgCACEDAkBBCBCSgICAACIBDQBBBEEIEJqAgIAAAAsgASACNgIEIAEgAzYCACAAQby0wIAANgIEIAAgATYCAAsUACAAQby0wIAANgIEIAAgATYCAAsMACAAIAEpAgA3AwALwwIBBH9BHyECAkAgAUGAgIAITw0AIAFBJiABQQh2ZyICa3ZBAXEgAkEBdHJBPnMhAgsgAEIANwIQIAAgAjYCHCACQQJ0QfjZwIAAaiEDAkBBACgClN3AgABBASACdCIEcQ0AIAMgADYCACAAIAM2AhggACAANgIMIAAgADYCCEEAQQAoApTdwIAAIARyNgKU3cCAAA8LAkACQAJAIAMoAgAiBCgCBEF4cSABRw0AIAQhAgwBCyABQQBBGSACQQF2ayACQR9GG3QhAwNAIAQgA0EddkEEcWoiBSgCECICRQ0CIANBAXQhAyACIQQgAigCBEF4cSABRw0ACwsgAigCCCIDIAA2AgwgAiAANgIIIABBADYCGCAAIAI2AgwgACADNgIIDwsgBUEQaiAANgIAIAAgBDYCGCAAIAA2AgwgACAANgIICw0AIAAgARCOgYCAAAALrwQCBH8DfSOAgICAAEEQayEBIAC8IgJBH3YhAwJAAkACQAJAAkACQAJAIAJB/////wdxIgRB0Ni6lQRJDQACQCAEQYCAgPwHTQ0AIAAPCwJAIARBl+TFlQRLDQAgAkF/Sg0CIAFDAACAgCAAlTgCCCABKgIIGgwCCwJAIAJBf0oNACABQwAAgIAgAJU4AgggASoCCBpDAAAAACEFIARBtOO/lgRNDQIMBwsgAEMAAAB/lA8LAkAgBEGY5MX1A0sNACAEQYCAgMgDTQ0CQQAhBEMAAAAAIQYgACEFDAULIARBkquU/ANNDQILIABDO6q4P5QgA0ECdCoCgLXAgACS/AAhBAwCCyABIABDAAAAf5I4AgwgASoCDBogAEMAAIA/kg8LIANBAXMgA2shBAsgACAEsiIFQwByMb+UkiIAIAVDjr6/NZQiBpMhBQsgACAFIAUgBSAFlCIHIAdDFVI1u5RDj6oqPpKUkyIHlEMAAABAIAeTlSAGk5JDAACAP5IhBSAERQ0AAkACQAJAAkAgBEH/AEoNACAEQYJ/Tg0DIAVDAACADJQhBSAEQZt+TQ0BIARB5gBqIQQMAwsgBUMAAAB/lCEFIARB/gFLDQEgBEGBf2ohBAwCCyAFQwAAgAyUIQUgBEG2fSAEQbZ9SxtBzAFqIQQMAQsgBUMAAAB/lCEFIARB/QIgBEH9AkkbQYJ+aiEECyAFIARBF3RBgICA/ANqQYCAgPwHcb6UIQULIAULCgAgABCigYCAAAuvIggJfwF8Cn8BfAh/AXwEfwN8I4CAgIAAQbAEayIGJICAgIAAIAZCADcDmAEgBkIANwOQASAGQgA3A4gBIAZCADcDgAEgBkIANwN4IAZCADcDcCAGQgA3A2ggBkIANwNgIAZCADcDWCAGQgA3A1AgBkIANwNIIAZCADcDQCAGQgA3AzggBkIANwMwIAZCADcDKCAGQgA3AyAgBkIANwMYIAZCADcDECAGQgA3AwggBkIANwMAIAZCADcDuAIgBkIANwOwAiAGQgA3A6gCIAZCADcDoAIgBkIANwOYAiAGQgA3A5ACIAZCADcDiAIgBkIANwOAAiAGQgA3A/gBIAZCADcD8AEgBkIANwPoASAGQgA3A+ABIAZCADcD2AEgBkIANwPQASAGQgA3A8gBIAZCADcDwAEgBkIANwO4ASAGQgA3A7ABIAZCADcDqAEgBkIANwOgASAGQgA3A9gDIAZCADcD0AMgBkIANwPIAyAGQgA3A8ADIAZCADcDuAMgBkIANwOwAyAGQgA3A6gDIAZCADcDoAMgBkIANwOYAyAGQgA3A5ADIAZCADcDiAMgBkIANwOAAyAGQgA3A/gCIAZCADcD8AIgBkIANwPoAiAGQgA3A+ACIAZCADcD2AIgBkIANwPQAiAGQgA3A8gCIAZCADcDwAIgBkHgA2pBAEHQAPwLACAFQQJ0KAKItcCAACIHIAFBf2oiCGohCSAEQX1qQRhtIgpBACAKQQBKGyILIAhrIQwgC0ECdCABQQJ0a0GctcCAAGohDSAGIQpBACEOA0ACQAJAIAwgDmpBAE4NAEQAAAAAAAAAACEPDAELIA0oAgC3IQ8LIAogDzkDACAKQQhqIQogDUEEaiENIA5BAWoiDiAJTQ0ACyABQQFxIRBBACABQX5xayEJIAFBA3QgBmpBcGohEUEAIQwDQEQAAAAAAAAAACEPAkACQAJAIAgNAEEAIQoMAQtBACENIBEhCiAAIQ4DQCAPIA4rAwAgCkEIaisDAKKgIA5BCGorAwAgCisDAKKgIQ8gCkFwaiEKIA5BEGohDiAJIA1BfmoiDUcNAAsgEEUNAUEAIA1rIQoLIA8gACAKQQN0aisDACAGIAwgCGogCmtBA3RqKwMAoqAhDwsgBkHAAmogDEEDdGogDzkDACARQQhqIREgDEEBaiIMIAdNDQALRAAAAAAAAPB/RAAAAAAAAOB/IAQgC0FobGoiEkFoaiITQf4PSyIUG0QAAAAAAAAAAEQAAAAAAABgAyATQblwSSIVG0QAAAAAAADwPyATQYJ4SCIWGyATQf8HSiIXGyATQf0XIBNB/RdJG0GCcGogEkHpd2ogFBsiGCATQfBoIBNB8GhLG0GSD2ogEkGxB2ogFRsiGSATIBYbIBcbQf8Haq1CNIa/oiEaIAFBAXEhG0EAIAFBfnFrIQkgBkHgA2pBfGoiHCAHQQJ0aiEdQS8gEmtBH3EhHkEwIBJrQR9xIR8gBkF4aiEgIAZBwAJqQXhqISEgE0F/aiEiIAchDAJAA0AgBkHAAmogDCIQQQN0IgpqKwMAIQ8CQCAQRQ0AIAZB4ANqIQ4DQCAOIA8gD0QAAAAAAABwPqL8ArciI0QAAAAAAABwwaKg/AI2AgAgISAKaisDACAjoCEPIA5BBGohDiAKQXhqIgoNAAsLAkACQAJAIBcNACAWDQEgEyEKDAILIA9EAAAAAAAA4H+iIg9EAAAAAAAA4H+iIA8gFBshDyAYIQoMAQsgD0QAAAAAAABgA6IiD0QAAAAAAABgA6IgDyAVGyEPIBkhCgsgDyAKQf8Haq1CNIa/oiIPIA9EAAAAAAAAwD+inEQAAAAAAAAgwKKgIg8gD/wCIiS3oSEPAkACQAJAAkACQAJAIBNBAEoiJQ0AAkAgEw0AIAZB4ANqIBBBAnRqQXxqKAIAQRd1ISYMAgtBAiEmQQAhJyAPRAAAAAAAAOA/ZkUNBQwCCyAGQeADaiAQQQJ0akF8aiIKIAooAgAiCiAKIB91IgogH3RrIg42AgAgDiAedSEmIAogJGohJAsgJkEBSA0BC0EBIQ4CQCAQRQ0AQQAhDUEAIQwCQCAQQQFGDQAgEEEBcSEnIBBBHnEhBEEAIQ0gBkHgA2ohCkEAIQwDQCAKKAIAIQ4CQAJAAkACQCAMRQ0AQf///wchDAwBCyAORQ0BQYCAgAghDAsgCiAMIA5rNgIAQQAhDAwBC0EBIQwLIApBBGoiESgCACEOAkACQAJAAkAgDA0AQf///wchDAwBCyAORQ0BQYCAgAghDAsgESAMIA5rNgIAQQEhDEEAIQ4MAQtBACEMQQEhDgsgCkEIaiEKIAQgDUECaiINRw0ACyAnRQ0BCyAGQeADaiANQQJ0aiINKAIAIQoCQAJAIAxFDQBB////ByEODAELQQEhDiAKRQ0BQYCAgAghDgsgDSAOIAprNgIAQQAhDgsCQCAlRQ0AQf///wMhCgJAAkAgIg4CAQACC0H///8BIQoLIAZB4ANqIBBBAnRqQXxqIg0gDSgCACAKcTYCAAsgJEEBaiEkICZBAkYNAQsgJiEnDAELRAAAAAAAAPA/IA+hIg8gDyAaoSAOGyEPQQIhJwsCQCAPRAAAAAAAAAAAYg0AIB0hCiAQIQwCQCAHIBBBf2oiDksNACAcIBBBAnRqIQpBACENAkADQCAKKAIAIA1yIQ0gDkUNASAKQXxqIQogByAOQX9qIg5NDQALCyAdIQogECEMIA1FDQAgBkHgA2ogEEECdGpBfGohCgNAIBBBf2ohECATQWhqIRMgCigCACEOIApBfGohCiAORQ0ADAQLCwNAIAxBAWohDCAKKAIAIQ4gCkF8aiEKIA5FDQALIBAgDE8NASAQQQFqIQogICABIBBqQQN0aiEEA0AgBiAQIAFqIhBBA3RqIAoiESALakECdCgCmLXAgAC3OQMAAkACQAJAIAgNAEEAIQpEAAAAAAAAAAAhDwwBC0QAAAAAAAAAACEPQQAhDSAEIQogACEOA0AgDyAOKwMAIApBCGorAwCioCAOQQhqKwMAIAorAwCioCEPIApBcGohCiAOQRBqIQ4gCSANQX5qIg1HDQALIBtFDQFBACANayEKCyAPIAAgCkEDdGorAwAgBiAQIAprQQN0aisDAKKgIQ8LIAZBwAJqIBFBA3RqIA85AwAgBEEIaiEEIBEhECARQQFqIgogDE0NAAwCCwsLAkACQAJAAkBBACATayIKQf8HSg0AIApBgnhODQMgD0QAAAAAAABgA6IhDyAKQbhwTQ0BQckHIBNrIQoMAwsgD0QAAAAAAADgf6IhDyAKQf4PSw0BQYF4IBNrIQoMAgsgD0QAAAAAAABgA6IhDyAKQfBoIApB8GhLG0GSD2ohCgwBCyAPRAAAAAAAAOB/oiEPIApB/RcgCkH9F0kbQYJwaiEKCwJAIA8gCkH/B2qtQjSGv6IiD0QAAAAAAABwQWYNACAGQeADaiAQQQJ0aiAP/AI2AgAMAQsgBkHgA2ogEEEBaiIKQQJ0aiAPRAAAAAAAAHA+ovwCIg42AgAgBkHgA2ogEEECdGogDyAOt0QAAAAAAABwwaKg/AI2AgAgCiEQIBIhEwsCQAJAAkACQCATQf8HSg0AIBNBgnhIDQFEAAAAAAAA8D8hDwwDCyATQf4PSw0BIBNBgXhqIRNEAAAAAAAA4H8hDwwCCwJAIBNBuHBNDQAgE0HJB2ohE0QAAAAAAABgAyEPDAILIBNB8GggE0HwaEsbQZIPaiETRAAAAAAAAAAAIQ8MAQsgE0H9FyATQf0XSRtBgnBqIRNEAAAAAAAA8H8hDwsgDyATQf8Haq1CNIa/oiEPAkACQCAQQQFxRQ0AIBAhDQwBCyAGQcACaiAQQQN0aiAPIAZB4ANqIBBBAnRqKAIAt6I5AwAgD0QAAAAAAABwPqIhDyAQQX9qIQ0LAkAgEEUNACANQQJ0IAZB4ANqakF8aiEKIA1BA3QgBkHAAmpqQXhqIQ4DQCAOIA9EAAAAAAAAcD6iIiMgCigCALeiOQMAIA5BCGogDyAKQQRqKAIAt6I5AwAgCkF4aiEKIA5BcGohDiAjRAAAAAAAAHA+oiEPIA1BfmoiDUF/Rw0ACwsgEEEBaiEhIAZBwAJqIBBBA3RqIQkgECEKA0ACQAJAAkAgByAQIAoiEWsiBCAHIARJGyIADQBEAAAAAAAAAAAhD0EAIQ4MAQsgAEEBakF+cSEMRAAAAAAAAAAAIQ9BACEKQQAhDgNAIA8gCkGgt8CAAGorAwAgCSAKaiINKwMAoqAgCkGot8CAAGorAwAgDUEIaisDAKKgIQ8gCkEQaiEKIAwgDkECaiIORw0ACyAAQQFxDQELIA8gDkEDdCsDoLfAgAAgBkHAAmogDiARakEDdGorAwCioCEPCyAGQaABaiAEQQN0aiAPOQMAIAlBeGohCSARQX9qIQogEQ0ACwJAAkACQAJAIAUOBAECAgABC0QAAAAAAAAAACEoAkAgEEUNACAQIQ4CQCAQQQFxRQ0AIAZBoAFqIBBBA3RqIgpBeGoiDiAOKwMAIg8gCisDACIjoCIaOQMAIAogIyAPIBqhoDkDACAQQX9qIQ4LIBBBAUYNACAOQQN0IAZBoAFqakFwaiEKA0AgCiAKKwMAIiMgCkEIaiINKwMAIhogCkEQaiIJKwMAIimgIg+gIio5AwAgCSApIBogD6GgOQMAIA0gDyAjICqhoDkDACAKQXBqIQogDkF+aiIODQALIBBBAUYNACAQQQN0IAZBoAFqakF4aiEKIBAhDgNAIAogCisDACIPIApBCGoiDSsDACIjoCIaOQMAIA0gIyAPIBqhoDkDACAKQXhqIQogDkECSyENIA5Bf2ohDiANDQALIAZBoAFqIBBBA3RqIQpEAAAAAAAAAAAhKANAICggCisDAKAhKCAQQQJLIQ4gCkF4aiEKIBBBf2ohECAODQALCyAGKwOgASEPAkAgJw0AIAIgDzkDACACICg5AxAgAiAGKwOoATkDCAwDCyACIA+aOQMAIAIgKJo5AxAgAiAGKwOoAZo5AwgMAgsCQAJAICFBA3EiDQ0ARAAAAAAAAAAAIQ8gECEODAELIAZBoAFqIBBBA3RqIQpEAAAAAAAAAAAhDyAQIQ4DQCAOQX9qIQ4gDyAKKwMAoCEPIApBeGohCiANQX9qIg0NAAsLAkAgEEEDSQ0AIA5BA3QgBkGgAWpqQWhqIQoDQCAPIApBGGorAwCgIApBEGorAwCgIApBCGorAwCgIAorAwCgIQ8gCkFgaiEKIA5BfGoiDkF/Rw0ACwsgAiAPmiAPICcbOQMADAELAkACQCAhQQNxIg0NAEQAAAAAAAAAACEPIBAhDgwBCyAGQaABaiAQQQN0aiEKRAAAAAAAAAAAIQ8gECEOA0AgDkF/aiEOIA8gCisDAKAhDyAKQXhqIQogDUF/aiINDQALCwJAIBBBA0kNACAOQQN0IAZBoAFqakFoaiEKA0AgDyAKQRhqKwMAoCAKQRBqKwMAoCAKQQhqKwMAoCAKKwMAoCEPIApBYGohCiAOQXxqIg5Bf0cNAAsLIAIgD5ogDyAnGzkDACAGKwOgASAPoSEPAkAgEEUNACAQQQNxIQ5BASEKAkAgEEF/akEDSQ0AIBBBfHEhCSAGQaABakEgaiEKQQAhDQNAIA8gCkFoaisDAKAgCkFwaisDAKAgCkF4aisDAKAgCisDAKAhDyAKQSBqIQogCSANQQRqIg1HDQALIA5FDQEgDUEBaiEKCyAGQaABaiAKQQN0aiEKA0AgDyAKKwMAoCEPIApBCGohCiAOQX9qIg4NAAsLIAIgD5ogDyAnGzkDCAsgBkGwBGokgICAgAAgJEEHcQuYDwQBfwF+An8EfCOAgICAAEEwayICJICAgIAAAkACQAJAIAG9IgNCIIinIgRB/////wdxIgVB+9S9gARJDQACQCAFQbyM8YAESQ0AAkACQAJAIAVB+8PkiQRJDQAgBUH//7//B0sNASACIANC/////////weDQoCAgICAgICwwQCEvyIB/AK3IgY5AwAgAiABIAahRAAAAAAAAHBBoiIB/AIiBLciBjkDCCACIAEgBqFEAAAAAAAAcEGiIgE5AxAgAkIANwMoIAJCADcDICACQgA3AxggAkECQQEgBBtBAyABRAAAAAAAAAAAYRsgAkEYakEDIAVBFHZB6ndqQQEQpIGAgAAhBSADQn9XDQIgACAFNgIIIAAgAisDIDkDECAAIAIrAxg5AwAMBgsCQCAFQRR2IgUgASABRIPIyW0wX+Q/okQAAAAAAAA4Q6BEAAAAAAAAOMOgIgZEAABAVPsh+b+ioCIBIAZEMWNiGmG00D2iIgehIgi9QjSIp0H/D3FrQRFIDQACQCAFIAEgBkQAAGAaYbTQPaIiCKEiCSAGRHNwAy6KGaM7oiABIAmhIAihoSIHoSIIvUI0iKdB/w9xa0EyTg0AIAkhAQwBCyAJIAZEAAAALooZozuiIgihIgEgBkTBSSAlmoN7OaIgCSABoSAIoaEiB6EhCAsgACAIOQMAIAAgBvwCNgIIIAAgASAIoSAHoTkDEAwFCyAAQQA2AgggACABIAGhIgE5AxAgACABOQMADAQLIABBACAFazYCCCAAIAIrAyCaOQMQIAAgAisDGJo5AwAMAwsCQCAFQb3714AESQ0AAkAgBUH7w+SABEcNAAJAIAEgAUSDyMltMF/kP6JEAAAAAAAAOEOgRAAAAAAAADjDoCIGRAAAQFT7Ifm/oqAiASAGRDFjYhphtNA9oiIHoSIIvUKAgICAgICA+P8Ag0L/////////hz9WDQACQCABIAZEAABgGmG00D2iIgihIgkgBkRzcAMuihmjO6IgASAJoSAIoaEiB6EiCL1CgICAgICAgID/AINC//////////88WA0AIAkhAQwBCyAJIAZEAAAALooZozuiIgihIgEgBkTBSSAlmoN7OaIgCSABoSAIoaEiB6EhCAsgACAIOQMAIAAgBvwCNgIIIAAgASAIoSAHoTkDEAwECwJAIANCAFMNACAAQQQ2AgggACABRAAAQFT7IRnAoCIBRDFjYhphtPC9oCIGOQMAIAAgASAGoUQxY2IaYbTwvaA5AxAMBAsgAEF8NgIIIAAgAUQAAEBU+yEZQKAiAUQxY2IaYbTwPaAiBjkDACAAIAEgBqFEMWNiGmG08D2gOQMQDAMLIAVB/LLLgARGDQECQCADQgBTDQAgAEEDNgIIIAAgAUQAADB/fNkSwKAiAUTKlJOnkQ7pvaAiBjkDACAAIAEgBqFEypSTp5EO6b2gOQMQDAMLIABBfTYCCCAAIAFEAAAwf3zZEkCgIgFEypSTp5EO6T2gIgY5AwAgACABIAahRMqUk6eRDuk9oDkDEAwCCwJAIARB//8/cUH7wyRGDQACQCAFQf2yi4AESQ0AAkAgA0J/Vw0AIABBAjYCCCAAIAFEAABAVPshCcCgIgFEMWNiGmG04L2gIgY5AwAgACABIAahRDFjYhphtOC9oDkDEAwECyAAQX42AgggACABRAAAQFT7IQlAoCIBRDFjYhphtOA9oCIGOQMAIAAgASAGoUQxY2IaYbTgPaA5AxAMAwsCQCADQn9VDQAgAEF/NgIIIAAgAUQAAEBU+yH5P6AiAUQxY2IaYbTQPaAiBjkDACAAIAEgBqFEMWNiGmG00D2gOQMQDAMLIABBATYCCCAAIAFEAABAVPsh+b+gIgFEMWNiGmG00L2gIgY5AwAgACABIAahRDFjYhphtNC9oDkDEAwCCwJAIAVBFHYiBSABIAFEg8jJbTBf5D+iRAAAAAAAADhDoEQAAAAAAAA4w6AiBkQAAEBU+yH5v6KgIgEgBkQxY2IaYbTQPaIiB6EiCL1CNIinQf8PcWtBEUgNAAJAIAUgASAGRAAAYBphtNA9oiIIoSIJIAZEc3ADLooZozuiIAEgCaEgCKGhIgehIgi9QjSIp0H/D3FrQTJODQAgCSEBDAELIAkgBkQAAAAuihmjO6IiCKEiASAGRMFJICWag3s5oiAJIAGhIAihoSIHoSEICyAAIAg5AwAgACAG/AI2AgggACABIAihIAehOQMQDAELAkAgASABRIPIyW0wX+Q/okQAAAAAAAA4Q6BEAAAAAAAAOMOgIgZEAABAVPsh+b+ioCIBIAZEMWNiGmG00D2iIgehIgi9QoCAgICAgID4/wCDQv////////+HP1YNAAJAIAEgBkQAAGAaYbTQPaIiCKEiCSAGRHNwAy6KGaM7oiABIAmhIAihoSIHoSIIvUKAgICAgICAgP8Ag0L//////////zxYDQAgCSEBDAELIAkgBkQAAAAuihmjO6IiCKEiASAGRMFJICWag3s5oiAJIAGhIAihoSIHoSEICyAAIAg5AwAgACAG/AI2AgggACABIAihIAehOQMQCyACQTBqJICAgIAAC7cGAgJ/BXwjgICAgABBIGsiASSAgICAAAJAAkAgAL1CIIinQf////8HcSICQfzDpP8DSQ0AAkACQAJAAkACQCACQf//v/8HSw0AIAFBCGogABClgYCAACABKwMYIQMgASsDCCIEIASiIgAgAKIhBSABKAIQQQNxDgQCAwQBAgsgACAAoSEADAULRAAAAAAAAPA/IABEAAAAAAAA4D+iIgahIgdEAAAAAAAA8D8gB6EgBqEgACAAIAAgAESQFcsZoAH6PqJEd1HBFmzBVr+gokRMVVVVVVWlP6CiIAUgBaIgACAARNQ4iL7p+qi9okTEsbS9nu4hPqCiRK1SnIBPfpK+oKKgoiAEIAOioaCgmiEADAQLIAQgBCAAoiIGRElVVVVVVcU/oiAAIANEAAAAAAAA4D+iIAYgACAFoiAARHzVz1o62eU9okTrnCuK5uVavqCiIAAgAER9/rFX4x3HPqJE1WHBGaABKr+gokSm+BARERGBP6CgoqGiIAOhoKEhAAwDC0QAAAAAAADwPyAARAAAAAAAAOA/oiIGoSIHRAAAAAAAAPA/IAehIAahIAAgACAAIABEkBXLGaAB+j6iRHdRwRZswVa/oKJETFVVVVVVpT+goiAFIAWiIAAgAETUOIi+6fqovaJExLG0vZ7uIT6gokStUpyAT36SvqCioKIgBCADoqGgoCEADAILIAQgBCAAoiIGRElVVVVVVcU/oiAAIANEAAAAAAAA4D+iIAYgACAFoiAARHzVz1o62eU9okTrnCuK5uVavqCiIAAgAER9/rFX4x3HPqJE1WHBGaABKr+gokSm+BARERGBP6CgoqGiIAOhoKGaIQAMAQsCQCACQYCAwPIDSQ0AIAAgACAAIACiIgSiIAQgBCAEIASioiAERHzVz1o62eU9okTrnCuK5uVavqCiIAQgBER9/rFX4x3HPqJE1WHBGaABKr+gokSm+BARERGBP6CgokRJVVVVVVXFv6CioCEADAELAkAgAkGAgMAASQ0AIAEgAEQAAAAAAABwR6A5AwggASsDCBoMAQsgASAARAAAAAAAAHA4ojkDCCABKwMIGgsgAUEgaiSAgICAACAACwoAIAAQpoGAgAALywYCAn8EfCOAgICAAEEgayIBJICAgIAAAkACQAJAAkACQAJAAkAgAL1CIIinQf////8HcSICQfzDpP8DSQ0AIAJB//+//wdLDQEgAUEIaiAAEKWBgIAAIAErAxghAyABKwMIIgQgBKIhACABKAIQQQNxDgQDBAUCAwsCQCAA/AINAEQAAAAAAADwPyEEIAJBnsGa8gNJDQYLRAAAAAAAAPA/IAAgAKIiBEQAAAAAAADgP6IiA6EiBUQAAAAAAADwPyAFoSADoSAEIAQgBCAERJAVyxmgAfo+okR3UcEWbMFWv6CiRExVVVVVVaU/oKIgBCAEoiIDIAOiIAQgBETUOIi+6fqovaJExLG0vZ7uIT6gokStUpyAT36SvqCioKIgAEQAAAAAAAAAgKKgoKAhBAwFCyAAIAChIQQMBAsgBCAEIACiIgVESVVVVVVVxT+iIAAgA0QAAAAAAADgP6IgBSAAIAAgAKKiIABEfNXPWjrZ5T2iROucK4rm5Vq+oKIgACAARH3+sVfjHcc+okTVYcEZoAEqv6CiRKb4EBEREYE/oKCioaIgA6GgoSEEDAMLRAAAAAAAAPA/IABEAAAAAAAA4D+iIgWhIgZEAAAAAAAA8D8gBqEgBaEgACAAIAAgAESQFcsZoAH6PqJEd1HBFmzBVr+gokRMVVVVVVWlP6CiIAAgAKIiBSAFoiAAIABE1DiIvun6qL2iRMSxtL2e7iE+oKJErVKcgE9+kr6goqCiIAQgA6KhoKAhBAwCCyAEIAQgAKIiBURJVVVVVVXFP6IgACADRAAAAAAAAOA/oiAFIAAgACAAoqIgAER81c9aOtnlPaJE65wriublWr6goiAAIABEff6xV+Mdxz6iRNVhwRmgASq/oKJEpvgQERERgT+goKKhoiADoaChmiEEDAELRAAAAAAAAPA/IABEAAAAAAAA4D+iIgWhIgZEAAAAAAAA8D8gBqEgBaEgACAAIAAgAESQFcsZoAH6PqJEd1HBFmzBVr+gokRMVVVVVVWlP6CiIAAgAKIiBSAFoiAAIABE1DiIvun6qL2iRMSxtL2e7iE+oKJErVKcgE9+kr6goqCiIAQgA6KhoKCaIQQLIAFBIGokgICAgAAgBAsKACAAEKiBgIAAC1gCAX4BfwJAIABE////////3z8gAKagIgC9IgFCNIinQf8PcSICQbIISw0AQoCAgICAgICAgH9CgICAgICAgHggAkGBeGqthyACQf8HSRsgAYO/IQALIAAL1goGAX8BfAJ/AXwBfwF8I4CAgIAAQRBrIgEkgICAgAAgALshAgJAAkACQAJAIAC8IgNB/////wdxIgRB25+k+gNJDQACQCAEQdKn7YMESQ0AAkAgBEHW44iHBEkNAAJAAkACQAJAAkAgBEH////7B0sNACABQgA3AwgCQAJAIARB2p+k7gRLDQAgAiACRIPIyW0wX+Q/okQAAAAAAAA4Q6BEAAAAAAAAOMOgIgVEAAAAUPsh+b+ioCAFRGNiGmG0EFG+oqAhAiAF/AIhBAwBCyABIAQgBEEXdkHqfmoiBkEXdGu+uzkDACABQQEgAUEIakEBIAZBABCkgYCAACEEAkAgA0EASA0AIAErAwghAgwBC0EAIARrIQQgASsDCJohAgsgBEEDcQ4EAgMEAQILIAAgAJMhAAwJCyACIAIgAqIiBaIiByAFIAWioiAFRKdGO4yHzcY+okR058ri+QAqv6CiIAIgByAFRLL7bokQEYE/okR3rMtUVVXFv6CioKC2IQAMCAsgAiACoiICRIFeDP3//9+/okQAAAAAAADwP6AgAiACoiIFREI6BeFTVaU/oqAgAiAFoiACRGlQ7uBCk/k+okQnHg/oh8BWv6CioLYhAAwHCyACIAKiIgUgApqiIgcgBSAFoqIgBUSnRjuMh83GPqJEdOfK4vkAKr+goiAHIAVEsvtuiRARgT+iRHesy1RVVcW/oKIgAqGgtiEADAYLIAIgAqIiAkSBXgz9///fv6JEAAAAAAAA8D+gIAIgAqIiBURCOgXhU1WlP6KgIAIgBaIgAkRpUO7gQpP5PqJEJx4P6IfAVr+goqC2jCEADAULIARB39u/hQRLDQICQCADQX9MDQAgAkTSITN/fNkSwKAiBSAFIAWiIgKiIgcgAiACoqIgAkSnRjuMh83GPqJEdOfK4vkAKr+goiAFIAcgAkSy+26JEBGBP6JEd6zLVFVVxb+goqCgtiEADAULRNIhM3982RLAIAKhIgUgBSAFoiICoiIHIAIgAqKiIAJEp0Y7jIfNxj6iRHTnyuL5ACq/oKIgBSAHIAJEsvtuiRARgT+iRHesy1RVVcW/oKKgoLYhAAwECyAEQeOX24AESw0CAkAgA0F/TA0ARBgtRFT7Ifk/IAKhIgUgBSAFoiICoiIHIAIgAqKiIAJEp0Y7jIfNxj6iRHTnyuL5ACq/oKIgBSAHIAJEsvtuiRARgT+iRHesy1RVVcW/oKKgoLYhAAwECyACRBgtRFT7Ifk/oCIFIAUgBaIiAqIiByACIAKioiACRKdGO4yHzcY+okR058ri+QAqv6CiIAUgByACRLL7bokQEYE/okR3rMtUVVXFv6CioKC2IQAMAwsCQCAEQYCAgMwDSQ0AIAIgAqIiAkSBXgz9///fv6JEAAAAAAAA8D+gIAIgAqIiBURCOgXhU1WlP6KgIAIgBaIgAkRpUO7gQpP5PqJEJx4P6IfAVr+goqC2IQAMAwsgASAAQwAAgHuSOAIIIAEqAggaQwAAgD8hAAwCC0QYLURU+yEZwEQYLURU+yEZQCADQX9KGyACoCICIAKiIgJEgV4M/f//37+iRAAAAAAAAPA/oCACIAKiIgVEQjoF4VNVpT+ioCACIAWiIAJEaVDu4EKT+T6iRCceD+iHwFa/oKKgtiEADAELRBgtRFT7IQnARBgtRFT7IQlAIANBf0obIAKgIgIgAqIiAkSBXgz9///fv6JEAAAAAAAA8D+gIAIgAqIiBURCOgXhU1WlP6KgIAIgBaIgAkRpUO7gQpP5PqJEJx4P6IfAVr+goqC2jCEACyABQRBqJICAgIAAIAALCgAgABCrgYCAAAtHAQJ/AkAgAEP///8+IACYkiIAvCIBQRd2Qf8BcSICQZUBSw0AQYCAgIB4QYCAgHwgAkGBf2p1IAJB/wBJGyABcb4hAAsgAAvYBQQBfwF+An8EfiOAgICAAEGwAWsiAySAgICAAAJAIAJCgICAgICAgIDAAFoNACAAIAJCAYZaDQACQAJAIAIgAkJ/fCIEg1ANACACIAJ5pyIFQX5qIgatIgeGIghCgICAgICAgIAgWA0CIAhCgICAgICAgIDAAFoNAiAAIAhCAYYiCVoNAiADQaABakIAQoCAgICAgICAgH8gCX0iAiAJQgAQuIGAgAAgA0GQAWogAykDoAEiBCADKQOoASIKIAlCABC9gYCAACADQYABaiAEIApCAYQgAEIBhkIAEL2BgIAAIAIgAykDmAF9IAMpA5ABIgBCAFKtfSECQgAgAH0hACADKQOIASEEIAMpA4ABIQoCQCAGIAFqIgZBP0kNAAJAIAEgBWpBv39qIgVBP25BAWpBA3EiAUUNAANAIANB8ABqIARCACAAIAIQvYGAgAAgBkFBaiEGIApCAYggAykDeHwhBCADKQNwIQogAUF/aiIBDQALCyAFQb0BSQ0AA0AgA0HgAGogBEIAIAAgAhC9gYCAACADQdAAaiADKQNoIgQgCkIBiHwiCiAKIARUrSAAIAIQvYGAgAAgA0HAAGogAykDWCIEIAMpA2BCAYh8IgogCiAEVK0gACACEL2BgIAAIANBMGogAykDSCIEIAMpA1BCAYh8IgogCiAEVK0gACACEL2BgIAAIAMpA0BCAYggAykDOHwhBCADKQMwIQogBkGEfmoiBkE+Sw0ACwsgA0EgaiAKIAQgBhDIgYCAACADQRBqIAAgAiAEIAZBP3OtiEIAEL2BgIAAIAMgAykDGCADKQMoQv///////////wCDfCADKQMQIgIgAykDIEJ+g3wgAlStfEICfEIAIAlCABC9gYCAACADKQMIIgJCACAIIAggAlYbfSAHiCECDAELQgAhAiABQcAATw0AIAQgACABrYaDIQILIANBsAFqJICAgIAAIAIPCwAL7QQDAX8HfgR/I4CAgIAAQSBrIgIkgICAgAACQAJAAkACQAJAIAC9IgNCgICAgICAgPj/AINCgICAgICAgPj/AFENAEIAIAG9IgR9QoCAgICAgID4/wCDUA0AIANC////////////AIMiBSAEQv///////////wCDIgZUDQQCQCAFQgAgBUKAgICAgICAeHwiBCAEIAVWGyIHQoCAgICAgID4/wCDfSIFIAZCACAGQoCAgICAgIB4fCIEIAQgBlYbIghCgICAgICAgPj/AIMiCX0iBEIBhlQNACAGIAlRDQIgBSAEgiEFCwJAIAdCNIgiBqciCiAIQjSIIgenIgtrIgxBH0sNAAJAIAYgB1ENACAMQQNxIQ0CQCALIAprQXxLDQAgDEEccSEMA0AgBUIAIAQgBSAEVBt9QgGGIgVCACAEIAUgBFQbfUIBhiIFQgAgBCAFIARUG31CAYYiBUIAIAQgBSAEVBt9QgGGIQUgDEF8aiIMDQALIA1FDQELQQAgDWshDANAIAVCACAEIAUgBFQbfUIBhiEFIAxBAWoiDA0ACwsgBUIAIAQgBSAEVBt9IQQMBAsgDEHAAE8NAiACQRBqIAVCACAMEMiBgIAAIAQgAikDGCIGWA0CIAIgAikDECAGIARCABDJgYCAACACKQMAIQQMAwsgACABoiIAIACjIQAMAwsACyAFIAwgBBCugYCAACEECyADQoCAgICAgICAgH+DIQUCQCAEUA0AIAtBNCAEeadBP3NrIgwgCyAMIAtJGyIMa61CNIYgBXwgBCAMrYZ8vyEADAELIAW/IQALIAJBIGokgICAgAAgAAsMACAAIAEQr4GAgAALhwUEAX8BfgJ/A3wjgICAgABBEGshASAAvSICQj+IpyEDAkACQAJAAkACQAJAAkACQCACQiCIp0H/////B3EiBEGrxpiEBEkNAAJAIAAgAGENACAADwsgAETvOfr+Qi6GQGQNAiAARNK8et0rI4bAY0UNASABRAAAAAAAAKC2IACjtjgCBCABKgIEGkQAAAAAAAAAACEFIABEUTAt1RBJh8BjRQ0BDAcLAkAgBEHC3Nj+A0sNACAEQYCAwPEDTQ0DRAAAAAAAAAAAIQZBACEEIAAhBQwGCyAEQbHFwv8DTQ0DCyAARP6CK2VHFfc/oiADQQN0KwPgt8CAAKD8AiEEDAMLIABEAAAAAAAA4H+iDwsgASAARAAAAAAAAOB/oDkDCCABKwMIGiAARAAAAAAAAPA/oA8LIANBAXMgA2shBAsgACAEtyIFRAAA4P5CLua/oqAiACAFRHY8eTXvOeo9oiIGoSEFCyAAIAUgBSAFIAWiIgcgByAHIAcgB0TQpL5yaTdmPqJE8WvSxUG9u76gokQs3iWvalYRP6CiRJO9vhZswWa/oKJEPlVVVVVVxT+goqEiB6JEAAAAAAAAAEAgB6GjIAahoEQAAAAAAADwP6AhBSAERQ0AAkACQAJAAkAgBEH/B0oNACAEQYJ4Tg0DIAVEAAAAAAAAYAOiIQUgBEG4cE0NASAEQckHaiEEDAMLIAVEAAAAAAAA4H+iIQUgBEH+D0sNASAEQYF4aiEEDAILIAVEAAAAAAAAYAOiIQUgBEHwaCAEQfBoSxtBkg9qIQQMAQsgBUQAAAAAAADgf6IhBSAEQf0XIARB/RdJG0GCcGohBAsgBSAEQf8Haq1CNIa/oiEFCyAFCwoAIAAQsYGAgAALrgEAAkACQAJAAkAgAUH/B0oNACABQYJ4Tg0DIABEAAAAAAAAYAOiIQAgAUG4cE0NASABQckHaiEBDAMLIABEAAAAAAAA4H+iIQAgAUH+D0sNASABQYF4aiEBDAILIABEAAAAAAAAYAOiIQAgAUHwaCABQfBoSxtBkg9qIQEMAQsgAEQAAAAAAADgf6IhACABQf0XIAFB/RdJG0GCcGohAQsgACABQf8Haq1CNIa/ogunAQACQAJAAkACQCABQf8ASg0AIAFBgn9ODQMgAEMAAIAMlCEAIAFBm35NDQEgAUHmAGohAQwDCyAAQwAAAH+UIQAgAUH+AUsNASABQYF/aiEBDAILIABDAACADJQhACABQbZ9IAFBtn1LG0HMAWohAQwBCyAAQwAAAH+UIQAgAUH9AiABQf0CSRtBgn5qIQELIAAgAUEXdEGAgID8A2pBgICA/AdxvpQLkxEIAXwBfgN/AX4BfwF+BX8EfEQAAAAAAADwPyECAkAgAb0iA0IgiKciBEH/////B3EiBSADpyIGckUNACAAvSIHpyEIAkAgB0IgiCIJQoCAwP8DUg0AIAhFDQELAkACQAJAAkACQAJAIAmnIgpB/////wdxIgtBgIDA/wdLDQACQAJAIAtBgIDA/wdHDQAgCA0CIAVBgIDA/wdLDQIMAQsgBUGBgMD/B08NAQsCQCAGRQ0AIAVBgIDA/wdGDQELIAdCAFMNAQwCCyAAIAGgDwtBAiEMIAVB////mQRLDQEgBUGAgMD/A0kNACAFQRR2IQ0CQCAFQf///4kESw0AQQAhDCAGDQRBACEMIAVBkwggDWsiBnYiDSAGdCAFRw0DQQIgDUEBcWshDAwDC0EAIQwgBkGzCCANayINdiIOIA10IAZHDQFBAiAOQQFxayEMDAELQQAhDAsgBg0BCwJAAkACQAJAAkACQCAFQYCAwP8DRg0AIAVBgIDA/wdHDQEgC0GAgMCAfGogCHJFDQcgC0H//7//A0sNBUQAAAAAAAAAACABmiADQn9VGw8LIANCf1cNASAADwsgBEGAgID/A0YNAiAEQYCAgIAERg0BDAQLRAAAAAAAAPA/IACjDwsgACAAog8LIAdCAFMNASAAnw8LIAFEAAAAAAAAAAAgA0J/VRsPCyAAmSECAkACQCAIDQACQCAKQX9KDQAgCkGAgICAeEYNAiAKQYCAwP97Rg0CIApBgIBARw0BDAILIApFDQEgCkGAgMD/A0YNASAKQYCAwP8HRg0BC0QAAAAAAADwPyEPAkAgB0IAWQ0AAkACQCAMDgIAAQILIAAgAKEiASABow8LRAAAAAAAAPC/IQ8LAkACQCAFQYCAgI8ESw0AIAJEAAAAAAAAQEOivSIHIAK9IAtBgIDAAEkiCBshCSAHQiCIpyALIAgbIgRB//8/cSIGQYCAwP8DciEFIARBFHVBzHdBgXggCBtqIQRBACEIAkAgBkGPsQ5JDQACQCAGQfrsLk8NAEEBIQgMAQsgBkGAgID/A3IhBSAEQQFqIQQLIAhBA3QiBisDgLjAgABEAAAAAAAA8D8gBisD8LfAgAAiACAFrUIghiAJQv////8Pg4S/IhCgoyICIBAgAKEiESAIQRJ0IAVBAXZqQYCAoIACaq1CIIa/IhIgESACoiIRvUKAgICAcIO/IgKioSAAIBKhIBCgIAKioaIiACACIAKiIhBEAAAAAAAACECgIAAgESACoKIgESARoiIAIACiIAAgACAAIAAgAETvTkVKKH7KP6JEZdvJk0qGzT+gokQBQR2pYHTRP6CiRE0mj1FVVdU/oKJE/6tv27Zt2z+gokQDMzMzMzPjP6CioCISoL1CgICAgHCDvyIAoiARIBIgAEQAAAAAAAAIwKAgEKGhoqAiESARIAIgAKIiAqC9QoCAgIBwg78iACACoaFE/QM63AnH7j+iIABE9QFbFOAvPr6ioKAiAiAGKwOQuMCAACIRIAIgAEQAAADgCcfuP6IiEKCgIAS3IgKgvUKAgICAcIO/IgAgAqEgEaEgEKGhIREMAQsCQAJAAkAgBUGAgMCfBEsNACALQf//v/8DSQ0CIAtBgIDA/wNLDQEgAkQAAAAAAADwv6AiAERE3134C65UPqIgACAAokQAAAAAAADgPyAAIABEAAAAAAAA0L+iRFVVVVVVVdU/oKKhokT+gitlRxX3v6KgIgIgAiAARAAAAGBHFfc/oiIRoL1CgICAgHCDvyIAIBGhoSERDAMLAkAgC0H//7//A0sNAEQAAAAAAADwf0QAAAAAAAAAACADQgBTGw8LRAAAAAAAAPB/RAAAAAAAAAAAIARBAEobDwsCQCAEQQBKDQAgD0RZ8/jCH26lAaJEWfP4wh9upQGiDwsgD0ScdQCIPOQ3fqJEnHUAiDzkN36iDwsCQCADQgBTDQAgD0RZ8/jCH26lAaJEWfP4wh9upQGiDwsgD0ScdQCIPOQ3fqJEnHUAiDzkN36iDwsgACADQoCAgIBwg78iEKIiAiABIBChIACiIAEgEaKgIgGgIgC9IgOnIQgCQAJAAkAgA0IgiKciBUH//7+EBEoNACAFQYD4//8HcUH/l8OEBE0NAiAFQYDovPsDaiAIcg0BIAEgACACoWVFDQIgD0RZ8/jCH26lAaJEWfP4wh9upQGiDwsCQCAFQYCAwPt7aiAIckUNACAPRJx1AIg85Dd+okScdQCIPOQ3fqIPCyABRP6CK2VHFZc8oCAAIAKhZEUNASAPRJx1AIg85Dd+okScdQCIPOQ3fqIPCyAPRFnz+MIfbqUBokRZ8/jCH26lAaIPC0EAIQgCQCAFQf////8HcUGAgID/A00NAEEAQYCAwAAgBUEUdkECanYgBWoiBUH//z9xQYCAwAByQRMgBUEUdiIGa3YiCGsgCCADQgBTGyEIIAEgAkGAgEAgBkEBanUgBXGtQiCGv6EiAqC9IQMLAkACQCAIQRR0IANCgICAgHCDvyIARAAAAABDLuY/oiIRIAEgACACoaFE7zn6/kIu5j+iIABEOWyoDGFcIL6ioCICoCIBIAEgASABIAGiIgAgACAAIAAgAETQpL5yaTdmPqJE8WvSxUG9u76gokQs3iWvalYRP6CiRJO9vhZswWa/oKJEPlVVVVVVxT+goqEiAKIgAEQAAAAAAAAAwKCjIAIgASARoaEiACABIACioKGhRAAAAAAAAPA/oCIBvSIDQiCIp2oiBUGAgMAASA0AIAWtQiCGIANC/////w+DhL8hAQwBCyABIAgQs4GAgAAhAQsgDyABoiECDAELRAAAAAAAAPA/IAKjIAIgA0IAUxshAiAHQn9VDQACQCAMIAtBgIDAgHxqcg0AIAIgAqEiASABow8LIAKaIAIgDEEBRhsPCyACCwwAIAAgARC1gYCAAAu6CAQBfwF+A38EfiOAgICAAEGwAWsiBSSAgICAAEIAIQYCQAJAAkACQAJAAkACQAJAIAR5IAN5QsAAfCAEQgBSG6ciByACeSABeULAAHwgAkIAUhunIghNDQAgCEE/Sw0BIAdB3wBLDQIgByAIa0EgSQ0DIAVBoAFqIAMgBEHgACAHayIJELmBgIAAIAU1AqABQgF8IQpCACELQgAhBgwECyABIANUIgggAiAEVCACIARRG0UNBUIAIQwMBgsgASABIAOAIgwgA359IQFCACEGQgAhAgwFCyACIAIgA0L/////D4MiBIAiBiADfn1CIIYgAUIgiCIMhCAEgCICQiCGIAwgAiADfn1CIIYgAUL/////D4OEIgEgBIAiA4QhDCABIAMgBH59IQEgAkIgiCAGhCEGQgAhAgwECyAFQTBqIAEgAkHAACAIayIIELmBgIAAIAVBIGogAyAEIAgQuYGAgABCACEGIAUgA0IAIAUpAzAgBSkDIIAiDEIAEL2BgIAAIAVBEGogBEIAIAxCABC9gYCAACAFKQMAIQoCQCAFKQMYIAUpAwgiDSAFKQMQfCILIA1UrXxCAFINACABIApUIgggAiALVCACIAtRG0UNAgsgBCACfCADIAF8IgEgA1StfCALfSABIApUrX0hAiAMQn98IQwgASAKfSEBDAMLAkACQANAIAVBkAFqIAEgAkHAACAIayIIELmBgIAAIAUpA5ABIQwCQCAIIAlPDQAgBUHQAGogAyAEIAgQuYGAgAAgBUHAAGogAyAEIAwgBSkDUIAiDUIAEL2BgIAAAkAgASAFKQNAIgpUIgggAiAFKQNIIgxUIAIgDFEbDQAgAiAMfSAIrX0hAiABIAp9IQEgBiALIA18IgwgC1StfCEGDAcLIAIgBHwgASADfCIEIAFUrXwgDH0gBCAKVK19IQIgBCAKfSEBIAYgDSALfEJ/fCIMIAtUrXwhBgwGCyAFQYABaiAMIAqAIgxCACAIIAlrIggQyIGAgAAgBUHwAGogAyAEIAxCABC9gYCAACAFQeAAaiAFKQNwIAUpA3ggCBDIgYCAACAFKQOIASAGfCAFKQOAASIGIAt8IgsgBlStfCEGAkAgByACIAUpA2h9IAEgBSkDYCIMVK19IgJ5IAEgDH0iAXlCwAB8IAJCAFIbpyIITQ0AIAhBP0sNAgwBCwsgASADVCIIIAIgBFQgAiAEURtFDQEgCyEMDAQLIAEgASADgCICIAN+fSEBIAYgCyACfCIMIAtUrXwhBkIAIQIMAwsgAiAEfSAIrX0hAiABIAN9IQEgBiALQgF8IgxQrXwhBgwCCyACIAt9IAitfSECIAEgCn0hAUIAIQYMAQsgAiAEfSAIrX0hAiABIAN9IQFCASEMCyAAIAE3AxAgACAMNwMAIAAgAjcDGCAAIAY3AwggBUGwAWokgICAgAALSAEBfyOAgICAAEEgayIFJICAgIAAIAUgASACIAMgBBC3gYCAACAFKQMAIQQgACAFKQMINwMIIAAgBDcDACAFQSBqJICAgIAAC04BAX4CQAJAIANBwABxDQAgA0UNASACQQAgA2uthiABIAOtIgSIhCEBIAIgBIghAgwBCyACIAOtiCEBQgAhAgsgACABNwMAIAAgAjcDCAuiBAQBfwF+AX8DfCOAgICAAEEgayIBJICAgIAAAkACQCAAvSICQiCIp0H/////B3EiA0H8w6T/A0kNAAJAIANB//+//wdLDQAgAUEIaiAAEKWBgIAAIAErAwggASsDGCABKAIQQQFxELuBgIAAIQAMAgsgACAAoSEADAELAkACQAJAIANBgICA8gNJDQAgAkKAgICAgP////8Ag0KAgICA8ITl8j9WIgMNASAAIQQMAgsgASAARAAAAAAAAHA4oiAARAAAAAAAAHBHoCADQYCAwABJGzkDCCABKwMIGgwCC0QYLURU+yHpPyAAmaFEB1wUMyamgTxEAAAAAAAAAAAgAKahoCEECyAEIAQgBCAEoiIFoiIGRGNVVVVVVdU/oiAFIAYgBSAFoiIAIAAgACAAIABEc1Ng28t1876iRKaSN6CIfhQ/oKJEAWXy8thEQz+gokQoA1bJIm1tP6CiRDfWBoT0ZJY/oKJEev4QERERwT+gIAUgACAAIAAgACAARNR6v3RwKvs+okTpp/AyD7gSP6CiRGgQjRr3JjA/oKJEFYPg/sjbVz+gokSThG7p4yaCP6CiRP5Bsxu6oas/oKKgokQAAAAAAAAAAKCiRAAAAAAAAAAAoKAiBaAhACADRQ0ARAAAAAAAAPA/IAQgBSAAIACiIABEAAAAAAAA8D+go6GgIgAgAKChIgCaIAAgAkIAUxshAAsgAUEgaiSAgICAACAAC64DAwF+AX8DfAJAIAC9IgNCgICAgID/////AINCgICAgPCE5fI/ViIERQ0ARBgtRFT7Iek/IACZoUQHXBQzJqaBPCABmiABIANCAFMboaAhAEQAAAAAAAAAACEBCyAAIAAgACAAoiIFoiIGRGNVVVVVVdU/oiABIAUgASAGIAUgBaIiByAHIAcgByAHRHNTYNvLdfO+okSmkjegiH4UP6CiRAFl8vLYREM/oKJEKANWySJtbT+gokQ31gaE9GSWP6CiRHr+EBEREcE/oCAFIAcgByAHIAcgB0TUer90cCr7PqJE6afwMg+4Ej+gokRoEI0a9yYwP6CiRBWD4P7I21c/oKJEk4Ru6eMmgj+gokT+QbMbuqGrP6CioKKgoqCgIgWgIQcCQCAEDQACQCACRQ0ARAAAAAAAAPC/IAejIgEgB71CgICAgHCDvyIGIAG9QoCAgIBwg78iB6JEAAAAAAAA8D+gIAUgBiAAoaEgB6KgoiAHoCEHCyAHDwtEAAAAAAAA8D8gAkEBdLihIgEgACAFIAcgB6IgASAHoKOhoCIHIAegoSIHmiAHIANCAFMbCwoAIAAQuoGAgAALbgEGfiAAIANC/////w+DIgUgAUL/////D4MiBn4iByADQiCIIgggBn4iBiAFIAFCIIgiCX58IgVCIIZ8Igo3AwAgACAIIAl+IAUgBlStQiCGIAVCIIiEfCAKIAdUrXwgBCABfiADIAJ+fHw3AwgLggICAn8CfQJAAkACQAJAIAC8IgFBgICABEgNACABQf////sHSw0DQYF/IQIgAUGAgID8A0cNAUMAAAAADwsCQCAAQwAAAABcDQBDAACA/w8LIAFBAEgNASAAQwAAAEyUvCEBQeh+IQILIAFBjfarAmoiAUEXdiACarIiA0OAcTE/lCABQf///wNxQfOJ1PkDar5DAACAv5IiACADQ9H3FzeUIAAgAEMAAABAkpUiAyAAIABDAAAAP5SUIgQgAyADlCIAIAAgAJQiAEPu6ZE+lEOqqio/kpQgACAAQyaeeD6UQxPOzD6SlJKSlJIgBJOSkg8LIAAgAJNDAAAAAJUhAAsgAAvmCgYBfwF8An8BfAF/AXwjgICAgABBEGsiASSAgICAACAAuyECAkACQCAAvCIDQf////8HcSIEQdufpPoDSQ0AAkAgBEHSp+2DBEkNAAJAIARB1uOIhwRJDQACQAJAAkACQAJAIARB////+wdLDQAgAUIANwMIAkACQCAEQdqfpO4ESw0AIAIgAkSDyMltMF/kP6JEAAAAAAAAOEOgRAAAAAAAADjDoCIFRAAAAFD7Ifm/oqAgBURjYhphtBBRvqKgIQIgBfwCIQQMAQsgASAEIARBF3ZB6n5qIgZBF3Rrvrs5AwAgAUEBIAFBCGpBASAGQQAQpIGAgAAhBAJAIANBAEgNACABKwMIIQIMAQtBACAEayEEIAErAwiaIQILIARBA3EOBAIDBAECCyAAIACTIQAMBwsgAiACoiICRIFeDP3//9+/okQAAAAAAADwP6AgAiACoiIFREI6BeFTVaU/oqAgAiAFoiACRGlQ7uBCk/k+okQnHg/oh8BWv6CioLaMIQAMBgsgAiACIAKiIgWiIgcgBSAFoqIgBUSnRjuMh83GPqJEdOfK4vkAKr+goiACIAcgBUSy+26JEBGBP6JEd6zLVFVVxb+goqCgtiEADAULIAIgAqIiAkSBXgz9///fv6JEAAAAAAAA8D+gIAIgAqIiBURCOgXhU1WlP6KgIAIgBaIgAkRpUO7gQpP5PqJEJx4P6IfAVr+goqC2IQAMBAsgAiACoiIFIAKaoiIHIAUgBaKiIAVEp0Y7jIfNxj6iRHTnyuL5ACq/oKIgByAFRLL7bokQEYE/okR3rMtUVVXFv6CiIAKhoLYhAAwDCwJAIARB4Nu/hQRJDQBEGC1EVPshGcBEGC1EVPshGUAgA0F/ShsgAqAiBSAFIAWiIgKiIgcgAiACoqIgAkSnRjuMh83GPqJEdOfK4vkAKr+goiAFIAcgAkSy+26JEBGBP6JEd6zLVFVVxb+goqCgtiEADAMLAkAgA0EASA0AIAJE0iEzf3zZEsCgIgIgAqIiAkSBXgz9///fv6JEAAAAAAAA8D+gIAIgAqIiBURCOgXhU1WlP6KgIAIgBaIgAkRpUO7gQpP5PqJEJx4P6IfAVr+goqC2jCEADAMLIAJE0iEzf3zZEkCgIgIgAqIiAkSBXgz9///fv6JEAAAAAAAA8D+gIAIgAqIiBURCOgXhU1WlP6KgIAIgBaIgAkRpUO7gQpP5PqJEJx4P6IfAVr+goqC2IQAMAgsCQCAEQeSX24AESQ0ARBgtRFT7IQnARBgtRFT7IQlAIANBf0obIAKgIgUgBaIiAiAFmqIiByACIAKioiACRKdGO4yHzcY+okR058ri+QAqv6CiIAcgAkSy+26JEBGBP6JEd6zLVFVVxb+goiAFoaC2IQAMAgsCQCADQQBIDQAgAkQYLURU+yH5v6AiAiACoiICRIFeDP3//9+/okQAAAAAAADwP6AgAiACoiIFREI6BeFTVaU/oqAgAiAFoiACRGlQ7uBCk/k+okQnHg/oh8BWv6CioLYhAAwCCyACRBgtRFT7Ifk/oCICIAKiIgJEgV4M/f//37+iRAAAAAAAAPA/oCACIAKiIgVEQjoF4VNVpT+ioCACIAWiIAJEaVDu4EKT+T6iRCceD+iHwFa/oKKgtowhAAwBCwJAIARBgICAzANJDQAgAiACoiIFIAKiIgcgBSAFoqIgBUSnRjuMh83GPqJEdOfK4vkAKr+goiAHIAVEsvtuiRARgT+iRHesy1RVVcW/oKIgAqCgtiEADAELIAEgAEMAAIADlCAAQwAAgHuSIARBgICABEkbOAIIIAEqAggaCyABQRBqJICAgIAAIAALCgAgABC/gYCAAAu0AgMDfwF9AnwjgICAgABBEGshAQJAAkAgALwiAkH/////B3EiA0GAgPCXBEsNACADQYGAgJgDTw0BIABDAACAP5IPCwJAAkAgA0GAgID8B0sNAAJAIAJB////lwRKDQAgAkEATg0DIAJB///XmHxLDQIgAkH//wNxRQ0DIAFDAQAAgCAAlTgCDCABKgIMGgwDCyAAQwAAAH+UIQALIAAPCyABQwEAAIAgAJU4AgwgASoCDBpDAAAAAA8LIABDAABASZIiBLxBCGoiA0EPcUEDdCsDoLjAgAAiBSAAIARDAABAyZKTuyIGRAAAAAC+v84/okQAAAAAQy7mP6AgBSAGoiIFoqAgBkQAAADAybKDP6JEAAAAgDRrrD+gIAYgBqIgBaKioCADQQR2Qf8Haq1CNIa/orYL+ggFAX8BfAJ/AnwBfyOAgICAAEEQayIBJICAgIAAIAC7IQICQAJAIAC8IgNB/////wdxIgRB25+k+gNJDQACQCAEQdKn7YMESQ0AAkAgBEHW44iHBEkNAAJAIARB////+wdLDQAgAUIANwMIAkACQCAEQdqfpO4ESw0AIAIgAkSDyMltMF/kP6JEAAAAAAAAOEOgRAAAAAAAADjDoCIFRAAAAFD7Ifm/oqAgBURjYhphtBBRvqKgIQYgBfwCIQQMAQsgASAEIARBF3ZB6n5qIgdBF3Rrvrs5AwAgAUEBIAFBCGpBASAHQQAQpIGAgAAhBAJAIANBAEgNACABKwMIIQYMAQtBACAEayEEIAErAwiaIQYLRAAAAAAAAPC/IAYgBiAGIAaiIgKiIgUgAkRyn5k4/RLBP6JEn8kYNE1V1T+goqAgBSACIAKiIgaiIAJEzjOMkPMdmT+iRP5ahh3JVKs/oCAGIAJEzRuXv7ligz+iRE707PytXWg/oKKgoqAiAqMgAiAEQQFxG7YhAAwECyAAIACTIQAMAwsCQCAEQeDbv4UESQ0ARBgtRFT7IRnARBgtRFT7IRlAIANBf0obIAKgIgYgBiAGIAaiIgKiIgYgAkRyn5k4/RLBP6JEn8kYNE1V1T+goqAgBiACIAKiIgWiIAJEzjOMkPMdmT+iRP5ahh3JVKs/oCAFIAJEzRuXv7ligz+iRE707PytXWg/oKKgoqC2IQAMAwtEAAAAAAAA8L9E0iEzf3zZEsBE0iEzf3zZEkAgA0F/ShsgAqAiBiAGIAYgBqIiAqIiBiACRHKfmTj9EsE/okSfyRg0TVXVP6CioCAGIAIgAqIiBaIgAkTOM4yQ8x2ZP6JE/lqGHclUqz+gIAUgAkTNG5e/uWKDP6JETvTs/K1daD+goqCioKO2IQAMAgsCQCAEQeSX24AESQ0ARBgtRFT7IQnARBgtRFT7IQlAIANBf0obIAKgIgYgBiAGIAaiIgKiIgYgAkRyn5k4/RLBP6JEn8kYNE1V1T+goqAgBiACIAKiIgWiIAJEzjOMkPMdmT+iRP5ahh3JVKs/oCAFIAJEzRuXv7ligz+iRE707PytXWg/oKKgoqC2IQAMAgtEAAAAAAAA8L9EGC1EVPsh+b9EGC1EVPsh+T8gA0F/ShsgAqAiBiAGIAYgBqIiAqIiBiACRHKfmTj9EsE/okSfyRg0TVXVP6CioCAGIAIgAqIiBaIgAkTOM4yQ8x2ZP6JE/lqGHclUqz+gIAUgAkTNG5e/uWKDP6JETvTs/K1daD+goqCioKO2IQAMAQsCQCAEQYCAgMwDSQ0AIAIgAqIiBiACoiIFIAZEcp+ZOP0SwT+iRJ/JGDRNVdU/oKIgAqAgBSAGIAaiIgKiIAZEzjOMkPMdmT+iRP5ahh3JVKs/oCACIAZEzRuXv7ligz+iRE707PytXWg/oKKgoqC2IQAMAQsgASAAQwAAgAOUIABDAACAe5IgBEGAgIAESRs4AgggASoCCBoLIAFBEGokgICAgAAgAAsKACAAEMKBgIAAC7wEBQF/An4BfAF/AXwjgICAgABBEGshAQJAAkAgAL0iAkIgiEL/////B4MiA0L/37+EBFYNACADQoCAwOQDWg0BIABEAAAAAAAA8D+gDwsCQAJAIAJCAFMNACADQv//v4QEVg0BCwJAAkAgA0L//7//B1YNACACQn9XDQEMAwtEAAAAAAAA8L8gAKMPCwJAIABEAAAAAADMkMBlRQ0AIAFEAAAAAAAAoLYgAKO2OAIMIAEqAgwaRAAAAAAAAAAADwsgAEQAAAAAAAAww6BEAAAAAAAAMEOgIABhDQEgAUQAAAAAAACgtiAAo7Y4AgwgASoCDBoMAQsgAEQAAAAAAADgf6IPCyAARAAAAAAAALhCoCIEvadBgAFqIgFBBHRB8B9xIgUrA6C5wIAAIgYgBiAAIAREAAAAAAAAuMKgoSAFKwOoucCAAKEiAKIgACAAIAAgAER0XIcDgNhVP6JEAAT3iKuygz+gokSmoATXCGusP6CiRHXFgv+9v84/oKJE7zn6/kIu5j+goqAhAAJAAkACQAJAIAFBCHUiAUH/B0oNACABQYJ4Tg0DIABEAAAAAAAAYAOiIQAgAUG4cE0NASABQckHaiEBDAMLIABEAAAAAAAA4H+iIQAgAUH+D0sNASABQYF4aiEBDAILIABEAAAAAAAAYAOiIQAgAUHwaCABQfBoSxtBkg9qIQEMAQsgAEQAAAAAAADgf6IhACABQf0XIAFB/RdJG0GCcGohAQsgACABQf8Haq1CNIa/ogsKACAAEMSBgIAAC8IMBQF9A38BfQR/A31DAACAPyECAkACQAJAIAC8IgNBgICA/ANGDQAgAbwiBEH/////B3EiBUUNAAJAAkACQCAAiyIGvCIHQYCAgPwHSw0AIAVBgICA/AdLDQAgA0EATg0BQQIhCCAFQf///9sESw0CIAVBgICA/ANJDQFBACEIIAVBlgEgBUEXdmsiCXYiCiAJdCAFRw0CQQIgCkEBcWshCAwCCyAAIAGSDwtBACEICwJAAkACQAJAAkAgBUGAgID8A0YNACAFQYCAgPwHRw0BAkACQCAHQYCAgPwDSiAHQYCAgPwDSGtB/wFxDgIHAQALQwAAAAAgAYwgBEF/ShsPCyABQwAAAAAgBEF/ShsPCyAEQX9MDQEgAA8LAkACQCAEQYCAgPgDRg0AIARBgICAgARHDQEgACAAlA8LIANBf0oNAgsCQAJAAkACQAJAAkAgB0UNACAHQf////8DcUGAgID8A0cNAQtDAACAPyAGlSAGIARBAEgbIQIgA0EATg0IIAcgCGpBgICA/ANHDQEgAiACkyIAIACVDwtDAACAPyELIANBAE4NAyAIDgIBAgMLIAKMIAIgCEEBRhsPCyAAIACTIgAgAJUPC0MAAIC/IQsLAkAgBUGAgIDoBEsNACAGQwAAgEuUvCAHIAdBgICABEkiAxsiCEH///8DcSIHQYCAgPwDciEFIAhBF3VB6X5BgX8gAxtqIQhBACEDAkAgB0HyiPMASQ0AAkAgB0HX5/YCTw0AQQEhAwwBCyAHQYCAgPgDciEFIAhBAWohCAsgA0ECdCIHKgKo2cCAAEMAAIA/IAcqAqDZwIAAIgAgBb4iDJKVIgIgDCAAkyIGIAVBAXZBgOD//wFxIANBFXRqQYCAgIICar4iDSAGIAKUIga8QYBgcb4iApSTIAAgDZMgDJIgApSTlCIAIAIgApQiDEMAAEBAkiAAIAYgApKUIAYgBpQiACAAlCAAIAAgACAAIABDQvFTPpRDVTJsPpKUQwWjiz6SlEOrqqo+kpRDt23bPpKUQ5qZGT+SlJIiDZK8QYBgcb4iAJQgBiANIABDAABAwJIgDJOTlJIiBiAGIAIgAJQiApK8QYBgcb4iACACk5NDTzh2P5QgAEPGI/a4lJKSIgIgByoCsNnAgAAiBiACIABDAEB2P5QiDJKSIAiyIgKSvEGAYHG+IgAgApMgBpMgDJOTIQIMAwsCQCAHQfj///sDSQ0AAkAgB0GHgID8A0sNACAGQwAAgL+SIgBDcKXsNpQgACAAlEMAAAA/IAAgAEMAAIC+lEOrqqo+kpSTlEM7qri/lJIiAiACIABDAKq4P5QiBpK8QYBgcb4iACAGk5MhAgwECwJAIARBAEoNACALQ2BCog2UQ2BCog2UDwsgC0PK8klxlEPK8klxlA8LAkAgBEEASA0AIAtDYEKiDZRDYEKiDZQPCyALQ8rySXGUQ8rySXGUDwtDAACAPyAAlQ8LIACRDwsCQAJAAkAgACAEQYBgcb4iBpQiDCABIAaTIACUIAEgApSSIgGSIgC8IgVBgICAmARKDQAgBUGAgICYBEYNASAAvEH/////B3EiA0GAgNiYBEsNBSAFQYCA2Jh8Rw0CIAEgACAMk19FDQIgC0NgQqINlENgQqINlA8LIAtDyvJJcZRDyvJJcZQPCyABQzyqODOSIAAgDJNeDQIgALxB/////wdxIQMLQQAhBAJAIANBgICA+ANNDQBBAEGAgIAEIANBF3ZBAmp2IAVqIgNB////A3FBgICABHJBFiADQRd2IgdrdiIEayAEIAVBAEgbIQQgASAMQYCAgHwgB0EBanUgA3G+kyIMkrwhBQsCQAJAIARBF3QgBUGAgH5xviIAQwByMT+UIgIgAEOMvr81lCABIAAgDJOTQxhyMT+UkiIGkiIAIAAgACAAIACUIgEgASABIAEgAUNMuzEzlEMO6t21kpRDVbOKOJKUQ2ELNruSlEOrqio+kpSTIgGUIAFDAAAAwJKVIAYgACACk5MiASAAIAGUkpOTQwAAgD+SIgC8aiIFQYCAgARIDQAgBb4hAAwBCyAAIAQQtIGAgAAhAAsgCyAAlCECCyACDwsgC0PK8klxlEPK8klxlA8LIAtDYEKiDZRDYEKiDZQLDAAgACABEMaBgIAAC04BAX4CQAJAIANBwABxDQAgA0UNASACIAOtIgSGIAFBACADa62IhCECIAEgBIYhAQwBCyABIAOthiECQgAhAQsgACABNwMAIAAgAjcDCAtIAQF/I4CAgIAAQSBrIgUkgICAgAAgBSABIAIgAyAEELeBgIAAIAUpAxAhBCAAIAUpAxg3AwggACAENwMAIAVBIGokgICAgAALiwYEAX8BfgF/BHwjgICAgABBEGsiASAAOQMIAkACQAJAAkACQAJAAkACQCAAvSICQiCIp0H/////B3EiA0H50I2CBEsNACADQcLc2P4DSw0CIANBgIDA5ANJDQFEAAAAAAAAAAAhBEEAIQMMBgsgACAAYg0GAkAgAkIAWQ0ARAAAAAAAAPC/DwsgAETvOfr+Qi6GQGRFDQIgAEQAAAAAAADgf6IPCyADQYCAwABPDQUgASsDCBogAA8LIANBssXC/wNJDQELIABE/oIrZUcV9z+iRAAAAAAAAOA/IACmoPwCIgO3IgREdjx5Ne856j2iIQUgACAERAAA4P5CLua/oqAhBAwBCwJAIAJCf1UNACAARAAA4P5CLuY/oCEERHY8eTXvOeq9IQVBfyEDDAELIABEAADg/kIu5r+gIQREdjx5Ne856j0hBUEBIQMLIAQgBCAFoSIAoSAFoSEECyAAIABEAAAAAAAA4D+iIgaiIgUgBSAFIAUgBSAFRC3DCW63/Yq+okQ5UuaGys/QPqCiRLfbqp4ZzhS/oKJEhVX+GaABWj+gokT0EBERERGhv6CiRAAAAAAAAPA/oCIHRAAAAAAAAAhAIAYgB6KhIgahRAAAAAAAABhAIAAgBqKho6IhBgJAIAMNACAAIAAgBqIgBaGhDwsgACAGIAShoiAEoSAFoSEFAkACQAJAIANBAWoOAwACAQILIAAgBaFEAAAAAAAA4D+iRAAAAAAAAOC/oA8LAkAgAEQAAAAAAADQv2MNACAAIAWhIgAgAKBEAAAAAAAA8D+gDwsgBSAARAAAAAAAAOA/oKFEAAAAAAAAAMCiDwsgA0H/B2qtQjSGvyEEAkAgA0E5SQ0AIAAgBaFEAAAAAAAA8D+gIgAgAKBEAAAAAAAA4H+iIAAgBKIgA0GACEYbRAAAAAAAAPC/oA8LIANB/wdzrUI0hr8hBgJAAkAgA0EUSQ0AIAAgBSAGoKFEAAAAAAAA8D+gIQAMAQtEAAAAAAAA8D8gBqEgACAFoaAhAAsgACAEoiEACyAAC5oCAwF/AXwBfiOAgICAAEEQayIBJICAgIAAAkACQAJAIACZIgK9IgNC/////6/95PA/Vg0AIANC/////++Vlug/Vg0BAkAgA0L/////////B1YNACABIAK2OAIMIAEqAgwaDAMLIAJEAAAAAAAAAMCiEMqBgIAAIgKaIAJEAAAAAAAAAECgoyECDAILAkAgA0L/////j4CAmsAAVg0ARAAAAAAAAPA/RAAAAAAAAABAIAIgAqAQyoGAgABEAAAAAAAAAECgo6EhAgwCC0QAAAAAAAAAgCACo0QAAAAAAADwP6AhAgwBCyACIAKgEMqBgIAAIgIgAkQAAAAAAAAAQKCjIQILIAFBEGokgICAgAAgApogAiAAvUIAUxsLngQEAX8BfgJ/A3wjgICAgABBEGshAQJAAkACQAJAAkACQCAAvSICQiCIp0H/////B3EiA0H//7+gBEsNACADQYCA8P4DSQ0BIACZIQAgA0GAgMz/A0kNAyADQYCAjoAESQ0CRAAAAAAAAPC/IACjIQBBAyEEDAQLIAAgAGINBEQYLURU+yH5PyAApg8LQX8hBCADQYCAgPIDTw0CIANBgIDAAE8NAyABIAC2OAIMIAEqAgwaIAAPCyAARAAAAAAAAPi/oCAARAAAAAAAAPg/okQAAAAAAADwP6CjIQBBAiEEDAELAkAgA0GAgJj/A0kNACAARAAAAAAAAPC/oCAARAAAAAAAAPA/oKMhAEEBIQQMAQsgACAAoEQAAAAAAADwv6AgAEQAAAAAAAAAQKCjIQBBACEECyAAIACiIgUgBaIiBiAGIAYgBiAGRC9saixEtKK/okSa/d5SLd6tv6CiRG2adK/ysLO/oKJEcRYj/sZxvL+gokTE65iZmZnJv6CiIQcgBSAGIAYgBiAGIAZEEdoi4zqtkD+iROsNdiRLe6k/oKJEUT3QoGYNsT+gokRuIEzFzUW3P6CiRP+DAJIkScI/oKJEDVVVVVVV1T+goiEGAkAgA0GAgPD+A0kNACAEQQN0IgMrA7jZwIAAIAAgByAGoKIgAysD2NnAgAChIAChoSIAmiAAIAJCAFMbDwsgACAAIAcgBqCioSEACyAACwoAIAAQzIGAgAALC9ddAgBBgIDAAAv4WRZzbGljZSBpbmRleCBzdGFydHMgYXQgwA0gYnV0IGVuZHMgYXQgwAAgaW5kZXggb3V0IG9mIGJvdW5kczogdGhlIGxlbiBpcyDAEiBidXQgdGhlIGluZGV4IGlzIMAAEnJhbmdlIHN0YXJ0IGluZGV4IMAiIG91dCBvZiByYW5nZSBmb3Igc2xpY2Ugb2YgbGVuZ3RoIMAAEHJhbmdlIGVuZCBpbmRleCDAIiBvdXQgb2YgcmFuZ2UgZm9yIHNsaWNlIG9mIGxlbmd0aCDAABFtaW4gPiBtYXguIG1pbiA9IMAILCBtYXggPSDAACRtaW4gPiBtYXgsIG9yIGVpdGhlciB3YXMgTmFOLiBtaW4gPSDACCwgbWF4ID0gwAAQYXNzZXJ0aW9uIGBsZWZ0IMAXIHJpZ2h0YCBmYWlsZWQKICBsZWZ0OiDACQogcmlnaHQ6IMAAc3JjL2tleXMvcm90YXJ5LnJzAHNyYy9rZXlzL2NsYXYucnMAL3J1c3RjLzU4Y2Y4ZjljMzViMzU1MTk5NzI3NjI3ZDA3YWUzNGE0ZTI4NDZkNjcvbGlicmFyeS9jb3JlL3NyYy9udW0vaW1wL2ZsdDJkZWMvc3RyYXRlZ3kvZ3Jpc3UucnMAL3J1c3RjLzU4Y2Y4ZjljMzViMzU1MTk5NzI3NjI3ZDA3YWUzNGE0ZTI4NDZkNjcvbGlicmFyeS9jb3JlL3NyYy9udW0vaW1wL2RpeV9mbG9hdC5ycwBzcmMvZHJ1bXMucnMAL3J1c3RjLzU4Y2Y4ZjljMzViMzU1MTk5NzI3NjI3ZDA3YWUzNGE0ZTI4NDZkNjcvbGlicmFyeS9zdGQvc3JjL3N5cy9zeW5jL3J3bG9jay9ub190aHJlYWRzLnJzAHNyYy9rZXlzL2NvbW1vbi5ycwAvcnVzdGMvNThjZjhmOWMzNWIzNTUxOTk3Mjc2MjdkMDdhZTM0YTRlMjg0NmQ2Ny9saWJyYXJ5L2NvcmUvc3JjL251bS9pbXAvZmx0MmRlYy9zdHJhdGVneS9kcmFnb24ucnMAL3J1c3RjLzU4Y2Y4ZjljMzViMzU1MTk5NzI3NjI3ZDA3YWUzNGE0ZTI4NDZkNjcvbGlicmFyeS9jb3JlL3NyYy9udW0vaW1wL2JpZ251bS5ycwBzcmMva2V5cy90b25ld2hlZWwucnMAc3JjL2tleXMvcGx1Y2sucnMAc3JjL2tleXMvc3RyaW5nLnJzAHNyYy9rZXlzL3RpbmUucnMAc3JjL292ZXJzYW1wbGUucnMAL3J1c3RjLzU4Y2Y4ZjljMzViMzU1MTk5NzI3NjI3ZDA3YWUzNGE0ZTI4NDZkNjcvbGlicmFyeS9hbGxvYy9zcmMvcmF3X3ZlYy9tb2QucnMAL3J1c3RjLzU4Y2Y4ZjljMzViMzU1MTk5NzI3NjI3ZDA3YWUzNGE0ZTI4NDZkNjcvbGlicmFyeS9jb3JlL3NyYy9udW0vaW1wL2ZsdDJkZWMvbW9kLnJzAHNyYy9rZXlzL3JlZWQucnMAL3J1c3QvZGVwcy9kbG1hbGxvYy0wLjIuMTQvc3JjL2RsbWFsbG9jLnJzAHNyYy9rZXlzL2VsZWN0cmljLnJzAC9ydXN0Yy81OGNmOGY5YzM1YjM1NTE5OTcyNzYyN2QwN2FlMzRhNGUyODQ2ZDY3L2xpYnJhcnkvY29yZS9zcmMvbnVtL2Y2NC5ycwAvcnVzdGMvNThjZjhmOWMzNWIzNTUxOTk3Mjc2MjdkMDdhZTM0YTRlMjg0NmQ2Ny9saWJyYXJ5L2NvcmUvc3JjL251bS9mMzIucnMAAAsFEABLAAAARQYAAAkAAAC/BBAASwAAADEGAAAJAAAAswMQABEAAABtAAAACQAAALMDEAARAAAAbgAAAAkAAAAAAAAAAADwPwAAAAAAAPA/AAAAAAAAQEAAAAAAAADwPwEAAAAAAAAAzczMzMzM9D8AAAAAAADwPwAAAAAAAERArkfhehSu8z8AAAAAAAAAAOxRuB6F6/E/mpmZmZmZ+T8AAAAAAABPQK5H4XoUrvM/AAAAAAAAAABVARAAEgAAAG4AAAAcAAAAVQEQABIAAACNAAAAEgAAAFUBEAASAAAAjgAAABIAAADg8Jx2Lxv0v+DwnHYvG/Q/jwMQABIAAADJAAAAGgAAAI8DEAASAAAAygAAABoAAACPAxAAEgAAALAAAAAaAAAAjwMQABIAAAC+AAAAEgAAAI8DEAASAAAAtwAAAB0AAACPAxAAEgAAANIAAAASAAAAZwMQABUAAABuAAAAMAAAALMDEAARAAAAdAAAABIAAAAAAAAAAACAPwAAAABoARAAEAAAAAQBAAAlAAAAaAEQABAAAAAnAQAADAAAAGgBEAAQAAAALQEAACMAAABoARAAEAAAADgBAAAlAAAAaAEQABAAAABKAQAAKwAAAGgBEAAQAAAAFAEAABgAAABoARAAEAAAABUBAAA6AAAAaAEQABAAAAAVAQAAHwAAAGgBEAAQAAAAGgEAAB8AAABoARAAEAAAABsBAAAJAAAAaAEQABAAAABdAQAAGAAAAKoEEAAUAAAAywAAAC0AAACqBBAAFAAAAM8AAAAbAAAAqgQQABQAAADFAAAAEgAAAKoEEAAUAAAAAgEAACEAAACqBBAAFAAAAAwBAAANAAAAqgQQABQAAACnAAAAGgAAAKoEEAAUAAAAqAAAABkAAACqBBAAFAAAALAAAAAgAAAAqgQQABQAAACxAAAAQAAAAKoEEAAUAAAAsQAAACcAAACqBBAAFAAAALYAAAAnAAAAqgQQABQAAAC2AAAAEQAAAKoEEAAUAAAAugAAACEAAACdAhAAEgAAAG4BAAAJAAAAZwMQABUAAAC+AQAAJwAAAPT///8HAAAAAAAAAAwAAAATAAAAGAAAABwAAAAfAAAAJAAAAGcDEAAVAAAAgAEAAA0AAABnAxAAFQAAAEIBAAAQAAAAZwMQABUAAABKAQAAHgAAAGcDEAAVAAAATwEAAB4AAABnAxAAFQAAAE8BAAARAAAAswMQABEAAADJAAAAFgAAADICEAAMAAAAewEAABsAAAAyAhAADAAAAKIBAAAdAAAAMgIQAAwAAAAbAgAAGQAAAJ0CEAASAAAAXQEAABIAAACdAhAAEgAAAD4BAAASAAAAnQIQABIAAABJAQAACQAAAJ0CEAASAAAATAEAABgAAACdAhAAEgAAAFcBAAAYAAAAnQIQABIAAABSAQAAGgAAAJ0CEAASAAAAkgEAAAoAAACdAhAAEgAAAJIBAAASAAAAMgIQAAwAAADaAwAAKgAAADICEAAMAAAA3wMAAB4AAAAyAhAADAAAAOADAAASAAAAMgIQAAwAAADgAwAACQAAADICEAAMAAAABQQAABIAAAAyAhAADAAAAEsEAAAUAAAACQAAAGATAAAIAAAACgAAAAsAAAAMAAAADQAAAA4AAAAPAAAAEAAAABEAAABwEQAACAAAABIAAAATAAAAFAAAABUAAAAWAAAAFwAAABgAAAAZAAAAuGkAAAgAAAAaAAAAGwAAABwAAAAdAAAAHgAAAB8AAAAgAAAAIQAAAHARAAAIAAAAIgAAACMAAAAkAAAAFQAAACUAAAAmAAAAJwAAACgAAABoFwAACAAAACkAAAAqAAAAKwAAACwAAAAtAAAALgAAAC8AAAAyAhAADAAAAMwAAAArAAAAfQMQABEAAACmAAAANgAAAH0DEAARAAAAvAAAAC8AAAB9AxAAEQAAAMgAAAATAAAAfQMQABEAAADHAAAAHwAAAKoEEAAUAAAAfAAAAB8AAACqBBAAFAAAAIMAAAAcAAAAAABAQGZm5j9mZmZAzcwswGZmJkDNzCxAAAAgQAAAIEDNzIw/zcwsQGZmlkDNzMy9zczMPzMzU8DNzIw/zcyMPzMzE0DNzExAmpkZP2ZmJkAzM/O/zcwMQM3MzL6amZm+MgIQAAwAAABZAAAAEQAAAJ0CEAASAAAAJQEAAAwAAAB9AxAAEQAAAGMBAAANAAAAfQMQABEAAABIAQAAIwAAAH0DEAARAAAAHQEAAB8AAAB9AxAAEQAAACEBAAAnAAAAfQMQABEAAAAsAQAAMgAAAH0DEAARAAAABwEAAEcAAABoARAAEAAAAAICAAANAAAAaAEQABAAAADmAQAAIwAAAGgBEAAQAAAAwwEAADQAAABoARAAEAAAAN0BAAARAAAAaAEQABAAAACNAQAAHwAAAAAAAAAAABRAAAAAAAAAJEAAAAAAAAAyQGcDEAAVAAAAqAIAAA0AAABnAxAAFQAAAHkCAAAjAAAAZwMQABUAAABvAgAAFAAAAGcDEAAVAAAAXgIAACYAAABnAxAAFQAAAGMCAAAjAAAAZwMQABUAAABmAgAAIwAAAGcDEAAVAAAAIAIAABoAAABnAxAAFQAAAOoBAAAVAAAAbgQQABAAAADYAAAADQAAAG4EEAAQAAAAuQAAACMAAABuBBAAEAAAAKIAAAAfAAAAogMQABAAAAASAQAADQAAAKIDEAAQAAAA5wAAACMAAACiAxAAEAAAANAAAAAfAAAAAAECAwRjYXBhY2l0eSBvdmVyZmxvdwAAxQMQAFAAAAAcAAAABQAAADAxMjM0NTY3ODlhYmNkZWYAAAAABAAAAAQAAAAwAAAALStOYU5pbmYwMC4wZTBhc3NlcnRpb24gZmFpbGVkOiBidWYubGVuKCkgPj0gbWF4bGVuABYEEABXAAAAiwIAAA0AAADcARAAVQAAAC4AAAAJAAAAYXNzZXJ0aW9uIGZhaWxlZDogb3RoZXIgPiAwYXNzZXJ0aW9uIGZhaWxlZDogbm9ib3Jyb3cAAAAUAxAAUgAAAIQBAAABAAAAYXNzZXJ0aW9uIGZhaWxlZDogZGlnaXRzIDwgNDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwPT0wMDAxMDIwMzA0MDUwNjA3MDgwOTEwMTExMjEzMTQxNTE2MTcxODE5MjAyMTIyMjMyNDI1MjYyNzI4MjkzMDMxMzIzMzM0MzUzNjM3MzgzOTQwNDE0MjQzNDQ0NTQ2NDc0ODQ5NTA1MTUyNTM1NDU1NTY1NzU4NTk2MDYxNjI2MzY0NjU2NjY3Njg2OTcwNzE3MjczNzQ3NTc2Nzc3ODc5ODA4MTgyODM4NDg1ODY4Nzg4ODk5MDkxOTI5Mzk0OTU5Njk3OTg5OS5hdHRlbXB0IHRvIGRpdmlkZSBieSB6ZXJvYXNzZXJ0aW9uIGZhaWxlZDogIWJ1Zi5pc19lbXB0eSgpAAAWBBAAVwAAALcAAAAFAAAAYXNzZXJ0aW9uIGZhaWxlZDogYnVmWzBdID4gYicwJwAWBBAAVwAAALgAAAAFAAAAFgQQAFcAAAAJAQAABQAAABYEEABXAAAACgEAAAUAAABlZS0AAAAAAN9FGj0DzxrmwfvM/gAAAADKxprHF/5wq9z71P4AAAAAT9y8vvyxd//2+9z+AAAAAAzWa0HvkVa+Efzk/gAAAAA8/H+QrR/QjSz87P4AAAAAg5pVMShcUdNG/PT+AAAAALXJpq2PrHGdYfz8/gAAAADLi+4jdyKc6nv8BP8AAAAAbVN4QJFJzK6W/Az/AAAAAFfOtl15EjyCsfwU/wAAAAA3VvtNNpQQwsv8HP8AAAAAT5hIOG/qlpDm/CT/AAAAAMc6giXLhXTXAP0s/wAAAAD0l7+Xzc+GoBv9NP8AAAAA5awqF5gKNO81/Tz/AAAAAI6yNSr7ZziyUP1E/wAAAAA7P8bS39TIhGv9TP8AAAAAus3TGidE3cWF/VT/AAAAAJbJJbvOn2uToP1c/wAAAACEpWJ9JGys27r9ZP8AAAAA9tpfDVhmq6PV/Wz/AAAAACbxw96T+OLz7/10/wAAAAC4gP+qqK21tQr+fP8AAAAAi0p8bAVfYocl/oT/AAAAAFMwwTRg/7zJP/6M/wAAAABVJrqRjIVOllr+lP8AAAAAvX4pcCR3+d90/pz/AAAAAI+45bifvd+mj/6k/wAAAACUfXSIz1+p+Kn+rP8AAAAAz5uoj5NwRLnE/rT/AAAAAGsVD7/48AiK3/68/wAAAAC2MTFlVSWwzfn+xP8AAAAArH970MbiP5kU/8z/AAAAAAY7KyrEEFzkLv/U/wAAAADTknNpmSQkqkn/3P8AAAAADsoAg/K1h/1j/+T/AAAAAOsaEZJkCOW8fv/s/wAAAADMiFBvCcy8jJn/9P8AAAAALGUZ4lgXt9Gz//z/AAAAAAAAAAAAAECczv8EAAAAAAAAAAAAEKXU6Oj/DAAAAAAAAABirMXreK0DABQAAAAAAIQJlPh4OT+BHgAcAAAAAACzFQfJe86XwDgAJAAAAAAAcFzqe84yfo9TACwAAAAAAGiA6aukONLVbQA0AAAAAABFIpoXJidPn4gAPAAAAAAAJ/vE1DGiY+2iAEQAAAAAAKityIw4Zd6wvQBMAAAAAADbZasajgjHg9gAVAAAAAAAmh1xQvkdXcTyAFwAAAAAAFjnG6YsaU2SDQFkAAAAAADqjXAaZO4B2icBbAAAAAAASnfvmpmjbaJCAXQAAAAAAIVrfbR7eAnyXAF8AAAAAAB3GN15oeRUtHcBhAAAAAAAwsWbW5KGW4aSAYwAAAAAAD1dlsjFUzXIrAGUAAAAAACzoJf6XLQqlccBnAAAAAAA41+gmb2fRt7hAaQAAAAAACWMOds0wpul/AGsAAAAAABcn5ijcprG9hYCtAAAAAAAzr7pVFO/3LcxArwAAAAAAOJBIvIX8/yITALEAAAAAACleFzTm84gzGYCzAAAAAAA31Mhe/NaFpiBAtQAAAAAADowH5fctaDimwLcAAAAAACWs+NcU9HZqLYC5AAAAAAAPESnpNl8m/vQAuwAAAAAABBEpKdMTHa76wL0AAAAAAAanEC2746riwYD/AAAAAAALIRXphDvH9AgAwQBAAAAACkxkenlpBCbOwMMAQAAAACdDJyh+5sQ51UDFAEAAAAAKfQ7YtkgKKxwAxwBAAAAAIXPp3peS0SAiwMkAQAAAAAt3awDQOQhv6UDLAEAAAAAj/9EXi+cZ47AAzQBAAAAAEG4jJydFzPU2gM8AQAAAACpG+O0ktsZnvUDRAEAAAAA2Xffum6/lusPBEwBAAAAAGFzc2VydGlvbiBmYWlsZWQ6IGQubWFudCA+IDB5ARAAYgAAAN4BAAAFAAAAeQEQAGIAAAB/AAAAFQAAAHkBEABiAAAANQIAABEAAAB5ARAAYgAAAG4CAAAJAAAAeQEQAGIAAACrAAAABQAAAGFzc2VydGlvbiBmYWlsZWQ6IGQubWludXMgPiAwAAAAeQEQAGIAAACsAAAABQAAAGFzc2VydGlvbiBmYWlsZWQ6IGQucGx1cyA+IDB5ARAAYgAAAK0AAAAFAAAAYXNzZXJ0aW9uIGZhaWxlZDogZC5tYW50ICsgZC5wbHVzIDwgKDEgPDwgNjEpAAAAeQEQAGIAAACxAAAABQAAAHkBEABiAAAADAEAABEAAAB5ARAAYgAAAEIBAAAJAAAAYXNzZXJ0aW9uIGZhaWxlZDogZC5tYW50LmNoZWNrZWRfc3ViKGQubWludXMpLmlzX3NvbWUoKQB5ARAAYgAAAK8AAAAFAAAAYXNzZXJ0aW9uIGZhaWxlZDogZC5tYW50LmNoZWNrZWRfYWRkKGQucGx1cykuaXNfc29tZSgpAAB5ARAAYgAAAK4AAAAFAAAAsAIQAGMAAAANAQAABQAAALACEABjAAAADgEAAAUAAACwAhAAYwAAAA8BAAAFAAAAsAIQAGMAAAB0AQAAJAAAALACEABjAAAAeQEAAC8AAACwAhAAYwAAAIYBAAASAAAAsAIQAGMAAABoAQAADQAAALACEABjAAAATgEAACIAAACwAhAAYwAAABEBAAAFAAAAsAIQAGMAAAAQAQAABQAAALACEABjAAAAeAAAAAUAAACwAhAAYwAAAHkAAAAFAAAAsAIQAGMAAAB6AAAABQAAALACEABjAAAAxAAAAAkAAACwAhAAYwAAAP0AAAANAAAAsAIQAGMAAAAEAQAAEgAAALACEABjAAAAfAAAAAUAAACwAhAAYwAAAHsAAAAFAAAAAQAAAAoAAABkAAAA6AMAABAnAACghgEAQEIPAICWmAAA4fUFAMqaO8Fv8oYjAAAAge+shVtBbS3uBAAAAR9qv2TtOG7tl6fa9Pk/6QNPGAABPpUuCZnfA/04FQ8v5HQj7PXP0wjcBMTasM28GX8zpgMmH+lOAgAAAXwumFuH075yn9nYhy8VEsZQ3mtwbkrPD9iV1W5xsiawZsatJDYVHVrTQjwOVP9jwHNVzBfv+WXyKLxV98fcgNztbvTO79xf91MFAHkBEABiAAAA8QIAACYAAAB5ARAAYgAAAOUCAAAmAAAAeQEQAGIAAADOAgAAJgAAADB4MDEyMzQ1Njc4OUFCQ0RFRgAAMQAAAAwAAAAEAAAAMgAAADMAAAA0AAAAAAAAAAgAAAAEAAAANQAAADYAAAA3AAAAOAAAADkAAAAQAAAABAAAADoAAAA7AAAAPAAAAD0AAABc9ulf3AL2ufHBcGzyYcEkOzdNSoIQRQnDpWHRPyA6j2Fzc2VydGlvbiBmYWlsZWQ6IHBzaXplID49IHNpemUgKyBtaW5fb3ZlcmhlYWQAAH8EEAAqAAAA6QQAAAkAAABhc3NlcnRpb24gZmFpbGVkOiBwc2l6ZSA8PSBzaXplICsgbWF4X292ZXJoZWFkAAB/BBAAKgAAAO8EAAANAAAAfwQQACoAAABNBQAAHgAAAHJ3bG9jayBvdmVyZmxvd2VkIHJlYWQgbG9ja3M/AhAAXQAAABgAAAAsAAAAAAAAAAgAAAAEAAAAPgAAADEAAAAMAAAABAAAAD8AAAALBQYBAQAAAEgLEAB0CxAAiAsQAKALEACkCxAACwUGEAsAAAAAAAA/AAAAvwMAAAAEAAAABAAAAAYAAACD+aIARE5uAPwpFQDRVycA3TT1AGLbwAA8mZUAQZBDAGNR/gC73qsAt2HFADpuJADSTUIASQbgAAnqLgAcktEA6x3+ACmxHADoPqcA9TWCAES7LgCc6YQAtCZwAEF+XwDWkTkAU4M5AJz0OQCLX4QAKPm9APgfOwDe/5cAD5gFABEv7wAKWosAbR9tAM9+NgAJyycARk+3AJ5mPwAt6l8Auid1AOXrxwA9e/EA9zkHAJJSigD7a+oAH7FfAAhdjQAwA1YAe/xGAPCrawAgvM8ANvSaAOOpHQBeYZEACBvmAIWZZQCgFF8AjUBoAIDY/wAnc00ABgYxAMpWFQDJqHMAe+JgAGuMwAAAAABA+yH5PwAAAAAtRHQ+AAAAgJhG+DwAAABgUcx4OwAAAICDG/A5AAAAQCAlejgAAACAIoLjNgAAAAAd82k1AAAAAAAA4D8AAAAAAADgvwAAAAAAAPA/AAAAAAAA+D8AAAAAAAAAAAbQz0Pr/Uw+AAAAAAAAAAAAAABAA7jiP807f2aeoOY/hwHrcxSh5z/boCpC5azoP5Dwo4KRxOk/rdNamZ/o6j+cUoXdmxnsP4ek+9wYWO0/2pCkoq+k7j8AAAAAAADwPw+J+WxYtfA/e1F9PLhy8T84YnVuejjyPxW3MQr+BvM/IjQSTKbe8z8nKjbV2r/0PylUSN0Hq/U/XT1/Zp6g5j8AAAAAAIg5PUQXdfpSsOY/AAAAAAAA2Dz+2Qt1EsDmPwAAAAAAeCi9v3bU3dzP5j8AAAAAAMAePSkaZTyy3+Y/AAAAAAAA2LzjOlmYku/mPwAAAAAAALy8hpNR+X3/5j8AAAAAANgvvaMt9GZ0D+c/AAAAAACILL3DX+zodR/nPwAAAAAAwBM9Bc/qhoIv5z8AAAAAADA4vVKBpUiaP+c/AAAAAADAAL38zNc1vU/nPwAAAAAAiC898WdCVutf5z8AAAAAAOADPUhtq7EkcOc/AAAAAADQJ704Xd5PaYDnPwAAAAAAAN28AB2sOLmQ5z8AAAAAAADjPHgB63MUoec/AAAAAAAA7bxg0HYJe7HnPwAAAAAAQCA9M8EwAe3B5z8AAAAAAACgPDaG/2Jq0uc/AAAAAACQJr07Ts828+LnPwAAAAAA4AK96MORhIfz5z8AAAAAAFgkvU4bPlQnBOg/AAAAAAAAMz0aB9Gt0hToPwAAAAAAAA89fs1MmYkl6D8AAAAAAMAhvdBCuR5MNug/AAAAAADQKT21yiNGGkfoPwAAAAAAEEc9vFufF/RX6D8AAAAAAGAiPa+RRJvZaOg/AAAAAADEMr2VozHZynnoPwAAAAAAACO9uGWK2ceK6D8AAAAAAIAqvQBYeKTQm+g/AAAAAAAA7bwjoipC5azoPwAAAAAAKDM9+hnWugW+6D8AAAAAALRCPYNDtRYyz+g/AAAAAADQLr1MZgheauDoPwAAAAAAUCC9B3gVma7x6D8AAAAAACgoPQ4sKND+Auk/AAAAAACwHL2W/5ELWxTpPwAAAAAA4AW9+S+qU8Ml6T8AAAAAAED1PErGzbA3N+k/AAAAAAAgFz2umF8ruEjpPwAAAAAAAAm9y1LIy0Ra6T8AAAAAAGglPSFvdprda+k/AAAAAADQNr0qTt6fgn3pPwAAAAAAAAG9oyN65DOP6T8AAAAAAAAtPQQGynDxoOk/AAAAAACkOL2J/1NNu7LpPwAAAAAAXDU9W/GjgpHE6T8AAAAAALgmPcW4Sxl01uk/AAAAAAAA7LyOI+MZY+jpPwAAAAAA0Bc9AvMHjV766T8AAAAAAEAWPU3lXXtmDOo/AAAAAAAA9bz2uI7teh7qPwAAAAAA4Ak9Jy5K7Jsw6j8AAAAAANgqPV0KRoDJQuo/AAAAAADwGr2bJT6yA1XqPwAAAAAAYAs9E2L0ikpn6j8AAAAAAIg4PaezMBOeeeo/AAAAAAAgET2NLsFT/ovqPwAAAAAAwAY90vx5VWue6j8AAAAAALgpvbhvNSHlsOo/AAAAAABwKz2B89O/a8PqPwAAAAAAANk8gCc8Ov/V6j8AAAAAAADkPKPSWpmf6Oo/AAAAAACQLL1n8yLmTPvqPwAAAAAAUBY9kLeNKQcO6z8AAAAAANQvPamJmmzOIOs/AAAAAABwEj1LGk+4ojPrPwAAAAAAR00950e3FYRG6z8AAAAAADg4vTpZ5Y1yWes/AAAAAAAAmDxqxfEpbmzrPwAAAAAA0Ao9UF778nZ/6z8AAAAAAIDePLJJJ/KMkus/AAAAAADABL0DBqEwsKXrPwAAAAAAcA29Zm+at+C46z8AAAAAAJANPf/BS5AezOs/AAAAAACgAj1vofPDad/rPwAAAAAAeB+9uB3XW8Ly6z8AAAAAAKAQvemyQWEoBuw/AAAAAABAEb3gUoXdmxnsPwAAAAAA4As97mT62Rwt7D8AAAAAAEAJvS/Q/1+rQOw/AAAAAADQDr0V/fp4R1TsPwAAAAAAZjk9y9BXLvFn7D8AAAAAABAavbbBiImoe+w/AAAAAIBFWL0z5waUbY/sPwAAAAAASBq938RRV0Cj7D8AAAAAAADLPJSQ79wgt+w/AAAAAABAAT2JFm0uD8vsPwAAAAAAIPA8EsRdVQvf7D8AAAAAAGDzPDurW1sV8+w/AAAAAACQBr28iQdKLQftPwAAAAAAoAk9+sgIK1Mb7T8AAAAAAOAVvYWKDQiHL+0/AAAAAAAoHT0DosrqyEPtPwAAAAAAoAE9kaT73BhY7T8AAAAAAADfPKHmYuh2bO0/AAAAAACgA71Og8kW44DtPwAAAAAA2Ay9kGD/cV2V7T8AAAAAAMD0PK4y2wPmqe0/AAAAAACQ/zwlgzrWfL7tPwAAAAAAgOk8RbQB8yHT7T8AAAAAACD1vL8FHGTV5+0/AAAAAABwHb3smnszl/ztPwAAAAAAFBa9Xn0Za2cR7j8AAAAAAEgLPeej9RRGJu4/AAAAAADOQD1c7hY7MzvuPwAAAAAAaAw9tD+L5y5Q7j8AAAAAADAJvWhtZyQ5Ze4/AAAAAAAA5bxETMf7UXruPwAAAAAA+Ae9JrfNd3mP7j8AAAAAAHDzvOiQpKKvpO4/AAAAAADQ5TzkynyG9LnuPwAAAAAAGhY9DWiOLUjP7j8AAAAAAFD1PBSFGKKq5O4/AAAAAABAxjwTWmHuG/ruPwAAAAAAgO68BkG2HJwP7z8AAAAAAIj6vGO5azcrJe8/AAAAAACQLL11ct1IyTrvPwAAAAAAAKo8JEVuW3ZQ7z8AAAAAAPD0vP1EiHkyZu8/AAAAAACAyjw4vpyt/XvvPwAAAAAAvPo8gjwkAtiR7z8AAAAAAGDUvI6QnoHBp+8/AAAAAAAMC70R1ZI2ur3vPwAAAAAA4MC8lHGPK8LT7z8AAAAAgN4Qve4jKmvZ6e8/AAAAAABD7jwAAAAAAADwPwAAAAAAAAAAvrxa+hoL8D8AAAAAAECzvAMz+6k9FvA/AAAAAAAXEr2CAjsUaCHwPwAAAAAAQLo8bIB3Ppos8D8AAAAAAJjvPMq7ES7UN/A/AAAAAABAx7yJf27oFUPwPwAAAAAAMNg8Z1T2cl9O8D8AAAAAAD8avVqFFdOwWfA/AAAAAACEAr2VHzwOCmXwPwAAAAAAYPE8GvfdKWtw8D8AAAAAACQVPS2ocivUe/A/AAAAAACg6bzQm3UYRYfwPwAAAAAAQOY8yAdm9r2S8D8AAAAAAHgAvYPzxso+nvA/AAAAAAAAmLwwOR+bx6nwPwAAAAAAoP88/Ij5bFi18D8AAAAAAMj6vIps5EXxwPA/AAAAAADA2TwWSHIrkszwPwAAAAAAIAU92F05IzvY8D8AAAAAAND6vPPR0zLs4/A/AAAAAACsGz2mqd9fpe/wPwAAAAAA6AS98NL+r2b78D8AAAAAADANvUsj1ygwB/E/AAAAAABQ8TxbWxLQARPxPwAAAAAAAOw8+Speq9se8T8AAAAAALwWPdUxbMC9KvE/AAAAAABA6Dx9BPIUqDbxPwAAAAAA0A696S2prppC8T8AAAAAAODoPDgxT5OVTvE/AAAAAABA6zxxjqXImFrxPwAAAAAAMAU938NxVKRm8T8AAAAAADgDPRFSfTy4cvE/AAAAAADUKD2fu5WG1H7xPwAAAAAA0AW9k42MOPmK8T8AAAAAAIgcvWZdN1gml/E/AAAAAADwET2ny2/rW6PxPwAAAAAASBA944cT+Jmv8T8AAAAAADlHvVRdBITgu/E/AAAAAADkJD1DHCiVL8jxPwAAAAAAIAq9srloMYfU8T8AAAAAAIDjPDFAtF7n4PE/AAAAAADA6jw42fwiUO3xPwAAAAAAkAE99804hMH58T8AAAAAAHgbvY+NYog7BvI/AAAAAACULT0eqHg1vhLyPwAAAAAAANg8Qd19kUkf8j8AAAAAADQrPSMTeaLdK/I/AAAAAAD4GT3nYXVuejjyPwAAAAAAyBm9JxSC+x9F8j8AAAAAADACPQKmsk/OUfI/AAAAAABIE72wzh5xhV7yPwAAAAAAcBI9Fn3iZUVr8j8AAAAAANARPQ/gHTQOePI/AAAAAADuMT0+Y/Xh34TyPwAAAAAAwBS9MLuRdbqR8j8AAAAAANgTvQnfH/WdnvI/AAAAAACwCD2bDtFmiqvyPwAAAAAAfCK9Otra0H+48j8AAAAAADQqPfkadzl+xfI/AAAAAACAEL3ZAuSmhdLyPwAAAAAA0A69eRVkH5bf8j8AAAAAACD0vM8uPqmv7PI/AAAAAACYJL0iiL1K0vnyPwAAAAAAMBa9JbYxCv4G8z8AAAAAADYyvQul7u0yFPM/AAAAAIDfcL2410z8cCHzPwAAAAAASCK9oumoO7gu8z8AAAAAAJglvWYXZLIIPPM/AAAAAADQHj0n+uNmYknzPwAAAAAAANy8D5+SX8VW8z8AAAAAANgwvbmI3qIxZPM/AAAAAADIIj05qjo3p3HzPwAAAAAAYCA9/nQeIyZ/8z8AAAAAAGAWvTjYBW2ujPM/AAAAAADgCr3DPnEbQJrzPwAAAAAAckS9IKDlNNun8z8AAAAAACAIPZVu7L9/tfM/AAAAAACAPj3yqBPDLcPzPwAAAAAAgO88IuHtROXQ8z8AAAAAAKAXvbs0Ekym3vM/AAAAAAAwJj3MThzfcOzzPwAAAAAApki9jH6sBEX68z8AAAAAANw8vbugZ8MiCPQ/AAAAAAC4JT2VLvchChb0PwAAAAAAwB49RkYJJ/sj9D8AAAAAAGATvSCpUNn1MfQ/AAAAAACYIz3ruYQ/+j/0PwAAAAAAAPo8GYlhYAhO9D8AAAAAAMD2vAHSp0IgXPQ/AAAAAADAC70WAB3tQWr0PwAAAAAAgBK9JjOLZm149D8AAAAAAOAwPQA8wbWihvQ/AAAAAABALb0Er5Lh4ZT0PwAAAAAAIAw9ctPX8Cqj9D8AAAAAAFAevQG4bep9sfQ/AAAAAACABz3hKTbV2r/0PwAAAAAAgBO9MsEXuEHO9D8AAAAAAIAAPdvd/Zmy3PQ/AAAAAABwLD2Wq9iBLev0PwAAAAAA4By9Ai2ddrL59D8AAAAAACAZPcExRX9BCPU/AAAAAADACL0qZs+i2hb1PwAAAAAAAPq86lE/6H0l9T8AAAAAAAhKPdpOnVYrNPU/AAAAAADYJr0arPb04kL1PwAAAAAARDK925RdyqRR9T8AAAAAADxIPWsR6d1wYPU/AAAAAACwJD3eKbU2R2/1PwAAAAAAWkE9DsTi2yd+9T8AAAAAAOApvW/Hl9QSjfU/AAAAAAAII71MC/8nCJz1PwAAAAAA7E09J1RI3Qer9T8AAAAAAADEvPR6qPsRuvU/AAAAAAAIMD0LRlmKJsn1PwAAAAAAyCa9P46ZkEXY9T8AAAAAAJpGPeEgrRVv5/U/AAAAAABAG73K69wgo/b1PwAAAAAAcBc9uNx2ueEF9j8AAAAAAPgmPRX3zeYqFfY/AAAAAAAAAT0xVTqwfiT2PwAAAAAA0BW9tSkZHd0z9j8AAAAAANASvRPDzDRGQ/Y/AAAAAACA6rz6jrz+uVL2PwAAAAAAYCi9lzNVgjhi9j8AAAAAAP5xPY4yCMfBcfY/AAAAAAAgN71+qUzUVYH2PwAAAAAAgOY8cZSesfSQ9j8AAAAAAHgpvQAAgD8AAMA/AAAAANzP0TUAAAAAAMAVP0+7YQVnrN0/GC1EVPsh6T+b9oHSC3PvPxgtRFT7Ifk/4mUvIn8rejwHXBQzJqaBPL3L8HqIB3A8B1wUMyamkTwAQfjZwAALzAMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQD/DwAA", zi, Bi, Vi = !1;
function Hi() {
	return Bi ??= (async () => {
		let e = Uint8Array.from(atob(Ri.slice(Ri.indexOf(",") + 1)), (e) => e.charCodeAt(0));
		zi = await WebAssembly.compile(e);
	})().catch((e) => {
		Bi = void 0, Vi || (Vi = !0, console.warn("Rackloose DSP unavailable, so Ladder filters, Analog drums and Analog keyboards play Digital:", e));
	}), Bi;
}
var Ui = () => zi, Wi = [
	Pi,
	Fi,
	Ii,
	Li
].map((e) => ({
	source: e,
	contexts: /* @__PURE__ */ new WeakMap()
}));
async function Gi(e) {
	await Promise.all([Hi(), ...Wi.map(({ source: t, contexts: n }) => {
		let r = n.get(e);
		if (!r) {
			let i = URL.createObjectURL(new Blob([t], { type: "text/javascript" }));
			r = e.audioWorklet.addModule(i).finally(() => URL.revokeObjectURL(i)), n.set(e, r), r.catch(() => n.delete(e));
		}
		return r;
	})]);
}
function Ki(e, t, n, r) {
	let i = 0, a = !1, o, s = /* @__PURE__ */ new Map(), c = (e) => {
		for (let t of s.values()) clearTimeout(t.timer), e ? t.reject(e) : t.resolve();
		s.clear();
	};
	return e.port.onmessage = ({ data: e }) => {
		if (a) return;
		typeof e.reduction == "number" && Number.isFinite(e.reduction) && n?.(e.reduction);
		let t = e.id === void 0 ? void 0 : s.get(e.id);
		t && (clearTimeout(t.timer), t.resolve(), s.delete(e.id));
	}, e.onprocessorerror = () => {
		a || (o = /* @__PURE__ */ Error(`${t} audio processor failed. Reload the patch to retry.`), c(o), r?.(o));
	}, {
		flush() {
			return o ? Promise.reject(o) : a ? Promise.resolve() : new Promise((n, r) => {
				let a = ++i, o = setTimeout(() => {
					s.delete(a), r(/* @__PURE__ */ Error(`${t} did not finish preparing audio. Try again.`));
				}, 5e3);
				s.set(a, {
					resolve: n,
					reject: r,
					timer: o
				}), e.port.postMessage({
					type: "flush",
					id: a
				});
			});
		},
		dispose() {
			a || (a = !0, e.port.postMessage({ type: "dispose" }), c(), e.port.onmessage = null, e.onprocessorerror = null, e.port.close());
		}
	};
}
// src/audio/drumEngine.ts
var qi = {
	boom: 0,
	punch: 1,
	orbit: 2,
	strike: 3,
	forge: 4
}, Ji = {
	boom: [["open", "hat"]],
	punch: [["open", "hat"]],
	strike: [["open", "hat"]],
	forge: [["open", "hat"], ["open", "pedal"]]
}, Yi = (e) => 2 ** (e / 12), Xi = 8;
function Zi(e, t, n, r) {
	let i = Qi(e, t, n, r);
	return Array.from({ length: Xi }, (e, r) => r === 7 ? n[`${t}Pan`] ?? 0 : i[r] ?? 0);
}
function Qi(e, t, n, r) {
	if (e === "orbit") return [
		Yi(n.pitch + n[`${t}Tune`]),
		n[`${t}Decay`],
		Math.min(1, n[`${t}Level`]),
		n[`${t}Tone`]
	];
	if (r) {
		let e = Yi(n[`${t}Tune`]), i = r.sample(t).length / (r.rate * e), a = Math.min(2e4, (r.tone ?? ((e) => 700 * 20 ** e))(n[`${t}Tone`]));
		return [
			r.rate * e,
			n[`${t}Decay`],
			a,
			n[`${t}Level`] * (r.peak ?? 1.6),
			Math.min(i, n[`${t}Decay`] * 2) + .01
		];
	}
	return t === "kick" ? e === "punch" ? [
		n.kickTune,
		n.kickDecay,
		n.kickClick
	] : [n.kickTune, n.kickDecay] : t === "snare" ? [
		n.snareTone,
		n.snappy,
		Yi(n.snareTune),
		n.snareDecay
	] : t === "rim" ? [Yi(n.rimTune), n.rimDecay] : t === "clap" ? [Lt(n.clapTone, 3), n.clapDecay] : t === "lowTom" ? [95 * Yi(n.tomTune), n.tomDecay] : t === "highTom" ? [145 * Yi(n.highTomTune), n.highTomDecay * .85] : t === "bell" ? [Yi(n.bellTune), n.bellDecay] : [n[`${t}Decay`], Lt(n[`${t}Tone`], 2)];
}
function $i(e, t, n) {
	let r = n[`${t}Level`] ?? 1;
	return e === "boom" || e === "punch" ? r : e === "orbit" ? Math.max(1, r) : 1;
}
function ea(e, t, n, { keep: r, onError: i }) {
	let a = Ui();
	if (!a) return null;
	let o = Z[t].drum.voices.map((e) => e.id), s = t === "strike" ? _i : t === "forge" ? Mi : void 0, c = (Ji[t] ?? []).map(([e, t]) => [o.indexOf(e), o.indexOf(t)]), l;
	try {
		l = r(new AudioWorkletNode(e, "rackloose-drums-v1", {
			numberOfInputs: 0,
			numberOfOutputs: 1,
			outputChannelCount: [2],
			processorOptions: {
				module: a,
				kit: qi[t],
				chokes: c
			}
		}));
	} catch (e) {
		return console.warn(`${Z[t].name} Analog engine unavailable, so it plays Digital:`, e), null;
	}
	l.connect(n);
	let u = Ki(l, Z[t].name, void 0, i), d = /* @__PURE__ */ new Set();
	return {
		trigger(e, n, r, i = 1) {
			let a = o.indexOf(e);
			a < 0 || (s && !d.has(e) && (d.add(e), l.port.postMessage({
				type: "sample",
				voice: a,
				pcm: s.sample(e)
			})), l.port.postMessage({
				type: "hit",
				time: n,
				voice: a,
				velocity: i * $i(t, e, r),
				params: Zi(t, e, r, s)
			}));
		},
		cancelScheduled(e) {
			l.port.postMessage({
				type: "cancel",
				time: e
			});
		},
		dispose: u.dispose,
		flush: u.flush
	};
}
function ta(e, t, n, r, i) {
	let a, o, s = i?.input ?? n, c = () => a ??= i ? i.classic() : t === "strike" ? vi(e, s) : pi(e, t, s, r), l = () => o === void 0 ? o = ea(e, t, s, r) : o;
	return {
		trigger(e, t, n, r) {
			(n.engine === 1 ? l() ?? c() : c()).trigger(e, t, n, r);
		},
		cancelScheduled(e) {
			a?.cancelScheduled(e), o?.cancelScheduled(e);
		},
		dispose() {
			a?.dispose(), o?.dispose(), i?.dispose();
		},
		flush: () => o?.flush() ?? Promise.resolve()
	};
}
// src/audio/envelope.ts
function na(e) {
	let t = [], n = (e) => {
		let n = t.findIndex(([t]) => t > e);
		if (n === 0 || !t.length) return 0;
		if (n < 0) return t[t.length - 1][1];
		let [r, i] = t[n - 1], [a, o] = t[n];
		return i + (o - i) * (e - r) / (a - r);
	}, r = (r, ...i) => {
		let a = n(r);
		ui(e, r), e.setValueAtTime(a, r);
		for (let [t, n] of i) e.linearRampToValueAtTime(n, t);
		t = [
			...t.filter(([e]) => e < r).slice(-16),
			[r, a],
			...i
		];
	};
	return {
		on(e, t, n, i, a) {
			r(e, [e + n, t], [e + n + i, t * a]);
		},
		off(e, t) {
			r(e, [e + t, 0]);
		}
	};
}
// src/audio/ladder.ts
function ra(e, { keep: t, onError: n, name: r }, i, a, o = []) {
	let s = t(e.createGain());
	s.gain.value = 0, s.connect(a);
	let c, l, u = !1, d = () => {
		let a = Ui();
		if (c || u || !a) return !!c;
		try {
			c = t(new AudioWorkletNode(e, "rackloose-ladder-v1", {
				numberOfInputs: 1,
				numberOfOutputs: 1,
				outputChannelCount: [1],
				processorOptions: { module: a }
			}));
		} catch (e) {
			return u = !0, console.warn(`${r} Ladder filter unavailable, so it plays Digital:`, e), !1;
		}
		for (let e of o) e.connect(c.parameters.get("detune"));
		return i.connect(c).connect(s), l = Ki(c, r, void 0, n), !0;
	};
	return {
		apply(t, n, r) {
			let i = t && d();
			if (r(s.gain, i ? n.level : 0), c) {
				let t = (e) => c.parameters.get(e);
				r(t("cutoff"), n.cutoff), r(t("resonance"), n.resonance), r(t("drive"), n.drive), r(t("detune"), n.detune ?? 0);
				let i = t("mode"), a = e.currentTime;
				i.cancelScheduledValues(a), i.setValueAtTime(n.mode ?? 0, a);
			}
			return i;
		},
		flush: () => l?.flush() ?? Promise.resolve(),
		dispose: () => l?.dispose()
	};
}
// src/audio/monarch.ts
var ia = [
	"sine",
	"triangle",
	"sawtooth",
	"square"
], aa = 1.4, oa = (e) => {
	let t = 1 + e * 5;
	return t / Math.tanh(t) / Math.sqrt(8 ** e);
}, sa = 1500, ca = 2400, la = 5, ua = 261.625565;
function da(e, t, { keep: n, source: r, onError: i }) {
	let a = (t = 1) => {
		let r = n(e.createGain());
		return r.gain.value = t, r;
	}, o = a(), s = a(), c = a(), l = n(e.createWaveShaper()), u = n(e.createBiquadFilter());
	u.type = "lowpass", u.Q.value = .5, o.connect(u);
	let d = [n(e.createBiquadFilter()), n(e.createBiquadFilter())], f = a(0), p = a(), m = a(.5), h = a(), g = a(), _ = xi(e, r, (e) => e * e), v = a(0), y = a(), b = a(), x = a(), S = a(0), C = a(0), w = a(0), T = a(0);
	_.bend.connect(v), v.connect(y), _.mod.connect(C.gain), x.connect(C), S.connect(C), C.connect(w), C.connect(T), c.connect(l).connect(d[0]).connect(d[1]).connect(g).connect(f).connect(p);
	let E = ra(e, {
		keep: n,
		onError: i,
		name: "MONARCH"
	}, c, f, [
		s,
		h,
		m,
		T
	]), D = r(e.createConstantSource()), O = r(e.createConstantSource());
	D.offset.value = 0, O.offset.value = 0, D.connect(f.gain), O.connect(h), u.connect(m);
	for (let e of d) e.type = "lowpass", s.connect(e.detune), h.connect(e.detune), m.connect(e.detune), T.connect(e.detune);
	let ee = [
		1,
		2,
		3
	].map((t) => {
		let n = r(e.createOscillator()), i = a();
		return n.frequency.value = ua, n.connect(i).connect(c), t < 3 ? (u.connect(n.detune), v.connect(n.detune), w.connect(n.detune)) : (u.connect(b).connect(n.detune), y.connect(n.detune), n.connect(x)), {
			osc: n,
			level: i
		};
	}), k = r(e.createBufferSource()), te = a(0);
	k.buffer = t, k.loop = !0, k.connect(te).connect(c), k.connect(S);
	let ne = {}, A = !1, j = -1, M = (t, n) => {
		A ? t.setTargetAtTime(n, e.currentTime, .008) : t.value = n;
	}, N = [[na(D.offset), "amp"], [na(O.offset), "filter"]];
	return {
		pitch: o,
		cv: s,
		output: p,
		apply(t) {
			ne = t;
			let n = t.osc3Mode === 1;
			ee.forEach(({ osc: e, level: n }, r) => {
				let i = `osc${r + 1}`;
				e.type = ia[t[`${i}Wave`]], M(e.detune, t[`${i}Octave`] * 1200 + t[`${i}Detune`]), M(n.gain, t[`${i}Level`] * .23);
			}), M(ee[2].osc.frequency, n ? la : ua), M(b.gain, +!n), M(y.gain, +!n), M(v.gain, t.bendRange * 100), M(x.gain, 1 - t.modMix), M(S.gain, t.modMix), M(w.gain, t.modDest === 1 ? 0 : sa), M(T.gain, t.modDest === 0 ? 0 : ca), M(te.gain, t.noise * .15), M(p.gain, t.level), M(u.frequency, t.glide ? Math.min(e.sampleRate * .45, 1 / (2 * Math.PI * t.glide)) : e.sampleRate * .45), M(m.gain, t.tracking), M(h.gain, t.envAmount * 4800), d.forEach((e, n) => {
				M(e.frequency, t.cutoff), M(e.Q, n === 0 ? .707 + t.resonance * 5 : .707);
			});
			let r = E.apply(t.filterModel === 1, {
				cutoff: t.cutoff,
				resonance: t.resonance,
				drive: t.drive,
				level: aa * oa(t.drive)
			}, M);
			if (M(g.gain, +!r), j !== t.drive) {
				j = t.drive;
				let e = 1 + t.drive * 5;
				l.curve = Float32Array.from({ length: 2049 }, (t, n) => Math.tanh(e * (n / 1024 - 1)) / Math.tanh(e)), l.oversample = "2x";
			}
			A = !0;
		},
		noteOn(e, t) {
			for (let [n, r] of N) n.on(t, e, ne[`${r}Attack`], ne[`${r}Decay`], ne[`${r}Sustain`]);
		},
		noteOff(e) {
			for (let [t, n] of N) t.off(e, ne[`${n}Release`]);
		},
		wheel: _.move,
		flush: E.flush,
		dispose: E.dispose
	};
}
// src/audio/oracle.ts
var fa = .25, pa = .98, ma = [
	[
		4,
		-3,
		70
	],
	[
		-5,
		2,
		-40
	],
	[
		1,
		6,
		110
	],
	[
		-2,
		-6,
		-90
	],
	[
		6,
		1,
		20
	]
], ha = 261.625565;
function ga(e, t, { keep: n, source: r, onError: i }) {
	let a = (t = 1) => {
		let r = n(e.createGain());
		return r.gain.value = t, r;
	}, o = (t = 0) => {
		let n = r(e.createConstantSource());
		return n.offset.value = t, n;
	}, s = (e) => Float32Array.from({ length: 1025 }, (t, n) => Math.tanh(e * (n / 512 - 1)) / Math.tanh(e)), c = (t, r, i) => {
		let a = n(e.createWaveShaper());
		return a.curve = s(24), a.oversample = "4x", t.connect(a), r.connect(a), Si(a, i);
	}, l = a(), u = a(), d = a(.5), f = a(), p = n(e.createBiquadFilter());
	p.type = "highpass", p.frequency.value = 20, p.Q.value = -3.01, d.connect(p).connect(f);
	let m = r(e.createBufferSource()), h = a(0);
	m.buffer = t, m.loop = !0, m.connect(h);
	let g = xi(e, r), _ = a(0), v = a(0), y = r(e.createOscillator()), b = a(), x = a(0), S = a(0), C = a(0), w = a(0), T = a(0);
	g.bend.connect(_), g.mod.connect(v).connect(S.gain), y.connect(b).connect(S), m.connect(x).connect(S), S.connect(C), S.connect(w), S.connect(T);
	let E = ma.map((t) => {
		let s = o(), f = o(), p = o(), m = o(), g = o(), v = r(e.createOscillator()), y = r(e.createOscillator());
		v.type = "sawtooth", v.frequency.value = ha, y.frequency.value = ha;
		let b = a(), x = a(0), S = a(), E = a(), D = a(), O = a(0), ee = a(), k = a();
		v.connect(b).connect(S), x.connect(S);
		let te = c(v, m, x);
		y.connect(D).connect(ee), O.connect(ee);
		let ne = c(y, g, O), A = a(), j = a(0), M = a(), N = [n(e.createBiquadFilter()), n(e.createBiquadFilter())];
		S.connect(E).connect(A), ee.connect(k).connect(A), h.connect(A), A.connect(N[0]).connect(N[1]).connect(M).connect(j).connect(d), f.connect(j.gain);
		let re = a(), ie = a(), ae = a(0), oe = a(0), se = a(), ce = a(0), le = a(0);
		p.connect(ie), p.connect(ae).connect(se), ee.connect(oe).connect(se), se.connect(ce).connect(v.detune), se.connect(le);
		for (let e of [v.detune, y.detune]) s.connect(e), l.connect(e), C.connect(e), _.connect(e);
		s.connect(re), l.connect(re), w.connect(m.offset), w.connect(g.offset);
		let ue = [
			re,
			ie,
			le,
			u,
			T
		];
		for (let e of N) {
			e.type = "lowpass";
			for (let t of ue) t.connect(e.detune);
		}
		return {
			drift: t,
			note: s,
			amp: f,
			filterEnv: p,
			a: v,
			b: y,
			aWidth: m,
			bWidth: g,
			aComparator: te,
			bComparator: ne,
			aSaw: b,
			aPulse: x,
			aLevel: E,
			bWave: D,
			bPulse: O,
			bLevel: k,
			filters: N,
			classic: M,
			ladder: ra(e, {
				keep: n,
				onError: i,
				name: "ORACLE"
			}, A, j, ue),
			tracking: re,
			envDepth: ie,
			polyEnv: ae,
			polyB: oe,
			polyA: ce,
			polyFilter: le,
			pitched: !1
		};
	}), D = new Ci(E.length), O = {}, ee = !1, k = (t, n) => {
		ee ? t.setTargetAtTime(n, e.currentTime, .008) : t.value = n;
	}, te = (e, t, n, r, i) => {
		let a = Math.max(.001, O[`${t}Attack`]);
		ui(e, r), i && e.setValueAtTime(0, r), e.linearRampToValueAtTime(n, r + a), e.setTargetAtTime(n * O[`${t}Sustain`], r + a, Math.max(.001, O[`${t}Decay`]) / 3);
	}, ne = (e, t, n) => {
		ui(e, n), e.setTargetAtTime(0, n, Math.max(.001, O[`${t}Release`]) / 4);
	}, A = (e, t) => {
		for (let { index: n, pending: r } of D.release(e, O.ampRelease, t)) {
			let t = E[n];
			r && ui(t.note.offset, e), ne(t.amp.offset, "amp", e), ne(t.filterEnv.offset, "filter", e);
		}
	};
	return {
		pitch: l,
		cv: u,
		output: f,
		apply(e) {
			O = e;
			let t = e.vintage, n = e.aShape, r = e.bShape, i = e.polyDest, a = e.lfoDest;
			for (let a of E) {
				k(a.a.detune, e.aOctave * 1200 + a.drift[0] * t), k(a.b.detune, e.bOctave * 1200 + e.bFine + a.drift[1] * t), a.b.type = r === 1 ? "triangle" : "sawtooth", k(a.aSaw.gain, n === 1 ? 0 : n === 2 ? .7 : 1), k(a.aPulse.gain, n === 0 ? 0 : n === 2 ? .7 : 1), k(a.bWave.gain, r === 2 ? 0 : 1), k(a.bPulse.gain, +(r === 2)), a.aComparator(n !== 0, !ee), a.bComparator(r === 2, !ee), k(a.aWidth.offset, 2 * e.aWidth - 1), k(a.bWidth.offset, 2 * e.bWidth - 1), k(a.aLevel.gain, e.aLevel * .25), k(a.bLevel.gain, e.bLevel * .25), k(a.polyEnv.gain, e.polyEnv * 3600), k(a.polyB.gain, e.polyOscB * 2400), k(a.polyA.gain, i === 1 ? 0 : 1), k(a.polyFilter.gain, i === 0 ? 0 : 1), k(a.tracking.gain, e.tracking), k(a.envDepth.gain, e.envAmount * 6e3), a.filters.forEach((n, r) => {
					k(n.frequency, e.cutoff), k(n.detune, a.drift[2] * t), k(n.Q, r === 0 ? -3.01 + e.resonance * 20 : -3.01);
				});
				let o = a.ladder.apply(e.filterModel === 1, {
					cutoff: e.cutoff,
					resonance: e.resonance,
					drive: fa,
					level: pa,
					detune: a.drift[2] * t
				}, k);
				k(a.classic.gain, +!o);
			}
			y.type = [
				"triangle",
				"sawtooth",
				"square"
			][e.lfoShape], k(y.frequency, e.lfoRate), k(S.gain, e.lfoAmount), k(v.gain, 1 - e.lfoAmount), k(b.gain, 1 - e.lfoMix), k(x.gain, e.lfoMix), k(C.gain, a === 0 ? 300 : 0), k(w.gain, a === 1 ? .9 : 0), k(T.gain, a === 2 ? 2400 : 0), k(_.gain, e.bendRange * 100), k(h.gain, e.noise * .2), k(f.gain, e.level), ee = !0;
		},
		noteOn(e, t, n, r) {
			A(n, r);
			let i = /* @__PURE__ */ new Set();
			for (let a of (mt[O.chord]?.[1] ?? [0]).slice(0, E.length)) {
				let o = D.allocate(n, i), s = E[o], c = (e + a - 60) * 100;
				i.add(o), D.start(o, r, n), ui(s.note.offset, n);
				let l = !s.pitched;
				O.glide > 0 && !l ? s.note.offset.setTargetAtTime(c, n, O.glide / 3) : s.note.offset.setValueAtTime(c, n), s.pitched = !0, te(s.amp.offset, "amp", t, n, l), te(s.filterEnv.offset, "filter", t, n, l);
			}
		},
		noteOff: A,
		wheel: g.move,
		flush: () => Promise.all(E.map((e) => e.ladder.flush())).then(() => void 0),
		dispose: () => {
			for (let e of E) e.ladder.dispose();
		}
	};
}
// src/audio/aurora.ts
var _a = .25, va = 1.22, ya = 2400, ba = 120;
function xa(e, { keep: t, source: n, onError: r }) {
	let i = (n = 1) => {
		let r = t(e.createGain());
		return r.gain.value = n, r;
	}, a = () => {
		let t = n(e.createConstantSource());
		return t.offset.value = 0, t;
	}, o = i(), s = i(), c = i(), l = i(.22);
	l.connect(c);
	let u = n(e.createOscillator()), d = i(0), f = i(0), p = i(0);
	u.connect(d), u.connect(f), u.connect(p);
	let m = xi(e, n), h = i(0), g = i(0), _ = i(0), v = i(0);
	m.bend.connect(h), m.bend.connect(g), m.mod.connect(_.gain), u.connect(_).connect(v);
	let y = Float32Array.from({ length: 2049 }, (e, t) => Math.tanh(24 * (t / 1024 - 1))), b = Array.from({ length: 8 }, (c, u) => {
		let m = a(), _ = a(), b = a(), x = i(), S = i(0), C = i(), w = i(), T = i(0), E = [0, 1].map(() => {
			let r = n(e.createOscillator()), s = a(), c = i(), l = i(0), u = i(), p = i();
			r.frequency.value = 261.625565;
			let g = t(e.createWaveShaper());
			return g.curve = y, g.oversample = "4x", r.connect(c).connect(p), r.connect(g), s.connect(g), l.connect(p), p.connect(u).connect(x), m.connect(r.detune), o.connect(r.detune), d.connect(r.detune), f.connect(s.offset), h.connect(r.detune), v.connect(r.detune), {
				osc: r,
				width: s,
				raw: c,
				pulse: l,
				level: u,
				out: p,
				pulsed: Si(g, l)
			};
		});
		E[1].out.connect(T).connect(E[0].osc.detune);
		let D = t(e.createBiquadFilter()), O = [t(e.createBiquadFilter()), t(e.createBiquadFilter())];
		D.type = "highpass", D.Q.value = -3.01;
		let ee = i(0), k = i(1);
		x.connect(D).connect(O[0]), O[0].connect(ee).connect(S), O[0].connect(O[1]).connect(k).connect(S), _.connect(S.gain), S.connect(l), m.connect(C), o.connect(C), b.connect(w);
		for (let e of O) e.type = "lowpass", C.connect(e.detune), w.connect(e.detune), s.connect(e.detune), p.connect(e.detune), g.connect(e.detune);
		return {
			note: m,
			oscillators: E,
			hpf: D,
			filters: O,
			twoPole: ee,
			fourPole: k,
			ladder: ra(e, {
				keep: t,
				onError: r,
				name: "AURORA"
			}, D, S, [
				C,
				w,
				s,
				p,
				g
			]),
			tracking: C,
			amount: w,
			cross: T,
			amp: na(_.offset),
			env: na(b.offset),
			pitched: !1,
			drift: [
				3,
				-4,
				1,
				5,
				-2,
				4,
				-5,
				2
			][u]
		};
	}), x = new Ci(8), S = {}, C = !1, w = (t, n) => {
		C ? t.setTargetAtTime(n, e.currentTime, .008) : t.value = n;
	}, T = (e, t) => {
		for (let { index: n, pending: r } of x.release(e, S.ampRelease, t)) {
			let t = b[n];
			r && ui(t.note.offset, e), t.amp.off(e, S.ampRelease), t.env.off(e, S.filterRelease);
		}
	};
	return {
		pitch: o,
		cv: s,
		output: c,
		apply(e) {
			S = e;
			for (let t of b) {
				t.oscillators.forEach((n, r) => {
					let i = `osc${r + 1}`, a = e[`${i}Wave`];
					n.osc.type = [
						"sawtooth",
						"sawtooth",
						"triangle",
						"sine"
					][a], w(n.osc.detune, e[`${i}Octave`] * 1200 + e[`${i}Detune`] + t.drift * e.vintage * (r ? -.7 : 1)), w(n.width.offset, 2 * e[`${i}Width`] - 1), w(n.raw.gain, a === 1 ? 0 : 1), w(n.pulse.gain, +(a === 1)), n.pulsed(a === 1, !C), w(n.level.gain, r ? e.blend : 1 - e.blend);
				}), w(t.cross.gain, e.crossMod * 1800), w(t.hpf.frequency, e.hpf);
				let n = t.ladder.apply(e.filterModel === 1, {
					cutoff: e.cutoff,
					resonance: e.resonance,
					drive: _a,
					level: va,
					mode: +(e.slope === 0),
					detune: t.drift * e.vintage * 9
				}, w);
				w(t.twoPole.gain, +(!n && e.slope === 0)), w(t.fourPole.gain, +(!n && e.slope === 1)), t.filters.forEach((n, r) => {
					w(n.frequency, e.cutoff), w(n.Q, r ? -3.01 : -3.01 + e.resonance * 17), w(n.detune, t.drift * e.vintage * 9);
				}), w(t.tracking.gain, e.tracking), w(t.amount.gain, e.envAmount * 6e3);
			}
			u.type = [
				"triangle",
				"sine",
				"square"
			][e.lfoShape], w(u.frequency, e.lfoRate), w(d.gain, e.lfoPitch * 100), w(f.gain, e.lfoWidth * .8), w(p.gain, e.lfoFilter * 2400), w(c.gain, e.level), w(h.gain, e.bendRange * 100), w(g.gain, e.bendFilter * ya), w(v.gain, e.leverLfo * ba), C = !0;
		},
		noteOn(e, t, n, r) {
			T(n, r);
			let i = /* @__PURE__ */ new Set();
			for (let a of mt[S.chord]?.[1] ?? [0]) {
				let o = x.allocate(n, i), s = b[o], c = (e + a - 60) * 100;
				i.add(o), x.start(o, r, n), ui(s.note.offset, n), S.glide && s.pitched ? s.note.offset.setTargetAtTime(c, n, S.glide / 3) : s.note.offset.setValueAtTime(c, n), s.pitched = !0, s.amp.on(n, t, S.ampAttack, S.ampDecay, S.ampSustain), s.env.on(n, 1, S.filterAttack, S.filterDecay, S.filterSustain);
			}
		},
		noteOff: T,
		wheel: m.move,
		flush: () => Promise.all(b.map((e) => e.ladder.flush())).then(() => void 0),
		dispose: () => {
			for (let e of b) e.ladder.dispose();
		}
	};
}
// src/audio/prism.ts
function Sa(e, { keep: t, source: n, onError: r }) {
	let i = t(new AudioWorkletNode(e, "rackloose-prism-v1", {
		numberOfInputs: 3,
		numberOfOutputs: 1,
		outputChannelCount: [1],
		processorOptions: { module: Ui() }
	})), a = t(e.createGain()), o = t(e.createGain());
	a.connect(i, 0, 0), o.connect(i, 0, 1);
	let s = xi(e, n), c = t(e.createGain());
	c.gain.value = 0, s.bend.connect(c).connect(i, 0, 0), s.mod.connect(i, 0, 2);
	let l = {};
	return {
		pitch: a,
		cv: o,
		output: i,
		...Ki(i, "PRISM", void 0, r),
		apply(t) {
			l = t, c.gain.setTargetAtTime(t.bendRange * 100, e.currentTime, .008), i.port.postMessage({
				type: "params",
				time: e.currentTime,
				params: t
			});
		},
		wheel: s.move,
		noteOn(e, t, n, r) {
			i.port.postMessage({
				type: "on",
				time: n,
				key: r,
				velocity: t,
				notes: (mt[l.chord]?.[1] ?? [0]).map((t) => e + t)
			});
		},
		noteOff(e, t) {
			i.port.postMessage({
				type: "off",
				time: e,
				key: t
			});
		}
	};
}
// src/audio/keys.ts
function Ca(e, t, { keep: n, onError: r }) {
	let i = n(new AudioWorkletNode(t, "rackloose-keys-v1", {
		numberOfInputs: 2,
		numberOfOutputs: 1,
		outputChannelCount: [2],
		processorOptions: {
			kind: e,
			module: Ui()
		}
	})), a = n(t.createGain()), o = n(t.createGain());
	a.connect(i, 0, 0), o.connect(i, 0, 1);
	let s = Ki(i, Z[e].name, void 0, r), c = (e) => i.port.postMessage(e);
	return {
		pitch: a,
		cv: o,
		output: i,
		...s,
		apply(e) {
			c({
				type: "params",
				time: t.currentTime,
				params: e
			});
		},
		wheel(e, n, r, i = !1) {
			c({
				type: "control",
				time: Math.max(r, t.currentTime),
				kind: e,
				level: n,
				cancel: i
			});
		},
		noteOn(e, t, n, r) {
			c({
				type: "on",
				time: n,
				key: r,
				velocity: t,
				note: e
			});
		},
		noteOff(e, t) {
			c({
				type: "off",
				time: e,
				key: t
			});
		}
	};
}
// src/audio/studio.ts
function wa(e, t, n, r) {
	let i = n(new AudioWorkletNode(e, "rackloose-studio-v1", {
		numberOfInputs: 1,
		numberOfOutputs: 1,
		outputChannelCount: [2],
		channelCount: 2,
		channelCountMode: "explicit",
		processorOptions: { type: t }
	})), a = 0;
	return {
		input: i,
		output: i,
		...Ki(i, Z[t].name, (e) => {
			a = e;
		}, r),
		get reduction() {
			return a;
		},
		apply(t) {
			i.port.postMessage({
				type: "params",
				time: e.currentTime,
				params: t
			});
		}
	};
}
// src/audio/sieve.ts
var Ta = [
	"lowpass",
	"highpass",
	"bandpass"
], Ea = [
	0,
	3,
	2
], Da = .2, Oa = [
	.1,
	1,
	2.5,
	4,
	6,
	9,
	12
], ka = [
	[
		.8,
		.1,
		-.8,
		-1.3,
		-1.9,
		-2.3,
		-2
	],
	[
		-4.1,
		-4.6,
		-5.3,
		-6,
		-6.7,
		-6.9,
		-4.7
	],
	[
		-6.9,
		2,
		6.4,
		9.1,
		12.1,
		16.8,
		22.8
	]
];
function Aa(e, t) {
	let n = ka[e], r = 0;
	for (; r < Oa.length - 2 && t > Oa[r + 1];) r++;
	let i = Math.min(1, Math.max(0, (t - Oa[r]) / (Oa[r + 1] - Oa[r])));
	return 10 ** (-(n[r] + i * (n[r + 1] - n[r])) / 20);
}
var ja = (e) => Math.min(1, Math.max(0, (e - .1) / 11.9));
function Ma(e, { keep: t, onError: n }) {
	let r = () => t(e.createGain()), i = r(), a = r(), o = r(), s = r(), c = t(e.createBiquadFilter());
	i.connect(c).connect(s).connect(o), a.connect(c.detune);
	let l = ra(e, {
		keep: t,
		onError: n,
		name: "SIEVE"
	}, i, o, [a]), u = !1, d = (t, n) => {
		u ? t.setTargetAtTime(n, e.currentTime, .008) : t.value = n;
	};
	return {
		input: i,
		cv: a,
		output: o,
		apply(e) {
			c.type = Ta[e.mode], d(c.frequency, e.cutoff), d(c.Q, e.resonance);
			let t = l.apply(e.filterModel === 1, {
				cutoff: e.cutoff,
				resonance: ja(e.resonance),
				drive: Da,
				level: Aa(e.mode, e.resonance),
				mode: Ea[e.mode]
			}, d);
			d(s.gain, +!t), u = !0;
		},
		flush: l.flush,
		dispose: l.dispose
	};
}
// src/audio/rust.ts
var Na = 4097;
function Pa(e, t, n, r, i) {
	let a = 1 + 60 * t ** 2, o = .6 * n, s = .25 * i;
	return Float32Array.from({ length: Na }, (t, n) => {
		let i = n / 4096 * 2 - 1, c = Math.sign(i) * Math.max(0, Math.abs(i) - s) / (1 - s), l = a * c + o * Math.min(1, a * Math.abs(c) * 4);
		switch (Ot[e]) {
			case "Rectify": return Math.abs(Math.tanh(1.5 * l));
			case "Fold": return Math.sin(Math.PI / 2 * l);
			case "Crush": {
				let e = 2 ** (r - 1);
				return Math.round(Math.tanh(l) * e) / e;
			}
			case "Broken": return l > 0 ? Math.tanh(3 * l) : Math.max(-.3, l * 1.5);
			default: return Math.max(-1, Math.min(1, l));
		}
	});
}
function Fa(e, t) {
	let n = t(e.createGain()), r = t(e.createGain()), i = t(e.createBiquadFilter()), a = t(e.createWaveShaper()), o = t(e.createBiquadFilter()), s = t(e.createBiquadFilter()), c = t(e.createGain()), l = t(e.createGain()), u = t(e.createGain());
	i.type = "peaking", i.Q.value = 1.1, i.gain.value = 9, o.type = "highpass", o.frequency.value = 30, s.type = "lowpass", s.Q.value = .5, n.connect(c).connect(u), n.connect(r).connect(i).connect(a).connect(o).connect(s).connect(l).connect(u);
	let d = "", f = !1;
	return {
		input: n,
		cv: r.gain,
		output: u,
		apply(t) {
			let n = (t, n) => {
				f ? t.setTargetAtTime(n, e.currentTime, .01) : t.value = n;
			}, r = [
				t.mode,
				t.drive,
				t.bias,
				t.crush,
				t.starve
			].join();
			r !== d && (a.curve = Pa(t.mode, t.drive, t.bias, t.crush, t.starve), a.oversample = Ot[t.mode] === "Crush" ? "none" : "2x", d = r), n(i.frequency, t.body), n(s.frequency, 1500 * 12 ** t.tone), n(c.gain, 1 - t.mix), n(l.gain, t.mix * (.7 - .25 * t.drive)), n(u.gain, t.level * 1.4), f = !0;
		}
	};
}
// src/audio/processors.ts
var Ia = (e) => 10 ** (e / 20), La = (e, t, n, r) => {
	r ? e.value = t : e.setTargetAtTime(t, n, .008);
}, Ra = [
	[2e-4, .3],
	[2e-4, .45],
	[4e-4, .6],
	[4e-4, .75],
	[4e-4, .9],
	[2e-4, 1]
], za = 24, Ba = 6;
function Va(e, t, n) {
	let r = Ia(e), i = e + t, a = Ia(i), o = (e) => 20 * Math.log10(e), s = (e, t) => e < r ? e : r + (1 - Math.exp(-t * (e - r))) / t, c = (e, t) => e < r ? 1 : (o(s(e * 1.001, t)) - o(s(e, t))) / (o(e * 1.001) - o(e)), l = .1, u = 1e4, d = 5;
	for (let e = 0; e < 15; e++) c(a, d) < 1 / n ? u = d : l = d, d = Math.sqrt(l * u);
	return (1 / (1 < a ? s(1, d) : Ia(o(s(a, d)) + (0 - i) / n))) ** .6;
}
function Ha(e, { keep: t }) {
	let n = (n = 1) => {
		let r = t(e.createGain());
		return r.gain.value = n, r;
	}, r = (n, r, i = 0) => {
		let a = t(e.createBiquadFilter());
		return a.type = n, a.frequency.value = r, a.gain.value = i, a.Q.value = -3.01, a;
	}, i = n(), a = n(), o = t(e.createWaveShaper()), s = n(), c = .2, l = .5 * (1 - Math.tanh(c) ** 2);
	o.curve = Float32Array.from({ length: 2049 }, (e, t) => (Math.tanh(2 * (t / 1024 - 1) + c) - Math.tanh(c)) / l), o.oversample = "2x";
	let u = t(e.createDynamicsCompressor());
	u.knee.value = za, u.ratio.value = Ba, i.connect(a).connect(o).connect(r("highpass", 12)).connect(r("lowshelf", 90, 1)).connect(r("highshelf", 9e3, -1)).connect(u).connect(s);
	let d = !0, f = NaN, p = 1;
	return {
		input: i,
		output: s,
		compressor: u,
		apply(t) {
			let n = e.currentTime, [r, i] = Ra[t.time] ?? Ra[1];
			f !== t.threshold && (f = t.threshold, p = Va(t.threshold, za, Ba)), La(a.gain, Ia(t.input) / 4, n, d), La(u.threshold, t.threshold, n, d), u.attack.value = r, u.release.value = i, La(s.gain, Ia(t.output) / p, n, d), d = !1;
		}
	};
}
function Ua(e, t) {
	return [
		{
			type: "highpass",
			frequency: e.hpf <= 16 ? 0 : e.hpf,
			Q: -3.01,
			gain: 0
		},
		{
			type: e.lfBell ? "peaking" : "lowshelf",
			frequency: e.lfFreq,
			Q: .7,
			gain: e.lfGain
		},
		{
			type: "peaking",
			frequency: e.lmfFreq,
			Q: e.lmfQ,
			gain: e.lmfGain
		},
		{
			type: "peaking",
			frequency: e.hmfFreq,
			Q: e.hmfQ,
			gain: e.hmfGain
		},
		{
			type: e.hfBell ? "peaking" : "highshelf",
			frequency: e.hfFreq,
			Q: .7,
			gain: e.hfGain
		},
		{
			type: "lowpass",
			frequency: e.lpf >= 22e3 ? t : Math.min(e.lpf, t),
			Q: -3.01,
			gain: 0
		}
	];
}
function Wa({ type: e, frequency: t, Q: n, gain: r }, i, a) {
	let o = a / 2;
	if (e === "highpass" && t <= 0 || e === "lowpass" && t >= o) return 0;
	let s = 10 ** (r / 40), c = 2 * Math.PI * t / a, l = Math.cos(c), u = Math.sin(c), d = u / (2 * 10 ** (n / 20)), f = u / (2 * n), p = u / 2 * Math.SQRT2 * 2 * Math.sqrt(s), [m, h, g, _, v, y] = {
		lowpass: [
			(1 - l) / 2,
			1 - l,
			(1 - l) / 2,
			1 + d,
			-2 * l,
			1 - d
		],
		highpass: [
			(1 + l) / 2,
			-(1 + l),
			(1 + l) / 2,
			1 + d,
			-2 * l,
			1 - d
		],
		peaking: [
			1 + f * s,
			-2 * l,
			1 - f * s,
			1 + f / s,
			-2 * l,
			1 - f / s
		],
		lowshelf: [
			s * (s + 1 - (s - 1) * l + p),
			2 * s * (s - 1 - (s + 1) * l),
			s * (s + 1 - (s - 1) * l - p),
			s + 1 + (s - 1) * l + p,
			-2 * (s - 1 + (s + 1) * l),
			s + 1 + (s - 1) * l - p
		],
		highshelf: [
			s * (s + 1 + (s - 1) * l + p),
			-2 * s * (s - 1 + (s + 1) * l),
			s * (s + 1 + (s - 1) * l - p),
			s + 1 - (s - 1) * l + p,
			2 * (s - 1 - (s + 1) * l),
			s + 1 - (s - 1) * l - p
		]
	}[e] ?? [
		1,
		0,
		0,
		1,
		0,
		0
	], b = 2 * Math.PI * i / a, x = Math.cos(b), S = Math.sin(b), C = Math.cos(2 * b), w = Math.sin(2 * b), T = (e, t, n) => Math.hypot(e + t * x + n * C, t * S + n * w);
	return 20 * Math.log10(T(m, h, g) / T(_, v, y));
}
function Ga(e, { keep: t }) {
	let n = (n = 1) => {
		let r = t(e.createGain());
		return r.gain.value = n, r;
	}, r = n(), i = n(), a = n(0), o = n(), s = e.sampleRate / 2, c = Array.from({ length: 6 }, () => t(e.createBiquadFilter()));
	c.reduce((e, t) => e.connect(t), r).connect(i).connect(o), r.connect(a).connect(o);
	let l = !0;
	return {
		input: r,
		output: o,
		apply(t) {
			let n = e.currentTime;
			Ua(t, s).forEach((e, t) => {
				let r = c[t];
				r.type !== e.type && (r.type = e.type), e.frequency <= 0 || e.frequency >= s ? (r.frequency.cancelScheduledValues(n), r.frequency.setValueAtTime(e.frequency, n)) : La(r.frequency, e.frequency, n, l), La(r.Q, e.Q, n, l), La(r.gain, e.gain, n, l);
			}), La(i.gain, +!t.active, n, l), La(a.gain, +!!t.active, n, l), La(o.gain, Ia(t.output), n, l), l = !1;
		}
	};
}
// src/audio/session.ts
function Ka() {
	let e = typeof navigator > "u" ? void 0 : navigator.audioSession;
	if (!e || e.type === "playback") return () => {};
	let t = e.type;
	return e.type = "playback", () => {
		e.type === "playback" && (e.type = t);
	};
}
// src/audio/engine.ts
var qa = [
	"sine",
	"triangle",
	"sawtooth",
	"square"
], Ja = (e, t) => `${e}:${t}`, Ya = (e, t, n) => {
	e.setTargetAtTime(t, n, .008);
}, Xa = .5, Za = .09, Qa = 4, $a = 120;
function eo({ analyser: e, data: t }) {
	e.getFloatTimeDomainData(t);
	let n = 0;
	for (let e of t) n = Math.max(n, Math.abs(e));
	return n > 0 ? Math.max(-60, 20 * Math.log10(n)) : -60;
}
function to(e, t = 0, n = 2, r = !1, i = 0) {
	let a = e.createBuffer(r ? 2 : 1, Math.ceil(e.sampleRate * n), e.sampleRate), o = 90210;
	for (let n = 0; n < a.numberOfChannels; n++) {
		let r = a.getChannelData(n), s = 0;
		for (let n = 0; n < r.length; n++) {
			o ^= o << 13, o ^= o >>> 17, o ^= o << 5;
			let a = (o >>> 0) / 2 ** 31 - 1;
			s = t === 1 ? .93 * s + .2 * a : t === 2 ? (s + .035 * a) / 1.035 : a, r[n] = s * (i ? Math.exp(-n / e.sampleRate / i * 5) : 1);
		}
	}
	return a;
}
var no = "seq", ro = "manual", io = "audition", ao = Object.fromEntries(B.map((e) => [e, Ue(e)])), oo = () => Object.fromEntries(B.map((e) => [e, []])), so = class {
	context;
	onError;
	master;
	nodes = [];
	sources = [];
	started = !1;
	runtime = /* @__PURE__ */ new Map();
	outputs = /* @__PURE__ */ new Map();
	inputs = /* @__PURE__ */ new Map();
	cvAmounts = /* @__PURE__ */ new Map();
	notes = /* @__PURE__ */ new Map();
	white = null;
	mix = Wn;
	open = {};
	muted = !1;
	manualTarget = null;
	manualOwned = /* @__PURE__ */ new Set();
	targets = /* @__PURE__ */ new Map();
	pulses = /* @__PURE__ */ new Map();
	dictators = /* @__PURE__ */ new Map();
	take = null;
	manualKeys = /* @__PURE__ */ new Set();
	hands = /* @__PURE__ */ new Map();
	holding = /* @__PURE__ */ new Map();
	laneDriven = /* @__PURE__ */ new Set();
	patch;
	constructor(e, t, n = e.destination, r = Wn, i) {
		this.context = e, this.onError = i, this.patch = t, this.master = this.keep(e.createGain());
		let a = this.keep(e.createDynamicsCompressor());
		a.threshold.value = -12, a.knee.value = 12, a.ratio.value = 8, a.attack.value = .003, a.release.value = .15, this.master.connect(a).connect(n);
		for (let e of t.modules) this.buildModule(e);
		for (let e of t.modules) Bn(e.type) && this.targets.set(e.id, Yn(t, e.id));
		for (let n of t.cables) {
			let r = this.outputs.get(Ja(n.from.moduleId, n.from.portId)), i = this.inputs.get(Ja(n.to.moduleId, n.to.portId));
			if (!r || !i || this.isNoteCable(n)) continue;
			let a = Z[t.modules.find((e) => e.id === n.to.moduleId).type].ports.find((e) => e.id === n.to.portId);
			if (a.kind === "cv") {
				let t = this.keep(e.createGain());
				t.gain.value = n.amount * (a.scale ?? 1), r.connect(t), "setValueAtTime" in i, t.connect(i), this.cvAmounts.set(n.id, t);
			} else "setValueAtTime" in i, r.connect(i);
		}
		this.applyPatch(t, !0), this.setMix(r, !0);
		for (let e of this.sources) e.start(0);
		this.started = !0;
	}
	keep(e) {
		return this.nodes.push(e), e;
	}
	isNoteCable(e) {
		let t = this.patch.modules.find((t) => t.id === e.from.moduleId)?.type;
		return e.to.portId === "pitch" && Rn(this.patch.modules.find((t) => t.id === e.to.moduleId).type) && !!t && Bn(t);
	}
	polyNote(e, t, n, r) {
		let i = this.patch.cables.find((t) => t.to.moduleId === e && this.isNoteCable(t));
		return i ? 60 + ((i.from.moduleId === t ? n : this.noteAt(i.from.moduleId, r)) - 60) * i.amount : 60;
	}
	noteAt(e, t) {
		let n = this.notes.get(e) ?? [];
		for (let e = n.length - 1; e >= 0; e--) if (n[e].time <= t) return n[e].note;
		return 48;
	}
	get main() {
		return (this.patch.modules.find((e) => e.type === "performance") ?? this.patch.modules[0]).id;
	}
	gain(e = 1) {
		let t = this.keep(this.context.createGain());
		return t.gain.value = e, t;
	}
	source(e) {
		return "offset" in e && li(e.offset, this.context), this.started && e.start(this.context.currentTime), this.keep(e), this.sources.push(e), e;
	}
	buildModule(e) {
		let { context: t } = this, n = (t) => Ja(e.id, t), r = (e, t) => this.inputs.set(n(e), t), i = this.gain(), a = (e, t, r = !0) => this.outputs.set(n(e), r ? t.connect(i) : t), o = !1, s = (e, n) => {
			o ? Ya(e, n, t.currentTime) : e.value = n;
		}, c = () => {}, l, u, d, f, p, m, h, g, _, v, y, b = (e) => {
			p = this.source(t.createConstantSource()), p.offset.value = 0;
			let n = this.gain(1200);
			p.connect(n), "setValueAtTime" in e, n.connect(e);
		};
		switch (e.type) {
			case "performance":
			case "dictator":
				l = this.source(t.createConstantSource()), l.offset.value = -1, a("pitch", l, !1);
				break;
			case "oscillator": {
				let e = this.source(t.createOscillator()), n = this.gain();
				e.frequency.value = 261.625565, e.connect(n), r("pitch", e.detune), b(e.detune), r("fm", e.detune), a("out", n), c = (t) => {
					e.type = qa[t.wave], s(e.detune, t.octave * 1200 + t.tune * 100 + t.fine), s(n.gain, t.level * .35);
				};
				break;
			}
			case "monarch":
				this.white ??= to(t, 0, 1), f = da(t, this.white, {
					onError: this.onError,
					keep: (e) => this.keep(e),
					source: (e) => this.source(e)
				}), r("pitch", f.pitch), b(f.pitch), r("cv", f.cv), a("out", f.output), c = f.apply;
				break;
			case "oracle":
			case "aurora":
			case "prism":
			case "velvet":
			case "reed":
			case "planet":
			case "strut":
			case "drawbar": {
				this.white ??= to(t, 0, 1);
				let n = {
					onError: this.onError,
					keep: (e) => this.keep(e),
					source: (e) => this.source(e)
				};
				g = e.type === "oracle" ? ga(t, this.white, n) : e.type === "aurora" ? xa(t, n) : e.type === "prism" ? Sa(t, n) : Ca(e.type, t, n), r("pitch", g.pitch), r("cv", g.cv), a("out", g.output), c = g.apply;
				break;
			}
			case "compressor":
				_ = Ha(t, { keep: (e) => this.keep(e) }), r("in", _.input), a("out", _.output), c = _.apply;
				break;
			case "cohere":
			case "talon":
			case "brit":
				m = wa(t, e.type, (e) => this.keep(e), this.onError), r("in", m.input), a("out", m.output), c = m.apply;
				break;
			case "equalizer": {
				let e = Ga(t, { keep: (e) => this.keep(e) });
				r("in", e.input), a("out", e.output), c = e.apply;
				break;
			}
			case "noise": {
				let n = this.source(t.createBufferSource()), r = this.gain();
				n.buffer = to(t, e.params.color), n.loop = !0, n.connect(r), a("out", r), c = (e) => s(r.gain, e.level * .3);
				break;
			}
			case "mixer": {
				let e = () => {
					let e = this.keep(t.createAnalyser());
					return e.fftSize = 512, {
						analyser: e,
						data: new Float32Array(e.fftSize)
					};
				}, n = this.gain(), i = this.gain(), o = this.keep(t.createChannelSplitter(2));
				y = {
					channels: [],
					bus: [e(), e()]
				}, n.connect(i).connect(o), y.bus.forEach(({ analyser: e }, t) => o.connect(e, t));
				let l = xt.map((i, a) => {
					let o = this.gain(), s = this.gain(), c = e(), l = [this.gain(), this.gain()], u = this.gain(), d = this.keep(t.createChannelSplitter(2)), f = this.keep(t.createChannelMerger(2));
					return u.channelCount = 2, u.channelCountMode = "explicit", u.channelInterpretation = "speakers", o.connect(s).connect(u).connect(d), s.connect(c.analyser), l.forEach((e, t) => d.connect(e, t).connect(f, 0, t)), f.connect(n), r(i, o), y.channels.push(c), {
						id: xt[a],
						level: o,
						gate: s,
						sides: l
					};
				});
				v = Object.fromEntries(l.map(({ id: e, gate: t }) => [e, t])), a("out", i), c = (e) => {
					for (let { id: t, level: n, sides: [r, i] } of l) {
						let a = e[St(t)];
						s(n.gain, e[t]), s(r.gain, a > 0 ? Math.cos(a * Math.PI / 2) : 1), s(i.gain, a < 0 ? Math.cos(-a * Math.PI / 2) : 1);
					}
					s(i.gain, e.master);
				};
				break;
			}
			case "filter":
				h = Ma(t, {
					keep: (e) => this.keep(e),
					onError: this.onError
				}), r("in", h.input), r("cv", h.cv), a("out", h.output), c = h.apply;
				break;
			case "amplifier": {
				let t = this.gain(), n = this.gain();
				t.connect(n), t.gain.value = +!this.patch.cables.some((t) => t.to.moduleId === e.id && t.to.portId === "cv"), r("in", t), r("cv", t.gain), a("out", n), c = (e) => s(n.gain, e.level);
				break;
			}
			case "envelope": {
				let e = this.source(t.createConstantSource());
				e.offset.value = 0, a("out", e), u = na(e.offset);
				break;
			}
			case "lfo": {
				let e = this.source(t.createOscillator());
				r("cv", e.frequency), a("out", e), c = (t) => {
					e.type = qa[t.wave], s(e.frequency, t.rate);
				};
				break;
			}
			case "delay": {
				let e = this.gain(), n = this.gain(), i = this.gain(), o = this.gain(), l = this.keep(t.createDelay(1)), u = this.gain();
				e.connect(i).connect(n), e.connect(l).connect(o).connect(n), l.connect(u).connect(l), r("in", e), a("out", n), c = (e) => {
					s(l.delayTime, e.time), s(u.gain, e.feedback), s(i.gain, 1 - e.mix), s(o.gain, e.mix);
				};
				break;
			}
			case "reverb": {
				let e = this.gain(), n = this.gain(), i = this.gain(), o = this.gain(), l = this.keep(t.createConvolver());
				e.connect(i).connect(n), e.connect(l).connect(o).connect(n), r("in", e), a("out", n);
				let u = -1;
				c = (e) => {
					u !== e.decay && (l.buffer = to(t, 0, e.decay, !0, e.decay), u = e.decay), s(i.gain, 1 - e.mix), s(o.gain, e.mix);
				};
				break;
			}
			case "boom":
			case "punch":
			case "orbit":
			case "strike":
			case "forge": {
				let n = this.gain(), o = this.gain(), l = this.gain(), u = this.gain();
				n.connect(o).connect(i).connect(u), l.connect(u), r("chain", l), a("out", u, !1), this.white ??= to(t, 0, 1);
				let f = e.type === "forge" ? Ni(t, n, (e) => this.keep(e)) : void 0;
				d = ta(t, e.type, n, {
					keep: (e) => this.keep(e),
					start: (e) => this.source(e),
					noise: this.white,
					onError: this.onError
				}, f), c = (e) => {
					f?.apply(e), s(o.gain, e.level * Xa);
				};
				break;
			}
			case "rust": {
				let e = Fa(t, (e) => this.keep(e));
				r("in", e.input), r("cv", e.cv), a("out", e.output), c = e.apply;
				break;
			}
			case "output": r("in", this.master), c = (e) => s(this.master.gain, this.muted ? 0 : e.volume * .8);
		}
		for (let t of Z[e.type].ports) {
			let e = t.copyOf && this.outputs.get(n(t.copyOf));
			e && this.outputs.set(n(t.id), e);
		}
		this.runtime.set(e.id, {
			module: e,
			apply: (e) => {
				c(e), o = !0;
			},
			gate: i,
			channels: v,
			meters: y,
			pitch: l,
			envelope: u,
			drums: d,
			monarch: f,
			sieve: h,
			poly: g,
			valve: _,
			studio: m,
			manualPitch: p
		});
	}
	applyPatch(e, t = !1) {
		for (let n of e.modules) {
			let e = this.runtime.get(n.id);
			e && (t || JSON.stringify(e.module.params) !== JSON.stringify(n.params)) && (e.apply(n.params), e.module = n);
		}
		for (let n of e.cables) {
			let r = this.cvAmounts.get(n.id);
			if (r && (t || this.patch.cables.find((e) => e.id === n.id)?.amount !== n.amount)) {
				let t = e.modules.find((e) => e.id === n.to.moduleId), i = Z[t.type].ports.find((e) => e.id === n.to.portId)?.scale ?? 1;
				Ya(r.gain, this.manualTarget === n.to.moduleId && n.to.portId === "pitch" && !Rn(t.type) ? 0 : n.amount * i, this.context.currentTime);
			}
		}
		this.patch = e;
	}
	gatedBy(e) {
		let t = new Set(this.patch.cables.filter((t) => t.from.moduleId === e && hn(this.patch, t.from)?.kind === "gate").map((e) => e.to.moduleId));
		return [...this.runtime.values()].filter((e) => (e.envelope || e.monarch || e.poly) && t.has(e.module.id));
	}
	setMix(e, t = !1) {
		this.mix = e, this.open = Xn(this.patch, e);
		let n = (e, n) => {
			t ? e.gain.value = +!!n : Ya(e.gain, +!!n, this.context.currentTime);
		};
		for (let { module: t, gate: r, channels: i } of this.runtime.values()) {
			n(r, this.open[t.id] !== !1);
			for (let [r, a] of Object.entries(i ?? {})) n(a, Qn(t, r, e));
		}
	}
	openEnvelope(e, t, n, r, i, a) {
		if (e.monarch) {
			e.monarch.noteOn(t, n);
			return;
		}
		if (e.poly) {
			e.poly.noteOn(this.polyNote(e.module.id, a, r, n), t, n, i);
			return;
		}
		let o = e.module.params;
		e.envelope?.on(n, t, o.attack, o.decay, o.sustain);
	}
	closeEnvelope(e, t, n) {
		e.monarch && e.monarch.noteOff(t), e.poly?.noteOff(t, n), e.envelope?.off(t, e.module.params.release);
	}
	setNote(e, t, n) {
		let r = this.runtime.get(e)?.pitch;
		r && (r.offset.cancelScheduledValues(n), r.offset.setValueAtTime((t - 60) / 12, n), this.notes.set(e, [...(this.notes.get(e) ?? []).filter((e) => e.time < n).slice(-63), {
			time: n,
			note: t
		}]));
	}
	gateOn(e, t, n, r) {
		if (this.open[e] !== !1) for (let i of this.gatedBy(e)) this.manualOwned.has(i.module.id) || this.openEnvelope(i, n, r, t, no, e);
	}
	noteOn(e, t = 1, n = this.context.currentTime, r = this.main) {
		this.manualTarget !== r && (this.setNote(r, e, n), this.gateOn(r, e, t, n));
	}
	noteOff(e = this.context.currentTime, t = this.main) {
		for (let n of this.gatedBy(t)) this.manualOwned.has(n.module.id) || this.closeEnvelope(n, e, no);
	}
	sequence(e, t, n, r) {
		let i = t % 16, a = e.filter((e) => e !== this.manualTarget).flatMap((e) => {
			let t = qt(this.patch, e)[i], a = this.runtime.get(e)?.module.params.lag;
			return t?.enabled && $n(e, i, this.mix) ? [{
				id: e,
				step: t,
				at: this.lagged(n, a),
				end: this.lagged(n + r * t.gate, a)
			}] : [];
		});
		for (let { id: e, step: t, at: n } of a) this.setNote(e, t.note, n);
		for (let { id: e, step: t, at: n, end: r } of a) if (this.gateOn(e, t.note, t.velocity, n), this.noteOff(r, e), this.open[e] !== !1) for (let t of this.targets.get(e) ?? []) this.pulse(t, n, e);
	}
	setTake(e) {
		this.take = e;
	}
	dictatorState(e) {
		let t = this.dictators.get(e);
		return t || this.dictators.set(e, t = {
			sounding: [],
			line: new N()
		}), t;
	}
	clipNotes(e, t, n, r) {
		let i = this.take?.id === e.id ? this.take : null, a = r ? [] : D(e.notes ?? [], t, n).filter(([e]) => !i || !j(e, i.covered));
		return i ? T([...a, ...D(i.notes, t, n)]) : a;
	}
	dictatorStep(e, t, n, r) {
		if (!(t < 0)) for (let i of e) {
			let e = this.patch.modules.find((e) => e.id === i);
			if (!e || e.type !== "dictator" || !this.runtime.has(i)) continue;
			let a = this.dictatorState(i), o = C(e.params.length), s = t * 240, c = s % o, l = (t) => this.lagged(n + (t - s) / 240 * r, e.params.lag), u = [];
			for (let e of a.sounding) e.end <= s + 240 && u.push({
				tick: Math.max(s, e.end),
				ends: e
			});
			if (this.open[i] !== !1) {
				let t = this.take?.id === i && this.take.hideFrom !== null && s >= this.take.hideFrom;
				for (let n of this.clipNotes(e, c, c + 240, t)) u.push({
					tick: s + n[0] - c,
					note: n
				});
			}
			u.sort((e, t) => e.tick - t.tick || ("ends" in e ? -1 : 0) - ("ends" in t ? -1 : 0));
			let d = this.gatedBy(i), f = this.kitsOf(i), p = this.manualTarget === i, m = d.filter((e) => e.poly && (p || !this.manualOwned.has(e.module.id))), h = p ? [] : d.filter((e) => !e.poly && !this.manualOwned.has(e.module.id));
			this.open[i] !== !1 && this.laneStep(e, s, c, o, l, d);
			for (let e of u) {
				let t = l(e.tick);
				if ("ends" in e) {
					a.sounding = a.sounding.filter((t) => t !== e.ends);
					for (let n of m) n.poly.noteOff(t, e.ends.key);
					let n = a.line.off(e.ends.id);
					if (n === null) for (let e of h) this.closeEnvelope(e, t, no);
					else if (n && !p) {
						this.setNote(i, n.note, t);
						for (let e of h) this.openEnvelope(e, n.velocity / 127, t, n.note, no, i);
					}
					continue;
				}
				let [n, r, u, d] = e.note, g = `dictator:${i}:${u}`;
				for (let e of a.sounding.filter((e) => e.note === u)) a.sounding = a.sounding.filter((t) => t !== e), a.line.off(e.id);
				let _ = {
					id: `${e.tick}:${u}`,
					key: g,
					note: u,
					end: Math.min(s - c + o, s + n - c + r)
				};
				a.sounding.push(_), a.line.on(_.id, u, d), p || this.setNote(i, u, t);
				for (let e of m) e.poly.noteOn(this.polyNote(e.module.id, i, u, t), d / 127, t, g);
				for (let e of h) this.openEnvelope(e, d / 127, t, u, no, i);
				this.drumNote(f, u, d / 127, t, i);
				for (let e of this.targets.get(i) ?? []) f.some((t) => t.module.id === e) || this.pulse(e, t, i);
			}
		}
	}
	wheelOf(e) {
		let t = this.runtime.get(e);
		return t?.monarch?.wheel ?? t?.poly?.wheel;
	}
	laneStep(e, t, n, r, i, a) {
		let o = this.take?.id === e.id ? this.take : null;
		for (let s of B) {
			let c = o?.lanes?.[s] ?? tn(e, s), l = Je(c, n, r);
			if (l === null) continue;
			let u = [[n, l], ...qe(c, n + 1, n + 240)];
			for (let e of a) {
				let r = this.wheelOf(e.module.id);
				if (r && sn(e.module.type).includes(s) && !this.holding.get(e.module.id)?.has(s)) {
					for (let [e, a] of u) r(s, Be(s, a), i(t + e - n));
					this.laneDriven.add(`${e.module.id}:${s}`);
				}
			}
		}
	}
	handWheel(e, t, n, r) {
		let i = this.context.currentTime;
		for (let a of e) {
			let e = this.wheelOf(a);
			if (!e) continue;
			this.hands.set(a, {
				...this.hands.get(a) ?? ao,
				[t]: n
			});
			let o = this.holding.get(a) ?? /* @__PURE__ */ new Set(), s = r && !o.has(t);
			r ? o.add(t) : o.delete(t), this.holding.set(a, o), e(t, n, i, s);
		}
	}
	restControllers() {
		let e = this.context.currentTime;
		for (let [t, n] of this.runtime) {
			let r = this.wheelOf(t);
			if (r) for (let i of sn(n.module.type)) this.laneDriven.has(`${t}:${i}`) || r(i, Ue(i), e, !0);
		}
		this.hands.clear(), this.holding.clear();
	}
	restoreHands(e) {
		for (let [t, n] of e) {
			let e = this.wheelOf(t), r = this.runtime.get(t)?.module.type;
			if (e && r) {
				this.hands.set(t, { ...n });
				for (let t of sn(r)) e(t, n[t], this.context.currentTime);
			}
		}
	}
	kitsOf(e) {
		return this.patch.cables.filter((t) => t.from.moduleId === e && t.to.portId === "trig" && hn(this.patch, t.from)?.kind === "gate").flatMap((e) => {
			let t = this.runtime.get(e.to.moduleId);
			return t?.drums ? [t] : [];
		});
	}
	drumNote(e, t, n, r, i) {
		for (let a of e) {
			let e = le(Z[a.module.type].drum?.voices ?? [], t);
			e && Qn(a.module, e, this.mix) && (a.drums.trigger(e, this.lagged(r, a.module.params[`${e}Lag`]), a.module.params, n), this.pulse(a.module.id, r, i));
		}
	}
	releaseDictator(e, t) {
		let n = this.dictators.get(e);
		if (n) {
			for (let r of this.gatedBy(e)) {
				if (r.poly) for (let e of n.sounding) r.poly.noteOff(t, e.key);
				else n.line.size && !this.manualOwned.has(r.module.id) && this.closeEnvelope(r, t, no);
				for (let e of sn(r.module.type)) this.laneDriven.delete(`${r.module.id}:${e}`) && !this.holding.get(r.module.id)?.has(e) && this.wheelOf(r.module.id)?.(e, this.hands.get(r.module.id)?.[e] ?? Ue(e), t, !0);
			}
			n.sounding = [], n.line.clear();
		}
	}
	lagged(e, t = 0) {
		return Math.max(this.context.currentTime, e + t / 1e3);
	}
	pulse(e, t, n) {
		this.pulses.set(e, [...(this.pulses.get(e) ?? []).slice(-63), {
			time: t,
			sequencer: n
		}]);
	}
	lastPulse(e, t) {
		let n = this.pulses.get(e);
		if (!n) return -1;
		let r = n.length - 1;
		for (; r >= 0 && n[r].time > t;) r--;
		return r > 0 && n.splice(0, r), r < 0 ? -1 : n[0].time;
	}
	mixerLevels(e) {
		let t = this.runtime.get(e)?.meters;
		return t ? {
			channels: t.channels.map(eo),
			bus: t.bus.map(eo)
		} : null;
	}
	manualOn(e, t, n = ro, r = 1) {
		this.manualTarget !== e && this.manualOff();
		let i = this.runtime.get(e), a = this.context.currentTime;
		if (i) {
			if (this.manualTarget = e, i.poly) this.manualOwned = /* @__PURE__ */ new Set([e]), i.poly.noteOff(a, no), i.poly.noteOn(t, r, a, n);
			else if (i.module.type === "dictator") {
				let i = this.gatedBy(e);
				if (this.manualOwned = new Set(i.map((e) => e.module.id)), this.open[e] === !1) return;
				this.setNote(e, t, a), this.manualKeys.add(n), this.drumNote(this.kitsOf(e), t, r, a, e);
				for (let o of i) o.poly ? o.poly.noteOn(this.polyNote(o.module.id, e, t, a), r, a, `${ro}:${n}`) : this.openEnvelope(o, r, a, t, ro, e);
			} else {
				if (i.module.type === "performance") {
					if (this.manualOwned = new Set(this.gatedBy(e).map((e) => e.module.id)), this.setNote(e, t, a), this.open[e] === !1) return;
				} else {
					let n = Vn(this.patch, e);
					this.manualOwned = new Set(i.monarch ? [e] : this.patch.cables.filter((e) => n.has(e.to.moduleId) && this.runtime.get(e.from.moduleId)?.envelope).map((e) => e.from.moduleId));
					for (let t of this.patch.cables) t.to.moduleId === e && t.to.portId === "pitch" && this.cvAmounts.get(t.id)?.gain.setValueAtTime(0, a);
					i.manualPitch?.offset.setValueAtTime((t - 60) / 12, a);
				}
				for (let n of this.manualOwned) {
					let i = this.runtime.get(n);
					i.poly?.noteOff(a, no), this.openEnvelope(i, r, a, t, ro, e);
				}
			}
		}
	}
	manualRelease(e, t) {
		let n = this.context.currentTime, r = this.runtime.get(this.manualTarget ?? "");
		if (r?.module.type !== "dictator") r?.poly?.noteOff(n, e);
		else {
			this.manualKeys.delete(e);
			for (let i of this.manualOwned) {
				let a = this.runtime.get(i);
				a?.poly ? a.poly.noteOff(n, `${ro}:${e}`) : a && t && (this.setNote(r.module.id, t.note, n), this.openEnvelope(a, t.velocity, n, t.note, ro, r.module.id));
			}
		}
	}
	manualOff() {
		let e = this.context.currentTime, t = this.manualTarget, n = this.runtime.get(t ?? "")?.module.type === "dictator";
		for (let t of this.manualOwned) {
			let r = this.runtime.get(t);
			if (r?.poly && n) for (let t of this.manualKeys) r.poly.noteOff(e, `${ro}:${t}`);
			else r && this.closeEnvelope(r, e);
		}
		this.manualKeys.clear(), this.runtime.get(t ?? "")?.manualPitch?.offset.setValueAtTime(0, e);
		for (let n of this.patch.cables) n.to.moduleId === t && n.to.portId === "pitch" && this.cvAmounts.get(n.id)?.gain.setValueAtTime(n.amount * 1200, e);
		this.manualOwned.clear(), this.manualTarget = null;
	}
	reduction(e) {
		return this.runtime.get(e)?.studio?.reduction ?? this.runtime.get(e)?.valve?.compressor.reduction ?? 0;
	}
	drumStep(e, t, n) {
		for (let { module: r, drums: i } of this.runtime.values()) {
			let a = r.type === "skitter";
			if (!(i || a) || n && r.id !== n || a && this.open[r.id] === !1) continue;
			let o = kn(r, e).filter(([e]) => Qn(r, e, this.mix)), s = Ar(this.patch.sequencer.bpm, this.patch.sequencer.swing, e % 16), c = (e) => e > 2 ? r.params.rollFade ?? 0 : 0;
			for (let [e, n] of o) for (let o = 0; o < n; o++) {
				let l = t + o * s / n, u = 1 - c(n) * o / n;
				a ? this.skitterHit(r, e, l, u, s / n) : i.trigger(e, this.lagged(l, r.params[`${e}Lag`]), r.params, u);
			}
			o.length && this.pulse(r.id, t, r.id);
		}
	}
	skitterTargets(e, t) {
		return this.patch.cables.filter((n) => n.from.moduleId === e && (hn(this.patch, n.from)?.copyOf ?? n.from.portId) === t).map((e) => this.runtime.get(e.to.moduleId)).filter((e) => !!e);
	}
	skitterHit(e, t, n, r, i) {
		if (t === "synth") for (let t of this.skitterTargets(e.id, "gate")) !this.manualOwned.has(t.module.id) && (t.envelope || t.monarch || t.poly) && (this.openEnvelope(t, r, n, 60, no, e.id), this.closeEnvelope(t, n + i * (e.params.gate ?? .5), no), this.pulse(t.module.id, n, e.id));
		else for (let i of this.skitterTargets(e.id, "trig")) {
			let a = wt[i.module.type]?.[t];
			a && i.drums && Qn(i.module, a, this.mix) && (i.drums.trigger(a, this.lagged(n, i.module.params[`${a}Lag`]), i.module.params, r), this.pulse(i.module.id, n, e.id));
		}
	}
	skitterKits(e) {
		return this.patch.modules.some((t) => t.id === e && t.type === "skitter") ? this.skitterTargets(e, "trig").filter((e) => e.drums).map((e) => e.module.id) : [];
	}
	hit(e, t, n = this.context.currentTime, r = 1) {
		let i = this.runtime.get(e);
		i && Qn(i.module, t, this.mix) && (i.module.type === "skitter" ? this.open[e] !== !1 && this.skitterHit(i.module, t, n, r, .12) : i.drums?.trigger(t, n, i.module.params, r));
	}
	cancelModule(e, t = this.context.currentTime) {
		let n = this.runtime.get(e);
		for (let [n, r] of this.pulses) this.pulses.set(n, r.filter((n) => n.sequencer !== e || n.time <= t));
		if (n?.drums && n.drums.cancelScheduled(t), n?.module.type === "skitter") {
			for (let n of this.skitterKits(e)) this.runtime.get(n).drums.cancelScheduled(t);
			for (let n of this.gatedBy(e)) this.manualOwned.has(n.module.id) || this.closeEnvelope(n, t, no);
		}
		n?.module.type === "dictator" && this.releaseDictator(e, t), n?.pitch && (this.noteOff(t, e), this.manualTarget !== e && (ui(n.pitch.offset, t), this.notes.set(e, (this.notes.get(e) ?? []).filter((e) => e.time <= t))));
	}
	cancelScheduled(e = this.context.currentTime) {
		for (let t of this.patch.modules) zn(t.type) && this.cancelModule(t.id, e);
	}
	setMute(e) {
		this.muted = e, Ya(this.master.gain, e ? 0 : this.patch.modules.find((e) => e.type === "output").params.volume * .8, this.context.currentTime);
	}
	async flush() {
		await Promise.all([...this.runtime.values()].map((e) => Promise.all([
			e.poly?.flush?.(),
			e.studio?.flush(),
			e.monarch?.flush(),
			e.sieve?.flush(),
			e.drums?.flush?.()
		])));
	}
	dispose() {
		for (let { poly: e, studio: t, monarch: n, sieve: r } of this.runtime.values()) e?.dispose?.(), t?.dispose(), n?.dispose(), r?.dispose();
		this.master.gain.cancelScheduledValues(this.context.currentTime), this.master.gain.value = 0;
		for (let { drums: e } of this.runtime.values()) e?.dispose();
		for (let e of this.sources) e.stop();
		for (let e of this.nodes) e.disconnect();
		this.sources = [], this.nodes = [];
	}
}, co = (e) => JSON.stringify({
	modules: e.modules.map((e) => [
		e.id,
		e.type,
		e.type === "noise" ? e.params.color : null
	]).sort(),
	cables: e.cables.map((e) => [
		e.id,
		e.from,
		e.to
	]).sort()
}), lo = class {
	patch;
	onError;
	context = null;
	graph = null;
	analyser = null;
	timer = null;
	notes = new kr();
	target = null;
	running = /* @__PURE__ */ new Map();
	nextTime = 0;
	count = 0;
	timeline = [];
	frozen = -1;
	remaining = .04;
	muted = !1;
	mix = Wn;
	suspended = !1;
	disposed = !1;
	revision = 0;
	manualRevision = 0;
	transportRevision = 0;
	moduleRevisions = /* @__PURE__ */ new Map();
	releaseSession = null;
	inputs = /* @__PURE__ */ new Map();
	velocities = /* @__PURE__ */ new Map();
	past = [];
	clickOn = !1;
	countIn = {
		left: 0,
		total: 0
	};
	clicks = /* @__PURE__ */ new Map();
	armed = null;
	take = null;
	onTake;
	hands = /* @__PURE__ */ new Map();
	holding = /* @__PURE__ */ new Set();
	strokes = {};
	heard = {
		notes: [],
		open: /* @__PURE__ */ new Map(),
		strokes: oo()
	};
	offset = 0;
	held = /* @__PURE__ */ new Map();
	playing = !1;
	constructor(e, t) {
		this.patch = e, this.onError = t;
	}
	get activeNote() {
		return this.notes.current;
	}
	get activeNotes() {
		return this.poly ? this.notes.entries.map(([, e]) => e) : this.notes.current === null ? [] : [this.notes.current];
	}
	get poly() {
		let e = this.patch.modules.find((e) => e.id === this.target)?.type;
		return !!e && (Rn(e) || e === "dictator");
	}
	get armedId() {
		return this.armed;
	}
	get recording() {
		return !!this.take;
	}
	takeNotes(e) {
		return this.take?.id === e ? this.take.notes : null;
	}
	arm(e) {
		this.take && this.take.id !== e && this.finishTake(), this.armed = e;
	}
	disarm() {
		if (this.take) {
			for (let e of B) this.strokes[e]?.take && (this.strokes[e] = void 0);
			this.take = null, this.graph?.setTake(null);
		}
		this.armed = null;
	}
	async record(e = 0) {
		let t = this.armed, n = this.patch.modules.find((e) => e.id === t && e.type === "dictator");
		if (!t || !n || this.take || this.suspended || this.disposed) return !1;
		let r = this.playing, i = r ? Math.max(0, Math.round(this.tickOf() ?? this.count * 240)) : this.count * 240, a = this.take = {
			id: t,
			start: i,
			replace: n.params.mode === 1,
			grid: n.params.qrec ? x[n.params.quantize]?.[1] ?? null : null,
			notes: [],
			open: /* @__PURE__ */ new Map(),
			covered: [],
			strokes: oo()
		};
		return this.showTake(), r ? this.running.has(t) || await this.play(t) : await this.play(void 0, e * 16), this.take === a ? this.playing ? (this.showTake(), !0) : (this.take = null, this.graph?.setTake(null), !1) : !1;
	}
	discardTake() {
		let e = this.take;
		if (!e) return 0;
		let t = e.notes.length + e.open.size;
		e.notes = [], e.open.clear(), e.covered = [], e.strokes = oo(), e.start = Math.max(e.start, Math.round(this.tickOf() ?? e.start));
		for (let e of B) this.strokes[e]?.take && (this.strokes[e] = void 0);
		return this.showTake(), t;
	}
	showTake() {
		let e = this.take;
		this.graph?.setTake(e && {
			id: e.id,
			notes: e.notes,
			hideFrom: e.replace ? e.start : null,
			covered: e.replace ? e.covered : [],
			lanes: this.takeLanes(e.id, e.strokes)
		});
	}
	takeLanes(e, t) {
		let n = this.patch.modules.find((t) => t.id === e);
		return n ? Object.fromEntries(B.filter((e) => t[e].length).map((e) => [e, $e(tn(n, e), t[e], C(n.params.length))])) : {};
	}
	get canCapture() {
		return this.heard.notes.length > 0 || B.some((e) => this.heard.strokes[e].length);
	}
	takeHeard(e) {
		let t = this.playing && this.ready ? this.tickOf() : null;
		for (let e of B) this.strokes[e] && !this.strokes[e].take && this.closeStroke(e, t);
		let { notes: n, strokes: r } = this.heard, i = [...n.map((e) => e[0]), ...B.flatMap((e) => r[e].map((e) => e.at(-1)[0]))], a = i.length ? ne(Math.max(...i)) : 0, o = A(n, e, a), s = Object.fromEntries(B.map((t) => [t, et(r[t], a - e, a)]));
		return this.heard.notes = [], this.heard.strokes = oo(), {
			notes: o,
			strokes: s
		};
	}
	setRecordOffset(e) {
		this.offset = Number.isFinite(e) ? Math.max(-100, Math.min(100, e)) : 0;
	}
	inputTick(e) {
		return this.tick(), this.tickOf((e ?? performance.now()) - this.offset);
	}
	finishTake() {
		let e = this.take;
		if (!e) return;
		let t = Math.round(this.tickOf() ?? e.start);
		for (let n of [...e.open.keys()]) this.captureEnd(n, void 0, t);
		this.closeStrokes(), this.take = null;
		let n = this.patch.modules.find((t) => t.id === e.id);
		n ? (this.graph?.setTake({
			id: e.id,
			notes: e.notes,
			hideFrom: null,
			covered: [],
			lanes: this.takeLanes(e.id, e.strokes)
		}), this.onTake?.(e.id, e.notes, e.replace ? [...e.covered, ...te(e.start, t, C(n.params.length))] : [], e.replace, e.strokes)) : this.graph?.setTake(null);
	}
	captureStart(e, t, n, r) {
		let i = this.take, a = this.inputTick(r);
		if (a === null || a < i.start - $a) return;
		let o = Math.max(i.start, Math.round(a));
		i.open.set(e, {
			start: i.grid ? O(o, i.grid) : o,
			raw: o,
			note: t,
			velocity: Math.round(n * 127)
		});
	}
	captureEnd(e, t, n) {
		let r = this.take, i = r?.open.get(e), a = this.patch.modules.find((e) => e.id === r?.id);
		if (!r || !i) return;
		r.open.delete(e);
		let o = n ?? Math.round(this.inputTick(t) ?? i.raw + 1);
		!a || r.notes.length >= 2048 || (r.notes = T([...r.notes, k(i.start, Math.max(1, o - i.raw), i.note, i.velocity, C(a.params.length))]), this.showTake());
	}
	hearStart(e, t, n, r, i) {
		let a = this.inputTick(r);
		a === null || a < -$a || this.patch.modules.find((e) => e.id === i)?.type === "noise" || this.heard.open.set(e, {
			raw: Math.max(0, Math.round(a)),
			note: t,
			velocity: Math.round(n * 127)
		});
	}
	hearEnd(e, t) {
		let n = this.heard.open.get(e);
		if (!n) return;
		this.heard.open.delete(e);
		let r = Math.round(this.inputTick(t) ?? n.raw + 1), i = [...this.heard.notes, [
			n.raw,
			Math.max(1, r - n.raw),
			n.note,
			n.velocity
		]];
		this.heard.notes = i.filter(([e]) => e > n.raw - v).slice(-y);
	}
	wheel(e, t, n, r, i) {
		if (this.suspended || this.disposed) return;
		let a = cn(this.patch, e, t);
		for (let e of a) this.hands.set(e, {
			...this.hands.get(e) ?? ao,
			[t]: n
		});
		r ? this.holding.add(t) : this.holding.delete(t), a.length && this.recordWheel(t, Ve(t, n), r, this.take?.id === e, i), this.ready ? this.graph.handWheel(a, t, n, r) : r && this.unlock().then((e) => {
			e && this.graph.handWheel(a, t, this.hands.get(a[0])?.[t] ?? n, this.holding.has(t));
		}).catch((e) => this.onError?.(e));
	}
	restControllers() {
		this.strokes = {}, this.hands.clear(), this.holding.clear(), this.graph?.restControllers();
	}
	releasePedals(e) {
		for (let t of [...this.holding]) t === "sustain" && this.wheel(e, t, 0, !1);
	}
	controllersAtRest() {
		for (let e of this.hands.values()) if (B.some((t) => e[t] !== Ue(t))) return !1;
		return !0;
	}
	recordWheel(e, t, n, r, i) {
		let a = this.inputTick(i), o = r && !!this.take;
		this.strokes[e] && this.strokes[e].take !== o && this.closeStroke(e, a);
		let s = this.strokes[e];
		if (a !== null && a >= -$a) {
			let r = [Math.max(0, Math.round(a)), t];
			s ? (s.points = tt(s.points, r), !n && s.points.at(-1)[0] < r[0] && (s.points = [...s.points, r])) : n && (this.strokes[e] = {
				points: [r],
				take: o
			});
		}
		n || this.closeStroke(e);
	}
	closeStroke(e, t) {
		let n = this.strokes[e];
		if (this.strokes[e] = void 0, !n?.points.length) return;
		let r = n.points.at(-1);
		if (t != null && Math.round(t) > r[0] && (n.points = [...n.points, [Math.round(t), r[1]]]), n.take && this.take) {
			this.take.strokes[e] = [...this.take.strokes[e], n.points], this.showTake();
			return;
		}
		let i = n.points.at(-1)[0];
		this.heard.strokes[e] = [...this.heard.strokes[e], n.points].filter((e) => e.at(-1)[0] > i - v);
	}
	closeStrokes() {
		let e = this.playing && this.ready ? this.tickOf() : null;
		for (let t of B) this.closeStroke(t, e);
	}
	wheelLevels(e) {
		if (!cn(this.patch, e).length) return null;
		let t = { ...ao }, n = this.playing && this.ready ? this.tickOf() : null;
		for (let r of B) {
			let i = cn(this.patch, e, r)[0];
			if (!i || (t[r] = this.hands.get(i)?.[r] ?? t[r], n === null || n < 0 || this.holding.has(r))) continue;
			let a = this.patch.modules.filter((e) => e.type === "dictator" && this.running.has(e.id) && this.patch.cables.some((t) => t.from.moduleId === e.id && t.to.moduleId === i && t.to.portId === "gate"));
			for (let e of a) {
				let i = C(e.params.length), a = Je((this.take?.id === e.id ? this.takeLanes(e.id, this.take.strokes)[r] : void 0) ?? tn(e, r), n % i, i);
				if (a !== null) {
					t[r] = Be(r, a);
					break;
				}
			}
		}
		return t;
	}
	reduction(e) {
		return this.ready ? this.graph.reduction(e) : 0;
	}
	get sampleRate() {
		return this.context?.sampleRate ?? 48e3;
	}
	get ready() {
		return !!this.graph && this.context?.state === "running";
	}
	get sounding() {
		let e = this.context?.currentTime ?? 0;
		for (; this.timeline.length > 1 && this.timeline[1].time <= e;) this.past.push(this.timeline.shift());
		for (; this.past.length && this.past[0].time + this.past[0].duration < e - Qa;) this.past.shift();
		return this.playing && this.timeline[0]?.time <= e ? this.timeline[0] : null;
	}
	get clock() {
		let e = this.sounding;
		return e && e.count >= 0 ? e.count : this.frozen;
	}
	get countingIn() {
		let e = this.sounding?.count;
		return e !== void 0 && e < 0 ? e : null;
	}
	clockSteps() {
		return this.sounding, [...this.past, ...this.timeline];
	}
	tickOf(e = performance.now()) {
		if (!this.context || !this.playing) return null;
		let t = this.context, n = typeof t.getOutputTimestamp == "function" ? t.getOutputTimestamp() : null, r = ie(e, n && {
			contextTime: n.contextTime ?? 0,
			performanceTime: n.performanceTime ?? 0
		}, {
			currentTime: t.currentTime,
			latency: (t.outputLatency || 0) + (t.baseLatency || 0),
			now: performance.now()
		});
		return re(this.clockSteps(), r);
	}
	setClick(e) {
		this.clickOn = e, !e && this.context && this.cancelClicks(this.context.currentTime, !1);
	}
	click(e, t, n = !1) {
		let r = this.context;
		if (!r) return;
		let i = r.createOscillator(), a = r.createGain();
		i.frequency.value = t ? 1760 : 1320, a.gain.setValueAtTime(t ? .45 : .3, e), a.gain.exponentialRampToValueAtTime(.001, e + .04), i.connect(a).connect(r.destination), i.start(e), i.stop(e + .05), i.onended = () => {
			i.disconnect(), a.disconnect(), this.clicks.delete(i);
		}, this.clicks.set(i, n);
	}
	cancelClicks(e, t = !0) {
		for (let [n, r] of this.clicks) if (t || !r) try {
			n.stop(e);
		} catch {}
	}
	get step() {
		return this.clock < 0 ? -1 : this.clock % 16;
	}
	modulePlaying(e) {
		return this.playing && this.running.has(e);
	}
	moduleClock(e) {
		let t = this.clock;
		return this.running.has(e) && t >= this.running.get(e) ? t : -1;
	}
	pulsing(e) {
		if (!this.graph || !this.context || !this.ready) return !1;
		let t = this.context.currentTime - (this.context.outputLatency || 0), n = this.graph.lastPulse(e, t);
		return n >= 0 && t - n < Za;
	}
	mixerLevels(e) {
		let t = {
			channels: xt.map(() => -60),
			bus: [-60, -60]
		}, n = this.graph && this.ready ? this.graph.mixerLevels(e) : null;
		if (!n || !this.context) return this.held.delete(e), t;
		let r = this.context.currentTime, i = this.held.get(e), a = i ? (r - i.time) * 24 : 0, o = (e, t, n) => Math.max(e, n ? n[t] - a : -60), s = {
			channels: n.channels.map((e, t) => o(e, t, i?.levels.channels)),
			bus: n.bus.map((e, t) => o(e, t, i?.levels.bus))
		};
		return this.held.set(e, {
			time: r,
			levels: s
		}), s;
	}
	get meter() {
		if (!this.analyser || !this.ready) return 0;
		let e = new Float32Array(this.analyser.fftSize);
		return this.analyser.getFloatTimeDomainData(e), Math.min(1, Math.sqrt(e.reduce((e, t) => e + t * t, 0) / e.length) * 6);
	}
	async unlock() {
		if (this.suspended || this.disposed) return !1;
		let e = this.revision;
		if (!this.context) {
			if (typeof AudioContext > "u") throw Error("Web Audio is unavailable in this browser. Try a current Chrome or Safari.");
			this.releaseSession = Ka(), this.context = new AudioContext({ latencyHint: "interactive" }), this.analyser = this.context.createAnalyser(), this.analyser.fftSize = 256, this.analyser.connect(this.context.destination);
		}
		let t = this.context;
		if (await t.resume(), this.disposed || this.suspended || e !== this.revision) return !1;
		try {
			await Gi(t);
		} catch (t) {
			if (this.disposed || this.suspended || e !== this.revision) return !1;
			throw t;
		}
		return this.disposed || this.suspended || e !== this.revision ? !1 : (this.graph || (this.graph = new so(this.context, this.patch, this.analyser, this.mix, (e) => {
			this.panic(), this.onError?.(e);
		}), this.graph.setMute(this.muted), this.graph.restoreHands(this.hands)), !0);
	}
	unlockForInput(e, t = !1) {
		return e === void 0 ? this.unlock() : (this.inputs.get(e)?.cancel(), new Promise((n, r) => {
			let i = () => {
				this.inputs.get(e) === a && this.inputs.delete(e);
			}, a = {
				started: !1,
				cancel: () => {
					i(), n(!1);
				},
				start: (e) => {
					a.started = !0, e.then((e) => {
						i(), n(e);
					}, (e) => {
						i(), r(e);
					});
				}
			};
			this.inputs.set(e, a), (!t || this.ready) && a.start(this.unlock());
		}));
	}
	lifted(e) {
		if (e !== void 0 && !this.inputs.has(e)) return;
		let t = [...this.inputs.values()].filter((e) => !e.started);
		if (!t.length) return;
		let n = this.unlock();
		for (let e of t) e.start(n);
	}
	update(e) {
		let t = co(e) !== co(this.patch);
		this.patch = e;
		for (let t of this.running.keys()) e.modules.some((e) => e.id === t && zn(e.type)) || this.running.delete(t);
		if (this.target && !e.modules.some((e) => e.id === this.target) && this.releaseManual(), this.playing && !this.running.size && this.pause(), this.graph && this.context) {
			if (t) {
				if (this.graph.dispose(), this.graph = new so(this.context, e, this.analyser, this.mix, (e) => {
					this.panic(), this.onError?.(e);
				}), this.graph.setMute(this.muted), this.graph.restoreHands(this.hands), this.showTake(), this.target && this.poly) for (let [e, t] of this.notes.entries) this.graph.manualOn(this.target, t, e, this.velocityOf(e));
				else this.notes.current !== null && this.target && this.graph.manualOn(this.target, this.notes.current, void 0, this.velocityOf());
				for (let e of this.timeline) e.time >= this.context.currentTime && this.schedule([...this.running.keys()], e);
			} else this.graph.applyPatch(e), this.take || this.graph.setTake(null);
		}
	}
	async press(e, t, n = this.patch.modules[0].id, r = !1, i = 1, a) {
		if (this.suspended || this.disposed) return;
		n !== this.target && this.releaseManual(), this.target = n, this.notes.press(e, t), this.velocities.set(e, i), e !== io && (this.take?.id === n ? this.captureStart(e, t, i, a) : this.hearStart(e, t, i, a, n));
		let o = this.manualRevision, s = !this.ready;
		await this.unlockForInput(e, r) && o === this.manualRevision && this.target === n && (this.poly ? this.notes.has(e) ? this.graph.manualOn(n, t, e, i) : s && this.tap(n, t, e, i) : this.notes.current === null ? s && this.tap(n, t, void 0, i) : this.graph.manualOn(n, this.notes.current, void 0, this.velocityOf()));
	}
	audition(e, t, n) {
		return this.release(io), this.press(io, e, t, !1, n);
	}
	endAudition() {
		this.release(io);
	}
	velocityOf(e = this.notes.entries.at(-1)?.[0]) {
		return e !== void 0 && this.velocities.get(e) || 1;
	}
	tap(e, t, n, r = 1) {
		let i = this.manualRevision;
		this.graph.manualOn(e, t, n, r), setTimeout(() => {
			i === this.manualRevision && this.target === e && this.graph && (n === void 0 ? this.notes.current === null && this.graph.manualOff() : this.notes.has(n) || this.graph.manualRelease(n));
		}, 150);
	}
	release(e, t) {
		if (this.captureEnd(e, t), this.hearEnd(e, t), this.poly) {
			if (!this.notes.has(e)) return;
			this.velocities.delete(e);
			let t = this.notes.current, n = this.notes.release(e);
			n === null ? this.graph?.manualOff() : this.graph?.manualRelease(e, t === n ? void 0 : {
				note: n,
				velocity: this.velocityOf()
			});
			return;
		}
		let n = this.notes.current, r = this.notes.release(e);
		this.velocities.delete(e), n !== r && (r !== null && this.target ? this.graph?.manualOn(this.target, r, void 0, this.velocityOf()) : this.graph?.manualOff());
	}
	async hit(e, t, n, r = !1, i = 1) {
		if (this.suspended || this.disposed) return;
		let a = this.manualRevision;
		await this.unlockForInput(n, r) && a === this.manualRevision && this.graph.hit(e, t, void 0, i);
	}
	cancel(e) {
		this.inputs.get(e)?.cancel(), this.release(e);
	}
	releaseManual() {
		for (let e of [...this.take?.open.keys() ?? []]) this.captureEnd(e);
		for (let e of [...this.heard.open.keys()]) this.hearEnd(e);
		this.manualRevision++, this.notes.clear(), this.velocities.clear(), this.graph?.manualOff(), this.target = null;
		for (let e of this.inputs.values()) e.cancel();
	}
	schedule(e, t) {
		if (!this.graph) return;
		let n = e.filter((e) => this.patch.modules.some((t) => t.id === e && t.type === "performance")), r = e.filter((e) => this.patch.modules.some((t) => t.id === e && t.type === "dictator"));
		this.graph.sequence(n, t.count, t.time, t.duration), this.graph.dictatorStep(r, t.count, t.time, t.duration);
		for (let i of e) !n.includes(i) && !r.includes(i) && this.graph.drumStep(t.count, t.time, i);
	}
	startClock(e = 0) {
		this.playing = !0, this.nextTime = this.context.currentTime + Math.max(.01, this.remaining), this.timeline = [], this.past = [], this.countIn = {
			left: e,
			total: e
		}, this.tick(), this.timer = setInterval(() => this.tick(), 25);
	}
	async play(e, t = 0) {
		let n = this.transportRevision, r = this.patch.modules.filter((t) => zn(t.type) && (!e || t.id === e)).map((e) => ({
			id: e.id,
			revision: this.moduleRevisions.get(e.id)
		}));
		if (!await this.unlock() || n !== this.transportRevision) return;
		let i = r.filter((e) => e.revision === this.moduleRevisions.get(e.id) && this.patch.modules.some((t) => t.id === e.id)).map((e) => e.id);
		if (i.length) {
			if (this.playing) {
				let e = this.timeline.filter((e) => e.time > this.context.currentTime);
				for (let t of i) if (!this.running.has(t)) {
					this.running.set(t, e[0]?.count ?? this.count);
					for (let n of e) this.schedule([t], n);
				}
			} else {
				this.running.clear();
				for (let e of i) this.running.set(e, this.count);
				this.startClock(t);
			}
		}
	}
	async rejoin() {
		if (!this.playing || this.countingIn !== null || this.countIn.left) return [];
		let e = this.patch.modules.filter((e) => zn(e.type) && !this.running.has(e.id)).map((e) => e.id);
		return e.length ? (await this.play(), e.filter((e) => this.running.has(e))) : [];
	}
	stopModule(e) {
		let t = this.graph?.skitterKits(e) ?? [];
		if (this.moduleRevisions.set(e, (this.moduleRevisions.get(e) ?? 0) + 1), this.running.delete(e), this.graph?.cancelModule(e), t.length && this.graph && this.context) {
			let e = [...this.running.keys()].filter((e) => t.includes(e) || this.graph.skitterKits(e).some((e) => t.includes(e)));
			for (let t of this.timeline) t.time >= this.context.currentTime && this.schedule(e, t);
		}
		this.running.size || this.pause();
	}
	tick() {
		if (this.context && this.graph && this.playing) for (; this.nextTime < this.context.currentTime + .1 + 50 / 1e3;) {
			let { bpm: e, swing: t } = this.patch.sequencer;
			if (this.countIn.left) {
				let n = this.countIn.total - this.countIn.left, r = Ar(e, t, n);
				this.timeline.push({
					count: n - this.countIn.total,
					time: this.nextTime,
					duration: r
				}), n % 4 == 0 && this.click(this.nextTime, n % 16 == 0, !0), this.countIn.left--, this.nextTime += r;
				continue;
			}
			let n = Ar(e, t, this.count % 16), r = {
				count: this.count,
				time: this.nextTime,
				duration: n
			};
			this.timeline.push(r), this.clickOn && this.count % 4 == 0 && this.click(r.time, this.count % 16 == 0), this.schedule([...this.running.keys()], r), this.nextTime += n, this.count++;
		}
	}
	pause() {
		if (this.transportRevision++, !this.playing) return;
		this.finishTake(), this.closeStrokes();
		for (let e of [...this.heard.open.keys()]) this.hearEnd(e);
		let e = this.context.currentTime, t = this.sounding;
		t && t.count >= 0 && (this.frozen = t.count);
		let n = this.timeline.find((t) => t.time > e && t.count >= 0);
		this.countIn.left || (t?.count ?? 0) < 0 ? (this.count = this.timeline.find((e) => e.count >= 0)?.count ?? this.count, this.remaining = .04) : (this.count = n?.count ?? this.count, this.remaining = Math.max(0, (n?.time ?? this.nextTime) - e)), this.playing = !1, this.timer && clearInterval(this.timer), this.timer = null, this.timeline = [], this.past = [], this.countIn = {
			left: 0,
			total: 0
		}, this.cancelClicks(e), this.graph?.cancelScheduled();
	}
	rewind() {
		this.playing ? this.seek(0) : this.reset();
	}
	reset() {
		this.pause(), this.running.clear(), this.frozen = -1, this.count = 0, this.remaining = .04, this.heard = {
			notes: [],
			open: /* @__PURE__ */ new Map(),
			strokes: oo()
		};
	}
	seek(e) {
		if (this.suspended || this.disposed || !Number.isFinite(e)) return;
		let t = Math.max(0, Math.round(e));
		for (let [e, n] of this.running) this.running.set(e, Math.min(n, t));
		if (this.closeStrokes(), this.heard = {
			notes: [],
			open: /* @__PURE__ */ new Map(),
			strokes: oo()
		}, !this.playing || !this.context) {
			this.count = t, this.frozen = t, this.remaining = .04;
			return;
		}
		let n = this.context.currentTime, r = this.timeline.filter((e) => e.time > n && e.count >= 0), i = (r[0]?.count ?? this.count) * 240, a = this.take;
		if (r.length && (this.timeline = this.timeline.filter((e) => !r.includes(e)), this.nextTime = r[0].time, this.cancelClicks(n, !1), this.graph?.cancelScheduled(r[0].time)), a) {
			let e = this.patch.modules.find((e) => e.id === a.id);
			for (let e of [...a.open.keys()]) this.captureEnd(e, void 0, i);
			a.replace && e && (a.covered = [...a.covered, ...te(a.start, i, C(e.params.length))]), a.start = t * 240, this.showTake();
		}
		this.count = t, this.tick();
	}
	stop() {
		this.reset();
	}
	setMute(e) {
		this.muted = e, this.graph?.setMute(e);
	}
	setMix(e) {
		this.mix = e, this.graph?.setMix(e);
	}
	panic() {
		this.revision++, this.reset(), this.releaseManual(), this.graph?.dispose(), this.graph = null;
	}
	setSuspended(e) {
		this.suspended = e, e && this.panic();
	}
	dispose() {
		this.disposed = !0, this.panic(), this.analyser?.disconnect(), this.context && this.context.close().catch(() => {}), this.context = null, this.releaseSession?.(), this.releaseSession = null;
	}
};
async function uo(e, t = 4, n = Wn) {
	let r = 44100, i = jr(e, t, .04), a = new OfflineAudioContext(2, Math.ceil((i.duration + 2.04) * r), r);
	e.modules.some((e) => [
		"prism",
		"cohere",
		"talon",
		"brit",
		...vt
	].includes(e.type) || e.params.filterModel === 1 || e.params.engine === 1) && await Gi(a);
	let o = new so(a, e, a.destination, n), s = e.modules.filter((e) => e.type === "performance").map((e) => e.id), c = e.modules.filter((e) => e.type === "dictator").map((e) => e.id);
	i.events.forEach(({ time: e, duration: t }, n) => {
		o.sequence(s, n, e, t), o.dictatorStep(c, n, e, t), o.drumStep(n, e);
	});
	try {
		return await o.flush(), await a.startRendering();
	} finally {
		o.dispose();
	}
}
function fo(e) {
	let t = e.numberOfChannels, n = e.length * t * 2, r = new ArrayBuffer(44 + n), i = new DataView(r), a = (e, t) => {
		for (let n = 0; n < t.length; n++) i.setUint8(e + n, t.charCodeAt(n));
	};
	a(0, "RIFF"), i.setUint32(4, 36 + n, !0), a(8, "WAVE"), a(12, "fmt "), i.setUint32(16, 16, !0), i.setUint16(20, 1, !0), i.setUint16(22, t, !0), i.setUint32(24, e.sampleRate, !0), i.setUint32(28, e.sampleRate * t * 2, !0), i.setUint16(32, t * 2, !0), i.setUint16(34, 16, !0), a(36, "data"), i.setUint32(40, n, !0);
	let o = Array.from({ length: t }, (t, n) => e.getChannelData(n));
	for (let n = 0; n < e.length; n++) for (let e = 0; e < t; e++) {
		let r = Math.max(-1, Math.min(1, o[e][n]));
		i.setInt16(44 + (n * t + e) * 2, Math.round(r * (r < 0 ? 32768 : 32767)), !0);
	}
	return r;
}
var Q = {
	app: "_app_1htkl_1",
	toolbar: "_toolbar_1htkl_26",
	brand: "_brand_1htkl_27",
	brandMark: "_brandMark_1htkl_31",
	toolbarActions: "_toolbarActions_1htkl_32",
	audioButton: "_audioButton_1htkl_34",
	statusLed: "_statusLed_1htkl_35",
	rackLight: "_rackLight_1htkl_35",
	deviceLed: "_deviceLed_1htkl_35",
	patchBar: "_patchBar_1htkl_41",
	patchRow: "_patchRow_1htkl_42",
	barGroup: "_barGroup_1htkl_43",
	rackActions: "_rackActions_1htkl_46",
	patchIdentity: "_patchIdentity_1htkl_49",
	patchName: "_patchName_1htkl_50",
	nameField: "_nameField_1htkl_53",
	dirtyMark: "_dirtyMark_1htkl_56",
	saveStatus: "_saveStatus_1htkl_58",
	saveLed: "_saveLed_1htkl_59",
	visuallyHidden: "_visuallyHidden_1htkl_62",
	historyActions: "_historyActions_1htkl_63",
	icon: "_icon_1htkl_64",
	addButton: "_addButton_1htkl_66",
	presetsButton: "_presetsButton_1htkl_67",
	flipButton: "_flipButton_1htkl_71",
	rackHeading: "_rackHeading_1htkl_72",
	rack: "_rack_1htkl_35",
	module: "_module_1htkl_75",
	revealFlash: "_revealFlash_1htkl_1",
	moduleHeader: "_moduleHeader_1htkl_92",
	moduleIdentity: "_moduleIdentity_1htkl_93",
	moduleName: "_moduleName_1htkl_94",
	moduleSubtitle: "_moduleSubtitle_1htkl_95",
	moduleTools: "_moduleTools_1htkl_96",
	moduleNumber: "_moduleNumber_1htkl_97",
	screw: "_screw_1htkl_99",
	screwTL: "_screwTL_1htkl_101",
	screwTR: "_screwTR_1htkl_101",
	screwBL: "_screwBL_1htkl_101",
	screwBR: "_screwBR_1htkl_101",
	moduleBody: "_moduleBody_1htkl_102",
	controls: "_controls_1htkl_103",
	knobControl: "_knobControl_1htkl_104",
	controlLabel: "_controlLabel_1htkl_105",
	dial: "_dial_1htkl_106",
	dialTicks: "_dialTicks_1htkl_107",
	dialCap: "_dialCap_1htkl_108",
	knobValue: "_knobValue_1htkl_111",
	selectControl: "_selectControl_1htkl_112",
	choiceGlyph: "_choiceGlyph_1htkl_114",
	moduleDecoration: "_moduleDecoration_1htkl_115",
	deviceLabel: "_deviceLabel_1htkl_117",
	envelopeGraphic: "_envelopeGraphic_1htkl_119",
	drumPads: "_drumPads_1htkl_121",
	drumLane: "_drumLane_1htkl_123",
	laneLevel: "_laneLevel_1htkl_124",
	voiceButton: "_voiceButton_1htkl_127",
	pads: "_pads_1htkl_128",
	padGroup: "_padGroup_1htkl_129",
	pad: "_pad_1htkl_128",
	euclid: "_euclid_1htkl_137",
	euclidHeading: "_euclidHeading_1htkl_139",
	euclidCell: "_euclidCell_1htkl_140",
	orbitRings: "_orbitRings_1htkl_141",
	orbitPath: "_orbitPath_1htkl_143",
	mixButtons: "_mixButtons_1htkl_145",
	muteToggle: "_muteToggle_1htkl_147",
	soloToggle: "_soloToggle_1htkl_148",
	clearToggle: "_clearToggle_1htkl_149",
	swapToggle: "_swapToggle_1htkl_149",
	sequenceBody: "_sequenceBody_1htkl_151",
	step: "_step_1htkl_151",
	stepCell: "_stepCell_1htkl_153",
	sequenceTop: "_sequenceTop_1htkl_155",
	lcd: "_lcd_1htkl_156",
	lcdDots: "_lcdDots_1htkl_159",
	numberField: "_numberField_1htkl_160",
	fader: "_fader_1htkl_163",
	swingField: "_swingField_1htkl_171",
	transport: "_transport_1htkl_173",
	playButton: "_playButton_1htkl_174",
	transportCaption: "_transportCaption_1htkl_176",
	steps: "_steps_1htkl_177",
	stepLed: "_stepLed_1htkl_179",
	stepNumber: "_stepNumber_1htkl_183",
	sequenceHint: "_sequenceHint_1htkl_184",
	lcdStack: "_lcdStack_1htkl_186",
	stepTransport: "_stepTransport_1htkl_187",
	transportKeys: "_transportKeys_1htkl_188",
	stepEditButton: "_stepEditButton_1htkl_190",
	stepEditor: "_stepEditor_1htkl_193",
	meters: "_meters_1htkl_195",
	meterRow: "_meterRow_1htkl_196",
	muteButton: "_muteButton_1htkl_197",
	rackBottom: "_rackBottom_1htkl_198",
	aboutButton: "_aboutButton_1htkl_199",
	keyboardPanel: "_keyboardPanel_1htkl_200",
	keyboardTop: "_keyboardTop_1htkl_201",
	keyHint: "_keyHint_1htkl_201",
	keyControls: "_keyControls_1htkl_203",
	octaveControls: "_octaveControls_1htkl_204",
	keysToggle: "_keysToggle_1htkl_204",
	piano: "_piano_1htkl_205",
	playSurface: "_playSurface_1htkl_207",
	wheels: "_wheels_1htkl_208",
	wheelSlot: "_wheelSlot_1htkl_209",
	wheel: "_wheel_1htkl_208",
	wheelRidges: "_wheelRidges_1htkl_212",
	wheelMark: "_wheelMark_1htkl_213",
	wheelLabel: "_wheelLabel_1htkl_216",
	pedals: "_pedals_1htkl_219",
	pedalSlot: "_pedalSlot_1htkl_220",
	pedal: "_pedal_1htkl_219",
	pedalFace: "_pedalFace_1htkl_223",
	swellFill: "_swellFill_1htkl_226",
	pedalLabel: "_pedalLabel_1htkl_228",
	rotarySwitch: "_rotarySwitch_1htkl_233",
	rotaryLever: "_rotaryLever_1htkl_234",
	whiteKey: "_whiteKey_1htkl_240",
	blackKey: "_blackKey_1htkl_242",
	toastAnchor: "_toastAnchor_1htkl_245",
	toast: "_toast_1htkl_245",
	library: "_library_1htkl_248",
	libraryHeading: "_libraryHeading_1htkl_249",
	libraryGrid: "_libraryGrid_1htkl_250",
	presetBrowser: "_presetBrowser_1htkl_252",
	presetActions: "_presetActions_1htkl_253",
	sectionLabel: "_sectionLabel_1htkl_254",
	presetList: "_presetList_1htkl_255",
	presetRow: "_presetRow_1htkl_256",
	presetLoad: "_presetLoad_1htkl_258",
	presetConfirm: "_presetConfirm_1htkl_261",
	dangerButton: "_dangerButton_1htkl_262",
	presetEmpty: "_presetEmpty_1htkl_266",
	factoryCategory: "_factoryCategory_1htkl_268",
	factoryCategoryLabel: "_factoryCategoryLabel_1htkl_268",
	factoryGrid: "_factoryGrid_1htkl_269",
	saveDialog: "_saveDialog_1htkl_270",
	saveTitle: "_saveTitle_1htkl_271",
	saveWarning: "_saveWarning_1htkl_273",
	saveNote: "_saveNote_1htkl_274",
	saveButtons: "_saveButtons_1htkl_275",
	saveButton: "_saveButton_1htkl_275",
	miniDevice: "_miniDevice_1htkl_276",
	routingBar: "_routingBar_1htkl_277",
	legend: "_legend_1htkl_278",
	portGroups: "_portGroups_1htkl_280",
	portGroup: "_portGroup_1htkl_280",
	portHeading: "_portHeading_1htkl_280",
	portRow: "_portRow_1htkl_280",
	socketControl: "_socketControl_1htkl_280",
	jacks: "_jacks_1htkl_282",
	socket: "_socket_1htkl_280",
	trim: "_trim_1htkl_285",
	cables: "_cables_1htkl_288",
	cableHits: "_cableHits_1htkl_288",
	cable: "_cable_1htkl_288",
	cableLine: "_cableLine_1htkl_292",
	cableShadow: "_cableShadow_1htkl_292",
	cableHit: "_cableHit_1htkl_288",
	loosePlug: "_loosePlug_1htkl_294",
	helpBackdrop: "_helpBackdrop_1htkl_296",
	help: "_help_1htkl_296",
	helpHeading: "_helpHeading_1htkl_296",
	about: "_about_1htkl_199",
	aboutFacts: "_aboutFacts_1htkl_298",
	aboutTagline: "_aboutTagline_1htkl_298",
	aboutCopyright: "_aboutCopyright_1htkl_298",
	exportControls: "_exportControls_1htkl_305",
	hitLed: "_hitLed_1htkl_305",
	globalControls: "_globalControls_1htkl_341",
	globalTransport: "_globalTransport_1htkl_342",
	playStoppedButton: "_playStoppedButton_1htkl_346",
	rewindButton: "_rewindButton_1htkl_346",
	clearAllButton: "_clearAllButton_1htkl_347",
	positionField: "_positionField_1htkl_352",
	globalPosition: "_globalPosition_1htkl_353",
	clickButton: "_clickButton_1htkl_355",
	clickLed: "_clickLed_1htkl_355",
	keyboardTarget: "_keyboardTarget_1htkl_357",
	midiToggle: "_midiToggle_1htkl_359",
	midiLed: "_midiLed_1htkl_360",
	routingHint: "_routingHint_1htkl_362",
	moduleNameButton: "_moduleNameButton_1htkl_364",
	moduleTransport: "_moduleTransport_1htkl_367",
	clearPatternButton: "_clearPatternButton_1htkl_371",
	performancePads: "_performancePads_1htkl_375",
	orbitEditor: "_orbitEditor_1htkl_381",
	orbitVoiceEditor: "_orbitVoiceEditor_1htkl_382",
	orbitEditorHeading: "_orbitEditorHeading_1htkl_383",
	orbitSteps: "_orbitSteps_1htkl_387",
	groupControls: "_groupControls_1htkl_395",
	grMeter: "_grMeter_1htkl_412",
	grUnit: "_grUnit_1htkl_415",
	grNeedle: "_grNeedle_1htkl_416",
	eqGraphic: "_eqGraphic_1htkl_431",
	countInField: "_countInField_1htkl_441",
	soundEditor: "_soundEditor_1htkl_475",
	editorHeading: "_editorHeading_1htkl_476",
	fmDisplay: "_fmDisplay_1htkl_479",
	operatorTabs: "_operatorTabs_1htkl_481",
	keysPanel: "_keysPanel_1htkl_536",
	keysPlate: "_keysPlate_1htkl_537",
	keysPlateName: "_keysPlateName_1htkl_539",
	keysPlateControls: "_keysPlateControls_1htkl_541",
	keysControl: "_keysControl_1htkl_542",
	keysWell: "_keysWell_1htkl_544",
	panelLegend: "_panelLegend_1htkl_545",
	keysLeverEnds: "_keysLeverEnds_1htkl_547",
	keysKnob: "_keysKnob_1htkl_550",
	keysKnobBody: "_keysKnobBody_1htkl_552",
	keysKnobIndex: "_keysKnobIndex_1htkl_552",
	keysKnobCap: "_keysKnobCap_1htkl_556",
	keysSwitch: "_keysSwitch_1htkl_572",
	keysSlideThumb: "_keysSlideThumb_1htkl_590",
	keysSelector: "_keysSelector_1htkl_593",
	keysSelectorHead: "_keysSelectorHead_1htkl_594",
	keysLever: "_keysLever_1htkl_547",
	keysLeverSlot: "_keysLeverSlot_1htkl_606",
	keysLeverHandle: "_keysLeverHandle_1htkl_607",
	velvetFelt: "_velvetFelt_1htkl_614",
	reedGrille: "_reedGrille_1htkl_617",
	strutRockers: "_strutRockers_1htkl_630",
	drawbars: "_drawbars_1htkl_643",
	drawbarSlot: "_drawbarSlot_1htkl_644",
	drawbar: "_drawbar_1htkl_643",
	drawbarRod: "_drawbarRod_1htkl_650",
	drawbarTab: "_drawbarTab_1htkl_652",
	console: "_console_1htkl_672",
	channelStrip: "_channelStrip_1htkl_673",
	mixBus: "_mixBus_1htkl_673",
	scribble: "_scribble_1htkl_675",
	channelSource: "_channelSource_1htkl_677",
	scribbleLink: "_scribbleLink_1htkl_679",
	faderValue: "_faderValue_1htkl_684",
	faderBay: "_faderBay_1htkl_687",
	faderScale: "_faderScale_1htkl_688",
	faderSlot: "_faderSlot_1htkl_690",
	faderCap: "_faderCap_1htkl_692",
	levelMeter: "_levelMeter_1htkl_695",
	processorHint: "_processorHint_1htkl_713",
	britPanel: "_britPanel_1htkl_730",
	britSection: "_britSection_1htkl_731",
	britWell: "_britWell_1htkl_733",
	marconi: "_marconi_1htkl_738",
	marconiRing: "_marconiRing_1htkl_738",
	marconiSkirt: "_marconiSkirt_1htkl_743",
	marconiFlutes: "_marconiFlutes_1htkl_744",
	marconiDome: "_marconiDome_1htkl_746",
	marconiPointer: "_marconiPointer_1htkl_748",
	ringPointer: "_ringPointer_1htkl_753",
	britCurve: "_britCurve_1htkl_756",
	britSwitch: "_britSwitch_1htkl_758",
	britLamp: "_britLamp_1htkl_760",
	talonPanel: "_talonPanel_1htkl_764",
	talonSection: "_talonSection_1htkl_765",
	talonWell: "_talonWell_1htkl_767",
	talonKnob: "_talonKnob_1htkl_768",
	talonGrip: "_talonGrip_1htkl_771",
	talonCap: "_talonCap_1htkl_772",
	talonIndex: "_talonIndex_1htkl_773",
	talonLamps: "_talonLamps_1htkl_776",
	talonLed: "_talonLed_1htkl_781",
	talonLatches: "_talonLatches_1htkl_783",
	talonPush: "_talonPush_1htkl_784",
	talonMeter: "_talonMeter_1htkl_786",
	talonSwitch: "_talonSwitch_1htkl_793",
	talonLamp: "_talonLamp_1htkl_776",
	talonOutput: "_talonOutput_1htkl_797",
	rollBrush: "_rollBrush_1htkl_812",
	orbitDevice: "_orbitDevice_1htkl_876",
	engineSwitch: "_engineSwitch_1htkl_893",
	engineCaption: "_engineCaption_1htkl_895",
	togglePlate: "_togglePlate_1htkl_897",
	toggleLegend: "_toggleLegend_1htkl_899",
	toggle: "_toggle_1htkl_897",
	toggleSlot: "_toggleSlot_1htkl_909",
	toggleKnob: "_toggleKnob_1htkl_912",
	toggleBrim: "_toggleBrim_1htkl_915",
	toggleRib: "_toggleRib_1htkl_917",
	toggleCap: "_toggleCap_1htkl_919",
	dictatorBody: "_dictatorBody_1htkl_938",
	armButton: "_armButton_1htkl_942",
	armLed: "_armLed_1htkl_943",
	recordLed: "_recordLed_1htkl_943",
	recordBlink: "_recordBlink_1htkl_1",
	quantizeRow: "_quantizeRow_1htkl_947",
	lampButton: "_lampButton_1htkl_950",
	lampLed: "_lampLed_1htkl_951",
	noteStripFrame: "_noteStripFrame_1htkl_953",
	stripSeek: "_stripSeek_1htkl_953",
	noteStrip: "_noteStrip_1htkl_953",
	playhead: "_playhead_1htkl_956",
	dictatorActions: "_dictatorActions_1htkl_957",
	playsControl: "_playsControl_1htkl_958",
	offsetControl: "_offsetControl_1htkl_958",
	midiTracks: "_midiTracks_1htkl_959",
	recordButton: "_recordButton_1htkl_960",
	editButton: "_editButton_1htkl_965",
	pianoRoll: "_pianoRoll_1htkl_966",
	rollTools: "_rollTools_1htkl_967",
	rollToolGroup: "_rollToolGroup_1htkl_968",
	rollStatus: "_rollStatus_1htkl_972",
	rollClose: "_rollClose_1htkl_973",
	rollScroller: "_rollScroller_1htkl_974",
	rollCanvas: "_rollCanvas_1htkl_975",
	rollRulerRow: "_rollRulerRow_1htkl_976",
	rollCorner: "_rollCorner_1htkl_977",
	rollLaneLabel: "_rollLaneLabel_1htkl_977",
	rollRuler: "_rollRuler_1htkl_976",
	rollBody: "_rollBody_1htkl_979",
	rollKeys: "_rollKeys_1htkl_980",
	rollWhite: "_rollWhite_1htkl_981",
	rollBlack: "_rollBlack_1htkl_981",
	rollGrid: "_rollGrid_1htkl_983",
	rollShade: "_rollShade_1htkl_985",
	rollRowLine: "_rollRowLine_1htkl_985",
	rollOctave: "_rollOctave_1htkl_985",
	rollBar: "_rollBar_1htkl_986",
	rollBeat: "_rollBeat_1htkl_986",
	rollStep: "_rollStep_1htkl_986",
	rollNote: "_rollNote_1htkl_987",
	rollTake: "_rollTake_1htkl_988",
	rollCursor: "_rollCursor_1htkl_989",
	rollMarquee: "_rollMarquee_1htkl_990",
	rollLaneRow: "_rollLaneRow_1htkl_992",
	rollLane: "_rollLane_1htkl_977",
	rollLaneTabs: "_rollLaneTabs_1htkl_996",
	rollLaneCentre: "_rollLaneCentre_1htkl_1002",
	rollWheelArea: "_rollWheelArea_1htkl_1003",
	rollWheelLine: "_rollWheelLine_1htkl_1003",
	moduleSlot: "_moduleSlot_1htkl_1012",
	moduleTape: "_moduleTape_1htkl_1016",
	tapeBody: "_tapeBody_1htkl_1020",
	tapePeel: "_tapePeel_1htkl_1022",
	tapeField: "_tapeField_1htkl_1023",
	tapeText: "_tapeText_1htkl_1024"
};
// src/components/Knob.tsx
function po(e, t) {
	return e.choices ? e.choices[t] ?? "" : e.unit === "ms" ? t ? `${t > 0 ? "+" : "−"}${Math.abs(t)}ms` : "On beat" : e.unit === "Hz" && t >= 1e3 ? `${(t / 1e3).toFixed(1)}k` : e.unit === "s" && t < .001 ? `${Math.round(t * 1e6)}μs` : e.unit === "s" && t < 1 ? `${e.step < .001 ? Number((t * 1e3).toFixed(2)) : Math.round(t * 1e3)}ms` : `${Number(t.toFixed(2))}${e.unit ?? ""}`;
}
function mo({ param: e, value: t, onChange: n, prefix: r = "", format: i, disabled: a = !1, travel: o = 130, axis: s = "y" }) {
	let c = u(null), l = Er(e, t), d = Math.max(4, Math.ceil(-Math.log10(e.step)));
	function f(t) {
		let r = Math.max(0, Math.min(1, t)), i = e.logarithmic ? e.min * (e.max / e.min) ** r : e.min + r * (e.max - e.min);
		n(Math.max(e.min, Math.min(e.max, Number((Math.round(i / e.step) * e.step).toFixed(d)))));
	}
	function p(e) {
		e.isPrimary && e.button === 0 && (c.current = {
			at: s === "x" ? -e.clientX : e.clientY,
			fraction: l
		}, e.currentTarget.setPointerCapture(e.pointerId), e.preventDefault());
	}
	let m = i ? i(t) : po(e, t);
	return {
		props: {
			role: "slider",
			tabIndex: a ? -1 : 0,
			"aria-disabled": a || void 0,
			"aria-label": `${r} ${e.label}`.trim(),
			"aria-valuemin": e.min,
			"aria-valuemax": e.max,
			"aria-valuenow": t,
			"aria-valuetext": m,
			onPointerDown: a ? void 0 : p,
			onPointerMove: (e) => {
				c.current && f(c.current.fraction + (c.current.at - (s === "x" ? -e.clientX : e.clientY)) / o);
			},
			onPointerUp: () => {
				c.current = null;
			},
			onPointerCancel: () => {
				c.current = null;
			},
			onLostPointerCapture: () => {
				c.current = null;
			},
			onDoubleClick: a ? void 0 : () => n(e.initial),
			onKeyDown: (r) => {
				!a && [
					"ArrowUp",
					"ArrowRight",
					"ArrowDown",
					"ArrowLeft",
					"Home",
					"End"
				].includes(r.key) && (r.preventDefault(), r.key === "Home" ? n(e.min) : r.key === "End" ? n(e.max) : e.logarithmic ? f(l + (["ArrowUp", "ArrowRight"].includes(r.key) ? .025 : -.025)) : n(Math.max(e.min, Math.min(e.max, Number((t + (["ArrowUp", "ArrowRight"].includes(r.key) ? e.step : -e.step)).toFixed(d))))));
			}
		},
		fraction: l,
		display: m
	};
}
function ho({ param: e, value: t, onChange: n, prefix: r = "", format: i, trim: a = !1, disabled: o = !1, caption: s }) {
	let { props: c, fraction: l, display: u } = mo({
		param: e,
		value: t,
		onChange: n,
		prefix: r,
		format: i,
		disabled: o
	}), d = /* @__PURE__ */ h("div", {
		className: a ? `${Q.dial} ${Q.trim}` : Q.dial,
		...c,
		title: a ? `${e.label} ${u}` : void 0,
		children: [/* @__PURE__ */ m("span", { className: Q.dialTicks }), /* @__PURE__ */ m("span", {
			className: Q.dialCap,
			style: { transform: `rotate(${-135 + l * 270}deg)` },
			children: /* @__PURE__ */ m("span", {})
		})]
	});
	return a ? d : /* @__PURE__ */ h("div", {
		className: Q.knobControl,
		title: e.hint,
		children: [
			/* @__PURE__ */ m("span", {
				className: Q.controlLabel,
				children: s ?? e.label
			}),
			d,
			/* @__PURE__ */ m("span", {
				className: Q.knobValue,
				children: u
			})
		]
	});
}
// src/components/CableLayer.tsx
var go = (e) => `${e.moduleId}:${e.portId}`, _o = (e, t) => {
	let n = Math.min(140, Math.abs(e.y - t.y) * .2 + Math.abs(e.x - t.x) * .25 + 40);
	return `M${e.x},${e.y} C${e.x + 12},${e.y + n} ${t.x - 12},${t.y + n} ${t.x},${t.y}`;
};
function vo({ patch: e, rackRef: t, selected: n, onSelect: r, drag: i }) {
	let [a, o] = d({}), [c, l] = d(null);
	s(() => {
		let e = t.current;
		if (!e) return;
		function n() {
			let t = e.getBoundingClientRect(), n = {};
			e.querySelectorAll("[data-port-key]").forEach((r) => {
				let i = r.getBoundingClientRect();
				n[r.dataset.portKey] = {
					x: i.x - t.x + i.width / 2 + e.scrollLeft,
					y: i.y - t.y + i.height / 2 + e.scrollTop
				};
			}), o(n);
		}
		n();
		let r = new ResizeObserver(n);
		return r.observe(e), e.querySelectorAll("article").forEach((e) => r.observe(e)), window.addEventListener("resize", n), () => {
			r.disconnect(), window.removeEventListener("resize", n);
		};
	}, [e.modules, t]);
	let u = (t) => {
		let n = e.modules.find((e) => e.id === t.moduleId), r = Z[n.type].ports, i = hn(e, t), a = _n(r, i), o = n.type === "mixer" && i.direction === "in" ? `Channel ${i.id.toUpperCase()}: ${or(e, n.id, i.id).source}` : i.label;
		return `${Z[n.type].name} ${o}${a && a > 1 ? ` ${a}` : ""}`;
	}, f = i && hn(e, i.anchor), g = i && a[go(i.anchor)], _ = i && (i.target ? a[go(i.target)] : i.point), v = f && g && _ ? f.direction === "out" ? _o(g, _) : _o(_, g) : null, y = e.cables.flatMap((t) => {
		let n = a[go(t.from)], r = a[go(t.to)];
		return n && r && t.id !== i?.cableId ? [{
			cable: t,
			path: _o(n, r),
			kind: hn(e, t.from).kind
		}] : [];
	});
	return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("svg", {
		className: Q.cableHits,
		"aria-label": "Patch cables",
		"data-analytics-private": e.modules.some((e) => e.label) ? "" : void 0,
		children: y.map(({ cable: e, path: t }) => /* @__PURE__ */ m("path", {
			className: Q.cableHit,
			d: t,
			role: "button",
			tabIndex: 0,
			"aria-label": `Cable from ${u(e.from)} to ${u(e.to)}`,
			onClick: () => r(e.id),
			onPointerEnter: () => l(e.id),
			onPointerLeave: () => l((t) => t === e.id ? null : t),
			onKeyDown: (t) => {
				(t.key === "Enter" || t.key === " ") && (t.preventDefault(), r(e.id));
			}
		}, e.id))
	}), /* @__PURE__ */ h("svg", {
		className: Q.cables,
		"aria-hidden": "true",
		children: [y.map(({ cable: e, path: t, kind: r }) => /* @__PURE__ */ h("g", {
			className: Q.cable,
			"data-kind": r,
			"data-selected": n === e.id,
			"data-hovered": c === e.id,
			children: [/* @__PURE__ */ m("path", {
				className: Q.cableShadow,
				d: t
			}), /* @__PURE__ */ m("path", {
				className: Q.cableLine,
				d: t
			})]
		}, e.id)), v && /* @__PURE__ */ h("g", {
			className: Q.cable,
			"data-kind": f.kind,
			"data-held": "true",
			"data-snapped": !!i.target,
			"data-invalid": !!i.error,
			children: [
				/* @__PURE__ */ m("path", {
					className: Q.cableShadow,
					d: v
				}),
				/* @__PURE__ */ m("path", {
					className: Q.cableLine,
					d: v
				}),
				!i.target && /* @__PURE__ */ m("circle", {
					className: Q.loosePlug,
					cx: _.x,
					cy: _.y,
					r: 8
				})
			]
		})]
	})] });
}
// src/audio/studio-processor.js
var yo = [
	1e-4,
	3e-4,
	.001,
	.003,
	.01,
	.03
], bo = [
	.1,
	.3,
	.6,
	1.2
], xo = [
	1,
	2,
	3,
	4,
	6,
	10,
	20,
	100
], So = [
	35,
	60,
	110,
	220
], Co = [
	360,
	700,
	1600,
	3200,
	4800,
	7200
], wo = [
	0,
	50,
	80,
	160,
	300
], To = (e) => 10 ** (e / 20), Eo = [
	1,
	0,
	0,
	0,
	0
];
function Do(e, t, n, r, i) {
	if (!t) return Eo.slice();
	let a = 2 * Math.PI * Math.min(t, i * .45) / i, o = Math.cos(a), s = Math.sin(a), c = 10 ** (n / 40), l = s / (2 * r), u = s * Math.sqrt(2 * c), d, f, p, m, h, g;
	if (e === "pole") {
		let e = Math.tan(a / 2);
		return [
			1 / (1 + e),
			-1 / (1 + e),
			0,
			(e - 1) / (e + 1),
			0
		];
	}
	return e === "highpass" ? [d, f, p, m, h, g] = [
		(1 + o) / 2,
		-(1 + o),
		(1 + o) / 2,
		1 + l,
		-2 * o,
		1 - l
	] : e === "bell" ? [d, f, p, m, h, g] = [
		1 + l * c,
		-2 * o,
		1 - l * c,
		1 + l / c,
		-2 * o,
		1 - l / c
	] : e === "low" ? [d, f, p, m, h, g] = [
		c * (c + 1 - (c - 1) * o + u),
		2 * c * (c - 1 - (c + 1) * o),
		c * (c + 1 - (c - 1) * o - u),
		c + 1 + (c - 1) * o + u,
		-2 * (c - 1 + (c + 1) * o),
		c + 1 + (c - 1) * o - u
	] : [d, f, p, m, h, g] = [
		c * (c + 1 + (c - 1) * o + u),
		-2 * c * (c - 1 + (c + 1) * o),
		c * (c + 1 + (c - 1) * o - u),
		c + 1 - (c - 1) * o + u,
		2 * (c - 1 - (c + 1) * o),
		c + 1 - (c - 1) * o - u
	], [
		d / m,
		f / m,
		p / m,
		h / m,
		g / m
	];
}
function Oo(e, t) {
	let n = wo[e.hpf] ?? 0;
	return [
		Do("pole", n, 0, 1, t),
		Do("highpass", n, 0, 1, t),
		Do("low", So[e.lfFreq] ?? 110, e.lfGain, .7, t),
		Do("bell", Co[e.midFreq] ?? 1600, e.midGain, .75, t),
		Do("high", 12e3, e.hfGain, .7, t)
	];
}
function ko(e, t, n = 48e3) {
	if (e.active) return 0;
	let r = 2 * Math.PI * t / n, i = (e, t, n) => Math.hypot(e + t * Math.cos(r) + n * Math.cos(2 * r), t * Math.sin(r) + n * Math.sin(2 * r));
	return Oo(e, n).reduce((e, [t, n, r, a, o]) => e + 20 * Math.log10(i(t, n, r) / i(1, a, o)), 0);
}
function Ao(e, t) {
	let n, r, i;
	return e === "cohere" ? (n = [
		2,
		4,
		10
	][t.ratio] ?? 4, r = t.threshold + [
		-3,
		0,
		2
	][t.ratio], i = [
		9,
		6,
		3
	][t.ratio]) : (n = xo[t.ratio] ?? 6, r = [
		-18,
		-26,
		-24,
		-22,
		-20,
		-18,
		-16,
		-18
	][t.ratio], i = [
		0,
		15,
		12,
		9,
		6,
		4,
		2,
		3
	][t.ratio], t.fierce && (n = Math.max(12, n * 2), r -= 3, i = 2)), [
		1 - 1 / n,
		r,
		i
	];
}
function jo(e, t, n, r) {
	if (!t) return 0;
	let i = e - n;
	return i <= -r / 2 ? 0 : i >= r / 2 ? -i * t : -t * (i + r / 2) ** 2 / (2 * r);
}
var Mo = class {
	constructor(e) {
		this.c = Eo.slice(), this.target = Eo.slice(), this.z1 = 0, this.z2 = 0, this.smooth = 1 - Math.exp(-1 / (e * .008));
	}
	set(e, t) {
		this.target = e, t && (this.c = e.slice());
	}
	run(e) {
		let t = this.c;
		for (let e = 0; e < 5; e++) t[e] += (this.target[e] - t[e]) * this.smooth;
		let n = t[0] * e + this.z1;
		return this.z1 = t[1] * e - t[3] * n + this.z2, this.z2 = t[2] * e - t[4] * n, n;
	}
}, No = Float64Array.from({ length: 49 }, (e, t) => {
	let n = t - 24, r = .1125;
	return (n ? Math.sin(2 * Math.PI * r * n) / (Math.PI * n) : 2 * r) * (.42 - .5 * Math.cos(2 * Math.PI * t / 48) + .08 * Math.cos(4 * Math.PI * t / 48));
}), Po = No.reduce((e, t) => e + t, 0);
for (let e = 0; e < No.length; e++) No[e] /= Po;
var Fo = class {
	constructor() {
		this.buffer = /* @__PURE__ */ new Float64Array(49), this.index = 0;
	}
	push(e) {
		this.buffer[this.index] = e, this.index = (this.index + 1) % 49;
	}
	run(e) {
		this.buffer[this.index] = e;
		let t = 0, n = this.index;
		for (let e = 0; e < 49; e++) t += No[e] * this.buffer[n], --n < 0 && (n = 48);
		return this.index = (this.index + 1) % 49, t;
	}
}, Io = class {
	constructor() {
		this.buffer = /* @__PURE__ */ new Float64Array(13), this.index = 0;
	}
	push(e) {
		this.index = this.index ? this.index - 1 : 12, this.buffer[this.index] = e;
	}
	run(e) {
		let t = 0, n = this.index;
		for (let r = e; r < 49; r += 4) t += No[r] * this.buffer[n], ++n > 12 && (n = 0);
		return t;
	}
}, Lo = class {
	constructor() {
		this.buffer = /* @__PURE__ */ new Float64Array(12), this.index = 0;
	}
	run(e) {
		let t = this.buffer[this.index];
		return this.buffer[this.index] = e, this.index = (this.index + 1) % this.buffer.length, t;
	}
}, Ro = class {
	constructor(e) {
		this.up = new Io(), this.down = new Fo(), this.clean = new Lo(), this.previous = 0, this.blocked = 0, this.dc = Math.exp(-2 * Math.PI * 5 / e);
	}
	run(e, t, n) {
		let r = 0, i = Math.tanh(n), a = t * (1 - i * i);
		this.up.push(e * 4);
		for (let e = 0; e < 4; e++) {
			let o = this.up.run(e), s = (Math.tanh(t * o + n) - i) / a;
			e === 0 ? r = this.down.run(s - o) : this.down.push(s - o);
		}
		return this.blocked = r - this.previous + this.dc * this.blocked, this.previous = r, this.clean.run(e) + this.blocked;
	}
}, zo = class {
	constructor(e, t) {
		this.type = e, this.rate = t, this.params = null, this.events = [], this.disposed = !1, this.reduction = 0, this.gain = [0, 0], this.memory = [0, 0], this.input = 1, this.output = 1, this.wet = 1, this.drive = 0, this.smooth = 1 - Math.exp(-1 / (t * .008)), this.channels = Array.from({ length: 2 }, () => ({
			filters: Array.from({ length: 5 }, () => new Mo(t)),
			hp: new Mo(t),
			emphasis: new Mo(t),
			audioPole: new Mo(t),
			audioHp: new Mo(t),
			color: new Ro(t),
			dry: new Lo(),
			clean: new Lo(),
			amount: .15,
			bias: 0
		}));
	}
	enqueue(e) {
		this.events.push(e), this.events.sort((e, t) => e.time - t.time);
	}
	configure(e) {
		let t = !this.params;
		this.params = { ...e }, this.inputTarget = To(this.type === "talon" ? e.input : 0), this.outputTarget = To(e.output), this.wetTarget = +!e.active, this.driveTarget = e.drive ?? 0, t && (this.input = this.inputTarget, this.output = this.outputTarget, this.wet = this.wetTarget, this.drive = this.driveTarget), this.type !== "brit" && (this.curveTarget = Ao(this.type, e), this.linkTarget = this.type === "cohere" ? 1 : e.link, this.attackTarget = this.type === "cohere" ? yo[e.attack] : e.attack, this.releaseTarget = this.type === "cohere" ? bo[e.release] ?? .3 : e.release, t && (this.curve = this.curveTarget.slice(), this.link = this.linkTarget, this.attack = this.attackTarget, this.release = this.releaseTarget));
		for (let n of this.channels) {
			this.type === "brit" && Oo(e, this.rate).forEach((e, r) => n.filters[r].set(e, t));
			let r = this.type === "cohere" ? [
				0,
				30,
				60,
				106,
				125,
				185
			][e.scHpf] : e.detectorHp ? 80 : 0;
			n.hp.set(Do("highpass", r, 0, Math.SQRT1_2, this.rate), t), n.emphasis.set(Do("bell", 6e3, e.detectorBand ? 10 : 0, 1, this.rate), t), n.audioPole.set(Do("pole", e.audioHp ? 49.01 : 0, 0, 1, this.rate), t), n.audioHp.set(Do("highpass", e.audioHp ? 44.915 : 0, 0, .691, this.rate), t), t && this.type === "talon" && (n.amount = [
				.15,
				.8,
				1.5
			][e.color], n.bias = e.color === 1 ? .3 : 0);
		}
	}
	envelope(e, t) {
		let n = this.params, r = jo(e, this.curve[0], this.curve[1], this.curve[2]), i = this.gain[t];
		this.memory[t] += (Math.max(0, -i) - this.memory[t]) * (1 - Math.exp(-1 / (this.rate * .6)));
		let a = this.release;
		this.type === "cohere" && n.release === 4 && (a = .1 + Math.min(1.1, this.memory[t] * .09)), this.type === "talon" && (n.ratio === 5 ? a = Math.min(20, this.release * (1 + this.memory[t] * .9)) : n.ratio === 7 ? a *= .45 + Math.min(1.5, Math.max(0, -i) / 15) : a *= [
			1,
			1.15,
			1.05,
			1,
			.9,
			1,
			.8,
			1
		][n.ratio], n.ratio !== 5 && (a = Math.min(3.5, a)), n.fierce && (a *= .65));
		let o = r < i ? this.attack : a;
		return this.gain[t] += (r - i) * (1 - Math.exp(-1 / (o * this.rate))), To(this.gain[t]);
	}
	render(e, t, n = 0) {
		if (this.disposed) {
			t.forEach((e) => e.fill(0));
			return;
		}
		let r = t[0].length;
		for (let i = 0; i < r; i++) {
			let r = (n + i) / this.rate;
			for (; this.events.length && this.events[0].time <= r;) this.configure(this.events.shift().params);
			if (!this.params) {
				t.forEach((e) => {
					e[i] = 0;
				});
				continue;
			}
			let a = this.params;
			this.input += (this.inputTarget - this.input) * this.smooth, this.output += (this.outputTarget - this.output) * this.smooth, this.wet += (this.wetTarget - this.wet) * this.smooth, this.drive += (this.driveTarget - this.drive) * this.smooth;
			let o = e[0]?.[i] ?? 0, s = e[1]?.[i] ?? o, c = o * this.input, l = s * this.input, u = 1, d = 1;
			if (this.type !== "brit") {
				for (let e = 0; e < 3; e++) this.curve[e] += (this.curveTarget[e] - this.curve[e]) * this.smooth;
				this.link += (this.linkTarget - this.link) * this.smooth, this.attack += (this.attackTarget - this.attack) * this.smooth, this.release += (this.releaseTarget - this.release) * this.smooth;
				let e = this.channels[0], t = this.channels[1], n = 20 * Math.log10(Math.max(1e-12, Math.abs(e.emphasis.run(e.hp.run(c))))), r = 20 * Math.log10(Math.max(1e-12, Math.abs(t.emphasis.run(t.hp.run(l))))), i = Math.max(n, r);
				this.envelope(n + this.link * (i - n), 0), this.envelope(r + this.link * (i - r), 1);
				let a = Math.min(this.gain[0], this.gain[1]), o = Math.max(this.memory[0], this.memory[1]), s = this.link * this.smooth;
				for (let e = 0; e < 2; e++) this.gain[e] += (a - this.gain[e]) * s, this.memory[e] += (o - this.memory[e]) * s;
				u = To(this.gain[0]), d = To(this.gain[1]), this.reduction = Math.min(this.gain[0], this.gain[1]) * this.wet;
			}
			for (let e = 0; e < t.length; e++) {
				let n = this.channels[e], r = e === 0 ? o : s, f = e === 0 ? c : l;
				if (this.type === "brit") {
					for (let e of n.filters) f = e.run(f);
					f = n.color.run(f, .22 * To(this.drive), .12);
				} else if (this.type === "talon") {
					f = n.audioHp.run(n.audioPole.run(f * (e === 0 ? u : d)));
					let t = [
						.15,
						.8,
						1.5
					][a.color] * (1 + Math.min(2, -this.gain[e] / 20));
					n.amount += (t - n.amount) * this.smooth, n.bias += ((a.color === 1 ? .3 : 0) - n.bias) * this.smooth, f = n.color.run(f, n.amount, n.bias);
				} else f = n.clean.run(f * (e === 0 ? u : d));
				let p = n.dry.run(r);
				t[e][i] = p + this.wet * (f * this.output - p);
			}
		}
	}
};
if (typeof registerProcessor < "u") {
	class e extends AudioWorkletProcessor {
		constructor(e) {
			super(), this.dsp = new zo(e.processorOptions.type, sampleRate), this.meterFrames = 0, this.port.onmessage = ({ data: e }) => {
				e.type === "flush" ? this.port.postMessage({ id: e.id }) : e.type === "dispose" ? (this.dsp.disposed = !0, this.dsp.events = []) : this.dsp.enqueue(e);
			};
		}
		process(e, t) {
			return this.dsp.render(e[0] ?? [], t[0], currentFrame), this.meterFrames += t[0][0].length, this.meterFrames >= sampleRate / 25 && (this.meterFrames = 0, this.port.postMessage({ reduction: this.dsp.reduction })), !this.dsp.disposed;
		}
	}
	registerProcessor("rackloose-studio-v1", e);
}
// src/components/Glyphs.tsx
var Bo = (e) => e.map((t, n) => `${n ? "L" : "M"}${(2 + n * 44 / (e.length - 1)).toFixed(1)} ${(17 - t * 14).toFixed(1)}`).join(" ");
function Vo(e, t) {
	let n = t, r = .5, i = Array.from({ length: 25 }, () => (n = n * 16807 % 2147483647, r += (n / 2147483647 - r) * e, r)), a = Math.min(...i), o = Math.max(...i);
	return Bo(i.map((e) => .1 + (e - a) / (o - a) * .8));
}
var Ho = {
	Sine: Bo(Array.from({ length: 33 }, (e, t) => .5 + .5 * Math.sin(t / 32 * Math.PI * 4))),
	Triangle: Bo([
		0,
		1,
		0,
		1,
		0
	]),
	Saw: "M2 17L24 3V17L46 3V17",
	Square: "M2 17V3H13V17H24V3H35V17H46V3",
	Pulse: "M2 17V3H8V17H24V3H30V17H46",
	"Saw + Pulse": "M2 17L13 13.5V6.5L24 3V17L35 13.5V6.5L46 3V17",
	"Low-pass": "M2 7H24C30 7 31 3 33 6C35 10 38 17 46 18",
	"High-pass": "M2 18C10 17 13 10 15 6C17 3 18 7 24 7H46",
	"Band-pass": "M2 18C14 17 18 4 24 4C30 4 34 17 46 18",
	White: Vo(1, 7),
	Pink: Vo(.45, 11),
	Brown: Vo(.16, 23),
	Bell: "M2 14C14 14 18 4 24 4C30 4 34 14 46 14",
	"Low shelf": "M2 6H14C20 6 22 14 30 14H46",
	"High shelf": "M2 14H18C26 14 28 6 34 6H46"
};
function Uo({ param: e, value: t }) {
	let n = e.choices?.[t] ?? "", r = Ho[n === "Shelf" ? e.id === "hfBell" ? "High shelf" : "Low shelf" : n];
	return r ? /* @__PURE__ */ m("svg", {
		className: Q.choiceGlyph,
		viewBox: "0 0 48 20",
		"aria-hidden": "true",
		children: /* @__PURE__ */ m("path", { d: r })
	}) : null;
}
function Wo({ params: e, brit: t = !1, rate: n = 48e3 }) {
	let r = Ua(e, 24e3), i = (e) => 25 - Math.max(-18, Math.min(18, e)) * 22 / 18, a = Array.from({ length: 72 }, (a, o) => {
		let s = 20 * 1e3 ** (o / 71);
		return `${o ? "L" : "M"}${(3 + o * 114 / 71).toFixed(1)} ${i(t ? ko(e, s, n) : r.reduce((e, t) => e + Wa(t, s, 48e3), 0)).toFixed(1)}`;
	}).join("");
	return /* @__PURE__ */ h("svg", {
		className: Q.eqGraphic,
		viewBox: "0 0 120 50",
		role: t ? "img" : void 0,
		"aria-label": t ? `BRIT filter response, 20 Hz to 20 kHz, at ${n / 1e3} kHz` : void 0,
		"aria-hidden": !t || void 0,
		"data-bypassed": e.active === 1,
		children: [
			[
				100,
				1e3,
				1e4
			].map((e) => /* @__PURE__ */ m("line", {
				x1: 3 + Math.log10(e / 20) / 3 * 114,
				x2: 3 + Math.log10(e / 20) / 3 * 114,
				y1: "3",
				y2: "47"
			}, e)),
			/* @__PURE__ */ m("line", {
				x1: "3",
				x2: "117",
				y1: "25",
				y2: "25"
			}),
			/* @__PURE__ */ m("path", { d: a })
		]
	});
}
function Go({ reduction: e, label: t, max: n = 20 }) {
	let r = Math.min(n, Math.max(0, -e)), i = (e) => 45 - e / n * 90, a = (e, t) => {
		let n = (i(e) - 90) * Math.PI / 180;
		return [60 + Math.cos(n) * t, 60 + Math.sin(n) * t].map((e) => Number(e.toFixed(1)));
	};
	return /* @__PURE__ */ m("div", {
		className: Q.grMeter,
		role: "meter",
		"aria-label": t,
		"aria-valuemin": 0,
		"aria-valuemax": n,
		"aria-valuenow": r,
		"aria-valuetext": `${r} dB gain reduction`,
		children: /* @__PURE__ */ h("svg", {
			viewBox: "0 0 120 50",
			"aria-hidden": "true",
			children: [
				/* @__PURE__ */ m("path", { d: `M${a(0, 48).join(" ")}A48 48 0 0 0 ${a(n, 48).join(" ")}` }),
				[
					0,
					n / 4,
					n / 2,
					n * 3 / 4,
					n
				].map((e) => {
					let [t, n] = a(e, 48), [r, i] = a(e, 53), [o, s] = a(e, 40);
					return /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("line", {
						x1: t,
						y1: n,
						x2: r,
						y2: i
					}), /* @__PURE__ */ m("text", {
						x: o,
						y: s,
						textAnchor: "middle",
						dominantBaseline: "middle",
						children: e
					})] }, e);
				}),
				/* @__PURE__ */ m("text", {
					className: Q.grUnit,
					x: "8",
					y: "45",
					children: "GR dB"
				}),
				/* @__PURE__ */ m("line", {
					className: Q.grNeedle,
					x1: "60",
					y1: "60",
					x2: "60",
					y2: "8",
					style: { transform: `rotate(${i(r)}deg)` }
				})
			]
		})
	});
}
var [Ko, qo, , Jo] = Z.envelope.params;
function Yo({ params: e }) {
	let t = (t) => 9 + Er(t, e[t.id]) * 24, n = 3 + t(Ko), r = n + t(qo), i = 117 - t(Jo), a = 40 - e.sustain * 35, o = [
		["A", (3 + n) / 2],
		["D", (n + r) / 2],
		["S", (r + i) / 2],
		["R", (i + 117) / 2]
	];
	return /* @__PURE__ */ h("svg", {
		className: Q.envelopeGraphic,
		viewBox: "0 0 120 50",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ m("path", { d: `M3 40L${n.toFixed(1)} 5L${r.toFixed(1)} ${a.toFixed(1)}L${i.toFixed(1)} ${a.toFixed(1)}L117 40` }), o.map(([e, t]) => /* @__PURE__ */ m("text", {
			x: t.toFixed(1),
			y: "48",
			textAnchor: "middle",
			children: e
		}, e))]
	});
}
var Xo = {
	play: /* @__PURE__ */ m("path", { d: "M3.5 2.2v9.6L11.6 7z" }),
	pause: /* @__PURE__ */ m("path", { d: "M3 2.2h2.9v9.6H3zM8.1 2.2H11v9.6H8.1z" }),
	stop: /* @__PURE__ */ m("path", { d: "M2.8 2.8h8.4v8.4H2.8z" }),
	reset: /* @__PURE__ */ m("path", { d: "M2.4 2.2h2v9.6h-2zM11.8 2.2v9.6L4.9 7z" }),
	undo: /* @__PURE__ */ m("path", {
		d: "M5.2 2.4 1.6 5.8l3.6 3.4V7.1h3.2a2.6 2.6 0 0 1 0 5.2H6.6v1.5h1.8a4.1 4.1 0 0 0 0-8.2H5.2z",
		transform: "translate(0 -1.2)"
	}),
	redo: /* @__PURE__ */ m("path", {
		d: "M8.8 2.4l3.6 3.4-3.6 3.4V7.1H5.6a2.6 2.6 0 0 0 0 5.2h1.8v1.5H5.6a4.1 4.1 0 0 1 0-8.2h3.2z",
		transform: "translate(0 -1.2)"
	})
};
function Zo({ name: e }) {
	return /* @__PURE__ */ m("svg", {
		className: Q.icon,
		viewBox: "0 0 14 14",
		"aria-hidden": "true",
		focusable: "false",
		children: Xo[e]
	});
}
// src/components/MixButtons.tsx
function Qo({ mixKey: e, label: t, mix: n, onToggle: r, solo: i = !0, onClear: a, clearable: o, onSwap: s }) {
	let c = n.muted.has(e), l = n.soloed.has(e);
	return /* @__PURE__ */ h("span", {
		className: Q.mixButtons,
		children: [
			/* @__PURE__ */ m("button", {
				className: Q.muteToggle,
				"aria-label": `Mute ${t}`,
				"aria-pressed": c,
				title: `Mute ${t}`,
				onClick: () => r(e, "muted"),
				children: "M"
			}),
			i && /* @__PURE__ */ m("button", {
				className: Q.soloToggle,
				"aria-label": `Solo ${t}`,
				"aria-pressed": l,
				title: `Solo ${t}`,
				onClick: () => r(e, "soloed"),
				children: "S"
			}),
			a && /* @__PURE__ */ m("button", {
				className: Q.clearToggle,
				"aria-label": `Clear ${t} mutes and solos`,
				title: `Clear ${t} mutes and solos`,
				disabled: !o,
				onClick: a,
				children: "CLR"
			}),
			s && /* @__PURE__ */ m("button", {
				className: Q.swapToggle,
				"aria-label": `Swap ${t} mute and solo`,
				title: `Swap ${t} mute and solo`,
				disabled: !c && !l,
				onClick: s,
				children: "SWAP"
			})
		]
	});
}
// src/components/Drums.tsx
var $o = [
	[1, "1/16"],
	[2, "1/32"],
	[3, "×3 · 1/32T"],
	[4, "×4 · 1/64"],
	[6, "×6 · 1/64T"]
], es = {
	2: "1/32",
	3: "1/32 triplet",
	4: "1/64",
	6: "1/64 triplet"
}, ts = (e) => (t) => {
	if (t <= 0) return "-∞ dB";
	let n = 20 * Math.log10(t / e.initial);
	return Math.abs(n) < .05 ? "0 dB" : `${n > 0 ? "+" : ""}${n.toFixed(1)} dB`;
};
function ns({ module: e, voice: t, onParams: n, labelled: r }) {
	let i = Z[e.type], a = i.params.find((e) => e.id === `${t}Level`);
	if (!a) return null;
	let o = /* @__PURE__ */ m(ho, {
		trim: !0,
		param: a,
		prefix: i.name,
		format: ts(a),
		value: e.params[a.id],
		onChange: (e) => n({ [a.id]: e })
	});
	return r ? /* @__PURE__ */ h("div", {
		className: Q.laneLevel,
		children: [o, /* @__PURE__ */ m("span", {
			"aria-hidden": "true",
			children: "LEVEL"
		})]
	}) : o;
}
function rs(e, t, n, r) {
	let i = e.params, a = 1 << n, o = En(i[`${t}Pattern`], n), s = On(e, t, n), c = (e) => Object.fromEntries(Et.map((n) => [Dt(t, n), n === e ? i[Dt(t, n)] | a : i[Dt(t, n)] & ~a]));
	return r === 1 ? {
		[`${t}Pattern`]: i[`${t}Pattern`] ^ a,
		...o ? c(0) : {}
	} : {
		[`${t}Pattern`]: i[`${t}Pattern`] | a,
		...c(o && s === r ? 0 : r)
	};
}
function is({ name: e, brush: t, onBrush: n }) {
	return /* @__PURE__ */ h("div", {
		className: Q.rollBrush,
		role: "group",
		"aria-label": `${e} pad mode`,
		children: [/* @__PURE__ */ m("span", { children: "NOTE" }), $o.map(([e, r]) => /* @__PURE__ */ m("button", {
			"aria-pressed": t === e,
			onClick: () => n(e),
			children: r
		}, e))]
	});
}
function as({ module: e, mix: t, onMix: n, step: r, onParams: i, onAudition: a, disabled: o, selected: s, onSelect: c, brush: l = 1 }) {
	let u = Z[e.type], d = u.params.some((e) => e.id === Dt(u.drum.voices[0].id, 2));
	return /* @__PURE__ */ m("div", {
		className: Q.drumPads,
		children: u.drum.voices.map((f) => {
			let p = `${f.id}Pattern`, g = e.params[p];
			return /* @__PURE__ */ h("div", {
				className: Q.drumLane,
				"data-silent": !Qn(e, f.id, t),
				children: [
					/* @__PURE__ */ m("button", {
						className: Q.voiceButton,
						"aria-label": `Play ${u.name} ${f.label}`,
						"aria-pressed": c ? s === f.id : void 0,
						disabled: o,
						onClick: () => {
							c?.(f.id), a(f.id);
						},
						children: f.label
					}),
					/* @__PURE__ */ m(Qo, {
						mixKey: Gn(e.id, f.id),
						label: `${u.name} ${f.label}`,
						mix: t,
						onToggle: n
					}),
					/* @__PURE__ */ m(ns, {
						labelled: !0,
						module: e,
						voice: f.id,
						onParams: i
					}),
					/* @__PURE__ */ m("div", {
						className: Q.pads,
						children: [
							0,
							1,
							2,
							3
						].map((t) => /* @__PURE__ */ m("div", {
							className: Q.padGroup,
							"data-group": t,
							children: [
								0,
								1,
								2,
								3
							].map((n) => {
								let a = t * 4 + n, o = En(g, a), s = o && d ? On(e, f.id, a) : 1;
								return /* @__PURE__ */ h("button", {
									className: Q.pad,
									"data-current": r === a,
									"data-roll": s > 1 ? s : void 0,
									"aria-pressed": o,
									"aria-label": `${u.name} ${f.label} step ${a + 1}${s > 1 ? `, ${es[s]}` : ""}`,
									onClick: () => i(d ? rs(e, f.id, a, l) : { [p]: g ^ 1 << a }),
									children: [/* @__PURE__ */ m("span", {}), s > 1 && /* @__PURE__ */ m("small", { children: s })]
								}, a);
							})
						}, t))
					})
				]
			}, f.id);
		})
	});
}
var os = [
	"Steps",
	"Hits",
	"Shift"
];
function ss({ module: t, mix: n, onMix: r, onParams: i, onAudition: a, disabled: o, clock: s, selected: c, onSelect: l, controls: u }) {
	let d = Z[t.type], f = d.drum.voices.find((e) => e.id === c), p = jn(t, c);
	return /* @__PURE__ */ h("div", {
		className: Q.orbitEditor,
		children: [
			/* @__PURE__ */ h("div", {
				className: Q.euclid,
				role: "group",
				"aria-label": `${d.name} rhythm`,
				children: [
					/* @__PURE__ */ m("span", { children: "VOICE / EDIT" }),
					/* @__PURE__ */ m("span", {}),
					[...os, "Level"].map((e) => /* @__PURE__ */ m("span", {
						className: Q.euclidHeading,
						children: e
					}, e)),
					d.drum.voices.map((s) => /* @__PURE__ */ h(e, { children: [
						/* @__PURE__ */ m("button", {
							className: Q.voiceButton,
							"aria-label": `Play ${d.name} ${s.label}`,
							"aria-pressed": c === s.id,
							disabled: o,
							"data-silent": !Qn(t, s.id, n),
							onClick: () => {
								l(s.id), a(s.id);
							},
							children: s.label
						}),
						/* @__PURE__ */ m(Qo, {
							mixKey: Gn(t.id, s.id),
							label: `${d.name} ${s.label}`,
							mix: n,
							onToggle: r
						}),
						os.map((e) => {
							let n = d.params.find((t) => t.id === `${s.id}${e}`);
							return /* @__PURE__ */ h("div", {
								className: Q.euclidCell,
								children: [/* @__PURE__ */ m(ho, {
									trim: !0,
									param: n,
									prefix: d.name,
									disabled: e !== "Steps" && !!t.params[`${s.id}Custom`],
									value: t.params[n.id],
									onChange: (e) => i({ [n.id]: e })
								}), /* @__PURE__ */ m("output", { children: t.params[n.id] })]
							}, e);
						}),
						/* @__PURE__ */ m(ns, {
							module: t,
							voice: s.id,
							onParams: i
						})
					] }, s.id))
				]
			}),
			/* @__PURE__ */ h("div", {
				className: Q.orbitVoiceEditor,
				role: "group",
				"aria-label": `Edit ORBIT ${f.label}`,
				children: [
					/* @__PURE__ */ h("div", {
						className: Q.orbitEditorHeading,
						children: [
							/* @__PURE__ */ h("label", { children: ["EDIT VOICE ", /* @__PURE__ */ m("select", {
								"aria-label": "Orbit edit voice",
								value: c,
								onChange: (e) => l(e.target.value),
								children: d.drum.voices.map((e) => /* @__PURE__ */ m("option", {
									value: e.id,
									children: e.label
								}, e.id))
							})] }),
							/* @__PURE__ */ m("span", { children: t.params[`${c}Custom`] ? "CUSTOM" : "EUCLIDEAN" }),
							/* @__PURE__ */ m("button", {
								disabled: !Pn(t, c),
								onClick: () => i(Nn(t, c)),
								"aria-label": `Generate ORBIT ${f.label} rhythm`,
								title: Pn(t, c) ? "Spread this lane’s hits evenly" : "Already Euclidean: turn Steps, Hits or Shift",
								children: "Generate"
							})
						]
					}),
					/* @__PURE__ */ m("div", {
						className: Q.controls,
						children: [
							"Tune",
							"Decay",
							"Tone",
							"Pan",
							"Lag"
						].map((e) => {
							let n = d.params.find((t) => t.id === `${c}${e}`);
							return /* @__PURE__ */ m(ho, {
								param: {
									...n,
									label: e
								},
								prefix: `ORBIT ${f.label}`,
								value: t.params[n.id],
								onChange: (e) => i({ [n.id]: e })
							}, n.id);
						})
					}),
					/* @__PURE__ */ m("div", {
						className: Q.orbitSteps,
						children: p.map((e, n) => /* @__PURE__ */ h("button", {
							className: Q.pad,
							"aria-pressed": e,
							"data-current": s >= 0 && s % p.length === n,
							"aria-label": `ORBIT ${f.label} step ${n + 1}`,
							onClick: () => {
								let e = Mn(t, c, n);
								i({
									[`${c}Pattern`]: e[`${c}Pattern`],
									[`${c}Custom`]: 1
								});
							},
							children: [/* @__PURE__ */ m("span", {}), n + 1]
						}, n))
					}),
					/* @__PURE__ */ m("small", { children: "Tap a step to customize. Generate makes it Euclidean again." })
				]
			}),
			/* @__PURE__ */ h("div", {
				className: Q.orbitDevice,
				children: [/* @__PURE__ */ m(ls, {
					module: t,
					clock: s
				}), u]
			})
		]
	});
}
var cs = [
	70,
	59,
	48,
	37,
	26,
	15
];
function ls({ module: e, clock: t }) {
	return /* @__PURE__ */ m("svg", {
		className: Q.orbitRings,
		viewBox: "0 0 160 160",
		"aria-hidden": "true",
		children: Z[e.type].drum.voices.map(({ id: n }, r) => {
			let i = jn(e, n), a = cs[r], o = t < 0 ? -1 : t % i.length;
			return /* @__PURE__ */ h("g", {
				"data-voice": n,
				children: [/* @__PURE__ */ m("circle", {
					className: Q.orbitPath,
					cx: "80",
					cy: "80",
					r: a
				}), i.map((e, t) => {
					let n = t / i.length * 2 * Math.PI - Math.PI / 2;
					return /* @__PURE__ */ m("circle", {
						cx: (80 + a * Math.cos(n)).toFixed(2),
						cy: (80 + a * Math.sin(n)).toFixed(2),
						r: t === o ? 3.8 : e ? 3 : 1.4,
						"data-hit": e,
						"data-current": t === o
					}, t);
				})]
			}, n);
		})
	});
}
// src/components/SoundEditors.tsx
function us({ module: e, onParams: t, onAudition: n, disabled: r, selected: i, onSelect: a }) {
	let o = Z[e.type], s = o.drum.voices.find((e) => e.id === i);
	return /* @__PURE__ */ h("div", {
		className: Q.soundEditor,
		role: "group",
		"aria-label": `${o.name} voice editor`,
		children: [/* @__PURE__ */ h("div", {
			className: Q.editorHeading,
			children: [/* @__PURE__ */ h("label", { children: [/* @__PURE__ */ m("span", { children: "EDIT VOICE" }), /* @__PURE__ */ m("select", {
				"aria-label": `${o.name} edit voice`,
				value: i,
				onChange: (e) => a(e.target.value),
				children: o.drum.voices.map((e) => /* @__PURE__ */ m("option", {
					value: e.id,
					children: e.label
				}, e.id))
			})] }), /* @__PURE__ */ h("button", {
				disabled: r,
				onClick: () => n(i),
				children: ["Audition ", s.label]
			})]
		}), /* @__PURE__ */ m("div", {
			className: Q.controls,
			children: o.params.filter((e) => e.voice === i && !e.pattern && e.id !== `${i}Level`).map((n) => /* @__PURE__ */ m(ho, {
				param: {
					...n,
					label: n.label.slice(s.label.length + 1)
				},
				prefix: `${o.name} ${s.label}`,
				value: e.params[n.id],
				onChange: (e) => t({ [n.id]: e })
			}, n.id))
		})]
	});
}
var ds = [
	"2→1 + 4→3 + 6→5",
	"3→2→1 + 6→5→4",
	"6→5→4→3→2→1",
	"5+6→4→1+2+3",
	"4→2→1 + 6→5→3→1",
	"1 + 2 + 3 + 4 + 5 + 6"
];
function fs({ module: e, onParams: t }) {
	let [n, r] = d(1);
	return /* @__PURE__ */ h("div", {
		className: Q.soundEditor,
		role: "group",
		"aria-label": "PRISM operator editor",
		children: [
			/* @__PURE__ */ h("div", {
				className: Q.fmDisplay,
				children: [
					/* @__PURE__ */ m("span", { children: ht[e.params.algorithm] }),
					/* @__PURE__ */ m("strong", { children: ds[e.params.algorithm] }),
					/* @__PURE__ */ m("small", { children: "16 VOICES · SIX OPERATORS · PHASE MODULATION" })
				]
			}),
			/* @__PURE__ */ m("div", {
				className: Q.operatorTabs,
				role: "group",
				"aria-label": "Select PRISM operator",
				children: [
					1,
					2,
					3,
					4,
					5,
					6
				].map((e) => /* @__PURE__ */ h("button", {
					"aria-pressed": n === e,
					"aria-label": `Edit PRISM operator ${e}`,
					onClick: () => r(e),
					children: ["OP ", e]
				}, e))
			}),
			/* @__PURE__ */ m("div", {
				className: Q.controls,
				children: Z.prism.params.filter((e) => e.voice === `op${n}`).map((r) => /* @__PURE__ */ m(ho, {
					param: r,
					prefix: `PRISM Operator ${n}`,
					value: e.params[r.id],
					onChange: (e) => t({ [r.id]: e })
				}, r.id))
			})
		]
	});
}
// src/components/Drawbars.tsx
var ps = 9, ms = [
	"brown",
	"brown",
	"white",
	"white",
	"black",
	"white",
	"black",
	"black",
	"white"
];
function hs({ params: e, values: t, prefix: n, onChange: r }) {
	return /* @__PURE__ */ m("div", {
		className: Q.drawbars,
		children: e.map((e, i) => /* @__PURE__ */ m(gs, {
			param: e,
			value: t[e.id] ?? e.initial,
			tab: ms[i] ?? "white",
			label: `${n} ${e.label}`,
			onChange: (t) => r(e.id, t)
		}, e.id))
	});
}
function gs({ param: e, value: t, tab: n, label: r, onChange: i }) {
	let a = u(null), o = (n) => {
		let r = Math.max(e.min, Math.min(e.max, Math.round(n)));
		r !== t && i(r);
	}, s = (e) => {
		e.button === 0 && (e.preventDefault(), e.currentTarget.focus(), e.currentTarget.setPointerCapture(e.pointerId), a.current = {
			pointer: e.pointerId,
			y: e.clientY,
			from: t
		});
	}, c = (e) => {
		let t = a.current;
		t?.pointer === e.pointerId && o(t.from + (e.clientY - t.y) / ps);
	}, l = (e) => {
		a.current?.pointer === e.pointerId && (a.current = null);
	};
	return /* @__PURE__ */ m("div", {
		className: Q.drawbarSlot,
		children: /* @__PURE__ */ m("div", {
			className: Q.drawbar,
			"data-tab": n,
			role: "slider",
			tabIndex: 0,
			"aria-label": r,
			"aria-orientation": "vertical",
			"aria-valuemin": e.min,
			"aria-valuemax": e.max,
			"aria-valuenow": t,
			"aria-valuetext": t ? `${t} of 8` : "In",
			title: `${e.hint ?? e.label} Drag down to pull it out, or use the arrow and number keys; double-click puts it back.`,
			style: { "--pull": t / e.max },
			onPointerDown: s,
			onPointerMove: c,
			onPointerUp: l,
			onPointerCancel: l,
			onLostPointerCapture: l,
			onKeyDown: (n) => {
				let r = {
					ArrowDown: 1,
					ArrowRight: 1,
					ArrowUp: -1,
					ArrowLeft: -1,
					PageDown: 2,
					PageUp: -2
				}[n.key], i = n.key === "Home" ? e.min : n.key === "End" ? e.max : /^[0-8]$/.test(n.key) ? Number(n.key) : r === void 0 ? null : t + r;
				i !== null && (n.preventDefault(), o(i));
			},
			onDoubleClick: () => o(e.initial),
			children: /* @__PURE__ */ h("span", {
				className: Q.drawbarRod,
				"aria-hidden": "true",
				children: [Array.from({ length: 8 }, (e, t) => /* @__PURE__ */ m("i", {
					style: { "--mark": t },
					children: t + 1
				}, t)), /* @__PURE__ */ m("span", {
					className: Q.drawbarTab,
					children: e.label
				})]
			})
		})
	});
}
// src/components/PanelLegend.tsx
function _s({ size: e, height: t, inner: n, marks: r }) {
	let i = (n, r) => [e / 2 + n * Math.sin(r * Math.PI / 180), t / 2 - n * Math.cos(r * Math.PI / 180)], a = (e, t) => n + 10 + (e.length - 1) * 2.2 * Math.abs(Math.sin(t * Math.PI / 180));
	return /* @__PURE__ */ m("svg", {
		className: Q.panelLegend,
		width: e,
		height: t,
		style: {
			width: e,
			height: t
		},
		viewBox: `0 0 ${e} ${t}`,
		"aria-hidden": "true",
		children: r.map(({ angle: e, text: t, lit: r }, o) => {
			let [s, c] = i(n, e), [l, u] = i(n + (t ? 4 : 2.5), e), [d, f] = i(a(t ?? "", e), e);
			return /* @__PURE__ */ h("g", {
				"data-lit": r || void 0,
				children: [/* @__PURE__ */ m("line", {
					x1: s,
					y1: c,
					x2: l,
					y2: u
				}), t && /* @__PURE__ */ m("text", {
					x: d,
					y: f,
					textAnchor: "middle",
					dominantBaseline: "central",
					children: t
				})]
			}, o);
		})
	});
}
// src/components/Brit.tsx
var vs = (e) => Z.brit.params.find((t) => t.id === e), ys = (e, t) => {
	let n = Math.min(270, (t - 1) * 45);
	return -n / 2 + e * n / (t - 1);
}, bs = (e, t) => e.choices ? ys(t, e.choices.length) : -135 + Er(e, t) * 270, xs = 104, Ss = (e) => ({
	"--size": `${e}px`,
	"--height": `${xs}px`
});
function Cs({ angle: e, skirt: t }) {
	return /* @__PURE__ */ h(p, { children: [
		t && /* @__PURE__ */ m("span", { className: Q.marconiSkirt }),
		/* @__PURE__ */ m("span", { className: Q.marconiFlutes }),
		/* @__PURE__ */ m("span", { className: Q.marconiDome }),
		/* @__PURE__ */ m("span", {
			className: Q.marconiPointer,
			style: { transform: `rotate(${e}deg)` }
		})
	] });
}
var ws = (e, t) => [...Array.from({ length: 11 }, (e, t) => ({ angle: -135 + t * 27 })), ...t.map(([t, n]) => ({
	angle: bs(e, t),
	text: n
}))], Ts = (e, t) => e.map((n, r) => ({
	angle: ys(r, e.length),
	text: n,
	lit: r === t
}));
function Es({ module: e, prefix: t, onParams: n, id: r, color: i, size: a, knob: o, skirt: s, title: c, labels: l, marks: u }) {
	let d = vs(r), f = e.params[r], { props: p, display: g } = mo({
		param: d,
		value: f,
		prefix: t,
		onChange: (e) => n({ [r]: e })
	});
	return /* @__PURE__ */ h("div", {
		className: Q.britSection,
		children: [
			/* @__PURE__ */ m("strong", { children: c }),
			/* @__PURE__ */ h("div", {
				className: Q.britWell,
				style: Ss(a),
				children: [/* @__PURE__ */ m(_s, {
					size: a,
					height: xs,
					inner: o / 2 + 3,
					marks: l ? Ts(l, f) : ws(d, u ?? [])
				}), /* @__PURE__ */ m("div", {
					className: Q.marconi,
					"data-color": i,
					"data-skirt": s || void 0,
					style: { "--knob": `${o}px` },
					...p,
					children: /* @__PURE__ */ m(Cs, {
						angle: bs(d, f),
						skirt: s
					})
				})]
			}),
			!l && /* @__PURE__ */ m("span", {
				className: Q.knobValue,
				children: g
			})
		]
	});
}
function Ds({ module: e, prefix: t, onParams: n, frequency: r, gain: i, color: a, title: o, labels: s }) {
	let c = vs(r), l = vs(i), u = mo({
		param: c,
		value: e.params[r],
		prefix: t,
		onChange: (e) => n({ [r]: e })
	}), d = mo({
		param: l,
		value: e.params[i],
		prefix: t,
		onChange: (e) => n({ [i]: e })
	});
	return /* @__PURE__ */ h("div", {
		className: Q.britSection,
		children: [
			/* @__PURE__ */ m("strong", { children: o }),
			/* @__PURE__ */ h("div", {
				className: Q.britWell,
				style: Ss(112),
				children: [
					/* @__PURE__ */ m(_s, {
						size: 112,
						height: xs,
						inner: 36,
						marks: Ts(s, e.params[r])
					}),
					/* @__PURE__ */ m("div", {
						className: Q.marconiRing,
						style: { "--ring": "66px" },
						...u.props,
						children: /* @__PURE__ */ m("span", {
							className: Q.ringPointer,
							style: { transform: `rotate(${bs(c, e.params[r])}deg)` }
						})
					}),
					/* @__PURE__ */ m("div", {
						className: Q.marconi,
						"data-color": a,
						style: { "--knob": "38px" },
						...d.props,
						children: /* @__PURE__ */ m(Cs, { angle: bs(l, e.params[i]) })
					})
				]
			}),
			/* @__PURE__ */ m("span", {
				className: Q.knobValue,
				children: d.display
			})
		]
	});
}
function Os({ module: e, onParams: t, rate: n }) {
	let r = Z.brit.name, i = e.params.active === 0, a = (n) => ({
		module: e,
		onParams: t,
		prefix: `${r} ${n}`
	});
	return /* @__PURE__ */ h("div", {
		className: Q.britPanel,
		"data-bypassed": !i,
		children: [
			/* @__PURE__ */ m(Es, {
				...a("Signal"),
				id: "hpf",
				color: "blue",
				size: 96,
				knob: 46,
				title: "High pass",
				labels: [
					"OFF",
					"50",
					"80",
					"160",
					"300"
				]
			}),
			/* @__PURE__ */ m(Ds, {
				...a("Low shelf"),
				frequency: "lfFreq",
				gain: "lfGain",
				color: "grey",
				title: "Low · Hz",
				labels: [
					"35",
					"60",
					"110",
					"220"
				]
			}),
			/* @__PURE__ */ m(Ds, {
				...a("Mid bell"),
				frequency: "midFreq",
				gain: "midGain",
				color: "blue",
				title: "Mid · kHz",
				labels: [
					".36",
					".7",
					"1.6",
					"3.2",
					"4.8",
					"7.2"
				]
			}),
			/* @__PURE__ */ m(Es, {
				...a("High shelf · 12 kHz"),
				id: "hfGain",
				color: "grey",
				size: 88,
				knob: 44,
				title: "High · 12k",
				marks: [
					[-16, "−16"],
					[0, "0"],
					[16, "+16"]
				]
			}),
			/* @__PURE__ */ m(Es, {
				...a("Signal"),
				id: "drive",
				color: "red",
				size: 100,
				knob: 64,
				skirt: !0,
				title: "Drive",
				marks: [
					[0, "0"],
					[12, "12"],
					[24, "24"]
				]
			}),
			/* @__PURE__ */ m(Es, {
				...a("Signal"),
				id: "output",
				color: "grey",
				size: 80,
				knob: 36,
				title: "Output",
				marks: [
					[-18, "−18"],
					[0, "0"],
					[18, "+18"]
				]
			}),
			/* @__PURE__ */ h("div", {
				className: Q.britSection,
				children: [/* @__PURE__ */ m("strong", { children: "EQ" }), /* @__PURE__ */ h("button", {
					className: Q.britSwitch,
					"aria-pressed": i,
					"aria-label": `${r} EQ in`,
					title: i ? "EQ in. Press to bypass." : "Bypassed. Press to switch the EQ in.",
					onClick: () => t({ active: +!!i }),
					children: [/* @__PURE__ */ m("span", { className: Q.britLamp }), "IN"]
				})]
			}),
			/* @__PURE__ */ h("div", {
				className: `${Q.britSection} ${Q.britCurve}`,
				children: [/* @__PURE__ */ m("strong", { children: "Response" }), /* @__PURE__ */ m(Wo, {
					params: e.params,
					brit: !0,
					rate: n
				})]
			})
		]
	});
}
// src/components/Talon.tsx
var ks = Z.talon.name, As = (e) => Z.talon.params.find((t) => t.id === e), js = (e) => `${ks} ${e.group} ${e.label}`, Ms = (e, t) => -135 + Er(e, t) * 270, Ns = 108, Ps = [
	1,
	2,
	3,
	4,
	6,
	8,
	10,
	14,
	20,
	30
];
function Fs({ module: e, onParams: t, id: n, size: r, knob: i, title: a, marks: o }) {
	let s = As(n), c = e.params[n], { props: l, display: u } = mo({
		param: s,
		value: c,
		prefix: `${ks} ${s.group}`,
		onChange: (e) => t({ [n]: e })
	}), d = [...Array.from({ length: 11 }, (e, t) => ({ angle: -135 + t * 27 })), ...o.map(([e, t]) => ({
		angle: Ms(s, e),
		text: t
	}))];
	return /* @__PURE__ */ h("div", {
		className: Q.talonSection,
		children: [
			/* @__PURE__ */ m("strong", { children: a }),
			/* @__PURE__ */ h("div", {
				className: Q.talonWell,
				style: {
					"--size": `${r}px`,
					"--height": `${Ns}px`
				},
				children: [/* @__PURE__ */ m(_s, {
					size: r,
					height: Ns,
					inner: i / 2 + 4,
					marks: d
				}), /* @__PURE__ */ h("div", {
					className: Q.talonKnob,
					style: { "--knob": `${i}px` },
					...l,
					children: [
						/* @__PURE__ */ m("span", { className: Q.talonGrip }),
						/* @__PURE__ */ m("span", { className: Q.talonCap }),
						/* @__PURE__ */ m("span", {
							className: Q.talonIndex,
							style: { transform: `rotate(${Ms(s, c)}deg)` }
						})
					]
				})]
			}),
			/* @__PURE__ */ m("span", {
				className: Q.knobValue,
				children: u
			})
		]
	});
}
function Is({ module: e, onParams: t, id: n, title: r, button: i, captions: a = [] }) {
	let o = As(n), s = e.params[n], c = o.choices.length;
	function l(e) {
		let r = {
			ArrowDown: s + 1,
			ArrowRight: s + 1,
			ArrowUp: s - 1,
			ArrowLeft: s - 1,
			Home: 0,
			End: c - 1
		}[e.key];
		if (r === void 0) return;
		e.preventDefault();
		let i = Math.max(0, Math.min(c - 1, r));
		t({ [n]: i }), e.currentTarget.querySelectorAll("[role=\"radio\"]")[i].focus();
	}
	return /* @__PURE__ */ h("div", {
		className: Q.talonSection,
		children: [
			/* @__PURE__ */ m("strong", { children: r }),
			/* @__PURE__ */ m("div", {
				className: Q.talonLamps,
				role: "radiogroup",
				"aria-label": js(o),
				onKeyDown: l,
				children: o.choices.map((e, r) => /* @__PURE__ */ h("button", {
					type: "button",
					role: "radio",
					"aria-checked": r === s,
					tabIndex: r === s ? 0 : -1,
					onClick: () => t({ [n]: r }),
					children: [
						/* @__PURE__ */ m("span", { className: Q.talonLed }),
						e,
						a[r] && /* @__PURE__ */ m("small", {
							"aria-hidden": "true",
							children: a[r]
						})
					]
				}, e))
			}),
			/* @__PURE__ */ m("button", {
				type: "button",
				className: Q.talonPush,
				"aria-label": `${js(o)}: next`,
				title: `Step to the next ${o.label.toLowerCase()} mode`,
				onClick: () => t({ [n]: (s + 1) % c }),
				children: i
			})
		]
	});
}
function Ls({ module: e, onParams: t, id: n, text: r }) {
	let i = As(n), a = e.params[n] === 1;
	return /* @__PURE__ */ h("button", {
		type: "button",
		className: Q.talonPush,
		"aria-pressed": a,
		"aria-label": js(i),
		title: `${i.label}: ${i.choices[e.params[n]]}`,
		onClick: () => t({ [n]: +!a }),
		children: [/* @__PURE__ */ m("span", { className: Q.talonLed }), r]
	});
}
function Rs({ reduction: e, label: t }) {
	let n = Math.min(40, Math.max(0, -e));
	return /* @__PURE__ */ h("div", {
		className: Q.talonSection,
		children: [/* @__PURE__ */ m("strong", { children: "GR" }), /* @__PURE__ */ m("div", {
			className: Q.talonMeter,
			role: "meter",
			"aria-label": t,
			"aria-valuemin": 0,
			"aria-valuemax": 40,
			"aria-valuenow": n,
			"aria-valuetext": `${n} dB gain reduction`,
			children: Ps.map((e) => /* @__PURE__ */ h("span", {
				"data-lit": n >= e,
				"data-hot": e > 10 || void 0,
				children: [/* @__PURE__ */ m("i", {}), e]
			}, e))
		})]
	});
}
function zs({ module: e, onParams: t, reduction: n, label: r }) {
	let i = {
		module: e,
		onParams: t
	}, a = e.params.active === 0;
	return /* @__PURE__ */ h("div", {
		className: Q.talonPanel,
		"data-bypassed": !a,
		children: [
			/* @__PURE__ */ m(Fs, {
				...i,
				id: "input",
				size: 100,
				knob: 60,
				title: "Input",
				marks: [
					[-12, "−12"],
					[0, "0"],
					[12, "12"],
					[30, "30"]
				]
			}),
			/* @__PURE__ */ m(Fs, {
				...i,
				id: "attack",
				size: 84,
				knob: 46,
				title: "Attack · ms",
				marks: [
					[5e-5, ".05"],
					[.001, "1"],
					[.01, "10"],
					[.03, "30"]
				]
			}),
			/* @__PURE__ */ m(Fs, {
				...i,
				id: "release",
				size: 84,
				knob: 46,
				title: "Release · s",
				marks: [
					[.05, ".05"],
					[.3, ".3"],
					[1, "1"],
					[3.5, "3.5"]
				]
			}),
			/* @__PURE__ */ m(Is, {
				...i,
				id: "ratio",
				title: "Ratio",
				button: "Ratio"
			}),
			/* @__PURE__ */ h("div", {
				className: Q.talonSection,
				children: [/* @__PURE__ */ m(Is, {
					...i,
					id: "color",
					title: "Harmonics",
					button: "Dist",
					captions: [
						"",
						"2nd",
						"3rd"
					]
				}), /* @__PURE__ */ h("div", {
					className: Q.talonLatches,
					children: [/* @__PURE__ */ m(Ls, {
						...i,
						id: "audioHp",
						text: "HP 65"
					}), /* @__PURE__ */ m(Ls, {
						...i,
						id: "fierce",
						text: "Fierce"
					})]
				})]
			}),
			/* @__PURE__ */ h("div", {
				className: Q.talonSection,
				children: [/* @__PURE__ */ m("strong", { children: "Detector" }), /* @__PURE__ */ h("div", {
					className: Q.talonLatches,
					children: [
						/* @__PURE__ */ m(Ls, {
							...i,
							id: "detectorHp",
							text: "HP 80"
						}),
						/* @__PURE__ */ m(Ls, {
							...i,
							id: "detectorBand",
							text: "Band 6k"
						}),
						/* @__PURE__ */ m(Ls, {
							...i,
							id: "link",
							text: "Link"
						})
					]
				})]
			}),
			/* @__PURE__ */ h("div", {
				className: Q.talonOutput,
				children: [
					/* @__PURE__ */ m(Rs, {
						reduction: n,
						label: r
					}),
					/* @__PURE__ */ m(Fs, {
						...i,
						id: "output",
						size: 100,
						knob: 60,
						title: "Output",
						marks: [
							[-30, "−30"],
							[-12, "−12"],
							[0, "0"],
							[12, "+12"]
						]
					}),
					/* @__PURE__ */ h("div", {
						className: Q.talonSection,
						children: [/* @__PURE__ */ m("strong", { children: "Comp" }), /* @__PURE__ */ h("button", {
							type: "button",
							className: Q.talonSwitch,
							"aria-pressed": a,
							"aria-label": `${ks} in`,
							title: a ? "In. Press to bypass." : "Bypassed. Press to switch TALON in.",
							onClick: () => t({ active: +!!a }),
							children: [/* @__PURE__ */ m("span", { className: Q.talonLamp }), "IN"]
						})]
					})
				]
			}),
			e.params.ratio === 5 && /* @__PURE__ */ m("p", {
				className: Q.processorHint,
				children: "Opto recovery lengthens with sustained reduction, up to 20 s."
			})
		]
	});
}
// src/components/KeysParts.tsx
var Bs = (e, t) => Z[e.type].params.find((e) => e.id === t), Vs = (e, t) => `${Z[e.type].name} ${t.group}`, Hs = (e, t) => -135 + Er(e, t) * 270, Us = 78;
function $({ module: e, onParams: t, id: n, title: r, look: i, size: a = 66, knob: o = 32, marks: s = [] }) {
	let c = Bs(e, n), l = e.params[n], { props: u, display: d } = mo({
		param: c,
		value: l,
		prefix: Vs(e, c),
		onChange: (e) => t({ [n]: e })
	}), f = [...Array.from({ length: 11 }, (e, t) => ({ angle: -135 + t * 27 })), ...s.map(([e, t]) => ({
		angle: Hs(c, e),
		text: t
	}))];
	return /* @__PURE__ */ h("div", {
		className: Q.keysControl,
		title: c.hint,
		children: [
			/* @__PURE__ */ m("strong", { children: r ?? c.label }),
			/* @__PURE__ */ h("div", {
				className: Q.keysWell,
				style: {
					"--size": `${a}px`,
					"--height": `${Us}px`
				},
				children: [/* @__PURE__ */ m(_s, {
					size: a,
					height: Us,
					inner: o / 2 + 3,
					marks: f
				}), /* @__PURE__ */ h("div", {
					className: Q.keysKnob,
					"data-look": i,
					style: { "--knob": `${o}px` },
					...u,
					children: [
						/* @__PURE__ */ m("span", { className: Q.keysKnobBody }),
						/* @__PURE__ */ m("span", { className: Q.keysKnobCap }),
						/* @__PURE__ */ m("span", {
							className: Q.keysKnobIndex,
							style: { transform: `rotate(${Hs(c, l)}deg)` }
						})
					]
				})]
			}),
			/* @__PURE__ */ m("span", {
				className: Q.knobValue,
				children: d
			})
		]
	});
}
function Ws({ module: e, onParams: t, id: n, title: r, look: i, labels: a }) {
	let o = Bs(e, n), s = e.params[n], c = o.choices, l = a ?? c, u = (e) => {
		e !== s && t({ [n]: e });
	};
	function d(e) {
		let t = {
			ArrowDown: s + 1,
			ArrowRight: s + 1,
			ArrowUp: s - 1,
			ArrowLeft: s - 1,
			Home: 0,
			End: c.length - 1
		}[e.key];
		if (t === void 0) return;
		e.preventDefault();
		let n = Math.max(0, Math.min(c.length - 1, t));
		u(n), e.currentTarget.querySelectorAll("[role=\"radio\"]")[n].focus();
	}
	return /* @__PURE__ */ h("div", {
		className: Q.keysControl,
		title: o.hint,
		children: [/* @__PURE__ */ m("strong", { children: r ?? o.label }), /* @__PURE__ */ h("div", {
			className: Q.keysSwitch,
			"data-look": i,
			"data-value": s,
			role: "radiogroup",
			"aria-label": `${Vs(e, o)} ${o.label}`,
			onKeyDown: d,
			children: [i === "slide" && /* @__PURE__ */ m("span", {
				className: Q.keysSlideThumb,
				"aria-hidden": "true",
				style: { "--at": s / Math.max(1, c.length - 1) }
			}), c.map((e, t) => /* @__PURE__ */ m("button", {
				type: "button",
				role: "radio",
				"aria-checked": t === s,
				"aria-label": e,
				tabIndex: t === s ? 0 : -1,
				onClick: () => u(t),
				children: /* @__PURE__ */ m("span", {
					"aria-hidden": "true",
					children: l[t]
				})
			}, e))]
		})]
	});
}
function Gs({ module: e, onParams: t, id: n, title: r, order: i, labels: a, look: o, size: s = 104, spread: c }) {
	let l = Bs(e, n), d = e.params[n], f = l.choices, p = i ?? f.map((e, t) => t), g = Math.max(0, p.indexOf(d)), _ = p.length, v = c ?? Math.min(270, (_ - 1) * 42), y = (e) => _ > 1 ? -v / 2 + e * v / (_ - 1) : 0, b = u(null), x = (e) => {
		let r = p[Math.max(0, Math.min(_ - 1, e))];
		r !== d && t({ [n]: r });
	}, S = o === "chicken" ? 46 : 34, C = Math.max(Us, s * .8), w = p.map((e, t) => ({
		angle: y(t),
		text: (a ?? f)[e],
		lit: e === d
	}));
	function T(e) {
		e.isPrimary && e.button === 0 && (b.current = {
			y: e.clientY,
			from: g,
			moved: !1
		}, e.currentTarget.setPointerCapture(e.pointerId), e.preventDefault(), e.currentTarget.focus());
	}
	function E(e) {
		let t = b.current;
		if (!t) return;
		let n = Math.round((t.y - e.clientY) / 16);
		n && (t.moved = !0), x(t.from + n);
	}
	function D() {
		b.current && !b.current.moved && x((g + 1) % _), b.current = null;
	}
	function O(e) {
		let t = {
			ArrowUp: g + 1,
			ArrowRight: g + 1,
			ArrowDown: g - 1,
			ArrowLeft: g - 1,
			Home: 0,
			End: _ - 1
		}[e.key];
		t !== void 0 && (e.preventDefault(), x(t));
	}
	return /* @__PURE__ */ h("div", {
		className: Q.keysControl,
		title: l.hint,
		children: [/* @__PURE__ */ m("strong", { children: r ?? l.label }), /* @__PURE__ */ h("div", {
			className: Q.keysWell,
			style: {
				"--size": `${s}px`,
				"--height": `${C}px`
			},
			children: [/* @__PURE__ */ m(_s, {
				size: s,
				height: C,
				inner: S / 2 + 4,
				marks: w
			}), /* @__PURE__ */ m("div", {
				className: Q.keysSelector,
				"data-look": o,
				style: {
					"--knob": `${S}px`,
					"--turn": `${y(g)}deg`
				},
				role: "slider",
				tabIndex: 0,
				"aria-label": `${Vs(e, l)} ${l.label}`,
				"aria-valuemin": 0,
				"aria-valuemax": _ - 1,
				"aria-valuenow": g,
				"aria-valuetext": f[d],
				onPointerDown: T,
				onPointerMove: E,
				onPointerUp: D,
				onPointerCancel: () => {
					b.current = null;
				},
				onLostPointerCapture: () => {
					b.current = null;
				},
				onKeyDown: O,
				children: /* @__PURE__ */ m("span", { className: Q.keysSelectorHead })
			})]
		})]
	});
}
function Ks({ module: e, onParams: t, id: n, title: r, ends: i }) {
	let a = Bs(e, n), o = e.params[n], { props: s, fraction: c, display: l } = mo({
		param: a,
		value: o,
		prefix: Vs(e, a),
		onChange: (e) => t({ [n]: e }),
		axis: "x",
		travel: 112
	});
	return /* @__PURE__ */ h("div", {
		className: Q.keysControl,
		title: a.hint,
		children: [
			/* @__PURE__ */ m("strong", { children: r ?? a.label }),
			/* @__PURE__ */ h("div", {
				className: Q.keysLever,
				style: { "--at": c },
				...s,
				children: [/* @__PURE__ */ m("span", { className: Q.keysLeverSlot }), /* @__PURE__ */ m("span", { className: Q.keysLeverHandle })]
			}),
			/* @__PURE__ */ h("span", {
				className: Q.keysLeverEnds,
				"aria-hidden": "true",
				children: [/* @__PURE__ */ m("span", { children: i[0] }), /* @__PURE__ */ m("span", { children: i[1] })]
			}),
			/* @__PURE__ */ m("span", {
				className: Q.knobValue,
				children: l
			})
		]
	});
}
function qs({ name: e, kind: t, children: n }) {
	return /* @__PURE__ */ h("div", {
		className: Q.keysPlate,
		"data-plate": t,
		children: [e && /* @__PURE__ */ m("span", {
			className: Q.keysPlateName,
			children: e
		}), /* @__PURE__ */ m("div", {
			className: Q.keysPlateControls,
			children: n
		})]
	});
}
// src/components/Velvet.tsx
var Js = [
	[0, "0"],
	[.5, "5"],
	[1, "10"]
], Ys = [
	[-12, "−"],
	[0, "0"],
	[12, "+"]
];
function Xs(e) {
	return /* @__PURE__ */ h("div", {
		className: Q.keysPanel,
		"data-panel": "velvet",
		children: [
			/* @__PURE__ */ h(qs, {
				kind: "strip",
				children: [
					/* @__PURE__ */ m($, {
						...e,
						id: "level",
						title: "Volume",
						look: "skirted",
						size: 72,
						knob: 36,
						marks: Js
					}),
					/* @__PURE__ */ m($, {
						...e,
						id: "bass",
						look: "skirted",
						marks: Ys
					}),
					/* @__PURE__ */ m($, {
						...e,
						id: "treble",
						look: "skirted",
						marks: Ys
					}),
					/* @__PURE__ */ m($, {
						...e,
						id: "drive",
						look: "skirted",
						marks: Js
					}),
					/* @__PURE__ */ m($, {
						...e,
						id: "tremRate",
						title: "Vib rate",
						look: "skirted",
						marks: [
							[.5, ".5"],
							[2, "2"],
							[10, "10"]
						]
					}),
					/* @__PURE__ */ m($, {
						...e,
						id: "tremDepth",
						title: "Intensity",
						look: "skirted",
						marks: Js
					}),
					/* @__PURE__ */ m(Gs, {
						...e,
						id: "model",
						look: "pointer",
						labels: [
							"SUITCASE",
							"STAGE I",
							"STAGE II"
						],
						size: 150,
						spread: 130
					})
				]
			}),
			/* @__PURE__ */ m("span", {
				className: Q.velvetFelt,
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ h(qs, {
				name: "Harp",
				kind: "harp",
				children: [
					/* @__PURE__ */ m($, {
						...e,
						id: "hardness",
						title: "Hammers",
						look: "fluted",
						marks: [[0, "S"], [1, "H"]]
					}),
					/* @__PURE__ */ m($, {
						...e,
						id: "bark",
						look: "fluted",
						marks: Js
					}),
					/* @__PURE__ */ m($, {
						...e,
						id: "bell",
						look: "fluted",
						marks: Js
					}),
					/* @__PURE__ */ m($, {
						...e,
						id: "decay",
						look: "fluted",
						marks: [
							[.3, ".3"],
							[1, "1"],
							[2, "2"]
						]
					}),
					/* @__PURE__ */ m($, {
						...e,
						id: "damper",
						look: "fluted",
						marks: Js
					})
				]
			})
		]
	});
}
// src/components/Reed.tsx
var Zs = [
	[0, "0"],
	[.5, "5"],
	[1, "10"]
];
function Qs(e) {
	return /* @__PURE__ */ h("div", {
		className: Q.keysPanel,
		"data-panel": "reed",
		children: [
			/* @__PURE__ */ m("span", {
				className: Q.reedGrille,
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ h(qs, {
				kind: "cheek",
				children: [
					/* @__PURE__ */ m($, {
						...e,
						id: "level",
						title: "Volume",
						look: "chrome",
						marks: Zs
					}),
					/* @__PURE__ */ m($, {
						...e,
						id: "tremDepth",
						title: "Vibrato",
						look: "chrome",
						marks: Zs
					}),
					/* @__PURE__ */ m($, {
						...e,
						id: "tremRate",
						title: "Speed",
						look: "chrome",
						marks: [
							[.5, ".5"],
							[2, "2"],
							[10, "10"]
						]
					}),
					/* @__PURE__ */ m($, {
						...e,
						id: "drive",
						look: "chrome",
						marks: Zs
					}),
					/* @__PURE__ */ m(Ws, {
						...e,
						id: "speaker",
						look: "rocker",
						labels: ["SPKR", "LINE"]
					})
				]
			}),
			/* @__PURE__ */ h(qs, {
				name: "Action",
				kind: "service",
				children: [
					/* @__PURE__ */ m($, {
						...e,
						id: "hardness",
						title: "Hammers",
						look: "fluted",
						marks: [[0, "S"], [1, "H"]]
					}),
					/* @__PURE__ */ m($, {
						...e,
						id: "bark",
						look: "fluted",
						marks: Zs
					}),
					/* @__PURE__ */ m($, {
						...e,
						id: "decay",
						look: "fluted",
						marks: [
							[.3, ".3"],
							[1, "1"],
							[2, "2"]
						]
					}),
					/* @__PURE__ */ m($, {
						...e,
						id: "damper",
						look: "fluted",
						marks: Zs
					})
				]
			}),
			/* @__PURE__ */ m("span", {
				className: Q.reedGrille,
				"aria-hidden": "true"
			})
		]
	});
}
// src/components/Planet.tsx
var $s = [
	[0, "0"],
	[.5, "5"],
	[1, "10"]
];
function ec(e) {
	return /* @__PURE__ */ h("div", {
		className: Q.keysPanel,
		"data-panel": "planet",
		children: [/* @__PURE__ */ h(qs, {
			kind: "trim",
			children: [
				/* @__PURE__ */ m(Ws, {
					...e,
					id: "model",
					look: "slide"
				}),
				/* @__PURE__ */ m($, {
					...e,
					id: "level",
					title: "Volume",
					look: "chrome",
					marks: $s
				}),
				/* @__PURE__ */ m($, {
					...e,
					id: "tone",
					look: "chrome",
					marks: [
						[-12, "−"],
						[0, "0"],
						[12, "+"]
					]
				}),
				/* @__PURE__ */ m($, {
					...e,
					id: "drive",
					look: "chrome",
					marks: $s
				}),
				/* @__PURE__ */ m($, {
					...e,
					id: "tremRate",
					title: "Speed",
					look: "chrome",
					marks: [
						[.5, ".5"],
						[2, "2"],
						[10, "10"]
					]
				}),
				/* @__PURE__ */ m($, {
					...e,
					id: "tremDepth",
					title: "Tremolo",
					look: "chrome",
					marks: $s
				})
			]
		}), /* @__PURE__ */ h(qs, {
			name: "Reeds",
			kind: "service",
			children: [
				/* @__PURE__ */ m($, {
					...e,
					id: "pluck",
					look: "fluted",
					marks: [[0, "S"], [1, "H"]]
				}),
				/* @__PURE__ */ m($, {
					...e,
					id: "bark",
					look: "fluted",
					marks: $s
				}),
				/* @__PURE__ */ m($, {
					...e,
					id: "decay",
					look: "fluted",
					marks: [
						[.3, ".3"],
						[1, "1"],
						[2, "2"]
					]
				}),
				/* @__PURE__ */ m($, {
					...e,
					id: "damper",
					look: "fluted",
					marks: $s
				})
			]
		})]
	});
}
// src/components/Strut.tsx
var tc = [
	[0, "0"],
	[.5, "5"],
	[1, "10"]
], nc = ["OFF", "ON"];
function rc(e) {
	return /* @__PURE__ */ h("div", {
		className: Q.keysPanel,
		"data-panel": "strut",
		children: [/* @__PURE__ */ h(qs, {
			kind: "strip",
			children: [/* @__PURE__ */ h("div", {
				className: Q.strutRockers,
				children: [
					/* @__PURE__ */ m(Ws, {
						...e,
						id: "pickupAB",
						title: "AB",
						look: "rocker"
					}),
					/* @__PURE__ */ m(Ws, {
						...e,
						id: "pickupCD",
						title: "CD",
						look: "rocker"
					}),
					/* @__PURE__ */ m(Ws, {
						...e,
						id: "brilliant",
						look: "rocker",
						labels: nc
					}),
					/* @__PURE__ */ m(Ws, {
						...e,
						id: "treble",
						look: "rocker",
						labels: nc
					}),
					/* @__PURE__ */ m(Ws, {
						...e,
						id: "medium",
						look: "rocker",
						labels: nc
					}),
					/* @__PURE__ */ m(Ws, {
						...e,
						id: "soft",
						look: "rocker",
						labels: nc
					})
				]
			}), /* @__PURE__ */ m(Ks, {
				...e,
				id: "mute",
				ends: ["OFF", "FULL"]
			})]
		}), /* @__PURE__ */ h(qs, {
			kind: "strip",
			children: [
				/* @__PURE__ */ m($, {
					...e,
					id: "hardness",
					look: "fluted",
					marks: [[0, "S"], [1, "H"]]
				}),
				/* @__PURE__ */ m($, {
					...e,
					id: "decay",
					look: "fluted",
					marks: [
						[.3, ".3"],
						[1, "1"],
						[2, "2"]
					]
				}),
				/* @__PURE__ */ m($, {
					...e,
					id: "release",
					look: "fluted",
					marks: tc
				}),
				/* @__PURE__ */ m($, {
					...e,
					id: "drive",
					look: "fluted",
					marks: tc
				}),
				/* @__PURE__ */ m($, {
					...e,
					id: "level",
					title: "Volume",
					look: "fluted",
					marks: tc
				})
			]
		})]
	});
}
// src/components/Organ.tsx
var ic = [
	[0, "0"],
	[.5, "5"],
	[1, "10"]
], ac = Z.drawbar.params.filter((e) => e.group === "Drawbars");
function oc(e) {
	let { module: t, onParams: n } = e;
	return /* @__PURE__ */ h("div", {
		className: Q.keysPanel,
		"data-panel": "drawbar",
		children: [
			/* @__PURE__ */ m(qs, {
				kind: "drawbars",
				children: /* @__PURE__ */ m(hs, {
					params: ac,
					values: t.params,
					prefix: `${Z.drawbar.name} Drawbars`,
					onChange: (e, t) => n({ [e]: t })
				})
			}),
			/* @__PURE__ */ h(qs, {
				kind: "tablets",
				children: [
					/* @__PURE__ */ m(Ws, {
						...e,
						id: "percussion",
						title: "Perc",
						look: "tablet",
						labels: ["OFF", "ON"]
					}),
					/* @__PURE__ */ m(Ws, {
						...e,
						id: "percVolume",
						title: "Volume",
						look: "tablet",
						labels: ["NORM", "SOFT"]
					}),
					/* @__PURE__ */ m(Ws, {
						...e,
						id: "percDecay",
						title: "Decay",
						look: "tablet",
						labels: ["FAST", "SLOW"]
					}),
					/* @__PURE__ */ m(Ws, {
						...e,
						id: "percHarmonic",
						title: "Harmonic",
						look: "tablet",
						labels: ["2ND", "3RD"]
					}),
					/* @__PURE__ */ m(Ws, {
						...e,
						id: "rotary",
						title: "Rotor",
						look: "tablet",
						labels: ["STOP", "RUN"]
					})
				]
			}),
			/* @__PURE__ */ h(qs, {
				kind: "controls",
				children: [
					/* @__PURE__ */ m(Gs, {
						...e,
						id: "vibrato",
						title: "Vibrato · chorus",
						look: "chicken",
						order: [
							0,
							1,
							4,
							2,
							5,
							3,
							6
						],
						labels: [
							"OFF",
							"V1",
							"V2",
							"V3",
							"C1",
							"C2",
							"C3"
						],
						size: 112
					}),
					/* @__PURE__ */ m($, {
						...e,
						id: "click",
						title: "Key click",
						look: "bakelite",
						marks: ic
					}),
					/* @__PURE__ */ m($, {
						...e,
						id: "leakage",
						look: "bakelite",
						marks: ic
					}),
					/* @__PURE__ */ m($, {
						...e,
						id: "drive",
						look: "bakelite",
						marks: ic
					}),
					/* @__PURE__ */ m($, {
						...e,
						id: "balance",
						look: "bakelite",
						marks: [[0, "DRUM"], [1, "HORN"]]
					}),
					/* @__PURE__ */ m($, {
						...e,
						id: "level",
						title: "Volume",
						look: "bakelite",
						marks: ic
					})
				]
			})
		]
	});
}
// src/components/EngineSwitch.tsx
var sc = [
	0,
	.14,
	.28,
	.42,
	.56,
	.7,
	.84
];
function cc({ module: e, param: t, name: n, onParams: r }) {
	let i = e.params[t.id] === 1, [a, o] = t.choices;
	return /* @__PURE__ */ h("button", {
		type: "button",
		role: "switch",
		className: Q.engineSwitch,
		"aria-checked": i,
		"aria-label": `${n} ${t.label}`,
		"data-modeled": i,
		title: `${t.label}: ${i ? o : a}. Slide to ${i ? a : o}.`,
		onClick: () => r({ [t.id]: +!i }),
		children: [/* @__PURE__ */ m("span", {
			className: Q.engineCaption,
			children: t.label
		}), /* @__PURE__ */ h("span", {
			className: Q.togglePlate,
			"aria-hidden": "true",
			children: [
				/* @__PURE__ */ m("span", {
					className: Q.toggleLegend,
					"data-lit": !i,
					children: a
				}),
				/* @__PURE__ */ h("span", {
					className: Q.toggle,
					children: [/* @__PURE__ */ m("span", { className: Q.toggleSlot }), /* @__PURE__ */ h("span", {
						className: Q.toggleKnob,
						children: [
							/* @__PURE__ */ m("span", { className: Q.toggleBrim }),
							sc.map((e) => /* @__PURE__ */ m("span", {
								className: Q.toggleRib,
								style: { "--f": e }
							}, e)),
							/* @__PURE__ */ m("span", { className: Q.toggleCap })
						]
					})]
				}),
				/* @__PURE__ */ m("span", {
					className: Q.toggleLegend,
					"data-lit": i,
					children: o
				})
			]
		})]
	});
}
// src/components/Mixer.tsx
var lc = 112, uc = [
	[1, "0"],
	[10 ** (-3 / 20), "3"],
	[.5, "6"],
	[10 ** (-10 / 20), "10"],
	[.1, "20"],
	[0, "∞"]
], dc = [
	-48,
	-42,
	-36,
	-30,
	-24,
	-18,
	-12,
	-9,
	-6,
	-3,
	0
], fc = (e) => Z.mixer.params.find((t) => t.id === e), pc = (e) => e <= 0 ? "−∞" : `${(20 * Math.log10(e)).toFixed(1).replace("-", "−")} dB`, mc = (e) => Math.abs(e) < .005 ? "C" : `${e < 0 ? "L" : "R"}${Math.round(Math.abs(e) * 100)}`;
function hc({ level: e, label: t }) {
	let n = Math.round(e);
	return /* @__PURE__ */ m("div", {
		className: Q.levelMeter,
		role: "meter",
		"aria-label": t,
		"aria-valuemin": dc[0],
		"aria-valuemax": 0,
		"aria-valuenow": Math.max(dc[0], Math.min(0, n)),
		"aria-valuetext": e < dc[0] ? "Silent" : `${n} dB`,
		children: dc.map((t) => /* @__PURE__ */ m("i", {
			"data-lit": e >= t,
			"data-zone": t >= -3 ? "hot" : t >= -9 ? "warm" : void 0
		}, t))
	});
}
function gc({ param: e, value: t, prefix: n, onChange: r, children: i }) {
	let { props: a, fraction: o, display: s } = mo({
		param: e,
		value: t,
		prefix: n,
		onChange: r,
		format: pc,
		travel: lc
	});
	return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ h("div", {
		className: Q.faderBay,
		style: { "--travel": `${lc}px` },
		children: [
			/* @__PURE__ */ m("span", {
				className: Q.faderScale,
				"aria-hidden": "true",
				children: uc.map(([e, t]) => /* @__PURE__ */ m("span", {
					style: { "--at": e },
					children: t
				}, t))
			}),
			/* @__PURE__ */ m("div", {
				className: Q.faderSlot,
				...a,
				children: /* @__PURE__ */ m("span", {
					className: Q.faderCap,
					style: { "--at": o }
				})
			}),
			i
		]
	}), /* @__PURE__ */ m("span", {
		className: Q.faderValue,
		children: s
	})] });
}
function _c({ module: e, patch: t, mix: n, levels: r, onParams: i, onToggle: a, onSwap: o, onGoTo: s }) {
	let c = Z[e.type].name;
	return /* @__PURE__ */ h("div", {
		className: Q.console,
		children: [xt.map((l, u) => {
			let { source: d, tooltip: f, connected: p, named: g, deviceId: _ } = or(t, e.id, l), v = l.toUpperCase(), y = St(l), b = Gn(e.id, l);
			return /* @__PURE__ */ h("div", {
				className: Q.channelStrip,
				role: "group",
				"aria-label": `${c} channel ${v}: ${d}`,
				"data-plugged": p,
				"data-silent": !Qn(e, l, n),
				"data-analytics-private": g ? "" : void 0,
				children: [
					_ ? /* @__PURE__ */ h("button", {
						type: "button",
						className: `${Q.scribble} ${Q.scribbleLink}`,
						"aria-label": `${d} ${v}, go to this device`,
						title: f,
						onClick: () => s(_),
						children: [/* @__PURE__ */ m("span", {
							className: Q.channelSource,
							"data-source-name": !0,
							children: d
						}), /* @__PURE__ */ m("b", { children: v })]
					}) : /* @__PURE__ */ h("div", {
						className: Q.scribble,
						children: [/* @__PURE__ */ m("span", {
							className: Q.channelSource,
							"data-source-name": !0,
							children: d
						}), /* @__PURE__ */ m("b", { children: v })]
					}),
					/* @__PURE__ */ m(ho, {
						param: fc(y),
						prefix: c,
						value: e.params[y],
						format: mc,
						caption: "PAN",
						onChange: (e) => i({ [y]: e })
					}),
					/* @__PURE__ */ m(Qo, {
						mixKey: b,
						label: `${c} channel ${v}`,
						mix: n,
						onToggle: a,
						onSwap: () => o(b)
					}),
					/* @__PURE__ */ m(gc, {
						param: fc(l),
						prefix: c,
						value: e.params[l],
						onChange: (e) => i({ [l]: e }),
						children: /* @__PURE__ */ m(hc, {
							level: r.channels[u],
							label: `${c} channel ${v} level`
						})
					})
				]
			}, l);
		}), /* @__PURE__ */ h("div", {
			className: Q.mixBus,
			role: "group",
			"aria-label": `${c} mix bus`,
			children: [/* @__PURE__ */ h("div", {
				className: Q.scribble,
				children: [/* @__PURE__ */ m("span", {
					className: Q.channelSource,
					children: "MIX BUS"
				}), /* @__PURE__ */ m("b", { children: "L · R" })]
			}), /* @__PURE__ */ h(gc, {
				param: fc("master"),
				prefix: c,
				value: e.params.master,
				onChange: (e) => i({ master: e }),
				children: [/* @__PURE__ */ m(hc, {
					level: r.bus[0],
					label: `${c} mix bus left level`
				}), /* @__PURE__ */ m(hc, {
					level: r.bus[1],
					label: `${c} mix bus right level`
				})]
			})]
		})]
	});
}
// src/components/ModuleTape.tsx
var vc = (e) => [...e].reduce((e, t) => (e * 31 + t.charCodeAt(0)) % 3, 1);
function yc({ module: e, slot: t, onName: n }) {
	let r = Z[e.type], a = `${r.name} ${t}`, o = vc(e.id), s = e.label, [c, l] = d(null), f = c !== null, g = u(null), _ = u(null), v = u(null), y = u(!1), b = u(!1);
	i(() => {
		f ? (g.current?.focus(), g.current?.select()) : b.current && (b.current = !1, (v.current ?? _.current)?.focus());
	}, [f]);
	function x() {
		y.current = !0, l(s ?? "");
	}
	function S(e, t) {
		y.current && (y.current = !1, b.current = t, l(null), e !== null && n(e));
	}
	function C(e) {
		e.key === "Escape" ? (e.preventDefault(), S(null, !0)) : e.key === "Enter" && e.target === g.current && (e.preventDefault(), S(c, !0));
	}
	return /* @__PURE__ */ h(p, { children: [e.type === "output" ? /* @__PURE__ */ m("span", {
		className: Q.moduleName,
		children: r.name
	}) : /* @__PURE__ */ m("button", {
		ref: _,
		type: "button",
		className: Q.moduleNameButton,
		"aria-label": `Name ${a}`,
		title: s ? "Rename this device" : "Name this device",
		onClick: x,
		children: r.name
	}), /* @__PURE__ */ h("span", {
		className: Q.moduleSlot,
		"data-taped": f || !!s,
		"data-subtitle": r.subtitle,
		children: [/* @__PURE__ */ m("span", {
			className: Q.moduleSubtitle,
			children: r.subtitle
		}), f ? /* @__PURE__ */ m("span", {
			className: Q.moduleTape,
			"data-tear": o,
			"data-analytics-private": "",
			onKeyDown: C,
			onBlur: (e) => {
				e.currentTarget.contains(e.relatedTarget) || S(c, !1);
			},
			children: /* @__PURE__ */ h("span", {
				className: Q.tapeBody,
				children: [/* @__PURE__ */ m("span", {
					className: Q.tapeField,
					"data-value": c,
					children: /* @__PURE__ */ m("input", {
						ref: g,
						"data-tape-input": "",
						"aria-label": `Name for ${a}`,
						maxLength: 40,
						size: 1,
						placeholder: "Name it",
						value: c,
						onChange: (e) => l(e.target.value)
					})
				}), /* @__PURE__ */ m("button", {
					type: "button",
					className: Q.tapePeel,
					"aria-label": `Remove name from ${a}`,
					title: "Peel the tape off",
					onMouseDown: (e) => e.preventDefault(),
					onClick: () => S("", !0),
					children: "×"
				})]
			})
		}) : s && /* @__PURE__ */ m("span", {
			className: Q.moduleTape,
			"data-tear": o,
			"data-analytics-private": "",
			children: /* @__PURE__ */ m("button", {
				ref: v,
				type: "button",
				className: Q.tapeBody,
				"aria-label": `Rename ${s}, ${a}`,
				title: s,
				onClick: x,
				children: /* @__PURE__ */ m("span", {
					className: Q.tapeText,
					children: s
				})
			})
		})]
	})] });
}
// src/components/TempoInput.tsx
var bc = 40, xc = 240;
function Sc({ bpm: e, onChange: t }) {
	let [n, r] = d(String(e)), o = a();
	return i(() => {
		r(String(e));
	}, [e]), /* @__PURE__ */ h("div", {
		className: Q.numberField,
		children: [
			/* @__PURE__ */ m("label", {
				htmlFor: o,
				children: "BPM"
			}),
			/* @__PURE__ */ m("input", {
				id: o,
				"aria-label": "Tempo",
				type: "number",
				min: bc,
				max: xc,
				step: 1,
				value: n,
				onChange: (e) => {
					r(e.target.value);
					let n = Number(e.target.value);
					n >= bc && n <= xc && t(n);
				},
				onBlur: () => {
					let i = n === "" ? e : Math.max(bc, Math.min(xc, Number(n)));
					r(String(i)), t(i);
				}
			}),
			/* @__PURE__ */ m("input", {
				className: Q.fader,
				type: "range",
				min: bc,
				max: xc,
				step: 1,
				value: e,
				"aria-label": "Tempo slider",
				"aria-valuetext": `${e} BPM`,
				onChange: (e) => t(Number(e.target.value))
			})
		]
	});
}
// src/components/Presets.tsx
var Cc = (e) => new Date(e).toLocaleString(void 0, {
	dateStyle: "medium",
	timeStyle: "short"
});
function wc({ presets: e, openId: t, dirty: n, onLoad: r, onLoadFactory: a, onExport: o, onDelete: s, onSaveAs: c, onImport: l, onExportCurrent: f, onClose: g }) {
	let [_, v] = d(null), y = u(null), b = u(null);
	return i(() => {
		_ && y.current?.focus();
	}, [_]), /* @__PURE__ */ h("div", {
		ref: b,
		tabIndex: -1,
		className: `${Q.library} ${Q.presetBrowser}`,
		role: "region",
		"aria-label": "Presets",
		"data-analytics-private": "",
		children: [
			/* @__PURE__ */ h("div", {
				className: Q.libraryHeading,
				children: [/* @__PURE__ */ m("strong", { children: "PRESETS" }), /* @__PURE__ */ h("span", {
					className: Q.presetActions,
					children: [
						/* @__PURE__ */ m("button", {
							onClick: (e) => c(e.currentTarget),
							title: "Save a copy under a new name (⇧⌘S / Ctrl+Shift+S)",
							children: "Save as…"
						}),
						/* @__PURE__ */ m("button", {
							onClick: l,
							title: "Add a .json patch file to My Presets",
							children: "↑ Import file…"
						}),
						/* @__PURE__ */ m("button", {
							onClick: f,
							title: "Download the rack as a .json patch file",
							children: "↓ Export file"
						}),
						/* @__PURE__ */ m("button", {
							"aria-label": "Close presets",
							onClick: g,
							children: "×"
						})
					]
				})]
			}),
			/* @__PURE__ */ m("strong", {
				className: Q.sectionLabel,
				children: "MY PRESETS · SAVED IN THIS BROWSER"
			}),
			e.length ? /* @__PURE__ */ m("ul", {
				className: Q.presetList,
				"aria-label": "My presets",
				children: e.map((e) => {
					let { id: i, patch: { name: a } } = e, c = i === t;
					return /* @__PURE__ */ m("li", {
						className: Q.presetRow,
						"data-open": c,
						children: _ === i ? /* @__PURE__ */ h(p, { children: [
							/* @__PURE__ */ h("span", {
								className: Q.presetConfirm,
								children: [
									"Delete “",
									a,
									"”? This can’t be undone."
								]
							}),
							/* @__PURE__ */ m("button", {
								className: Q.dangerButton,
								"aria-label": `Confirm delete ${a}`,
								onClick: () => {
									v(null), s(e), b.current?.focus();
								},
								children: "Delete"
							}),
							/* @__PURE__ */ m("button", {
								ref: y,
								"aria-label": `Keep ${a}`,
								onClick: () => v(null),
								children: "Keep"
							})
						] }) : /* @__PURE__ */ h(p, { children: [
							/* @__PURE__ */ h("button", {
								className: Q.presetLoad,
								"aria-label": `Load ${a}`,
								"aria-current": c || void 0,
								onClick: () => r(e),
								children: [/* @__PURE__ */ m("strong", { children: a }), /* @__PURE__ */ m("small", { children: c ? n ? "OPEN · UNSAVED CHANGES" : "OPEN" : `Saved ${Cc(e.savedAt)}` })]
							}),
							/* @__PURE__ */ m("button", {
								"aria-label": `Export ${a}`,
								title: `Download ${a} as a .json patch file`,
								onClick: () => o(e.patch),
								children: "↓ Export"
							}),
							/* @__PURE__ */ m("button", {
								"aria-label": `Delete ${a}`,
								title: `Delete ${a} from this browser`,
								onClick: () => v(i),
								children: "Delete"
							})
						] })
					}, i);
				})
			}) : /* @__PURE__ */ m("p", {
				className: Q.presetEmpty,
				children: "Nothing saved yet. Save keeps your rack here under its name; Import file adds a patch you exported."
			}),
			/* @__PURE__ */ m("strong", {
				className: Q.sectionLabel,
				children: "FACTORY"
			}),
			/* @__PURE__ */ m("div", {
				role: "group",
				"aria-label": "Factory presets",
				children: _r.map(([e, t]) => /* @__PURE__ */ h("div", {
					className: Q.factoryCategory,
					children: [/* @__PURE__ */ m("span", {
						className: Q.factoryCategoryLabel,
						"aria-hidden": "true",
						children: e.toUpperCase()
					}), /* @__PURE__ */ m("div", {
						className: Q.factoryGrid,
						role: "group",
						"aria-label": `${e} presets`,
						children: t.map((e) => /* @__PURE__ */ m("button", {
							title: e,
							onClick: () => a(e),
							children: e
						}, e))
					})]
				}, e))
			})
		]
	});
}
function Tc({ initialName: e, presets: t, onSave: n, onCancel: r }) {
	let [o, s] = d(e), c = u(null), l = a(), f = a(), p = ni(t, o), g = !o.trim();
	i(() => {
		c.current?.select();
	}, []);
	function _(e) {
		if (e.key === "Escape") {
			e.preventDefault(), r();
			return;
		}
		if (e.key !== "Tab") return;
		let t = [...e.currentTarget.querySelectorAll("input, button:not(:disabled)")], n = t[0], i = t.at(-1);
		e.shiftKey && document.activeElement === n ? (e.preventDefault(), i?.focus()) : !e.shiftKey && document.activeElement === i && (e.preventDefault(), n?.focus());
	}
	return /* @__PURE__ */ m("div", {
		className: Q.helpBackdrop,
		children: /* @__PURE__ */ m("div", {
			className: Q.saveDialog,
			"data-analytics-private": "",
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": l,
			"aria-describedby": f,
			onKeyDown: _,
			children: /* @__PURE__ */ h("form", {
				onSubmit: (e) => {
					e.preventDefault(), g || n(o);
				},
				children: [
					/* @__PURE__ */ m("strong", {
						id: l,
						className: Q.saveTitle,
						children: "Save preset"
					}),
					/* @__PURE__ */ h("label", { children: ["Name", /* @__PURE__ */ m("input", {
						ref: c,
						autoFocus: !0,
						"aria-label": "Preset name",
						maxLength: 100,
						value: o,
						onChange: (e) => s(e.target.value)
					})] }),
					p && /* @__PURE__ */ h("p", {
						className: Q.saveWarning,
						role: "status",
						children: [
							"“",
							p.patch.name,
							"” is already in My Presets. Saving replaces it."
						]
					}),
					/* @__PURE__ */ m("p", {
						id: f,
						className: Q.saveNote,
						children: "Saved in this browser. Export a file to back it up or move it to another browser."
					}),
					/* @__PURE__ */ h("div", {
						className: Q.saveButtons,
						children: [/* @__PURE__ */ m("button", {
							type: "button",
							onClick: r,
							children: "Cancel"
						}), /* @__PURE__ */ m("button", {
							type: "submit",
							className: Q.saveButton,
							disabled: g,
							children: p ? "Replace" : "Save"
						})]
					})
				]
			})
		})
	});
}
// src/components/Live.tsx
function Ec() {
	let e = {
		pulsing: /* @__PURE__ */ new Set(),
		meter: 0,
		reductions: {},
		mixerLevels: {},
		wheels: null
	}, t = /* @__PURE__ */ new Set();
	return {
		get: () => e,
		set(n) {
			if (!Object.keys(n).every((t) => n[t] === e[t])) {
				e = {
					...e,
					...n
				};
				for (let e of t) e();
			}
		},
		subscribe(e) {
			return t.add(e), () => {
				t.delete(e);
			};
		}
	};
}
var Dc = t(null);
function Oc({ select: e, children: t }) {
	let n = r(Dc), i = () => e(n.get());
	return /* @__PURE__ */ m(p, { children: t(f(n.subscribe, i, i)) });
}
// src/components/Wheels.tsx
var kc = 80, Ac = .03, jc = .05, Mc = .25;
function Nc({ levels: e, disabled: t, onMove: n }) {
	return /* @__PURE__ */ h("div", {
		className: Q.wheels,
		role: "group",
		"aria-label": "Wheels",
		children: [/* @__PURE__ */ m(Pc, {
			kind: "bend",
			label: "Pitch",
			level: e.bend,
			disabled: t,
			onMove: n
		}), /* @__PURE__ */ m(Pc, {
			kind: "mod",
			label: "Mod",
			level: e.mod,
			disabled: t,
			onMove: n
		})]
	});
}
function Pc({ kind: e, label: t, level: n, disabled: r, onMove: a }) {
	let o = e === "bend", s = o ? -1 : 0, [c, l] = d(null), f = u(null), p = u(0), g = u(!1), _ = c ?? n, v = (e) => Math.max(s, Math.min(1, e)), y = () => {
		cancelAnimationFrame(p.current), p.current = 0;
	};
	i(() => y, []);
	let b = (t, n) => {
		let r = v(o && Math.abs(t) < Ac ? 0 : t);
		l(r), a(e, r, !0, n);
	}, x = (t) => {
		if (y(), !o || t === 0) {
			l(null), a(e, t, !1);
			return;
		}
		let n = performance.now(), r = (i) => {
			let o = Math.max(0, 1 - (i - n) / kc);
			if (o > 0) {
				let n = t * o * o;
				l(n), a(e, n, !0), p.current = requestAnimationFrame(r);
			} else p.current = 0, l(null), a(e, 0, !1);
		};
		p.current = requestAnimationFrame(r);
	}, S = (e) => {
		r || e.button !== 0 || (e.preventDefault(), e.currentTarget.focus(), e.currentTarget.setPointerCapture(e.pointerId), y(), f.current = {
			pointer: e.pointerId,
			y: e.clientY,
			from: _
		}, b(_, e.timeStamp));
	}, C = (e) => {
		let t = f.current;
		if (!t || t.pointer !== e.pointerId) return;
		let n = e.currentTarget.clientHeight / (o ? 2 : 1) || 1;
		b(t.from + (t.y - e.clientY) / n, e.timeStamp);
	}, w = (e) => {
		f.current?.pointer === e.pointerId && (f.current = null, x(c ?? _));
	}, T = (e) => {
		let t = {
			ArrowUp: jc,
			ArrowRight: jc,
			ArrowDown: -.05,
			ArrowLeft: -.05,
			PageUp: Mc,
			PageDown: -.25
		}[e.key], n = e.key === "Home" ? s : e.key === "End" ? 1 : t === void 0 ? null : v(_ + t);
		r || n === null || (e.preventDefault(), y(), g.current = !0, b(n));
	}, E = () => {
		g.current && (g.current = !1, x(c ?? _));
	}, D = Math.round(_ * 100);
	return /* @__PURE__ */ h("div", {
		className: Q.wheelSlot,
		children: [/* @__PURE__ */ h("div", {
			className: Q.wheel,
			"data-kind": e,
			"data-held": c !== null,
			role: "slider",
			tabIndex: r ? -1 : 0,
			"aria-disabled": r || void 0,
			"aria-label": `${t} wheel`,
			"aria-orientation": "vertical",
			"aria-valuemin": s * 100,
			"aria-valuemax": 100,
			"aria-valuenow": D,
			"aria-valuetext": o ? D ? `${D > 0 ? "Up" : "Down"} ${Math.abs(D)}%` : "Centre" : `${D}%`,
			title: o ? "Pitch wheel: drag up or down to bend; it springs back when let go. Each synth’s Bend sets how far." : "Mod wheel: drag up to bring in modulation; it stays where you leave it. Double-click takes it back down.",
			style: { "--wheel": _ },
			onPointerDown: S,
			onPointerMove: C,
			onPointerUp: w,
			onPointerCancel: w,
			onLostPointerCapture: w,
			onDoubleClick: () => {
				!o && !r && (b(0), x(0));
			},
			onKeyDown: T,
			onKeyUp: E,
			onBlur: E,
			children: [/* @__PURE__ */ m("span", {
				className: Q.wheelRidges,
				"aria-hidden": "true"
			}), /* @__PURE__ */ m("span", {
				className: Q.wheelMark,
				"aria-hidden": "true"
			})]
		}), /* @__PURE__ */ m("span", {
			className: Q.wheelLabel,
			"aria-hidden": "true",
			children: t.toUpperCase()
		})]
	});
}
// src/components/Pedals.tsx
var Fc = 250, Ic = 4, Lc = .1, Rc = .25, zc = [
	"mod",
	"expression",
	"sustain"
], Bc = "Sustain pedal: hold it down, or click to latch it, and every damper lifts, so notes ring on after you let go. Drag up while holding it, or use the arrow keys, for half-pedal.";
function Vc({ kinds: e, levels: t, disabled: n, onMove: r }) {
	return /* @__PURE__ */ m("div", {
		className: Q.pedals,
		role: "group",
		"aria-label": "Pedals",
		children: zc.filter((t) => e.includes(t)).map((e) => e === "mod" ? /* @__PURE__ */ m(qc, {
			fast: t.mod >= .5,
			disabled: n,
			onMove: r
		}, e) : e === "expression" ? /* @__PURE__ */ m(Kc, {
			level: t.expression,
			disabled: n,
			onMove: r
		}, e) : /* @__PURE__ */ m(Wc, {
			level: t.sustain,
			disabled: n,
			onMove: r
		}, e))
	});
}
var Hc = (e) => Math.max(0, Math.min(1, e)), Uc = (e) => e <= 0 ? "Up" : e >= 1 ? "Down" : `Part way, ${Math.round(e * 100)}%`;
function Wc({ level: e, disabled: t, onMove: n }) {
	let r = "sustain", [i, a] = d(null), [o, s] = d(null), c = u(null), l = u(null), f = i ?? o ?? e, p = (e, t) => {
		e > 0 ? (s(e), n(r, e, !0, t)) : (s(null), n(r, 0, !1, t));
	}, g = (e) => {
		t || e.button !== 0 || (e.preventDefault(), e.currentTarget.focus(), e.currentTarget.setPointerCapture(e.pointerId), o === null ? (c.current = {
			pointer: e.pointerId,
			y: e.clientY,
			at: e.timeStamp,
			moved: !1
		}, a(1), n(r, 1, !0, e.timeStamp)) : (l.current = e.pointerId, p(0, e.timeStamp)));
	}, _ = (e) => {
		let t = c.current;
		if (!t || t.pointer !== e.pointerId) return;
		let i = e.clientY - t.y;
		if (!t.moved && Math.abs(i) < Ic) return;
		t.moved = !0;
		let o = Hc(1 + i / (e.currentTarget.clientHeight || 1));
		a(o), n(r, o, !0, e.timeStamp);
	}, v = (e) => {
		if (l.current === e.pointerId) {
			l.current = null;
			return;
		}
		let t = c.current;
		t && t.pointer === e.pointerId && (c.current = null, a(null), !t.moved && e.type !== "pointercancel" && e.timeStamp - t.at < Fc ? s(1) : n(r, 0, !1, e.timeStamp));
	};
	return /* @__PURE__ */ h("div", {
		className: Q.pedalSlot,
		children: [/* @__PURE__ */ m("div", {
			className: Q.pedal,
			"data-kind": r,
			"data-held": i !== null,
			"data-latched": o !== null,
			role: "slider",
			tabIndex: t ? -1 : 0,
			"aria-disabled": t || void 0,
			"aria-label": "Sustain pedal",
			"aria-orientation": "vertical",
			"aria-valuemin": 0,
			"aria-valuemax": 100,
			"aria-valuenow": Math.round(f * 100),
			"aria-valuetext": Uc(f),
			title: Bc,
			style: { "--depth": f },
			onPointerDown: g,
			onPointerMove: _,
			onPointerUp: v,
			onPointerCancel: v,
			onLostPointerCapture: v,
			onKeyDown: (e) => {
				if (t) return;
				if (e.key === " " || e.key === "Enter") {
					e.preventDefault(), e.repeat || p(f > 0 ? 0 : 1);
					return;
				}
				let n = {
					ArrowUp: Lc,
					ArrowRight: Lc,
					ArrowDown: -.1,
					ArrowLeft: -.1,
					PageUp: Rc,
					PageDown: -.25
				}[e.key], r = e.key === "Home" ? 0 : e.key === "End" ? 1 : n === void 0 ? null : Hc(Math.round((f + n) * 100) / 100);
				r !== null && (e.preventDefault(), p(r));
			},
			children: /* @__PURE__ */ m("span", {
				className: Q.pedalFace,
				"aria-hidden": "true"
			})
		}), /* @__PURE__ */ m("span", {
			className: Q.pedalLabel,
			"aria-hidden": "true",
			children: "SUS"
		})]
	});
}
var Gc = .72;
function Kc({ level: e, disabled: t, onMove: n }) {
	let [r, i] = d(null), a = u(null), o = u(!1), s = r ?? e, c = (e, t) => {
		let r = Hc(e);
		i(r), n("expression", r, !0, t);
	}, l = (e) => {
		let t = r ?? s;
		i(null), n("expression", t, !1, e);
	}, f = (e) => {
		t || e.button !== 0 || (e.preventDefault(), e.currentTarget.focus(), e.currentTarget.setPointerCapture(e.pointerId), a.current = {
			pointer: e.pointerId,
			y: e.clientY,
			from: s
		}, c(s, e.timeStamp));
	}, p = (e) => {
		let t = a.current;
		t?.pointer === e.pointerId && c(t.from - (e.clientY - t.y) / ((e.currentTarget.clientHeight || 1) * Gc), e.timeStamp);
	}, g = (e) => {
		a.current?.pointer === e.pointerId && (a.current = null, l(e.timeStamp));
	}, _ = (e) => {
		let n = {
			ArrowUp: Lc,
			ArrowRight: Lc,
			ArrowDown: -.1,
			ArrowLeft: -.1,
			PageUp: Rc,
			PageDown: -.25
		}[e.key], r = e.key === "Home" ? 0 : e.key === "End" ? 1 : n === void 0 ? null : Math.round((s + n) * 100) / 100;
		t || r === null || (e.preventDefault(), o.current = !0, c(r));
	}, v = () => {
		o.current && (o.current = !1, l());
	}, y = Math.round(s * 100);
	return /* @__PURE__ */ h("div", {
		className: Q.pedalSlot,
		children: [/* @__PURE__ */ h("div", {
			className: Q.pedal,
			"data-kind": "expression",
			"data-held": r !== null,
			role: "slider",
			tabIndex: t ? -1 : 0,
			"aria-disabled": t || void 0,
			"aria-label": "Swell pedal",
			"aria-orientation": "vertical",
			"aria-valuemin": 0,
			"aria-valuemax": 100,
			"aria-valuenow": y,
			"aria-valuetext": y >= 100 ? "Open" : y <= 0 ? "Closed" : `${y}% open`,
			title: "Swell (expression) pedal: drag up to open it, down to close it, from silent to full. It stays where you leave it; double-click opens it fully.",
			style: {
				"--depth": s,
				"--travel": Gc
			},
			onPointerDown: f,
			onPointerMove: p,
			onPointerUp: g,
			onPointerCancel: g,
			onLostPointerCapture: g,
			onDoubleClick: () => {
				t || (c(Ue("expression")), l());
			},
			onKeyDown: _,
			onKeyUp: v,
			onBlur: v,
			children: [/* @__PURE__ */ m("span", {
				className: Q.swellFill,
				"aria-hidden": "true"
			}), /* @__PURE__ */ m("span", {
				className: Q.pedalFace,
				"aria-hidden": "true"
			})]
		}), /* @__PURE__ */ m("span", {
			className: Q.pedalLabel,
			"aria-hidden": "true",
			children: "SWELL"
		})]
	});
}
function qc({ fast: e, disabled: t, onMove: n }) {
	return /* @__PURE__ */ h("div", {
		className: Q.pedalSlot,
		children: [/* @__PURE__ */ m("button", {
			className: Q.rotarySwitch,
			"aria-pressed": e,
			"aria-label": "Rotary fast",
			disabled: t,
			"data-fast": e,
			onClick: () => {
				let t = +!e;
				n("mod", t, !0), n("mod", t, !1);
			},
			title: "Rotary speaker: SLOW or FAST, as an organ’s half-moon switch. The horn and drum speed up or slow down over a second or two. A MIDI mod wheel’s top half switches it too.",
			children: /* @__PURE__ */ m("span", {
				className: Q.rotaryLever,
				"aria-hidden": "true"
			})
		}), /* @__PURE__ */ m("span", {
			className: Q.pedalLabel,
			"aria-hidden": "true",
			children: e ? "FAST" : "SLOW"
		})]
	});
}
// src/components/seek.ts
var Jc = 4, Yc = (e) => `Bar ${Math.floor(e / 16) + 1}, beat ${Math.floor(e % 16 / Jc) + 1}`;
function Xc(e, t, n, r) {
	let i = u(null), a = u({
		step: 0,
		at: -Infinity
	}), o = (e) => Math.max(0, Math.min(t - Jc, Math.floor(e / Jc) * Jc)), s = (e) => {
		let n = e.currentTarget.getBoundingClientRect();
		return o((e.clientX - n.left) / n.width * t);
	}, c = n ?? 0;
	return {
		role: "slider",
		tabIndex: 0,
		"aria-label": `${e} playhead`,
		"aria-valuemin": 0,
		"aria-valuemax": t - 1,
		"aria-valuenow": c,
		"aria-valuetext": Yc(c),
		onPointerDown(e) {
			if (e.pointerType === "mouse" && e.button !== 0) return;
			let t = e.pointerType === "touch", n = s(e);
			i.current = {
				pointer: e.pointerId,
				x: e.clientX,
				y: e.clientY,
				touch: t,
				step: n
			}, t || (e.currentTarget.setPointerCapture?.(e.pointerId), r(n));
		},
		onPointerMove(e) {
			let t = i.current;
			if (!t || t.pointer !== e.pointerId) return;
			if (t.touch) {
				Math.hypot(e.clientX - t.x, e.clientY - t.y) > 8 && (i.current = null);
				return;
			}
			let n = s(e);
			n !== t.step && (t.step = n, r(n));
		},
		onPointerUp(e) {
			let t = i.current;
			i.current = null, t?.touch && t.pointer === e.pointerId && r(t.step);
		},
		onPointerCancel() {
			i.current = null;
		},
		onLostPointerCapture(e) {
			i.current?.pointer === e.pointerId && !i.current.touch && (i.current = null);
		},
		onKeyDown(e) {
			let n = o(e.timeStamp - a.current.at < 300 ? a.current.step : c), i = e.shiftKey ? 16 : Jc, s = {
				ArrowLeft: n - i,
				ArrowDown: n - i,
				ArrowRight: n + i,
				ArrowUp: n + i,
				PageDown: n - 16,
				PageUp: n + 16,
				Home: 0,
				End: t - 16
			}[e.key];
			s !== void 0 && (e.preventDefault(), e.stopPropagation(), a.current = {
				step: o(s),
				at: e.timeStamp
			}, r(o(s)));
		}
	};
}
// src/pianoRoll.ts
function Zc(e) {
	let t = [...e].sort((e, t) => e.note[0] - t.note[0] || e.note[2] - t.note[2] || Number(t.selected) - Number(e.selected)), n = [], r = /* @__PURE__ */ new Set();
	for (let e of t) {
		let t = n.at(-1);
		t && t[0] === e.note[0] && t[2] === e.note[2] || (e.selected && r.add(n.length), n.push(e.note));
	}
	return {
		notes: n,
		selected: r
	};
}
var Qc = (e, t, n) => Zc(e.map((e, r) => t.has(r) ? {
	note: n(e),
	selected: !0
} : {
	note: e,
	selected: !1
})), $c = (e, t, n) => Math.max(t, Math.min(n, e)), el = (e, t) => t ? Math.floor(e / t) * t : Math.round(e), tl = (e, t) => t ? Math.round(e / t) * t : Math.round(e);
function nl(e, t, n) {
	for (let r = e.length - 1; r >= 0; r--) {
		let [i, a, o] = e[r];
		if (o === n && i <= t && t < i + a) return r;
	}
	return -1;
}
function rl(e, t, n, r, i) {
	let a = /* @__PURE__ */ new Set();
	return e.forEach(([e, o, s], c) => {
		s >= r && s <= i && e < n && e + o > t && a.add(c);
	}), a;
}
function il(e, t, n, r, i, a) {
	if (e.length >= 2048) return {
		notes: [...e],
		selected: /* @__PURE__ */ new Set()
	};
	let o = $c(Math.round(t), 0, a - 1), s = [
		o,
		$c(Math.round(n), 1, a - o),
		$c(Math.round(r), 0, 127),
		$c(Math.round(i), 1, 127)
	];
	return Zc([...e.map((e) => ({
		note: e,
		selected: !1
	})), {
		note: s,
		selected: !0
	}]);
}
var al = (e, t) => ({
	notes: e.filter((e, n) => !t.has(n)),
	selected: /* @__PURE__ */ new Set()
});
function ol(e, t, n, r, i) {
	let a = e.filter((e, n) => t.has(n));
	if (!a.length) return {
		notes: [...e],
		selected: /* @__PURE__ */ new Set()
	};
	let o = Math.min(...a.map((e) => e[0])), s = Math.max(...a.map((e) => e[0])), c = Math.min(...a.map((e) => e[2])), l = Math.max(...a.map((e) => e[2])), u = $c(Math.round(n), -o, i - 1 - s), d = $c(Math.round(r), -c, 127 - l);
	return Qc(e, t, ([e, t, n, r]) => [
		e + u,
		Math.min(t, i - e - u),
		n + d,
		r
	]);
}
function sl(e, t, n, r, i = 1) {
	return Qc(e, t, ([e, t, a, o]) => [
		e,
		$c(Math.round(t + n), Math.min(i, r - e), r - e),
		a,
		o
	]);
}
function cl(e, t, n, r = !1) {
	return Qc(e, t, ([e, t, i, a]) => [
		e,
		t,
		i,
		$c(Math.round(r ? n : a + n), 1, 127)
	]);
}
function ll(e, t, n, r, i) {
	return Qc(e, t, ([e, t, a, o]) => {
		let s = O(e, n, r, i);
		return [
			s,
			$c(t, 1, i - s),
			a,
			o
		];
	});
}
function ul(e, t, n, r) {
	let i = e.filter((e, n) => t.has(n));
	if (!i.length) return {
		notes: [...e],
		selected: /* @__PURE__ */ new Set()
	};
	let a = Math.min(...i.map((e) => e[0])), o = Math.max(...i.map((e) => e[0] + e[1])), s = Math.max(n, Math.ceil((o - a) / n) * n), c = i.map(([e, t, n, i]) => [
		e + s,
		Math.min(t, r - e - s),
		n,
		i
	]).filter(([e]) => e < r).slice(0, Math.max(0, y - e.length));
	return Zc([...e.map((e) => ({
		note: e,
		selected: !1
	})), ...c.map((e) => ({
		note: e,
		selected: !0
	}))]);
}
// src/components/PianoRoll.tsx
var dl = 11, fl = 42, pl = 16, ml = 48, hl = 3, gl = 64, _l = 1408, vl = /* @__PURE__ */ new Set([
	1,
	3,
	6,
	8,
	10
]), yl = {
	3840: "1 bar",
	1920: "1/2",
	960: "1/4",
	480: "1/8",
	320: "1/8T",
	240: "1/16",
	160: "1/16T",
	120: "1/32"
}, bl = (e) => yl[e] ?? `${e} ticks`, xl = (e, t, n) => Math.max(t, Math.min(n, e)), Sl = (e, t) => e.length === t.length && e.every((e, n) => e.every((e, r) => e === t[n][r])), Cl = (e, t) => e.length === t.length && e.every(([e, n], r) => e === t[r][0] && n === t[r][1]), wl = {
	vel: ["Velocity", "Velocity: drag a note’s bar to set how hard it is played"],
	bend: ["Pitch", "Pitch wheel: draw bends up or down from the centre line. Each synth’s Bend sets how far the wheel reaches."],
	mod: ["Mod", "Mod wheel: draw how far it is pushed up, bringing in each synth’s modulation, or on the organ its rotary speed, fast in the top half"],
	sustain: ["Sustain", "Sustain pedal: draw how far it is pressed down, part way for half-pedal"],
	expression: ["Swell", "Swell pedal: draw how far it is open, fully at the top"]
}, Tl = [], El = (e) => e === "vel" ? "VEL" : Pe[e].tab, Dl = (e) => `${wl[e][0]} ${e === "bend" || e === "mod" ? "wheel" : "pedal"} lane`, Ol = (e, t) => e === "bend" ? ml / 2 - t * (ml / 2 - 3) : 45 - t * 42, kl = (e, t) => e === "bend" ? `Pitch ${t > 0 ? "+" : ""}${t}` : `${wl[e][0]} ${t}`;
function Al({ name: e, notes: t, lanes: n, kinds: r, take: l, loop: f, grid: g, clock: _, disabled: v, onChange: y, onWheels: b, onAudition: S, onAuditionEnd: C, onClose: w, onSeek: T, handle: E }) {
	let D = f / 240, O = a().replace(/[^\w-]/g, ""), ee = a(), [k, te] = d("select"), [ne, A] = d(g), [j, M] = d(13), [N, re] = d(() => /* @__PURE__ */ new Set()), [ie, oe] = d(null), [se, ce] = d(null), [le, ue] = d(() => ({
		tick: 0,
		pitch: t[0]?.[2] ?? 60
	})), [P, F] = d(!1), [de, I] = d({
		length: null,
		velocity: 100
	}), [fe, pe] = d(null), [L, R] = d(!1), [me, he] = d(null), [ge, _e] = d("vel"), [ve, ye] = d(null), [be, xe] = d(null), Se = ["vel", ...r], z = Se.includes(ge) ? ge : "vel", Ce = (e) => n[e] ?? Tl, we = u(null), Te = a(), Ee = u(null), De = u(null), Oe = u(null), ke = u(t), Ae = u(null), je = D * j, Me = ne ?? 240, B = {
		length: L && de.length !== null ? de.length : Me,
		velocity: L ? de.velocity : 100
	}, Ne = (e) => e / 240 * j, Fe = (e) => (127 - e) * dl;
	i(() => {
		t !== ke.current && (ke.current = t, re(/* @__PURE__ */ new Set()), oe(null), ce(null), Ee.current = null);
	}, [t]), s(() => {
		let e = De.current;
		e && M(xl(Math.floor((e.clientWidth - fl) / D), hl, gl));
	}, [D]), s(() => {
		let e = De.current;
		if (!e) return;
		let t = ke.current.map((e) => e[2]), n = t.length ? (Math.min(...t) + Math.max(...t)) / 2 : 60;
		e.scrollTop = Fe(n) - (e.clientHeight - pl - ml) / 2;
	}, []);
	let Ie = _ < 0 ? null : Ne(_ % D * 240), Le = u(null), Re = Xc(e, D, _ < 0 ? null : _ % D, T);
	s(() => {
		let e = De.current, t = Le.current;
		if (Le.current = Ie, !e || Ie === null || Ee.current || we.current) return;
		let n = (t) => t >= e.scrollLeft && t < e.scrollLeft + e.clientWidth - fl;
		!n(Ie) && (l || t !== null && n(t)) && (e.scrollLeft = Math.floor(Ie / (16 * j)) * 16 * j);
	}, [
		Ie,
		l,
		j
	]);
	let ze = ie?.notes ?? t, He = ie?.selected ?? N, Ue = ze.reduce((e, [t]) => e + +(t < f), 0), We = (e, n) => {
		ke.current = e.notes, re(e.selected), oe(null), Sl(e.notes, t) || y(e.notes, n);
		let r = e.selected.size === 1 ? e.notes[[...e.selected][0]] : null;
		r && I({
			length: r[1],
			velocity: r[3]
		});
	}, Ge = (e) => {
		let t = Oe.current.getBoundingClientRect();
		return {
			tick: xl((e.clientX - t.left) / j * 240, 0, f - 1),
			pitch: xl(127 - Math.floor((e.clientY - t.top) / dl), 0, 127),
			x: e.clientX,
			y: e.clientY
		};
	}, Ke = (e, t, n = !1) => {
		v || S(e, t, n);
	}, qe = () => C(), Je = (e, t) => {
		let n = De.current;
		if (!n) return;
		let r = Ne(e), i = Fe(t), a = n.clientWidth - fl, o = n.clientHeight - pl - ml;
		(r < n.scrollLeft || r > n.scrollLeft + a - 24) && (n.scrollLeft = r - a / 3), (i < n.scrollTop || i > n.scrollTop + o - dl) && (n.scrollTop = i - o / 2);
	};
	function Qe(e) {
		if (e.button !== 0 || v || Ee.current) return;
		e.preventDefault(), Oe.current?.focus({ preventScroll: !0 });
		let n = e.pointerType === "touch", r = Ge(e), i = nl(t, r.tick, r.pitch), a = {
			pointer: e.pointerId,
			hit: i,
			tick: r.tick,
			pitch: r.pitch,
			x: r.x,
			y: r.y,
			moved: !1,
			extend: e.shiftKey,
			result: null,
			heard: r.pitch
		};
		if (i >= 0) {
			let [o, s, c, l] = t[i], u = N;
			if (e.shiftKey ? (u = new Set(N), u.has(i) ? u.delete(i) : u.add(i)) : N.has(i) || (u = /* @__PURE__ */ new Set([i])), re(u), ue({
				tick: o,
				pitch: c
			}), !u.has(i)) return;
			let d = Ne(o + s) - (r.x - Oe.current.getBoundingClientRect().left) < Math.min(7, Ne(s) / 3);
			Ee.current = {
				...a,
				kind: d ? "resize" : "move",
				origin: t,
				selected: u,
				anchor: d ? o + s : o,
				heard: c
			}, Ke(c, l, n);
		} else if (k === "draw") {
			let e = il(t, el(r.tick, ne), B.length, r.pitch, B.velocity, f);
			if (!e.selected.size) return;
			let [i, o] = e.notes[[...e.selected][0]];
			oe(e), ue({
				tick: i,
				pitch: r.pitch
			}), Ee.current = {
				...a,
				kind: "draw",
				origin: e.notes,
				selected: e.selected,
				anchor: i + o,
				result: e
			}, Ae.current = {
				note: r.pitch,
				tick: i,
				at: performance.now()
			}, Ke(r.pitch, B.velocity, n);
		} else {
			let n = e.shiftKey ? new Set(N) : /* @__PURE__ */ new Set();
			re(n), ce([
				r.tick,
				r.tick,
				r.pitch,
				r.pitch
			]), ue({
				tick: el(r.tick, ne),
				pitch: r.pitch
			}), Ee.current = {
				...a,
				kind: "marquee",
				origin: t,
				selected: n,
				anchor: r.tick
			};
		}
		e.currentTarget.setPointerCapture(e.pointerId);
	}
	function $e(e) {
		let t = Ee.current;
		if (!t || t.pointer !== e.pointerId || t.kind === "velocity") return;
		let n = Ge(e);
		if (!t.moved && Math.hypot(n.x - t.x, n.y - t.y) < 4) return;
		if (t.moved = !0, t.kind === "marquee") {
			let e = Math.min(t.tick, n.tick), r = Math.max(t.tick, n.tick), i = Math.min(t.pitch, n.pitch), a = Math.max(t.pitch, n.pitch), o = rl(t.origin, e, r, i, a);
			for (let e of t.selected) o.add(e);
			ce([
				e,
				r,
				i,
				a
			]), re(o);
			return;
		}
		let r = n.tick - t.tick;
		if (t.kind === "move") {
			let i = t.origin[t.hit][2] + n.pitch - t.pitch;
			t.result = ol(t.origin, t.selected, tl(t.anchor + r, ne) - t.anchor, n.pitch - t.pitch, f), i !== t.heard && i >= 0 && i <= 127 && (t.heard = i, qe(), Ke(i, t.origin[t.hit][3], e.pointerType === "touch"));
		} else t.result = sl(t.origin, t.selected, tl(t.anchor + r, ne) - t.anchor, f, ne ?? 30);
		oe(t.result);
	}
	function et(e) {
		let t = Ee.current;
		t && t.pointer === e.pointerId && (Ee.current = null, qe(), ce(null), t.kind !== "marquee" && (!t.moved && t.kind !== "draw" ? (!t.extend && t.hit >= 0 && re(/* @__PURE__ */ new Set([t.hit])), oe(null)) : t.result ? We(t.result) : oe(null)));
	}
	function tt(e) {
		let t = Ee.current;
		t && t.pointer === e.pointerId && (Ee.current = null, qe(), oe(null), ce(null));
	}
	function nt(e) {
		if (v) return;
		let n = Ge(e), r = nl(t, n.tick, n.pitch), i = Ae.current;
		r >= 0 && !(i && performance.now() - i.at < 600 && t[r][2] === i.note && t[r][0] === i.tick) ? We(al(t, /* @__PURE__ */ new Set([r]))) : r < 0 && k === "select" && We(il(t, el(n.tick, ne), B.length, n.pitch, B.velocity, f));
	}
	function rt(e) {
		if (e.button !== 0 || v || Ee.current) return;
		let n = e.currentTarget.getBoundingClientRect(), r = e.clientX - n.left, i = -1, a = 8;
		if (t.forEach(([e], t) => {
			let n = Math.abs(Ne(e) + 1 - r) - (N.has(t) ? .5 : 0);
			e < f && n < a && (i = t, a = n);
		}), i < 0) return;
		e.preventDefault();
		let o = N.has(i) ? N : /* @__PURE__ */ new Set([i]);
		re(o), Ee.current = {
			kind: "velocity",
			pointer: e.pointerId,
			origin: t,
			selected: o,
			hit: i,
			anchor: t[i][3],
			tick: 0,
			pitch: 0,
			x: e.clientX,
			y: e.clientY,
			moved: !0,
			extend: !1,
			result: null,
			heard: -1
		}, e.currentTarget.setPointerCapture(e.pointerId), it(e);
	}
	function it(e) {
		let t = Ee.current;
		if (!t || t.pointer !== e.pointerId || t.kind !== "velocity") return;
		let n = e.currentTarget.getBoundingClientRect(), r = xl(Math.round((1 - (e.clientY - n.top - 3) / 42) * 127), 1, 127);
		t.result = t.selected.size === 1 ? cl(t.origin, t.selected, r, !0) : cl(t.origin, t.selected, r - t.anchor), oe(t.result);
	}
	function V(e) {
		let t = Ee.current;
		t && t.pointer === e.pointerId && (Ee.current = null, t.result ? We(t.result) : oe(null));
	}
	function H(e, t) {
		let n = t.currentTarget.getBoundingClientRect(), r = t.clientY - n.top, i = xl(Math.floor((t.clientX - n.left) / j * 240), 0, f - 1), a = e === "bend" ? xl((ml / 2 - r) / (ml / 2 - 3), -1, 1) : xl((45 - r) / 42, 0, 1);
		return [i, Ve(e, e === "bend" && Math.abs(a) < .04 ? 0 : a)];
	}
	function U(e, t) {
		let n = ne ?? 30;
		for (let [r, i] of Ze(e.kind, e.last, t, n)) r < f && e.cells.set(r, i);
		e.last = t, e.low = Math.min(e.low, t[0]), e.high = Math.max(e.high, t[0]);
		let r = Math.floor(e.low / n) * n, i = Math.min(f, (Math.floor(e.high / n) + 1) * n);
		e.result = e.erase ? Xe(e.origin, r, i) : Ye(e.origin, r, i, [...e.cells], f, Pe[e.kind].rest), ye(e.result), xe(e.erase ? null : t);
	}
	function W(e) {
		if (z === "vel" || e.button !== 0 || v || Ee.current || we.current) return;
		e.preventDefault();
		let t = H(z, e);
		we.current = {
			pointer: e.pointerId,
			kind: z,
			origin: Ce(z),
			cells: /* @__PURE__ */ new Map(),
			last: t,
			erase: e.altKey,
			low: t[0],
			high: t[0],
			result: null
		}, e.currentTarget.setPointerCapture(e.pointerId), U(we.current, t);
	}
	function G(e) {
		let t = we.current;
		t && t.pointer === e.pointerId && U(t, H(t.kind, e));
	}
	function K(e) {
		let t = we.current;
		t && t.pointer === e.pointerId && (we.current = null, ye(null), xe(null), e.type !== "pointercancel" && t.result && !Cl(t.result, t.origin) && b(t.kind, t.result));
	}
	let at = () => new Set(t.flatMap(([e], t) => e < f ? [t] : []));
	function q(e) {
		let n = [...at()];
		if (!n.length) return;
		let r = N.size ? Math.min(...N) : -1, i = n[(((r >= 0 ? n.indexOf(r) : n.findIndex((e) => t[e][0] >= le.tick) - +(e > 0)) + e) % n.length + n.length) % n.length];
		re(/* @__PURE__ */ new Set([i])), ue({
			tick: t[i][0],
			pitch: t[i][2]
		}), Je(t[i][0], t[i][2]), Ke(t[i][2], t[i][3]), window.setTimeout(qe, 160);
	}
	function ot(e) {
		if (Ee.current || v || e.defaultPrevented) return;
		let n = e.key, r = e.metaKey || e.ctrlKey, i = N.size > 0, a = null;
		if (r && n.toLowerCase() === "a") re(at());
		else if (r && n.toLowerCase() === "d") i && (a = ul(t, N, Math.max(Me, 960), f));
		else if (r || e.altKey) return;
		else if (n === "Delete" || n === "Backspace") {
			if (i) a = al(t, N);
			else return;
		} else if (n === "ArrowUp" || n === "ArrowDown") {
			let r = (n === "ArrowUp" ? 1 : -1) * (e.shiftKey ? 12 : 1);
			if (i) a = ol(t, N, 0, r, f);
			else {
				let e = xl(le.pitch + r, 0, 127);
				ue({
					...le,
					pitch: e
				}), Je(le.tick, e);
			}
		} else if (n === "ArrowLeft" || n === "ArrowRight") {
			let r = n === "ArrowRight" ? 1 : -1;
			if (i && e.shiftKey) a = sl(t, N, r * Me, f, Me);
			else if (i) a = ol(t, N, r * Me, 0, f);
			else {
				let t = xl(el(le.tick, ne) + r * (e.shiftKey ? 3840 : Me), 0, f - Me);
				ue({
					...le,
					tick: t
				}), Je(t, le.pitch);
			}
		} else if (n === "n" || n === "N") a = il(t, le.tick, B.length, le.pitch, B.velocity, f), Ke(le.pitch, B.velocity), window.setTimeout(qe, 160);
		else if (n === "]" || n === "[") q(n === "]" ? 1 : -1);
		else if (n === "Escape") i ? re(/* @__PURE__ */ new Set()) : w();
		else return;
		if (e.preventDefault(), e.stopPropagation(), a) {
			We(a);
			let e = a.notes[Math.min(...a.selected)];
			e && (ue({
				tick: e[0],
				pitch: e[2]
			}), Je(e[0], e[2]));
		}
	}
	let st = N.size === 1 ? t[[...N][0]] : null, ct = be && z !== "vel" ? `${kl(z, be[1])} at ${ae(Math.floor(be[0] / 240), D)}` : st ? `${Or(st[2])} at ${ae(Math.floor(st[0] / 240), D)}, ${bl(st[1])}, velocity ${st[3]}` : N.size ? `${N.size} of ${Ue} notes selected` : `${Ue} ${Ue === 1 ? "note" : "notes"} · cursor ${Or(le.pitch)} at ${ae(Math.floor(le.tick / 240), D)}`, J = N.size ? t[Math.min(...N)]?.[3] ?? "" : "", lt = (e, n) => {
		N.size && We(e(t, N), n);
	};
	o(E, () => ({ quantize: (e) => v || !N.size ? 0 : (We(ll(t, N, e, 1, f)), N.size) }));
	let ut = c(() => Array.from({ length: 128 }, (e, t) => {
		let n = 127 - t, r = vl.has(n % 12);
		return /* @__PURE__ */ h("g", {
			"data-pitch": n,
			"data-down": n === me,
			children: [
				/* @__PURE__ */ m("rect", {
					y: t * dl,
					width: fl,
					height: dl,
					className: Q.rollWhite
				}),
				r && /* @__PURE__ */ m("rect", {
					y: t * dl,
					width: fl * .6,
					height: dl,
					className: Q.rollBlack
				}),
				n % 12 == 0 && /* @__PURE__ */ m("text", {
					x: 39,
					y: t * dl + dl - 2,
					children: Or(n)
				})
			]
		}, n);
	}), [me]), dt = (e) => xl(127 - Math.floor((e.clientY - e.currentTarget.getBoundingClientRect().top) / dl), 0, 127), ft = () => {
		me !== null && (he(null), qe());
	}, pt = c(() => ze.map(([e, t, n, r], i) => e < f && /* @__PURE__ */ m("rect", {
		className: Q.rollNote,
		x: Ne(e),
		y: Fe(n) + 1,
		width: Math.max(3, Ne(t) - 1),
		height: 9,
		rx: 2,
		fillOpacity: .5 + r / 127 * .5,
		"data-note": n,
		"data-tick": e,
		"data-length": t,
		"data-velocity": r,
		"data-selected": He.has(i)
	}, i)), [
		ze,
		He,
		f,
		j
	]), Y = Math.ceil(D / 16), [mt, X] = wl[z], ht = z === "vel" ? null : ve ?? Ce(z), gt = ht?.filter(([e]) => e < f).length ?? 0, _t = c(() => {
		if (z === "vel" || !ht) return null;
		let e = ht.filter(([e]) => e < f);
		if (!e.length) return null;
		let t = (e) => Ol(z, Be(z, e)), n = `M0 ${t(e.at(-1)[1])}`;
		for (let [r, i] of e) n += `H${Ne(r)}V${t(i)}`;
		return n += `H${je}`, {
			line: n,
			area: `${n}V${Ol(z, 0)}H0Z`
		};
	}, [
		z,
		ht,
		f,
		j,
		je
	]);
	return /* @__PURE__ */ h("div", {
		className: Q.pianoRoll,
		role: "group",
		"aria-label": `${e} piano roll`,
		children: [
			/* @__PURE__ */ h("div", {
				className: Q.rollTools,
				children: [
					/* @__PURE__ */ h("span", {
						className: Q.rollToolGroup,
						role: "group",
						"aria-label": "Tool",
						children: [
							/* @__PURE__ */ m("button", {
								"aria-pressed": k === "select",
								onClick: () => te("select"),
								title: "Drag across notes to select them; double-click to add one",
								children: "Select"
							}),
							/* @__PURE__ */ m("button", {
								"aria-pressed": k === "draw",
								onClick: () => te("draw"),
								title: "Click to draw a note, drag right or left to set its length",
								children: "Draw"
							}),
							/* @__PURE__ */ m("button", {
								"aria-pressed": L,
								onClick: () => R(!L),
								title: "New notes take the length and velocity of the last note you drew or edited. Off, each starts one Snap step long at velocity 100.",
								children: "Inherit"
							})
						]
					}),
					/* @__PURE__ */ h("label", {
						className: Q.playsControl,
						title: "Where notes land as you draw, move and resize them; Off places them freely. Quantize, beside the clip's settings, is separate.",
						children: ["SNAP", /* @__PURE__ */ h("select", {
							"aria-label": "Snap",
							value: ne ?? 0,
							onChange: (e) => A(Number(e.target.value) || null),
							children: [x.map(([e, t]) => /* @__PURE__ */ m("option", {
								value: t,
								children: e
							}, t)), /* @__PURE__ */ m("option", {
								value: 0,
								children: "Off"
							})]
						})]
					}),
					/* @__PURE__ */ h("span", {
						className: Q.rollToolGroup,
						role: "group",
						"aria-label": "Zoom",
						children: [/* @__PURE__ */ m("button", {
							"aria-label": "Zoom out",
							title: "Zoom out",
							disabled: j <= hl,
							onClick: () => M(Math.max(hl, Math.floor(j / 1.5))),
							children: "−"
						}), /* @__PURE__ */ m("button", {
							"aria-label": "Zoom in",
							title: "Zoom in",
							disabled: j >= gl,
							onClick: () => M(Math.min(gl, Math.ceil(j * 1.5))),
							children: "＋"
						})]
					}),
					/* @__PURE__ */ h("label", {
						className: Q.playsControl,
						title: "The selected notes' velocity, 1 to 127, as hard as each is played. The bars under the grid set it by dragging.",
						children: ["VEL", /* @__PURE__ */ m("input", {
							type: "number",
							min: 1,
							max: 127,
							"aria-label": "Velocity of the selected notes",
							disabled: v || !N.size,
							value: fe ?? J,
							onChange: (e) => {
								let t = Number(e.target.value);
								pe(e.target.value), e.target.value && t >= 1 && t <= 127 && lt((e, n) => cl(e, n, Math.round(t), !0), "roll-velocity");
							},
							onBlur: () => pe(null)
						})]
					}),
					/* @__PURE__ */ m("span", {
						className: Q.rollToolGroup,
						role: "group",
						"aria-label": "Transpose",
						children: [
							[
								-12,
								"down an octave",
								"−12"
							],
							[
								-1,
								"down a semitone",
								"−1"
							],
							[
								1,
								"up a semitone",
								"+1"
							],
							[
								12,
								"up an octave",
								"+12"
							]
						].map(([e, t, n]) => /* @__PURE__ */ m("button", {
							"aria-label": `Transpose ${t}`,
							title: `Move the selected notes ${t}${Math.abs(e) === 12 ? " (Shift+↑/↓)" : " (↑/↓)"}`,
							disabled: v || !N.size,
							onClick: () => lt((t, n) => ol(t, n, 0, e, f)),
							children: n
						}, e))
					}),
					/* @__PURE__ */ m("button", {
						disabled: v || !N.size,
						onClick: () => lt((e, t) => ul(e, t, Math.max(Me, 960), f)),
						title: "Copy the selected notes to just after them (⌘D / Ctrl+D)",
						children: "Duplicate"
					}),
					/* @__PURE__ */ m("button", {
						disabled: v || !N.size,
						onClick: () => lt(al),
						"aria-label": "Delete the selected notes",
						title: "Delete the selected notes (Delete)",
						children: "Delete"
					}),
					/* @__PURE__ */ m("button", {
						disabled: !Ue,
						onClick: () => re(at()),
						title: "Select every note in the clip (⌘A / Ctrl+A)",
						children: "Select all"
					}),
					z !== "vel" && /* @__PURE__ */ h("button", {
						disabled: v || !Ce(z).length,
						onClick: () => b(z, []),
						"aria-label": `Clear the ${mt} lane`,
						title: `Delete every point in the ${El(z)} lane, leaving the ${z === "bend" || z === "mod" ? "wheel" : "pedal"} at rest. Undo brings them back.`,
						children: ["Clear ", El(z)]
					}),
					/* @__PURE__ */ m("span", {
						className: Q.rollStatus,
						"aria-live": "polite",
						children: ct
					}),
					/* @__PURE__ */ m("button", {
						className: Q.rollClose,
						"aria-label": "Close piano roll",
						title: "Close the piano roll",
						onClick: w,
						children: "×"
					})
				]
			}),
			/* @__PURE__ */ m("div", {
				ref: De,
				className: Q.rollScroller,
				children: /* @__PURE__ */ h("div", {
					className: Q.rollCanvas,
					style: { width: fl + je },
					children: [
						/* @__PURE__ */ h("div", {
							className: Q.rollRulerRow,
							children: [/* @__PURE__ */ m("span", { className: Q.rollCorner }), /* @__PURE__ */ h("svg", {
								className: Q.rollRuler,
								width: je,
								height: pl,
								style: {
									width: je,
									height: pl
								},
								...Re,
								children: [Array.from({ length: Y }, (e, t) => /* @__PURE__ */ h("g", { children: [/* @__PURE__ */ m("line", {
									x1: t * 16 * j,
									x2: t * 16 * j,
									y1: 0,
									y2: pl
								}), /* @__PURE__ */ m("text", {
									x: t * 16 * j + 3,
									y: 12,
									children: t + 1
								})] }, t)), Ie !== null && /* @__PURE__ */ m("line", {
									className: Q.playhead,
									x1: Ie,
									x2: Ie,
									y1: 0,
									y2: pl
								})]
							})]
						}),
						/* @__PURE__ */ h("div", {
							className: Q.rollBody,
							children: [/* @__PURE__ */ m("svg", {
								className: Q.rollKeys,
								width: fl,
								height: _l,
								style: {
									width: fl,
									height: _l
								},
								"aria-hidden": "true",
								onPointerDown: (e) => {
									if (e.pointerType !== "mouse" || e.button !== 0) return;
									let t = dt(e);
									he(t), Ke(t, 100);
								},
								onPointerMove: (e) => {
									if (me === null) return;
									let t = dt(e);
									t !== me && (qe(), he(t), Ke(t, 100));
								},
								onPointerUp: ft,
								onPointerLeave: ft,
								onPointerCancel: ft,
								children: ut
							}), /* @__PURE__ */ h("svg", {
								ref: Oe,
								className: Q.rollGrid,
								width: je,
								height: _l,
								style: {
									width: je,
									height: _l
								},
								tabIndex: 0,
								role: "application",
								"aria-label": `${e} notes`,
								"aria-describedby": ee,
								"data-notes": Ue,
								"data-tool": k,
								onPointerDown: Qe,
								onPointerMove: $e,
								onPointerUp: et,
								onPointerCancel: tt,
								onLostPointerCapture: et,
								onDoubleClick: nt,
								onKeyDown: ot,
								onFocus: () => F(!0),
								onBlur: () => F(!1),
								children: [
									/* @__PURE__ */ h("defs", { children: [/* @__PURE__ */ m("pattern", {
										id: `${O}rows`,
										width: je,
										height: 132,
										patternUnits: "userSpaceOnUse",
										children: Array.from({ length: 12 }, (e, t) => {
											let n = 127 - t;
											return /* @__PURE__ */ h("g", { children: [vl.has(n % 12) && /* @__PURE__ */ m("rect", {
												y: t * dl,
												width: je,
												height: dl,
												className: Q.rollShade
											}), /* @__PURE__ */ m("line", {
												x1: 0,
												x2: je,
												y1: (t + 1) * dl,
												y2: (t + 1) * dl,
												className: n % 12 == 0 ? Q.rollOctave : Q.rollRowLine
											})] }, t);
										})
									}), /* @__PURE__ */ m("pattern", {
										id: `${O}beats`,
										width: 16 * j,
										height: _l,
										patternUnits: "userSpaceOnUse",
										children: Array.from({ length: 16 }, (e, t) => (t % 4 == 0 || j >= 8) && /* @__PURE__ */ m("line", {
											x1: t * j,
											x2: t * j,
											y1: 0,
											y2: _l,
											className: t === 0 ? Q.rollBar : t % 4 == 0 ? Q.rollBeat : Q.rollStep
										}, t))
									})] }),
									/* @__PURE__ */ m("rect", {
										width: je,
										height: _l,
										fill: `url(#${O}rows)`
									}),
									/* @__PURE__ */ m("rect", {
										width: je,
										height: _l,
										fill: `url(#${O}beats)`
									}),
									pt,
									l?.map(([e, t, n], r) => e < f && /* @__PURE__ */ m("rect", {
										className: Q.rollTake,
										x: Ne(e),
										y: Fe(n) + 1,
										width: Math.max(3, Ne(t) - 1),
										height: 9,
										rx: 2
									}, `take${r}`)),
									P && !N.size && /* @__PURE__ */ m("rect", {
										className: Q.rollCursor,
										x: Ne(le.tick),
										y: Fe(le.pitch),
										width: Math.max(3, Ne(B.length)),
										height: dl
									}),
									se && /* @__PURE__ */ m("rect", {
										className: Q.rollMarquee,
										x: Ne(se[0]),
										y: Fe(se[3]),
										width: Ne(se[1] - se[0]),
										height: (se[3] - se[2] + 1) * dl
									}),
									Ie !== null && /* @__PURE__ */ m("line", {
										className: Q.playhead,
										x1: Ie,
										x2: Ie,
										y1: 0,
										y2: _l
									})
								]
							})]
						}),
						/* @__PURE__ */ h("div", {
							className: Q.rollLaneRow,
							children: [/* @__PURE__ */ m("span", {
								className: `${Q.rollLaneLabel} ${Q.rollLaneTabs}`,
								role: "tablist",
								"aria-label": "Lane",
								"aria-orientation": "vertical",
								"data-many": Se.length > 4 || void 0,
								children: Se.map((e) => /* @__PURE__ */ m("button", {
									role: "tab",
									"aria-selected": z === e,
									"aria-controls": Te,
									tabIndex: z === e ? 0 : -1,
									title: wl[e][1],
									onClick: () => _e(e),
									onKeyDown: (e) => {
										let t = e.key === "ArrowDown" ? 1 : e.key === "ArrowUp" ? -1 : 0;
										if (!t) return;
										e.preventDefault();
										let n = Se[(Se.indexOf(z) + t + Se.length) % Se.length];
										_e(n), (e.currentTarget.parentElement?.querySelector(`[data-lane="${n}"]`))?.focus();
									},
									"data-lane": e,
									children: El(e)
								}, e))
							}), z === "vel" ? /* @__PURE__ */ m("svg", {
								id: Te,
								className: Q.rollLane,
								width: je,
								height: ml,
								style: {
									width: je,
									height: ml
								},
								role: "img",
								"aria-label": "Note velocities",
								"data-lane": "vel",
								onPointerDown: rt,
								onPointerMove: it,
								onPointerUp: V,
								onPointerCancel: tt,
								onLostPointerCapture: V,
								children: ze.map(([e, , , t], n) => e < f && /* @__PURE__ */ m("rect", {
									x: Ne(e),
									y: 45 - t / 127 * 42,
									width: 3,
									height: t / 127 * 42,
									"data-velocity": t,
									"data-selected": He.has(n)
								}, n))
							}) : /* @__PURE__ */ h("svg", {
								id: Te,
								className: Q.rollLane,
								width: je,
								height: ml,
								style: {
									width: je,
									height: ml
								},
								role: "img",
								"aria-label": `${Dl(z)}, ${gt} ${gt === 1 ? "point" : "points"}`,
								"data-lane": z,
								"data-points": gt,
								onPointerDown: W,
								onPointerMove: G,
								onPointerUp: K,
								onPointerCancel: K,
								onLostPointerCapture: K,
								children: [
									/* @__PURE__ */ m("title", { children: `${X}${X.endsWith(".") ? "" : "."} Alt-drag erases.` }),
									z === "bend" && /* @__PURE__ */ m("line", {
										className: Q.rollLaneCentre,
										x1: 0,
										x2: je,
										y1: ml / 2,
										y2: ml / 2
									}),
									_t && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", {
										className: Q.rollWheelArea,
										d: _t.area
									}), /* @__PURE__ */ m("path", {
										className: Q.rollWheelLine,
										d: _t.line
									})] }),
									Ie !== null && /* @__PURE__ */ m("line", {
										className: Q.playhead,
										x1: Ie,
										x2: Ie,
										y1: 0,
										y2: ml
									})
								]
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ h("p", {
				id: ee,
				className: Q.visuallyHidden,
				children: [
					k === "select" ? "Drag across notes to select them; double-click to add one. " : "Click to draw a note and drag right or left to set its length. ",
					L ? "New notes take the length and velocity of the last note drawn or edited. " : "New notes start one Snap step long at velocity 100. ",
					"Drag a note to move it, or its right edge to resize; double-click deletes it. Under the grid, VEL and the tabs beside it pick the lane: drag in a wheel's or pedal's lane to draw its moves, and Alt-drag to erase them. Keys: arrows move the selection or the cursor, Shift+←/→ resizes, Shift+↑/↓ moves an octave, N adds a note at the cursor, [ and ] step through notes, Delete removes and ⌘D duplicates. Click or drag the bar numbers to move the playhead, or tap them on a touch screen, where dragging the keys or bar numbers scrolls."
				]
			})
		]
	});
}
// src/components/Dictator.tsx
var jl = [
	"monarch",
	"oracle",
	"aurora",
	"prism",
	"velvet",
	"reed",
	"planet",
	"strut",
	"drawbar"
], Ml = (e) => jl.includes(e.type) || un(e.type), Nl = [], Pl = Array.from({ length: 41 }, (e, t) => t * 5 - 100);
function Fl({ module: e, patch: t, name: n, clock: r, take: i, armed: a, recording: o, disabled: s, control: l, transport: d, plays: f, offset: p, editing: g, grid: _, onParam: v, onPlays: y, onArm: b, onClear: S, onQuantize: w, onCapture: T, onDiscard: E, onOffset: D, onEditing: O, onNotes: ee, onWheels: k, onAudition: te, onAuditionEnd: ne, onSeek: A, importing: j, onExportMidi: M, onImportMidi: N, onImportTracks: re, onImportCancel: ie }) {
	let oe = u(null), se = u(null), ce = u(null), le = e.notes ?? Nl, ue = C(e.params.length), P = ue / 240, F = t.modules.filter(Ml), de = le.length + (i?.length ?? 0), I = o && a, fe = e.params.qrec === 1, pe = x[e.params.quantize]?.[0] ?? "1/16", L = c(() => Object.fromEntries(B.map((t) => [t, tn(e, t)])), [e]), R = ln(t, e.id), me = R.length ? R : ["bend", "mod"], he = B.filter((e) => me.includes(e) || L[e].length), ge = c(() => he, [he.join()]);
	return /* @__PURE__ */ h("div", {
		className: Q.dictatorBody,
		children: [
			/* @__PURE__ */ h("div", {
				className: Q.sequenceTop,
				children: [
					/* @__PURE__ */ h("div", {
						className: Q.lcd,
						children: [
							/* @__PURE__ */ m("small", { children: I ? "RECORDING" : "CLIP" }),
							/* @__PURE__ */ m("strong", { children: ae(Math.max(0, r), P).split(".").slice(0, 2).join(".") }),
							/* @__PURE__ */ m("span", {
								className: Q.lcdDots,
								"aria-hidden": "true"
							})
						]
					}),
					/* @__PURE__ */ h("button", {
						className: Q.armButton,
						"aria-pressed": a,
						"data-recording": I,
						disabled: s,
						"aria-label": `${a ? "Disarm" : "Arm"} ${n} to record`,
						title: "Arm this DICTATOR to record into it: the keys play through it, and RECORD or R records what you play. With more than one DICTATOR, only the armed one records; arming another disarms this one.",
						onClick: b,
						children: [/* @__PURE__ */ m("span", { className: Q.armLed }), "ARM"]
					}),
					/* @__PURE__ */ h("div", {
						className: Q.controls,
						children: [
							l("length"),
							l("mode"),
							l("lag")
						]
					}),
					/* @__PURE__ */ h("div", {
						className: Q.transport,
						children: [d, /* @__PURE__ */ m("span", {
							className: Q.transportCaption,
							children: "LOOPING CLIP / POLY"
						})]
					})
				]
			}),
			/* @__PURE__ */ h("div", {
				className: Q.quantizeRow,
				children: [
					l("quantize"),
					/* @__PURE__ */ m("button", {
						disabled: s || !le.some(([e]) => e < ue),
						"aria-label": `Quantize notes in ${n}`,
						onClick: () => w(g ? ce.current?.quantize(_) ?? 0 : 0),
						title: `Move note starts onto the ${pe} grid now: the notes selected in the piano roll, or else every note. Undo moves them back.`,
						children: "Quantize"
					}),
					/* @__PURE__ */ h("button", {
						className: Q.lampButton,
						"aria-pressed": fe,
						disabled: s,
						"aria-label": `Auto-quantize ${n} while recording`,
						onClick: () => v("qrec", +!fe),
						title: Z.dictator.params.find((e) => e.id === "qrec")?.hint,
						children: [/* @__PURE__ */ m("span", { className: Q.lampLed }), "AUTO"]
					})
				]
			}),
			g ? /* @__PURE__ */ m(Al, {
				handle: ce,
				name: n,
				notes: le,
				take: i,
				loop: ue,
				grid: _,
				clock: r,
				disabled: s,
				onChange: ee,
				lanes: L,
				kinds: ge,
				onWheels: k,
				onAudition: te,
				onAuditionEnd: ne,
				onSeek: A,
				onClose: () => {
					O(!1), oe.current?.focus();
				}
			}) : /* @__PURE__ */ m(Ll, {
				name: n,
				notes: le,
				take: i,
				loop: ue,
				position: r < 0 ? null : r % P,
				onSeek: A,
				label: `${n} clip, ${de} ${de === 1 ? "note" : "notes"}`
			}),
			/* @__PURE__ */ h("div", {
				className: Q.dictatorActions,
				children: [
					/* @__PURE__ */ h("label", {
						className: Q.playsControl,
						title: "Patch this clip's Pitch and Gate into an instrument in one step. Undo puts the cables back.",
						children: ["PLAYS", /* @__PURE__ */ h("select", {
							"data-analytics-private": F.some((e) => e.label) ? "" : void 0,
							"aria-label": `${n} plays`,
							value: f ?? "",
							disabled: s,
							onChange: (e) => {
								e.target.value && y(e.target.value);
							},
							children: [/* @__PURE__ */ m("option", {
								value: "",
								children: f === null ? "Choose…" : "Patched by hand"
							}), F.map((e) => /* @__PURE__ */ m("option", {
								value: e.id,
								children: nr(t, e)
							}, e.id))]
						})]
					}),
					/* @__PURE__ */ m("button", {
						ref: oe,
						className: Q.editButton,
						"aria-pressed": g,
						"aria-label": `Edit ${n} notes`,
						title: "Open the clip in the piano roll to draw, move and resize its notes",
						onClick: () => O(!g),
						children: "EDIT"
					}),
					I ? /* @__PURE__ */ m("button", {
						onClick: E,
						title: "Throw away this take so far and keep recording (Backspace)",
						children: "Discard take"
					}) : /* @__PURE__ */ m("button", {
						disabled: s || o,
						onClick: T,
						"aria-label": `Capture into ${n}`,
						title: "Keep what you just played with the transport running, without having pressed RECORD",
						children: "Capture"
					}),
					/* @__PURE__ */ m("button", {
						disabled: s || !Fn(t, e),
						onClick: S,
						"aria-label": `Clear ${n} notes`,
						title: "Delete every note in the clip, and its wheel and pedal lanes. Undo brings them back.",
						children: "Clear"
					}),
					/* @__PURE__ */ m("button", {
						disabled: !le.some(([e]) => e < ue),
						onClick: M,
						"aria-label": `Export ${n} as a MIDI file`,
						title: "Save the clip as a .mid file, for a DAW or another Rackloose",
						children: "Export .mid"
					}),
					/* @__PURE__ */ m("button", {
						disabled: s || I,
						onClick: () => se.current?.click(),
						"aria-label": `Import a MIDI file into ${n}`,
						title: "Replace the clip with the notes of a .mid file, up to 16 bars",
						children: "Import .mid"
					}),
					/* @__PURE__ */ m("input", {
						ref: se,
						type: "file",
						accept: ".mid,.midi,audio/midi,audio/x-midi",
						hidden: !0,
						"aria-label": `MIDI file for ${n}`,
						onChange: (e) => {
							let t = e.target.files?.[0];
							e.target.value = "", t && N(t);
						}
					}),
					/* @__PURE__ */ h("label", {
						className: Q.offsetControl,
						title: "If the notes you record land later than you played them, as with Bluetooth headphones or a slow keyboard, record them this much earlier; if they land early, later. It changes only what is recorded, never what you hear, and is kept in this browser, for every DICTATOR.",
						children: ["REC TIMING", /* @__PURE__ */ m("select", {
							"aria-label": "Recording timing",
							value: p,
							onChange: (e) => D(Number(e.target.value)),
							children: Pl.map((e) => /* @__PURE__ */ m("option", {
								value: e,
								children: e > 0 ? `${e} ms earlier` : e < 0 ? `${-e} ms later` : "As played"
							}, e))
						})]
					})
				]
			}),
			j && /* @__PURE__ */ m(Il, {
				importing: j,
				onPick: re,
				onCancel: ie
			})
		]
	});
}
function Il({ importing: e, onPick: t, onCancel: n }) {
	let [r, i] = d("all"), a = (e) => `${e} ${e === 1 ? "note" : "notes"}`;
	return /* @__PURE__ */ h("div", {
		className: Q.midiTracks,
		role: "group",
		"aria-label": `Tracks of ${e.file}`,
		children: [
			/* @__PURE__ */ h("span", { children: [
				e.file,
				" has ",
				e.tracks.length,
				" tracks."
			] }),
			/* @__PURE__ */ h("select", {
				"aria-label": "Track to import",
				value: r,
				autoFocus: !0,
				onChange: (e) => i(e.target.value),
				children: [/* @__PURE__ */ h("option", {
					value: "all",
					children: ["All tracks · ", a(e.tracks.reduce((e, t) => e + t.notes.length, 0))]
				}), e.tracks.map((e, t) => /* @__PURE__ */ h("option", {
					value: t,
					children: [
						e.name,
						" · ch ",
						e.channel + 1,
						e.channel === 9 ? " drums" : "",
						" · ",
						a(e.notes.length)
					]
				}, t))]
			}),
			/* @__PURE__ */ m("button", {
				onClick: () => t(r === "all" ? null : Number(r)),
				children: "Import"
			}),
			/* @__PURE__ */ m("button", {
				onClick: n,
				children: "Cancel"
			})
		]
	});
}
function Ll({ name: e, notes: t, take: n, loop: r, position: i, onSeek: a, label: o }) {
	let s = Xc(e, r / 240, i, a), c = i === null ? null : i * 240, l = [...t, ...n ?? []].filter(([e]) => e < r), u = l.length ? Math.min(...l.map((e) => e[2])) : 48, d = l.length ? Math.max(...l.map((e) => e[2])) : 59, f = Math.max(12, d - u + 1), p = d + Math.floor((f - (d - u + 1)) / 2), _ = ([e, t, n, i], a, o) => /* @__PURE__ */ m("rect", {
		x: e,
		y: p - n,
		width: Math.max(t, r / 400),
		height: 1,
		"data-take": a,
		opacity: .45 + i / 127 * .55,
		children: /* @__PURE__ */ h("title", { children: [
			Or(n),
			" · velocity ",
			i
		] })
	}, `${a ? "t" : "n"}${o}`);
	return /* @__PURE__ */ h("div", {
		className: Q.noteStripFrame,
		children: [/* @__PURE__ */ h("svg", {
			className: Q.noteStrip,
			role: "img",
			"aria-label": o,
			"data-notes": l.length,
			viewBox: `0 0 ${r} ${f}`,
			preserveAspectRatio: "none",
			children: [
				Array.from({ length: r / g - 1 }, (e, t) => /* @__PURE__ */ m("line", {
					x1: (t + 1) * g,
					x2: (t + 1) * g,
					y1: 0,
					y2: f,
					vectorEffect: "non-scaling-stroke"
				}, t)),
				t.filter(([e]) => e < r).map((e, t) => _(e, !1, t)),
				n?.map((e, t) => _(e, !0, t)),
				c !== null && /* @__PURE__ */ m("line", {
					className: Q.playhead,
					x1: c,
					x2: c,
					y1: 0,
					y2: f,
					vectorEffect: "non-scaling-stroke"
				})
			]
		}), /* @__PURE__ */ m("div", {
			className: Q.stripSeek,
			...s
		})]
	});
}
// ../../../../../rackloose.svg?inline
var Rl = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2064%2064'%3e%3crect%20x='5'%20y='6'%20width='54'%20height='52'%20rx='3'%20fill='%23303337'%20stroke='%23101214'%20stroke-width='2'/%3e%3cpath%20d='M10%2010v44M54%2010v44'%20stroke='%23777'%20stroke-width='3'/%3e%3crect%20x='14'%20y='12'%20width='36'%20height='17'%20fill='%23b9503a'%20stroke='%23111'/%3e%3crect%20x='14'%20y='31'%20width='36'%20height='20'%20fill='%23a0ac9b'%20stroke='%23111'/%3e%3cg%20fill='%23232626'%20stroke='%23dfdfca'%3e%3ccircle%20cx='23'%20cy='21'%20r='5'/%3e%3ccircle%20cx='41'%20cy='21'%20r='5'/%3e%3c/g%3e%3cpath%20d='M23%2021v-4m18%204%203-3'%20stroke='%23fff'%20stroke-width='2'/%3e%3cg%20fill='%231b2221'%20stroke='%23555'%3e%3ccircle%20cx='22'%20cy='39'%20r='3'/%3e%3ccircle%20cx='42'%20cy='44'%20r='3'/%3e%3c/g%3e%3cpath%20d='M22%2039c-6%2020%2027%2020%2020%205'%20fill='none'%20stroke='%23f4bb50'%20stroke-width='3'/%3e%3cpath%20d='M7%208h50'%20stroke='%23a9abad'/%3e%3c/svg%3e", zl = {
	channels: Array(8).fill(-60),
	bus: [-60, -60]
}, Bl = [
	"a",
	"w",
	"s",
	"e",
	"d",
	"f",
	"t",
	"g",
	"y",
	"h",
	"u",
	"j",
	"k",
	"o",
	"l",
	"p",
	";",
	"'"
], Vl = [...new Set(Object.values(S))].sort((e, t) => e - t), Hl = [
	"a",
	"s",
	"d",
	"f",
	"g",
	"h",
	"j",
	"k",
	"l",
	";",
	"'",
	"z",
	"x",
	"c",
	"v",
	"b"
], Ul = /* @__PURE__ */ new Set([
	1,
	3,
	6,
	8,
	10
]), Wl = "input:not([type]), input[type=\"text\"], input[type=\"search\"], textarea, [contenteditable=\"true\"]", Gl = 30, Kl = 40, ql = {
	id: "depth",
	label: "Depth",
	min: -1,
	max: 1,
	step: .01,
	initial: 1
}, Jl = (e) => `${Math.round(e * 100)}%`, Yl = [
	"boom",
	"punch",
	"strike",
	"forge"
], Xl = {
	velvet: Xs,
	reed: Qs,
	planet: ec,
	strut: rc,
	drawbar: oc
}, Zl = {
	oscillator: "1V / OCT",
	filter: "CV CONTROL",
	delay: "WARM REPEATS",
	boom: "LONG LOW END",
	punch: "FOUR ON THE FLOOR",
	skitter: "NO SOUND · ALL BOUNCE",
	forge: "HIT IT HARDER",
	rust: "NOTHING CLEAN"
}, Ql = {
	boom: "ANALOG KIT · 11 VOICES",
	punch: "DANCE FLOOR KIT · 5 VOICES",
	strike: "ORIGINAL DIGITAL KIT · 16 VOICES",
	forge: "INDUSTRIAL KIT · 11 VOICES"
};
function $l(e, t, n) {
	let r = URL.createObjectURL(new Blob([e], { type: t })), i = document.createElement("a");
	i.href = r, i.download = n, i.click(), setTimeout(() => URL.revokeObjectURL(r), 1e3);
}
var eu = (e) => {
	let [t, n] = e.dataset.portKey.split(":");
	return {
		moduleId: t,
		portId: n
	};
}, tu = (e, t) => e === t || !!e && !!t && gn(e, t), nu = (e, t) => e.error === t.error && e.inside === t.inside && e.cableId === t.cableId && gn(e.anchor, t.anchor) && e.point.x === t.point.x && e.point.y === t.point.y && tu(e.target, t.target), ru = (e, t) => gn(e.from, t) ? e.to : e.from, iu = (e, t) => ({
	...e,
	cables: e.cables.filter((e) => e.id !== t)
});
function au(e) {
	try {
		let t = localStorage.getItem(`${e}:baselinePatch`);
		if (t) {
			let e = Cr(t);
			return {
				signature: Sr(e),
				patch: e
			};
		}
	} catch {}
	return null;
}
function ou(e, { signature: t, patch: n }) {
	localStorage.setItem(`${e}:baseline`, t), localStorage.setItem(`${e}:baselinePatch`, xr(n));
}
function su({ key: e, patch: t, open: n }) {
	let r = Tr(localStorage, e, t);
	return r || (n ? localStorage.setItem(`${e}:open`, n) : localStorage.removeItem(`${e}:open`)), r;
}
var cu = 3, lu = 127, uu = (e, t = !1) => B.reduce((n, r) => Ne(r) === t ? n + e[r].length : n, 0);
function du(e, t) {
	let n = (e, t) => e ? `${e} ${t} ${e === 1 ? "move" : "moves"}` : "", r = [
		e && `${e} ${e === 1 ? "note" : "notes"}`,
		n(uu(t), "wheel"),
		n(uu(t, !0), "pedal")
	].filter(Boolean);
	return r.length > 1 ? `${r.slice(0, -1).join(", ")} and ${r.at(-1)}` : r.join("");
}
var fu = (e) => He(B.filter((t) => e[t]?.length).map((e) => Pe[e].name));
function pu({ keysEnabled: e = !0, suspended: t = !1, storageKey: r = "rackloose.patch.v1", linkBrand: o = !0, onEvent: s }) {
	let f = u(s);
	i(() => {
		f.current = s;
	});
	let g = n((e) => {
		try {
			f.current?.(e);
		} catch {}
	}, []), [v, y] = d(() => br()), b = u(v), T = u(null), E = u(null), D = u(null), O = u(null), k = u(null), te = u(null), ne = u(null), [A, j] = d(!1), [N, re] = d(!1), [ie, ce] = d(null), [ue, P] = d(!1), [F, de] = d(null), [I, fe] = d(null), [pe, L] = l((e, t) => ({
		text: t,
		serial: e.serial + 1
	}), {
		text: "Ready when you are. Enable audio, then play a key or start the pattern.",
		serial: 0
	}), R = pe.text, [me, he] = d(!0), [ge, _e] = d(!1), [ve, ye] = d(!1), [be, xe] = d(!1), [Se, z] = d(-1), [Ce, we] = d([]), [Te, Ee] = d(48e3), [De] = d(Ec), [Oe, ke] = d(lu), [Ae, je] = d(!1), [Me, Ie] = d(null), [Le, Re] = d(null), [ze, Ve] = d(!1), [He, Ue] = d(1), [We, Ge] = d(null), Ke = u(() => {}), [qe, Je] = d(cu), [Ye, Xe] = d(!0), [Ze, Qe] = d(null), $e = u(/* @__PURE__ */ new Map()), [et, tt] = d(null), [nt, it] = d(null), [V, H] = d(null), [U, W] = d(null), [G, K] = d(null), [at, q] = d(4), [ot, ct] = d(!1), [J, lt] = d(Wn), [ut, dt] = d(!1), [ft, pt] = d(0), [Y, mt] = d("performance"), X = u("performance"), [ht, gt] = d(/* @__PURE__ */ new Set()), _t = u(/* @__PURE__ */ new Map()), [vt, yt] = d({}), [bt, xt] = d({}), [St, Ct] = d(null), [wt, Tt] = d(null), [Et, Dt] = d(!1), [Ot, kt] = d(null), At = u(null), jt = u(!1), Mt = u(() => {}), Nt = u(() => {}), Pt = u(!0), Ft = u(/* @__PURE__ */ new Set()), [It, Lt] = d({}), [Rt, zt] = d(null), [Vt, Ut] = d({}), [en, nn] = d({
		undo: 0,
		redo: 0
	}), on = u(Wn), sn = u(!1), cn = u(cu), yn = u(lu), bn = u(Gr()), xn = u(null), [Cn, En] = d([]), [Dn, On] = d({}), [kn, An] = d(""), jn = u(""), [Mn, Nn] = d(null), Pn = u(null), Rn = u(null), Bn = u(null), Vn = u(0), Gn = u(!1), qn = u(null), Yn = u(0), Zn = a(), Qn = a(), er = a(), ar = a(), lr = `${r}:presets`, fr = Cn.find((e) => e.id === Dn[kn]) ?? null, pr = fr?.id ?? null, mr = Vt[kn] ?? null, hr = c(() => Sr(v), [v]), gr = c(() => fr ? Sr(fr.patch) : mr?.signature ?? null, [fr, mr]), _r = gr !== null && hr !== gr, vr = fr?.patch ?? mr?.patch ?? null, yr = !!vr && (_r || J.muted.size > 0 || J.soloed.size > 0 || be || qe !== cu || Oe !== lu || Le !== null || ut);
	i(() => {
		b.current = v, T.current?.update(v);
	}, [v]), i(() => {
		let e = new lo(b.current, (e) => L(e.message));
		T.current = e, e.onTake = (...e) => Ke.current(...e);
		let n = 0, r = 0;
		function i(t) {
			let a = De.get(), o = b.current.modules.filter((t) => Jn(t.type) && e.pulsing(t.id)).map((e) => e.id), s = e.wheelLevels(X.current), c = a.wheels, l = s && Object.fromEntries(B.map((e) => [e, Math.round(s[e] * 500) / 500]));
			if (De.set({
				pulsing: o.length === a.pulsing.size && o.every((e) => a.pulsing.has(e)) ? a.pulsing : new Set(o),
				wheels: l && c && B.every((e) => l[e] === c[e]) ? c : l
			}), t - r > 40) {
				Ee(e.sampleRate), z(e.clock), Ie(e.countingIn), _e(e.playing), ye(e.ready), Ve(e.recording), dt(!e.controllersAtRest());
				let n = e.armedId, i = n ? e.takeNotes(n) : null;
				Ge((e) => e?.id === n && e?.notes === i || !e && !i ? e : i && n ? {
					id: n,
					notes: i
				} : null), we((t) => {
					let n = e.activeNotes;
					return n.length === t.length && n.every((e, n) => e === t[n]) ? t : n;
				}), Lt((t) => {
					let n = Object.fromEntries(b.current.modules.filter((e) => zn(e.type)).map((t) => [t.id, {
						playing: e.modulePlaying(t.id),
						clock: e.moduleClock(t.id)
					}]));
					return JSON.stringify(n) === JSON.stringify(t) ? t : n;
				});
				let o = Object.fromEntries(b.current.modules.filter((e) => [
					"compressor",
					"cohere",
					"talon"
				].includes(e.type)).map((t) => [t.id, Math.round(e.reduction(t.id) * 2) / 2])), s = Object.fromEntries(b.current.modules.filter((e) => e.type === "mixer").map((t) => {
					let { channels: n, bus: r } = e.mixerLevels(t.id), i = {
						channels: n.map(Math.round),
						bus: r.map(Math.round)
					}, o = a.mixerLevels[t.id];
					return [t.id, o && JSON.stringify(o) === JSON.stringify(i) ? o : i];
				}));
				De.set({
					meter: e.meter,
					reductions: JSON.stringify(o) === JSON.stringify(a.reductions) ? a.reductions : o,
					mixerLevels: Object.keys(s).length === Object.keys(a.mixerLevels).length && Object.entries(s).every(([e, t]) => a.mixerLevels[e] === t) ? a.mixerLevels : s
				}), r = t;
			}
			n = requestAnimationFrame(i);
		}
		n = requestAnimationFrame(i);
		let a = () => {
			document.hidden ? e.setSuspended(!0) : e.setSuspended(t);
		};
		document.addEventListener("visibilitychange", a);
		let o = E.current, s = (t) => e.lifted(`pointer-${t.pointerId}`), c = () => e.lifted();
		return o?.addEventListener("pointerup", s, !0), o?.addEventListener("touchend", c, !0), () => {
			cancelAnimationFrame(n), document.removeEventListener("visibilitychange", a), o?.removeEventListener("pointerup", s, !0), o?.removeEventListener("touchend", c, !0), e.dispose(), T.current = null;
		};
	}, [t, De]), i(() => {
		T.current?.setSuspended(t);
	}, [t]), i(() => {
		he(!0);
		let e = setTimeout(() => he(!1), Math.min(9e3, 3500 + pe.text.length * 40));
		return () => clearTimeout(e);
	}, [pe]), i(() => {
		T.current?.setMute(be);
	}, [be, t]), i(() => {
		T.current?.setClick(Ae);
	}, [Ae, t]);
	let [Tr, Er] = d(0);
	i(() => {
		let e = 0;
		try {
			e = Math.round(Number(localStorage.getItem(`${r}:recordOffset`) ?? 0));
		} catch {}
		Er(Number.isFinite(e) ? Math.max(-100, Math.min(100, e)) : 0);
	}, [r]), i(() => {
		T.current?.setRecordOffset(Tr);
	}, [Tr]);
	let Dr = n((e) => {
		Er(e);
		try {
			e ? localStorage.setItem(`${r}:recordOffset`, String(e)) : localStorage.removeItem(`${r}:recordOffset`);
		} catch {}
	}, [r]);
	i(() => {
		T.current?.setMix(J);
	}, [J, t]);
	let kr = n((e) => {
		b.current = e.patch, on.current = e.mix, sn.current = e.mainMuted, cn.current = e.octave, yn.current = e.velocity, jn.current = e.session, y(e.patch), lt(e.mix), xe(e.mainMuted), Je(e.octave), ke(e.velocity), An(e.session);
	}, []), Ar = n(() => ({
		patch: b.current,
		mix: on.current,
		mainMuted: sn.current,
		octave: cn.current,
		velocity: yn.current,
		session: jn.current
	}), []), jr = n(() => {
		bn.current = Gr(), nn({
			undo: 0,
			redo: 0
		});
	}, []), Mr = n((e, t = null) => {
		let n = Ar(), r = {
			...n,
			...typeof e == "function" ? e(n) : e
		};
		Object.keys(n).every((e) => r[e] === n[e]) || (bn.current = Kr(bn.current, n, t, Date.now()), nn({
			undo: bn.current.past.length,
			redo: 0
		}), kr(r));
	}, [kr, Ar]), Nr = n((e, t = null) => Mr((t) => ({ patch: e(t.patch) }), t), [Mr]), Pr = n((e, t) => {
		let n = b.current.modules.find((t) => t.id === e), r = Object.keys(t);
		if (!n || r.every((e) => n.params[e] === t[e])) return;
		let i = r.length === 1 ? Z[n.type].params.find((e) => e.id === r[0]) : void 0;
		Nr((n) => ({
			...n,
			modules: n.modules.map((n) => n.id === e ? {
				...n,
				params: {
					...n.params,
					...t
				}
			} : n)
		}), i && !i.choices && !i.pattern ? `param:${e}:${i.id}` : null);
	}, [Nr]), Fr = n((e, t) => Mr((n) => ({ mix: sr(n.mix, e, t) })), [Mr]), Ir = n((e) => Mr((t) => ({ mix: cr(t.mix, e) })), [Mr]), Rr = n((e) => {
		let t = jn.current;
		Ut((n) => ({
			...n,
			[t]: {
				signature: Sr(e),
				patch: e
			}
		}));
	}, []);
	i(() => {
		let e, t = {
			presets: [],
			error: null
		}, n = null;
		try {
			xn.current && xn.current.key !== r && su(xn.current), e = wr(localStorage, r), t = $r(localStorage, `${r}:presets`), n = localStorage.getItem(`${r}:open`);
		} catch {
			e = {
				patch: null,
				error: "Local save unavailable. Export a patch file to keep your work."
			};
		}
		(e.error ?? t.error) && L(e.error ?? t.error);
		let i = e.patch ?? br(), a = e.patch ? au(r) : null;
		T.current?.panic(), X.current = Xt(i).id, mt(X.current);
		let o = Ht("session");
		En(t.presets), On(n && t.presets.some((e) => e.id === n) ? { [o]: n } : {}), Nn(null), kr({
			...Ar(),
			patch: i,
			mix: Wn,
			mainMuted: !1,
			session: o
		}), jr(), Ut({ [o]: a ?? {
			signature: Sr(i),
			patch: i
		} }), fe(null), de(r);
	}, [
		r,
		kr,
		Ar,
		jr
	]), i(() => {
		if (F !== r) return;
		let e = xn.current = {
			key: r,
			patch: v,
			open: pr
		}, t = setTimeout(() => {
			try {
				fe({ error: su(e) });
			} catch {
				fe({ error: "Local save unavailable. Export a patch file to keep your work." });
			}
		}, 400);
		return () => clearTimeout(t);
	}, [
		v,
		pr,
		F,
		r
	]), i(() => {
		if (F === r && mr) try {
			ou(r, mr);
		} catch {}
	}, [
		mr,
		F,
		r
	]), i(() => {
		let e = (e) => {
			if (e.key === lr || e.key === null) try {
				En($r(localStorage, lr).presets);
			} catch {}
		};
		return window.addEventListener("storage", e), () => window.removeEventListener("storage", e);
	}, [lr]), i(() => {
		let e = () => {
			if (xn.current) try {
				su(xn.current);
			} catch {}
		};
		return window.addEventListener("pagehide", e), () => {
			window.removeEventListener("pagehide", e), e();
		};
	}, []), i(() => () => {
		cancelAnimationFrame(Vn.current), cancelAnimationFrame(Yn.current);
	}, []), i(() => (Pt.current = !0, Dt(Vr()), () => {
		Pt.current = !1, At.current?.(), At.current = null;
	}), []);
	let Hr = n((e) => L(e instanceof Error ? e.message : "Audio could not start. Try enabling it again."), []), Ur = n((e, t = !1, n) => {
		(!t || Ft.current.has(e)) && (Ft.current.delete(e), t ? T.current?.cancel(e) : T.current?.release(e, n), _t.current.delete(e) && gt(new Set(_t.current.values())));
	}, []), Xr = n((e) => {
		let t = `pointer-${e.pointerId}`;
		Ft.current.has(t) && Ur(t, !1, e.timeStamp);
	}, [Ur]), Zr = n(() => {
		T.current?.releaseManual(), Ft.current.clear(), _t.current.clear(), gt(/* @__PURE__ */ new Set());
	}, []), Qr = n((e, n, r, i) => {
		t || T.current?.wheel(X.current, e, n, r, i);
	}, [t]), oi = n((e, n, r = !1, i) => {
		if (t) return;
		let a = b.current, o = a.modules.find((e) => e.id === X.current) ?? Xt(a), s = Z[o.type];
		if (!Ln(o.type)) {
			L("Add an instrument or sequencer to play from the keys.");
			return;
		}
		Hn(a, o.id) || L(`${s.name} has no audio path to MAIN. Flip the rack to connect it.`);
		let c = o.type === "dictator" ? pn(a, o.id) : null;
		if (c) {
			let t = Z[c.type].drum.voices[n];
			if (!t || _t.current.has(e)) return;
			_t.current.set(e, t.id), gt(new Set(_t.current.values())), T.current?.press(e, se[t.id], o.id, r, Oe / 127, i).catch(Hr);
		} else if (s.drum) {
			let t = s.drum.voices[n];
			if (!t || _t.current.has(e)) return;
			_t.current.set(e, t.id), gt(new Set(_t.current.values())), T.current?.hit(o.id, t.id, e, r).catch(Hr);
		} else o.type === "noise" && (_t.current.set(e, "noise"), gt(new Set(_t.current.values()))), T.current?.press(e, o.type === "noise" ? 60 : (qe + 1) * 12 + n, o.id, r, Oe / 127, i).catch(Hr);
	}, [
		Hr,
		t,
		qe,
		Oe
	]), si = n((e, t) => yt((n) => n[e] === t ? n : {
		...n,
		[e]: t
	}), []), ci = n((e, n) => {
		t || T.current?.hit(e, n).catch(Hr);
	}, [Hr, t]), li = n(() => {
		T.current?.playing ? T.current.pause() : (g({ name: "transport_play" }), T.current?.play().catch(Hr));
	}, [Hr, g]), ui = n(() => {
		T.current?.rejoin().then((e) => {
			let t = e.map((e) => b.current.modules.find((t) => t.id === e)).filter((e) => !!e).map((e) => nr(b.current, e));
			t.length && L(`${t.length > 1 ? `${t.slice(0, -1).join(", ")} and ${t.at(-1)}` : t[0]} ${t.length > 1 ? "play" : "plays"} again, in time with the rest.`);
		}).catch(Hr);
	}, [Hr]), di = n((e) => {
		Ln(e.type) && X.current !== e.id && (Zr(), T.current?.releasePedals(X.current), X.current = e.id, mt(e.id));
	}, [Zr]), fi = n((e) => {
		T.current?.arm(e), Re(e);
		let t = e && b.current.modules.find((t) => t.id === e);
		t && di(t);
	}, [di]), pi = n(() => {
		let e = T.current;
		if (!e || t) return;
		if (e.recording) {
			e.finishTake();
			return;
		}
		let n = b.current.modules.filter((e) => e.type === "dictator"), r = n.find((t) => t.id === e.armedId)?.id ?? n.find((e) => e.id === X.current)?.id ?? (n.length === 1 ? n[0].id : null);
		r ? (fi(r), e.record(e.playing ? 0 : He).then((e) => {
			e && g({ name: "record_start" }), e && L(`Recording into ${nr(b.current, b.current.modules.find((e) => e.id === r))}. Play the keys; RECORD or R stops.`);
		}).catch(Hr)) : L(n.length ? "Arm a DICTATOR to record into: its ARM button, beside its clip." : "Add a DICTATOR to record what you play: Add device, then DICTATOR.");
	}, [
		t,
		fi,
		He,
		Hr,
		g
	]), mi = n(() => {
		let e = T.current?.discardTake() ?? 0;
		L(e ? `Discarded ${e} ${e === 1 ? "note" : "notes"}. Still recording: play again.` : "Nothing recorded yet. Still recording.");
	}, []), hi = n((e) => {
		let t = T.current, n = b.current.modules.find((t) => t.id === e);
		if (!t || !n || t.recording) return;
		let { notes: r, strokes: i } = t.takeHeard(C(n.params.length)), a = nr(b.current, n), o = uu(i) + uu(i, !0);
		!r.length && !o ? L("Nothing to capture yet. Play the keys or the wheels while the transport runs, then Capture keeps it.") : (Mr((t) => ({ patch: an($t(t.patch, e, M(Zt(t.patch, e), r, !1, [])), e, i) })), L(`Captured ${du(r.length, i)} into ${a}. Undo takes ${r.length + o === 1 ? "it" : "them"} back.`));
	}, [Mr]), gi = n((e, n) => {
		let r = T.current, i = b.current.modules.find((t) => t.id === e);
		if (!r || !i || t) return;
		let a = w(i.params.length), o = Math.max(0, r.clock);
		r.seek(o - o % a + n);
	}, [t]);
	i(() => {
		Ke.current = (e, t, n, r, i) => {
			let a = b.current.modules.find((t) => t.id === e);
			if (!a) return;
			let o = a.notes ?? [], s = M(o, t, r, n), c = uu(i) + uu(i, !0), l = an(b.current, e, i).modules.find((t) => t.id === e), u = s.length !== o.length || s.some((e, t) => e.some((e, n) => e !== o[t][n])) || B.some((e) => JSON.stringify(tn(l, e)) !== JSON.stringify(tn(a, e)));
			u && Mr((t) => ({ patch: an($t(t.patch, e, s), e, i) })), xn.current &&= {
				...xn.current,
				patch: b.current
			};
			let d = nr(b.current, a);
			L(t.length || c ? `Recorded ${du(t.length, i)} into ${d}. Undo takes the take back.` : u ? `Cleared what ${d} passed over. Undo brings it back.` : "Recording stopped. Nothing was played.");
		};
	}, [Mr]), i(() => {
		if (!e || t || ie || Mn !== null) return;
		let n = (e) => {
			let t = e.key.toLowerCase();
			t !== "r" && !(t === "backspace" && T.current?.recording) || e.repeat || e.defaultPrevented || e.metaKey || e.ctrlKey || e.altKey || (e.target instanceof Element ? e.target : null)?.closest("input, select, textarea, [contenteditable=\"true\"]") || (e.preventDefault(), t === "r" ? pi() : mi());
		};
		return window.addEventListener("keydown", n), () => window.removeEventListener("keydown", n);
	}, [
		e,
		t,
		ie,
		Mn,
		pi,
		mi
	]), i(() => {
		if (!e || t || ie || Mn !== null) {
			Zr();
			return;
		}
		function n(e) {
			if (e.defaultPrevented || e.metaKey || e.ctrlKey || e.altKey || e.target instanceof Element && e.target.closest("input, select, textarea, [contenteditable=\"true\"]")) return;
			let t = b.current.modules.find((e) => e.id === X.current), n = t?.type === "dictator" ? pn(b.current, t.id) : null, r = t && (Z[(n ?? t).type].drum?.voices.length ?? +(t.type === "noise")), i = r ? Hl.slice(0, r) : Bl, a = e.key.toLowerCase();
			if (!r && (a === "z" || a === "x")) {
				e.preventDefault(), e.repeat || Mr((e) => ({ octave: Math.min(6, Math.max(1, e.octave + (a === "x" ? 1 : -1))) }), "octave");
				return;
			}
			if ((!r || n) && S[a] !== void 0) {
				e.preventDefault(), Mr({ velocity: S[a] }, "velocity");
				return;
			}
			let o = i.indexOf(a);
			o >= 0 && (e.preventDefault(), e.repeat || oi(`key-${e.code}`, o, !1, e.timeStamp));
		}
		let r = (e) => Ur(`key-${e.code}`, !1, e.timeStamp);
		return window.addEventListener("keydown", n), window.addEventListener("keyup", r), window.addEventListener("blur", Zr), () => {
			window.removeEventListener("keydown", n), window.removeEventListener("keyup", r), window.removeEventListener("blur", Zr), Zr();
		};
	}, [
		e,
		t,
		oi,
		Ur,
		li,
		ie,
		Mn,
		Zr,
		Mr
	]), i(() => {
		Mt.current = ({ on: n, note: r, velocity: i, timeStamp: a }) => {
			let o = `midi-${r}`;
			if (Ur(o, !1, a), !n || !e || t) return;
			let s = b.current, c = s.modules.find((e) => e.id === X.current) ?? Xt(s);
			if (!Ln(c.type)) return;
			let l = c.type === "dictator" ? pn(s, c.id) : null, u = Z[(l ?? c).type].drum, d = u ? le(u.voices, r) : c.type === "noise" ? "noise" : null;
			(!u || d) && (d && (_t.current.set(o, d), gt(new Set(_t.current.values()))), u && !l ? T.current?.hit(c.id, d, o, !1, i / 127).catch(Hr) : T.current?.press(o, c.type === "noise" ? 60 : r, c.id, !1, i / 127, a).catch(Hr));
		};
	}, [
		e,
		t,
		Ur,
		Hr
	]), i(() => {
		Nt.current = ({ kind: t, value: n, timeStamp: r }) => {
			e && Qr(t, Be(t, n), n !== Pe[t].rest, r);
		};
	}, [e, Qr]);
	async function _i() {
		if (At.current) At.current(), At.current = null, kt(null), Zr(), L("MIDI input off.");
		else if (!jt.current) {
			jt.current = !0;
			try {
				let e = [], t = await Wr((e) => Mt.current(e), (t) => {
					e = t, kt(t);
				}, (e) => Nt.current(e));
				if (!Pt.current) {
					t();
					return;
				}
				At.current = t, L(e.length ? `MIDI on: ${e.join(", ")} plays the keyboard’s device.` : "MIDI on. Connect a MIDI keyboard to play the keyboard’s device.");
			} catch {
				L("MIDI access was blocked. Allow MIDI devices for this site in the browser, then turn MIDI on again.");
			} finally {
				jt.current = !1;
			}
		}
	}
	i(() => {
		if (!e || t || ie || Mn !== null) return;
		let n = (e) => {
			if (e.code !== "Space" || e.metaKey || e.ctrlKey || e.altKey) return;
			let t = e.target instanceof Element ? e.target : null;
			t?.closest(Wl) || (E.current?.contains(t) || !e.defaultPrevented && !t?.closest("button, [role=\"button\"], [role=\"slider\"], input, select, [contenteditable=\"true\"]")) && (e.preventDefault(), e.stopPropagation(), e.type === "keydown" && !e.repeat && li());
		};
		return window.addEventListener("keydown", n, !0), window.addEventListener("keyup", n, !0), () => {
			window.removeEventListener("keydown", n, !0), window.removeEventListener("keyup", n, !0);
		};
	}, [
		e,
		t,
		ie,
		Mn,
		li
	]), i(() => {
		if (!G) return;
		let e = D.current, t = e?.querySelector(`[data-module-id="${G}"]`);
		if (e && t) {
			let n = t.offsetTop - 6, r = t.offsetTop + t.offsetHeight + 6, i = matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth";
			n < e.scrollTop || r - n > e.clientHeight ? e.scrollTo({
				top: n,
				behavior: i
			}) : r > e.scrollTop + e.clientHeight && e.scrollTo({
				top: r - e.clientHeight,
				behavior: i
			});
		}
		let n = setTimeout(() => K(null), 1400);
		return () => clearTimeout(n);
	}, [G]);
	let vi = n(() => {
		Bn.current = null, cancelAnimationFrame(Vn.current), Vn.current = 0, H(null);
	}, []), yi = n(() => {
		let e = Bn.current;
		return !e?.moved || e.cancelled ? !1 : (e.cancelled = !0, cancelAnimationFrame(Vn.current), Vn.current = 0, H(null), !0);
	}, []), bi = n((e) => {
		let t = (e === "undo" ? qr : Jr)(bn.current, Ar());
		if (!t) return;
		bn.current = t.history, nn({
			undo: t.history.past.length,
			redo: t.history.future.length
		}), Bn.current && (Gn.current = !0), vi(), it(null), zt(null), tt((e) => e && t.state.patch.cables.some((t) => t.id === e) ? e : null), t.state.patch.modules.some((e) => e.id === X.current) || (Zr(), X.current = Xt(t.state.patch).id, mt(X.current)), kr(t.state);
		let n = e === "undo" ? t.history.past.length : t.history.future.length;
		L(`${e === "undo" ? "Undone" : "Redone"}. ${n} more ${n === 1 ? "step" : "steps"} to ${e}.`);
	}, [
		kr,
		Zr,
		vi,
		Ar
	]);
	i(() => {
		let t = (t) => {
			t.key !== "Escape" || t.defaultPrevented || (yi() ? (t.preventDefault(), L("Drag cancelled. Your cables are unchanged.")) : (nt || Rt || et) && (e || E.current?.contains(t.target)) && (t.preventDefault(), it(null), zt(null), tt(null), L(Rt ? "Plug back in its jack." : "Patching cancelled.")));
		}, n = () => yi();
		return window.addEventListener("keydown", t, !0), window.addEventListener("blur", n), () => {
			window.removeEventListener("keydown", t, !0), window.removeEventListener("blur", n);
		};
	}, [
		nt,
		Rt,
		et,
		e,
		yi
	]), i(() => {
		if (!et) return;
		let t = (t) => {
			if (t.key !== "Delete" && t.key !== "Backspace" || t.defaultPrevented || t.metaKey || t.ctrlKey || t.altKey) return;
			let n = t.target instanceof Element ? t.target : null;
			n?.closest("input, select, textarea, [contenteditable=\"true\"]") || !e && !E.current?.contains(n) || (t.preventDefault(), Nr((e) => iu(e, et)), tt(null), it(null), zt(null), L("Cable removed. Undo puts it back."));
		};
		return window.addEventListener("keydown", t, !0), () => window.removeEventListener("keydown", t, !0);
	}, [
		et,
		e,
		Nr
	]), i(() => {
		let n = (n) => {
			if (n.defaultPrevented || n.altKey || !(n.metaKey || n.ctrlKey) || ie || Mn !== null) return;
			let r = n.key.toLowerCase(), i = r === "z" && !n.shiftKey, a = r === "z" && n.shiftKey || r === "y" && n.ctrlKey && !n.shiftKey;
			if (!i && !a) return;
			let o = n.target instanceof Element ? n.target : null;
			(E.current?.contains(o) || e && !t && !o?.closest("input, select, textarea, [contenteditable=\"true\"]")) && (o?.closest("[data-tape-input]") || (n.preventDefault(), bi(i ? "undo" : "redo")));
		};
		return window.addEventListener("keydown", n, !0), () => window.removeEventListener("keydown", n, !0);
	}, [
		e,
		t,
		ie,
		Mn,
		bi
	]);
	let xi = n((e) => {
		try {
			let t = e($r(localStorage, lr).presets);
			if (t.length > 200) return "My Presets holds up to 200 presets. Delete or export some first.";
			let n = ei(localStorage, lr, t);
			return n || En(t), n;
		} catch {
			return Yr;
		}
	}, [lr]), Si = n((e, t) => {
		let n = xi((n) => ti(n, {
			id: e,
			savedAt: Date.now(),
			patch: t
		}));
		if (n) {
			L(n);
			return;
		}
		let r = jn.current;
		On((t) => ({
			...t,
			[r]: e
		})), Rr(t), L(`Saved “${t.name}” in this browser.`), g({ name: "patch_save" });
	}, [
		xi,
		Rr,
		g
	]), Ci = n((e) => {
		Rn.current = e ?? (document.activeElement instanceof HTMLElement ? document.activeElement : null), Nn(b.current.name);
	}, []), wi = n((e) => {
		let t = b.current;
		!fr || !t.name.trim() || ni(Cn, t.name, fr.id) ? Ci(e) : Si(fr.id, t);
	}, [
		fr,
		Cn,
		Ci,
		Si
	]);
	i(() => {
		let n = (n) => {
			if (n.defaultPrevented || n.altKey || !(n.metaKey || n.ctrlKey) || n.key.toLowerCase() !== "s") return;
			let r = n.target instanceof Element ? n.target : null, i = !!E.current?.contains(r);
			ie || Mn !== null ? i && n.preventDefault() : (i || e && !t && !r?.closest("input, select, textarea, [contenteditable=\"true\"]")) && (n.preventDefault(), n.shiftKey ? Ci() : wi());
		};
		return window.addEventListener("keydown", n, !0), () => window.removeEventListener("keydown", n, !0);
	}, [
		e,
		t,
		ie,
		Mn,
		wi,
		Ci
	]);
	function Ti(e, t, n, r = null) {
		Nr((r) => {
			let i = qt(r, e), a = i[t];
			return !a || Object.keys(n).every((e) => a[e] === n[e]) ? r : Jt(r, e, i.map((e, r) => r === t ? {
				...e,
				...n
			} : e));
		}, r && `${r}:${e}`);
	}
	function Ei(e, t) {
		Nr((n) => n.sequencer[e] === t ? n : {
			...n,
			sequencer: {
				...n.sequencer,
				[e]: t
			}
		}, e);
	}
	function Di(e, t) {
		Nr((n) => n.cables.some((n) => n.id === e && n.amount !== t) ? {
			...n,
			cables: n.cables.map((n) => n.id === e ? {
				...n,
				amount: t
			} : n)
		} : n, `depth:${e}`);
	}
	function Oi(e, t, n = null) {
		vi(), zt(null), T.current?.panic(), T.current?.restControllers(), pt((e) => e + 1), Zr();
		let r = Ht("session");
		n && On((e) => ({
			...e,
			[r]: n
		})), Mr({
			patch: e,
			mix: Wn,
			mainMuted: !1,
			session: r
		}), Rr(e), P(!1), X.current = Xt(e).id, mt(X.current), Qe(null), tt(null), it(null), L(_r ? `${t} Undo brings back your unsaved changes.` : t);
	}
	function ki() {
		vr && yr && (Bn.current && (Gn.current = !0), vi(), it(null), zt(null), Qe(null), tt((e) => e && vr.cables.some((t) => t.id === e) ? e : null), vr.modules.some((e) => e.id === X.current) || (Zr(), X.current = Xt(vr).id, mt(X.current)), T.current?.disarm(), Re(null), T.current?.restControllers(), dt(!1), pt((e) => e + 1), Mr({
			patch: vr,
			mix: Wn,
			mainMuted: !1,
			octave: cu,
			velocity: lu
		}), L(`Reverted to “${vr.name}” as ${fr ? "last saved" : "loaded"}, with every mute, solo and wheel back. Undo brings back your changes.`));
	}
	function Ai() {
		Nn(null);
		let e = Rn.current;
		Rn.current = null, e?.isConnected && e.focus();
	}
	function ji(e) {
		e !== b.current.name && Nr((t) => ({
			...t,
			name: e
		})), Si(ni(Cn, e)?.id ?? Ht("preset"), b.current), Ai();
	}
	function Mi(e) {
		let t = xi((t) => t.filter((t) => t.id !== e.id));
		L(t ?? `Deleted “${e.patch.name}” from this browser.${e.id === pr ? " The rack still has it; Save adds it back." : ""}`);
	}
	function Ni(e) {
		let t = `${ii(e.name)}.rackloose.json`;
		$l(xr(e), "application/json", t), L(`Exported ${t}. Import it in any browser to add it to My Presets.`), g({ name: "patch_export" });
	}
	function Pi(e) {
		let t = nr(v, e), n = C(e.params.length), r = v.modules.find((t) => t.id === fn(v, e.id)), i = (e.notes ?? []).filter(([e]) => e < n).map(([e, t, r, i]) => [
			e,
			Math.min(t, n - e),
			r,
			i
		]), a = Object.fromEntries(B.map((t) => [t, rt(tn(e, t), n)])), o = `${ii(v.name)}-${ii(t)}.mid`;
		$l(Lr([{
			name: r ? `${t} - ${nr(v, r)}` : t,
			notes: i,
			channel: pn(v, e.id) ? 9 : 0,
			...Object.fromEntries(B.map((e) => [Fe[e], a[e]]))
		}], v.sequencer.bpm), "audio/midi", o);
		let s = fu(a);
		L(`Exported ${o}: ${i.length} ${i.length === 1 ? "note" : "notes"}${s ? ` with ${s}` : ""} at ${v.sequencer.bpm} BPM.`);
	}
	async function Fi(e, t) {
		try {
			if (t.size > 1e6) throw Error("MIDI files must be smaller than 1 MB.");
			let n = zr(new Uint8Array(await t.arrayBuffer()));
			if (!n.tracks.length) {
				Tt(null), L(`${t.name} has no notes to import.`);
				return;
			}
			n.tracks.length === 1 ? Ii(e, t.name, n.tracks) : Tt({
				id: e,
				file: t.name,
				song: n
			});
		} catch (e) {
			Hr(e);
		}
	}
	function Ii(e, t, n) {
		Tt(null);
		let r = b.current.modules.find((t) => t.id === e);
		if (!r) return;
		let i = Object.fromEntries(B.map((e) => [Fe[e], n.find((t) => t[Fe[e]]?.length)?.[Fe[e]]])), a = Br(n.flatMap((e) => e.notes), Qt(b.current, e), i), o = nr(b.current, r);
		Nr((t) => {
			let n = $t({
				...t,
				modules: t.modules.map((t) => t.id === e ? {
					...t,
					params: {
						...t.params,
						length: a.length
					}
				} : t)
			}, e, a.notes);
			return B.reduce((t, n) => rn(t, e, n, a.lanes[n]), n);
		});
		let s = a.dropped ? ` ${a.dropped} ${a.dropped === 1 ? "note was" : "notes were"} left out: past 16 bars, repeated, or over the note limit.` : "", c = fu(a.lanes);
		L(`Imported ${a.notes.length} ${a.notes.length === 1 ? "note" : "notes"}${c ? ` with ${c}` : ""} from ${t} into ${o}, ${_[a.length]} ${a.length ? "bars" : "bar"} long.${s} Undo puts the clip back.`);
	}
	function Li(e) {
		g({
			name: "module_add",
			module_type: e
		});
		let t = Gt(e), n = b.current.modules.find((e) => e.id === X.current && Ml(e)), r = n && (un(n.type) ? ["trig"] : ["pitch", "gate"]).every((e) => !vn(b.current, {
			moduleId: n.id,
			portId: e
		}));
		Nr((i) => {
			let a = Yt(i, [
				...i.modules.slice(0, -1),
				t,
				i.modules.at(-1)
			]);
			return e === "dictator" && r ? dn(a, t.id, n.id) : a;
		});
		let i = e !== "dictator" && Fn({
			...b.current,
			modules: [...b.current.modules, t]
		}, t);
		di(t), re(!1), K(t.id), L(`${Z[e].name} added${i ? " with a starter pattern. CLEAR empties it; flip" : ". Flip"} the rack to connect it.`);
	}
	function Ri(e) {
		let t = {
			...e,
			id: Ht(),
			params: { ...e.params },
			...e.type === "performance" ? { steps: qt(b.current, e.id) } : {}
		};
		Nr((n) => {
			let r = [...n.modules];
			r.splice(r.findIndex((t) => t.id === e.id) + 1, 0, t);
			let i = t.notes ? $t(Yt(n, r), t.id, t.notes) : Yt(n, r);
			return B.reduce((e, n) => tn(t, n).length ? rn(e, t.id, n, tn(t, n)) : e, i);
		}), di(t), K(t.id), L(`${Z[e.type].name} duplicated without its cables.`);
	}
	function zi(e) {
		if (e.key === "Tab") {
			let t = e.currentTarget.querySelectorAll("button");
			t.length === 1 && (e.preventDefault(), t[0].focus());
		}
	}
	function Bi() {
		ce(null), (ie === "about" ? te : k).current?.focus();
	}
	function Vi(e, t, n = null) {
		try {
			let r = Un(b.current, e, t, n);
			if (it(null), zt(null), r === b.current) {
				L("Plug back in its jack.");
				return;
			}
			Mr({ patch: r }), L(n ? "Cable moved." : "Connected. Flip to the front to hear your patch.");
		} catch (e) {
			Hr(e);
		}
	}
	function Hi(e) {
		Nr((t) => iu(t, e)), tt(null), zt(null), L("Cable unplugged. Undo puts it back.");
	}
	function Ui(e) {
		if (Gn.current) {
			Gn.current = !1;
			return;
		}
		let t = vn(b.current, e);
		if (Rt) {
			t?.id === Rt.cableId && !gn(e, Rt.anchor) ? (zt(null), L("Plug back in its jack.")) : Vi(Rt.anchor, e, Rt.cableId);
			return;
		}
		if (nt && gn(nt, e)) {
			it(null), L("Patching cancelled.");
			return;
		}
		if (nt) {
			Vi(nt, e);
			return;
		}
		if (t) {
			zt({
				cableId: t.id,
				anchor: ru(t, e)
			}), tt(t.id), L("Plug lifted. Choose a free jack, or tap empty rack space to unplug. Tap the jack again or press Escape to put it back.");
			return;
		}
		let n = hn(b.current, e);
		n && (it(e), tt(null), L(`Choose a free ${n.kind.toUpperCase()} ${n.direction === "out" ? "input" : "output"}. Escape cancels.`));
	}
	function Wi(e) {
		A && !e.target.closest("button, [role=\"button\"], [role=\"slider\"], input, select, label, a") && (Rt ? Hi(Rt.cableId) : nt ? (it(null), L("Patching cancelled.")) : tt(null));
	}
	function Gi(e) {
		let t = D.current;
		if (!t) return null;
		let n = t.getBoundingClientRect(), r = e.clientX >= n.left && e.clientX <= n.right && e.clientY >= n.top && e.clientY <= n.bottom, i = null, a = Gl;
		r && t.querySelectorAll("[data-port-key]").forEach((t) => {
			let r = t.getBoundingClientRect(), o = r.left + r.width / 2, s = r.top + r.height / 2, c = e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom ? -1 : Math.hypot(o - e.clientX, s - e.clientY);
			c >= a || s < n.top || s > n.bottom || (i = eu(t), a = c);
		});
		let o = !!i && gn(i, e.anchor), s = i && !o ? Sn(b.current, e.anchor, i, e.cableId) : null;
		return {
			anchor: e.anchor,
			cableId: e.cableId,
			target: s || o ? null : i,
			candidate: i,
			error: s,
			inside: r,
			point: {
				x: e.clientX - n.left + t.scrollLeft,
				y: e.clientY - n.top + t.scrollTop
			}
		};
	}
	function Ki() {
		let e = Bn.current, t = D.current;
		if (!e?.moved || e.cancelled || !t) {
			Vn.current = 0;
			return;
		}
		let n = t.getBoundingClientRect(), r = n.top + Kl - e.clientY, i = e.clientY - (n.bottom - Kl);
		r > 0 ? t.scrollTop -= Math.ceil(Math.min(r, Kl) / 3) : i > 0 && (t.scrollTop += Math.ceil(Math.min(i, Kl) / 3));
		let a = Gi(e);
		H((e) => e && a && nu(e, a) ? e : a), Vn.current = requestAnimationFrame(Ki);
	}
	function qi(e, t) {
		if (!e.isPrimary || e.button !== 0) return;
		e.stopPropagation(), Gn.current = !1;
		let n = vn(b.current, t);
		Bn.current = {
			pointerId: e.pointerId,
			anchor: n ? ru(n, t) : t,
			cableId: n?.id ?? null,
			x: e.clientX,
			y: e.clientY,
			clientX: e.clientX,
			clientY: e.clientY,
			moved: !1,
			cancelled: !1
		}, e.currentTarget.setPointerCapture(e.pointerId);
	}
	function Ji(e) {
		let t = Bn.current;
		if (t && t.pointerId === e.pointerId && !t.cancelled) {
			if (t.clientX = e.clientX, t.clientY = e.clientY, !t.moved) {
				if (Math.hypot(e.clientX - t.x, e.clientY - t.y) <= 5) return;
				t.moved = !0, it(null), zt(null), tt(t.cableId), L(t.cableId ? "Plug pulled out. Drop it on a free jack, or on empty rack space to unplug. Escape puts it back." : "Drop the plug on a free highlighted jack. Escape cancels.");
			}
			Vn.current ||= requestAnimationFrame(Ki);
		}
	}
	function Yi(e, t = !1) {
		let n = Bn.current;
		if (!n || n.pointerId !== e.pointerId) return;
		t || (n.clientX = e.clientX, n.clientY = e.clientY), n.moved ||= Math.hypot(n.clientX - n.x, n.clientY - n.y) > 5;
		let r = Gi(n);
		vi(), (n.moved || n.cancelled) && (Gn.current = !0), n.moved && !n.cancelled && (r?.error ? L(`${r.error}${n.cableId ? " The plug went back in its jack." : ""}`) : r?.target ? (Vi(n.anchor, r.target, n.cableId), n.cableId && tt(n.cableId)) : n.cableId && r?.inside && !r.candidate ? Hi(n.cableId) : L(n.cableId ? "Plug back in its jack." : "Connection cancelled. Your cables are unchanged."));
	}
	function Xi() {
		Bn.current && (Gn.current = !0, vi());
	}
	function Zi(e) {
		let t = Rt?.anchor ?? nt;
		t && !Bn.current && e.pointerType === "mouse" && (qn.current = {
			anchor: t,
			cableId: Rt?.cableId ?? null,
			clientX: e.clientX,
			clientY: e.clientY
		}, Yn.current ||= requestAnimationFrame(() => {
			Yn.current = 0;
			let e = qn.current && Gi(qn.current);
			W((t) => t && e && nu(t, e) ? t : e);
		}));
	}
	async function Qi(e) {
		if (e) {
			try {
				if (e.size > 1e6) throw Error("Patch files must be smaller than 1 MB.");
				let t = await e.text(), n = Cr(t);
				g({ name: "patch_import" });
				let r = n.cables.length;
				try {
					let e = JSON.parse(t);
					Array.isArray(e.cables) && (r = e.cables.length);
				} catch {}
				let i = r - n.cables.length, a = i > 0 ? ` ${i} ${i === 1 ? "cable shared a jack" : "cables shared jacks"} with no spare left, so ${i === 1 ? "it was" : "they were"} left out.` : "", o = n.name.trim() ? n.name : "Imported patch", s = ni(Cn, o);
				if (s && Sr(s.patch) === Sr({
					...n,
					name: s.patch.name
				})) Oi(s.patch, `“${s.patch.name}” is already in My Presets, so it opened.${a}`, s.id);
				else {
					let e = {
						id: Ht("preset"),
						savedAt: Date.now(),
						patch: {
							...n,
							name: s ? ri(Cn, o) : o
						}
					}, t = xi((t) => ti(t, e));
					Oi(e.patch, t ? `Opened “${e.patch.name}”. ${t}${a}` : `Imported “${e.patch.name}” into My Presets.${s ? ` You already had a different “${s.patch.name}”.` : ""}${a}`, t ? null : e.id);
				}
			} catch (e) {
				Hr(e);
			}
			O.current && (O.current.value = "");
		}
	}
	async function $i() {
		ct(!0), L("Rendering your patch…");
		try {
			$l(fo(await uo(v, at, J)), "audio/wav", `${ii(v.name)}.wav`), L("WAV exported. Your loop includes a two-second effects tail."), g({
				name: "wav_export",
				loops: at
			});
		} catch (e) {
			Hr(e);
		} finally {
			ct(!1);
		}
	}
	let ea = v.cables.find((e) => e.id === et), ta = Rt?.anchor ?? nt, na = Rt?.cableId ?? null, ra = V ?? (A && ta && U && gn(U.anchor, ta) && U.cableId === na ? U : null);
	function ia(e) {
		K(e), D.current?.querySelector(`[data-module-id="${e}"] .${Q.moduleNameButton}`)?.focus({ preventScroll: !0 });
	}
	let aa = V?.anchor ?? ta, oa = V ? V.cableId : na, sa = ra?.cableId ?? null;
	function ca(e, t, n) {
		let r = Z[e.type], i = {
			moduleId: e.id,
			portId: t.id
		}, a = !!aa && gn(aa, i), o = vn(v, i), s = !!o && (o.id !== sa || a), c = t.direction === "in" ? "input" : "output", l = e.type === "mixer" && t.direction === "in" ? or(v, e.id, t.id) : null, u = l ? `Channel ${t.id.toUpperCase()}: ${l.source}` : t.label;
		return /* @__PURE__ */ m("button", {
			className: Q.socket,
			"data-port-key": `${e.id}:${t.id}`,
			"data-kind": t.kind,
			"data-jack": n ?? void 0,
			"data-connected": s,
			"data-compatible": !!aa && !a && !Sn(v, aa, i, oa),
			"data-pending": a,
			"data-lifted": !!Rt && o?.id === Rt.cableId && !a,
			"data-target": !!ra?.target && gn(ra.target, i),
			"data-selected-end": !!ea && ea.id !== sa && (gn(ea.from, i) || gn(ea.to, i)),
			"aria-label": `${r.name} ${u} ${c}${n && n > 1 ? ` ${n}` : ""}`,
			"aria-description": `${t.kind.toUpperCase()} ${c}${l?.tooltip ? ` · ${l.tooltip}` : ""}`,
			title: `${u}${l?.tooltip ? ` · ${l.tooltip}` : ""}${n ? ` · jack ${n}` : ""} · ${t.kind.toUpperCase()}${o ? " · plugged" : ""}`,
			onClick: () => Ui(i),
			onPointerDown: (e) => qi(e, i),
			onPointerMove: Ji,
			onPointerUp: (e) => Yi(e),
			onPointerCancel: Xi,
			onLostPointerCapture: (e) => Yi(e, !0),
			children: /* @__PURE__ */ m("span", {})
		}, t.id);
	}
	function la(e) {
		let t = Z[e.type];
		return /* @__PURE__ */ m("div", {
			className: Q.portGroups,
			children: ["in", "out"].filter((e) => t.ports.some((t) => t.direction === e)).map((n) => {
				let r = t.ports.filter((e) => e.direction === n);
				return /* @__PURE__ */ h("div", {
					className: Q.portGroup,
					"data-direction": n,
					children: [/* @__PURE__ */ m("span", {
						className: Q.portHeading,
						children: n === "in" ? "INPUTS" : "OUTPUTS"
					}), /* @__PURE__ */ m("div", {
						className: Q.portRow,
						children: r.filter((e) => !e.copyOf).map((i) => {
							let a = r.filter((e) => e === i || e.copyOf === i.id), o = n === "in" && i.kind === "cv", s = o ? v.cables.find((t) => gn(t.to, {
								moduleId: e.id,
								portId: i.id
							})) : void 0, c = e.type === "mixer" && n === "in" ? or(v, e.id, i.id) : null;
							return /* @__PURE__ */ h("div", {
								className: Q.socketControl,
								"data-source": !!c,
								"data-trim": o,
								"data-jacks": a.length,
								"data-analytics-private": c?.named ? "" : void 0,
								children: [
									a.length > 1 ? /* @__PURE__ */ m("div", {
										className: Q.jacks,
										children: a.map((n) => ca(e, n, _n(t.ports, n)))
									}) : ca(e, i, null),
									o && /* @__PURE__ */ m(ho, {
										trim: !0,
										param: ql,
										value: s?.amount ?? ql.initial,
										format: Jl,
										prefix: `${t.name} ${i.label}`,
										disabled: !s,
										onChange: (e) => {
											s && Di(s.id, e);
										}
									}),
									/* @__PURE__ */ m("span", {
										title: c?.tooltip || void 0,
										children: c?.source ?? i.label
									}),
									(n !== "in" || i.kind !== "audio") && /* @__PURE__ */ h("small", { children: [i.kind.toUpperCase(), s && ` · ${Jl(s.amount)}`] })
								]
							}, i.id);
						})
					})]
				}, n);
			})
		});
	}
	function ua(e) {
		let t = vt[e.id];
		return Z[e.type].drum?.voices.some((e) => e.id === t) ? t : void 0;
	}
	function da(e, t, n) {
		return t.choices ? /* @__PURE__ */ h("label", {
			className: Q.selectControl,
			title: t.hint,
			children: [
				/* @__PURE__ */ m("span", {
					className: Q.controlLabel,
					children: t.label
				}),
				/* @__PURE__ */ m("select", {
					"aria-label": `${n} ${t.label}`,
					value: e.params[t.id],
					onChange: (n) => Pr(e.id, { [t.id]: Number(n.target.value) }),
					children: t.choices.map((e, t) => /* @__PURE__ */ m("option", {
						value: t,
						children: e
					}, e))
				}),
				/* @__PURE__ */ m(Uo, {
					param: t,
					value: e.params[t.id]
				})
			]
		}, t.id) : /* @__PURE__ */ m(ho, {
			param: t,
			prefix: n,
			value: e.params[t.id],
			onChange: (n) => Pr(e.id, { [t.id]: n })
		}, t.id);
	}
	function fa(e) {
		let t = Xl[e.type];
		return t ? /* @__PURE__ */ m(t, {
			module: e,
			onParams: (t) => Pr(e.id, t)
		}) : null;
	}
	function pa(e) {
		let t = Z[e.type], n = [...new Set(t.params.filter((e) => e.group && !e.voice).map((e) => e.group))];
		if (!n.length) return null;
		let r = (e) => t.params.filter((t) => t.group === e && !st.includes(t.id));
		return /* @__PURE__ */ m("div", {
			className: Q.groupControls,
			"data-type": e.type,
			children: n.map((n) => /* @__PURE__ */ h("fieldset", {
				"data-group": n,
				children: [/* @__PURE__ */ m("legend", { children: n }), e.type === "drawbar" && n === "Drawbars" ? /* @__PURE__ */ m(hs, {
					params: r(n),
					values: e.params,
					prefix: `${t.name} ${n}`,
					onChange: (t, n) => Pr(e.id, { [t]: n })
				}) : /* @__PURE__ */ m("div", {
					className: Q.controls,
					children: r(n).map((r) => da(e, r, `${t.name} ${n}`))
				})]
			}, n))
		});
	}
	function ma(e) {
		let t = Z[e.type];
		return /* @__PURE__ */ m("div", {
			className: Q.controls,
			children: t.params.filter((e) => !e.voice && !e.group && !st.includes(e.id)).map((n) => da(e, n, t.name))
		});
	}
	function ha(e) {
		return tr(v, e);
	}
	function ga(e, t) {
		Nr((n) => ir(n, e.id, t)), e.label && !rr(t) && L("Name removed. Undo brings it back.");
	}
	function _a(e) {
		let n = !!It[e.id]?.playing;
		return /* @__PURE__ */ h("button", {
			className: Q.playButton,
			disabled: t,
			"aria-label": `${n ? "Stop" : "Play"} ${ha(e)} sequencer`,
			"data-playing": n,
			onClick: () => {
				T.current?.modulePlaying(e.id) ? T.current.stopModule(e.id) : T.current?.play(e.id).catch(Hr);
			},
			children: [/* @__PURE__ */ m(Zo, { name: n ? "stop" : "play" }), /* @__PURE__ */ m("span", { children: n ? "STOP" : "PLAY" })]
		});
	}
	function va(e) {
		let n = ha(e), r = e.type === "performance" ? "steps" : "hits";
		return /* @__PURE__ */ m("button", {
			className: Q.clearPatternButton,
			disabled: t || !Fn(v, e),
			"aria-label": `Clear ${n} pattern`,
			title: `Clear every ${e.type === "performance" ? "step" : "hit"} in the pattern. Undo brings them back.`,
			onClick: () => {
				Nr((t) => In(t, e.id)), L(`${nr(v, e)} cleared. Undo brings its ${r} back.`);
			},
			children: /* @__PURE__ */ m("span", { children: "CLEAR" })
		});
	}
	let ya = ge && Me === null && !t && v.modules.some((e) => zn(e.type) && !It[e.id]?.playing), ba = v.modules.find((e) => e.id === Y) ?? Xt(v), xa = Z[ba.type], Sa = ba.type === "dictator" ? pn(v, ba.id) : null, Ca = Z[(Sa ?? ba).type], wa = Ca.drum?.voices ?? (ba.type === "noise" ? [{
		id: "noise",
		label: "Noise"
	}] : null), Ta = wa ? [] : ln(v, ba.id), Ea = Ta.includes("bend"), Da = Ta.filter((e) => Ne(e) || e === "mod" && !Ea), Oa = (e) => {
		xa.drum && !t && si(ba.id, e);
	}, ka = wa && wa.length > 6 ? Math.ceil(wa.length / 2) : 6, Aa = Hn(v, ba.id) ? null : `${xa.name} needs an audio path to MAIN. Flip the rack to connect it.`;
	function ja(e) {
		let n = ha(e), r = Z.dictator, i = Le === e.id, a = C(e.params.length), o = x[e.params.quantize]?.[1] ?? 240;
		return /* @__PURE__ */ m(Fl, {
			module: e,
			patch: v,
			name: n,
			clock: ge ? It[e.id]?.clock ?? -1 : Se,
			take: We?.id === e.id ? We.notes : null,
			onSeek: (t) => gi(e.id, t),
			armed: i,
			recording: ze,
			disabled: t,
			offset: Tr,
			onOffset: Dr,
			onCapture: () => hi(e.id),
			onDiscard: mi,
			transport: _a(e),
			control: (t) => da(e, r.params.find((e) => e.id === t), n),
			onParam: (t, n) => Pr(e.id, { [t]: n }),
			plays: fn(v, e.id),
			editing: St === e.id,
			grid: o,
			onEditing: (t) => {
				Ct(t ? e.id : null), t && di(e);
			},
			onNotes: (t, n) => Nr((n) => $t(n, e.id, t), n ? `${e.id}:${n}` : null),
			onWheels: (t, n) => {
				Nr((r) => rn(r, e.id, t, n)), n.length || L(`${nr(v, e)}'s ${t === "bend" ? "PITCH" : "MOD"} lane cleared. Undo brings it back.`);
			},
			importing: wt?.id === e.id ? {
				file: wt.file,
				tracks: wt.song.tracks
			} : null,
			onExportMidi: () => Pi(e),
			onImportMidi: (t) => void Fi(e.id, t),
			onImportTracks: (t) => {
				wt && Ii(e.id, wt.file, t === null ? wt.song.tracks : [wt.song.tracks[t]]);
			},
			onImportCancel: () => Tt(null),
			onAudition: (n, r, i) => {
				t || ze || i && !T.current?.ready || T.current?.audition(n, e.id, r / 127).catch(Hr);
			},
			onAuditionEnd: () => T.current?.endAudition(),
			onArm: () => {
				i ? (ze && T.current?.finishTake(), fi(null)) : fi(e.id);
			},
			onPlays: (t) => {
				let n = v.modules.find((e) => e.id === t);
				if (n) try {
					Nr((n) => dn(n, e.id, t)), L(`${nr(v, e)} plays ${nr(v, n)}. Undo puts the cables back as they were.`);
				} catch (e) {
					Hr(e);
				}
			},
			onClear: () => {
				Nr((t) => In(t, e.id)), L(`${nr(v, e)} cleared. Undo brings its ${e.notes?.length ? "notes" : "wheel moves"} back.`);
			},
			onQuantize: (t) => {
				t || Nr((t) => $t(t, e.id, ee(e.notes ?? [], o, 1, a))), L(`${t ? `${t} selected ${t === 1 ? "note" : "notes"}` : `${n}'s notes`} moved onto the ${x[e.params.quantize]?.[0] ?? "1/16"} grid. Undo moves them back.`);
			}
		});
	}
	function Ma(e = !1) {
		e && Ze && $e.current.get(Ze.moduleId)?.focus(), Qe(null);
	}
	function Na(e) {
		let t = qt(v, e.id), n = It[e.id]?.clock ?? -1, r = n < 0 ? -1 : n % 16, i = ha(e), a = i !== Z[e.type].name, o = Ze?.moduleId === e.id, s = o ? Ze.index : null, c = s === null ? null : t[s];
		return /* @__PURE__ */ h("div", {
			className: Q.sequenceBody,
			"data-editing": o,
			children: [
				/* @__PURE__ */ h("div", {
					className: Q.sequenceTop,
					children: [
						/* @__PURE__ */ h("div", {
							className: Q.lcdStack,
							children: [/* @__PURE__ */ h("div", {
								className: Q.lcd,
								children: [
									/* @__PURE__ */ m("small", { children: "SEQUENCER" }),
									/* @__PURE__ */ h("strong", { children: [r >= 0 ? String(r + 1).padStart(2, "0") : "16", /* @__PURE__ */ m("span", { children: "STEPS" })] }),
									/* @__PURE__ */ m("span", {
										className: Q.lcdDots,
										"aria-hidden": "true"
									})
								]
							}), /* @__PURE__ */ m("span", {
								className: Q.transportCaption,
								children: "16TH NOTE / MONO"
							})]
						}),
						Z.performance.params.map((t) => da(e, t, i)),
						/* @__PURE__ */ h("div", {
							className: `${Q.transport} ${Q.stepTransport}`,
							children: [_a(e), /* @__PURE__ */ h("div", {
								className: Q.transportKeys,
								children: [va(e), /* @__PURE__ */ m("button", {
									ref: (t) => {
										t ? $e.current.set(e.id, t) : $e.current.delete(e.id);
									},
									className: Q.stepEditButton,
									"aria-pressed": o,
									"aria-label": `Edit ${i} steps`,
									title: "Pick a step to set its note, velocity and gate. Turn EDIT off to switch steps on and off again.",
									onClick: () => Qe(o ? null : {
										moduleId: e.id,
										index: null
									}),
									children: "EDIT"
								})]
							})]
						})
					]
				}),
				/* @__PURE__ */ m("div", {
					className: Q.steps,
					role: "group",
					"aria-label": `${i} steps`,
					children: t.map((t, n) => /* @__PURE__ */ h("div", {
						className: Q.stepCell,
						children: [/* @__PURE__ */ h("button", {
							className: Q.step,
							"data-enabled": t.enabled,
							"data-silent": !$n(e.id, n, J),
							"data-current": r === n,
							"data-editing": s === n,
							"aria-label": `Step ${n + 1}: ${t.enabled ? Or(t.note) : "rest"}`,
							"aria-pressed": o ? s === n : t.enabled,
							onClick: () => {
								o ? Qe({
									moduleId: e.id,
									index: n
								}) : Ti(e.id, n, { enabled: !t.enabled });
							},
							children: [
								/* @__PURE__ */ m("span", { className: Q.stepLed }),
								/* @__PURE__ */ m("span", {
									className: Q.stepNumber,
									children: String(n + 1).padStart(2, "0")
								}),
								/* @__PURE__ */ m("strong", { children: t.enabled || o ? Or(t.note) : "—" })
							]
						}), /* @__PURE__ */ m(Qo, {
							mixKey: Kn(e.id, n),
							label: a ? `${i} step ${n + 1}` : `step ${n + 1}`,
							mix: J,
							onToggle: Fr
						})]
					}, n))
				}),
				s !== null && c && /* @__PURE__ */ h("div", {
					className: Q.stepEditor,
					children: [
						/* @__PURE__ */ h("strong", { children: ["STEP ", String(s + 1).padStart(2, "0")] }),
						/* @__PURE__ */ h("label", { children: [/* @__PURE__ */ m("input", {
							type: "checkbox",
							checked: c.enabled,
							onChange: (t) => Ti(e.id, s, { enabled: t.target.checked })
						}), "Note on"] }),
						/* @__PURE__ */ h("label", { children: ["Note", /* @__PURE__ */ m("select", {
							"aria-label": "Step note",
							value: c.note,
							onChange: (t) => Ti(e.id, s, { note: Number(t.target.value) }),
							children: Array.from({ length: 73 }, (e, t) => t + 24).map((e) => /* @__PURE__ */ m("option", {
								value: e,
								children: Or(e)
							}, e))
						})] }),
						/* @__PURE__ */ h("label", { children: [
							"Velocity",
							/* @__PURE__ */ m("input", {
								"aria-label": "Step velocity",
								type: "range",
								min: 0,
								max: 1,
								step: .01,
								value: c.velocity,
								onChange: (t) => Ti(e.id, s, { velocity: Number(t.target.value) }, `step:${s}:velocity`)
							}),
							/* @__PURE__ */ h("output", { children: [Math.round(c.velocity * 100), "%"] })
						] }),
						/* @__PURE__ */ h("label", { children: [
							"Gate",
							/* @__PURE__ */ m("input", {
								"aria-label": "Step gate",
								type: "range",
								min: .1,
								max: .95,
								step: .01,
								value: c.gate,
								onChange: (t) => Ti(e.id, s, { gate: Number(t.target.value) }, `step:${s}:gate`)
							}),
							/* @__PURE__ */ h("output", { children: [Math.round(c.gate * 100), "%"] })
						] }),
						/* @__PURE__ */ m("button", {
							onClick: () => Ma(!0),
							"aria-label": "Close step editor",
							children: "×"
						})
					]
				}),
				/* @__PURE__ */ h("div", {
					className: Q.sequenceHint,
					children: [o ? "Click a step to edit it. Turn EDIT off to switch steps on and off." : "Click a step to switch it on or off. EDIT sets its note, velocity & gate.", /* @__PURE__ */ m("span", { children: "PATCHABLE PITCH + GATE" })]
				})
			]
		});
	}
	let Pa = Xn(v, J), Fa = ai(_r, I), Ia = mn(v), La = /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("img", {
		className: Q.brandMark,
		src: Rl,
		width: "48",
		height: "48",
		alt: ""
	}), /* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("strong", { children: "Rackloose" }), /* @__PURE__ */ m("small", { children: "MODULAR SYNTHESIZER" })] })] }), Ra = ra || nt || Rt ? oa ? "Drop the plug on a free highlighted jack, or on empty rack space to unplug. Escape puts it back." : "Choose a free highlighted jack. Escape cancels." : ea ? "Drag either plug to move it. Delete unplugs this cable." : "One cable per jack. Drag from a jack to patch; drag a plug to move or unplug it.";
	return /* @__PURE__ */ m(Dc.Provider, {
		value: De,
		children: /* @__PURE__ */ h("section", {
			ref: E,
			className: Q.app,
			"aria-label": "Rackloose modular synthesizer",
			onKeyDown: (e) => {
				e.key !== "Escape" || e.defaultPrevented || (ie ? Bi() : Mn === null ? ue ? (P(!1), Pn.current?.focus()) : N ? (re(!1), ne.current?.focus()) : nt || et || Rt ? (it(null), tt(null), zt(null), L(Rt ? "Plug back in its jack." : "Patching cancelled.")) : Ze && Ma(!0) : Ai());
			},
			children: [
				/* @__PURE__ */ h("header", {
					className: Q.toolbar,
					children: [o ? /* @__PURE__ */ m("a", {
						className: Q.brand,
						href: "https://www.rackloose.com/",
						target: "_blank",
						rel: "noopener noreferrer",
						title: "Open Rackloose in a new tab",
						children: La
					}) : /* @__PURE__ */ m("div", {
						className: Q.brand,
						children: La
					}), /* @__PURE__ */ h("div", {
						className: Q.toolbarActions,
						children: [
							/* @__PURE__ */ h("button", {
								className: Q.audioButton,
								"data-ready": ve,
								disabled: t,
								onClick: () => {
									ve ? (T.current?.panic(), L("Audio stopped.")) : T.current?.unlock().then(() => L("Audio enabled. Play A–K, tap a key, or start the pattern.")).catch(Hr);
								},
								children: [/* @__PURE__ */ m("span", { className: Q.statusLed }), ve ? "Audio on" : "Enable audio"]
							}),
							/* @__PURE__ */ m("button", {
								onClick: () => {
									T.current?.panic(), L("Panic: all sound and pending notes cleared.");
								},
								title: "Immediately silence all sound",
								children: "Panic"
							}),
							/* @__PURE__ */ m("button", {
								ref: k,
								onClick: () => {
									g({ name: "guide_open" }), ce("guide");
								},
								"aria-label": "Open user guide",
								title: "User guide",
								children: "?"
							})
						]
					})]
				}),
				/* @__PURE__ */ m("div", {
					className: Q.patchBar,
					children: /* @__PURE__ */ h("div", {
						className: Q.patchRow,
						children: [
							/* @__PURE__ */ h("div", {
								className: Q.patchIdentity,
								children: [/* @__PURE__ */ h("label", {
									className: Q.patchName,
									"data-analytics-private": "",
									children: [/* @__PURE__ */ m("span", { children: "PATCH" }), /* @__PURE__ */ h("span", {
										className: Q.nameField,
										"data-value": v.name,
										children: [/* @__PURE__ */ m("input", {
											"aria-label": "Patch name",
											"aria-describedby": _r ? ar : void 0,
											maxLength: 100,
											size: 1,
											value: v.name,
											onChange: (e) => {
												let t = e.target.value;
												Nr((e) => e.name === t ? e : {
													...e,
													name: t
												}, "name");
											}
										}), _r && /* @__PURE__ */ h("span", {
											id: ar,
											className: Q.dirtyMark,
											title: "Unsaved changes",
											children: [/* @__PURE__ */ m("span", {
												"aria-hidden": "true",
												children: "*"
											}), /* @__PURE__ */ m("span", {
												className: Q.visuallyHidden,
												children: "Unsaved changes"
											})]
										})]
									})]
								}), /* @__PURE__ */ m("span", {
									className: Q.saveStatus,
									"data-save-status": !0,
									"data-state": Fa.state,
									"aria-live": "polite",
									title: Fa.detail || void 0,
									children: Fa.text && /* @__PURE__ */ h(p, { children: [
										/* @__PURE__ */ m("span", {
											className: Q.saveLed,
											"aria-hidden": "true"
										}),
										/* @__PURE__ */ m("span", { children: Fa.text }),
										Fa.state === "failed" && /* @__PURE__ */ m("span", {
											className: Q.visuallyHidden,
											children: Fa.detail
										})
									] })
								})]
							}),
							/* @__PURE__ */ h("span", {
								className: Q.barGroup,
								role: "group",
								"aria-label": "Save and presets",
								children: [/* @__PURE__ */ m("button", {
									"aria-label": "Save to My Presets",
									title: "Save to My Presets in this browser (⌘S / Ctrl+S)",
									onClick: (e) => wi(e.currentTarget),
									children: "Save"
								}), /* @__PURE__ */ m("button", {
									ref: Pn,
									className: Q.presetsButton,
									"aria-expanded": ue,
									onClick: () => {
										P(!ue), re(!1);
									},
									children: "Presets"
								})]
							}),
							/* @__PURE__ */ h("span", {
								className: `${Q.barGroup} ${Q.exportControls}`,
								role: "group",
								"aria-label": "Export audio",
								children: [/* @__PURE__ */ m("select", {
									"aria-label": "Export loop count",
									title: "Loops to render",
									value: at,
									onChange: (e) => q(Number(e.target.value)),
									children: [
										1,
										2,
										4,
										8
									].map((e) => /* @__PURE__ */ h("option", {
										value: e,
										children: [
											e,
											" ",
											e === 1 ? "loop" : "loops"
										]
									}, e))
								}), /* @__PURE__ */ m("button", {
									disabled: ot,
									"aria-busy": ot,
									title: "Render every sequencer to a WAV file",
									onClick: () => void $i(),
									children: ot ? "Rendering…" : "↓ Export WAV"
								})]
							}),
							/* @__PURE__ */ m("input", {
								ref: O,
								type: "file",
								accept: ".json,application/json",
								hidden: !0,
								"aria-label": "Import patch file",
								onChange: (e) => void Qi(e.target.files?.[0])
							}),
							/* @__PURE__ */ h("div", {
								className: Q.rackActions,
								children: [/* @__PURE__ */ h("span", {
									className: `${Q.barGroup} ${Q.historyActions}`,
									role: "group",
									"aria-label": "Edit history",
									children: [
										/* @__PURE__ */ m("button", {
											"aria-label": "Undo",
											title: "Undo (⌘Z / Ctrl+Z)",
											disabled: !en.undo,
											onClick: () => bi("undo"),
											children: /* @__PURE__ */ m(Zo, { name: "undo" })
										}),
										/* @__PURE__ */ m("button", {
											"aria-label": "Redo",
											title: "Redo (⇧⌘Z / Ctrl+Y)",
											disabled: !en.redo,
											onClick: () => bi("redo"),
											children: /* @__PURE__ */ m(Zo, { name: "redo" })
										}),
										/* @__PURE__ */ m("button", {
											className: Q.dangerButton,
											title: `Revert to the patch as ${fr ? "last saved" : "loaded"}, clearing every mute and solo and resetting the keys and wheels`,
											disabled: !yr,
											onClick: ki,
											children: "Revert"
										})
									]
								}), /* @__PURE__ */ h("span", {
									className: Q.barGroup,
									role: "group",
									"aria-label": "Rack",
									children: [/* @__PURE__ */ m("button", {
										ref: ne,
										className: Q.addButton,
										"aria-expanded": N,
										onClick: () => {
											re(!N), P(!1);
										},
										children: "＋ Add device"
									}), /* @__PURE__ */ h("button", {
										className: Q.flipButton,
										"aria-label": A ? "Show front" : "Flip rack",
										"aria-pressed": A,
										onClick: () => {
											vi(), j(!A), it(null), tt(null), zt(null), L(A ? "Front panel. Turn a knob and make it yours." : "Rear panel. Drag from one jack to another, or tap one then the other.");
										},
										children: ["⇄ ", A ? "Show front" : "Flip rack"]
									})]
								})]
							})
						]
					})
				}),
				ue && /* @__PURE__ */ m(wc, {
					presets: Cn,
					openId: pr,
					dirty: _r,
					onSaveAs: Ci,
					onImport: () => O.current?.click(),
					onExportCurrent: () => Ni(v),
					onExport: Ni,
					onDelete: Mi,
					onLoad: (e) => {
						g({
							name: "preset_load",
							source: "user"
						}), Oi(e.patch, `Loaded “${e.patch.name}” from My Presets.`, e.id);
					},
					onLoadFactory: (e) => {
						g({
							name: "preset_load",
							source: "factory",
							preset: e
						}), Oi(br(e), `${e} loaded. Your rack is patched and ready to play.`);
					},
					onClose: () => {
						P(!1), Pn.current?.focus();
					}
				}),
				N && /* @__PURE__ */ h("div", {
					className: Q.library,
					role: "region",
					"aria-label": "Device library",
					children: [/* @__PURE__ */ h("div", {
						className: Q.libraryHeading,
						children: [/* @__PURE__ */ m("strong", { children: "MAKE ROOM FOR SOMETHING NEW." }), /* @__PURE__ */ m("button", {
							"aria-label": "Close device library",
							onClick: () => re(!1),
							children: "×"
						})]
					}), /* @__PURE__ */ m("div", {
						className: Q.libraryGrid,
						children: Bt.map((e) => /* @__PURE__ */ h("button", {
							"data-device": Z[e].color,
							disabled: v.modules.length >= 32,
							onClick: () => Li(e),
							children: [
								/* @__PURE__ */ h("span", {
									className: Q.miniDevice,
									children: ["◉ ◉ ", /* @__PURE__ */ m("span", { children: "▰" })]
								}),
								/* @__PURE__ */ m("strong", { children: Z[e].name }),
								/* @__PURE__ */ m("small", { children: Z[e].subtitle })
							]
						}, e))
					})]
				}),
				/* @__PURE__ */ h("div", {
					className: Q.rackHeading,
					children: [/* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m("span", { className: Q.rackLight }), A ? "REAR PANEL / SIGNAL ROUTING" : "YOUR RACK / FRONT PANEL"] }), /* @__PURE__ */ h("span", { children: [
						v.modules.length,
						" DEVICES · ",
						v.cables.length,
						" CONNECTIONS"
					] })]
				}),
				A && /* @__PURE__ */ h("div", {
					className: Q.routingBar,
					children: [/* @__PURE__ */ m("span", { children: Ra }), /* @__PURE__ */ h("span", {
						className: Q.legend,
						children: [
							/* @__PURE__ */ m("i", { "data-kind": "audio" }),
							" AUDIO ",
							/* @__PURE__ */ m("i", { "data-kind": "cv" }),
							" CV ",
							/* @__PURE__ */ m("i", { "data-kind": "gate" }),
							" GATE"
						]
					})]
				}),
				/* @__PURE__ */ h("div", {
					className: Q.rack,
					ref: D,
					"data-holding": !!ra,
					onClick: Wi,
					onPointerMove: Zi,
					onPointerLeave: () => W(null),
					children: [
						A && /* @__PURE__ */ m(vo, {
							patch: v,
							rackRef: D,
							selected: et,
							onSelect: (e) => {
								tt(e), it(null), zt(null);
							},
							drag: ra
						}),
						v.modules.map((e, n) => {
							let r = Z[e.type], i = Wt(e.type), a = Yl.includes(e.type), o = (t) => si(e.id, t);
							return /* @__PURE__ */ h("article", {
								className: Q.module,
								"data-module-id": e.id,
								"data-device": r.color,
								"data-rear": A,
								"data-revealed": G === e.id,
								"data-silent": Pa[e.id] === !1,
								"data-keyboard-target": ba.id === e.id,
								"aria-current": ba.id === e.id ? "true" : void 0,
								onPointerDown: () => {
									A || di(e);
								},
								onFocus: () => {
									A || di(e);
								},
								"aria-label": `${r.name} ${r.subtitle}`,
								children: [
									/* @__PURE__ */ m("span", { className: `${Q.screw} ${Q.screwTL}` }),
									/* @__PURE__ */ m("span", { className: `${Q.screw} ${Q.screwTR}` }),
									/* @__PURE__ */ m("span", { className: `${Q.screw} ${Q.screwBL}` }),
									/* @__PURE__ */ m("span", { className: `${Q.screw} ${Q.screwBR}` }),
									/* @__PURE__ */ h("div", {
										className: Q.moduleHeader,
										children: [
											/* @__PURE__ */ h("div", {
												className: Q.moduleIdentity,
												children: [Jn(e.type) && /* @__PURE__ */ m(Oc, {
													select: (t) => t.pulsing.has(e.id),
													children: (e) => /* @__PURE__ */ m("span", {
														className: Q.hitLed,
														"data-lit": e,
														title: "Flashes on each sequencer hit",
														"aria-hidden": "true"
													})
												}), /* @__PURE__ */ m(yc, {
													module: e,
													slot: n + 1,
													onName: (t) => ga(e, t)
												})]
											}),
											!A && i && /* @__PURE__ */ m(cc, {
												module: e,
												param: i,
												name: r.name,
												onParams: (t) => Pr(e.id, t)
											}),
											/* @__PURE__ */ h("div", {
												className: Q.moduleTools,
												children: [
													e.type !== "output" && /* @__PURE__ */ m(Qo, {
														mixKey: e.id,
														label: r.name,
														mix: J,
														onToggle: Fr,
														clearable: ur(e, J),
														onClear: () => Mr((t) => ({ mix: dr(t.mix, e) })),
														onSwap: () => Ir(e.id)
													}),
													/* @__PURE__ */ m("span", {
														className: Q.moduleNumber,
														children: String(n + 1).padStart(2, "0")
													}),
													!Kt(v, e.id) && /* @__PURE__ */ h(p, { children: [
														/* @__PURE__ */ m("button", {
															"aria-label": `Move ${r.name} up`,
															disabled: n === 0,
															onClick: () => Nr((t) => Tn(t, e.id, -1)),
															children: "↑"
														}),
														/* @__PURE__ */ m("button", {
															"aria-label": `Move ${r.name} down`,
															disabled: n === v.modules.length - 2,
															onClick: () => Nr((t) => Tn(t, e.id, 1)),
															children: "↓"
														}),
														/* @__PURE__ */ m("button", {
															"aria-label": `Duplicate ${r.name}`,
															disabled: v.modules.length >= 32,
															onClick: () => Ri(e),
															children: "⧉"
														}),
														/* @__PURE__ */ m("button", {
															"aria-label": `Remove ${r.name}`,
															onClick: () => {
																vi(), zt(null), X.current === e.id && di(Xt({
																	...v,
																	modules: v.modules.filter((t) => t.id !== e.id)
																})), Nr((t) => wn(t, e.id)), tt(null), it(null), L(`${r.name} removed. Undo brings it back with its cables.`);
															},
															children: "×"
														})
													] })
												]
											})
										]
									}),
									A ? la(e) : e.type === "performance" ? Na(e) : e.type === "dictator" ? ja(e) : /* @__PURE__ */ h(p, { children: [
										r.drum && /* @__PURE__ */ h("div", {
											className: Q.moduleTransport,
											children: [
												_a(e),
												va(e),
												/* @__PURE__ */ h("span", { children: [
													"SHARED TEMPO · ",
													v.sequencer.bpm,
													" BPM"
												] })
											]
										}),
										r.drum?.mode !== "euclid" && /* @__PURE__ */ h("div", {
											className: Q.moduleBody,
											"data-head": r.drum ? "drum" : void 0,
											children: [
												e.type === "mixer" ? /* @__PURE__ */ m(Oc, {
													select: (t) => t.mixerLevels[e.id] ?? zl,
													children: (t) => /* @__PURE__ */ m(_c, {
														module: e,
														patch: v,
														mix: J,
														levels: t,
														onParams: (t) => Pr(e.id, t),
														onToggle: Fr,
														onSwap: Ir,
														onGoTo: ia
													})
												}) : ma(e),
												a && /* @__PURE__ */ m(us, {
													module: e,
													selected: ua(e) ?? r.drum.voices[0].id,
													onSelect: o,
													onParams: (t) => Pr(e.id, t),
													onAudition: (t) => ci(e.id, t),
													disabled: t
												}),
												e.type === "skitter" && /* @__PURE__ */ m(is, {
													name: r.name,
													brush: bt[e.id] ?? 1,
													onBrush: (t) => xt((n) => ({
														...n,
														[e.id]: t
													}))
												}),
												e.type !== "mixer" && /* @__PURE__ */ m("div", {
													className: Q.moduleDecoration,
													children: e.type === "output" ? /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(Oc, {
														select: (e) => e.meter,
														children: (e) => /* @__PURE__ */ m("div", {
															className: Q.meters,
															"aria-label": "Output level",
															role: "meter",
															"aria-valuemin": 0,
															"aria-valuemax": 1,
															"aria-valuenow": Number(e.toFixed(3)),
															children: [0, 1].map((t) => /* @__PURE__ */ h("div", {
																className: Q.meterRow,
																children: [/* @__PURE__ */ m("span", { children: t === 0 ? "L" : "R" }), Array.from({ length: 18 }, (t, n) => /* @__PURE__ */ m("i", {
																	"data-lit": n / 18 < e,
																	"data-hot": n > 14
																}, n))]
															}, t))
														})
													}), /* @__PURE__ */ m("button", {
														"aria-pressed": be,
														onClick: () => Mr((e) => ({ mainMuted: !e.mainMuted })),
														className: Q.muteButton,
														children: be ? "UNMUTE" : "MUTE"
													})] }) : e.type === "envelope" ? /* @__PURE__ */ m(Yo, { params: e.params }) : ["compressor", "cohere"].includes(e.type) ? /* @__PURE__ */ m(Oc, {
														select: (t) => t.reductions[e.id] ?? 0,
														children: (e) => /* @__PURE__ */ m(Go, {
															reduction: e,
															label: `${r.name} ${n + 1} gain reduction`
														})
													}) : e.type === "equalizer" ? /* @__PURE__ */ m(Wo, { params: e.params }) : /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("span", { className: Q.deviceLed }), /* @__PURE__ */ h("span", {
														className: Q.deviceLabel,
														children: [
															Zl[e.type] ?? "RACKLOOSE",
															/* @__PURE__ */ m("br", {}),
															/* @__PURE__ */ m("small", { children: Ql[e.type] ?? "PATCH. PLAY. REPEAT." })
														]
													})] })
												})
											]
										}),
										e.type === "brit" ? /* @__PURE__ */ m(Os, {
											module: e,
											rate: Te,
											onParams: (t) => Pr(e.id, t)
										}) : e.type === "talon" ? /* @__PURE__ */ m(Oc, {
											select: (t) => t.reductions[e.id] ?? 0,
											children: (t) => /* @__PURE__ */ m(zs, {
												module: e,
												reduction: t,
												label: `${r.name} ${n + 1} gain reduction`,
												onParams: (t) => Pr(e.id, t)
											})
										}) : fa(e) ?? pa(e),
										e.type === "prism" && /* @__PURE__ */ m(fs, {
											module: e,
											onParams: (t) => Pr(e.id, t)
										}),
										r.drum?.mode === "euclid" && /* @__PURE__ */ m(ss, {
											module: e,
											selected: ua(e) ?? r.drum.voices[0].id,
											onSelect: o,
											clock: It[e.id]?.clock ?? -1,
											mix: J,
											onMix: Fr,
											disabled: t,
											onParams: (t) => Pr(e.id, t),
											onAudition: (t) => ci(e.id, t),
											controls: ma(e)
										}),
										r.drum?.mode === "steps" && /* @__PURE__ */ m(as, {
											module: e,
											brush: bt[e.id] ?? 1,
											...a ? {
												selected: ua(e) ?? r.drum.voices[0].id,
												onSelect: o
											} : {},
											mix: J,
											onMix: Fr,
											step: (It[e.id]?.clock ?? -1) < 0 ? -1 : It[e.id].clock % 16,
											disabled: t,
											onParams: (t) => Pr(e.id, t),
											onAudition: (t) => ci(e.id, t)
										})
									] })
								]
							}, e.id);
						}),
						/* @__PURE__ */ h("div", {
							className: Q.rackBottom,
							children: [/* @__PURE__ */ m("button", {
								ref: te,
								className: Q.aboutButton,
								"aria-label": "About Rackloose",
								title: "About Rackloose",
								onClick: () => ce("about"),
								children: "RACKLOOSE / BY MICHAEL ZICK © 2026"
							}), /* @__PURE__ */ m("span", { children: "NO RULES. JUST SIGNAL." })]
						})
					]
				}),
				/* @__PURE__ */ m("div", {
					className: Q.toastAnchor,
					children: /* @__PURE__ */ m("div", {
						className: Q.toast,
						role: "status",
						"data-analytics-private": "",
						"data-shown": me,
						children: R
					})
				}),
				/* @__PURE__ */ h("div", {
					className: Q.keyboardPanel,
					children: [
						/* @__PURE__ */ h("div", {
							className: Q.globalControls,
							role: "group",
							"aria-label": "Global controls",
							children: [
								/* @__PURE__ */ h("div", {
									className: Q.globalTransport,
									children: [
										/* @__PURE__ */ h("button", {
											className: Q.playButton,
											disabled: t,
											onClick: li,
											"data-playing": ge,
											"aria-label": ge ? "Pause all sequencers" : "Play all sequencers",
											children: [/* @__PURE__ */ m(Zo, { name: ge ? "pause" : "play" }), /* @__PURE__ */ m("span", { children: ge ? "PAUSE ALL" : "PLAY ALL" })]
										}),
										/* @__PURE__ */ h("button", {
											className: Q.playStoppedButton,
											disabled: !ya,
											onClick: ui,
											"aria-label": "Play stopped sequencers",
											title: "Start every stopped sequencer again, in time with the rest. Mutes, solos and patch edits stay as they are.",
											children: [/* @__PURE__ */ m(Zo, { name: "play" }), /* @__PURE__ */ m("span", { children: "PLAY STOPPED" })]
										}),
										/* @__PURE__ */ h("button", {
											className: Q.rewindButton,
											onClick: () => T.current?.rewind(),
											"aria-label": "Rewind to the start",
											title: "Back to bar 1. Playing, it carries on from there.",
											children: [/* @__PURE__ */ m(Zo, { name: "reset" }), /* @__PURE__ */ m("span", { children: "REWIND" })]
										}),
										/* @__PURE__ */ m("button", {
											className: Q.clearAllButton,
											disabled: !J.muted.size && !J.soloed.size && !be,
											onClick: () => {
												Mr({
													mix: Wn,
													mainMuted: !1
												}), L("All mutes and solos cleared.");
											},
											"aria-label": "Clear all mutes and solos",
											children: /* @__PURE__ */ m("span", { children: "CLR ALL" })
										}),
										/* @__PURE__ */ h("button", {
											className: Q.recordButton,
											disabled: t,
											"data-recording": ze,
											"aria-pressed": ze,
											"aria-label": ze ? "Stop recording" : "Record",
											title: "Record into the armed DICTATOR (R)",
											onClick: pi,
											children: [/* @__PURE__ */ m("span", { className: Q.recordLed }), /* @__PURE__ */ m("span", { children: ze ? "STOP REC" : "RECORD" })]
										}),
										/* @__PURE__ */ h("label", {
											className: Q.countInField,
											title: "Bars of clicks before recording starts from a stop",
											children: ["PRE", /* @__PURE__ */ m("select", {
												"aria-label": "Count-in",
												value: He,
												onChange: (e) => Ue(Number(e.target.value)),
												children: [
													0,
													1,
													2
												].map((e) => /* @__PURE__ */ m("option", {
													value: e,
													children: e ? `${e} bar${e > 1 ? "s" : ""}` : "Off"
												}, e))
											})]
										}),
										/* @__PURE__ */ h("button", {
											className: Q.clickButton,
											"aria-pressed": Ae,
											title: "Click on every beat while the transport runs. It never reaches MAIN or an export.",
											onClick: () => je(!Ae),
											children: [/* @__PURE__ */ m("span", { className: Q.clickLed }), /* @__PURE__ */ m("span", { children: "CLICK" })]
										})
									]
								}),
								/* @__PURE__ */ m(Sc, {
									bpm: v.sequencer.bpm,
									onChange: (e) => Ei("bpm", e)
								}),
								/* @__PURE__ */ h("label", {
									className: Q.swingField,
									children: [
										"SWING",
										/* @__PURE__ */ m("input", {
											className: Q.fader,
											type: "range",
											min: 0,
											max: .6,
											step: .01,
											value: v.sequencer.swing,
											"aria-label": "Swing",
											onChange: (e) => Ei("swing", Number(e.target.value))
										}),
										/* @__PURE__ */ h("span", { children: [Math.round(v.sequencer.swing * 100), "%"] })
									]
								})
							]
						}),
						/* @__PURE__ */ h("div", {
							className: Q.keyboardTop,
							children: [
								/* @__PURE__ */ h("strong", {
									className: Q.keyboardTarget,
									"data-analytics-private": ba.label ? "" : void 0,
									children: ["KEYBOARD → ", nr(v, ba)]
								}),
								Aa ? /* @__PURE__ */ m("span", {
									className: Q.routingHint,
									title: Aa,
									children: Aa
								}) : e && /* @__PURE__ */ m("span", {
									className: Q.keyHint,
									children: wa ? `${wa.length > 11 ? "Home row + Z X C V B" : "Home row · pads"}${Sa ? " · 1–0 velocity" : ""}` : "A–' notes · Z X octave · 1–0 velocity"
								}),
								/* @__PURE__ */ h("div", {
									className: Q.positionField,
									title: `Where the transport is, as bar.beat.16th, counting through the longest loop in the rack: ${Ia / 16} ${Ia > 16 ? "bars" : "bar"}`,
									children: [/* @__PURE__ */ m("span", {
										"aria-hidden": "true",
										children: "POSITION"
									}), /* @__PURE__ */ m("span", {
										className: Q.globalPosition,
										"aria-label": "Global position",
										"data-count-in": Me !== null,
										children: Me === null ? ae(Math.max(0, Se), Ia) : oe(Me)
									})]
								}),
								/* @__PURE__ */ h("div", {
									className: Q.keyControls,
									children: [
										(!wa || Sa) && /* @__PURE__ */ h("div", {
											className: Q.octaveControls,
											children: [
												!wa && /* @__PURE__ */ h(p, { children: [
													/* @__PURE__ */ m("button", {
														"aria-label": "Lower keyboard octave",
														disabled: qe === 1,
														onClick: () => Mr((e) => ({ octave: Math.max(1, e.octave - 1) }), "octave"),
														children: "−"
													}),
													/* @__PURE__ */ h("span", { children: ["OCT ", qe] }),
													/* @__PURE__ */ m("button", {
														"aria-label": "Raise keyboard octave",
														disabled: qe === 6,
														onClick: () => Mr((e) => ({ octave: Math.min(6, e.octave + 1) }), "octave"),
														children: "＋"
													})
												] }),
												/* @__PURE__ */ m("button", {
													"aria-label": "Lower keyboard velocity",
													disabled: Oe === Vl[0],
													onClick: () => Mr({ velocity: Vl[Math.max(0, Vl.indexOf(Oe) - 1)] }, "velocity"),
													children: "−"
												}),
												/* @__PURE__ */ h("span", {
													title: "Velocity of the notes you play: 1–0 on the keyboard",
													children: ["VEL ", Oe]
												}),
												/* @__PURE__ */ m("button", {
													"aria-label": "Raise keyboard velocity",
													disabled: Oe === Vl.at(-1),
													onClick: () => Mr({ velocity: Vl[Math.min(Vl.length - 1, Vl.indexOf(Oe) + 1)] }, "velocity"),
													children: "＋"
												})
											]
										}),
										Et && /* @__PURE__ */ h("button", {
											className: Q.midiToggle,
											"aria-pressed": Ot !== null,
											"aria-label": "MIDI input",
											title: Ot === null ? "Play the keyboard’s device from a MIDI keyboard" : Ot.length ? `MIDI in: ${Ot.join(", ")}` : "MIDI on: no MIDI keyboard connected",
											onClick: () => void _i(),
											children: [/* @__PURE__ */ m("span", {
												className: Q.midiLed,
												"data-connected": !!Ot?.length
											}), "MIDI"]
										}),
										/* @__PURE__ */ m("button", {
											className: Q.keysToggle,
											"aria-expanded": Ye,
											"aria-controls": Zn,
											onClick: () => Xe(!Ye),
											children: Ye ? "Hide keys" : "Show keys"
										})
									]
								})
							]
						}),
						/* @__PURE__ */ m("div", {
							id: Zn,
							hidden: !Ye,
							children: wa ? /* @__PURE__ */ m("div", {
								className: Q.performancePads,
								"data-voices": wa.length,
								"data-rows": wa.length > 6 ? 2 : 1,
								style: { "--pad-columns": ka },
								"aria-label": `${Ca.name} performance pads`,
								children: wa.map((n, r) => /* @__PURE__ */ h("button", {
									"data-playing": ht.has(n.id),
									"aria-label": `Keyboard ${Ca.name} ${n.label}`,
									disabled: t,
									onPointerDown: (e) => {
										e.button === 0 && (e.preventDefault(), e.currentTarget.setPointerCapture(e.pointerId), Ft.current.add(`pointer-${e.pointerId}`), oi(`pointer-${e.pointerId}`, r, e.pointerType !== "mouse", e.timeStamp), Oa(n.id));
									},
									onPointerUp: (e) => Ur(`pointer-${e.pointerId}`, !1, e.timeStamp),
									onPointerCancel: (e) => Ur(`pointer-${e.pointerId}`, !0),
									onLostPointerCapture: Xr,
									onKeyDown: (e) => {
										e.key !== "Enter" && e.key !== " " || e.repeat || (e.preventDefault(), e.stopPropagation(), oi(`pad-${n.id}`, r), Oa(n.id));
									},
									onKeyUp: (e) => {
										(e.key === "Enter" || e.key === " ") && (e.preventDefault(), Ur(`pad-${n.id}`));
									},
									onBlur: () => Ur(`pad-${n.id}`),
									children: [/* @__PURE__ */ m("span", { children: n.label }), e && /* @__PURE__ */ m("small", { children: Hl[r].toUpperCase() })]
								}, n.id))
							}) : /* @__PURE__ */ h("div", {
								className: Q.playSurface,
								children: [
									Ea && /* @__PURE__ */ m(Oc, {
										select: (e) => e.wheels,
										children: (e) => /* @__PURE__ */ m(Nc, {
											levels: e ?? ao,
											disabled: t,
											onMove: Qr
										})
									}),
									Da.length > 0 && /* @__PURE__ */ m(Oc, {
										select: (e) => e.wheels,
										children: (e) => /* @__PURE__ */ m(Vc, {
											kinds: Da,
											levels: e ?? ao,
											disabled: t,
											onMove: Qr
										}, `${ba.id}:${ft}`)
									}),
									/* @__PURE__ */ m("div", {
										className: Q.piano,
										"aria-label": "Piano keyboard",
										children: Bl.map((e, n) => {
											let r = (qe + 1) * 12 + n, i = Ul.has(n % 12);
											return /* @__PURE__ */ h("button", {
												className: i ? Q.blackKey : Q.whiteKey,
												"data-note": r,
												"data-playing": Ce.includes(r),
												"aria-label": `Play ${Or(r)}`,
												disabled: t,
												onPointerDown: (e) => {
													e.button === 0 && (e.preventDefault(), e.currentTarget.setPointerCapture(e.pointerId), Ft.current.add(`pointer-${e.pointerId}`), oi(`pointer-${e.pointerId}`, n, e.pointerType !== "mouse", e.timeStamp));
												},
												onPointerUp: (e) => Ur(`pointer-${e.pointerId}`, !1, e.timeStamp),
												onPointerCancel: (e) => Ur(`pointer-${e.pointerId}`, !0),
												onLostPointerCapture: Xr,
												onKeyDown: (e) => {
													e.key !== "Enter" && e.key !== " " || e.repeat || (e.preventDefault(), e.stopPropagation(), oi(`piano-${r}`, n));
												},
												onKeyUp: (e) => {
													(e.key === "Enter" || e.key === " ") && (e.preventDefault(), Ur(`piano-${r}`));
												},
												onBlur: () => Ur(`piano-${r}`),
												children: [/* @__PURE__ */ m("span", { children: Bl[n].toUpperCase() }), !i && /* @__PURE__ */ m("small", { children: Or(r) })]
											}, n);
										})
									})
								]
							})
						})
					]
				}),
				ie === "guide" && /* @__PURE__ */ m("div", {
					className: Q.helpBackdrop,
					children: /* @__PURE__ */ h("div", {
						className: Q.help,
						role: "dialog",
						"aria-modal": "true",
						"aria-labelledby": Qn,
						"data-analytics-private": "",
						onKeyDown: zi,
						children: [
							/* @__PURE__ */ h("div", {
								className: Q.helpHeading,
								children: [
									/* @__PURE__ */ m("img", {
										src: "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2064%2064'%3e%3crect%20x='5'%20y='6'%20width='54'%20height='52'%20rx='3'%20fill='%23303337'%20stroke='%23101214'%20stroke-width='2'/%3e%3cpath%20d='M10%2010v44M54%2010v44'%20stroke='%23777'%20stroke-width='3'/%3e%3crect%20x='14'%20y='12'%20width='36'%20height='17'%20fill='%23b9503a'%20stroke='%23111'/%3e%3crect%20x='14'%20y='31'%20width='36'%20height='20'%20fill='%23a0ac9b'%20stroke='%23111'/%3e%3cg%20fill='%23232626'%20stroke='%23dfdfca'%3e%3ccircle%20cx='23'%20cy='21'%20r='5'/%3e%3ccircle%20cx='41'%20cy='21'%20r='5'/%3e%3c/g%3e%3cpath%20d='M23%2021v-4m18%204%203-3'%20stroke='%23fff'%20stroke-width='2'/%3e%3cg%20fill='%231b2221'%20stroke='%23555'%3e%3ccircle%20cx='22'%20cy='39'%20r='3'/%3e%3ccircle%20cx='42'%20cy='44'%20r='3'/%3e%3c/g%3e%3cpath%20d='M22%2039c-6%2020%2027%2020%2020%205'%20fill='none'%20stroke='%23f4bb50'%20stroke-width='3'/%3e%3cpath%20d='M7%208h50'%20stroke='%23a9abad'/%3e%3c/svg%3e",
										width: "34",
										height: "34",
										alt: ""
									}),
									/* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("small", { children: "RACKLOOSE · MODULAR SYNTHESIZER" }), /* @__PURE__ */ m("h2", {
										id: Qn,
										children: "User Guide"
									})] }),
									/* @__PURE__ */ m("button", {
										autoFocus: !0,
										onClick: Bi,
										"aria-label": "Close user guide",
										children: "×"
									})
								]
							}),
							/* @__PURE__ */ m("h3", { children: "Transport" }),
							/* @__PURE__ */ h("p", { children: [
								"Play All starts every sequencer and turns into Pause All while anything plays. Play Stopped starts every sequencer you stopped while the transport plays again, in time, and leaves mutes, solos and the patch alone. Rewind goes back to bar 1: playing, it plays on from there. Type a tempo or drag the small fader under it; the change is heard right away. Space always plays and pauses, whichever control has focus, except while typing in a text field. Each STEP–16, DICTATOR and drum machine also has its own Play/Stop, locked to the shared tempo, swing and position. POSITION, in the keyboard bar, shows it as bar.beat.16th of the longest loop: 11.2.1 is bar 11, beat 2, its first 16th. CLICK sounds each beat, higher on the first, straight to your speakers: it is never in an export. RECORD, or ",
								/* @__PURE__ */ m("strong", { children: "R" }),
								", records into a DICTATOR (see Recording)."
							] }),
							/* @__PURE__ */ m("h3", { children: "Playing" }),
							/* @__PURE__ */ h("p", { children: [
								"Click a device to aim the keyboard at it. Click its printed name to write your own on a strip of masking tape, like Lead synth or Big drums. Click the tape to change it, then its × to peel it off. SUM’s channels and their signal paths use the names you write: a channel goes by the name nearest it, on an effect, its instrument, or the sequencer playing it. Click a channel’s name to go to that device. MONARCH, ORACLE, AURORA, PRISM, SOLID and DICTATOR play on ",
								/* @__PURE__ */ m("strong", { children: "A W S E D F T G Y H U J K O L P ; '" }),
								", eighteen keys from C to the F above. ",
								/* @__PURE__ */ m("strong", { children: "Z" }),
								" and ",
								/* @__PURE__ */ m("strong", { children: "X" }),
								", or OCT, shift the octave, and the number keys set how hard you play, from ",
								/* @__PURE__ */ m("strong", { children: "1" }),
								" (softest) to ",
								/* @__PURE__ */ m("strong", { children: "0" }),
								" (full), shown as VEL. MONARCH plays one note at a time; ORACLE plays up to five, AURORA eight and PRISM sixteen. Their Chord setting turns every note, from the keys or STEP–16, into a chord. The chrome Engine switch in a device’s header slides between Digital, its black tab on the left, and Analog, its red tab on the right. On MONARCH, ORACLE, AURORA and SIEVE, Analog is a Moog-style ladder filter that self-oscillates near full Resonance; on PRISM it adds a ladder to every voice, set in its Filter section. Drum machines get pads on the home row, ",
								/* @__PURE__ */ m("strong", { children: "A S D F G H J K L ; '" }),
								", plus ",
								/* @__PURE__ */ m("strong", { children: "Z X C V B" }),
								" for STRIKE’s remaining five voices. STATIC holds noise on A. STEP–16 plays whatever its Pitch and Gate cables reach, and effects keep the last instrument. The light beside each instrument and drum machine flashes every time a sequencer plays it. Hide keys keeps every global control."
							] }),
							/* @__PURE__ */ m("p", { children: "Left of the keys sit a pitch wheel and a mod wheel, for MONARCH, ORACLE, AURORA and PRISM, or a DICTATOR or STEP–16 that plays one. Drag them up and down, or focus one and use the arrows; a MIDI keyboard’s wheels move them too. The pitch wheel springs back to the centre when you let go, and each synth’s Bend sets how far it reaches, up to 12 semitones. The mod wheel stays where you leave it, and a double-click takes it back down. Each does what it did on the synth it is modelled on. On MONARCH it sets how much of the Mod mix, Osc 3 or noise, reaches the oscillators or the filter; switch Osc 3 to LFO for a vibrato. On ORACLE it brings in the LFO and noise beyond the LFO’s own Amount. On AURORA it brings in LFO vibrato, as deep as LFO mod, and VCF bend lets the pitch wheel sweep the filter too. On PRISM it deepens vibrato, tremolo or brightness, as Mod to picks, as far as Mod range." }),
							/* @__PURE__ */ m("p", { children: "VELVET, REED, PLANET, STRUT and DRAWBAR are electric keyboards, each behind its original’s front panel. VELVET is a tine electric piano: a Suitcase Mk I through its own stereo tremolo and speakers, or a Stage Mk I or Mk II into a guitar amp. REED is a reed electric piano with its own tremolo and speaker. PLANET plucks its reeds with sticky pads, the N bright and barky, the T round and mellow. STRUT is a clavinet: the AB and CD rockers pick its pickups, the four tone rockers shape it, and the mute lever damps it to a pizzicato. DRAWBAR is a tonewheel organ: pull the drawbars, set its percussion with the ivory tabs, turn the vibrato and chorus switch, and stop or run the rotary speaker. Their Analog engines model each instrument’s tines, reeds, strings or tonewheels and its pickups and amp. In place of the wheels, they have foot pedals beside the keys. The electric pianos have a sustain pedal: hold it, click to latch it, or drag it for half-pedal. Every one has a swell pedal: drag it up to open it, down to close it. DRAWBAR’s half-moon switch turns the rotary SLOW or FAST, as the top half of a MIDI mod wheel does. A MIDI keyboard’s sustain and expression pedals play them too, DICTATOR records the pedals in its SUS and SWELL lanes, and .mid files carry them both ways." }),
							/* @__PURE__ */ m("h3", { children: "Recording" }),
							/* @__PURE__ */ h("p", { children: [
								"DICTATOR records what you play on the keys as MIDI notes, in a looping clip of 1 to 16 bars, and plays them back on whatever its Pitch and Gate cables reach: pick an instrument under PLAYS to patch it in one step. ARM a DICTATOR, which takes the keyboard, then press RECORD or ",
								/* @__PURE__ */ m("strong", { children: "R" }),
								". With more than one DICTATOR, only the armed one records, and arming another disarms it; with none armed, RECORD uses the DICTATOR the keys play, or asks you to arm one. From a stop, PRE counts in 0, 1 or 2 bars with the click before every sequencer starts; while playing, recording starts at once. Each key is its own note, so chords record as chords, at the velocity VEL shows, placed where you heard them. Every pass round the loop adds notes (Overdub), or Record set to Replace clears what the playhead passes. In the QUANTIZE row, which picks a grid from quarter notes to 1/32s, the Quantize button moves note starts onto it now (the notes selected in the piano roll, or else every note), and the AUTO lamp moves each note onto it as you record. RECORD, R, Pause or Panic stops, and the take is one step that Undo takes back whole; Backspace while recording throws the take away so far and keeps recording. Capture keeps what you just played with the transport running, without RECORD. Moving a wheel while recording writes its moves into the clip’s PITCH and MOD lanes, replacing them only where you moved it, and Capture keeps wheel moves too. If what you record lands late, as with Bluetooth headphones, REC TIMING records it up to 100 ms earlier, in this browser; it never changes what you hear. Lag plays the clip up to 50 ms late or early against the beat, which you hear against the click or other parts. DICTATOR’s mute and solo work like STEP–16’s, and Export WAV renders its whole clip. Rest the pointer on any control to see what it does."
							] }),
							/* @__PURE__ */ m("p", { children: "EDIT opens the clip in a piano roll. Draw clicks a note onto the SNAP grid, or drags it longer; Select drags across notes to select them. Drag a note to move it, its right edge to resize it, or the velocity lane under it to set how hard it plays; double-click deletes it. VEL, PITCH and MOD, beside the lane, pick what it shows: drag in PITCH or MOD to draw the wheel’s moves, a step per SNAP cell or smoothly with SNAP off, Alt-drag to erase them, and Clear PITCH or Clear MOD empties the lane. The wheel holds each value until the next, round the loop, and a wheel you hold takes over from the lane until you let go. With the roll focused, the arrows move the selection, or a cursor, by a SNAP step or a semitone, Shift+arrows resize it or move it an octave, N adds a note at the cursor, [ and ] step through the notes, Delete removes them, ⌘A or Ctrl+A selects all, ⌘D or Ctrl+D duplicates, and Escape clears the selection, then closes the roll. On a touch screen, a finger draws on the grid and scrolls on the keys or the bar numbers. Each edit is one step that Undo takes back." }),
							/* @__PURE__ */ m("p", { children: "Click or drag DICTATOR’s strip, or the piano roll’s bar numbers, to move the playhead there, or tap them on a touch screen; with one focused, the arrows move it a beat and Shift+arrows a bar. The playhead is the shared position, so every sequencer moves with it, whether stopped, playing or recording." }),
							/* @__PURE__ */ m("p", { children: "Pick a drum machine under PLAYS and DICTATOR plays it by General MIDI note, the kick on 36, snare 38, closed hat 42 and so on, as hard as each note was played; the keyboard then shows that kit’s pads, which record as those notes. Export .mid saves the clip as a MIDI file for a DAW, and Import .mid replaces it with a file’s notes, one track or all of them. MIDI, beside the keys, plays the keyboard’s device from a MIDI keyboard in Chrome, Edge or Firefox once the browser has your permission, and records like the keys, at the velocity you play." }),
							/* @__PURE__ */ m("h3", { children: "Knobs and steps" }),
							/* @__PURE__ */ m("p", { children: "Drag a knob up or down, or use the arrow keys; double-click restores its default. Click a STEP–16 step to switch it on or off, as on a drum machine’s pads. To set a step’s note, velocity and gate, turn on EDIT, beside CLEAR under Play, which dashes every step’s border, and click the step; its Note on box switches it too. Turn EDIT off, or press Escape, to switch steps with a click again. A step that is off keeps its note for when you switch it back on, and CLEAR, under Play, turns every step into a rest the same way. A STEP–16’s Lag moves all its notes up to 50 ms ahead of the beat (turn it left) or behind it (right); centred is On beat. Add device adds more STEP–16s: each has its own 16 steps, Play/Stop and step mutes, and plays whatever its own Pitch and Gate cables reach, so separate parts can drive separate instruments. Typing in a field never plays notes." }),
							/* @__PURE__ */ m("h3", { children: "Patching cables" }),
							/* @__PURE__ */ m("p", { children: "Flip the rack to patch. Each jack holds one cable. Drag from an empty jack to a free one; jacks that can take it light up. Drag a plugged jack to pull its plug out: drop it on a free jack to move it, or on empty rack space to unplug it. You can also tap a plugged jack to lift its plug, then tap a free jack. Escape or a bad drop puts the plug back, and Delete unplugs a selected cable. Every output has a spare jack, and STEP–16 has three Pitch and three Gate jacks, so one signal can feed several places. Amber is audio, blue is CV and coral is gate; types must match. The trim beside a CV input sets its depth. SUM mixes eight channels and names each one after the instrument feeding it, through any effects; hover the name to see the chain." }),
							/* @__PURE__ */ m("h3", { children: "Mixing on SUM" }),
							/* @__PURE__ */ m("p", { children: "SUM is laid out like a console. Each channel strip has Pan, M and S, a fader and a level meter: green, amber from −9 dB and red from −3 dB. Drag a fader or pan knob, or use the arrow keys; double-click returns it to its default. The MIX BUS fader on the right sets the level of the whole mix, with its own left and right meters." }),
							/* @__PURE__ */ m("h3", { children: "Drums" }),
							/* @__PURE__ */ m("p", { children: "AURORA is an eight-voice Jupiter-8-inspired polysynth: blend two oscillators, shape them with high-pass and 12/24 dB low-pass filters, and animate pulse width with the LFO. PRISM is a focused DX7-inspired FM synth: choose one of six algorithms, then select an operator to edit its ratio, level and envelope. Brightness controls modulation depth; Velocity makes quieter sequenced notes softer in tone. Both use their own envelopes and work with STEP–16 Pitch and Gate, or directly from the keyboard." }),
							/* @__PURE__ */ m("p", { children: "STRIKE has sixteen vintage digital drum lanes, original generated one-shots inspired by LinnDrum. BOOM has eleven voices: kick, snare, rim, clap, closed and open hat, low and high tom, crash, ride and bell. A closed hat cuts off a ringing open hat. On BOOM, PUNCH, STRIKE and FORGE, click a voice’s name, tap its performance pad or pick it under Edit voice to hear it and shape it in the voice editor, with its own knobs, such as Tune, Decay and Tone, its Pan and its Lag. Lag moves just that voice up to 50 ms ahead of the beat (turn it left) or behind it (right), like hats pushed ahead or a snare laid back. ORBIT shows the same knobs for the lane you pick. Every drum machine’s Engine toggle picks Digital or Analog, which builds each voice from modeled analog circuits (or, on STRIKE and FORGE, plays its one-shots through a ladder tone filter) at the same level. Every device starts Analog, presets and older patches included. The knob marked LEVEL on each drum lane, in ORBIT’s Level column, sets that voice’s level: centred leaves it as it was, down silences it and full adds 6 dB. Hover it to read the change; double-click resets it. Click pads to program a voice’s steps. CLEAR, beside a drum machine’s Play, empties the pattern it came with, rolls and custom rings included, so you can start from silence; ORBIT’s rings keep their Steps and Shift, so Generate refills them. ORBIT voices each have Steps, Hits and Shift; tap its step pads for a custom rhythm, and Generate turns it back into a Euclidean one, spreading the hits you tapped evenly if the lane had no Hits. A drum machine’s Chain in passes another instrument through. SKITTER is a trap step sequencer that makes no sound: patch Trig out into a drum machine’s Trig in and its lanes play that kit’s kick, snare, clap, hats and perc, or patch Synth gate into MONARCH, CONTOUR or a polysynth. Pick a note under Note, then tap a step to play it as a 1/16, a pair of 1/32s, or a roll of 1/32 triplets, 1/64s or 1/64 triplets. FORGE is an industrial rock kit with its own Drive and gated Room, and RUST distorts anything patched into it, from fuzz to crushed bits." }),
							/* @__PURE__ */ m("h3", { children: "Dynamics and EQ" }),
							/* @__PURE__ */ m("p", { children: "VALVE is a tube limiter: Input drives the tube, Threshold sets where it starts to hold the level back, and Time constant picks how fast it lets go, from 1 (quick) to 6 (slow). The needle shows the gain reduction. CONSOLE is a channel EQ: high- and low-pass filters, LF and HF that switch between shelf and bell, and two sweepable mids with Q. The screen draws the curve you hear, and EQ Out bypasses it. Every factory preset carves at least one instrument with it." }),
							/* @__PURE__ */ m("h3", { children: "Mute and solo" }),
							/* @__PURE__ */ m("p", { children: "M mutes and S solos a device, drum voice, SUM channel or step, and the two are exclusive. CLR clears one device’s mutes and solos, with its voices’, channels’ or steps’, and SWAP turns a muted device or SUM channel soloed or a soloed one muted; CLR ALL clears everything, MAIN’s mute included. Silenced parts dim. These settings last for this session, and Revert clears them all." }),
							/* @__PURE__ */ m("h3", { children: "Undo and unsaved changes" }),
							/* @__PURE__ */ h("p", { children: [
								"Undo and Redo, or ",
								/* @__PURE__ */ m("strong", { children: "⌘Z" }),
								" and ",
								/* @__PURE__ */ m("strong", { children: "⇧⌘Z" }),
								" (",
								/* @__PURE__ */ m("strong", { children: "Ctrl+Z" }),
								" and ",
								/* @__PURE__ */ m("strong", { children: "Ctrl+Y" }),
								"), step through your last 50 changes: knobs, steps, CLEAR, recorded takes, tempo, cables, devices, presets, mutes, solos, octave and velocity. A ",
								/* @__PURE__ */ m("strong", { children: "*" }),
								" after the patch name means it has changed since you last saved it to My Presets or loaded it, and Revert puts it back that way as one more step, so Undo brings your changes back. While it has changed, the line under the name says whether those edits are saved in this browser, which brings them back after a reload; if it says Not saved, export a file to keep them. Revert, in red, puts back every setting with the patch: it clears every mute and solo, MAIN’s included, returns the keys to octave 3 and velocity 127, lets the wheels and pedals go back to rest, and disarms any DICTATOR, throwing away a take it was recording. It lights whenever any of that differs. The transport plays on: Play Stopped starts what you stopped, and Rewind only moves back to bar 1."
							] }),
							/* @__PURE__ */ m("h3", { children: "Presets and files" }),
							/* @__PURE__ */ h("p", { children: [
								"Your rack keeps itself between visits. Save, or ",
								/* @__PURE__ */ m("strong", { children: "⌘S" }),
								" (",
								/* @__PURE__ */ m("strong", { children: "Ctrl+S" }),
								"), keeps it in My Presets in this browser: the first save asks for a name, and later saves update that preset. Type a new name in PATCH and save to rename it; Save as… (",
								/* @__PURE__ */ m("strong", { children: "⇧⌘S" }),
								") makes a copy. Presets lists My Presets above the factory presets. Export downloads a preset as a .json file, Import file adds one to My Presets, and Delete removes your own presets. Export WAV renders the number of loops chosen next to it, every sequencer from the start, effects and mutes included, but not MAIN’s Mute. Once you edit the rack, the line under the patch name says whether your edits are kept in this browser, and messages appear briefly over the bottom of the rack. Panic silences everything at once."
							] })
						]
					})
				}),
				ie === "about" && /* @__PURE__ */ m("div", {
					className: Q.helpBackdrop,
					children: /* @__PURE__ */ h("div", {
						className: `${Q.help} ${Q.about}`,
						role: "dialog",
						"aria-modal": "true",
						"aria-labelledby": er,
						onKeyDown: zi,
						children: [
							/* @__PURE__ */ h("div", {
								className: Q.helpHeading,
								children: [
									/* @__PURE__ */ m("img", {
										src: "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2064%2064'%3e%3crect%20x='5'%20y='6'%20width='54'%20height='52'%20rx='3'%20fill='%23303337'%20stroke='%23101214'%20stroke-width='2'/%3e%3cpath%20d='M10%2010v44M54%2010v44'%20stroke='%23777'%20stroke-width='3'/%3e%3crect%20x='14'%20y='12'%20width='36'%20height='17'%20fill='%23b9503a'%20stroke='%23111'/%3e%3crect%20x='14'%20y='31'%20width='36'%20height='20'%20fill='%23a0ac9b'%20stroke='%23111'/%3e%3cg%20fill='%23232626'%20stroke='%23dfdfca'%3e%3ccircle%20cx='23'%20cy='21'%20r='5'/%3e%3ccircle%20cx='41'%20cy='21'%20r='5'/%3e%3c/g%3e%3cpath%20d='M23%2021v-4m18%204%203-3'%20stroke='%23fff'%20stroke-width='2'/%3e%3cg%20fill='%231b2221'%20stroke='%23555'%3e%3ccircle%20cx='22'%20cy='39'%20r='3'/%3e%3ccircle%20cx='42'%20cy='44'%20r='3'/%3e%3c/g%3e%3cpath%20d='M22%2039c-6%2020%2027%2020%2020%205'%20fill='none'%20stroke='%23f4bb50'%20stroke-width='3'/%3e%3cpath%20d='M7%208h50'%20stroke='%23a9abad'/%3e%3c/svg%3e",
										width: "34",
										height: "34",
										alt: ""
									}),
									/* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("small", { children: "RACKLOOSE · MODULAR SYNTHESIZER" }), /* @__PURE__ */ m("h2", {
										id: er,
										children: "About Rackloose"
									})] }),
									/* @__PURE__ */ m("button", {
										autoFocus: !0,
										onClick: Bi,
										"aria-label": "Close about Rackloose",
										children: "×"
									})
								]
							}),
							/* @__PURE__ */ h("dl", {
								className: Q.aboutFacts,
								children: [
									/* @__PURE__ */ m("dt", { children: "Version" }),
									/* @__PURE__ */ m("dd", { children: "2.14.0" }),
									/* @__PURE__ */ m("dt", { children: "By" }),
									/* @__PURE__ */ m("dd", { children: "Michael Zick" })
								]
							}),
							/* @__PURE__ */ m("p", {
								className: Q.aboutTagline,
								children: "Small studio. Endless possibilities."
							}),
							/* @__PURE__ */ m("p", {
								className: Q.aboutCopyright,
								children: "© 2026 Michael Zick"
							})
						]
					})
				}),
				Mn !== null && /* @__PURE__ */ m(Tc, {
					initialName: Mn,
					presets: Cn,
					onSave: ji,
					onCancel: Ai
				})
			]
		})
	});
}
export { pu as RacklooseApp, Cr as parsePatch, br as preset, xr as serializePatch };
