type Params = Record<string, number>;
type Host = {
    keep: <T extends AudioNode>(node: T) => T;
    source: <T extends OscillatorNode | ConstantSourceNode | AudioBufferSourceNode>(node: T) => T;
    onError?: (error: Error) => void;
};
export declare function createMonarch(context: BaseAudioContext, noiseBuffer: AudioBuffer, { keep, source, onError }: Host): {
    pitch: GainNode;
    cv: GainNode;
    output: GainNode;
    apply(p: Params): void;
    noteOn(velocity: number, time: number): void;
    noteOff(time: number): void;
    wheel: import("./poly").WheelMove;
    flush: () => Promise<void>;
    dispose: () => void | undefined;
};
export {};
