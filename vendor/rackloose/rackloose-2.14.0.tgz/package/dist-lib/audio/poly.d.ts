import type { ControlKind } from '../wheels';
/**
 * Moves a synth's pitch or mod wheel to `level` at `time`: the pitch wheel from −1 to 1, the mod wheel from 0 to 1.
 * `cancel` first drops the moves still queued, as when a hand takes the wheel from a DICTATOR lane.
 */
export type WheelMove = (kind: ControlKind, level: number, time: number, cancel?: boolean) => void;
/** Common instrument ports, timestamped note lifecycle and wheels. */
export type PolyInstrument = {
    pitch: AudioNode | AudioParam;
    cv: AudioNode | AudioParam;
    output: AudioNode;
    apply: (params: Record<string, number>) => void;
    noteOn: (note: number, velocity: number, time: number, key: string) => void;
    noteOff: (time: number, key?: string) => void;
    wheel: WheelMove;
    flush?: () => Promise<void>;
    dispose?: () => void;
};
export type SynthHost = {
    onError?: (error: Error) => void;
    keep: <T extends AudioNode>(node: T) => T;
    source: <T extends OscillatorNode | ConstantSourceNode | AudioBufferSourceNode>(node: T) => T;
};
/** How quickly a wheel's signal follows a move: a 5 ms time constant, smooth enough not to click and quick enough to feel. */
export declare const WHEEL_GLIDE = 0.005;
/**
 * A synth's pitch and mod wheels as signals, which it scales and routes as its original did. Each move glides over
 * WHEEL_GLIDE, so a move played live and one a DICTATOR lane plays are both smooth and land on time; the mod wheel's
 * signal is its level put through `taper`.
 */
export declare function wheelSignals(context: BaseAudioContext, source: SynthHost['source'], taper?: (level: number) => number): {
    bend: ConstantSourceNode;
    mod: ConstantSourceNode;
    move: WheelMove;
};
/**
 * Connects `from` to `to` only while it is `used`, so a costly node nothing listens to (an oversampled pulse shaper
 * behind a closed level) is not rendered at all. Going unused waits for that level to fade before disconnecting;
 * `initial` disconnects at once, before any sound.
 */
export declare function switchable(from: AudioNode, to: AudioNode): (used: boolean, initial: boolean) => void;
type Slot = {
    key: string | null;
    start: number;
    releaseAt: number;
    freeAt: number;
};
/**
 * Chooses voices from scheduled times alone, so an offline render, where every note is queued up front, allocates
 * exactly as live playback does. A new note takes the voice that has been silent longest, then the one released
 * longest ago, and only then steals the oldest held note.
 */
export declare class VoicePool {
    readonly voices: Slot[];
    constructor(size?: number);
    allocate(time: number, taken?: ReadonlySet<number>): number;
    start(index: number, key: string, time: number): void;
    /** Releases held voices, all or one key's, including notes scheduled to start after `time`. */
    release(time: number, tail: number, key?: string): {
        index: number;
        pending: boolean;
    }[];
}
export {};
