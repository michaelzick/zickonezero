import type { PolyInstrument, SynthHost } from './poly';
/** The modeled keyboards, which share one processor: VELVET, REED, PLANET, STRUT and DRAWBAR. */
export type KeysType = 'velvet' | 'reed' | 'planet' | 'strut' | 'drawbar';
/**
 * A modeled keyboard. Notes, pedals and params go to its processor as timestamped events, so a pedal a DICTATOR lane
 * presses lands on the same sample as the notes around it. The Pitch input bends every string in cents and the CV input
 * moves the keyboard's own CV target; its output is stereo.
 */
export declare function createKeys(type: KeysType, context: BaseAudioContext, { keep, onError }: SynthHost): PolyInstrument;
