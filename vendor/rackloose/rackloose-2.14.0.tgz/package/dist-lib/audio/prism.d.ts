export { prepareAudio } from './worklets';
import { type PolyInstrument, type SynthHost } from './poly';
export declare function createPrism(context: BaseAudioContext, { keep, source, onError }: SynthHost): PolyInstrument;
