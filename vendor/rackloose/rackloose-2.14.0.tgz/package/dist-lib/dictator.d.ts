/**
 * DICTATOR's recording and timing, free of audio and React. Notes are kept in ticks at 960 to the quarter note, as Reason
 * records them, so each of the rack's 16th-note steps is 240 ticks and a bar of 16 steps is 3,840.
 */
export declare const PPQ = 960;
export declare const STEP_TICKS: number;
export declare const BAR_STEPS = 16;
export declare const BAR_TICKS: number;
/** A recorded note: where it starts in its clip and how long it lasts, in ticks, then its MIDI note and velocity, 1–127. */
export type Note = [tick: number, length: number, note: number, velocity: number];
/** The clip lengths DICTATOR's Length offers, in bars. */
export declare const CLIP_BARS: number[];
export declare const MAX_TICKS: number;
/** The most notes one DICTATOR keeps, and the most a whole patch keeps, so patches stay well inside storage limits. */
export declare const NOTE_LIMIT = 2048;
export declare const PATCH_NOTE_LIMIT = 8192;
/** DICTATOR's Quantize values, with their grid in ticks. */
export declare const QUANTIZE: [label: string, ticks: number][];
/** The furthest, in ms, the record offset moves what is recorded earlier or later. */
export declare const RECORD_OFFSET_LIMIT = 100;
/** Reason's number-key velocities: 1 plays at 1 and 0 at 127. */
export declare const VELOCITY_KEYS: Record<string, number>;
/** A clip's length in ticks, from its Length param (an index into CLIP_BARS). */
export declare const clipTicks: (lengthIndex: number) => number;
/** The same length in 16th-note steps. */
export declare const clipSteps: (lengthIndex: number) => number;
/** Notes in playing order: by start, then pitch. */
export declare const sortNotes: (notes: readonly Note[]) => Note[];
/** The index of the first note starting at or after `tick` in sorted `notes`. */
export declare function firstAt(notes: readonly Note[], tick: number): number;
/** The notes of sorted `notes` that start in [from, to). */
export declare const notesIn: (notes: readonly Note[], from: number, to: number) => Note[];
/** `tick` moved `amount` of the way to the nearest line of a `grid`-tick grid, wrapped into a `loop`-tick clip. */
export declare function quantizeTick(tick: number, grid: number, amount?: number, loop?: number): number;
/** Moves note starts toward the grid, as Reason's Quantize does, keeping lengths, and clips each note at the loop end. */
export declare function quantizeNotes(notes: readonly Note[], grid: number, amount: number, loop: number): Note[];
/** A note that starts in the clip at `tick` for `length` ticks, clipped at the loop end so it never plays past it. */
export declare function clipNote(tick: number, length: number, note: number, velocity: number, loop: number): Note;
/**
 * The parts of a `loop`-tick clip the playhead crossed between absolute ticks `from` and `to`, as [start, end) spans.
 * A whole loop or more covers everything.
 */
export declare function coveredSpans(from: number, to: number, loop: number): [number, number][];
/** Where Capture's window ends for input heard last at absolute tick `newest`: the end of the bar it falls in. */
export declare const windowEnd: (newest: number) => number;
/**
 * What Capture keeps for a `loop`-tick clip from `heard`, notes played at absolute ticks: those that start within `loop`
 * ticks before `end`, by default the end of the bar the newest one starts in, placed where the clip plays them, as
 * recording would.
 */
export declare function captureWindow(heard: readonly Note[], loop: number, end?: number): Note[];
/** Whether `tick` falls in one of the [start, end) `spans`. */
export declare const within: (tick: number, spans: readonly [number, number][]) => boolean;
/**
 * A clip with a take recorded into it. Overdub keeps every note already there; Replace first drops those starting where
 * the playhead passed while recording. A take note on the same tick and pitch as an existing note replaces it, and a
 * clip stays within NOTE_LIMIT by leaving out the latest take notes.
 */
export declare function mergeTake(existing: readonly Note[], take: readonly Note[], replace: boolean, spans: readonly [number, number][]): Note[];
/**
 * Plays held notes the way a monophonic instrument hears the keys: the newest note sounds, every press retriggers, and
 * letting go of it falls back to the newest one still held, retriggering, as `NoteStack` does for live playing.
 */
export declare class MonoLine {
    private held;
    /** Presses note `id`; returns what to play. */
    on(id: string, note: number, velocity: number): {
        note: number;
        velocity: number;
    };
    /** Lets note `id` go: the note to fall back to, `null` when nothing is held any more, or `undefined` when nothing changes. */
    off(id: string): {
        note: number;
        velocity: number;
    } | null | undefined;
    clear(): void;
    get size(): number;
}
/** A step of the shared clock: its 16th-note count from Play, when it starts and how long it lasts, in seconds. */
export type ClockStep = {
    count: number;
    time: number;
    duration: number;
};
/**
 * The absolute tick sounding at context time `time`, from the clock's recent steps (in time order): `count` × 240 plus
 * how far through its step `time` falls, so swing is undone. Null before the first step or after the last one ends.
 */
export declare function tickAt(steps: readonly ClockStep[], time: number): number | null;
/**
 * The context time of the sound heard when an input event with `timeStamp` (on the `performance.now()` clock) happened.
 * `output` pairs the sample leaving the speakers with the moment it did; without it, the current time less the output
 * latency stands in. Either way the player's own monitoring delay is taken out, so notes land where they were heard.
 */
export declare function heardAt(timeStamp: number, output: {
    contextTime: number;
    performanceTime: number;
} | null, fallback: {
    currentTime: number;
    latency: number;
    now: number;
}): number;
/** A position as bar.beat.16th, counted from 1, within a loop of `loopSteps` 16ths. */
export declare function positionLabel(count: number, loopSteps?: number): string;
/** A count-in step, from -1 back, as the bars and beat still to come before the downbeat, such as −1.3. */
export declare const countInLabel: (count: number) => string;
/**
 * The General MIDI drum note each kit voice plays from, so a DICTATOR whose Gate reaches a drum machine's Trig in plays
 * a kit voice per note, and a .mid file of drums plays the voices it names. ORBIT's voices take the notes of the kit
 * voices SKITTER plays them as.
 */
export declare const GM_DRUMS: Record<string, number>;
/** The voice of a kit with `voices` that MIDI note `note` plays, or null when the kit has none near it. */
export declare function drumVoiceOf(voices: readonly {
    id: string;
}[], note: number): string | null;
