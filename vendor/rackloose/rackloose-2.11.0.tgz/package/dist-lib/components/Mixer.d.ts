import { type Mix, type Patch, type RackModule } from '../model';
import type { MixerLevels } from '../audio/engine';
import { type MixToggle } from './MixButtons';
/** A vertical ladder of LEDs: green, amber from −9 dBFS and red from −3. */
export declare function LevelMeter({ level, label }: {
    level: number;
    label: string;
}): import("react").JSX.Element;
/**
 * SUM's front panel, laid out like a console: a strip per channel, named after the instrument feeding it or what the player calls it, with pan,
 * mute, solo and swap, a fader and a meter, then the mix bus fader with its stereo meter. A plugged-in strip's name goes to the device it names.
 */
export declare function MixerConsole({ module, patch, mix, levels, onParams, onToggle, onSwap, onGoTo }: {
    module: RackModule;
    patch: Patch;
    mix: Mix;
    levels: MixerLevels;
    onParams: (values: Record<string, number>) => void;
    onToggle: MixToggle;
    onSwap: (key: string) => void;
    onGoTo: (id: string) => void;
}): import("react").JSX.Element;
