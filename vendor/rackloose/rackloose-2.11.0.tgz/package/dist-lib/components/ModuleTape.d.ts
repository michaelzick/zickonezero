import { type RackModule } from '../model';
/**
 * A device's printed name and subtitle, with the strip of masking tape the player names it on. Clicking the name or the
 * tape writes on it: Enter or leaving keeps the text as one undo step, Escape keeps what was there, and the × or a blank
 * name peels the tape off. MAIN is never cabled into anything, so it has no tape.
 */
export declare function ModuleTape({ module, slot, onName }: {
    module: RackModule;
    slot: number;
    onName: (text: string) => void;
}): import("react").JSX.Element;
