import type { DrumKit } from './drums';
/** Original drum models printed to low-rate, companded 8-bit-style PCM. No recordings or external assets. */
export declare function strikeSample(voice: string): Float32Array;
export declare function createStrike(context: BaseAudioContext, bus: AudioNode): DrumKit;
