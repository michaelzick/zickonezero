export declare function createStudio(context: BaseAudioContext, type: 'cohere' | 'talon' | 'brit', keep: <T extends AudioNode>(node: T) => T, onError?: (error: Error) => void): {
    reduction: number;
    apply(params: Record<string, number>): void;
    flush(): Promise<void>;
    dispose(): void;
    input: AudioWorkletNode;
    output: AudioWorkletNode;
};
