export { VoicePool } from './poly';
/** Five Prophet-style voices built from native nodes, so live and offline rendering share the same sound. */
type Params = Record<string, number>;
type Host = {
    keep: <T extends AudioNode>(node: T) => T;
    source: <T extends OscillatorNode | ConstantSourceNode | AudioBufferSourceNode>(node: T) => T;
};
export declare function createOracle(context: BaseAudioContext, noiseBuffer: AudioBuffer, { keep, source }: Host): {
    pitch: GainNode;
    cv: GainNode;
    output: GainNode;
    apply(p: Params): void;
    /** Starts one voice per chord note. A key already sounding is released first, so a held key never stacks. */
    noteOn(note: number, velocity: number, time: number, key: string): void;
    noteOff: (time: number, key?: string) => void;
};
