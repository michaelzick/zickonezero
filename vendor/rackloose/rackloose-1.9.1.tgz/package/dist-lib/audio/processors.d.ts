/** VALVE and CONSOLE: dynamics and EQ from native nodes, shared by live playback and offline export. */
type Params = Record<string, number>;
type Host = {
    keep: <T extends AudioNode>(node: T) => T;
};
/** Fairchild time constants 1 to 6. Web Audio caps release at one second, so the slow settings are scaled into it. */
export declare const VALVE_TIMES: number[][];
/**
 * The automatic make-up gain a DynamicsCompressorNode adds, from the static curve in the Web Audio spec. VALVE divides
 * it back out so a signal under the threshold passes at unity and Output alone sets the level.
 */
export declare function compressorMakeup(threshold: number, knee: number, ratio: number): number;
export declare function createValve(context: BaseAudioContext, { keep }: Host): {
    input: GainNode;
    output: GainNode;
    compressor: DynamicsCompressorNode;
    apply(p: Params): void;
};
export type Band = {
    type: BiquadFilterType;
    frequency: number;
    Q: number;
    gain: number;
};
/**
 * CONSOLE's six filters in signal order. The high- and low-pass filters are Butterworth (Web Audio reads their Q in
 * dB); fully anticlockwise and fully clockwise they sit at 0 Hz and Nyquist, where a biquad passes everything.
 */
export declare function consoleBands(p: Params, nyquist: number): Band[];
/** A band's gain in dB at `f`, from the biquad formulas in the Web Audio spec, so the drawn curve matches the sound. */
export declare function biquadResponse({ type, frequency, Q, gain }: Band, f: number, sampleRate: number): number;
export declare function createConsole(context: BaseAudioContext, { keep }: Host): {
    input: GainNode;
    output: GainNode;
    apply(p: Params): void;
};
export {};
