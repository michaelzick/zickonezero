/**
 * iOS gives Web Audio the "ambient" audio session unless told otherwise, and the Ring/Silent switch mutes that session, so an iPhone in
 * Silent mode played nothing. An instrument plays like a music app instead: through Silent mode, pausing other apps' audio. Browsers
 * without the Audio Session API are unaffected. Returns a function that puts the previous type back.
 */
export declare function claimPlayback(): () => void;
