type Params = Record<string, number>;
type Host = {
    keep: <T extends AudioNode>(node: T) => T;
    source: <T extends OscillatorNode | ConstantSourceNode | AudioBufferSourceNode>(node: T) => T;
};
export declare function createMonarch(context: BaseAudioContext, noiseBuffer: AudioBuffer, { keep, source }: Host): {
    pitch: GainNode;
    cv: GainNode;
    output: GainNode;
    apply(p: Params): void;
    noteOn(velocity: number, time: number): void;
    noteOff(time: number): void;
};
export {};
