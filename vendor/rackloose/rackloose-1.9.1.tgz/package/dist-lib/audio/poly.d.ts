/** Common instrument ports and timestamped note lifecycle. */
export type PolyInstrument = {
    pitch: AudioNode | AudioParam;
    cv: AudioNode | AudioParam;
    output: AudioNode;
    apply: (params: Record<string, number>) => void;
    noteOn: (note: number, velocity: number, time: number, key: string) => void;
    noteOff: (time: number, key?: string) => void;
    flush?: () => Promise<void>;
    dispose?: () => void;
};
export type SynthHost = {
    onError?: (error: Error) => void;
    keep: <T extends AudioNode>(node: T) => T;
    source: <T extends OscillatorNode | ConstantSourceNode | AudioBufferSourceNode>(node: T) => T;
};
/**
 * Connects `from` to `to` only while it is `used`, so a costly node nothing listens to (an oversampled pulse shaper
 * behind a closed level) is not rendered at all. Going unused waits for that level to fade before disconnecting;
 * `initial` disconnects at once, before any sound.
 */
export declare function switchable(from: AudioNode, to: AudioNode): (used: boolean, initial: boolean) => void;
type Slot = {
    key: string | null;
    start: number;
    releaseAt: number;
    freeAt: number;
};
/**
 * Chooses voices from scheduled times alone, so an offline render, where every note is queued up front, allocates
 * exactly as live playback does. A new note takes the voice that has been silent longest, then the one released
 * longest ago, and only then steals the oldest held note.
 */
export declare class VoicePool {
    readonly voices: Slot[];
    constructor(size?: number);
    allocate(time: number, taken?: ReadonlySet<number>): number;
    start(index: number, key: string, time: number): void;
    /** Releases held voices, all or one key's, including notes scheduled to start after `time`. */
    release(time: number, tail: number, key?: string): {
        index: number;
        pending: boolean;
    }[];
}
export {};
