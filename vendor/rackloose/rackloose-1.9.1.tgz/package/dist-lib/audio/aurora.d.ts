import { type SynthHost, type PolyInstrument } from './poly';
/** Eight independent dual-VCO voices. Pitch is sampled on note-on; modulation CV remains continuous. */
export declare function createAurora(context: BaseAudioContext, { keep, source }: SynthHost): PolyInstrument;
