/**
 * A linear ADSR on `param` that remembers the breakpoints it scheduled, so every attack and release starts from the exact
 * level it interrupts. Web Audio alone holds a finished ramp's last event, which would start a release from the end of
 * the decay instead of the key-up; and dropping to zero to retrigger a ringing note pops like clipping.
 */
export declare function linearEnvelope(param: AudioParam): {
    on(time: number, velocity: number, attack: number, decay: number, sustain: number): void;
    off(time: number, release: number): void;
};
