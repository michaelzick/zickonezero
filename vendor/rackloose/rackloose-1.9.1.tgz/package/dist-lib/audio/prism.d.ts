export { prepareAudio } from './worklets';
import type { PolyInstrument, SynthHost } from './poly';
export declare function createPrism(context: BaseAudioContext, { keep, onError }: SynthHost): PolyInstrument;
