type Event = {
    type: 'set' | 'ramp' | 'target';
    time: number;
    value: number;
    constant: number;
};
/** The level `events` give at `time`, following Web Audio's rules for the three event types Rackloose schedules. */
export declare function levelAt(events: Event[], base: number, time: number): number;
/**
 * Lets `holdAt` stop `param` exactly where it would be at a future time in browsers without `cancelAndHoldAtTime`
 * (Firefox), by recording this one param's automation. Does nothing where the method exists; never touches the prototype.
 * Given `context`, events more than a second in the past are folded into the starting level, so a long session's
 * history stays short; nothing is ever scheduled or held that far back.
 */
export declare function holdable<T extends AudioParam>(param: T, context?: {
    readonly currentTime: number;
}): T;
/**
 * `cancelAndHoldAtTime`, which Firefox lacks. There a `holdable` param stops at its scheduled level at `time`; any other
 * param holds its current value, which is exact only for `time` at or near the present.
 */
export declare function holdAt(param: AudioParam, time: number): void;
/** The automation events `holdable` has recorded for `param`, for tests. */
export declare const recordedEvents: (param: AudioParam) => readonly Event[];
export {};
