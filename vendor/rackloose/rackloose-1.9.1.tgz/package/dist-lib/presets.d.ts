import { type Patch } from './model';
/** A patch kept in My Presets. Its name is the patch's own name, which is unique among the user's presets. */
export type SavedPreset = {
    id: string;
    savedAt: number;
    patch: Patch;
};
export declare const PRESET_LIMIT = 200;
export declare const STORAGE_ERROR = "This browser could not save to My Presets. Export a file to keep your work.";
/** Reads My Presets. Storage is untrusted: entries that fail validation are left out, and a corrupt list reads as empty. */
export declare function readPresets(storage: Pick<Storage, 'getItem'>, key: string): {
    presets: SavedPreset[];
    error: string | null;
};
export declare function writePresets(storage: Pick<Storage, 'setItem'>, key: string, presets: SavedPreset[]): string | null;
/** Adds `entry`, or replaces the preset with its id. Any other preset with the same name is replaced too, so names stay unique. */
export declare function storePreset(presets: SavedPreset[], entry: SavedPreset): SavedPreset[];
/** The user preset called `name`, ignoring case and surrounding spaces, other than `exceptId`. */
export declare const presetNamed: (presets: SavedPreset[], name: string, exceptId?: string) => SavedPreset | undefined;
/** `name`, or `name (2)`, `name (3)`… when it is taken, always within the 100 characters a patch name allows. */
export declare function availableName(presets: SavedPreset[], name: string): string;
/** A file name stem for a patch, e.g. `Dub Rack!` → `dub-rack`. */
export declare function fileStem(name: string): string;
