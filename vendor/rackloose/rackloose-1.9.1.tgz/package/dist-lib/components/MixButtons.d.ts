import type { Mix } from '../model';
export type MixToggle = (key: string, kind: 'muted' | 'soloed') => void;
/**
 * Mute and solo toggles for one module, drum voice or step. `solo` is false where soloing means nothing, as on MAIN.
 * `onClear` adds a button that resets every mute and solo inside a module; `clearable` enables it.
 */
export declare function MixButtons({ mixKey, label, mix, onToggle, solo, onClear, clearable }: {
    mixKey: string;
    label: string;
    mix: Mix;
    onToggle: MixToggle;
    solo?: boolean;
    onClear?: () => void;
    clearable?: boolean;
}): import("react").JSX.Element;
