import { type Patch, type PresetName } from '../model';
import { type SavedPreset } from '../presets';
type BrowserProps = {
    presets: SavedPreset[];
    openId: string | null;
    dirty: boolean;
    onLoad: (preset: SavedPreset) => void;
    onLoadFactory: (name: PresetName) => void;
    onExport: (patch: Patch) => void;
    onDelete: (preset: SavedPreset) => void;
    onSaveAs: (opener: HTMLElement) => void;
    onImport: () => void;
    onExportCurrent: () => void;
    onClose: () => void;
};
/** My Presets, kept in this browser, above the factory presets. Only the user's own presets can be exported one by one or deleted. */
export declare function PresetBrowser({ presets, openId, dirty, onLoad, onLoadFactory, onExport, onDelete, onSaveAs, onImport, onExportCurrent, onClose }: BrowserProps): import("react").JSX.Element;
/** Names a preset before saving it. A name already in My Presets turns Save into Replace. */
export declare function SavePresetDialog({ initialName, presets, onSave, onCancel }: {
    initialName: string;
    presets: SavedPreset[];
    onSave: (name: string) => void;
    onCancel: () => void;
}): import("react").JSX.Element;
export {};
