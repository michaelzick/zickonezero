/** A typed tempo with a small slider under it; both change the tempo as they move. */
export declare function TempoInput({ bpm, onChange }: {
    bpm: number;
    onChange: (bpm: number) => void;
}): import("react").JSX.Element;
