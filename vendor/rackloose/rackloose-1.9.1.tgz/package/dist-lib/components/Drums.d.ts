import { type Mix, type RackModule } from '../model';
import { type MixToggle } from './MixButtons';
/** `onParams` changes one or more of the module's params as a single edit. */
type DrumProps = {
    module: RackModule;
    mix: Mix;
    onMix: MixToggle;
    onParams: (values: Record<string, number>) => void;
    onAudition: (voice: string) => void;
    disabled?: boolean;
};
/** One lane of 16 pads per voice, in groups of four. The voice name auditions it; `step` lights the playhead. */
export declare function DrumPads({ module, mix, onMix, step, onParams, onAudition, disabled }: DrumProps & {
    step: number;
}): import("react").JSX.Element;
/** Six rhythm lanes plus the sound and step editor for the selected lane. */
export declare function EuclidMatrix({ module, mix, onMix, onParams, onAudition, disabled, clock }: DrumProps & {
    clock: number;
}): import("react").JSX.Element;
/** Concentric rings, outermost first: one dot per step, large dots for hits, and the playhead glowing at `clock`. */
export declare function OrbitRings({ module, clock }: {
    module: RackModule;
    clock: number;
}): import("react").JSX.Element;
export {};
