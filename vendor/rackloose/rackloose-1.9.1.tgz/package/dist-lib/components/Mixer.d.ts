import { type Mix, type Patch, type RackModule } from '../model';
import type { MixerLevels } from '../audio/engine';
import { type MixToggle } from './MixButtons';
/** A vertical ladder of LEDs: green, amber from −9 dBFS and red from −3. */
export declare function LevelMeter({ level, label }: {
    level: number;
    label: string;
}): import("react").JSX.Element;
/**
 * SUM's front panel, laid out like a console: a strip per channel, named after the instrument feeding it, with pan,
 * mute and solo, a fader and a meter, then the mix bus fader with its stereo meter.
 */
export declare function MixerConsole({ module, patch, mix, levels, onParams, onToggle }: {
    module: RackModule;
    patch: Patch;
    mix: Mix;
    levels: MixerLevels;
    onParams: (values: Record<string, number>) => void;
    onToggle: MixToggle;
}): import("react").JSX.Element;
