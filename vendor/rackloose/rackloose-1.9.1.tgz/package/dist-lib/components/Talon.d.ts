import { type RackModule } from '../model';
type ControlProps = {
    module: RackModule;
    onParams: (values: Record<string, number>) => void;
};
/**
 * TALON's front panel in the manner of a vintage hardware compressor: big black knobs for input and output, smaller ones
 * for the time constants, lamp selectors for ratio and harmonics, latching buttons for the filters and link, a lamp
 * meter and an IN switch.
 */
export declare function TalonPanel({ module, onParams, reduction, label }: ControlProps & {
    reduction: number;
    label: string;
}): import("react").JSX.Element;
export {};
