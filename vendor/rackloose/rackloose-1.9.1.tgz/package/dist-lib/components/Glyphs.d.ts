import { type Param } from '../model';
export declare function ChoiceGlyph({ param, value }: {
    param: Param;
    value: number;
}): import("react").JSX.Element | null;
/** CONSOLE's summed response from 20 Hz to 20 kHz over ±18 dB, from the same band settings the audio uses. */
export declare function EqGraphic({ params, brit, rate }: {
    params: Record<string, number>;
    brit?: boolean;
    rate?: number;
}): import("react").JSX.Element;
/** VALVE's needle swings left from 0 to 20 dB of gain reduction, pivoting below the window like a VU meter. */
export declare function GainReductionMeter({ reduction, label, max }: {
    reduction: number;
    label: string;
    max?: number;
}): import("react").JSX.Element;
export declare function EnvelopeGraphic({ params }: {
    params: Record<string, number>;
}): import("react").JSX.Element;
declare const ICONS: {
    play: import("react").JSX.Element;
    pause: import("react").JSX.Element;
    stop: import("react").JSX.Element;
    reset: import("react").JSX.Element;
    undo: import("react").JSX.Element;
    redo: import("react").JSX.Element;
};
/** A 14-unit icon drawn in the button's text color. */
export declare function Icon({ name }: {
    name: keyof typeof ICONS;
}): import("react").JSX.Element;
export {};
