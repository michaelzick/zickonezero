import { type HTMLAttributes, type ReactNode } from 'react';
import { type Param } from '../model';
type KnobProps = {
    param: Param;
    value: number;
    onChange: (value: number) => void;
    prefix?: string;
    format?: (value: number) => string;
    trim?: boolean;
    disabled?: boolean;
    caption?: ReactNode;
};
/** A param's value as its readout shows it, such as 1.6k, 50μs or 2.5dB. A choice shows its label. */
export declare function displayValue(param: Param, value: number): string;
/**
 * Everything a rotary control does, for any dial artwork: vertical drag, arrow keys, Home and End, double-click to
 * reset, and the slider semantics. A choice param turns in detents, one per choice. `travel` is how far, in pixels,
 * a drag goes from minimum to maximum; a fader sets it to its slot's length so the cap follows the pointer.
 */
export declare function useDial({ param, value, onChange, prefix, format, disabled, travel }: Omit<KnobProps, 'trim' | 'caption'> & {
    travel?: number;
}): {
    props: HTMLAttributes<HTMLDivElement> & {
        'aria-valuemin': number;
        'aria-valuemax': number;
        'aria-valuenow': number;
    };
    fraction: number;
    display: string;
};
/**
 * A rotary control. `trim` renders the small attenuator used beside CV inputs, without a label or readout. `caption`
 * replaces the label shown above the dial, leaving its accessible name as the param's label.
 */
export declare function Knob({ param, value, onChange, prefix, format, trim, disabled, caption }: KnobProps): import("react").JSX.Element;
export {};
