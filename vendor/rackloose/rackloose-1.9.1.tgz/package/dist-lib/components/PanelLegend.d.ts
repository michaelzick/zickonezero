export type Mark = {
    angle: number;
    text?: string;
    lit?: boolean;
};
/** The legend printed on a panel around a control: a tick at each detent or division, and its values. */
export declare function PanelLegend({ size, height, inner, marks }: {
    size: number;
    height: number;
    inner: number;
    marks: Mark[];
}): import("react").JSX.Element;
