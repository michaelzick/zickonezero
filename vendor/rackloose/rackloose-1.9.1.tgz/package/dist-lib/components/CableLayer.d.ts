import { type RefObject } from 'react';
import { type Endpoint, type Patch } from '../model';
type Point = {
    x: number;
    y: number;
};
/** A cable in hand: `anchor` stays plugged in, `point` is the pointer in rack content coordinates, `cableId` names a lifted cable. */
export type CableDrag = {
    anchor: Endpoint;
    cableId: string | null;
    point: Point;
    target: Endpoint | null;
    candidate?: Endpoint | null;
    error?: string | null;
    inside?: boolean;
};
type CableLayerProps = {
    patch: Patch;
    rackRef: RefObject<HTMLDivElement | null>;
    selected: string | null;
    onSelect: (id: string) => void;
    drag: CableDrag | null;
};
/**
 * Draws cables in front of the panels, hanging over jacks and printed legends as real patch cords do. Their hit areas
 * sit in a layer below the sockets, so a jack under a cable can still be patched, and a cable is picked up anywhere else.
 */
export declare function CableLayer({ patch, rackRef, selected, onSelect, drag }: CableLayerProps): import("react").JSX.Element;
export {};
