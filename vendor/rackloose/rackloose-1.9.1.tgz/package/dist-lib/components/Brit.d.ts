import { type RackModule } from '../model';
/**
 * BRIT's front panel in the manner of a classic British console channel: a blue stepped high-pass, dual-concentric
 * low and mid bands with grey frequency rings, a grey 12 kHz shelf, the big red drive and an EQ push switch.
 */
export declare function BritPanel({ module, onParams, rate }: {
    module: RackModule;
    onParams: (values: Record<string, number>) => void;
    rate: number;
}): import("react").JSX.Element;
