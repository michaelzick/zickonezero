import { type RackModule } from '../model';
type EditorProps = {
    module: RackModule;
    onParams: (values: Record<string, number>) => void;
};
export declare function StrikeEditor({ module, onParams, onAudition, disabled }: EditorProps & {
    onAudition: (voice: string) => void;
    disabled?: boolean;
}): import("react").JSX.Element;
export declare function PrismEditor({ module, onParams }: EditorProps): import("react").JSX.Element;
export {};
