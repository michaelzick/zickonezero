import { type ReactNode } from 'react';
import type { MixerLevels } from '../audio/engine';
/** Readings polled from the engine every frame: hit LEDs, the output meter, gain reduction and SUM's meters. */
export type LiveReadings = {
    pulsing: ReadonlySet<string>;
    meter: number;
    reductions: Record<string, number>;
    mixerLevels: Record<string, MixerLevels>;
};
export type LiveStore = {
    get: () => LiveReadings;
    set: (changes: Partial<LiveReadings>) => void;
    subscribe: (listener: () => void) => () => void;
};
/**
 * Holds the live readings outside React state, so a meter moving redraws only that meter, not the whole rack. Setting
 * a reading to the same object it already holds changes nothing.
 */
export declare function createLiveStore(): LiveStore;
export declare const LiveContext: import("react").Context<LiveStore | null>;
/** Renders `children` with one live reading. `select` must return the same value while the reading is unchanged. */
export declare function Live<T>({ select, children }: {
    select: (readings: LiveReadings) => T;
    children: (value: T) => ReactNode;
}): import("react").JSX.Element;
