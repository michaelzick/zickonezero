export declare const HISTORY_LIMIT = 50;
/** How long after a change another change with the same key still joins it, so a knob turn or a typed word is one step. */
export declare const MERGE_WINDOW = 1000;
/** Undo and redo stacks of whole snapshots. `key` and `at` describe the last recorded change, for merging. */
export type History<T> = {
    past: T[];
    future: T[];
    key: string | null;
    at: number;
};
export declare const emptyHistory: <T>() => History<T>;
/**
 * Records `before`, the state a change replaced. A change with the same `key` as the previous one, made within
 * MERGE_WINDOW of it and with nothing undone since, joins that step instead. New changes clear redo.
 */
export declare function record<T>(history: History<T>, before: T, key: string | null, now: number): History<T>;
/** Steps back from `current`, or returns null when there is nothing to undo. */
export declare function undo<T>(history: History<T>, current: T): {
    history: History<T>;
    state: T;
} | null;
/** Reapplies the last undone step, or returns null when there is nothing to redo. */
export declare function redo<T>(history: History<T>, current: T): {
    history: History<T>;
    state: T;
} | null;
