import type { Patch } from './model';
export { RETRO_PRESETS } from './model';
type Name = typeof import('./model').RETRO_PRESETS[number];
/**
 * Six originals from the 1980s: synthwave, boogie, a slow jam, new wave, an arcade theme and a Balearic sunrise. AURORA,
 * PRISM and MONARCH split the parts, STRIKE plays the drum machine, and each mix runs into COHERE.
 */
export declare function retroPreset(name: Name): Patch;
