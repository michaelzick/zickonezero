import type { Patch } from './model';
export { GROOVE_PRESETS } from './model';
type Name = typeof import('./model').GROOVE_PRESETS[number];
/**
 * Nine grooves from funk, disco, hip-hop, reggae, dub, R&B, broken beat and percussion. Each is an original part
 * written for its style, and each processes its tracks the way that style's records were: TALON on drums, BRIT or
 * CONSOLE on the part that needs colour, and VALVE or COHERE on the mix bus.
 */
export declare function groovePreset(name: Name): Patch;
