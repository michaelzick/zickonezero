"use client";
import { Fragment as e, createContext as t, useCallback as n, useContext as r, useEffect as i, useId as a, useLayoutEffect as o, useMemo as s, useReducer as c, useRef as l, useState as u, useSyncExternalStore as d } from "react";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
//#region src/presetKit.ts
var h = (e) => [...e].reduce((e, t, n) => t === "x" ? e | 1 << n : e, 0), g = (e, t, n) => [...e].map((e, r) => ({
	note: t[r],
	enabled: e !== ".",
	velocity: e === "X" ? 1 : e === "o" ? .5 : .74,
	gate: typeof n == "number" ? n : n[r]
})), _ = (...e) => e.flatMap(([e, t]) => Array(t).fill(e)), v = (e) => Number((45 / e).toFixed(3)), y = (...e) => Object.fromEntries(Array.from({ length: 6 }, (t, n) => {
	let [r, i, a, o, s, c, l] = e[n] ?? [
		1,
		0,
		0,
		.005,
		.3,
		0,
		.2
	];
	return Object.entries({
		Ratio: r,
		Detune: i,
		Level: a,
		Attack: o,
		Decay: s,
		Sustain: c,
		Release: l
	}).map(([e, t]) => [`op${n + 1}${e}`, t]);
}).flat()), b = {
	epiano: y([
		1,
		0,
		.85,
		.002,
		1.8,
		.12,
		.7
	], [
		1,
		0,
		.45,
		.002,
		1,
		.05,
		.5
	], [
		1,
		4,
		.45,
		.002,
		1.4,
		.1,
		.6
	], [
		14,
		0,
		.2,
		.002,
		.12,
		0,
		.1
	], [
		1,
		-4,
		.35,
		.002,
		1.6,
		.1,
		.6
	], [
		1,
		0,
		.12,
		.002,
		.6,
		0,
		.3
	]),
	bell: y([
		1,
		0,
		.8,
		.002,
		2.2,
		0,
		1.4
	], [
		3.5,
		0,
		.5,
		.002,
		1.4,
		0,
		1
	], [
		2,
		3,
		.35,
		.002,
		1.5,
		0,
		1
	], [
		7,
		0,
		.3,
		.002,
		.6,
		0,
		.5
	], [
		4,
		0,
		.12,
		.002,
		.9,
		0,
		.6
	], [
		10.5,
		0,
		.15,
		.002,
		.3,
		0,
		.3
	]),
	reed: y([
		1,
		0,
		.8,
		.03,
		.4,
		.8,
		.25
	], [
		2,
		0,
		.5,
		.03,
		.5,
		.6,
		.3
	], [
		1,
		6,
		.3,
		.03,
		.4,
		.8,
		.25
	], [
		2,
		0,
		.3,
		.03,
		.5,
		.5,
		.3
	]),
	kalimba: y([
		1,
		0,
		.85,
		.002,
		.7,
		0,
		.4
	], [
		3,
		0,
		.35,
		.002,
		.08,
		0,
		.08
	], [
		1,
		5,
		.4,
		.002,
		.5,
		0,
		.3
	], [
		7,
		0,
		.18,
		.002,
		.04,
		0,
		.04
	]),
	slap: y([
		1,
		0,
		.9,
		.002,
		.35,
		.25,
		.08
	], [
		1,
		0,
		.65,
		.002,
		.15,
		.05,
		.06
	], [
		1,
		3,
		.5,
		.002,
		.3,
		.2,
		.08
	], [
		3,
		0,
		.35,
		.002,
		.05,
		0,
		.04
	], [
		.5,
		0,
		.35,
		.002,
		.4,
		.3,
		.08
	], [
		.5,
		0,
		.1,
		.002,
		.2,
		0,
		.06
	]),
	bass: y([
		1,
		0,
		.9,
		.002,
		.4,
		.3,
		.1
	], [
		1,
		0,
		.55,
		.002,
		.25,
		.1,
		.08
	], [
		.5,
		0,
		.5,
		.002,
		.5,
		.4,
		.1
	], [
		1,
		0,
		.2,
		.002,
		.15,
		0,
		.08
	]),
	pluck: y([
		1,
		0,
		.8,
		.002,
		.45,
		0,
		.3
	], [
		2,
		0,
		.4,
		.002,
		.15,
		0,
		.1
	], [
		2,
		3,
		.35,
		.002,
		.35,
		0,
		.25
	], [
		5,
		0,
		.2,
		.002,
		.06,
		0,
		.05
	])
};
function x(e, t, n, r, i) {
	let a = {
		version: 1,
		name: e,
		modules: Object.entries(r).map(([e, { type: t, params: n, lanes: r, euclid: i, steps: a }], o) => {
			let s = ve(t, e), c = I[t].drum?.voices ?? [];
			if (r) for (let e of c) s.params[`${e.id}Pattern`] = h(r[e.id] ?? "");
			if (i) for (let e of c) {
				let [t, n, r = 0] = i[e.id] ?? [0, s.params[`${e.id}Steps`]];
				Object.assign(s.params, {
					[`${e.id}Hits`]: t,
					[`${e.id}Steps`]: n,
					[`${e.id}Shift`]: r
				});
			}
			return Object.assign(s.params, n), a && o > 0 ? {
				...s,
				steps: a
			} : s;
		}),
		cables: [],
		sequencer: {
			bpm: t,
			swing: n,
			steps: Object.values(r)[0].steps
		}
	};
	for (let [e, t, n, r, o] of i) a = Ee(a, {
		moduleId: e,
		portId: t
	}, {
		moduleId: n,
		portId: r
	}, o);
	return a;
}
var S = (e, t, n = "") => [[
	e,
	`pitch${n}`,
	t,
	"pitch"
], [
	e,
	`gate${n}`,
	t,
	"gate"
]], C = (...e) => e.slice(1).map((t, n) => [
	e[n],
	"out",
	t,
	"in"
]), w = (e, t, ...n) => [...e.flatMap((e, n) => [...C(...e), [
	e.at(-1),
	"out",
	t,
	"abcdefgh"[n]
]]), ...C(t, ...n)], T = (e, ...t) => w(e, "mixer", ...t, "output");
function E(e) {
	return e === "Vintage Bass" ? x(e, 94, .1, {
		performance: {
			type: "performance",
			steps: g("X..o.xx.X..x.xx.", [
				43,
				43,
				43,
				43,
				43,
				46,
				48,
				48,
				36,
				36,
				36,
				48,
				48,
				46,
				41,
				41
			], [
				.9,
				.5,
				.5,
				.5,
				.5,
				.6,
				.9,
				.5,
				.9,
				.5,
				.5,
				.45,
				.5,
				.6,
				.9,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Wave: 3,
				osc2Detune: 4,
				osc2Level: .4,
				osc3Wave: 1,
				osc3Level: .55,
				cutoff: 480,
				resonance: .3,
				drive: .3,
				envAmount: .45,
				filterAttack: .004,
				filterDecay: .25,
				filterSustain: .25,
				filterRelease: .15,
				ampAttack: .004,
				ampDecay: .4,
				ampSustain: .8,
				ampRelease: .08,
				glide: .04,
				level: .75
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 2,
				midFreq: 1,
				midGain: 3,
				drive: 6
			}
		},
		melody: {
			type: "performance",
			steps: g("x".repeat(16), _([86, 6], [84, 1], [82, 1], [79, 6], [77, 1], [79, 1]), .95)
		},
		whistle: {
			type: "monarch",
			params: {
				osc1Wave: 0,
				osc1Level: .9,
				osc2Level: 0,
				osc3Level: 0,
				cutoff: 6e3,
				resonance: 0,
				drive: 0,
				envAmount: 0,
				tracking: 0,
				ampAttack: .03,
				ampDecay: .3,
				ampSustain: 1,
				ampRelease: .3,
				glide: .12,
				level: .5
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(94),
				feedback: .35,
				mix: .25
			}
		},
		chords: {
			type: "performance",
			steps: g("x.......x.......", _([55, 8], [60, 8]), .95)
		},
		keys: {
			type: "aurora",
			params: {
				osc1Wave: 2,
				osc2Wave: 1,
				osc2Detune: 8,
				blend: .45,
				cutoff: 1600,
				resonance: .1,
				envAmount: .2,
				filterAttack: .05,
				filterDecay: .8,
				filterSustain: .4,
				ampAttack: .04,
				ampDecay: .9,
				ampSustain: .7,
				ampRelease: 1.6,
				lfoWidth: .3,
				chord: 4,
				vintage: .4,
				level: .6
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 1.8,
				mix: .25
			}
		},
		drums: {
			type: "strike",
			params: {
				level: 1,
				kickDecay: .4,
				snareTune: -2,
				snareDecay: .3,
				clapLevel: .55,
				hatDecay: .06,
				hatLevel: .45,
				hatPan: .2,
				openLevel: .4,
				openPan: .2,
				tambourineLevel: .3,
				tambourinePan: -.3
			},
			lanes: {
				kick: "x......xx.x.....",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "x.xxx.x.x.xxx.x.",
				open: ".....x.......x..",
				tambourine: "....x.......x..."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .01,
				release: .15,
				color: 1,
				detectorHp: 1,
				output: 7
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: .6,
				c: .7,
				d: .7
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 0,
				attack: 4,
				release: 4,
				output: 2
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("performance", "monarch"),
		...S("melody", "whistle"),
		...S("chords", "keys"),
		...T([
			["drums", "talon"],
			["monarch", "brit"],
			["keys", "space"],
			["whistle", "echo"]
		], "cohere")
	]) : e === "Vintage Lead" ? x(e, 120, 0, {
		performance: {
			type: "performance",
			steps: g("X.xx.xx.X.xxX.xx", [
				76,
				76,
				76,
				74,
				74,
				72,
				74,
				74,
				72,
				72,
				69,
				72,
				71,
				71,
				67,
				71
			], .7)
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 3,
				osc1Level: .7,
				osc2Detune: 9,
				osc2Level: .5,
				osc3Wave: 3,
				osc3Octave: 1,
				osc3Level: .2,
				cutoff: 2600,
				resonance: .25,
				drive: .2,
				envAmount: .35,
				tracking: .6,
				filterDecay: .2,
				filterSustain: .4,
				ampAttack: .004,
				ampDecay: .25,
				ampSustain: .7,
				ampRelease: .15,
				glide: .025,
				level: .6
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(120),
				feedback: .3,
				mix: .22
			}
		},
		octaves: {
			type: "performance",
			steps: g("XxXxXxXxXxXxXxXx", [
				33,
				45,
				33,
				45,
				33,
				45,
				33,
				45,
				29,
				41,
				29,
				41,
				31,
				43,
				31,
				43
			], .5)
		},
		bass: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Detune: 6,
				osc2Level: .4,
				osc3Level: .3,
				cutoff: 600,
				resonance: .3,
				envAmount: .5,
				filterDecay: .12,
				filterSustain: .3,
				ampAttack: .002,
				ampDecay: .15,
				ampSustain: .5,
				ampRelease: .05,
				level: .7
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 1,
				lfGain: 2,
				midFreq: 3,
				midGain: 2,
				drive: 6
			}
		},
		chords: {
			type: "performance",
			steps: g("x.......x...x...", _([57, 8], [50, 4], [52, 4]), .95)
		},
		strings: {
			type: "aurora",
			params: {
				osc2Wave: 0,
				osc2Detune: 12,
				hpf: 200,
				cutoff: 3e3,
				envAmount: .15,
				filterAttack: .1,
				filterDecay: .8,
				filterSustain: .6,
				ampAttack: .08,
				ampDecay: .6,
				ampSustain: .8,
				ampRelease: 1.2,
				lfoRate: .5,
				lfoWidth: .2,
				chord: 2,
				vintage: .4,
				level: .7
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2,
				mix: .3
			}
		},
		drums: {
			type: "boom",
			params: {
				kickTune: 52,
				kickDecay: .5,
				snareTone: .55,
				snappy: .7,
				hatDecay: .04,
				openDecay: .25,
				level: .85
			},
			lanes: {
				kick: "x...x...x...x...",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "xx.xxx.xxx.xxx.x",
				open: "..x...x...x...x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .003,
				release: .1,
				color: 1,
				detectorHp: 1,
				output: 5
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: .75,
				c: 1,
				d: .45
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 1,
				attack: 4,
				release: 1,
				output: 2
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("performance", "monarch"),
		...S("octaves", "bass"),
		...S("chords", "strings"),
		...T([
			["drums", "talon"],
			["bass", "brit"],
			["strings", "space"],
			["monarch", "echo"]
		], "cohere")
	]) : e === "Boom Bap" ? x(e, 84, .18, {
		performance: {
			type: "performance",
			steps: g("X.....x.X..x..x.", _([50, 8], [55, 6], [50, 2]), [
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.4,
				.5,
				.95,
				.5,
				.5,
				.4,
				.5,
				.5,
				.6,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 1,
				osc1Octave: -1,
				osc1Level: .8,
				osc2Wave: 0,
				osc2Octave: -1,
				osc2Detune: 0,
				osc2Level: .3,
				osc3Wave: 0,
				osc3Octave: -2,
				osc3Level: .55,
				cutoff: 420,
				resonance: .1,
				drive: .3,
				envAmount: .25,
				tracking: .4,
				filterDecay: .3,
				filterSustain: .3,
				ampAttack: .006,
				ampDecay: .5,
				ampSustain: .75,
				ampRelease: .12,
				glide: .03,
				level: .8
			}
		},
		delay: {
			type: "delay",
			params: {
				time: v(84),
				feedback: .3,
				mix: .18
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 50,
				kickDecay: .55,
				snareTone: .4,
				snappy: .45,
				hatDecay: .05,
				level: .85
			},
			lanes: {
				kick: "x.....x...x..x..",
				snare: "....x.......x...",
				hat: "x.x.x.x.x.x.x.xx"
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .8,
				woodTune: 3,
				woodLevel: .4,
				shakerDecay: .08,
				shakerLevel: .5
			},
			euclid: {
				wood: [
					3,
					16,
					3
				],
				shaker: [
					8,
					16,
					1
				]
			}
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .1,
				brightness: .8,
				velocity: .75,
				lfoRate: 4.5,
				lfoDepth: .03,
				chord: 4,
				level: .7,
				...b.epiano
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 3,
				midFreq: 1,
				midGain: 2,
				hfGain: -6,
				drive: 10,
				output: 4
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .006,
				release: .15,
				color: 2,
				detectorHp: 1,
				output: 5
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: .5,
				c: .45,
				d: 1
			}
		},
		valve: {
			type: "compressor",
			params: {
				input: 1,
				threshold: -16,
				time: 1,
				output: 1
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("performance", "monarch"),
		...S("performance", "prism", 3),
		...T([
			["boom", "talon"],
			[
				"prism",
				"brit",
				"delay"
			],
			["monarch"],
			["orbit"]
		], "valve")
	]) : e === "Late Night Hip-Hop" ? x(e, 72, .24, {
		performance: {
			type: "performance",
			steps: g("X.....o.X....x..", _([41, 8], [39, 5], [46, 3]), [
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.95,
				.5,
				.5,
				.5,
				.5,
				.7,
				.5,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 1,
				osc1Level: .8,
				osc2Wave: 0,
				osc2Detune: 0,
				osc2Level: .3,
				osc3Wave: 0,
				osc3Level: .4,
				cutoff: 520,
				resonance: .1,
				drive: .12,
				envAmount: .3,
				filterDecay: .4,
				ampAttack: .008,
				ampDecay: .6,
				ampSustain: .8,
				ampRelease: .25,
				glide: .05,
				level: .8
			}
		},
		chords: {
			type: "performance",
			steps: g("x.......x.....o.", _([57, 8], [55, 8]), .95)
		},
		keys: {
			type: "aurora",
			params: {
				osc1Wave: 1,
				osc1Width: .3,
				osc2Wave: 2,
				osc2Octave: 1,
				blend: .4,
				cutoff: 1400,
				envAmount: .25,
				filterAttack: .01,
				filterDecay: 1.2,
				ampAttack: .06,
				ampDecay: 1.5,
				ampSustain: .6,
				ampRelease: 2,
				lfoWidth: .35,
				lfoFilter: .05,
				chord: 2,
				vintage: .5,
				level: .6
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 3,
				midFreq: 0,
				midGain: -3,
				hfGain: -5,
				drive: 8,
				output: 3
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2.4,
				mix: .3
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 47,
				kickDecay: .7,
				snareTone: .3,
				snappy: .35,
				hatDecay: .04,
				openDecay: .3,
				level: .85
			},
			lanes: {
				kick: "x......x..x.....",
				snare: "....x.......x...",
				rim: "..............x.",
				hat: "..x...x...x...x."
			}
		},
		orbit: {
			type: "orbit",
			params: {
				pitch: -4,
				level: .8,
				shakerLevel: .5
			},
			euclid: { shaker: [
				6,
				16,
				2
			] }
		},
		talon: {
			type: "talon",
			params: {
				input: 4,
				ratio: 5,
				attack: .01,
				release: .4,
				color: 1,
				output: 9
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: .6,
				c: .55,
				d: 1
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 25,
				lpf: 9e3,
				lfGain: 1.5,
				lfFreq: 120,
				lfBell: 1,
				hfGain: -2,
				hfFreq: 6e3
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -18,
				ratio: 0,
				attack: 4,
				release: 4,
				output: 3
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("performance", "monarch"),
		...S("chords", "keys"),
		...T([
			["boom", "talon"],
			["monarch"],
			[
				"keys",
				"brit",
				"space"
			],
			["orbit"]
		], "console", "cohere")
	]) : e === "Roots Reggae" ? x(e, 76, .2, {
		performance: {
			type: "performance",
			steps: g("..X...x.X..x.xx.", [
				33,
				33,
				33,
				33,
				33,
				33,
				36,
				36,
				38,
				38,
				38,
				38,
				38,
				41,
				40,
				40
			], [
				.65,
				.65,
				.85,
				.65,
				.65,
				.65,
				.5,
				.65,
				.85,
				.65,
				.65,
				.45,
				.65,
				.5,
				.85,
				.65
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 1,
				osc1Level: .7,
				osc2Wave: 0,
				osc2Octave: 1,
				osc2Detune: 0,
				osc2Level: .15,
				osc3Wave: 0,
				osc3Octave: 0,
				osc3Level: .5,
				cutoff: 520,
				resonance: .05,
				drive: .15,
				envAmount: .15,
				filterDecay: .3,
				ampAttack: .006,
				ampDecay: .35,
				ampSustain: .7,
				ampRelease: .12,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 3,
				midFreq: 0,
				midGain: -3,
				hfGain: -4,
				drive: 4
			}
		},
		bubble: {
			type: "performance",
			steps: g("..xx..xx..xx..xx", _([57, 8], [50, 8]), .6)
		},
		organ: {
			type: "aurora",
			params: {
				osc1Wave: 1,
				osc2Wave: 3,
				osc2Octave: 1,
				osc2Detune: 0,
				blend: .5,
				cutoff: 2600,
				resonance: 0,
				slope: 0,
				envAmount: 0,
				ampAttack: .003,
				ampDecay: .2,
				ampSustain: .85,
				ampRelease: .04,
				lfoRate: 6,
				lfoPitch: .01,
				lfoWidth: 0,
				chord: 2,
				vintage: .2,
				level: .45
			}
		},
		skank: {
			type: "performance",
			steps: g("....X.......X...", _([69, 8], [62, 8]), .35)
		},
		guitar: {
			type: "oracle",
			params: {
				bShape: 2,
				bFine: 5,
				cutoff: 2800,
				resonance: .2,
				envAmount: .3,
				filterDecay: .12,
				filterSustain: 0,
				ampAttack: .002,
				ampDecay: .14,
				ampSustain: 0,
				ampRelease: .08,
				chord: 2,
				level: 1
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(76),
				feedback: .4,
				mix: .3
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 1.6,
				mix: .22
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 46,
				kickDecay: .6,
				snareTone: .5,
				hatDecay: .05,
				openDecay: .35,
				level: .85
			},
			lanes: {
				kick: "........x.......",
				rim: "........x.......",
				hat: "x.x.x...x.x.x..x",
				open: "......x.......x."
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .8,
				metalDecay: .09,
				metalTone: .7,
				metalLevel: .5,
				sandDecay: .06,
				sandLevel: .55
			},
			euclid: {
				metal: [
					2,
					16,
					4
				],
				sand: [
					2,
					16,
					4
				]
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 1,
				ratio: 2,
				attack: .01,
				release: .25,
				color: 1,
				output: 6
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: 1,
				c: .8,
				d: .7,
				e: .9
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 0,
				attack: 4,
				release: 4,
				output: 2
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("performance", "monarch"),
		...S("bubble", "organ"),
		...S("skank", "guitar"),
		...T([
			["boom", "talon"],
			["orbit"],
			["monarch", "brit"],
			["organ"],
			[
				"guitar",
				"echo",
				"space"
			]
		], "cohere")
	]) : e === "Dub Session" ? x(e, 70, .18, {
		performance: {
			type: "performance",
			steps: g("X..x..x.X..x..x.", [
				28,
				28,
				28,
				28,
				28,
				28,
				31,
				31,
				33,
				33,
				33,
				31,
				31,
				31,
				26,
				26
			], [
				.85,
				.5,
				.5,
				.4,
				.5,
				.5,
				.6,
				.5,
				.85,
				.5,
				.5,
				.5,
				.5,
				.5,
				.7,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 0,
				osc1Level: .7,
				osc2Wave: 1,
				osc2Octave: 1,
				osc2Detune: 0,
				osc2Level: .12,
				osc3Wave: 0,
				osc3Octave: 0,
				osc3Level: .45,
				cutoff: 300,
				resonance: .1,
				drive: .25,
				envAmount: .1,
				ampAttack: .01,
				ampDecay: .4,
				ampSustain: .8,
				ampRelease: .2,
				glide: .02,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 3,
				midFreq: 0,
				midGain: -3,
				hfGain: -8,
				drive: 6
			}
		},
		skank: {
			type: "performance",
			steps: g("....x.......x...", _([64, 16]), .3)
		},
		guitar: {
			type: "oracle",
			params: {
				bShape: 2,
				bFine: 5,
				cutoff: 2400,
				resonance: .2,
				envAmount: .3,
				filterDecay: .12,
				filterSustain: 0,
				ampAttack: .002,
				ampDecay: .15,
				ampSustain: 0,
				ampRelease: .1,
				chord: 2,
				level: 1
			}
		},
		repeats: {
			type: "delay",
			params: {
				time: Number((60 / 70).toFixed(3)),
				feedback: .6,
				mix: .4
			}
		},
		melody: {
			type: "performance",
			steps: g("X.....X.X.X...X.", [
				71,
				71,
				71,
				71,
				71,
				71,
				74,
				74,
				71,
				71,
				69,
				69,
				69,
				69,
				67,
				67
			], .95)
		},
		melodica: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: 0,
				brightness: .9,
				velocity: .5,
				lfoRate: 5,
				lfoDepth: .12,
				level: 1,
				...b.reed
			}
		},
		hall: {
			type: "reverb",
			params: {
				decay: 2.2,
				mix: .3
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 45,
				kickDecay: 1.2,
				snareTone: .35,
				snappy: .5,
				hatDecay: .06,
				openDecay: .5,
				level: .8
			},
			lanes: {
				kick: "x..x......x.....",
				snare: "....x.......x...",
				rim: ".......x........",
				hat: "x.x.x.x.x.x.x...",
				open: "..............x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 3,
				ratio: 2,
				attack: .003,
				release: .2,
				color: 2,
				output: 8
			}
		},
		reverb: {
			type: "reverb",
			params: {
				decay: 1.4,
				mix: .2
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .9,
				skinTune: 5,
				skinDecay: .25,
				skinLevel: 1,
				woodLevel: .5
			},
			euclid: {
				skin: [
					1,
					16,
					12
				],
				wood: [
					2,
					16,
					6
				]
			}
		},
		delay: {
			type: "delay",
			params: {
				time: v(70),
				feedback: .55,
				mix: .45
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: 1,
				c: .7,
				d: 1,
				e: 1
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 0,
				attack: 4,
				release: 4,
				output: 2
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("performance", "monarch"),
		...S("skank", "guitar"),
		...S("melody", "melodica"),
		...T([
			[
				"boom",
				"talon",
				"reverb"
			],
			["orbit", "delay"],
			["monarch", "brit"],
			["guitar", "repeats"],
			["melodica", "hall"]
		], "cohere")
	]) : e === "Trap Soul" ? x(e, 68, .06, {
		performance: {
			type: "performance",
			steps: g("X.......X.....x.", _([53, 8], [58, 8]), [
				.95,
				.65,
				.65,
				.65,
				.65,
				.65,
				.65,
				.65,
				.95,
				.65,
				.65,
				.65,
				.65,
				.65,
				.6,
				.65
			])
		},
		oracle: {
			type: "oracle",
			params: {
				aLevel: .7,
				bLevel: .6,
				bFine: 6,
				noise: .03,
				cutoff: 1300,
				resonance: .12,
				envAmount: .3,
				tracking: .4,
				filterAttack: .005,
				filterDecay: .9,
				filterSustain: .25,
				filterRelease: 1.6,
				ampAttack: .01,
				ampDecay: 1.2,
				ampSustain: .6,
				ampRelease: 2.4,
				lfoRate: .35,
				lfoAmount: .12,
				lfoDest: 2,
				vintage: .45,
				chord: 4,
				level: 1
			}
		},
		equalizer: {
			type: "equalizer",
			params: {
				hpf: 140,
				lmfGain: -3,
				lmfFreq: 380,
				lmfQ: 1.2,
				hmfGain: 2,
				hmfFreq: 2800,
				hmfQ: .8,
				hfGain: 3,
				hfFreq: 9e3,
				lpf: 16e3,
				output: 4
			}
		},
		reverb: {
			type: "reverb",
			params: {
				decay: 2.6,
				mix: .3
			}
		},
		performance2: {
			type: "performance",
			steps: g("X.....x.X..x..x.", [
				53,
				53,
				53,
				53,
				53,
				53,
				53,
				53,
				58,
				58,
				58,
				56,
				56,
				56,
				60,
				60
			], [
				.95,
				.65,
				.65,
				.65,
				.65,
				.65,
				.6,
				.65,
				.95,
				.65,
				.65,
				.5,
				.65,
				.65,
				.5,
				.65
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 0,
				osc1Octave: -2,
				osc1Level: .8,
				osc2Wave: 1,
				osc2Octave: -1,
				osc2Detune: 0,
				osc2Level: .12,
				osc3Level: 0,
				cutoff: 700,
				resonance: 0,
				drive: .55,
				envAmount: .1,
				tracking: .3,
				ampAttack: .003,
				ampDecay: .8,
				ampSustain: .75,
				ampRelease: 1.1,
				glide: .07,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 2,
				midFreq: 1,
				midGain: 4,
				drive: 12,
				output: -2
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 52,
				kickDecay: .32,
				snareTone: .65,
				snappy: .8,
				hatDecay: .035,
				openDecay: .3,
				level: .8
			},
			lanes: {
				kick: "x.....x.x.....x.",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "x.x.x.xxx.x.x.xx",
				open: "...........x...."
			}
		},
		compressor: {
			type: "compressor",
			params: {
				input: 3,
				threshold: -26,
				time: 1,
				output: 8
			}
		},
		bells: {
			type: "performance",
			steps: g("..X...X...X..X..", [
				84,
				84,
				84,
				84,
				84,
				84,
				80,
				80,
				80,
				80,
				82,
				82,
				82,
				77,
				77,
				77
			], .5)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .05,
				brightness: 1,
				velocity: .6,
				level: 1,
				...b.bell
			}
		},
		delay: {
			type: "delay",
			params: {
				time: v(68),
				feedback: .4,
				mix: .3
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: .55,
				c: 1,
				d: 1
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -18,
				ratio: 0,
				attack: 4,
				release: 4,
				scHpf: 2,
				output: 2
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("performance", "oracle"),
		...S("performance2", "monarch"),
		...S("bells", "prism"),
		...T([
			[
				"oracle",
				"equalizer",
				"reverb"
			],
			["monarch", "brit"],
			["boom", "compressor"],
			["prism", "delay"]
		], "cohere")
	]) : e === "Broken Beat" ? x(e, 108, .1, {
		performance: {
			type: "performance",
			steps: g("X..x..x...x..x.x", [
				36,
				36,
				36,
				48,
				48,
				48,
				34,
				34,
				34,
				34,
				41,
				41,
				41,
				44,
				44,
				43
			], .4)
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Wave: 3,
				osc2Detune: 5,
				osc2Level: .35,
				osc3Wave: 0,
				osc3Level: .45,
				cutoff: 700,
				resonance: .35,
				drive: .3,
				envAmount: .55,
				filterDecay: .14,
				filterSustain: .15,
				ampAttack: .003,
				ampDecay: .2,
				ampSustain: .4,
				ampRelease: .06,
				level: .7
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 2,
				lfGain: 2,
				midFreq: 2,
				midGain: 3,
				drive: 8
			}
		},
		stabs: {
			type: "performance",
			steps: g("X..x...x..x..x..", _([48, 7], [53, 9]), .4)
		},
		keys: {
			type: "oracle",
			params: {
				aShape: 2,
				bFine: 8,
				cutoff: 1800,
				resonance: .15,
				envAmount: .45,
				filterDecay: .25,
				filterSustain: .2,
				ampAttack: .003,
				ampDecay: .35,
				ampSustain: .3,
				ampRelease: .25,
				chord: 4,
				vintage: .4,
				level: .9
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(108),
				feedback: .3,
				mix: .2
			}
		},
		punch: {
			type: "punch",
			params: {
				kickTune: 54,
				kickClick: .55,
				kickDecay: .4,
				snareTone: .55,
				snappy: .65,
				hatDecay: .04,
				openDecay: .2,
				level: .85
			},
			lanes: {
				kick: "x.....x..x...x..",
				snare: "....x.......x...",
				clap: "....x..........x",
				hat: "x.xxx.x.x.xxx.x.",
				open: ".....x.......x.."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .004,
				release: .12,
				color: 2,
				detectorHp: 1,
				output: 5
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .5,
				skinTune: 5,
				tomTune: 7,
				sandLevel: .6
			},
			euclid: {
				skin: [3, 8],
				tom: [
					2,
					16,
					3
				],
				sand: [5, 12]
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: .5,
				c: .85,
				d: .8
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 1,
				attack: 4,
				release: 1,
				output: 2
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("performance", "monarch"),
		...S("stabs", "keys"),
		...T([
			["punch", "talon"],
			["orbit"],
			["monarch", "brit"],
			["keys", "echo"]
		], "cohere")
	]) : x(e, 96, .08, {
		performance: {
			type: "performance",
			steps: g("X..X..X.X..X..X.", [
				62,
				62,
				62,
				65,
				65,
				65,
				69,
				69,
				67,
				67,
				67,
				72,
				72,
				72,
				69,
				69
			], .5)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: 0,
				brightness: .9,
				velocity: .6,
				level: 1,
				...b.kalimba
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(96),
				feedback: .35,
				mix: .25
			}
		},
		bass: {
			type: "performance",
			steps: g("X......o..x.....", _([38, 10], [36, 6]), [
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.6,
				.5,
				.5,
				.95,
				.5,
				.5,
				.5,
				.5,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 0,
				osc1Level: .8,
				osc2Wave: 1,
				osc2Detune: 0,
				osc2Level: .2,
				osc3Level: 0,
				cutoff: 300,
				resonance: 0,
				drive: .2,
				envAmount: .1,
				ampAttack: .006,
				ampDecay: .6,
				ampSustain: .8,
				ampRelease: .2,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 2,
				midFreq: 1,
				midGain: 4,
				drive: 10
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 44,
				kickDecay: .9,
				level: .85
			},
			lanes: { kick: "x.......x......." }
		},
		talon: {
			type: "talon",
			params: {
				input: 3,
				ratio: 4,
				attack: .002,
				release: .2,
				color: 2,
				output: 4
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .65,
				woodLevel: .5,
				metalLevel: .35,
				shakerLevel: .45
			},
			euclid: {
				skin: [
					5,
					16,
					2
				],
				wood: [
					3,
					8,
					2
				],
				sand: [7, 12],
				metal: [2, 15],
				shaker: [
					9,
					16,
					2
				],
				tom: [
					3,
					14,
					1
				]
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .75,
				b: .8,
				c: 1,
				d: .6
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -18,
				ratio: 0,
				attack: 4,
				release: 4,
				output: 2
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("performance", "prism"),
		...S("bass", "monarch"),
		...T([
			["boom", "talon"],
			["orbit"],
			["prism", "echo"],
			["monarch", "brit"]
		], "cohere")
	]);
}
//#endregion
//#region src/retroPresets.ts
var D = (...e) => w(e, "mixer", "cohere", "main"), ee = {
	cohere: {
		type: "cohere",
		params: {
			threshold: -16,
			ratio: 0,
			attack: 4,
			release: 4,
			scHpf: 2,
			output: 2
		}
	},
	main: {
		type: "output",
		params: { volume: .7 }
	}
};
function te(e) {
	return e === "Neon Skyline" ? x(e, 112, 0, {
		pads: {
			type: "performance",
			steps: g("X.......X.......", _([57, 8], [52, 8]), .95)
		},
		aurora: {
			type: "aurora",
			params: {
				osc2Wave: 0,
				osc2Detune: 12,
				hpf: 150,
				cutoff: 2400,
				envAmount: .2,
				filterAttack: .1,
				filterDecay: 1.5,
				filterSustain: .5,
				ampAttack: .08,
				ampDecay: 1,
				ampSustain: .8,
				ampRelease: 2.2,
				lfoRate: .4,
				lfoWidth: .3,
				chord: 2,
				vintage: .5,
				level: .8
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2.6,
				mix: .35
			}
		},
		bass: {
			type: "performance",
			steps: g("X.x.X.x.X.x.X.x.", _([41, 8], [36, 8]), .55)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .2,
				brightness: 1,
				velocity: .6,
				level: 1,
				...b.bass
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 2,
				midFreq: 2,
				midGain: 2,
				hfGain: 1,
				drive: 8,
				output: 8
			}
		},
		arp: {
			type: "performance",
			steps: g("XxxxXxxxXxxxXxxx", [
				69,
				72,
				76,
				79,
				81,
				79,
				76,
				72,
				67,
				72,
				76,
				79,
				84,
				79,
				76,
				72
			], .5)
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 3,
				osc1Level: .7,
				osc2Detune: 5,
				osc2Level: .4,
				osc3Level: 0,
				cutoff: 2200,
				resonance: .3,
				envAmount: .4,
				filterDecay: .12,
				filterSustain: .1,
				ampAttack: .002,
				ampDecay: .18,
				ampSustain: .2,
				ampRelease: .12,
				level: .55
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(112),
				feedback: .35,
				mix: .3
			}
		},
		strike: {
			type: "strike",
			params: {
				level: 1,
				kickDecay: .4,
				snareTune: -2,
				snareDecay: .3,
				clapLevel: .5,
				hatLevel: .4,
				hatPan: .2,
				tambourineLevel: .3,
				tambourinePan: -.3
			},
			lanes: {
				kick: "x...x...x...x...",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "x.x.x.x.x.x.x.x.",
				tambourine: "....x.......x..."
			}
		},
		room: {
			type: "reverb",
			params: {
				decay: 1.2,
				mix: .3
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 0,
				ratio: 7,
				attack: 2e-4,
				release: .08,
				color: 2,
				output: 12
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: .75,
				c: .6,
				d: .45
			}
		},
		...ee
	}, [
		...S("pads", "aurora"),
		...S("bass", "prism"),
		...S("arp", "monarch"),
		...D([
			"strike",
			"room",
			"talon"
		], ["prism", "brit"], ["aurora", "space"], ["monarch", "echo"])
	]) : e === "Digital Boogie" ? x(e, 116, .12, {
		bass: {
			type: "performance",
			steps: g("X..x..x.X.xx..x.", [
				40,
				40,
				40,
				52,
				52,
				52,
				40,
				40,
				45,
				45,
				45,
				57,
				57,
				57,
				43,
				43
			], [
				.6,
				.5,
				.5,
				.3,
				.5,
				.5,
				.6,
				.5,
				.6,
				.5,
				.5,
				.3,
				.5,
				.5,
				.6,
				.5
			])
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .3,
				brightness: 1.1,
				velocity: .8,
				level: 1,
				...b.slap
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 2,
				lfGain: 2,
				midFreq: 3,
				midGain: 3,
				drive: 6,
				output: 8
			}
		},
		stabs: {
			type: "performance",
			steps: g("..X..x....X..x..", _([52, 8], [57, 8]), .6)
		},
		aurora: {
			type: "aurora",
			params: {
				osc2Detune: 8,
				cutoff: 2600,
				envAmount: .4,
				filterDecay: .2,
				filterSustain: .2,
				ampAttack: .003,
				ampDecay: .3,
				ampSustain: .2,
				ampRelease: .2,
				lfoWidth: .2,
				chord: 4,
				vintage: .35,
				level: .6
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 1.2,
				mix: .2
			}
		},
		strike: {
			type: "strike",
			params: {
				level: 1,
				kickDecay: .35,
				snareDecay: .25,
				clapLevel: .6,
				hatDecay: .05,
				hatLevel: .35,
				hatPan: .2,
				bellLevel: .35,
				bellPan: -.25
			},
			lanes: {
				kick: "x.....x.x.....x.",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "x".repeat(16),
				bell: "......x.......x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .003,
				release: .1,
				color: 1,
				detectorHp: 1,
				output: 9
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: .75,
				c: .75
			}
		},
		...ee
	}, [
		...S("bass", "prism"),
		...S("stabs", "aurora"),
		...D(["strike", "talon"], ["prism", "brit"], ["aurora", "space"])
	]) : e === "Midnight Ballad" ? x(e, 76, .04, {
		keys: {
			type: "performance",
			steps: g("X.....x.X.....x.", _([58, 8], [51, 8]), .9)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .08,
				brightness: .75,
				velocity: .75,
				lfoRate: 4.5,
				lfoDepth: .04,
				chord: 3,
				level: .7,
				...b.epiano
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(76),
				feedback: .25,
				mix: .15
			}
		},
		strings: {
			type: "performance",
			steps: g("X.......X.......", _([58, 8], [63, 8]), .95)
		},
		aurora: {
			type: "aurora",
			params: {
				osc1Wave: 0,
				osc2Wave: 0,
				osc2Detune: 10,
				hpf: 250,
				cutoff: 2200,
				envAmount: .15,
				filterAttack: .15,
				filterDecay: 1.5,
				filterSustain: .6,
				ampAttack: .12,
				ampDecay: 1.2,
				ampSustain: .8,
				ampRelease: 2.8,
				lfoRate: .3,
				lfoWidth: .3,
				chord: 1,
				vintage: .45,
				level: .8
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2.8,
				mix: .4
			}
		},
		bass: {
			type: "performance",
			steps: g("X.....x.X.....x.", _([34, 6], [41, 2], [39, 6], [46, 2]), [
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.8,
				.5,
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.8,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 1,
				osc1Level: .8,
				osc2Wave: 0,
				osc2Detune: 0,
				osc2Level: .3,
				osc3Wave: 0,
				osc3Level: .3,
				cutoff: 700,
				resonance: .15,
				drive: .15,
				envAmount: .25,
				filterDecay: .5,
				filterSustain: .4,
				ampAttack: .01,
				ampDecay: .8,
				ampSustain: .7,
				ampRelease: .3,
				glide: .08,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 2,
				midFreq: 1,
				midGain: 2,
				hfGain: -3,
				drive: 4
			}
		},
		strike: {
			type: "strike",
			params: {
				level: .9,
				kickDecay: .45,
				snareTune: -3,
				snareDecay: .5,
				hatLevel: .35,
				hatPan: .2,
				rideLevel: .3,
				ridePan: -.2
			},
			lanes: {
				kick: "x.......x..x....",
				snare: "....x.......x...",
				hat: "x...x...x...x...",
				ride: "..x...x...x...x."
			}
		},
		room: {
			type: "reverb",
			params: {
				decay: 1.6,
				mix: .35
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 0,
				ratio: 6,
				attack: 5e-4,
				release: .12,
				color: 1,
				output: 8
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .75,
				b: 1,
				c: .55,
				d: .4
			}
		},
		...ee
	}, [
		...S("keys", "prism"),
		...S("strings", "aurora"),
		...S("bass", "monarch"),
		...D([
			"strike",
			"room",
			"talon"
		], ["prism", "echo"], ["aurora", "space"], ["monarch", "brit"])
	]) : e === "New Wave Motion" ? x(e, 132, 0, {
		bass: {
			type: "performance",
			steps: g("X.x.x.x.X.x.x.x.", [
				38,
				38,
				38,
				38,
				38,
				38,
				50,
				50,
				34,
				34,
				34,
				34,
				34,
				34,
				46,
				46
			], .6)
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Detune: 7,
				osc2Level: .5,
				osc3Wave: 3,
				osc3Level: .35,
				cutoff: 900,
				resonance: .3,
				drive: .35,
				envAmount: .45,
				filterDecay: .15,
				filterSustain: .3,
				ampAttack: .002,
				ampDecay: .15,
				ampSustain: .6,
				ampRelease: .05,
				level: .7
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 2,
				lfGain: 2,
				midFreq: 2,
				midGain: 4,
				hfGain: 2,
				drive: 10
			}
		},
		pad: {
			type: "performance",
			steps: g("x.......x.......", _([50, 16]), .95)
		},
		aurora: {
			type: "aurora",
			params: {
				osc1Wave: 1,
				osc1Width: .35,
				osc2Wave: 0,
				osc2Detune: 9,
				hpf: 180,
				cutoff: 2600,
				envAmount: .2,
				filterAttack: .15,
				filterDecay: 1,
				filterSustain: .5,
				ampAttack: .06,
				ampDecay: .8,
				ampSustain: .75,
				ampRelease: 1.6,
				lfoRate: .7,
				lfoWidth: .45,
				chord: 2,
				vintage: .35,
				level: .7
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 1.8,
				mix: .25
			}
		},
		hook: {
			type: "performance",
			steps: g("X..X..X...X..X..", [
				81,
				81,
				81,
				77,
				77,
				77,
				74,
				74,
				74,
				74,
				76,
				76,
				76,
				77,
				77,
				77
			], .6)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .05,
				brightness: 1.1,
				velocity: .6,
				level: 1,
				...b.bell
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(132),
				feedback: .35,
				mix: .25
			}
		},
		strike: {
			type: "strike",
			params: {
				level: 1,
				kickDecay: .35,
				snareDecay: .3,
				hatDecay: .05,
				hatLevel: .4,
				hatPan: .2,
				midTomPan: .3,
				lowTomPan: -.3
			},
			lanes: {
				kick: "x.......x.x.....",
				snare: "....x.......x...",
				hat: "x.x.x.x.x.x.x...",
				midTom: "..............x.",
				lowTom: "...............x"
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 4,
				attack: .002,
				release: .1,
				color: 2,
				detectorHp: 1,
				output: 10
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: .65,
				c: .55,
				d: .7
			}
		},
		...ee
	}, [
		...S("bass", "monarch"),
		...S("pad", "aurora"),
		...S("hook", "prism"),
		...D(["strike", "talon"], ["monarch", "brit"], ["aurora", "space"], ["prism", "echo"])
	]) : e === "Glass Arcade" ? x(e, 108, 0, {
		arp: {
			type: "performance",
			steps: g("XxxxXxxxXxxxXxxx", [
				72,
				76,
				79,
				83,
				84,
				83,
				79,
				76,
				69,
				72,
				76,
				79,
				81,
				79,
				76,
				72
			], .5)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: 0,
				brightness: 1.2,
				velocity: .6,
				level: 1,
				...b.bell,
				op1Decay: .6,
				op1Release: .4,
				op3Decay: .5,
				op3Release: .3
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(108),
				feedback: .4,
				mix: .3
			}
		},
		melody: {
			type: "performance",
			steps: g("X.x.x...X.x.xx..", [
				76,
				76,
				79,
				79,
				81,
				81,
				79,
				79,
				76,
				76,
				74,
				74,
				72,
				74,
				74,
				74
			], .75)
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 3,
				osc1Level: .8,
				osc2Wave: 3,
				osc2Detune: 6,
				osc2Level: .35,
				osc3Level: 0,
				cutoff: 3200,
				resonance: .15,
				envAmount: .2,
				filterDecay: .2,
				filterSustain: .6,
				ampAttack: .003,
				ampDecay: .2,
				ampSustain: .75,
				ampRelease: .1,
				glide: .02,
				level: .55
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 2,
				midFreq: 3,
				midGain: 3,
				hfGain: 2,
				drive: 4,
				output: 4
			}
		},
		bass: {
			type: "performance",
			steps: g("X.x.X.x.X.x.X.x.", [
				36,
				36,
				48,
				48,
				36,
				36,
				48,
				48,
				33,
				33,
				45,
				45,
				33,
				33,
				45,
				45
			], .55)
		},
		aurora: {
			type: "aurora",
			params: {
				osc1Wave: 1,
				osc1Width: .25,
				osc2Wave: 1,
				osc2Octave: -1,
				osc2Detune: 0,
				osc2Width: .5,
				blend: .4,
				cutoff: 1400,
				resonance: .2,
				envAmount: .4,
				filterDecay: .15,
				filterSustain: .2,
				ampAttack: .002,
				ampDecay: .2,
				ampSustain: .5,
				ampRelease: .06,
				lfoWidth: 0,
				level: 1
			}
		},
		strike: {
			type: "strike",
			params: {
				level: 1,
				kickDecay: .3,
				snareDecay: .22,
				hatDecay: .04,
				hatLevel: .4,
				hatPan: .2,
				openLevel: .35,
				openPan: .2
			},
			lanes: {
				kick: "x.....x.x.......",
				snare: "....x.......x...",
				hat: "x.x.x.x.x.x.x...",
				open: "..............x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 3,
				ratio: 3,
				attack: 3e-4,
				release: .1,
				color: 0,
				detectorHp: 1,
				output: 10
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: 1,
				c: .3,
				d: .85
			}
		},
		...ee
	}, [
		...S("arp", "prism"),
		...S("melody", "monarch"),
		...S("bass", "aurora"),
		...D(["strike", "talon"], ["prism", "echo"], ["monarch", "brit"], ["aurora"])
	]) : x(e, 96, .06, {
		pads: {
			type: "performance",
			steps: g("X.......X.......", _([50, 8], [55, 8]), .95)
		},
		aurora: {
			type: "aurora",
			params: {
				osc1Wave: 0,
				osc2Wave: 2,
				osc2Octave: 1,
				osc2Detune: 6,
				blend: .4,
				hpf: 120,
				cutoff: 2e3,
				envAmount: .15,
				filterAttack: .12,
				filterDecay: 1.5,
				filterSustain: .6,
				ampAttack: .1,
				ampDecay: 1.2,
				ampSustain: .8,
				ampRelease: 2.4,
				lfoRate: .25,
				lfoWidth: .3,
				lfoFilter: .05,
				chord: 3,
				vintage: .4,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 2,
				midFreq: 0,
				midGain: -2,
				hfGain: 5,
				drive: 3
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2.8,
				mix: .35
			}
		},
		pluck: {
			type: "performance",
			steps: g("X.XX.X.XX.X.XX.X", [
				74,
				74,
				78,
				81,
				81,
				85,
				85,
				81,
				79,
				79,
				83,
				86,
				86,
				83,
				83,
				79
			], .5)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: 0,
				brightness: .9,
				velocity: .6,
				level: 1,
				...b.pluck,
				op1Level: 1
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(96),
				feedback: .45,
				mix: .3
			}
		},
		bass: {
			type: "performance",
			steps: g("X.....x.X.....x.", _([38, 8], [43, 8]), [
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 0,
				osc1Level: .8,
				osc2Wave: 1,
				osc2Detune: 0,
				osc2Level: .25,
				osc3Level: 0,
				cutoff: 400,
				resonance: 0,
				drive: .1,
				envAmount: .1,
				ampAttack: .01,
				ampDecay: .6,
				ampSustain: .8,
				ampRelease: .3,
				glide: .04,
				level: .8
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .9,
				woodTune: 5,
				woodLevel: .45,
				sandLevel: .5,
				shakerDecay: .08,
				shakerLevel: .55
			},
			euclid: {
				wood: [3, 8],
				sand: [
					5,
					16,
					2
				],
				shaker: [
					8,
					16,
					1
				]
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .7,
				b: 1,
				c: .53,
				d: 1
			}
		},
		...ee,
		cohere: {
			type: "cohere",
			params: {
				threshold: -14,
				ratio: 0,
				attack: 5,
				release: 4,
				output: 1
			}
		}
	}, [
		...S("pads", "aurora"),
		...S("pluck", "prism"),
		...S("bass", "monarch"),
		...D([
			"aurora",
			"brit",
			"space"
		], ["prism", "echo"], ["monarch"], ["orbit"])
	]);
}
//#endregion
//#region src/studioPresets.ts
var ne = (...e) => w(e, "sum", "cohere", "main");
function re(e) {
	return e === "French Touch" ? x(e, 123, .08, {
		seq: {
			type: "performance",
			steps: g("X.xx.x.xX.x.X.xx", [
				33,
				33,
				45,
				33,
				33,
				43,
				43,
				45,
				38,
				38,
				50,
				38,
				48,
				48,
				45,
				43
			], .5)
		},
		stabs: {
			type: "performance",
			steps: g("..X..x.x..X..x..", _([57, 8], [62, 8]), .55)
		},
		bass: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Wave: 3,
				osc2Detune: 5,
				osc2Level: .45,
				osc3Wave: 3,
				osc3Level: .5,
				cutoff: 520,
				resonance: .35,
				drive: .35,
				envAmount: .55,
				tracking: .6,
				filterAttack: .003,
				filterDecay: .16,
				filterSustain: .12,
				filterRelease: .08,
				ampAttack: .003,
				ampDecay: .3,
				ampSustain: .7,
				ampRelease: .06,
				glide: .015,
				level: .75
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 2,
				lfGain: 2.5,
				midFreq: 1,
				midGain: 3,
				drive: 8,
				output: -2
			}
		},
		keys: {
			type: "aurora",
			params: {
				osc2Wave: 0,
				osc2Detune: 9,
				hpf: 180,
				cutoff: 2200,
				envAmount: .35,
				filterAttack: .002,
				filterDecay: .22,
				filterSustain: .2,
				ampAttack: .004,
				ampDecay: .35,
				ampSustain: .5,
				ampRelease: .22,
				lfoWidth: 0,
				chord: 4,
				vintage: .35,
				level: .75
			}
		},
		sieve: {
			type: "filter",
			params: {
				cutoff: 1100,
				resonance: 4.5
			}
		},
		sweep: {
			type: "lfo",
			params: {
				wave: 1,
				rate: .12
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(123),
				feedback: .3,
				mix: .2
			}
		},
		drums: {
			type: "punch",
			params: {
				kickTune: 52,
				kickClick: .45,
				kickDecay: .5,
				snappy: .6,
				hatDecay: .04,
				openDecay: .28,
				level: .85
			},
			lanes: {
				kick: "x...x...x...x...",
				clap: "....x.......x...",
				hat: "...x...x...x...x",
				open: "..x...x...x...x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .008,
				release: .12,
				color: 1,
				detectorHp: 1,
				output: 5
			}
		},
		sum: {
			type: "mixer",
			params: {
				a: .8,
				b: .9,
				c: .55
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 1,
				attack: 4,
				release: 1,
				output: 3
			}
		},
		main: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("seq", "bass"),
		...S("stabs", "keys"),
		[
			"sweep",
			"out",
			"sieve",
			"cv",
			.8
		],
		...ne(["drums", "talon"], [
			"keys",
			"sieve",
			"echo"
		], ["bass", "brit"])
	]) : e === "Distortion Disco" ? x(e, 116, 0, {
		seq: {
			type: "performance",
			steps: g("Xx.xX.x.Xx.xX.xx", [
				28,
				40,
				40,
				28,
				38,
				38,
				40,
				40,
				31,
				43,
				43,
				31,
				33,
				33,
				35,
				38
			], .6)
		},
		stabs: {
			type: "performance",
			steps: g("..X....x..X..x..", _([64, 8], [57, 8]), .7)
		},
		bass: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Detune: 14,
				osc2Level: .6,
				osc3Wave: 3,
				osc3Octave: 1,
				osc3Level: .3,
				cutoff: 650,
				resonance: .25,
				drive: 1,
				envAmount: .5,
				tracking: .7,
				filterDecay: .2,
				filterSustain: .3,
				ampAttack: .002,
				ampDecay: .2,
				ampSustain: .8,
				ampRelease: .05,
				level: .7
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 2,
				lfGain: 3,
				midFreq: 1,
				midGain: 6,
				hfGain: -4,
				drive: 20,
				output: -2
			}
		},
		prophet: {
			type: "oracle",
			params: {
				bFine: 10,
				aLevel: .8,
				bLevel: .7,
				cutoff: 1400,
				resonance: .2,
				envAmount: .5,
				filterAttack: .005,
				filterDecay: .3,
				filterSustain: .3,
				filterRelease: .2,
				ampAttack: .004,
				ampDecay: .5,
				ampSustain: .55,
				ampRelease: .25,
				chord: 2,
				vintage: .45,
				level: .9
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 1.4,
				mix: .18
			}
		},
		drums: {
			type: "strike",
			params: {
				level: .85,
				kickDecay: .35,
				kickLevel: 1,
				snareDecay: .25,
				snareLevel: .85,
				clapLevel: .6,
				hatDecay: .06,
				hatLevel: .5,
				hatPan: -.15,
				openLevel: .45,
				tambourineLevel: .4,
				tambourinePan: .25
			},
			lanes: {
				kick: "x...x...x...x...",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "x.x.x.x.x.x.x...",
				open: "..............x.",
				tambourine: "..x...x...x...x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 8,
				ratio: 6,
				attack: .001,
				release: .1,
				color: 2,
				fierce: 1,
				detectorHp: 1,
				output: 5
			}
		},
		sum: {
			type: "mixer",
			params: {
				a: 1,
				b: .9,
				c: .6
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -18,
				ratio: 2,
				attack: 3,
				release: 1,
				output: 4
			}
		},
		main: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("seq", "bass"),
		...S("stabs", "prophet"),
		...ne(["drums", "talon"], ["prophet", "space"], ["bass", "brit"])
	]) : e === "Electro Pogo" ? x(e, 128, 0, {
		seq: {
			type: "performance",
			steps: g(".xXx.xXx.xXx.xXx", [
				38,
				38,
				50,
				38,
				38,
				38,
				50,
				38,
				34,
				34,
				46,
				34,
				36,
				36,
				48,
				36
			], .6)
		},
		hook: {
			type: "performance",
			steps: g("X.x.xx.x.X.xX.x.", [
				69,
				69,
				74,
				74,
				77,
				76,
				76,
				74,
				74,
				77,
				77,
				74,
				76,
				76,
				79,
				79
			], .7)
		},
		bass: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Detune: 8,
				osc2Level: .5,
				osc3Wave: 3,
				osc3Level: .45,
				cutoff: 500,
				resonance: .4,
				drive: .55,
				envAmount: .6,
				filterDecay: .12,
				filterSustain: .15,
				ampDecay: .18,
				ampSustain: .6,
				ampRelease: .04,
				level: .7
			}
		},
		lead: {
			type: "oracle",
			params: {
				bOctave: 1,
				bFine: 6,
				bLevel: .5,
				cutoff: 2600,
				resonance: .3,
				envAmount: .35,
				filterDecay: .25,
				filterSustain: .4,
				ampAttack: .003,
				ampDecay: .3,
				ampSustain: .65,
				ampRelease: .15,
				glide: .035,
				level: 1
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 2,
				midFreq: 3,
				midGain: 4,
				hfGain: 4,
				drive: 6,
				output: 6
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(128),
				feedback: .32,
				mix: .22
			}
		},
		drums: {
			type: "punch",
			params: {
				kickTune: 50,
				kickClick: .7,
				kickDecay: .45,
				snareTone: .6,
				snappy: .8,
				hatDecay: .035,
				openDecay: .2,
				level: .85
			},
			lanes: {
				kick: "x...x...x...x...",
				snare: "....x.......x..x",
				clap: "....x.......x...",
				hat: "xx.xxx.xxx.xxx.x",
				open: "..x...x...x...x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .006,
				release: .09,
				color: 1,
				detectorHp: 1,
				output: 5
			}
		},
		sum: {
			type: "mixer",
			params: {
				a: .8,
				b: .8,
				c: .5
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -14,
				ratio: 1,
				attack: 5,
				release: 4,
				scHpf: 2,
				output: 2
			}
		},
		main: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("seq", "bass"),
		...S("hook", "lead"),
		...ne(["drums", "talon"], [
			"lead",
			"brit",
			"echo"
		], ["bass"])
	]) : x(e, 126, 0, {
		seq: {
			type: "performance",
			steps: g("XxxxXxxxXxxxXxxx", [
				36,
				48,
				36,
				48,
				36,
				48,
				36,
				48,
				32,
				44,
				32,
				44,
				34,
				46,
				34,
				46
			], .45)
		},
		hook: {
			type: "performance",
			steps: g("..X..x.x..X..x..", [
				75,
				75,
				75,
				75,
				75,
				74,
				74,
				72,
				72,
				72,
				75,
				75,
				75,
				74,
				74,
				74
			], .8)
		},
		bass: {
			type: "monarch",
			params: {
				osc1Wave: 3,
				osc1Level: .8,
				osc2Detune: -7,
				osc2Level: .5,
				osc3Wave: 3,
				osc3Level: .35,
				cutoff: 420,
				resonance: .75,
				drive: .6,
				envAmount: .7,
				tracking: .6,
				filterAttack: .002,
				filterDecay: .11,
				filterSustain: 0,
				filterRelease: .05,
				ampAttack: .002,
				ampDecay: .15,
				ampSustain: .5,
				ampRelease: .04,
				level: .7
			}
		},
		fm: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .35,
				brightness: 1,
				velocity: .7,
				lfoRate: 5.5,
				lfoDepth: .12,
				level: .55,
				...y([
					1,
					0,
					.9,
					.005,
					.8,
					.6,
					.25
				], [
					1,
					0,
					.55,
					.02,
					.4,
					.35,
					.2
				], [
					1,
					9,
					.8,
					.005,
					.8,
					.6,
					.25
				], [
					3,
					0,
					.25,
					.003,
					.25,
					.1,
					.15
				], [
					2,
					-6,
					.35,
					.005,
					.6,
					.4,
					.25
				], [
					1,
					0,
					.35,
					.003,
					.3,
					.15,
					.15
				])
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 2,
				midFreq: 1,
				midGain: 3,
				hfGain: 2,
				drive: 10,
				output: 12
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(126),
				feedback: .38,
				mix: .28
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2.2,
				mix: .22
			}
		},
		drums: {
			type: "boom",
			params: {
				kickTune: 48,
				kickDecay: .4,
				snareTone: .6,
				snappy: .75,
				hatDecay: .05,
				level: .85
			},
			lanes: {
				kick: "x...x...x...x...",
				snare: "....x.......x...",
				clap: "....x.......x...",
				rim: "...x.....x...x..",
				hat: "x.x.x.x.x.x.x.x.",
				bell: "..x..x....x..x.."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 4,
				attack: .003,
				release: .15,
				color: 2,
				fierce: 1,
				detectorHp: 1,
				output: 8
			}
		},
		sum: {
			type: "mixer",
			params: {
				a: .8,
				b: .8,
				c: .42
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 1,
				attack: 4,
				release: 1,
				scHpf: 2,
				output: 3
			}
		},
		main: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("seq", "bass"),
		...S("hook", "fm"),
		...ne(["drums", "talon"], [
			"fm",
			"brit",
			"echo",
			"space"
		], ["bass"])
	]);
}
//#endregion
//#region src/model.ts
var O = (e, t, n, r, i, a = .01, o, s = !1) => ({
	id: e,
	label: t,
	min: n,
	max: r,
	initial: i,
	step: a,
	unit: o,
	logarithmic: s
}), k = (e, t, n, r) => ({
	id: e,
	label: t,
	choices: n,
	initial: r,
	min: 0,
	max: n.length - 1,
	step: 1
}), A = (e, t, n = "audio", r) => ({
	id: e,
	label: t,
	kind: n,
	direction: "in",
	scale: r
}), j = (e, t, n = "audio") => ({
	id: e,
	label: t,
	kind: n,
	direction: "out"
}), M = (e, t = 2) => Array.from({ length: t }, (t, n) => n ? {
	...e,
	id: `${e.id}${n + 1}`,
	copyOf: e.id
} : e), N = (e) => ({
	...e,
	legacyDefault: e.initial
}), P = (e, t) => ({
	id: `${e}Pattern`,
	label: "Pattern",
	min: 0,
	max: 65535,
	step: 1,
	initial: [...t].reduce((e, t, n) => t === "x" ? e | 1 << n : e, 0),
	pattern: !0,
	voice: e
}), ie = (e, t, n, r, i) => [
	{
		...O(`${e}Steps`, `${t} steps`, 1, 16, n, 1),
		voice: e
	},
	{
		...O(`${e}Hits`, `${t} hits`, 0, 16, r, 1),
		voice: e
	},
	{
		...O(`${e}Shift`, `${t} shift`, 0, 15, i, 1),
		voice: e
	}
], ae = [
	"Skin",
	"Wood",
	"Sand",
	"Metal",
	"Shaker",
	"Tom"
].map((e) => ({
	id: e.toLowerCase(),
	label: e
})), oe = ({ id: e, label: t }, n) => {
	let [r, i, a] = [
		[
			16,
			5,
			2
		],
		[
			8,
			3,
			0
		],
		[
			12,
			8,
			0
		],
		[
			16,
			0,
			0
		],
		[
			16,
			0,
			0
		],
		[
			16,
			0,
			0
		]
	][n], o = (t) => ({
		...N(t),
		voice: e
	});
	return [
		...ie(e, t, r, i, a).map((e) => n > 2 ? o(e) : e),
		o(O(`${e}Tune`, `${t} tune`, -24, 24, 0, 1, "st")),
		o(O(`${e}Decay`, `${t} decay`, .02, 2, [
			.32,
			.07,
			.07,
			.5,
			.12,
			.4
		][n], .01, "s", !0)),
		o(O(`${e}Tone`, `${t} tone`, 0, 1, .5)),
		o(O(`${e}Level`, `${t} level`, 0, 1, 1)),
		o(k(`${e}Custom`, `${t} rhythm`, ["Euclidean", "Custom"], 0)),
		o(P(e, "................"))
	];
}, se = (e, t) => [
	O(`${e}Attack`, "Attack", .002, 2, .008, .001, "s", !0),
	O(`${e}Decay`, "Decay", .01, 3, .25, .01, "s", !0),
	O(`${e}Sustain`, "Sustain", 0, 1, e === "amp" ? .65 : .2),
	O(`${e}Release`, "Release", .01, 4, .2, .01, "s", !0)
].map((e) => ({
	...e,
	group: t
})), ce = [A("chain", "Chain in"), ...M(j("out", "Drums out"))], F = (e, t) => t.map((t) => ({
	...t,
	group: e
})), le = [
	["Off", [0]],
	["Maj 7", [
		0,
		4,
		7,
		11
	]],
	["Min 7", [
		0,
		3,
		7,
		10
	]],
	["Maj 9", [
		0,
		4,
		7,
		11,
		14
	]],
	["Min 9", [
		0,
		3,
		7,
		10,
		14
	]],
	["Min 11", [
		0,
		3,
		10,
		14,
		17
	]],
	["Dom 9", [
		0,
		4,
		7,
		10,
		14
	]]
], ue = [
	["kick", "Kick"],
	["snare", "Snare"],
	["rim", "Sidestick"],
	["clap", "Clap"],
	["hat", "Closed hat"],
	["open", "Open hat"],
	["lowTom", "Low tom"],
	["midTom", "Mid tom"],
	["highTom", "High tom"],
	["lowConga", "Low conga"],
	["highConga", "High conga"],
	["cabasa", "Cabasa"],
	["tambourine", "Tambourine"],
	["bell", "Cowbell"],
	["crash", "Crash"],
	["ride", "Ride"]
].map(([e, t]) => ({
	id: e,
	label: t
})), de = [
	"Three pairs",
	"Twin stacks",
	"Serial stack",
	"Shared modulation",
	"Branched",
	"Additive"
], fe = [
	"a",
	"b",
	"c",
	"d",
	"e",
	"f",
	"g",
	"h"
], pe = (e) => `${e}Pan`, me = [
	["kick", "Kick"],
	["snare", "Snare"],
	["rim", "Rim"],
	["clap", "Clap"],
	["hat", "Hat"],
	["open", "Open"],
	["lowTom", "Lo tom"],
	["highTom", "Hi tom"],
	["crash", "Crash"],
	["ride", "Ride"],
	["bell", "Bell"]
].map(([e, t]) => ({
	id: e,
	label: t
})), I = {
	performance: {
		name: "STEP–16",
		subtitle: "PATTERN & NOTE CONTROLLER",
		color: "performance",
		params: [],
		ports: [...M(j("pitch", "Pitch · 1V/oct", "cv"), 3), ...M(j("gate", "Note gate", "gate"), 3)]
	},
	oscillator: {
		name: "SOLID",
		subtitle: "ANALOG OSCILLATOR",
		color: "oscillator",
		params: [
			k("wave", "Waveform", [
				"Sine",
				"Triangle",
				"Saw",
				"Square"
			], 2),
			O("octave", "Octave", -3, 3, 0, 1),
			O("tune", "Tune", -12, 12, 0, 1, "st"),
			O("fine", "Fine", -50, 50, 0, 1, "ct"),
			O("level", "Level", 0, 1, .7)
		],
		ports: [
			A("pitch", "Pitch · 1V/oct", "cv", 1200),
			A("fm", "FM", "cv", 1200),
			...M(j("out", "Audio out"))
		]
	},
	noise: {
		name: "STATIC",
		subtitle: "NOISE GENERATOR",
		color: "noise",
		params: [k("color", "Color", [
			"White",
			"Pink",
			"Brown"
		], 0), O("level", "Level", 0, 1, .4)],
		ports: [...M(j("out", "Audio out"))]
	},
	mixer: {
		name: "SUM",
		subtitle: "EIGHT CHANNEL MIXER",
		color: "mixer",
		params: [
			...fe.map((e, t) => {
				let n = O(e, `Channel ${e.toUpperCase()}`, 0, 1, .7);
				return t > 2 ? N(n) : n;
			}),
			...fe.map((e) => N(O(pe(e), `Channel ${e.toUpperCase()} pan`, -1, 1, 0))),
			N(O("master", "Mix bus", 0, 1, 1))
		],
		ports: [...fe.map((e) => A(e, `Channel ${e.toUpperCase()}`)), ...M(j("out", "Mix out"))]
	},
	filter: {
		name: "SIEVE",
		subtitle: "MULTIMODE FILTER",
		color: "filter",
		params: [
			k("mode", "Mode", [
				"Low-pass",
				"High-pass",
				"Band-pass"
			], 0),
			O("cutoff", "Cutoff", 40, 18e3, 1400, 1, "Hz", !0),
			O("resonance", "Resonance", .1, 12, 2.5, .1)
		],
		ports: [
			A("in", "Audio in"),
			A("cv", "Cutoff CV", "cv", 2400),
			...M(j("out", "Audio out"))
		]
	},
	amplifier: {
		name: "LEVEL",
		subtitle: "VOLTAGE CONTROLLED AMPLIFIER",
		color: "amplifier",
		params: [O("level", "Level", 0, 1, .8)],
		ports: [
			A("in", "Audio in"),
			A("cv", "Amplitude CV", "cv", 1),
			...M(j("out", "Audio out"))
		]
	},
	envelope: {
		name: "CONTOUR",
		subtitle: "ADSR ENVELOPE",
		color: "envelope",
		params: [
			O("attack", "Attack", .002, 2, .01, .001, "s", !0),
			O("decay", "Decay", .01, 3, .2, .01, "s", !0),
			O("sustain", "Sustain", 0, 1, .5),
			O("release", "Release", .01, 4, .18, .01, "s", !0)
		],
		ports: [A("gate", "Note gate", "gate"), ...M(j("out", "Envelope CV", "cv"))]
	},
	lfo: {
		name: "PULSE",
		subtitle: "LOW FREQUENCY OSCILLATOR",
		color: "lfo",
		params: [k("wave", "Waveform", [
			"Sine",
			"Triangle",
			"Saw",
			"Square"
		], 0), O("rate", "Rate", .05, 20, 2, .05, "Hz", !0)],
		ports: [A("cv", "Rate CV", "cv", 5), ...M(j("out", "Modulation CV", "cv"))]
	},
	delay: {
		name: "ECHO",
		subtitle: "FEEDBACK DELAY",
		color: "delay",
		params: [
			O("time", "Time", .02, 1, .28, .01, "s"),
			O("feedback", "Feedback", 0, .85, .32),
			O("mix", "Mix", 0, 1, .22)
		],
		ports: [A("in", "Audio in"), ...M(j("out", "Audio out"))]
	},
	reverb: {
		name: "SPACE",
		subtitle: "STEREO REVERBERATOR",
		color: "reverb",
		params: [O("decay", "Decay", .2, 3, 1.5, .1, "s"), O("mix", "Mix", 0, 1, .25)],
		ports: [A("in", "Audio in"), ...M(j("out", "Audio out"))]
	},
	boom: {
		name: "BOOM",
		subtitle: "ANALOG DRUM MACHINE",
		color: "boom",
		ports: ce,
		drum: {
			mode: "steps",
			voices: me
		},
		params: [
			...F("Kick", [O("kickTune", "Tune", 30, 90, 49, 1, "Hz"), O("kickDecay", "Decay", .1, 2.5, .8, .01, "s", !0)]),
			...F("Snare", [O("snareTone", "Tone", 0, 1, .5), O("snappy", "Snappy", 0, 1, .6)]),
			...F("Hat decay", [O("hatDecay", "Closed", .02, .6, .06, .01, "s", !0), N(O("openDecay", "Open", .1, 1.2, .4, .01, "s", !0))]),
			...F("Toms", [N(O("tomTune", "Tune", -12, 12, 0, 1, "st")), N(O("tomDecay", "Decay", .1, 1.5, .45, .01, "s", !0))]),
			...F("Cymbal decay", [N(O("crashDecay", "Crash", .3, 3, 1.6, .01, "s", !0)), N(O("rideDecay", "Ride", .2, 2.5, 1, .01, "s", !0))]),
			...F("Bell", [O("bellTune", "Tune", -12, 12, 0, 1, "st")]),
			O("level", "Level", 0, 1, .8),
			P("kick", "x......x..x....."),
			P("snare", "....x.......x..."),
			P("hat", "x.x.x.x.x.x.x.x."),
			P("bell", "...........x..x."),
			...[
				"rim",
				"clap",
				"open",
				"lowTom",
				"highTom",
				"crash",
				"ride"
			].map((e) => N(P(e, "................")))
		]
	},
	punch: {
		name: "PUNCH",
		subtitle: "DANCE FLOOR DRUM MACHINE",
		color: "punch",
		ports: ce,
		drum: {
			mode: "steps",
			voices: [
				{
					id: "kick",
					label: "Kick"
				},
				{
					id: "snare",
					label: "Snare"
				},
				{
					id: "clap",
					label: "Clap"
				},
				{
					id: "hat",
					label: "Hat"
				},
				{
					id: "open",
					label: "Open"
				}
			]
		},
		params: [
			O("kickTune", "Kick tune", 40, 90, 55, 1, "Hz"),
			O("kickClick", "Kick click", 0, 1, .5),
			O("kickDecay", "Kick decay", .1, 1.2, .45, .01, "s", !0),
			O("snareTone", "Snare tone", 0, 1, .5),
			O("snappy", "Snappy", 0, 1, .7),
			O("hatDecay", "Hat decay", .02, .3, .05, .01, "s", !0),
			O("openDecay", "Open decay", .1, 1, .35, .01, "s", !0),
			O("level", "Level", 0, 1, .8),
			P("kick", "x...x...x...x..."),
			P("snare", "............x..x"),
			P("clap", "....x.......x..."),
			P("hat", "xx..xx..xx..xx.."),
			P("open", "..x...x...x...x.")
		]
	},
	orbit: {
		name: "ORBIT",
		subtitle: "EUCLIDEAN PERCUSSION",
		color: "orbit",
		ports: ce,
		drum: {
			mode: "euclid",
			voices: ae
		},
		params: [
			O("pitch", "Pitch", -12, 12, 0, 1, "st"),
			O("level", "Level", 0, 1, .7),
			...ae.flatMap(oe)
		]
	},
	monarch: {
		name: "MONARCH",
		subtitle: "VINTAGE MONOSYNTH",
		color: "monarch",
		ports: [
			A("pitch", "Pitch · 1V/oct", "cv", 1200),
			A("gate", "Note gate", "gate"),
			A("cv", "Cutoff CV", "cv", 2400),
			...M(j("out", "Audio out"))
		],
		params: [
			...[
				1,
				2,
				3
			].flatMap((e) => [
				k(`osc${e}Wave`, "Waveform", [
					"Sine",
					"Triangle",
					"Saw",
					"Square"
				], 2),
				O(`osc${e}Octave`, "Octave", -3, 3, e === 3 ? -1 : 0, 1),
				O(`osc${e}Detune`, "Detune", -50, 50, e === 2 ? 7 : 0, 1, "ct"),
				O(`osc${e}Level`, "Level", 0, 1, e === 1 ? .7 : .35)
			].map((t) => ({
				...t,
				group: `Oscillator ${e}`
			}))),
			...[
				O("cutoff", "Cutoff", 40, 18e3, 1100, 1, "Hz", !0),
				O("resonance", "Resonance", 0, 1, .2),
				O("drive", "Drive", 0, 1, .25),
				O("envAmount", "Env amount", -1, 1, .5),
				O("tracking", "Key track", 0, 1, .5)
			].map((e) => ({
				...e,
				group: "Filter"
			})),
			...se("filter", "Filter envelope"),
			...se("amp", "Amplifier envelope"),
			...[
				O("noise", "Noise", 0, 1, 0),
				O("glide", "Glide", 0, 1, 0, .01, "s"),
				O("level", "Level", 0, 1, .7)
			].map((e) => ({
				...e,
				group: "Performance"
			}))
		]
	},
	oracle: {
		name: "ORACLE",
		subtitle: "FIVE-VOICE POLYSYNTH",
		color: "oracle",
		ports: [
			A("pitch", "Pitch · 1V/oct", "cv", 1200),
			A("gate", "Note gate", "gate"),
			A("cv", "Cutoff CV", "cv", 2400),
			...M(j("out", "Audio out"))
		],
		params: [
			...F("Poly-Mod", [
				O("polyEnv", "Filt env", 0, 1, 0),
				O("polyOscB", "Osc B", 0, 1, 0),
				k("polyDest", "Dest", [
					"Freq A",
					"Filter",
					"Both"
				], 0)
			]),
			...F("Oscillator A", [
				O("aOctave", "Octave", -2, 2, 0, 1),
				k("aShape", "Shape", [
					"Saw",
					"Pulse",
					"Saw + Pulse"
				], 0),
				O("aWidth", "Width", .05, .95, .5)
			]),
			...F("Oscillator B", [
				O("bOctave", "Octave", -2, 2, 0, 1),
				O("bFine", "Fine", -50, 50, 7, 1, "ct"),
				k("bShape", "Shape", [
					"Saw",
					"Triangle",
					"Pulse"
				], 0),
				O("bWidth", "Width", .05, .95, .5)
			]),
			...F("LFO", [
				O("lfoRate", "Rate", .05, 20, 4, .05, "Hz", !0),
				k("lfoShape", "Shape", [
					"Triangle",
					"Saw",
					"Square"
				], 0),
				O("lfoAmount", "Amount", 0, 1, 0),
				k("lfoDest", "Dest", [
					"Pitch",
					"PW",
					"Filter"
				], 0)
			]),
			...F("Mixer", [
				O("aLevel", "Osc A", 0, 1, .8),
				O("bLevel", "Osc B", 0, 1, .6),
				O("noise", "Noise", 0, 1, 0)
			]),
			...F("Filter", [
				O("cutoff", "Cutoff", 40, 18e3, 1600, 1, "Hz", !0),
				O("resonance", "Resonance", 0, 1, .15),
				O("envAmount", "Env amount", 0, 1, .4),
				O("tracking", "Key track", 0, 1, .5)
			]),
			...se("filter", "Filter envelope"),
			...se("amp", "Amplifier envelope"),
			...F("Voices", [
				O("glide", "Glide", 0, 1, 0, .01, "s"),
				O("vintage", "Vintage", 0, 1, .3),
				k("chord", "Chord", le.map(([e]) => e), 0),
				O("level", "Level", 0, 1, .7)
			])
		]
	},
	aurora: {
		name: "AURORA",
		subtitle: "EIGHT-VOICE ANALOG POLYSYNTH",
		color: "aurora",
		ports: [
			A("pitch", "Pitch · 1V/oct", "cv", 1200),
			A("gate", "Note gate", "gate"),
			A("cv", "Cutoff CV", "cv", 2400),
			...M(j("out", "Audio out"))
		],
		params: [
			...[1, 2].flatMap((e) => F(`Oscillator ${e}`, [
				k(`osc${e}Wave`, "Waveform", [
					"Saw",
					"Pulse",
					"Triangle",
					"Sine"
				], e === 1 ? 0 : 1),
				O(`osc${e}Octave`, "Octave", -2, 2, 0, 1),
				O(`osc${e}Detune`, "Detune", -50, 50, e === 2 ? 6 : 0, 1, "ct"),
				O(`osc${e}Width`, "Width", .05, .95, .5)
			])),
			...F("Source mix", [
				O("blend", "Osc 1 / 2", 0, 1, .5),
				O("crossMod", "Cross mod", 0, 1, 0),
				O("hpf", "High-pass", 20, 3e3, 20, 1, "Hz", !0)
			]),
			...F("Filter", [
				O("cutoff", "Cutoff", 40, 18e3, 2200, 1, "Hz", !0),
				O("resonance", "Resonance", 0, 1, .15),
				k("slope", "Slope", ["12 dB", "24 dB"], 1),
				O("envAmount", "Env amount", -1, 1, .35),
				O("tracking", "Key track", 0, 1, .5)
			]),
			...se("filter", "Filter envelope"),
			...se("amp", "Amplifier envelope"),
			...F("LFO", [
				O("lfoRate", "Rate", .05, 20, .6, .05, "Hz", !0),
				k("lfoShape", "Waveform", [
					"Triangle",
					"Sine",
					"Square"
				], 0),
				O("lfoPitch", "Pitch", 0, 1, 0),
				O("lfoWidth", "PWM", 0, 1, .15),
				O("lfoFilter", "Filter", 0, 1, 0)
			]),
			...F("Voices", [
				O("glide", "Glide", 0, 1, 0, .01, "s"),
				O("vintage", "Vintage", 0, 1, .25),
				k("chord", "Chord", le.map(([e]) => e), 0),
				O("level", "Level", 0, 1, .65)
			])
		]
	},
	strike: {
		name: "STRIKE",
		subtitle: "VINTAGE DIGITAL DRUM MACHINE",
		color: "strike",
		ports: ce,
		drum: {
			mode: "steps",
			voices: ue
		},
		params: [O("level", "Level", 0, 1, .8), ...ue.flatMap(({ id: e, label: t }) => [P(e, e === "kick" ? "x.......x.x....." : e === "snare" ? "....x.......x..." : e === "hat" ? "x.x.x.x.x.x.x.x." : "................"), ...[
			O(`${e}Tune`, "Tune", -24, 24, 0, 1, "st"),
			O(`${e}Decay`, "Decay", .03, 3, ["crash", "ride"].includes(e) ? 1.8 : e === "open" ? .45 : e === "hat" ? .08 : .35, .01, "s", !0),
			O(`${e}Tone`, "Tone", 0, 1, .7),
			O(`${e}Level`, "Level", 0, 1, .8),
			O(`${e}Pan`, "Pan", -1, 1, 0)
		].map((n) => ({
			...n,
			voice: e,
			label: `${t} ${n.label}`
		}))])]
	},
	prism: {
		name: "PRISM",
		subtitle: "SIX-OPERATOR FM SYNTH",
		color: "prism",
		ports: [
			A("pitch", "Pitch · 1V/oct", "cv", 1200),
			A("gate", "Note gate", "gate"),
			A("cv", "Brightness CV", "cv", 1),
			...M(j("out", "Audio out"))
		],
		params: [
			...F("Sound", [
				k("algorithm", "Algorithm", de, 0),
				O("feedback", "Feedback", 0, 1, .08),
				O("brightness", "Brightness", 0, 2, .8),
				O("velocity", "Velocity", 0, 1, .7)
			]),
			...F("Performance", [
				O("lfoRate", "LFO rate", .05, 20, 5, .05, "Hz", !0),
				O("lfoDepth", "Vibrato", 0, 1, 0),
				k("chord", "Chord", le.map(([e]) => e), 0),
				O("level", "Level", 0, 1, .65)
			]),
			...Array.from({ length: 6 }, (e, t) => {
				let n = `op${t + 1}`;
				return [
					O(`${n}Ratio`, "Ratio", .5, 16, t % 2 ? 2 : 1, .5),
					O(`${n}Detune`, "Detune", -50, 50, 0, 1, "ct"),
					O(`${n}Level`, "Level", 0, 1, t < 2 ? .8 : .4),
					O(`${n}Attack`, "Attack", .002, 2, .005, .001, "s", !0),
					O(`${n}Decay`, "Decay", .01, 3, t % 2 ? .35 : 1.2, .01, "s", !0),
					O(`${n}Sustain`, "Sustain", 0, 1, t % 2 ? .05 : .25),
					O(`${n}Release`, "Release", .01, 4, .25, .01, "s", !0)
				].map((e) => ({
					...e,
					voice: n
				}));
			}).flat()
		]
	},
	compressor: {
		name: "VALVE",
		subtitle: "VARIABLE-MU LIMITER",
		color: "compressor",
		ports: [A("in", "Audio in"), ...M(j("out", "Audio out"))],
		params: [
			O("input", "Input", -12, 18, 0, .5, "dB"),
			O("threshold", "Threshold", -40, 0, -18, .5, "dB"),
			k("time", "Time constant", [
				"1",
				"2",
				"3",
				"4",
				"5",
				"6"
			], 1),
			O("output", "Output", -12, 12, 0, .5, "dB")
		]
	},
	equalizer: {
		name: "CONSOLE",
		subtitle: "FOUR-BAND CHANNEL EQ",
		color: "equalizer",
		ports: [A("in", "Audio in"), ...M(j("out", "Audio out"))],
		params: [
			k("active", "EQ", ["In", "Out"], 0),
			O("output", "Output", -12, 12, 0, .5, "dB"),
			...F("Filters", [O("hpf", "High-pass", 16, 350, 16, 1, "Hz", !0), O("lpf", "Low-pass", 3e3, 22e3, 22e3, 10, "Hz", !0)]),
			...F("LF", [
				O("lfGain", "Gain", -15, 15, 0, .5, "dB"),
				O("lfFreq", "Freq", 30, 450, 100, 1, "Hz", !0),
				k("lfBell", "Shape", ["Shelf", "Bell"], 0)
			]),
			...F("LMF", [
				O("lmfGain", "Gain", -15, 15, 0, .5, "dB"),
				O("lmfFreq", "Freq", 200, 2500, 600, 1, "Hz", !0),
				O("lmfQ", "Q", .5, 4, 1, .1)
			]),
			...F("HMF", [
				O("hmfGain", "Gain", -15, 15, 0, .5, "dB"),
				O("hmfFreq", "Freq", 600, 7e3, 2500, 10, "Hz", !0),
				O("hmfQ", "Q", .5, 4, 1, .1)
			]),
			...F("HF", [
				O("hfGain", "Gain", -15, 15, 0, .5, "dB"),
				O("hfFreq", "Freq", 1500, 16e3, 8e3, 10, "Hz", !0),
				k("hfBell", "Shape", ["Shelf", "Bell"], 0)
			])
		]
	},
	cohere: {
		name: "COHERE",
		subtitle: "STEREO BUS COMPRESSOR",
		color: "cohere",
		ports: [A("in", "Audio in"), ...M(j("out", "Audio out"))],
		params: [...F("Dynamics", [
			O("threshold", "Threshold", -40, 10, -18, .5, "dB"),
			k("ratio", "Ratio", [
				"2:1",
				"4:1",
				"10:1"
			], 1),
			k("attack", "Attack", [
				"0.1 ms",
				"0.3 ms",
				"1 ms",
				"3 ms",
				"10 ms",
				"30 ms"
			], 4),
			k("release", "Release", [
				"0.1 s",
				"0.3 s",
				"0.6 s",
				"1.2 s",
				"Auto"
			], 4)
		]), ...F("Bus", [
			k("scHpf", "Detector HP", [
				"Off",
				"30 Hz",
				"60 Hz",
				"106 Hz",
				"125 Hz",
				"185 Hz"
			], 0),
			O("output", "Makeup", -12, 20, 0, .5, "dB"),
			k("active", "Process", ["In", "Bypass"], 0)
		])]
	},
	talon: {
		name: "TALON",
		subtitle: "HARMONIC DYNAMICS PROCESSOR",
		color: "talon",
		ports: [A("in", "Audio in"), ...M(j("out", "Audio out"))],
		params: [
			...F("Dynamics", [
				O("input", "Input", -12, 30, 0, .5, "dB"),
				k("ratio", "Ratio", [
					"1:1",
					"2:1",
					"3:1",
					"4:1",
					"6:1",
					"10:1 Opto",
					"20:1",
					"Crush"
				], 4),
				O("attack", "Attack", 5e-5, .03, .003, 5e-5, "s", !0),
				O("release", "Release", .05, 3.5, .3, .01, "s", !0)
			]),
			...F("Character", [
				k("color", "Harmonics", [
					"Clean",
					"Even",
					"Odd"
				], 0),
				k("audioHp", "Audio HP", ["Off", "65 Hz"], 0),
				k("fierce", "Fierce", ["Off", "On"], 0)
			]),
			...F("Detector", [
				k("detectorHp", "High-pass", ["Off", "80 Hz"], 0),
				k("detectorBand", "Emphasis", ["Off", "6 kHz"], 0),
				k("link", "Stereo link", ["Off", "On"], 1)
			]),
			...F("Output", [O("output", "Output", -30, 12, 0, .5, "dB"), k("active", "Process", ["In", "Bypass"], 0)])
		]
	},
	brit: {
		name: "BRIT",
		subtitle: "THREE-BAND CLASS A EQUALIZER",
		color: "brit",
		ports: [A("in", "Audio in"), ...M(j("out", "Audio out"))],
		params: [
			...F("Low shelf", [k("lfFreq", "Freq", [
				"35 Hz",
				"60 Hz",
				"110 Hz",
				"220 Hz"
			], 2), O("lfGain", "Gain", -16, 16, 0, .5, "dB")]),
			...F("Mid bell", [k("midFreq", "Freq", [
				"360 Hz",
				"700 Hz",
				"1.6 kHz",
				"3.2 kHz",
				"4.8 kHz",
				"7.2 kHz"
			], 2), O("midGain", "Gain", -18, 18, 0, .5, "dB")]),
			...F("High shelf · 12 kHz", [O("hfGain", "Gain", -16, 16, 0, .5, "dB")]),
			...F("Signal", [
				k("hpf", "High-pass", [
					"Off",
					"50 Hz",
					"80 Hz",
					"160 Hz",
					"300 Hz"
				], 0),
				O("drive", "Drive", 0, 24, 0, .5, "dB"),
				O("output", "Output", -18, 18, 0, .5, "dB"),
				k("active", "Process", ["In", "Bypass"], 0)
			])
		]
	},
	output: {
		name: "MAIN",
		subtitle: "STEREO MASTER OUTPUT",
		color: "output",
		params: [O("volume", "Master", 0, 1, .65)],
		ports: [A("in", "Audio in")]
	}
}, he = Object.keys(I).filter((e) => e !== "output"), ge = 0, _e = (e = "module") => `${e}-${Date.now().toString(36)}-${++ge}`, ve = (e, t = _e()) => ({
	id: t,
	type: e,
	params: Object.fromEntries(I[e].params.map((e) => [e.id, e.initial]))
}), ye = (e) => e === "performance" ? {
	...ve(e),
	steps: Array.from({ length: 16 }, (e, t) => ({
		enabled: t % 4 == 0,
		note: 48,
		velocity: .8,
		gate: .5
	}))
} : ve(e), be = (e, t) => {
	let n = e.modules.findIndex((e) => e.id === t);
	return n === 0 || e.modules[n]?.type === "output";
}, xe = (e, t) => e.modules[0].id === t ? e.sequencer.steps : e.modules.find((e) => e.id === t)?.steps ?? e.sequencer.steps;
function Se(e, t, n) {
	return e.modules[0].id === t ? {
		...e,
		sequencer: {
			...e.sequencer,
			steps: n
		}
	} : {
		...e,
		modules: e.modules.map((e) => e.id === t ? {
			...e,
			steps: n
		} : e)
	};
}
var L = (e, t) => {
	let n = e.modules.find((e) => e.id === t.moduleId);
	return n && I[n.type].ports.find((e) => e.id === t.portId);
}, R = (e, t) => e.moduleId === t.moduleId && e.portId === t.portId;
function Ce(e, t) {
	let n = e.filter((e) => (e.copyOf ?? e.id) === (t.copyOf ?? t.id));
	return n.length > 1 ? n.indexOf(t) + 1 : null;
}
var we = (e, t) => e.cables.find((e) => R(e.from, t) || R(e.to, t));
function Te(e, t, n) {
	let r = L(e, t), i = L(e, n);
	if (!r || !i) return "That socket no longer exists.";
	if (r.direction !== "out" || i.direction !== "in") return "Connect an output to an input.";
	if (r.kind !== i.kind) return `A ${r.kind.toUpperCase()} output needs a ${r.kind.toUpperCase()} input.`;
	if (e.cables.some((e) => R(e.to, n))) return "That input already has a cable. Pull its plug out first.";
	if (e.cables.some((e) => R(e.from, t))) return "That output jack already has a cable. Use its spare jack, or pull the plug out first.";
	let a = /* @__PURE__ */ new Set(), o = (n) => n === t.moduleId || !a.has(n) && (a.add(n), e.cables.filter((e) => e.from.moduleId === n).some((e) => o(e.to.moduleId)));
	return o(n.moduleId) ? "External feedback loops are not supported. Use ECHO’s feedback control." : null;
}
function Ee(e, t, n, r = 1) {
	let i = Te(e, t, n);
	if (i) throw Error(i);
	return {
		...e,
		cables: [...e.cables, {
			id: _e("cable"),
			from: t,
			to: n,
			amount: r
		}]
	};
}
function De(e, t, n) {
	let r = L(e, t), i = L(e, n);
	return !r || !i || r.direction === i.direction ? null : r.direction === "out" ? {
		from: t,
		to: n
	} : {
		from: n,
		to: t
	};
}
function Oe(e, t, n, r = null) {
	if (!L(e, t) || !L(e, n)) return "That socket no longer exists.";
	let i = De(e, t, n);
	return i ? Te(r ? {
		...e,
		cables: e.cables.filter((e) => e.id !== r)
	} : e, i.from, i.to) : "Connect an output to an input.";
}
function ke(e, t, n, r) {
	if (!e.cables.find((e) => e.id === t)) throw Error("That cable no longer exists.");
	let i = Oe(e, n, r, t);
	if (i) throw Error(i);
	let a = De(e, n, r);
	return {
		...e,
		cables: e.cables.map((e) => e.id === t ? {
			...e,
			...a
		} : e)
	};
}
function Ae(e, t) {
	return be(e, t) ? e : {
		...e,
		modules: e.modules.filter((e) => e.id !== t),
		cables: e.cables.filter((e) => e.from.moduleId !== t && e.to.moduleId !== t)
	};
}
function je(e, t, n) {
	let r = [...e.modules], i = r.findIndex((e) => e.id === t), a = i + n;
	return i < 1 || a < 1 || a >= r.length - 1 || be(e, t) ? e : ([r[i], r[a]] = [r[a], r[i]], {
		...e,
		modules: r
	});
}
var Me = (e, t) => (e >> t & 1) == 1;
function Ne(e, t, n = 0) {
	let r = Math.max(1, Math.min(16, Math.round(e))), i = Math.max(0, Math.min(r, Math.round(t))), a = Math.round(n);
	return Array.from({ length: r }, (e, t) => ((t - a) % r + r) % r * i % r < i);
}
function Pe(e, t) {
	let n = I[e.type].drum, r = e.params;
	return n ? n.voices.filter(({ id: i }) => {
		if (n.mode === "steps") return Me(r[`${i}Pattern`], t % 16);
		let a = z(e, i);
		return a[t % a.length];
	}).map((e) => e.id) : [];
}
function z(e, t) {
	let n = e.params, r = n[`${t}Steps`];
	return n[`${t}Custom`] ? Array.from({ length: r }, (e, r) => Me(n[`${t}Pattern`], r)) : Ne(r, n[`${t}Hits`], n[`${t}Shift`]);
}
function Fe(e, t, n) {
	let r = e.params[`${t}Custom`] ? e.params[`${t}Pattern`] : z(e, t).reduce((e, t, n) => e | (t ? 1 << n : 0), 0);
	return {
		...e.params,
		[`${t}Custom`]: 1,
		[`${t}Pattern`]: r ^ 1 << n
	};
}
var Ie = (e) => [
	"performance",
	"oscillator",
	"monarch",
	"oracle",
	"aurora",
	"prism",
	"strike",
	"noise",
	"boom",
	"punch",
	"orbit"
].includes(e), B = (e) => [
	"oracle",
	"aurora",
	"prism"
].includes(e), Le = (e) => e === "performance" || !!I[e].drum;
function Re(e, t) {
	let n = /* @__PURE__ */ new Set([t]);
	for (let t of n) for (let r of e.cables) r.from.moduleId === t && L(e, r.from)?.kind === "audio" && n.add(r.to.moduleId);
	return n;
}
function ze(e, t) {
	if (e.modules.find((e) => e.id === t)?.type === "performance") {
		let n = /* @__PURE__ */ new Set([t]);
		for (let t of n) for (let r of e.cables) r.from.moduleId === t && L(e, r.from)?.kind !== "audio" && n.add(r.to.moduleId);
		return [...n].some((n) => n !== t && ze(e, n));
	}
	let n = Re(e, t);
	return e.modules.some((e) => e.type === "output" && n.has(e.id));
}
function Be(e, t, n, r = null) {
	let i = De(e, t, n);
	if (!i) throw Error("Connect an output to an input.");
	if (!r) return Ee(e, i.from, i.to);
	let a = e.cables.find((e) => e.id === r);
	return a && R(a.from, i.from) && R(a.to, i.to) ? e : ke(e, r, i.from, i.to);
}
var Ve = {
	muted: /* @__PURE__ */ new Set(),
	soloed: /* @__PURE__ */ new Set()
}, He = (e, t) => `${e}:${t}`, Ue = (e, t) => `${e}:step:${t}`, We = /* @__PURE__ */ new Set([
	"oscillator",
	"noise",
	"boom",
	"punch",
	"orbit",
	"monarch",
	"oracle",
	"aurora",
	"prism",
	"strike"
]), Ge = (e) => We.has(e);
function Ke(e, t) {
	let n = /* @__PURE__ */ new Set([t]);
	for (let t of n) for (let r of e.cables) r.from.moduleId === t && L(e, r.from)?.kind !== "audio" && n.add(r.to.moduleId);
	return n.delete(t), e.modules.filter((t) => We.has(t.type) && [...Re(e, t.id)].some((e) => n.has(e))).map((e) => e.id);
}
function qe(e, t) {
	let n = new Set(e.modules.map((e) => e.id)), r = new Set([...t.soloed].filter((e) => n.has(e)));
	for (let t of r) for (let n of e.cables) n.from.moduleId === t && L(e, n.from)?.kind !== "audio" && r.add(n.to.moduleId);
	let i = (t, n = /* @__PURE__ */ new Set()) => r.has(t) ? !0 : !n.has(t) && (n.add(t), e.cables.some((e) => e.from.moduleId === t && e.to.portId !== "chain" && i(e.to.moduleId, n)));
	return Object.fromEntries(e.modules.filter((e) => e.type !== "output").map((e) => [e.id, !t.muted.has(e.id) && (!r.size || !We.has(e.type) || i(e.id))]));
}
var Je = (e) => I[e].drum?.voices.map((e) => e.id) ?? (e === "mixer" ? fe : []);
function Ye(e, t, n) {
	let r = Je(e.type).some((t) => n.soloed.has(He(e.id, t)));
	return !n.muted.has(He(e.id, t)) && (!r || n.soloed.has(He(e.id, t)));
}
function Xe(e, t, n) {
	return !n.muted.has(Ue(e, t)) && (!Array.from({ length: 16 }, (t, n) => Ue(e, n)).some((e) => n.soloed.has(e)) || n.soloed.has(Ue(e, t)));
}
function Ze(e, t, n) {
	let r = [], i = we(e, {
		moduleId: t,
		portId: n
	});
	for (; i;) {
		let t = e.modules.find((e) => e.id === i.from.moduleId);
		if (!t || r.includes(t) || (r.unshift(t), We.has(t.type) || t.type === "mixer")) break;
		let n = I[t.type].ports.filter((e) => e.direction === "in" && e.kind === "audio");
		i = n.length === 1 ? we(e, {
			moduleId: t.id,
			portId: n[0].id
		}) : void 0;
	}
	return r;
}
function Qe(e, t) {
	let n = I[t.type].name;
	return e.modules.filter((e) => e.type === t.type).length > 1 ? `${n} #${e.modules.findIndex((e) => e.id === t.id) + 1}` : n;
}
function $e(e, t, n) {
	let r = Ze(e, t, n), i = n.toUpperCase();
	return {
		source: r.length ? Qe(e, r[0]) : `Channel ${i}`,
		tooltip: r.map((t) => Qe(e, t)).join(" → "),
		connected: r.length > 0
	};
}
function et(e, t, n) {
	let r = new Set(e.muted), i = new Set(e.soloed), [a, o] = n === "muted" ? [r, i] : [i, r];
	return a.delete(t) || (a.add(t), o.delete(t)), {
		muted: r,
		soloed: i
	};
}
var tt = (e, t) => t === e.id || t.startsWith(`${e.id}:`), nt = (e, t) => [...t.muted, ...t.soloed].some((t) => tt(e, t));
function rt(e, t) {
	return nt(t, e) ? {
		muted: new Set([...e.muted].filter((e) => !tt(t, e))),
		soloed: new Set([...e.soloed].filter((e) => !tt(t, e)))
	} : e;
}
var it = [
	"Vintage Bass",
	"Vintage Lead",
	"Boom Bap",
	"Late Night Hip-Hop",
	"Roots Reggae",
	"Dub Session",
	"Trap Soul",
	"Broken Beat",
	"Orbit Percussion"
], at = [
	"Neon Skyline",
	"Digital Boogie",
	"Midnight Ballad",
	"New Wave Motion",
	"Glass Arcade",
	"Analog Sunrise"
], V = [
	"French Touch",
	"Distortion Disco",
	"Electro Pogo",
	"Electroclash"
], ot = [
	"Bass",
	"Lead",
	"Pluck",
	"Groove",
	"House",
	...it,
	...at,
	...V
], st = (e, t) => e.includes(t);
function ct(e = "Bass") {
	if (st(V, e)) return re(e);
	if (st(at, e)) return te(e);
	if (st(it, e)) return E(e);
	let t = e === "Groove" ? ["boom", "orbit"] : e === "House" ? ["punch"] : [], n = [
		"performance",
		"oscillator",
		"filter",
		"amplifier",
		"envelope",
		"lfo",
		"delay",
		...t,
		"output"
	].map((e) => ve(e, e)), r = (e) => n.find((t) => t.type === e);
	e === "Lead" ? (Object.assign(r("oscillator").params, {
		wave: 3,
		octave: 1
	}), Object.assign(r("filter").params, {
		cutoff: 3200,
		resonance: 1.8
	}), Object.assign(r("envelope").params, {
		attack: .04,
		decay: .15,
		sustain: .65,
		release: .35
	}), r("delay").params.mix = .3) : e === "Pluck" ? (Object.assign(r("oscillator").params, {
		wave: 1,
		octave: 1
	}), Object.assign(r("filter").params, {
		cutoff: 2600,
		resonance: 3.5
	}), Object.assign(r("envelope").params, {
		attack: .002,
		decay: .24,
		sustain: 0,
		release: .12
	}), r("delay").params.mix = .35) : e === "Groove" ? (Object.assign(r("envelope").params, {
		decay: .16,
		sustain: .3
	}), r("delay").params.mix = .15) : e === "House" && (r("oscillator").params.wave = 3, Object.assign(r("filter").params, {
		cutoff: 900,
		resonance: 5
	}), Object.assign(r("envelope").params, {
		attack: .002,
		decay: .14,
		sustain: 0,
		release: .08
	}), r("delay").params.mix = .12);
	let i = [
		36,
		36,
		43,
		36,
		48,
		36,
		46,
		43,
		36,
		36,
		43,
		48,
		46,
		43,
		38,
		43
	], a = e === "Bass" || e === "Groove" || e === "House", o = (t) => e === "House" ? t % 4 != 0 : t !== 1 && t !== 9, s = {
		version: 1,
		name: e,
		modules: n,
		cables: [],
		sequencer: {
			bpm: e === "Groove" ? 94 : e === "House" ? 124 : 110,
			swing: e === "Groove" ? .12 : 0,
			steps: i.map((e, t) => ({
				enabled: o(t),
				note: e + (a ? 0 : 12),
				velocity: t % 4 == 0 ? 1 : .75,
				gate: .65
			}))
		}
	}, c = ["delay", ...t];
	for (let [e, n, r, i, a] of [
		[
			"oscillator",
			"out",
			"filter",
			"in",
			1
		],
		[
			"filter",
			"out",
			"amplifier",
			"in",
			1
		],
		[
			"amplifier",
			"out",
			"delay",
			"in",
			1
		],
		...t.map((e, t) => [
			c[t],
			"out",
			e,
			"chain",
			1
		]),
		[
			c.at(-1),
			"out",
			"output",
			"in",
			1
		],
		[
			"performance",
			"pitch",
			"oscillator",
			"pitch",
			1
		],
		[
			"performance",
			"gate",
			"envelope",
			"gate",
			1
		],
		[
			"envelope",
			"out",
			"amplifier",
			"cv",
			1
		],
		[
			"lfo",
			"out",
			"filter",
			"cv",
			.12
		]
	]) s = Ee(s, {
		moduleId: e,
		portId: n
	}, {
		moduleId: r,
		portId: i
	}, a);
	return s;
}
function lt(e) {
	return JSON.stringify(e, null, 2);
}
function ut(e) {
	let t = e.cables.map((e) => JSON.stringify([
		e.from.moduleId,
		e.from.portId,
		e.to.moduleId,
		e.to.portId,
		e.amount
	])).sort();
	return JSON.stringify({
		name: e.name,
		modules: e.modules,
		sequencer: e.sequencer,
		cables: t
	});
}
function dt(e) {
	if (e.length > 1e6) throw Error("Patch files must be smaller than 1 MB.");
	let t = JSON.parse(e), n = (e) => typeof e == "object" && !!e && !Array.isArray(e), r = () => {
		throw Error("This is not a valid Rackloose v1 patch.");
	}, i = (e) => !Array.isArray(e) || e.length !== 16 ? r() : e.map((e) => !n(e) || typeof e.enabled != "boolean" || typeof e.note != "number" || !Number.isInteger(e.note) || e.note < 24 || e.note > 96 || typeof e.velocity != "number" || !Number.isFinite(e.velocity) || e.velocity < 0 || e.velocity > 1 || typeof e.gate != "number" || !Number.isFinite(e.gate) || e.gate < .1 || e.gate > .95 ? r() : {
		enabled: e.enabled,
		note: e.note,
		velocity: e.velocity,
		gate: e.gate
	});
	if (!n(t) || t.version !== 1 || typeof t.name != "string" || t.name.length > 100 || !Array.isArray(t.modules) || !Array.isArray(t.cables) || !n(t.sequencer) || t.modules.length < 2 || t.modules.length > 32 || t.cables.length > 128) return r();
	let a = /* @__PURE__ */ new Set(), o = t.modules.map((e, t) => {
		if (!n(e) || typeof e.id != "string" || !/^[\w-]{1,80}$/.test(e.id) || a.has(e.id) || typeof e.type != "string" || !Object.hasOwn(I, e.type) || !n(e.params)) return r();
		a.add(e.id);
		let o = e.type, s = e.params, c = Object.fromEntries(I[o].params.map((e) => {
			let t = s[e.id] === void 0 && e.legacyDefault !== void 0 ? e.legacyDefault : s[e.id];
			return typeof t != "number" || !Number.isFinite(t) || t < e.min || t > e.max || (e.choices || e.pattern) && !Number.isInteger(t) ? r() : [e.id, t];
		}));
		return o === "performance" && t > 0 ? {
			id: e.id,
			type: o,
			params: c,
			steps: i(e.steps)
		} : {
			id: e.id,
			type: o,
			params: c
		};
	});
	if (o[0].type !== "performance" || o.filter((e) => e.type === "output").length !== 1 || o.at(-1)?.type !== "output") return r();
	let s = t.sequencer;
	if (typeof s.bpm != "number" || !Number.isFinite(s.bpm) || s.bpm < 40 || s.bpm > 240 || typeof s.swing != "number" || !Number.isFinite(s.swing) || s.swing < 0 || s.swing > .6) return r();
	let c = i(s.steps), l = {
		version: 1,
		name: t.name,
		modules: o,
		cables: [],
		sequencer: {
			bpm: s.bpm,
			swing: s.swing,
			steps: c
		}
	}, u = /* @__PURE__ */ new Set();
	for (let e of t.cables) {
		if (!n(e) || typeof e.id != "string" || !/^[\w-]{1,80}$/.test(e.id) || u.has(e.id) || !n(e.from) || !n(e.to) || typeof e.from.moduleId != "string" || typeof e.from.portId != "string" || typeof e.to.moduleId != "string" || typeof e.to.portId != "string" || typeof e.amount != "number" || !Number.isFinite(e.amount) || e.amount < -1 || e.amount > 1) return r();
		u.add(e.id);
		let t = {
			moduleId: e.from.moduleId,
			portId: e.from.portId
		}, i = {
			moduleId: e.to.moduleId,
			portId: e.to.portId
		}, a = L(l, t);
		if (a && l.cables.some((e) => R(e.from, t))) {
			let e = I[l.modules.find((e) => e.id === t.moduleId).type].ports.find((e) => (e.copyOf ?? e.id) === (a.copyOf ?? a.id) && !l.cables.some((n) => R(n.from, {
				moduleId: t.moduleId,
				portId: e.id
			})));
			if (!e) continue;
			t.portId = e.id;
		}
		if (Te(l, t, i) || L(l, t)?.kind !== "cv" && e.amount !== 1) return r();
		l = {
			...l,
			cables: [...l.cables, {
				id: e.id,
				from: t,
				to: i,
				amount: e.amount
			}]
		};
	}
	return l;
}
function ft(e, t) {
	try {
		let n = e.getItem(t);
		return {
			patch: n ? dt(n) : null,
			error: null
		};
	} catch {
		return {
			patch: null,
			error: "Saved patch unavailable. You can still play and export patch files."
		};
	}
}
function pt(e, t, n) {
	try {
		return e.setItem(t, lt(n)), null;
	} catch {
		return "Local save unavailable. Export a patch file to keep your work.";
	}
}
var H = (e, t) => e.logarithmic ? Math.log(t / e.min) / Math.log(e.max / e.min) : (t - e.min) / (e.max - e.min), mt = [
	"C",
	"C♯",
	"D",
	"D♯",
	"E",
	"F",
	"F♯",
	"G",
	"G♯",
	"A",
	"A♯",
	"B"
], ht = (e) => `${mt[e % 12]}${Math.floor(e / 12) - 1}`, gt = class {
	notes = /* @__PURE__ */ new Map();
	press(e, t) {
		return this.notes.delete(e), this.notes.set(e, t), this.current;
	}
	release(e) {
		return this.notes.delete(e), this.current;
	}
	clear() {
		this.notes.clear();
	}
	has(e) {
		return this.notes.has(e);
	}
	get current() {
		return [...this.notes.values()].at(-1) ?? null;
	}
	get entries() {
		return [...this.notes];
	}
}, _t = (e, t, n) => 60 / e / 4 * (n % 2 == 0 ? 1 + t : 1 - t);
function vt(e, t, n = 0) {
	let r = [], i = n;
	for (let n = 0; n < t * 16; n++) {
		let t = n % 16, a = _t(e.sequencer.bpm, e.sequencer.swing, t);
		r.push({
			step: e.sequencer.steps[t],
			index: t,
			time: i,
			duration: a
		}), i += a;
	}
	return {
		events: r,
		duration: i - n
	};
}
var yt = () => ({
	past: [],
	future: [],
	key: null,
	at: 0
});
function bt(e, t, n, r) {
	return n !== null && n === e.key && r - e.at < 1e3 && !e.future.length ? {
		...e,
		at: r
	} : {
		past: [...e.past, t].slice(-50),
		future: [],
		key: n,
		at: r
	};
}
function xt(e, t) {
	let n = e.past.at(-1);
	return n === void 0 ? null : {
		state: n,
		history: {
			past: e.past.slice(0, -1),
			future: [t, ...e.future],
			key: null,
			at: 0
		}
	};
}
function St(e, t) {
	let [n, ...r] = e.future;
	return n === void 0 ? null : {
		state: n,
		history: {
			past: [...e.past, t].slice(-50),
			future: r,
			key: null,
			at: 0
		}
	};
}
var Ct = "This browser could not save to My Presets. Export a file to keep your work.", wt = 100, Tt = (e, t) => e.trim().toLocaleLowerCase() === t.trim().toLocaleLowerCase(), U = (e, t) => e.patch.name.localeCompare(t.patch.name, void 0, {
	sensitivity: "base",
	numeric: !0
}) || e.savedAt - t.savedAt;
function Et(e, t) {
	try {
		let n = e.getItem(t);
		if (!n) return {
			presets: [],
			error: null
		};
		let r = JSON.parse(n);
		if (typeof r != "object" || !r || !("presets" in r) || !Array.isArray(r.presets)) throw Error("Not a preset list");
		let i = [], a = /* @__PURE__ */ new Set();
		for (let e of r.presets.slice(0, 200)) try {
			if (typeof e != "object" || !e) continue;
			let { id: t, savedAt: n, patch: r } = e;
			if (typeof t != "string" || !/^[\w-]{1,80}$/.test(t) || a.has(t) || typeof n != "number" || !Number.isFinite(n)) continue;
			let o = dt(JSON.stringify(r));
			if (i.some((e) => Tt(e.patch.name, o.name))) continue;
			a.add(t), i.push({
				id: t,
				savedAt: n,
				patch: o
			});
		} catch {}
		return {
			presets: i.sort(U),
			error: null
		};
	} catch {
		return {
			presets: [],
			error: "My Presets could not be read. Export files to keep your presets."
		};
	}
}
function Dt(e, t, n) {
	try {
		return e.setItem(t, JSON.stringify({
			version: 1,
			presets: n
		})), null;
	} catch {
		return Ct;
	}
}
function Ot(e, t) {
	return [...e.filter((e) => e.id !== t.id && !Tt(e.patch.name, t.patch.name)), t].sort(U);
}
var kt = (e, t, n) => e.find((e) => e.id !== n && Tt(e.patch.name, t));
function At(e, t) {
	for (let n = 1;; n++) {
		let r = n === 1 ? "" : ` (${n})`, i = `${t.slice(0, wt - r.length).trimEnd()}${r}`;
		if (!kt(e, i)) return i;
	}
}
function jt(e) {
	return e.trim().toLowerCase().replace(/[^a-z0-9_-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80).replace(/-+$/, "") || "rackloose-patch";
}
//#endregion
//#region src/audio/hold.ts
var W = /* @__PURE__ */ new WeakMap(), Mt = 64;
function Nt(e, t, n) {
	let r = () => t, i = 0;
	for (let t of e) if (t.type === "ramp") {
		if (t.time > n) {
			let e = r(i);
			return e + (t.value - e) * (n - i) / (t.time - i);
		}
		r = () => t.value, i = t.time;
	} else {
		if (t.time > n) break;
		let e = r(t.time), a = t.time;
		r = t.type === "set" ? () => t.value : (n) => t.value + (e - t.value) * Math.exp(-(n - a) / t.constant), i = t.time;
	}
	return r(n);
}
function Pt(e, t) {
	if (typeof e.cancelAndHoldAtTime == "function" || W.has(e)) return e;
	let n = [], { setValueAtTime: r, linearRampToValueAtTime: i, setTargetAtTime: a, cancelScheduledValues: o } = e, s, c = (r) => {
		s ??= e.value;
		let i = n.length;
		for (; i && n[i - 1].time > r.time;) i--;
		if (n.splice(i, 0, r), t && n.length > Mt) {
			let e = -1;
			for (let r = 0; r < n.length && n[r].time <= t.currentTime - 1; r++) n[r].type !== "ramp" && (e = r);
			e > 0 && (s = Nt(n.slice(0, e), s, n[e].time), n.splice(0, e));
		}
	};
	return Object.assign(e, {
		setValueAtTime(t, n) {
			return c({
				type: "set",
				time: n,
				value: t,
				constant: 0
			}), r.call(e, t, n);
		},
		linearRampToValueAtTime(t, n) {
			return c({
				type: "ramp",
				time: n,
				value: t,
				constant: 0
			}), i.call(e, t, n);
		},
		setTargetAtTime(t, n, r) {
			return c({
				type: "target",
				time: n,
				value: t,
				constant: r
			}), a.call(e, t, n, r);
		},
		cancelScheduledValues(t) {
			return n.splice(0, n.length, ...n.filter((e) => e.time < t)), o.call(e, t);
		}
	}), W.set(e, {
		events: n,
		hold: (t) => {
			let r = Nt(n, s ?? e.value, t), i = n.find((e) => e.time >= t);
			e.cancelScheduledValues(t), i?.type === "ramp" ? e.linearRampToValueAtTime(r, t) : e.setValueAtTime(r, t);
		}
	}), e;
}
function G(e, t) {
	if (typeof e.cancelAndHoldAtTime == "function") {
		e.cancelAndHoldAtTime(t);
		return;
	}
	let n = W.get(e)?.hold;
	if (n) n(t);
	else {
		let n = e.value;
		e.cancelScheduledValues(t), e.setValueAtTime(n, t);
	}
}
//#endregion
//#region src/audio/drums.ts
var Ft = [
	205.3,
	304.4,
	369.6,
	522.7,
	540,
	800
], It = (e) => 2 ** (e / 12);
function Lt(e, t, n, { keep: r, start: i, noise: a }) {
	let o = /* @__PURE__ */ new Set(), s = /* @__PURE__ */ new Map(), c = (t = 0, i = n) => {
		let a = r(e.createGain());
		return a.gain.value = t, a.connect(i), a;
	}, l = (t, n, i = .7) => {
		let a = r(e.createBiquadFilter());
		return a.type = t, a.frequency.value = n, a.Q.value = i, a;
	}, u = (...e) => (e.reduce((e, t) => e.connect(t)), e.at(-1)), d = null, f = () => (d || (d = i(e.createBufferSource()), d.buffer = a, d.loop = !0), d), p = (t, n) => {
		let a = r(e.createGain());
		return a.gain.value = n, {
			sum: a,
			oscillators: t.map((t) => {
				let n = i(e.createOscillator());
				return n.type = "square", n.frequency.value = t, n.connect(a), n;
			})
		};
	}, m = /* @__PURE__ */ new Map(), h = (t, n, r, i, a = 5e-4) => {
		Pt(t, e);
		let o = m.get(t) ?? [], s = o.filter((t) => t.time < e.currentTime).at(-1);
		m.set(t, [
			...s ? [s] : [],
			...o.filter((t) => t.time >= e.currentTime),
			{
				time: n,
				peak: r,
				decay: i,
				rise: a
			}
		].sort((e, t) => e.time - t.time)), t.setTargetAtTime(r, n, a), t.setTargetAtTime(0, n + a * 5, i / 4.6);
	}, g = (e, t) => e.setTargetAtTime(0, t, .003);
	function _(e) {
		if (o.delete(e)) {
			for (let t of [
				...e.sources,
				...e.nodes,
				e.vca
			]) t.disconnect();
			s.get(e.voice) === e && s.delete(e.voice);
		}
	}
	function v(t, r, i, a, c, l = n) {
		let u = e.createGain(), d = [];
		u.gain.value = 0, Pt(u.gain, e), u.connect(l);
		let f = {
			voice: t,
			vca: u,
			nodes: d,
			sources: c(u, d),
			start: r,
			end: r + a * 1.25 + .05,
			naturalEnd: r + a * 1.25 + .05,
			decay: a
		};
		u.gain.setValueAtTime(0, r), u.gain.linearRampToValueAtTime(i, r + .0015), u.gain.setTargetAtTime(0, r + .0015, a / 4.6);
		for (let e of f.sources) e.start(r), e.stop(f.end);
		f.sources[0].onended = () => _(f), o.add(f);
		let p = s.get(t), [m, h] = p && p.start > r ? [f, p] : [p, f];
		if (s.set(t, h), m && o.has(m) && m.end > h.start) {
			m.vca.gain.setTargetAtTime(0, h.start, .002), m.end = h.start + .03, m.chokeAt = h.start;
			for (let e of m.sources) e.stop(m.end);
		}
	}
	let y = (t, n, r, i, a = 1) => {
		let o = e.createOscillator();
		if (o.type = r, o.frequency.value = i, a === 1) o.connect(t);
		else {
			let r = e.createGain();
			r.gain.value = a, o.connect(r).connect(t), n.push(r);
		}
		return o;
	}, b = (e, t, n, r, i) => {
		e.frequency.setValueAtTime(n * r, t), e.frequency.exponentialRampToValueAtTime(n, t + i);
	}, x = () => {};
	if (t === "boom") {
		let e = c(), t = c(), n = c(), r = c(), i = c(), a = c(), o = c(), s = c();
		u(f(), l("highpass", 1800), e), u(f(), l("highpass", 5e3), t), u(f(), l("bandpass", 1e3, 1.4), n);
		let d = p(Ft, .5).sum, m = u(d, l("bandpass", 1e4, 1), l("highpass", 7e3));
		m.connect(r), m.connect(i);
		let _ = l("highpass", 5e3);
		u(d, l("bandpass", 7e3, .5), _), u(f(), c(.35, _)), _.connect(a), u(p(Ft.map((e) => e * 1.13), .5).sum, l("bandpass", 4800, 2.5), l("highpass", 3e3), o);
		let S = p([540, 800], .5);
		u(S.sum, l("bandpass", 2640, 1.4), s);
		let C = (e, t, n, r) => v(e, t, .9, r, (e, r) => {
			let i = y(e, r, "sine", n), a = y(e, r, "triangle", n * 1.5, .15);
			return b(i, t, n, 1.6, .06), b(a, t, n * 1.5, 1.6, .06), [i, a];
		});
		x = (c, l, u) => {
			if (c === "kick") v("kick", l, 1, u.kickDecay, (e) => {
				let t = y(e, [], "sine", u.kickTune);
				return b(t, l, u.kickTune, 2, .025), [t];
			});
			else if (c === "snare") {
				let t = u.snareTone;
				v("snare", l, .55, .13, (e, n) => [y(e, n, "sine", 185, 1 - .6 * t), y(e, n, "sine", 330, .35 + .65 * t)]), h(e.gain, l, .6 * u.snappy, .2);
			} else if (c === "rim") v("rim", l, .7, .03, (e, t) => [y(e, t, "triangle", 455, .6), y(e, t, "triangle", 1667)]), h(t.gain, l, .5, .008);
			else if (c === "clap") {
				for (let e of [
					0,
					.01,
					.021
				]) h(n.gain, l + e, 1.4, .016, 4e-4);
				h(n.gain, l + .032, 1.4, .2);
			} else if (c === "hat") g(i.gain, l), h(r.gain, l, 1.25, u.hatDecay);
			else if (c === "open") h(i.gain, l, 1, u.openDecay);
			else if (c === "lowTom") C("lowTom", l, 95 * It(u.tomTune), u.tomDecay);
			else if (c === "highTom") C("highTom", l, 145 * It(u.tomTune), u.tomDecay * .85);
			else if (c === "crash") h(a.gain, l, .75, u.crashDecay, .002);
			else if (c === "ride") h(o.gain, l, .8, u.rideDecay, .001);
			else if (c === "bell") {
				let e = It(u.bellTune);
				S.oscillators.forEach((t, n) => t.frequency.setValueAtTime([540, 800][n] * e, l)), h(s.gain, l, .9, .32);
			}
		};
	} else if (t === "punch") {
		let t = r(e.createWaveShaper()), i = c(1, t), a = c(0, i), o = c(), s = c(), d = c(), m = c();
		t.curve = Float32Array.from({ length: 1025 }, (e, t) => Math.tanh(2.2 * (t / 512 - 1)) / Math.tanh(2.2)), t.oversample = "2x", t.connect(n), u(f(), l("lowpass", 4e3), a);
		let _ = l("lowpass", 6e3);
		u(f(), l("highpass", 1200), _, o), u(f(), l("bandpass", 1100, 1.6), s);
		let S = l("highpass", 7500);
		u(p(Ft.map((e) => e * 1.5), .5).sum, S), u(f(), c(.35, S)), S.connect(d), S.connect(m), x = (e, t, n) => {
			if (e === "kick") v("kick", t, 1, n.kickDecay, (e) => {
				let r = y(e, [], "sine", n.kickTune), i = r.frequency;
				return i.setValueAtTime(n.kickTune * 5, t), i.exponentialRampToValueAtTime(n.kickTune * 1.3, t + .03), i.exponentialRampToValueAtTime(n.kickTune, t + .16), [r];
			}, i), h(a.gain, t, .7 * n.kickClick, .012);
			else if (e === "snare") v("snare", t, .5, .11, (e, n) => [180, 330].map((r, i) => {
				let a = y(e, n, "triangle", r, i ? .6 : 1);
				return b(a, t, r, 1.15, .02), a;
			})), _.frequency.setValueAtTime(3e3 + 7e3 * n.snareTone, t), h(o.gain, t, .75 * n.snappy, .18);
			else if (e === "clap") {
				for (let e of [
					0,
					.011,
					.022
				]) h(s.gain, t + e, 1.5, .018, 4e-4);
				h(s.gain, t + .033, 1.5, .24);
			} else e === "hat" ? (g(m.gain, t), h(d.gain, t, .9, n.hatDecay)) : e === "open" && h(m.gain, t, .75, n.openDecay);
		};
	} else if (t === "orbit") {
		let e = l("bandpass", 6500, 1.2), t = c(), n = l("highpass", 4500), r = c();
		u(f(), e, l("highpass", 3e3), t), u(f(), n, r), x = (i, a, o) => {
			let s = It(o.pitch + o[`${i}Tune`]), c = o[`${i}Decay`], l = o[`${i}Level`], u = o[`${i}Tone`];
			i === "skin" || i === "tom" ? v(i, a, (i === "skin" ? .8 : .95) * l, c, (e, t) => {
				let n = (i === "skin" ? 196 : 98) * s, r = y(e, t, "sine", n), o = y(e, t, "sine", n * (i === "skin" ? 311 / 196 : 1.5), u * .5);
				return b(r, a, n, i === "skin" ? 1.4 : 2.2, .035), b(o, a, n * (i === "skin" ? 311 / 196 : 1.5), 1.4, .035), [r, o];
			}) : i === "wood" ? v("wood", a, .6 * l, c, (e, t) => {
				let n = y(e, t, "sine", 1450 * s), r = y(e, t, "sine", 3915 * s, u * .6);
				return b(n, a, 1450 * s, 1.05, .005), [n, r];
			}) : i === "sand" ? (e.frequency.setValueAtTime(Math.min(18e3, 6500 * s * (.5 + u)), a), h(t.gain, a, .9 * l, c, .004)) : i === "shaker" ? (n.frequency.setValueAtTime(Math.min(16e3, (1500 + u * 6e3) * s), a), h(r.gain, a, .65 * l, c, .008)) : i === "metal" && v("metal", a, .3 * l, c, (e, t) => [
				440,
				623,
				1067,
				1573
			].map((n, r) => y(e, t, r ? "sine" : "triangle", n * s, r ? .15 + u * .7 : 1)));
		};
	}
	return {
		trigger: x,
		cancelScheduled(e) {
			for (let t of [...o]) if (t.start >= e) {
				for (let n of t.sources) n.stop(e);
				_(t);
			}
			s.clear();
			for (let t of o) {
				if (t.chokeAt !== void 0 && t.chokeAt >= e) {
					G(t.vca.gain, e), t.vca.gain.setTargetAtTime(0, e, t.decay / 4.6), t.end = t.naturalEnd, t.chokeAt = void 0;
					for (let e of t.sources) e.stop(t.end);
				}
				(!s.has(t.voice) || s.get(t.voice).start < t.start) && s.set(t.voice, t);
			}
			for (let [t, n] of m) {
				let r = n.filter((t) => t.time < e).at(-1);
				G(t, e), r ? t.setTargetAtTime(0, Math.max(e, r.time + r.rise * 5), r.decay / 4.6) : t.setValueAtTime(0, e), m.set(t, r ? [r] : []);
			}
		},
		dispose() {
			for (let e of o) for (let t of e.sources) t.stop();
			for (let e of [...o]) _(e);
			s.clear();
		}
	};
}
//#endregion
//#region src/audio/envelope.ts
function Rt(e) {
	let t = [], n = (e) => {
		let n = t.findIndex(([t]) => t > e);
		if (n === 0 || !t.length) return 0;
		if (n < 0) return t[t.length - 1][1];
		let [r, i] = t[n - 1], [a, o] = t[n];
		return i + (o - i) * (e - r) / (a - r);
	}, r = (r, ...i) => {
		let a = n(r);
		G(e, r), e.setValueAtTime(a, r);
		for (let [t, n] of i) e.linearRampToValueAtTime(n, t);
		t = [
			...t.filter(([e]) => e < r).slice(-16),
			[r, a],
			...i
		];
	};
	return {
		on(e, t, n, i, a) {
			r(e, [e + n, t], [e + n + i, t * a]);
		},
		off(e, t) {
			r(e, [e + t, 0]);
		}
	};
}
//#endregion
//#region src/audio/monarch.ts
var zt = [
	"sine",
	"triangle",
	"sawtooth",
	"square"
];
function Bt(e, t, { keep: n, source: r }) {
	let i = (t = 1) => {
		let r = n(e.createGain());
		return r.gain.value = t, r;
	}, a = i(), o = i(), s = i(), c = n(e.createWaveShaper()), l = n(e.createBiquadFilter());
	l.type = "lowpass", l.Q.value = .5, a.connect(l);
	let u = [n(e.createBiquadFilter()), n(e.createBiquadFilter())], d = i(0), f = i(), p = i(.5), m = i();
	s.connect(c).connect(u[0]).connect(u[1]).connect(d).connect(f);
	let h = r(e.createConstantSource()), g = r(e.createConstantSource());
	h.offset.value = 0, g.offset.value = 0, h.connect(d.gain), g.connect(m), l.connect(p);
	for (let e of u) e.type = "lowpass", o.connect(e.detune), m.connect(e.detune), p.connect(e.detune);
	let _ = [
		1,
		2,
		3
	].map(() => {
		let t = r(e.createOscillator()), n = i();
		return t.frequency.value = 261.625565, t.connect(n).connect(s), l.connect(t.detune), {
			osc: t,
			level: n
		};
	}), v = r(e.createBufferSource()), y = i(0);
	v.buffer = t, v.loop = !0, v.connect(y).connect(s);
	let b = {}, x = !1, S = -1, C = (t, n) => {
		x ? t.setTargetAtTime(n, e.currentTime, .008) : t.value = n;
	}, w = [[Rt(h.offset), "amp"], [Rt(g.offset), "filter"]];
	return {
		pitch: a,
		cv: o,
		output: f,
		apply(t) {
			if (b = t, _.forEach(({ osc: e, level: n }, r) => {
				let i = `osc${r + 1}`;
				e.type = zt[t[`${i}Wave`]], C(e.detune, t[`${i}Octave`] * 1200 + t[`${i}Detune`]), C(n.gain, t[`${i}Level`] * .23);
			}), C(y.gain, t.noise * .15), C(f.gain, t.level), C(l.frequency, t.glide ? Math.min(e.sampleRate * .45, 1 / (2 * Math.PI * t.glide)) : e.sampleRate * .45), C(p.gain, t.tracking), C(m.gain, t.envAmount * 4800), u.forEach((e, n) => {
				C(e.frequency, t.cutoff), C(e.Q, n === 0 ? .707 + t.resonance * 5 : .707);
			}), S !== t.drive) {
				S = t.drive;
				let e = 1 + t.drive * 5;
				c.curve = Float32Array.from({ length: 2049 }, (t, n) => Math.tanh(e * (n / 1024 - 1)) / Math.tanh(e)), c.oversample = "2x";
			}
			x = !0;
		},
		noteOn(e, t) {
			for (let [n, r] of w) n.on(t, e, b[`${r}Attack`], b[`${r}Decay`], b[`${r}Sustain`]);
		},
		noteOff(e) {
			for (let [t, n] of w) t.off(e, b[`${n}Release`]);
		}
	};
}
//#endregion
//#region src/audio/poly.ts
function Vt(e, t) {
	let n = !1, r;
	return (i, a) => {
		if (clearTimeout(r), r = void 0, i && !n) e.connect(t), n = !0;
		else if (!i && n) {
			let i = () => {
				r = void 0, n = !1;
				try {
					e.disconnect(t);
				} catch {}
			};
			a ? i() : r = setTimeout(i, 100);
		}
	};
}
var Ht = class {
	voices;
	constructor(e = 5) {
		this.voices = Array.from({ length: e }, () => ({
			key: null,
			start: -Infinity,
			releaseAt: -Infinity,
			freeAt: -Infinity
		}));
	}
	allocate(e, t = /* @__PURE__ */ new Set()) {
		let n = this.voices.map((e, t) => ({
			voice: e,
			index: t
		})).filter(({ index: e }) => !t.has(e)), r = (e, t) => e.reduce((e, n) => t(n.voice) < t(e.voice) ? n : e).index, i = n.filter(({ voice: t }) => t.freeAt <= e), a = n.filter(({ voice: t }) => t.releaseAt <= e);
		return i.length ? r(i, (e) => e.freeAt) : a.length ? r(a, (e) => e.releaseAt) : r(n, (e) => e.start);
	}
	start(e, t, n) {
		Object.assign(this.voices[e], {
			key: t,
			start: n,
			releaseAt: Infinity,
			freeAt: Infinity
		});
	}
	release(e, t, n) {
		return this.voices.flatMap((r, i) => {
			if (n !== void 0 && r.key !== n || r.releaseAt <= e) return [];
			let a = r.start > e;
			return Object.assign(r, {
				start: Math.min(r.start, e),
				releaseAt: e,
				freeAt: e + t
			}), [{
				index: i,
				pending: a
			}];
		});
	}
}, Ut = [
	[
		4,
		-3,
		70
	],
	[
		-5,
		2,
		-40
	],
	[
		1,
		6,
		110
	],
	[
		-2,
		-6,
		-90
	],
	[
		6,
		1,
		20
	]
], Wt = 261.625565;
function Gt(e, t, { keep: n, source: r }) {
	let i = (t = 1) => {
		let r = n(e.createGain());
		return r.gain.value = t, r;
	}, a = (t = 0) => {
		let n = r(e.createConstantSource());
		return n.offset.value = t, n;
	}, o = (e) => Float32Array.from({ length: 1025 }, (t, n) => Math.tanh(e * (n / 512 - 1)) / Math.tanh(e)), s = (t, r, i) => {
		let a = n(e.createWaveShaper());
		return a.curve = o(24), a.oversample = "4x", t.connect(a), r.connect(a), Vt(a, i);
	}, c = i(), l = i(), u = i(.5), d = i(), f = n(e.createBiquadFilter());
	f.type = "highpass", f.frequency.value = 20, f.Q.value = -3.01, u.connect(f).connect(d);
	let p = r(e.createBufferSource()), m = i(0);
	p.buffer = t, p.loop = !0, p.connect(m);
	let h = r(e.createOscillator()), g = i(0), _ = i(0), v = i(0);
	h.connect(g), h.connect(_), h.connect(v);
	let y = Ut.map((t) => {
		let o = a(), d = a(), f = a(), p = a(), h = a(), y = r(e.createOscillator()), b = r(e.createOscillator());
		y.type = "sawtooth", y.frequency.value = Wt, b.frequency.value = Wt;
		let x = i(), S = i(0), C = i(), w = i(), T = i(), E = i(0), D = i(), ee = i();
		y.connect(x).connect(C), S.connect(C);
		let te = s(y, p, S);
		b.connect(T).connect(D), E.connect(D);
		let ne = s(b, h, E), re = i(), O = i(0), k = [n(e.createBiquadFilter()), n(e.createBiquadFilter())];
		C.connect(w).connect(re), D.connect(ee).connect(re), m.connect(re), re.connect(k[0]).connect(k[1]).connect(O).connect(u), d.connect(O.gain);
		let A = i(), j = i(), M = i(0), N = i(0), P = i(), ie = i(0), ae = i(0);
		f.connect(j), f.connect(M).connect(P), D.connect(N).connect(P), P.connect(ie).connect(y.detune), P.connect(ae);
		for (let e of [y.detune, b.detune]) o.connect(e), c.connect(e), g.connect(e);
		o.connect(A), c.connect(A), _.connect(p.offset), _.connect(h.offset);
		for (let e of k) {
			e.type = "lowpass";
			for (let t of [
				A,
				j,
				ae,
				l,
				v
			]) t.connect(e.detune);
		}
		return {
			drift: t,
			note: o,
			amp: d,
			filterEnv: f,
			a: y,
			b,
			aWidth: p,
			bWidth: h,
			aComparator: te,
			bComparator: ne,
			aSaw: x,
			aPulse: S,
			aLevel: w,
			bWave: T,
			bPulse: E,
			bLevel: ee,
			filters: k,
			tracking: A,
			envDepth: j,
			polyEnv: M,
			polyB: N,
			polyA: ie,
			polyFilter: ae,
			pitched: !1
		};
	}), b = new Ht(y.length), x = {}, S = !1, C = (t, n) => {
		S ? t.setTargetAtTime(n, e.currentTime, .008) : t.value = n;
	}, w = (e, t, n, r) => {
		let i = Math.max(.001, x[`${t}Attack`]);
		G(e, r), e.linearRampToValueAtTime(n, r + i), e.setTargetAtTime(n * x[`${t}Sustain`], r + i, Math.max(.001, x[`${t}Decay`]) / 3);
	}, T = (e, t, n) => {
		G(e, n), e.setTargetAtTime(0, n, Math.max(.001, x[`${t}Release`]) / 4);
	}, E = (e, t) => {
		for (let { index: n, pending: r } of b.release(e, x.ampRelease, t)) {
			let t = y[n];
			r && G(t.note.offset, e), T(t.amp.offset, "amp", e), T(t.filterEnv.offset, "filter", e);
		}
	};
	return {
		pitch: c,
		cv: l,
		output: d,
		apply(e) {
			x = e;
			let t = e.vintage, n = e.aShape, r = e.bShape, i = e.polyDest, a = e.lfoDest;
			for (let a of y) C(a.a.detune, e.aOctave * 1200 + a.drift[0] * t), C(a.b.detune, e.bOctave * 1200 + e.bFine + a.drift[1] * t), a.b.type = r === 1 ? "triangle" : "sawtooth", C(a.aSaw.gain, n === 1 ? 0 : n === 2 ? .7 : 1), C(a.aPulse.gain, n === 0 ? 0 : n === 2 ? .7 : 1), C(a.bWave.gain, r === 2 ? 0 : 1), C(a.bPulse.gain, +(r === 2)), a.aComparator(n !== 0, !S), a.bComparator(r === 2, !S), C(a.aWidth.offset, 2 * e.aWidth - 1), C(a.bWidth.offset, 2 * e.bWidth - 1), C(a.aLevel.gain, e.aLevel * .25), C(a.bLevel.gain, e.bLevel * .25), C(a.polyEnv.gain, e.polyEnv * 3600), C(a.polyB.gain, e.polyOscB * 2400), C(a.polyA.gain, i === 1 ? 0 : 1), C(a.polyFilter.gain, i === 0 ? 0 : 1), C(a.tracking.gain, e.tracking), C(a.envDepth.gain, e.envAmount * 6e3), a.filters.forEach((n, r) => {
				C(n.frequency, e.cutoff), C(n.detune, a.drift[2] * t), C(n.Q, r === 0 ? -3.01 + e.resonance * 20 : -3.01);
			});
			h.type = [
				"triangle",
				"sawtooth",
				"square"
			][e.lfoShape], C(h.frequency, e.lfoRate), C(g.gain, a === 0 ? e.lfoAmount * 300 : 0), C(_.gain, a === 1 ? e.lfoAmount * .9 : 0), C(v.gain, a === 2 ? e.lfoAmount * 2400 : 0), C(m.gain, e.noise * .2), C(d.gain, e.level), S = !0;
		},
		noteOn(e, t, n, r) {
			E(n, r);
			let i = /* @__PURE__ */ new Set();
			for (let a of (le[x.chord]?.[1] ?? [0]).slice(0, y.length)) {
				let o = b.allocate(n, i), s = y[o], c = (e + a - 60) * 100;
				i.add(o), b.start(o, r, n), G(s.note.offset, n), x.glide > 0 && s.pitched ? s.note.offset.setTargetAtTime(c, n, x.glide / 3) : s.note.offset.setValueAtTime(c, n), s.pitched = !0, w(s.amp.offset, "amp", t, n), w(s.filterEnv.offset, "filter", t, n);
			}
		},
		noteOff: E
	};
}
//#endregion
//#region src/audio/aurora.ts
function Kt(e, { keep: t, source: n }) {
	let r = (n = 1) => {
		let r = t(e.createGain());
		return r.gain.value = n, r;
	}, i = () => {
		let t = n(e.createConstantSource());
		return t.offset.value = 0, t;
	}, a = r(), o = r(), s = r(), c = r(.22);
	c.connect(s);
	let l = n(e.createOscillator()), u = r(0), d = r(0), f = r(0);
	l.connect(u), l.connect(d), l.connect(f);
	let p = Float32Array.from({ length: 2049 }, (e, t) => Math.tanh(24 * (t / 1024 - 1))), m = Array.from({ length: 8 }, (s, l) => {
		let m = i(), h = i(), g = i(), _ = r(), v = r(0), y = r(), b = r(), x = r(0), S = [0, 1].map(() => {
			let o = n(e.createOscillator()), s = i(), c = r(), l = r(0), f = r(), h = r();
			o.frequency.value = 261.625565;
			let g = t(e.createWaveShaper());
			return g.curve = p, g.oversample = "4x", o.connect(c).connect(h), o.connect(g), s.connect(g), l.connect(h), h.connect(f).connect(_), m.connect(o.detune), a.connect(o.detune), u.connect(o.detune), d.connect(s.offset), {
				osc: o,
				width: s,
				raw: c,
				pulse: l,
				level: f,
				out: h,
				pulsed: Vt(g, l)
			};
		});
		S[1].out.connect(x).connect(S[0].osc.detune);
		let C = t(e.createBiquadFilter()), w = [t(e.createBiquadFilter()), t(e.createBiquadFilter())];
		C.type = "highpass", C.Q.value = -3.01;
		let T = r(0), E = r(1);
		_.connect(C).connect(w[0]), w[0].connect(T).connect(v), w[0].connect(w[1]).connect(E).connect(v), h.connect(v.gain), v.connect(c), m.connect(y), a.connect(y), g.connect(b);
		for (let e of w) e.type = "lowpass", y.connect(e.detune), b.connect(e.detune), o.connect(e.detune), f.connect(e.detune);
		return {
			note: m,
			oscillators: S,
			hpf: C,
			filters: w,
			twoPole: T,
			fourPole: E,
			tracking: y,
			amount: b,
			cross: x,
			amp: Rt(h.offset),
			env: Rt(g.offset),
			pitched: !1,
			drift: [
				3,
				-4,
				1,
				5,
				-2,
				4,
				-5,
				2
			][l]
		};
	}), h = new Ht(8), g = {}, _ = !1, v = (t, n) => {
		_ ? t.setTargetAtTime(n, e.currentTime, .008) : t.value = n;
	}, y = (e, t) => {
		for (let { index: n, pending: r } of h.release(e, g.ampRelease, t)) {
			let t = m[n];
			r && G(t.note.offset, e), t.amp.off(e, g.ampRelease), t.env.off(e, g.filterRelease);
		}
	};
	return {
		pitch: a,
		cv: o,
		output: s,
		apply(e) {
			g = e;
			for (let t of m) t.oscillators.forEach((n, r) => {
				let i = `osc${r + 1}`, a = e[`${i}Wave`];
				n.osc.type = [
					"sawtooth",
					"sawtooth",
					"triangle",
					"sine"
				][a], v(n.osc.detune, e[`${i}Octave`] * 1200 + e[`${i}Detune`] + t.drift * e.vintage * (r ? -.7 : 1)), v(n.width.offset, 2 * e[`${i}Width`] - 1), v(n.raw.gain, a === 1 ? 0 : 1), v(n.pulse.gain, +(a === 1)), n.pulsed(a === 1, !_), v(n.level.gain, r ? e.blend : 1 - e.blend);
			}), v(t.cross.gain, e.crossMod * 1800), v(t.hpf.frequency, e.hpf), v(t.twoPole.gain, +(e.slope === 0)), v(t.fourPole.gain, +(e.slope === 1)), t.filters.forEach((n, r) => {
				v(n.frequency, e.cutoff), v(n.Q, r ? -3.01 : -3.01 + e.resonance * 17), v(n.detune, t.drift * e.vintage * 9);
			}), v(t.tracking.gain, e.tracking), v(t.amount.gain, e.envAmount * 6e3);
			l.type = [
				"triangle",
				"sine",
				"square"
			][e.lfoShape], v(l.frequency, e.lfoRate), v(u.gain, e.lfoPitch * 100), v(d.gain, e.lfoWidth * .8), v(f.gain, e.lfoFilter * 2400), v(s.gain, e.level), _ = !0;
		},
		noteOn(e, t, n, r) {
			y(n, r);
			let i = /* @__PURE__ */ new Set();
			for (let a of le[g.chord]?.[1] ?? [0]) {
				let o = h.allocate(n, i), s = m[o], c = (e + a - 60) * 100;
				i.add(o), h.start(o, r, n), G(s.note.offset, n), g.glide && s.pitched ? s.note.offset.setTargetAtTime(c, n, g.glide / 3) : s.note.offset.setValueAtTime(c, n), s.pitched = !0, s.amp.on(n, t, g.ampAttack, g.ampDecay, g.ampSustain), s.env.on(n, 1, g.filterAttack, g.filterDecay, g.filterSustain);
			}
		},
		noteOff: y
	};
}
//#endregion
//#region src/audio/worklets.ts
var qt = ["/** Self-contained phase-modulation DSP, imported directly by tests and as inline source by the worklet loader. */\nexport const ALGORITHMS = [\n  {inputs: [[1], [], [3], [], [5], []], carriers: [0, 2, 4]},\n  {inputs: [[1], [2], [], [4], [5], []], carriers: [0, 3]},\n  {inputs: [[1], [2], [3], [4], [5], []], carriers: [0]},\n  {inputs: [[3], [3], [3], [4, 5], [], []], carriers: [0, 1, 2]},\n  {inputs: [[1, 2], [3], [4], [], [5], []], carriers: [0]},\n  {inputs: [[], [], [], [], [], []], carriers: [0, 1, 2, 3, 4, 5]},\n];\nconst TAU = 2 * Math.PI;\nexport class PrismDSP {\n  constructor(rate) {\n    this.rate = rate; this.events = []; this.params = {}; this.level = 0; this.disposed = false;\n    this.voices = Array.from({length: 16}, () => ({key: null, start: -Infinity, released: -Infinity, free: -Infinity,\n      phase: new Float64Array(6), env: new Float64Array(6), stage: new Uint8Array(6), attackStep: new Float64Array(6), releaseStep: new Float64Array(6), values: new Float64Array(6), frequency: 0, velocity: 1, feedback: 0, lastFeedback: 0}));\n  }\n  enqueue(event) {\n    if (event.type === 'off') this.events = this.events.filter(e => !(e.time >= event.time && (event.key === undefined || e.key === event.key) && (e.type === 'on' || e.type === 'off')));\n    this.events.push(event); this.events.sort((a, b) => a.time - b.time);\n  }\n  release(time, key) {\n    for (const v of this.voices) if (v.key !== null && (key === undefined || v.key === key) && v.released === Infinity) {\n      v.released = time; v.free = time + Math.max(...this.ops.map(o => o.release));\n      for (let i = 0; i < 6; i++) {v.stage[i] = 3; v.releaseStep[i] = v.env[i] / (this.ops[i].release * this.rate);}\n    }\n  }\n  apply(event) {\n    if (event.type === 'params') {\n      this.params = event.params;\n      this.ops = Array.from({length: 6}, (_, i) => {const id = `op${i + 1}`, p = this.params; return {\n        ratio: p[`${id}Ratio`] * 2 ** (p[`${id}Detune`] / 1200), level: p[`${id}Level`], attack: p[`${id}Attack`],\n        decay: Math.exp(-1 / (p[`${id}Decay`] * this.rate / 4)), sustain: p[`${id}Sustain`], release: p[`${id}Release`],\n      };});\n    } else if (event.type === 'off') this.release(event.time, event.key);\n    else if (event.type === 'on' && this.ops) {\n      this.release(event.time, event.key);\n      const taken = new Set();\n      for (const note of event.notes) {\n        const available = this.voices.filter(v => !taken.has(v));\n        const silent = available.filter(v => v.free <= event.time), released = available.filter(v => v.released <= event.time);\n        const candidates = silent.length ? silent : released.length ? released : available;\n        const field = silent.length ? 'free' : released.length ? 'released' : 'start';\n        const v = candidates.reduce((a, b) => b[field] < a[field] ? b : a);\n        taken.add(v);\n        if (v.free <= event.time) {v.phase.fill(0); v.env.fill(0); v.feedback = 0; v.lastFeedback = 0;}\n        v.key = event.key; v.start = event.time; v.free = Infinity; v.released = Infinity;\n        v.frequency = 440 * 2 ** ((note - 69) / 12); v.velocity = event.velocity;\n        for (let i = 0; i < 6; i++) {v.stage[i] = 0; v.attackStep[i] = (1 - v.env[i]) / (this.ops[i].attack * this.rate);}\n      }\n    }\n  }\n  render(output, startFrame, pitch, brightness) {\n    if (this.disposed) {output.fill(0); return;}\n    for (let n = 0; n < output.length; n++) {\n      const time = (startFrame + n) / this.rate;\n      while (this.events.length && this.events[0].time <= time) this.apply(this.events.shift());\n      if (!this.ops) {output[n] = 0; continue;}\n      const p = this.params, algorithm = ALGORITHMS[p.algorithm];\n      const bend = (pitch?.[n] ?? 0) + Math.sin(TAU * p.lfoRate * time) * p.lfoDepth * 100;\n      const tune = 2 ** (Math.max(-9600, Math.min(9600, bend)) / 1200);\n      const color = Math.max(0, Math.min(4, p.brightness + (brightness?.[n] ?? 0)));\n      let sum = 0;\n      for (let index = 0; index < this.voices.length; index++) {\n        const v = this.voices[index];\n        if (v.free <= time) continue;\n        const touch = 1 - p.velocity + p.velocity * v.velocity;\n        for (let i = 5; i >= 0; i--) {\n          const op = this.ops[i];\n          if (v.stage[i] === 0) {v.env[i] = Math.min(1, v.env[i] + v.attackStep[i]); if (v.env[i] >= 1) v.stage[i] = 1;}\n          else if (v.stage[i] === 1) v.env[i] = op.sustain + (v.env[i] - op.sustain) * op.decay;\n          else v.env[i] = Math.max(0, v.env[i] - v.releaseStep[i]);\n          const frequency = Math.min(this.rate * 0.45, v.frequency * tune * op.ratio);\n          // The step is under half a turn, so subtracting a turn wraps exactly as the remainder would.\n          v.phase[i] += TAU * frequency / this.rate; if (v.phase[i] >= TAU) v.phase[i] -= TAU;\n          // A released operator at zero contributes nothing, so its sine is skipped.\n          if (v.env[i] === 0) {v.values[i] = 0; continue;}\n          let modulation = i === 5 ? (v.feedback + v.lastFeedback) * 0.5 * p.feedback * 3.5 : 0;\n          const inputs = algorithm.inputs[i];\n          for (let k = 0; k < inputs.length; k++) modulation += v.values[inputs[k]] * 5 * color * touch;\n          v.values[i] = Math.sin(v.phase[i] + modulation) * v.env[i] * op.level;\n        }\n        v.lastFeedback = v.feedback; v.feedback = v.values[5];\n        let voice = 0;\n        for (let k = 0; k < algorithm.carriers.length; k++) voice += v.values[algorithm.carriers[k]];\n        sum += voice / Math.sqrt(algorithm.carriers.length) * v.velocity;\n      }\n      this.level += (p.level - this.level) * 0.003;\n      output[n] = sum * this.level * 0.18;\n    }\n  }\n}\n// The guard lets unit tests import the exact processor DSP without an audio environment.\nif (typeof registerProcessor !== 'undefined') {\n  class PrismProcessor extends AudioWorkletProcessor {\n    constructor() {\n      super(); this.dsp = new PrismDSP(sampleRate);\n      this.port.onmessage = ({data}) => {\n        if (data.type === 'flush') this.port.postMessage({id: data.id});\n        else if (data.type === 'dispose') {this.dsp.disposed = true; this.dsp.events = [];}\n        else this.dsp.enqueue(data);\n      };\n    }\n    process(inputs, outputs) {\n      this.dsp.render(outputs[0][0], currentFrame, inputs[0]?.[0], inputs[1]?.[0]);\n      return !this.dsp.disposed;\n    }\n  }\n  registerProcessor('rackloose-prism-v1', PrismProcessor);\n}\n", "/** Original behavioral models, not measured circuit replicas. See docs/studio-processors.md for calibration and sources. */\nexport const COHERE_ATTACKS = [0.0001, 0.0003, 0.001, 0.003, 0.01, 0.03];\nexport const COHERE_RELEASES = [0.1, 0.3, 0.6, 1.2];\nexport const TALON_RATIOS = [1, 2, 3, 4, 6, 10, 20, 100];\nexport const BRIT_LOW = [35, 60, 110, 220];\nexport const BRIT_MID = [360, 700, 1600, 3200, 4800, 7200];\nexport const BRIT_HP = [0, 50, 80, 160, 300];\nconst db = x => 10 ** (x / 20);\nconst unity = [1, 0, 0, 0, 0];\n\n/** Normalized biquads and one pole filters. A third-order Butterworth HP is a first order plus a Q=1 biquad. */\nexport function coefficients(type, frequency, gain, Q, rate) {\n  if (!frequency) return unity.slice();\n  const w = 2 * Math.PI * Math.min(frequency, rate * 0.45) / rate, c = Math.cos(w), s = Math.sin(w);\n  const A = 10 ** (gain / 40), alpha = s / (2 * Q), shelf = s * Math.sqrt(2 * A);\n  let b0, b1, b2, a0, a1, a2;\n  if (type === 'pole') {\n    const k = Math.tan(w / 2); return [1 / (1 + k), -1 / (1 + k), 0, (k - 1) / (k + 1), 0];\n  } else if (type === 'highpass') {\n    [b0, b1, b2, a0, a1, a2] = [(1 + c) / 2, -(1 + c), (1 + c) / 2, 1 + alpha, -2 * c, 1 - alpha];\n  } else if (type === 'bell') {\n    [b0, b1, b2, a0, a1, a2] = [1 + alpha * A, -2 * c, 1 - alpha * A, 1 + alpha / A, -2 * c, 1 - alpha / A];\n  } else if (type === 'low') {\n    [b0, b1, b2, a0, a1, a2] = [A * (A + 1 - (A - 1) * c + shelf), 2 * A * (A - 1 - (A + 1) * c), A * (A + 1 - (A - 1) * c - shelf), A + 1 + (A - 1) * c + shelf, -2 * (A - 1 + (A + 1) * c), A + 1 + (A - 1) * c - shelf];\n  } else {\n    [b0, b1, b2, a0, a1, a2] = [A * (A + 1 + (A - 1) * c + shelf), -2 * A * (A - 1 + (A + 1) * c), A * (A + 1 + (A - 1) * c - shelf), A + 1 - (A - 1) * c + shelf, 2 * (A - 1 - (A + 1) * c), A + 1 - (A - 1) * c - shelf];\n  }\n  return [b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0];\n}\nexport function britFilters(p, rate) {\n  const hp = BRIT_HP[p.hpf] ?? 0;\n  return [coefficients('pole', hp, 0, 1, rate), coefficients('highpass', hp, 0, 1, rate),\n    coefficients('low', BRIT_LOW[p.lfFreq] ?? 110, p.lfGain, 0.7, rate),\n    coefficients('bell', BRIT_MID[p.midFreq] ?? 1600, p.midGain, 0.75, rate), coefficients('high', 12000, p.hfGain, 0.7, rate)];\n}\nexport function britResponse(p, frequency, rate = 48000) {\n  if (p.active) return 0;\n  const w = 2 * Math.PI * frequency / rate;\n  const magnitude = (a, b, c) => Math.hypot(a + b * Math.cos(w) + c * Math.cos(2 * w), b * Math.sin(w) + c * Math.sin(2 * w));\n  return britFilters(p, rate).reduce((sum, [b0, b1, b2, a1, a2]) => sum + 20 * Math.log10(magnitude(b0, b1, b2) / magnitude(1, a1, a2)), 0);\n}\n\n/** Each TALON mode has its own threshold and knee; Input drives a fixed characteristic instead of moving a threshold. */\nfunction curveSettings(type, p) {\n  let ratio, threshold, knee;\n  if (type === 'cohere') {\n    ratio = [2, 4, 10][p.ratio] ?? 4;\n    threshold = p.threshold + [-3, 0, 2][p.ratio]; knee = [9, 6, 3][p.ratio];\n  } else {\n    ratio = TALON_RATIOS[p.ratio] ?? 6;\n    threshold = [-18, -26, -24, -22, -20, -18, -16, -18][p.ratio];\n    knee = [0, 15, 12, 9, 6, 4, 2, 3][p.ratio];\n    if (p.fierce) {ratio = Math.max(12, ratio * 2); threshold -= 3; knee = 2;}\n  }\n  return [1 - 1 / ratio, threshold, knee];\n}\nfunction curveGain(level, slope, threshold, knee) {\n  if (!slope) return 0;\n  const over = level - threshold;\n  return over <= -knee / 2 ? 0 : over >= knee / 2 ? -over * slope : -slope * (over + knee / 2) ** 2 / (2 * knee);\n}\nexport function compressionCurve(type, level, p) {return curveGain(level, ...curveSettings(type, p));}\n\nclass Filter {\n  constructor(rate) {this.c = unity.slice(); this.target = unity.slice(); this.z1 = 0; this.z2 = 0; this.smooth = 1 - Math.exp(-1 / (rate * 0.008));}\n  set(c, initial) {this.target = c; if (initial) this.c = c.slice();}\n  run(x) {\n    const c = this.c;\n    for (let i = 0; i < 5; i++) c[i] += (this.target[i] - c[i]) * this.smooth;\n    const y = c[0] * x + this.z1;\n    this.z1 = c[1] * x - c[3] * y + this.z2; this.z2 = c[2] * x - c[4] * y;\n    return y;\n  }\n}\n\n// 4x interpolation/decimation of the nonlinear residual only: linear audio keeps its full bandwidth.\n// Two symmetric 49-tap Blackman-windowed sinc FIRs give exactly 12 base-rate samples of delay.\nexport const FIR = Float64Array.from({length: 49}, (_, i) => {\n  const n = i - 24, cutoff = 0.1125;\n  return (n ? Math.sin(2 * Math.PI * cutoff * n) / (Math.PI * n) : 2 * cutoff) * (0.42 - 0.5 * Math.cos(2 * Math.PI * i / 48) + 0.08 * Math.cos(4 * Math.PI * i / 48));\n});\nconst total = FIR.reduce((sum, x) => sum + x, 0); for (let i = 0; i < FIR.length; i++) FIR[i] /= total;\nclass Fir {\n  constructor() {this.buffer = new Float64Array(49); this.index = 0;}\n  /** Stores `x` without computing an output, for decimation steps whose output is discarded. */\n  push(x) {this.buffer[this.index] = x; this.index = (this.index + 1) % 49;}\n  run(x) {\n    this.buffer[this.index] = x; let sum = 0, at = this.index;\n    for (let i = 0; i < 49; i++) {sum += FIR[i] * this.buffer[at]; if (--at < 0) at = 48;}\n    this.index = (this.index + 1) % 49; return sum;\n  }\n}\n/**\n * The FIR over a 4x zero-stuffed signal, computed polyphase: phase `i` reads only the taps that meet a real sample,\n * in the same order, so it matches the full filter exactly at a quarter of the work.\n */\nclass Interpolator {\n  constructor() {this.buffer = new Float64Array(13); this.index = 0;}\n  push(x) {this.index = this.index ? this.index - 1 : 12; this.buffer[this.index] = x;}\n  run(phase) {\n    let sum = 0, at = this.index;\n    for (let k = phase; k < 49; k += 4) {sum += FIR[k] * this.buffer[at]; if (++at > 12) at = 0;}\n    return sum;\n  }\n}\nexport const STUDIO_LATENCY = 12;\nclass Delay {\n  constructor() {this.buffer = new Float64Array(STUDIO_LATENCY); this.index = 0;}\n  run(x) {const y = this.buffer[this.index]; this.buffer[this.index] = x; this.index = (this.index + 1) % this.buffer.length; return y;}\n}\nexport class Color {\n  constructor(rate) {this.up = new Interpolator(); this.down = new Fir(); this.clean = new Delay(); this.previous = 0; this.blocked = 0; this.dc = Math.exp(-2 * Math.PI * 5 / rate);}\n  run(x, amount, bias) {\n    let residual = 0;\n    const offset = Math.tanh(bias), slope = amount * (1 - offset * offset);\n    this.up.push(x * 4);\n    for (let i = 0; i < 4; i++) {\n      const up = this.up.run(i);\n      const shaped = (Math.tanh(amount * up + bias) - offset) / slope;\n      // Only every fourth decimated sample is kept, so the others are stored without being filtered.\n      if (i === 0) residual = this.down.run(shaped - up); else this.down.push(shaped - up);\n    }\n    // AC coupling of the nonlinear residual removes the DC generated by asymmetric coloration.\n    this.blocked = residual - this.previous + this.dc * this.blocked; this.previous = residual;\n    return this.clean.run(x) + this.blocked;\n  }\n}\n\nexport class StudioDSP {\n  constructor(type, rate) {\n    this.type = type; this.rate = rate; this.params = null; this.events = []; this.disposed = false; this.reduction = 0;\n    this.gain = [0, 0]; this.memory = [0, 0]; this.input = 1; this.output = 1; this.wet = 1; this.drive = 0;\n    this.smooth = 1 - Math.exp(-1 / (rate * 0.008));\n    this.channels = Array.from({length: 2}, () => ({filters: Array.from({length: 5}, () => new Filter(rate)),\n      hp: new Filter(rate), emphasis: new Filter(rate), audioPole: new Filter(rate), audioHp: new Filter(rate), color: new Color(rate), dry: new Delay(), clean: new Delay(), amount: 0.15, bias: 0}));\n  }\n  enqueue(event) {this.events.push(event); this.events.sort((a, b) => a.time - b.time);}\n  configure(p) {\n    const initial = !this.params; this.params = {...p};\n    this.inputTarget = db(this.type === 'talon' ? p.input : 0); this.outputTarget = db(p.output);\n    this.wetTarget = p.active ? 0 : 1; this.driveTarget = p.drive ?? 0;\n    if (initial) {this.input = this.inputTarget; this.output = this.outputTarget; this.wet = this.wetTarget; this.drive = this.driveTarget;}\n    if (this.type !== 'brit') {\n      this.curveTarget = curveSettings(this.type, p); this.linkTarget = this.type === 'cohere' ? 1 : p.link;\n      this.attackTarget = this.type === 'cohere' ? COHERE_ATTACKS[p.attack] : p.attack;\n      this.releaseTarget = this.type === 'cohere' ? COHERE_RELEASES[p.release] ?? 0.3 : p.release;\n      if (initial) {this.curve = this.curveTarget.slice(); this.link = this.linkTarget; this.attack = this.attackTarget; this.release = this.releaseTarget;}\n    }\n    for (const channel of this.channels) {\n      if (this.type === 'brit') britFilters(p, this.rate).forEach((c, i) => channel.filters[i].set(c, initial));\n      const hp = this.type === 'cohere' ? [0, 30, 60, 106, 125, 185][p.scHpf] : p.detectorHp ? 80 : 0;\n      channel.hp.set(coefficients('highpass', hp, 0, Math.SQRT1_2, this.rate), initial);\n      channel.emphasis.set(coefficients('bell', 6000, p.detectorBand ? 10 : 0, 1, this.rate), initial);\n      // Third-order Bessel HP, normalized to -3 dB at 65 Hz. Distinct from the detector filter.\n      channel.audioPole.set(coefficients('pole', p.audioHp ? 65 * 0.754 : 0, 0, 1, this.rate), initial);\n      channel.audioHp.set(coefficients('highpass', p.audioHp ? 65 * 0.691 : 0, 0, 0.691, this.rate), initial);\n      if (initial && this.type === 'talon') {channel.amount = [0.15, 0.8, 1.5][p.color]; channel.bias = p.color === 1 ? 0.3 : 0;}\n    }\n  }\n  envelope(level, channel) {\n    const p = this.params, target = curveGain(level, this.curve[0], this.curve[1], this.curve[2]), current = this.gain[channel];\n    // A slow reservoir makes Auto and Opto depend on both the depth and duration of preceding compression.\n    this.memory[channel] += (Math.max(0, -current) - this.memory[channel]) * (1 - Math.exp(-1 / (this.rate * 0.6)));\n    let release = this.release;\n    if (this.type === 'cohere' && p.release === 4) release = 0.1 + Math.min(1.1, this.memory[channel] * 0.09);\n    if (this.type === 'talon') {\n      if (p.ratio === 5) release = Math.min(20, this.release * (1 + this.memory[channel] * 0.9));\n      else if (p.ratio === 7) release *= 0.45 + Math.min(1.5, Math.max(0, -current) / 15);\n      else release *= [1, 1.15, 1.05, 1, 0.9, 1, 0.8, 1][p.ratio];\n      if (p.ratio !== 5) release = Math.min(3.5, release);\n      if (p.fierce) release *= 0.65;\n    }\n    const seconds = target < current ? this.attack : release;\n    this.gain[channel] += (target - current) * (1 - Math.exp(-1 / (seconds * this.rate)));\n    return db(this.gain[channel]);\n  }\n  render(inputs, outputs, startFrame = 0) {\n    if (this.disposed) {outputs.forEach(out => out.fill(0)); return;}\n    const frames = outputs[0].length;\n    for (let n = 0; n < frames; n++) {\n      const time = (startFrame + n) / this.rate;\n      while (this.events.length && this.events[0].time <= time) this.configure(this.events.shift().params);\n      if (!this.params) {outputs.forEach(out => {out[n] = 0;}); continue;}\n      const p = this.params;\n      this.input += (this.inputTarget - this.input) * this.smooth; this.output += (this.outputTarget - this.output) * this.smooth;\n      this.wet += (this.wetTarget - this.wet) * this.smooth; this.drive += (this.driveTarget - this.drive) * this.smooth;\n      const left = inputs[0]?.[n] ?? 0, right = inputs[1]?.[n] ?? left;\n      const l = left * this.input, r = right * this.input;\n      let gainL = 1, gainR = 1;\n      if (this.type !== 'brit') {\n        for (let i = 0; i < 3; i++) this.curve[i] += (this.curveTarget[i] - this.curve[i]) * this.smooth;\n        this.link += (this.linkTarget - this.link) * this.smooth;\n        this.attack += (this.attackTarget - this.attack) * this.smooth; this.release += (this.releaseTarget - this.release) * this.smooth;\n        const a = this.channels[0], b = this.channels[1];\n        const levelL = 20 * Math.log10(Math.max(1e-12, Math.abs(a.emphasis.run(a.hp.run(l)))));\n        const levelR = 20 * Math.log10(Math.max(1e-12, Math.abs(b.emphasis.run(b.hp.run(r)))));\n        const dominant = Math.max(levelL, levelR);\n        this.envelope(levelL + this.link * (dominant - levelL), 0); this.envelope(levelR + this.link * (dominant - levelR), 1);\n        // Converge existing independent histories continuously when linking, never copy one channel's gain instantly.\n        const commonGain = Math.min(this.gain[0], this.gain[1]), commonMemory = Math.max(this.memory[0], this.memory[1]), coupling = this.link * this.smooth;\n        for (let i = 0; i < 2; i++) {this.gain[i] += (commonGain - this.gain[i]) * coupling; this.memory[i] += (commonMemory - this.memory[i]) * coupling;}\n        gainL = db(this.gain[0]); gainR = db(this.gain[1]);\n        this.reduction = Math.min(this.gain[0], this.gain[1]) * this.wet;\n      }\n      for (let i = 0; i < outputs.length; i++) {\n        const channel = this.channels[i], raw = i === 0 ? left : right;\n        let wet = i === 0 ? l : r;\n        if (this.type === 'brit') {\n          for (const filter of channel.filters) wet = filter.run(wet);\n          wet = channel.color.run(wet, 0.22 * db(this.drive), 0.12);\n        } else if (this.type === 'talon') {\n          wet = channel.audioHp.run(channel.audioPole.run(wet * (i === 0 ? gainL : gainR)));\n          const amount = [0.15, 0.8, 1.5][p.color] * (1 + Math.min(2, -this.gain[i] / 20));\n          channel.amount += (amount - channel.amount) * this.smooth; channel.bias += ((p.color === 1 ? 0.3 : 0) - channel.bias) * this.smooth;\n          wet = channel.color.run(wet, channel.amount, channel.bias);\n        } else wet = channel.clean.run(wet * (i === 0 ? gainL : gainR));\n        const dry = channel.dry.run(raw);\n        outputs[i][n] = dry + this.wet * (wet * this.output - dry);\n      }\n    }\n  }\n}\n\nif (typeof registerProcessor !== 'undefined') {\n  class StudioProcessor extends AudioWorkletProcessor {\n    constructor(options) {\n      super(); this.dsp = new StudioDSP(options.processorOptions.type, sampleRate); this.meterFrames = 0;\n      this.port.onmessage = ({data}) => {\n        if (data.type === 'flush') this.port.postMessage({id: data.id});\n        else if (data.type === 'dispose') {this.dsp.disposed = true; this.dsp.events = [];}\n        else this.dsp.enqueue(data);\n      };\n    }\n    process(inputs, outputs) {\n      this.dsp.render(inputs[0] ?? [], outputs[0], currentFrame);\n      this.meterFrames += outputs[0][0].length;\n      if (this.meterFrames >= sampleRate / 25) {this.meterFrames = 0; this.port.postMessage({reduction: this.dsp.reduction});}\n      return !this.dsp.disposed;\n    }\n  }\n  registerProcessor('rackloose-studio-v1', StudioProcessor);\n}\n"].map((e) => ({
	source: e,
	contexts: /* @__PURE__ */ new WeakMap()
}));
async function Jt(e) {
	await Promise.all(qt.map(({ source: t, contexts: n }) => {
		let r = n.get(e);
		if (!r) {
			let i = URL.createObjectURL(new Blob([t], { type: "text/javascript" }));
			r = e.audioWorklet.addModule(i).finally(() => URL.revokeObjectURL(i)), n.set(e, r), r.catch(() => n.delete(e));
		}
		return r;
	}));
}
function Yt(e, t, n, r) {
	let i = 0, a = !1, o, s = /* @__PURE__ */ new Map(), c = (e) => {
		for (let t of s.values()) clearTimeout(t.timer), e ? t.reject(e) : t.resolve();
		s.clear();
	};
	return e.port.onmessage = ({ data: e }) => {
		if (a) return;
		typeof e.reduction == "number" && Number.isFinite(e.reduction) && n?.(e.reduction);
		let t = e.id === void 0 ? void 0 : s.get(e.id);
		t && (clearTimeout(t.timer), t.resolve(), s.delete(e.id));
	}, e.onprocessorerror = () => {
		a || (o = /* @__PURE__ */ Error(`${t} audio processor failed. Reload the patch to retry.`), c(o), r?.(o));
	}, {
		flush() {
			return o ? Promise.reject(o) : a ? Promise.resolve() : new Promise((n, r) => {
				let a = ++i, o = setTimeout(() => {
					s.delete(a), r(/* @__PURE__ */ Error(`${t} did not finish preparing audio. Try again.`));
				}, 5e3);
				s.set(a, {
					resolve: n,
					reject: r,
					timer: o
				}), e.port.postMessage({
					type: "flush",
					id: a
				});
			});
		},
		dispose() {
			a || (a = !0, e.port.postMessage({ type: "dispose" }), c(), e.port.onmessage = null, e.onprocessorerror = null, e.port.close());
		}
	};
}
//#endregion
//#region src/audio/prism.ts
function Xt(e, { keep: t, onError: n }) {
	let r = t(new AudioWorkletNode(e, "rackloose-prism-v1", {
		numberOfInputs: 2,
		numberOfOutputs: 1,
		outputChannelCount: [1]
	})), i = t(e.createGain()), a = t(e.createGain());
	i.connect(r, 0, 0), a.connect(r, 0, 1);
	let o = {};
	return {
		pitch: i,
		cv: a,
		output: r,
		...Yt(r, "PRISM", void 0, n),
		apply(t) {
			o = t, r.port.postMessage({
				type: "params",
				time: e.currentTime,
				params: t
			});
		},
		noteOn(e, t, n, i) {
			r.port.postMessage({
				type: "on",
				time: n,
				key: i,
				velocity: t,
				notes: (le[o.chord]?.[1] ?? [0]).map((t) => e + t)
			});
		},
		noteOff(e, t) {
			r.port.postMessage({
				type: "off",
				time: e,
				key: t
			});
		}
	};
}
//#endregion
//#region src/audio/studio.ts
function Zt(e, t, n, r) {
	let i = n(new AudioWorkletNode(e, "rackloose-studio-v1", {
		numberOfInputs: 1,
		numberOfOutputs: 1,
		outputChannelCount: [2],
		channelCount: 2,
		channelCountMode: "explicit",
		processorOptions: { type: t }
	})), a = 0;
	return {
		input: i,
		output: i,
		...Yt(i, I[t].name, (e) => {
			a = e;
		}, r),
		get reduction() {
			return a;
		},
		apply(t) {
			i.port.postMessage({
				type: "params",
				time: e.currentTime,
				params: t
			});
		}
	};
}
//#endregion
//#region src/audio/strike.ts
var K = 28e3, Qt = /* @__PURE__ */ new Map();
function $t(e) {
	let t = Qt.get(e);
	if (t) return t;
	let n = ue.findIndex((t) => t.id === e);
	if (n < 0) throw Error(`Unknown STRIKE voice: ${e}`);
	let r = [
		"crash",
		"ride",
		"open"
	].includes(e), i = Math.ceil(K * (r ? 3 : 1.5)), a = new Float32Array(i), o = 7103 + n * 197, s = 0, c = 0, l = 0, u = (e, t) => Math.sin(2 * Math.PI * e * t), d = {
		lowTom: 100,
		midTom: 142,
		highTom: 195,
		lowConga: 210,
		highConga: 310
	};
	for (let t = 0; t < i; t++) {
		o ^= o << 13, o ^= o >>> 17, o ^= o << 5;
		let n = (o >>> 0) / 2 ** 31 - 1, r = t / K;
		s = .65 * s + .35 * n;
		let f = n - c;
		c = n;
		let p = 0;
		if (e === "kick") l += 2 * Math.PI * (54 + 120 * Math.exp(-r * 80)) / K, p = Math.sin(l) * Math.exp(-r * 9) + .28 * s * Math.exp(-r * 170) + .1 * u(105, r) * Math.exp(-r * 25);
		else if (e === "snare") p = (.55 * u(185, r) + .28 * u(331, r)) * Math.exp(-r * 25) + .75 * (n - s) * Math.exp(-r * 15);
		else if (e === "rim") p = (u(420, r) + .65 * u(1750, r) + .35 * u(3100, r)) * Math.exp(-r * 85) + n * .25 * Math.exp(-r * 300);
		else if (e === "clap") {
			let e = [
				0,
				.011,
				.024
			].reduce((e, t) => e + (r >= t ? Math.exp(-(r - t) * 230) : 0), 0);
			p = (n - s) * (e + (r > .035 ? .65 * Math.exp(-(r - .035) * 16) : 0));
		} else if (e in d) {
			let t = d[e], n = e.includes("Conga");
			l += 2 * Math.PI * t * (1 + .55 * Math.exp(-r * 55)) / K, p = (Math.sin(l) + .3 * u(t * (n ? 2.14 : 1.59), r)) * Math.exp(-r * (n ? 14 : 8)) + .22 * s * Math.exp(-r * 95);
		} else if (e === "bell") p = (u(540, r) + .65 * u(800, r) + .22 * u(1620, r)) * Math.exp(-r * 11);
		else {
			let t = [
				3421,
				4517,
				5683,
				7129,
				9181
			].reduce((t, n, i) => t + u(n * (e === "ride" ? .68 : 1), r) / (i + 2), 0), n = e === "hat" ? 34 : e === "open" ? 5 : e === "crash" ? 1.8 : e === "ride" ? 2.3 : e === "cabasa" ? 32 : 16;
			p = ((e === "cabasa" ? 0 : .4) * t + (e === "ride" ? .2 : .65) * f) * Math.exp(-r * n), e === "tambourine" && (p *= .65 + .35 * u(85, r)), e === "crash" && (p *= Math.min(1, r * 180));
		}
		let m = Math.tanh(p), h = Math.sign(m) * Math.log1p(255 * Math.abs(m)) / Math.log(256), g = Math.round(h * 127) / 127;
		a[t] = Math.sign(g) * Math.expm1(Math.abs(g) * Math.log(256)) / 255 * Math.min(1, t / 12) * Math.min(1, (i - 1 - t) / 128);
	}
	return Qt.set(e, a), a;
}
function en(e, t) {
	let n = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Set(), i = (e) => {
		if (r.delete(e)) for (let t of [
			e.source,
			e.gain,
			e.filter,
			e.pan
		]) t.disconnect();
	};
	function a(t) {
		let n = e.currentTime, i = /* @__PURE__ */ new Map();
		for (let e of r) {
			let t = i.get(e.voice) ?? [];
			t.push(e), i.set(e.voice, t);
		}
		for (let e of i.values()) e.sort((e, t) => e.start - t.start);
		for (let [e, r] of i) if (!t || e === t || e === "open" && t === "hat") for (let [t, a] of r.entries()) {
			let o = r[t + 1], s = e === "open" ? i.get("hat")?.find((e) => e.start >= a.start) : void 0, c = (s && (!o || s.start < o.start) ? s : o)?.start ?? Infinity, l = a.gain.gain, u = (e) => a.peak * Math.min(1, Math.max(0, e - a.start) / .001) * Math.exp(-Math.max(0, e - a.start - .001) * 4.6 / a.decay);
			l.cancelScheduledValues(n), n < a.start + .001 ? (l.setValueAtTime(u(n), n), l.setValueAtTime(0, Math.max(n, a.start)), l.linearRampToValueAtTime(a.peak, a.start + .001)) : l.setValueAtTime(c < n ? u(c) * Math.max(0, 1 - (n - c) / .004) : u(n), n), l.setTargetAtTime(0, Math.max(n, a.start + .001), a.decay / 4.6), c >= n && c < a.end && (l.cancelScheduledValues(c), l.setValueAtTime(u(c), c), l.linearRampToValueAtTime(0, c + .004)), a.source.stop(Math.max(n, Math.min(a.end, c + .005)));
		}
	}
	return {
		trigger(o, s, c) {
			let l = n.get(o);
			if (!l) {
				let t = $t(o);
				l = e.createBuffer(1, t.length, K), l.copyToChannel(new Float32Array(t), 0), n.set(o, l);
			}
			let u = e.createBufferSource(), d = e.createGain(), f = e.createBiquadFilter(), p = e.createStereoPanner();
			u.buffer = l, u.playbackRate.value = 2 ** (c[`${o}Tune`] / 12), f.type = "lowpass", f.frequency.value = 700 * 20 ** c[`${o}Tone`], f.Q.value = -3.01, p.pan.value = c[`${o}Pan`], d.gain.value = 0, u.connect(f).connect(d).connect(p).connect(t);
			let m = {
				voice: o,
				start: s,
				end: s + Math.min(l.duration / u.playbackRate.value, c[`${o}Decay`] * 2) + .01,
				peak: c[`${o}Level`] * 1.6,
				decay: c[`${o}Decay`],
				source: u,
				gain: d,
				filter: f,
				pan: p
			};
			u.onended = () => i(m), r.add(m), u.start(s), a(o);
		},
		cancelScheduled(e) {
			for (let t of [...r]) t.start >= e && (t.source.stop(e), i(t));
			a();
		},
		dispose() {
			for (let e of [...r]) e.source.stop(), i(e);
			n.clear();
		}
	};
}
//#endregion
//#region src/audio/processors.ts
var tn = (e) => 10 ** (e / 20), nn = (e, t, n, r) => {
	r ? e.value = t : e.setTargetAtTime(t, n, .008);
}, rn = [
	[2e-4, .3],
	[2e-4, .45],
	[4e-4, .6],
	[4e-4, .75],
	[4e-4, .9],
	[2e-4, 1]
], an = 24, on = 6;
function sn(e, t, n) {
	let r = tn(e), i = e + t, a = tn(i), o = (e) => 20 * Math.log10(e), s = (e, t) => e < r ? e : r + (1 - Math.exp(-t * (e - r))) / t, c = (e, t) => e < r ? 1 : (o(s(e * 1.001, t)) - o(s(e, t))) / (o(e * 1.001) - o(e)), l = .1, u = 1e4, d = 5;
	for (let e = 0; e < 15; e++) c(a, d) < 1 / n ? u = d : l = d, d = Math.sqrt(l * u);
	return (1 / (1 < a ? s(1, d) : tn(o(s(a, d)) + (0 - i) / n))) ** .6;
}
function cn(e, { keep: t }) {
	let n = (n = 1) => {
		let r = t(e.createGain());
		return r.gain.value = n, r;
	}, r = (n, r, i = 0) => {
		let a = t(e.createBiquadFilter());
		return a.type = n, a.frequency.value = r, a.gain.value = i, a.Q.value = -3.01, a;
	}, i = n(), a = n(), o = t(e.createWaveShaper()), s = n(), c = .2, l = .5 * (1 - Math.tanh(c) ** 2);
	o.curve = Float32Array.from({ length: 2049 }, (e, t) => (Math.tanh(2 * (t / 1024 - 1) + c) - Math.tanh(c)) / l), o.oversample = "2x";
	let u = t(e.createDynamicsCompressor());
	u.knee.value = an, u.ratio.value = on, i.connect(a).connect(o).connect(r("highpass", 12)).connect(r("lowshelf", 90, 1)).connect(r("highshelf", 9e3, -1)).connect(u).connect(s);
	let d = !0, f = NaN, p = 1;
	return {
		input: i,
		output: s,
		compressor: u,
		apply(t) {
			let n = e.currentTime, [r, i] = rn[t.time] ?? rn[1];
			f !== t.threshold && (f = t.threshold, p = sn(t.threshold, an, on)), nn(a.gain, tn(t.input) / 4, n, d), nn(u.threshold, t.threshold, n, d), u.attack.value = r, u.release.value = i, nn(s.gain, tn(t.output) / p, n, d), d = !1;
		}
	};
}
function ln(e, t) {
	return [
		{
			type: "highpass",
			frequency: e.hpf <= 16 ? 0 : e.hpf,
			Q: -3.01,
			gain: 0
		},
		{
			type: e.lfBell ? "peaking" : "lowshelf",
			frequency: e.lfFreq,
			Q: .7,
			gain: e.lfGain
		},
		{
			type: "peaking",
			frequency: e.lmfFreq,
			Q: e.lmfQ,
			gain: e.lmfGain
		},
		{
			type: "peaking",
			frequency: e.hmfFreq,
			Q: e.hmfQ,
			gain: e.hmfGain
		},
		{
			type: e.hfBell ? "peaking" : "highshelf",
			frequency: e.hfFreq,
			Q: .7,
			gain: e.hfGain
		},
		{
			type: "lowpass",
			frequency: e.lpf >= 22e3 ? t : Math.min(e.lpf, t),
			Q: -3.01,
			gain: 0
		}
	];
}
function un({ type: e, frequency: t, Q: n, gain: r }, i, a) {
	let o = a / 2;
	if (e === "highpass" && t <= 0 || e === "lowpass" && t >= o) return 0;
	let s = 10 ** (r / 40), c = 2 * Math.PI * t / a, l = Math.cos(c), u = Math.sin(c), d = u / (2 * 10 ** (n / 20)), f = u / (2 * n), p = u / 2 * Math.SQRT2 * 2 * Math.sqrt(s), [m, h, g, _, v, y] = {
		lowpass: [
			(1 - l) / 2,
			1 - l,
			(1 - l) / 2,
			1 + d,
			-2 * l,
			1 - d
		],
		highpass: [
			(1 + l) / 2,
			-(1 + l),
			(1 + l) / 2,
			1 + d,
			-2 * l,
			1 - d
		],
		peaking: [
			1 + f * s,
			-2 * l,
			1 - f * s,
			1 + f / s,
			-2 * l,
			1 - f / s
		],
		lowshelf: [
			s * (s + 1 - (s - 1) * l + p),
			2 * s * (s - 1 - (s + 1) * l),
			s * (s + 1 - (s - 1) * l - p),
			s + 1 + (s - 1) * l + p,
			-2 * (s - 1 + (s + 1) * l),
			s + 1 + (s - 1) * l - p
		],
		highshelf: [
			s * (s + 1 + (s - 1) * l + p),
			-2 * s * (s - 1 + (s + 1) * l),
			s * (s + 1 + (s - 1) * l - p),
			s + 1 - (s - 1) * l + p,
			2 * (s - 1 - (s + 1) * l),
			s + 1 - (s - 1) * l - p
		]
	}[e] ?? [
		1,
		0,
		0,
		1,
		0,
		0
	], b = 2 * Math.PI * i / a, x = Math.cos(b), S = Math.sin(b), C = Math.cos(2 * b), w = Math.sin(2 * b), T = (e, t, n) => Math.hypot(e + t * x + n * C, t * S + n * w);
	return 20 * Math.log10(T(m, h, g) / T(_, v, y));
}
function dn(e, { keep: t }) {
	let n = (n = 1) => {
		let r = t(e.createGain());
		return r.gain.value = n, r;
	}, r = n(), i = n(), a = n(0), o = n(), s = e.sampleRate / 2, c = Array.from({ length: 6 }, () => t(e.createBiquadFilter()));
	c.reduce((e, t) => e.connect(t), r).connect(i).connect(o), r.connect(a).connect(o);
	let l = !0;
	return {
		input: r,
		output: o,
		apply(t) {
			let n = e.currentTime;
			ln(t, s).forEach((e, t) => {
				let r = c[t];
				r.type !== e.type && (r.type = e.type), e.frequency <= 0 || e.frequency >= s ? (r.frequency.cancelScheduledValues(n), r.frequency.setValueAtTime(e.frequency, n)) : nn(r.frequency, e.frequency, n, l), nn(r.Q, e.Q, n, l), nn(r.gain, e.gain, n, l);
			}), nn(i.gain, +!t.active, n, l), nn(a.gain, +!!t.active, n, l), nn(o.gain, tn(t.output), n, l), l = !1;
		}
	};
}
//#endregion
//#region src/audio/session.ts
function fn() {
	let e = typeof navigator > "u" ? void 0 : navigator.audioSession;
	if (!e || e.type === "playback") return () => {};
	let t = e.type;
	return e.type = "playback", () => {
		e.type === "playback" && (e.type = t);
	};
}
//#endregion
//#region src/audio/engine.ts
var pn = [
	"sine",
	"triangle",
	"sawtooth",
	"square"
], mn = [
	"lowpass",
	"highpass",
	"bandpass"
], q = (e, t) => `${e}:${t}`, J = (e, t, n) => {
	e.setTargetAtTime(t, n, .008);
}, hn = .5, gn = .09;
function Y({ analyser: e, data: t }) {
	e.getFloatTimeDomainData(t);
	let n = 0;
	for (let e of t) n = Math.max(n, Math.abs(e));
	return n > 0 ? Math.max(-60, 20 * Math.log10(n)) : -60;
}
function X(e, t = 0, n = 2, r = !1, i = 0) {
	let a = e.createBuffer(r ? 2 : 1, Math.ceil(e.sampleRate * n), e.sampleRate), o = 90210;
	for (let n = 0; n < a.numberOfChannels; n++) {
		let r = a.getChannelData(n), s = 0;
		for (let n = 0; n < r.length; n++) {
			o ^= o << 13, o ^= o >>> 17, o ^= o << 5;
			let a = (o >>> 0) / 2 ** 31 - 1;
			s = t === 1 ? .93 * s + .2 * a : t === 2 ? (s + .035 * a) / 1.035 : a, r[n] = s * (i ? Math.exp(-n / e.sampleRate / i * 5) : 1);
		}
	}
	return a;
}
var Z = "seq", _n = "manual", vn = class {
	context;
	onError;
	master;
	nodes = [];
	sources = [];
	runtime = /* @__PURE__ */ new Map();
	outputs = /* @__PURE__ */ new Map();
	inputs = /* @__PURE__ */ new Map();
	cvAmounts = /* @__PURE__ */ new Map();
	notes = /* @__PURE__ */ new Map();
	white = null;
	mix = Ve;
	open = {};
	muted = !1;
	manualTarget = null;
	manualOwned = /* @__PURE__ */ new Set();
	targets = /* @__PURE__ */ new Map();
	pulses = /* @__PURE__ */ new Map();
	patch;
	constructor(e, t, n = e.destination, r = Ve, i) {
		this.context = e, this.onError = i, this.patch = t, this.master = this.keep(e.createGain());
		let a = this.keep(e.createDynamicsCompressor());
		a.threshold.value = -12, a.knee.value = 12, a.ratio.value = 8, a.attack.value = .003, a.release.value = .15, this.master.connect(a).connect(n);
		for (let e of t.modules) this.buildModule(e);
		for (let e of t.modules) e.type === "performance" && this.targets.set(e.id, Ke(t, e.id));
		for (let n of t.cables) {
			let r = this.outputs.get(q(n.from.moduleId, n.from.portId)), i = this.inputs.get(q(n.to.moduleId, n.to.portId));
			if (!r || !i || this.isNoteCable(n)) continue;
			let a = I[t.modules.find((e) => e.id === n.to.moduleId).type].ports.find((e) => e.id === n.to.portId);
			if (a.kind === "cv") {
				let t = this.keep(e.createGain());
				t.gain.value = n.amount * (a.scale ?? 1), r.connect(t), "setValueAtTime" in i, t.connect(i), this.cvAmounts.set(n.id, t);
			} else "setValueAtTime" in i, r.connect(i);
		}
		this.applyPatch(t, !0), this.setMix(r, !0);
		for (let e of this.sources) e.start(0);
	}
	keep(e) {
		return this.nodes.push(e), e;
	}
	isNoteCable(e) {
		return e.to.portId === "pitch" && B(this.patch.modules.find((t) => t.id === e.to.moduleId).type) && this.patch.modules.find((t) => t.id === e.from.moduleId)?.type === "performance";
	}
	polyNote(e, t, n, r) {
		let i = this.patch.cables.find((t) => t.to.moduleId === e && this.isNoteCable(t));
		return i ? 60 + ((i.from.moduleId === t ? n : this.noteAt(i.from.moduleId, r)) - 60) * i.amount : 60;
	}
	noteAt(e, t) {
		let n = this.notes.get(e) ?? [];
		for (let e = n.length - 1; e >= 0; e--) if (n[e].time <= t) return n[e].note;
		return 48;
	}
	get main() {
		return this.patch.modules[0].id;
	}
	gain(e = 1) {
		let t = this.keep(this.context.createGain());
		return t.gain.value = e, t;
	}
	source(e) {
		return "offset" in e && Pt(e.offset, this.context), this.keep(e), this.sources.push(e), e;
	}
	buildModule(e) {
		let { context: t } = this, n = (t) => q(e.id, t), r = (e, t) => this.inputs.set(n(e), t), i = this.gain(), a = (e, t, r = !0) => this.outputs.set(n(e), r ? t.connect(i) : t), o = !1, s = (e, n) => {
			o ? J(e, n, t.currentTime) : e.value = n;
		}, c = () => {}, l, u, d, f, p, m, h, g, _, v, y = (e) => {
			p = this.source(t.createConstantSource()), p.offset.value = 0;
			let n = this.gain(1200);
			p.connect(n), "setValueAtTime" in e, n.connect(e);
		};
		switch (e.type) {
			case "performance":
				l = this.source(t.createConstantSource()), l.offset.value = -1, a("pitch", l, !1);
				break;
			case "oscillator": {
				let e = this.source(t.createOscillator()), n = this.gain();
				e.frequency.value = 261.625565, e.connect(n), r("pitch", e.detune), y(e.detune), r("fm", e.detune), a("out", n), c = (t) => {
					e.type = pn[t.wave], s(e.detune, t.octave * 1200 + t.tune * 100 + t.fine), s(n.gain, t.level * .35);
				};
				break;
			}
			case "monarch":
				this.white ??= X(t, 0, 1), f = Bt(t, this.white, {
					keep: (e) => this.keep(e),
					source: (e) => this.source(e)
				}), r("pitch", f.pitch), y(f.pitch), r("cv", f.cv), a("out", f.output), c = f.apply;
				break;
			case "oracle":
			case "aurora":
			case "prism": {
				this.white ??= X(t, 0, 1);
				let n = {
					onError: this.onError,
					keep: (e) => this.keep(e),
					source: (e) => this.source(e)
				};
				h = e.type === "oracle" ? Gt(t, this.white, n) : e.type === "aurora" ? Kt(t, n) : Xt(t, n), r("pitch", h.pitch), r("cv", h.cv), a("out", h.output), c = h.apply;
				break;
			}
			case "compressor":
				g = cn(t, { keep: (e) => this.keep(e) }), r("in", g.input), a("out", g.output), c = g.apply;
				break;
			case "cohere":
			case "talon":
			case "brit":
				m = Zt(t, e.type, (e) => this.keep(e), this.onError), r("in", m.input), a("out", m.output), c = m.apply;
				break;
			case "equalizer": {
				let e = dn(t, { keep: (e) => this.keep(e) });
				r("in", e.input), a("out", e.output), c = e.apply;
				break;
			}
			case "noise": {
				let n = this.source(t.createBufferSource()), r = this.gain();
				n.buffer = X(t, e.params.color), n.loop = !0, n.connect(r), a("out", r), c = (e) => s(r.gain, e.level * .3);
				break;
			}
			case "mixer": {
				let e = () => {
					let e = this.keep(t.createAnalyser());
					return e.fftSize = 512, {
						analyser: e,
						data: new Float32Array(e.fftSize)
					};
				}, n = this.gain(), i = this.gain(), o = this.keep(t.createChannelSplitter(2));
				v = {
					channels: [],
					bus: [e(), e()]
				}, n.connect(i).connect(o), v.bus.forEach(({ analyser: e }, t) => o.connect(e, t));
				let l = fe.map((i, a) => {
					let o = this.gain(), s = this.gain(), c = e(), l = [this.gain(), this.gain()], u = this.gain(), d = this.keep(t.createChannelSplitter(2)), f = this.keep(t.createChannelMerger(2));
					return u.channelCount = 2, u.channelCountMode = "explicit", u.channelInterpretation = "speakers", o.connect(s).connect(u).connect(d), s.connect(c.analyser), l.forEach((e, t) => d.connect(e, t).connect(f, 0, t)), f.connect(n), r(i, o), v.channels.push(c), {
						id: fe[a],
						level: o,
						gate: s,
						sides: l
					};
				});
				_ = Object.fromEntries(l.map(({ id: e, gate: t }) => [e, t])), a("out", i), c = (e) => {
					for (let { id: t, level: n, sides: [r, i] } of l) {
						let a = e[pe(t)];
						s(n.gain, e[t]), s(r.gain, a > 0 ? Math.cos(a * Math.PI / 2) : 1), s(i.gain, a < 0 ? Math.cos(-a * Math.PI / 2) : 1);
					}
					s(i.gain, e.master);
				};
				break;
			}
			case "filter": {
				let e = this.keep(t.createBiquadFilter());
				r("in", e), r("cv", e.detune), a("out", e), c = (t) => {
					e.type = mn[t.mode], s(e.frequency, t.cutoff), s(e.Q, t.resonance);
				};
				break;
			}
			case "amplifier": {
				let t = this.gain(), n = this.gain();
				t.connect(n), t.gain.value = +!this.patch.cables.some((t) => t.to.moduleId === e.id && t.to.portId === "cv"), r("in", t), r("cv", t.gain), a("out", n), c = (e) => s(n.gain, e.level);
				break;
			}
			case "envelope": {
				let e = this.source(t.createConstantSource());
				e.offset.value = 0, a("out", e), u = Rt(e.offset);
				break;
			}
			case "lfo": {
				let e = this.source(t.createOscillator());
				r("cv", e.frequency), a("out", e), c = (t) => {
					e.type = pn[t.wave], s(e.frequency, t.rate);
				};
				break;
			}
			case "delay": {
				let e = this.gain(), n = this.gain(), i = this.gain(), o = this.gain(), l = this.keep(t.createDelay(1)), u = this.gain();
				e.connect(i).connect(n), e.connect(l).connect(o).connect(n), l.connect(u).connect(l), r("in", e), a("out", n), c = (e) => {
					s(l.delayTime, e.time), s(u.gain, e.feedback), s(i.gain, 1 - e.mix), s(o.gain, e.mix);
				};
				break;
			}
			case "reverb": {
				let e = this.gain(), n = this.gain(), i = this.gain(), o = this.gain(), l = this.keep(t.createConvolver());
				e.connect(i).connect(n), e.connect(l).connect(o).connect(n), r("in", e), a("out", n);
				let u = -1;
				c = (e) => {
					u !== e.decay && (l.buffer = X(t, 0, e.decay, !0, e.decay), u = e.decay), s(i.gain, 1 - e.mix), s(o.gain, e.mix);
				};
				break;
			}
			case "boom":
			case "punch":
			case "orbit":
			case "strike": {
				let n = this.gain(), o = this.gain(), l = this.gain(), u = this.gain();
				n.connect(o).connect(i).connect(u), l.connect(u), r("chain", l), a("out", u, !1), this.white ??= X(t, 0, 1), d = e.type === "strike" ? en(t, n) : Lt(t, e.type, n, {
					keep: (e) => this.keep(e),
					start: (e) => this.source(e),
					noise: this.white
				}), c = (e) => s(o.gain, e.level * hn);
				break;
			}
			case "output": r("in", this.master), c = (e) => s(this.master.gain, this.muted ? 0 : e.volume * .8);
		}
		for (let t of I[e.type].ports) {
			let e = t.copyOf && this.outputs.get(n(t.copyOf));
			e && this.outputs.set(n(t.id), e);
		}
		this.runtime.set(e.id, {
			module: e,
			apply: (e) => {
				c(e), o = !0;
			},
			gate: i,
			channels: _,
			meters: v,
			pitch: l,
			envelope: u,
			drums: d,
			monarch: f,
			poly: h,
			valve: g,
			studio: m,
			manualPitch: p
		});
	}
	applyPatch(e, t = !1) {
		for (let n of e.modules) {
			let e = this.runtime.get(n.id);
			e && (t || JSON.stringify(e.module.params) !== JSON.stringify(n.params)) && (e.apply(n.params), e.module = n);
		}
		for (let n of e.cables) {
			let r = this.cvAmounts.get(n.id);
			if (r && (t || this.patch.cables.find((e) => e.id === n.id)?.amount !== n.amount)) {
				let t = e.modules.find((e) => e.id === n.to.moduleId), i = I[t.type].ports.find((e) => e.id === n.to.portId)?.scale ?? 1;
				J(r.gain, this.manualTarget === n.to.moduleId && n.to.portId === "pitch" && !B(t.type) ? 0 : n.amount * i, this.context.currentTime);
			}
		}
		this.patch = e;
	}
	gatedBy(e) {
		let t = new Set(this.patch.cables.filter((t) => t.from.moduleId === e && L(this.patch, t.from)?.kind === "gate").map((e) => e.to.moduleId));
		return [...this.runtime.values()].filter((e) => (e.envelope || e.monarch || e.poly) && t.has(e.module.id));
	}
	setMix(e, t = !1) {
		this.mix = e, this.open = qe(this.patch, e);
		let n = (e, n) => {
			t ? e.gain.value = +!!n : J(e.gain, +!!n, this.context.currentTime);
		};
		for (let { module: t, gate: r, channels: i } of this.runtime.values()) {
			n(r, this.open[t.id] !== !1);
			for (let [r, a] of Object.entries(i ?? {})) n(a, Ye(t, r, e));
		}
	}
	openEnvelope(e, t, n, r, i, a) {
		if (e.monarch) {
			e.monarch.noteOn(t, n);
			return;
		}
		if (e.poly) {
			e.poly.noteOn(this.polyNote(e.module.id, a, r, n), t, n, i);
			return;
		}
		let o = e.module.params;
		e.envelope?.on(n, t, o.attack, o.decay, o.sustain);
	}
	closeEnvelope(e, t, n) {
		e.monarch && e.monarch.noteOff(t), e.poly?.noteOff(t, n), e.envelope?.off(t, e.module.params.release);
	}
	setNote(e, t, n) {
		let r = this.runtime.get(e)?.pitch;
		r && (r.offset.cancelScheduledValues(n), r.offset.setValueAtTime((t - 60) / 12, n), this.notes.set(e, [...(this.notes.get(e) ?? []).filter((e) => e.time < n).slice(-63), {
			time: n,
			note: t
		}]));
	}
	gateOn(e, t, n, r) {
		if (this.open[e] !== !1) for (let i of this.gatedBy(e)) this.manualOwned.has(i.module.id) || this.openEnvelope(i, n, r, t, Z, e);
	}
	noteOn(e, t = 1, n = this.context.currentTime, r = this.main) {
		this.manualTarget !== r && (this.setNote(r, e, n), this.gateOn(r, e, t, n));
	}
	noteOff(e = this.context.currentTime, t = this.main) {
		for (let n of this.gatedBy(t)) this.manualOwned.has(n.module.id) || this.closeEnvelope(n, e, Z);
	}
	sequence(e, t, n, r) {
		let i = t % 16, a = e.filter((e) => e !== this.manualTarget).flatMap((e) => {
			let t = xe(this.patch, e)[i];
			return t?.enabled && Xe(e, i, this.mix) ? [{
				id: e,
				step: t
			}] : [];
		});
		for (let { id: e, step: t } of a) this.setNote(e, t.note, n);
		for (let { id: e, step: t } of a) if (this.gateOn(e, t.note, t.velocity, n), this.noteOff(n + r * t.gate, e), this.open[e] !== !1) for (let t of this.targets.get(e) ?? []) this.pulse(t, n, e);
	}
	pulse(e, t, n) {
		this.pulses.set(e, [...(this.pulses.get(e) ?? []).slice(-63), {
			time: t,
			sequencer: n
		}]);
	}
	lastPulse(e, t) {
		let n = this.pulses.get(e);
		if (!n) return -1;
		let r = n.length - 1;
		for (; r >= 0 && n[r].time > t;) r--;
		return r > 0 && n.splice(0, r), r < 0 ? -1 : n[0].time;
	}
	mixerLevels(e) {
		let t = this.runtime.get(e)?.meters;
		return t ? {
			channels: t.channels.map(Y),
			bus: t.bus.map(Y)
		} : null;
	}
	manualOn(e, t, n = _n) {
		this.manualTarget !== e && this.manualOff();
		let r = this.runtime.get(e), i = this.context.currentTime;
		if (r) {
			if (this.manualTarget = e, r.poly) {
				this.manualOwned = /* @__PURE__ */ new Set([e]), r.poly.noteOff(i, Z), r.poly.noteOn(t, 1, i, n);
				return;
			}
			if (r.module.type === "performance") {
				if (this.manualOwned = new Set(this.gatedBy(e).map((e) => e.module.id)), this.setNote(e, t, i), this.open[e] === !1) return;
			} else {
				let n = Re(this.patch, e);
				this.manualOwned = new Set(r.monarch ? [e] : this.patch.cables.filter((e) => n.has(e.to.moduleId) && this.runtime.get(e.from.moduleId)?.envelope).map((e) => e.from.moduleId));
				for (let t of this.patch.cables) t.to.moduleId === e && t.to.portId === "pitch" && this.cvAmounts.get(t.id)?.gain.setValueAtTime(0, i);
				r.manualPitch?.offset.setValueAtTime((t - 60) / 12, i);
			}
			for (let n of this.manualOwned) {
				let r = this.runtime.get(n);
				r.poly?.noteOff(i, Z), this.openEnvelope(r, 1, i, t, _n, e);
			}
		}
	}
	manualRelease(e) {
		this.runtime.get(this.manualTarget ?? "")?.poly?.noteOff(this.context.currentTime, e);
	}
	manualOff() {
		let e = this.context.currentTime, t = this.manualTarget;
		for (let t of this.manualOwned) {
			let n = this.runtime.get(t);
			n && this.closeEnvelope(n, e);
		}
		this.runtime.get(t ?? "")?.manualPitch?.offset.setValueAtTime(0, e);
		for (let n of this.patch.cables) n.to.moduleId === t && n.to.portId === "pitch" && this.cvAmounts.get(n.id)?.gain.setValueAtTime(n.amount * 1200, e);
		this.manualOwned.clear(), this.manualTarget = null;
	}
	reduction(e) {
		return this.runtime.get(e)?.studio?.reduction ?? this.runtime.get(e)?.valve?.compressor.reduction ?? 0;
	}
	drumStep(e, t, n) {
		for (let { module: r, drums: i } of this.runtime.values()) {
			if (!i || n && r.id !== n) continue;
			let a = Pe(r, e).filter((e) => Ye(r, e, this.mix));
			for (let e of a) i.trigger(e, t, r.params);
			a.length && this.pulse(r.id, t, r.id);
		}
	}
	hit(e, t, n = this.context.currentTime) {
		let r = this.runtime.get(e);
		r && Ye(r.module, t, this.mix) && r.drums?.trigger(t, n, r.module.params);
	}
	cancelModule(e, t = this.context.currentTime) {
		let n = this.runtime.get(e);
		for (let [n, r] of this.pulses) this.pulses.set(n, r.filter((n) => n.sequencer !== e || n.time <= t));
		n?.drums && n.drums.cancelScheduled(t), n?.pitch && (this.noteOff(t, e), this.manualTarget !== e && (G(n.pitch.offset, t), this.notes.set(e, (this.notes.get(e) ?? []).filter((e) => e.time <= t))));
	}
	cancelScheduled(e = this.context.currentTime) {
		for (let t of this.patch.modules) Le(t.type) && this.cancelModule(t.id, e);
	}
	setMute(e) {
		this.muted = e, J(this.master.gain, e ? 0 : this.patch.modules.find((e) => e.type === "output").params.volume * .8, this.context.currentTime);
	}
	async flush() {
		await Promise.all([...this.runtime.values()].map((e) => Promise.all([e.poly?.flush?.(), e.studio?.flush()])));
	}
	dispose() {
		for (let { poly: e, studio: t } of this.runtime.values()) e?.dispose?.(), t?.dispose();
		this.master.gain.cancelScheduledValues(this.context.currentTime), this.master.gain.value = 0;
		for (let { drums: e } of this.runtime.values()) e?.dispose();
		for (let e of this.sources) e.stop();
		for (let e of this.nodes) e.disconnect();
		this.sources = [], this.nodes = [];
	}
}, yn = (e) => JSON.stringify({
	modules: e.modules.map((e) => [
		e.id,
		e.type,
		e.type === "noise" ? e.params.color : null
	]).sort(),
	cables: e.cables.map((e) => [
		e.id,
		e.from,
		e.to
	]).sort()
}), bn = class {
	patch;
	onError;
	context = null;
	graph = null;
	analyser = null;
	timer = null;
	notes = new gt();
	target = null;
	running = /* @__PURE__ */ new Map();
	nextTime = 0;
	count = 0;
	timeline = [];
	frozen = -1;
	remaining = .04;
	muted = !1;
	mix = Ve;
	suspended = !1;
	disposed = !1;
	revision = 0;
	manualRevision = 0;
	transportRevision = 0;
	moduleRevisions = /* @__PURE__ */ new Map();
	releaseSession = null;
	inputs = /* @__PURE__ */ new Map();
	held = /* @__PURE__ */ new Map();
	playing = !1;
	constructor(e, t) {
		this.patch = e, this.onError = t;
	}
	get activeNote() {
		return this.notes.current;
	}
	get activeNotes() {
		return this.poly ? this.notes.entries.map(([, e]) => e) : this.notes.current === null ? [] : [this.notes.current];
	}
	get poly() {
		let e = this.patch.modules.find((e) => e.id === this.target)?.type;
		return !!e && B(e);
	}
	reduction(e) {
		return this.ready ? this.graph.reduction(e) : 0;
	}
	get sampleRate() {
		return this.context?.sampleRate ?? 48e3;
	}
	get ready() {
		return !!this.graph && this.context?.state === "running";
	}
	get sounding() {
		let e = this.context?.currentTime ?? 0;
		for (; this.timeline.length > 1 && this.timeline[1].time <= e;) this.timeline.shift();
		return this.playing && this.timeline[0]?.time <= e ? this.timeline[0] : null;
	}
	get clock() {
		return this.sounding?.count ?? this.frozen;
	}
	get step() {
		return this.clock < 0 ? -1 : this.clock % 16;
	}
	modulePlaying(e) {
		return this.playing && this.running.has(e);
	}
	moduleClock(e) {
		let t = this.clock;
		return this.running.has(e) && t >= this.running.get(e) ? t : -1;
	}
	pulsing(e) {
		if (!this.graph || !this.context || !this.ready) return !1;
		let t = this.context.currentTime - (this.context.outputLatency || 0), n = this.graph.lastPulse(e, t);
		return n >= 0 && t - n < gn;
	}
	mixerLevels(e) {
		let t = {
			channels: fe.map(() => -60),
			bus: [-60, -60]
		}, n = this.graph && this.ready ? this.graph.mixerLevels(e) : null;
		if (!n || !this.context) return this.held.delete(e), t;
		let r = this.context.currentTime, i = this.held.get(e), a = i ? (r - i.time) * 24 : 0, o = (e, t, n) => Math.max(e, n ? n[t] - a : -60), s = {
			channels: n.channels.map((e, t) => o(e, t, i?.levels.channels)),
			bus: n.bus.map((e, t) => o(e, t, i?.levels.bus))
		};
		return this.held.set(e, {
			time: r,
			levels: s
		}), s;
	}
	get meter() {
		if (!this.analyser || !this.ready) return 0;
		let e = new Float32Array(this.analyser.fftSize);
		return this.analyser.getFloatTimeDomainData(e), Math.min(1, Math.sqrt(e.reduce((e, t) => e + t * t, 0) / e.length) * 6);
	}
	async unlock() {
		if (this.suspended || this.disposed) return !1;
		let e = this.revision;
		if (!this.context) {
			if (typeof AudioContext > "u") throw Error("Web Audio is unavailable in this browser. Try a current Chrome or Safari.");
			this.releaseSession = fn(), this.context = new AudioContext({ latencyHint: "interactive" }), this.analyser = this.context.createAnalyser(), this.analyser.fftSize = 256, this.analyser.connect(this.context.destination);
		}
		let t = this.context;
		if (await t.resume(), this.disposed || this.suspended || e !== this.revision) return !1;
		try {
			await Jt(t);
		} catch (t) {
			if (this.disposed || this.suspended || e !== this.revision) return !1;
			throw t;
		}
		return this.disposed || this.suspended || e !== this.revision ? !1 : (this.graph || (this.graph = new vn(this.context, this.patch, this.analyser, this.mix, (e) => {
			this.panic(), this.onError?.(e);
		}), this.graph.setMute(this.muted)), !0);
	}
	unlockForInput(e, t = !1) {
		return e === void 0 ? this.unlock() : (this.inputs.get(e)?.cancel(), new Promise((n, r) => {
			let i = () => {
				this.inputs.get(e) === a && this.inputs.delete(e);
			}, a = {
				started: !1,
				cancel: () => {
					i(), n(!1);
				},
				start: (e) => {
					a.started = !0, e.then((e) => {
						i(), n(e);
					}, (e) => {
						i(), r(e);
					});
				}
			};
			this.inputs.set(e, a), (!t || this.ready) && a.start(this.unlock());
		}));
	}
	lifted(e) {
		if (e !== void 0 && !this.inputs.has(e)) return;
		let t = [...this.inputs.values()].filter((e) => !e.started);
		if (!t.length) return;
		let n = this.unlock();
		for (let e of t) e.start(n);
	}
	update(e) {
		let t = yn(e) !== yn(this.patch);
		this.patch = e;
		for (let t of this.running.keys()) e.modules.some((e) => e.id === t && Le(e.type)) || this.running.delete(t);
		if (this.target && !e.modules.some((e) => e.id === this.target) && this.releaseManual(), this.playing && !this.running.size && this.pause(), this.graph && this.context) {
			if (t) {
				if (this.graph.dispose(), this.graph = new vn(this.context, e, this.analyser, this.mix, (e) => {
					this.panic(), this.onError?.(e);
				}), this.graph.setMute(this.muted), this.target && this.poly) for (let [e, t] of this.notes.entries) this.graph.manualOn(this.target, t, e);
				else this.notes.current !== null && this.target && this.graph.manualOn(this.target, this.notes.current);
				for (let e of this.timeline) e.time >= this.context.currentTime && this.schedule([...this.running.keys()], e);
			} else this.graph.applyPatch(e);
		}
	}
	async press(e, t, n = this.patch.modules[0].id, r = !1) {
		if (this.suspended || this.disposed) return;
		n !== this.target && this.releaseManual(), this.target = n, this.notes.press(e, t);
		let i = this.manualRevision, a = !this.ready;
		await this.unlockForInput(e, r) && i === this.manualRevision && this.target === n && (this.poly ? this.notes.has(e) ? this.graph.manualOn(n, t, e) : a && this.tap(n, t, e) : this.notes.current === null ? a && this.tap(n, t) : this.graph.manualOn(n, this.notes.current));
	}
	tap(e, t, n) {
		let r = this.manualRevision;
		this.graph.manualOn(e, t, n), setTimeout(() => {
			r === this.manualRevision && this.target === e && this.graph && (n === void 0 ? this.notes.current === null && this.graph.manualOff() : this.notes.has(n) || this.graph.manualRelease(n));
		}, 150);
	}
	release(e) {
		if (this.poly) {
			if (!this.notes.has(e)) return;
			this.notes.release(e) === null ? this.graph?.manualOff() : this.graph?.manualRelease(e);
			return;
		}
		let t = this.notes.current, n = this.notes.release(e);
		t !== n && (n !== null && this.target ? this.graph?.manualOn(this.target, n) : this.graph?.manualOff());
	}
	async hit(e, t, n, r = !1) {
		if (this.suspended || this.disposed) return;
		let i = this.manualRevision;
		await this.unlockForInput(n, r) && i === this.manualRevision && this.graph.hit(e, t);
	}
	cancel(e) {
		this.inputs.get(e)?.cancel(), this.release(e);
	}
	releaseManual() {
		this.manualRevision++, this.notes.clear(), this.graph?.manualOff(), this.target = null;
		for (let e of this.inputs.values()) e.cancel();
	}
	schedule(e, t) {
		if (!this.graph) return;
		let n = e.filter((e) => this.patch.modules.some((t) => t.id === e && t.type === "performance"));
		this.graph.sequence(n, t.count, t.time, t.duration);
		for (let r of e) n.includes(r) || this.graph.drumStep(t.count, t.time, r);
	}
	startClock() {
		this.playing = !0, this.nextTime = this.context.currentTime + Math.max(.01, this.remaining), this.timeline = [], this.tick(), this.timer = setInterval(() => this.tick(), 25);
	}
	async play(e) {
		let t = this.transportRevision, n = this.patch.modules.filter((t) => Le(t.type) && (!e || t.id === e)).map((e) => ({
			id: e.id,
			revision: this.moduleRevisions.get(e.id)
		}));
		if (!await this.unlock() || t !== this.transportRevision) return;
		let r = n.filter((e) => e.revision === this.moduleRevisions.get(e.id) && this.patch.modules.some((t) => t.id === e.id)).map((e) => e.id);
		if (r.length) {
			if (this.playing) {
				let e = this.timeline.filter((e) => e.time > this.context.currentTime);
				for (let t of r) if (!this.running.has(t)) {
					this.running.set(t, e[0]?.count ?? this.count);
					for (let n of e) this.schedule([t], n);
				}
			} else {
				this.running.clear();
				for (let e of r) this.running.set(e, this.count);
				this.startClock();
			}
		}
	}
	stopModule(e) {
		this.moduleRevisions.set(e, (this.moduleRevisions.get(e) ?? 0) + 1), this.running.delete(e), this.graph?.cancelModule(e), this.running.size || this.pause();
	}
	tick() {
		if (this.context && this.graph && this.playing) for (; this.nextTime < this.context.currentTime + .1;) {
			let e = _t(this.patch.sequencer.bpm, this.patch.sequencer.swing, this.count % 16), t = {
				count: this.count,
				time: this.nextTime,
				duration: e
			};
			this.timeline.push(t), this.schedule([...this.running.keys()], t), this.nextTime += e, this.count++;
		}
	}
	pause() {
		if (this.transportRevision++, !this.playing) return;
		let e = this.context.currentTime;
		this.frozen = this.sounding?.count ?? this.frozen;
		let t = this.timeline.find((t) => t.time > e);
		this.count = t?.count ?? this.count, this.remaining = Math.max(0, (t?.time ?? this.nextTime) - e), this.playing = !1, this.timer && clearInterval(this.timer), this.timer = null, this.timeline = [], this.graph?.cancelScheduled();
	}
	reset() {
		this.pause(), this.running.clear(), this.frozen = -1, this.count = 0, this.remaining = .04;
	}
	stop() {
		this.reset();
	}
	setMute(e) {
		this.muted = e, this.graph?.setMute(e);
	}
	setMix(e) {
		this.mix = e, this.graph?.setMix(e);
	}
	panic() {
		this.revision++, this.reset(), this.releaseManual(), this.graph?.dispose(), this.graph = null;
	}
	setSuspended(e) {
		this.suspended = e, e && this.panic();
	}
	dispose() {
		this.disposed = !0, this.panic(), this.analyser?.disconnect(), this.context && this.context.close().catch(() => {}), this.context = null, this.releaseSession?.(), this.releaseSession = null;
	}
};
async function xn(e, t = 4, n = Ve) {
	let r = 44100, i = vt(e, t, .04), a = new OfflineAudioContext(2, Math.ceil((i.duration + 2.04) * r), r);
	e.modules.some((e) => [
		"prism",
		"cohere",
		"talon",
		"brit"
	].includes(e.type)) && await Jt(a);
	let o = new vn(a, e, a.destination, n), s = e.modules.filter((e) => e.type === "performance").map((e) => e.id);
	i.events.forEach(({ time: e, duration: t }, n) => {
		o.sequence(s, n, e, t), o.drumStep(n, e);
	});
	try {
		return await o.flush(), await a.startRendering();
	} finally {
		o.dispose();
	}
}
function Sn(e) {
	let t = e.numberOfChannels, n = e.length * t * 2, r = new ArrayBuffer(44 + n), i = new DataView(r), a = (e, t) => {
		for (let n = 0; n < t.length; n++) i.setUint8(e + n, t.charCodeAt(n));
	};
	a(0, "RIFF"), i.setUint32(4, 36 + n, !0), a(8, "WAVE"), a(12, "fmt "), i.setUint32(16, 16, !0), i.setUint16(20, 1, !0), i.setUint16(22, t, !0), i.setUint32(24, e.sampleRate, !0), i.setUint32(28, e.sampleRate * t * 2, !0), i.setUint16(32, t * 2, !0), i.setUint16(34, 16, !0), a(36, "data"), i.setUint32(40, n, !0);
	let o = Array.from({ length: t }, (t, n) => e.getChannelData(n));
	for (let n = 0; n < e.length; n++) for (let e = 0; e < t; e++) {
		let r = Math.max(-1, Math.min(1, o[e][n]));
		i.setInt16(44 + (n * t + e) * 2, Math.round(r * (r < 0 ? 32768 : 32767)), !0);
	}
	return r;
}
var Q = {
	app: "_app_6yply_1",
	toolbar: "_toolbar_6yply_21",
	brand: "_brand_6yply_22",
	brandMark: "_brandMark_6yply_26",
	toolbarActions: "_toolbarActions_6yply_27",
	audioButton: "_audioButton_6yply_29",
	statusLed: "_statusLed_6yply_30",
	rackLight: "_rackLight_6yply_30",
	deviceLed: "_deviceLed_6yply_30",
	patchBar: "_patchBar_6yply_32",
	patchName: "_patchName_6yply_33",
	nameField: "_nameField_6yply_36",
	dirtyMark: "_dirtyMark_6yply_39",
	saveStatus: "_saveStatus_6yply_40",
	saveText: "_saveText_6yply_41",
	saveLed: "_saveLed_6yply_42",
	exportControls: "_exportControls_6yply_44",
	visuallyHidden: "_visuallyHidden_6yply_45",
	historyActions: "_historyActions_6yply_46",
	icon: "_icon_6yply_48",
	patchFile: "_patchFile_6yply_50",
	rackActions: "_rackActions_6yply_50",
	addButton: "_addButton_6yply_52",
	flipButton: "_flipButton_6yply_53",
	rackHeading: "_rackHeading_6yply_54",
	rack: "_rack_6yply_30",
	module: "_module_6yply_57",
	revealFlash: "_revealFlash_6yply_1",
	moduleHeader: "_moduleHeader_6yply_73",
	moduleIdentity: "_moduleIdentity_6yply_74",
	moduleName: "_moduleName_6yply_75",
	moduleSubtitle: "_moduleSubtitle_6yply_76",
	moduleTools: "_moduleTools_6yply_77",
	moduleNumber: "_moduleNumber_6yply_78",
	screw: "_screw_6yply_80",
	screwTL: "_screwTL_6yply_82",
	screwTR: "_screwTR_6yply_82",
	screwBL: "_screwBL_6yply_82",
	screwBR: "_screwBR_6yply_82",
	moduleBody: "_moduleBody_6yply_83",
	controls: "_controls_6yply_84",
	knobControl: "_knobControl_6yply_85",
	controlLabel: "_controlLabel_6yply_86",
	dial: "_dial_6yply_87",
	dialTicks: "_dialTicks_6yply_88",
	dialCap: "_dialCap_6yply_89",
	knobValue: "_knobValue_6yply_92",
	selectControl: "_selectControl_6yply_93",
	choiceGlyph: "_choiceGlyph_6yply_95",
	moduleDecoration: "_moduleDecoration_6yply_96",
	deviceLabel: "_deviceLabel_6yply_98",
	envelopeGraphic: "_envelopeGraphic_6yply_100",
	drumPads: "_drumPads_6yply_102",
	drumLane: "_drumLane_6yply_103",
	voiceButton: "_voiceButton_6yply_104",
	pads: "_pads_6yply_105",
	padGroup: "_padGroup_6yply_106",
	pad: "_pad_6yply_105",
	euclid: "_euclid_6yply_112",
	euclidHeading: "_euclidHeading_6yply_114",
	euclidCell: "_euclidCell_6yply_115",
	orbitRings: "_orbitRings_6yply_116",
	orbitPath: "_orbitPath_6yply_118",
	mixButtons: "_mixButtons_6yply_120",
	muteToggle: "_muteToggle_6yply_122",
	soloToggle: "_soloToggle_6yply_123",
	clearToggle: "_clearToggle_6yply_124",
	sequenceBody: "_sequenceBody_6yply_126",
	step: "_step_6yply_126",
	stepCell: "_stepCell_6yply_128",
	sequenceTop: "_sequenceTop_6yply_130",
	lcd: "_lcd_6yply_131",
	lcdDots: "_lcdDots_6yply_134",
	numberField: "_numberField_6yply_135",
	tempoSlider: "_tempoSlider_6yply_138",
	swingField: "_swingField_6yply_143",
	transport: "_transport_6yply_145",
	playButton: "_playButton_6yply_146",
	transportCaption: "_transportCaption_6yply_148",
	steps: "_steps_6yply_149",
	stepLed: "_stepLed_6yply_151",
	stepNumber: "_stepNumber_6yply_155",
	sequenceHint: "_sequenceHint_6yply_156",
	stepEditor: "_stepEditor_6yply_157",
	meters: "_meters_6yply_159",
	meterRow: "_meterRow_6yply_160",
	muteButton: "_muteButton_6yply_161",
	rackBottom: "_rackBottom_6yply_162",
	keyboardPanel: "_keyboardPanel_6yply_163",
	keyboardTop: "_keyboardTop_6yply_164",
	keyHint: "_keyHint_6yply_164",
	octaveControls: "_octaveControls_6yply_165",
	keysToggle: "_keysToggle_6yply_165",
	piano: "_piano_6yply_166",
	whiteKey: "_whiteKey_6yply_168",
	blackKey: "_blackKey_6yply_170",
	toastAnchor: "_toastAnchor_6yply_173",
	toast: "_toast_6yply_173",
	library: "_library_6yply_176",
	libraryHeading: "_libraryHeading_6yply_177",
	libraryGrid: "_libraryGrid_6yply_178",
	presetBrowser: "_presetBrowser_6yply_180",
	presetActions: "_presetActions_6yply_181",
	sectionLabel: "_sectionLabel_6yply_182",
	presetList: "_presetList_6yply_183",
	presetRow: "_presetRow_6yply_184",
	presetLoad: "_presetLoad_6yply_186",
	presetConfirm: "_presetConfirm_6yply_189",
	dangerButton: "_dangerButton_6yply_190",
	presetEmpty: "_presetEmpty_6yply_191",
	factoryGrid: "_factoryGrid_6yply_193",
	saveDialog: "_saveDialog_6yply_194",
	saveTitle: "_saveTitle_6yply_195",
	saveWarning: "_saveWarning_6yply_197",
	saveNote: "_saveNote_6yply_198",
	saveButtons: "_saveButtons_6yply_199",
	saveButton: "_saveButton_6yply_199",
	miniDevice: "_miniDevice_6yply_200",
	routingBar: "_routingBar_6yply_201",
	legend: "_legend_6yply_202",
	portGroups: "_portGroups_6yply_204",
	portGroup: "_portGroup_6yply_204",
	portHeading: "_portHeading_6yply_204",
	portRow: "_portRow_6yply_204",
	socketControl: "_socketControl_6yply_204",
	jacks: "_jacks_6yply_206",
	socket: "_socket_6yply_204",
	trim: "_trim_6yply_209",
	cables: "_cables_6yply_212",
	cableHits: "_cableHits_6yply_212",
	cable: "_cable_6yply_212",
	cableLine: "_cableLine_6yply_216",
	cableShadow: "_cableShadow_6yply_216",
	cableHit: "_cableHit_6yply_212",
	loosePlug: "_loosePlug_6yply_218",
	helpBackdrop: "_helpBackdrop_6yply_220",
	help: "_help_6yply_220",
	helpHeading: "_helpHeading_6yply_220",
	hitLed: "_hitLed_6yply_228",
	globalControls: "_globalControls_6yply_243",
	globalTransport: "_globalTransport_6yply_244",
	resetButton: "_resetButton_6yply_248",
	clearAllButton: "_clearAllButton_6yply_249",
	globalPosition: "_globalPosition_6yply_253",
	keyboardTarget: "_keyboardTarget_6yply_254",
	routingHint: "_routingHint_6yply_255",
	moduleNameButton: "_moduleNameButton_6yply_257",
	moduleTransport: "_moduleTransport_6yply_258",
	performancePads: "_performancePads_6yply_261",
	orbitEditor: "_orbitEditor_6yply_267",
	orbitVoiceEditor: "_orbitVoiceEditor_6yply_268",
	orbitEditorHeading: "_orbitEditorHeading_6yply_269",
	orbitSteps: "_orbitSteps_6yply_273",
	groupControls: "_groupControls_6yply_280",
	grMeter: "_grMeter_6yply_297",
	grUnit: "_grUnit_6yply_300",
	grNeedle: "_grNeedle_6yply_301",
	eqGraphic: "_eqGraphic_6yply_316",
	soundEditor: "_soundEditor_6yply_359",
	editorHeading: "_editorHeading_6yply_360",
	fmDisplay: "_fmDisplay_6yply_363",
	operatorTabs: "_operatorTabs_6yply_365",
	console: "_console_6yply_403",
	channelStrip: "_channelStrip_6yply_404",
	mixBus: "_mixBus_6yply_404",
	scribble: "_scribble_6yply_406",
	channelSource: "_channelSource_6yply_408",
	faderValue: "_faderValue_6yply_411",
	faderBay: "_faderBay_6yply_414",
	faderScale: "_faderScale_6yply_415",
	faderSlot: "_faderSlot_6yply_417",
	faderCap: "_faderCap_6yply_419",
	levelMeter: "_levelMeter_6yply_422",
	processorHint: "_processorHint_6yply_440",
	britPanel: "_britPanel_6yply_457",
	britSection: "_britSection_6yply_458",
	britWell: "_britWell_6yply_460",
	panelLegend: "_panelLegend_6yply_461",
	marconi: "_marconi_6yply_465",
	marconiRing: "_marconiRing_6yply_465",
	marconiSkirt: "_marconiSkirt_6yply_470",
	marconiFlutes: "_marconiFlutes_6yply_471",
	marconiDome: "_marconiDome_6yply_473",
	marconiPointer: "_marconiPointer_6yply_475",
	ringPointer: "_ringPointer_6yply_480",
	britCurve: "_britCurve_6yply_483",
	britSwitch: "_britSwitch_6yply_485",
	britLamp: "_britLamp_6yply_487",
	talonPanel: "_talonPanel_6yply_491",
	talonSection: "_talonSection_6yply_492",
	talonWell: "_talonWell_6yply_494",
	talonKnob: "_talonKnob_6yply_495",
	talonGrip: "_talonGrip_6yply_498",
	talonCap: "_talonCap_6yply_499",
	talonIndex: "_talonIndex_6yply_500",
	talonLamps: "_talonLamps_6yply_503",
	talonLed: "_talonLed_6yply_508",
	talonLatches: "_talonLatches_6yply_510",
	talonPush: "_talonPush_6yply_511",
	talonMeter: "_talonMeter_6yply_513",
	talonSwitch: "_talonSwitch_6yply_520",
	talonLamp: "_talonLamp_6yply_503",
	talonOutput: "_talonOutput_6yply_524"
};
//#endregion
//#region src/components/Knob.tsx
function Cn(e, t) {
	return e.choices ? e.choices[t] ?? "" : e.unit === "Hz" && t >= 1e3 ? `${(t / 1e3).toFixed(1)}k` : e.unit === "s" && t < .001 ? `${Math.round(t * 1e6)}μs` : e.unit === "s" && t < 1 ? `${e.step < .001 ? Number((t * 1e3).toFixed(2)) : Math.round(t * 1e3)}ms` : `${Number(t.toFixed(2))}${e.unit ?? ""}`;
}
function $({ param: e, value: t, onChange: n, prefix: r = "", format: i, disabled: a = !1, travel: o = 130 }) {
	let s = l(null), c = H(e, t), u = Math.max(4, Math.ceil(-Math.log10(e.step)));
	function d(t) {
		let r = Math.max(0, Math.min(1, t)), i = e.logarithmic ? e.min * (e.max / e.min) ** r : e.min + r * (e.max - e.min);
		n(Math.max(e.min, Math.min(e.max, Number((Math.round(i / e.step) * e.step).toFixed(u)))));
	}
	function f(e) {
		e.isPrimary && e.button === 0 && (s.current = {
			y: e.clientY,
			fraction: c
		}, e.currentTarget.setPointerCapture(e.pointerId), e.preventDefault());
	}
	let p = i ? i(t) : Cn(e, t);
	return {
		props: {
			role: "slider",
			tabIndex: a ? -1 : 0,
			"aria-disabled": a || void 0,
			"aria-label": `${r} ${e.label}`.trim(),
			"aria-valuemin": e.min,
			"aria-valuemax": e.max,
			"aria-valuenow": t,
			"aria-valuetext": p,
			onPointerDown: a ? void 0 : f,
			onPointerMove: (e) => {
				s.current && d(s.current.fraction + (s.current.y - e.clientY) / o);
			},
			onPointerUp: () => {
				s.current = null;
			},
			onPointerCancel: () => {
				s.current = null;
			},
			onDoubleClick: a ? void 0 : () => n(e.initial),
			onKeyDown: (r) => {
				!a && [
					"ArrowUp",
					"ArrowRight",
					"ArrowDown",
					"ArrowLeft",
					"Home",
					"End"
				].includes(r.key) && (r.preventDefault(), r.key === "Home" ? n(e.min) : r.key === "End" ? n(e.max) : e.logarithmic ? d(c + (["ArrowUp", "ArrowRight"].includes(r.key) ? .025 : -.025)) : n(Math.max(e.min, Math.min(e.max, Number((t + (["ArrowUp", "ArrowRight"].includes(r.key) ? e.step : -e.step)).toFixed(u))))));
			}
		},
		fraction: c,
		display: p
	};
}
function wn({ param: e, value: t, onChange: n, prefix: r = "", format: i, trim: a = !1, disabled: o = !1, caption: s }) {
	let { props: c, fraction: l, display: u } = $({
		param: e,
		value: t,
		onChange: n,
		prefix: r,
		format: i,
		disabled: o
	}), d = /* @__PURE__ */ m("div", {
		className: a ? `${Q.dial} ${Q.trim}` : Q.dial,
		...c,
		title: a ? `${e.label} ${u}` : void 0,
		children: [/* @__PURE__ */ p("span", { className: Q.dialTicks }), /* @__PURE__ */ p("span", {
			className: Q.dialCap,
			style: { transform: `rotate(${-135 + l * 270}deg)` },
			children: /* @__PURE__ */ p("span", {})
		})]
	});
	return a ? d : /* @__PURE__ */ m("div", {
		className: Q.knobControl,
		children: [
			/* @__PURE__ */ p("span", {
				className: Q.controlLabel,
				children: s ?? e.label
			}),
			d,
			/* @__PURE__ */ p("span", {
				className: Q.knobValue,
				children: u
			})
		]
	});
}
//#endregion
//#region src/components/CableLayer.tsx
var Tn = (e) => `${e.moduleId}:${e.portId}`, En = (e, t) => {
	let n = Math.min(140, Math.abs(e.y - t.y) * .2 + Math.abs(e.x - t.x) * .25 + 40);
	return `M${e.x},${e.y} C${e.x + 12},${e.y + n} ${t.x - 12},${t.y + n} ${t.x},${t.y}`;
};
function Dn({ patch: e, rackRef: t, selected: n, onSelect: r, drag: i }) {
	let [a, s] = u({}), [c, l] = u(null);
	o(() => {
		let e = t.current;
		if (!e) return;
		function n() {
			let t = e.getBoundingClientRect(), n = {};
			e.querySelectorAll("[data-port-key]").forEach((r) => {
				let i = r.getBoundingClientRect();
				n[r.dataset.portKey] = {
					x: i.x - t.x + i.width / 2 + e.scrollLeft,
					y: i.y - t.y + i.height / 2 + e.scrollTop
				};
			}), s(n);
		}
		n();
		let r = new ResizeObserver(n);
		return r.observe(e), e.querySelectorAll("article").forEach((e) => r.observe(e)), window.addEventListener("resize", n), () => {
			r.disconnect(), window.removeEventListener("resize", n);
		};
	}, [e.modules, t]);
	let d = (t) => {
		let n = e.modules.find((e) => e.id === t.moduleId), r = I[n.type].ports, i = L(e, t), a = Ce(r, i), o = n.type === "mixer" && i.direction === "in" ? `Channel ${i.id.toUpperCase()}: ${$e(e, n.id, i.id).source}` : i.label;
		return `${I[n.type].name} ${o}${a && a > 1 ? ` ${a}` : ""}`;
	}, h = i && L(e, i.anchor), g = i && a[Tn(i.anchor)], _ = i && (i.target ? a[Tn(i.target)] : i.point), v = h && g && _ ? h.direction === "out" ? En(g, _) : En(_, g) : null, y = e.cables.flatMap((t) => {
		let n = a[Tn(t.from)], r = a[Tn(t.to)];
		return n && r && t.id !== i?.cableId ? [{
			cable: t,
			path: En(n, r),
			kind: L(e, t.from).kind
		}] : [];
	});
	return /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("svg", {
		className: Q.cableHits,
		"aria-label": "Patch cables",
		children: y.map(({ cable: e, path: t }) => /* @__PURE__ */ p("path", {
			className: Q.cableHit,
			d: t,
			role: "button",
			tabIndex: 0,
			"aria-label": `Cable from ${d(e.from)} to ${d(e.to)}`,
			onClick: () => r(e.id),
			onPointerEnter: () => l(e.id),
			onPointerLeave: () => l((t) => t === e.id ? null : t),
			onKeyDown: (t) => {
				(t.key === "Enter" || t.key === " ") && (t.preventDefault(), r(e.id));
			}
		}, e.id))
	}), /* @__PURE__ */ m("svg", {
		className: Q.cables,
		"aria-hidden": "true",
		children: [y.map(({ cable: e, path: t, kind: r }) => /* @__PURE__ */ m("g", {
			className: Q.cable,
			"data-kind": r,
			"data-selected": n === e.id,
			"data-hovered": c === e.id,
			children: [/* @__PURE__ */ p("path", {
				className: Q.cableShadow,
				d: t
			}), /* @__PURE__ */ p("path", {
				className: Q.cableLine,
				d: t
			})]
		}, e.id)), v && /* @__PURE__ */ m("g", {
			className: Q.cable,
			"data-kind": h.kind,
			"data-held": "true",
			"data-snapped": !!i.target,
			"data-invalid": !!i.error,
			children: [
				/* @__PURE__ */ p("path", {
					className: Q.cableShadow,
					d: v
				}),
				/* @__PURE__ */ p("path", {
					className: Q.cableLine,
					d: v
				}),
				!i.target && /* @__PURE__ */ p("circle", {
					className: Q.loosePlug,
					cx: _.x,
					cy: _.y,
					r: 8
				})
			]
		})]
	})] });
}
//#endregion
//#region src/audio/studio-processor.js
var On = [
	1e-4,
	3e-4,
	.001,
	.003,
	.01,
	.03
], kn = [
	.1,
	.3,
	.6,
	1.2
], An = [
	1,
	2,
	3,
	4,
	6,
	10,
	20,
	100
], jn = [
	35,
	60,
	110,
	220
], Mn = [
	360,
	700,
	1600,
	3200,
	4800,
	7200
], Nn = [
	0,
	50,
	80,
	160,
	300
], Pn = (e) => 10 ** (e / 20), Fn = [
	1,
	0,
	0,
	0,
	0
];
function In(e, t, n, r, i) {
	if (!t) return Fn.slice();
	let a = 2 * Math.PI * Math.min(t, i * .45) / i, o = Math.cos(a), s = Math.sin(a), c = 10 ** (n / 40), l = s / (2 * r), u = s * Math.sqrt(2 * c), d, f, p, m, h, g;
	if (e === "pole") {
		let e = Math.tan(a / 2);
		return [
			1 / (1 + e),
			-1 / (1 + e),
			0,
			(e - 1) / (e + 1),
			0
		];
	}
	return e === "highpass" ? [d, f, p, m, h, g] = [
		(1 + o) / 2,
		-(1 + o),
		(1 + o) / 2,
		1 + l,
		-2 * o,
		1 - l
	] : e === "bell" ? [d, f, p, m, h, g] = [
		1 + l * c,
		-2 * o,
		1 - l * c,
		1 + l / c,
		-2 * o,
		1 - l / c
	] : e === "low" ? [d, f, p, m, h, g] = [
		c * (c + 1 - (c - 1) * o + u),
		2 * c * (c - 1 - (c + 1) * o),
		c * (c + 1 - (c - 1) * o - u),
		c + 1 + (c - 1) * o + u,
		-2 * (c - 1 + (c + 1) * o),
		c + 1 + (c - 1) * o - u
	] : [d, f, p, m, h, g] = [
		c * (c + 1 + (c - 1) * o + u),
		-2 * c * (c - 1 + (c + 1) * o),
		c * (c + 1 + (c - 1) * o - u),
		c + 1 - (c - 1) * o + u,
		2 * (c - 1 - (c + 1) * o),
		c + 1 - (c - 1) * o - u
	], [
		d / m,
		f / m,
		p / m,
		h / m,
		g / m
	];
}
function Ln(e, t) {
	let n = Nn[e.hpf] ?? 0;
	return [
		In("pole", n, 0, 1, t),
		In("highpass", n, 0, 1, t),
		In("low", jn[e.lfFreq] ?? 110, e.lfGain, .7, t),
		In("bell", Mn[e.midFreq] ?? 1600, e.midGain, .75, t),
		In("high", 12e3, e.hfGain, .7, t)
	];
}
function Rn(e, t, n = 48e3) {
	if (e.active) return 0;
	let r = 2 * Math.PI * t / n, i = (e, t, n) => Math.hypot(e + t * Math.cos(r) + n * Math.cos(2 * r), t * Math.sin(r) + n * Math.sin(2 * r));
	return Ln(e, n).reduce((e, [t, n, r, a, o]) => e + 20 * Math.log10(i(t, n, r) / i(1, a, o)), 0);
}
function zn(e, t) {
	let n, r, i;
	return e === "cohere" ? (n = [
		2,
		4,
		10
	][t.ratio] ?? 4, r = t.threshold + [
		-3,
		0,
		2
	][t.ratio], i = [
		9,
		6,
		3
	][t.ratio]) : (n = An[t.ratio] ?? 6, r = [
		-18,
		-26,
		-24,
		-22,
		-20,
		-18,
		-16,
		-18
	][t.ratio], i = [
		0,
		15,
		12,
		9,
		6,
		4,
		2,
		3
	][t.ratio], t.fierce && (n = Math.max(12, n * 2), r -= 3, i = 2)), [
		1 - 1 / n,
		r,
		i
	];
}
function Bn(e, t, n, r) {
	if (!t) return 0;
	let i = e - n;
	return i <= -r / 2 ? 0 : i >= r / 2 ? -i * t : -t * (i + r / 2) ** 2 / (2 * r);
}
var Vn = class {
	constructor(e) {
		this.c = Fn.slice(), this.target = Fn.slice(), this.z1 = 0, this.z2 = 0, this.smooth = 1 - Math.exp(-1 / (e * .008));
	}
	set(e, t) {
		this.target = e, t && (this.c = e.slice());
	}
	run(e) {
		let t = this.c;
		for (let e = 0; e < 5; e++) t[e] += (this.target[e] - t[e]) * this.smooth;
		let n = t[0] * e + this.z1;
		return this.z1 = t[1] * e - t[3] * n + this.z2, this.z2 = t[2] * e - t[4] * n, n;
	}
}, Hn = Float64Array.from({ length: 49 }, (e, t) => {
	let n = t - 24, r = .1125;
	return (n ? Math.sin(2 * Math.PI * r * n) / (Math.PI * n) : 2 * r) * (.42 - .5 * Math.cos(2 * Math.PI * t / 48) + .08 * Math.cos(4 * Math.PI * t / 48));
}), Un = Hn.reduce((e, t) => e + t, 0);
for (let e = 0; e < Hn.length; e++) Hn[e] /= Un;
var Wn = class {
	constructor() {
		this.buffer = /* @__PURE__ */ new Float64Array(49), this.index = 0;
	}
	push(e) {
		this.buffer[this.index] = e, this.index = (this.index + 1) % 49;
	}
	run(e) {
		this.buffer[this.index] = e;
		let t = 0, n = this.index;
		for (let e = 0; e < 49; e++) t += Hn[e] * this.buffer[n], --n < 0 && (n = 48);
		return this.index = (this.index + 1) % 49, t;
	}
}, Gn = class {
	constructor() {
		this.buffer = /* @__PURE__ */ new Float64Array(13), this.index = 0;
	}
	push(e) {
		this.index = this.index ? this.index - 1 : 12, this.buffer[this.index] = e;
	}
	run(e) {
		let t = 0, n = this.index;
		for (let r = e; r < 49; r += 4) t += Hn[r] * this.buffer[n], ++n > 12 && (n = 0);
		return t;
	}
}, Kn = class {
	constructor() {
		this.buffer = /* @__PURE__ */ new Float64Array(12), this.index = 0;
	}
	run(e) {
		let t = this.buffer[this.index];
		return this.buffer[this.index] = e, this.index = (this.index + 1) % this.buffer.length, t;
	}
}, qn = class {
	constructor(e) {
		this.up = new Gn(), this.down = new Wn(), this.clean = new Kn(), this.previous = 0, this.blocked = 0, this.dc = Math.exp(-2 * Math.PI * 5 / e);
	}
	run(e, t, n) {
		let r = 0, i = Math.tanh(n), a = t * (1 - i * i);
		this.up.push(e * 4);
		for (let e = 0; e < 4; e++) {
			let o = this.up.run(e), s = (Math.tanh(t * o + n) - i) / a;
			e === 0 ? r = this.down.run(s - o) : this.down.push(s - o);
		}
		return this.blocked = r - this.previous + this.dc * this.blocked, this.previous = r, this.clean.run(e) + this.blocked;
	}
}, Jn = class {
	constructor(e, t) {
		this.type = e, this.rate = t, this.params = null, this.events = [], this.disposed = !1, this.reduction = 0, this.gain = [0, 0], this.memory = [0, 0], this.input = 1, this.output = 1, this.wet = 1, this.drive = 0, this.smooth = 1 - Math.exp(-1 / (t * .008)), this.channels = Array.from({ length: 2 }, () => ({
			filters: Array.from({ length: 5 }, () => new Vn(t)),
			hp: new Vn(t),
			emphasis: new Vn(t),
			audioPole: new Vn(t),
			audioHp: new Vn(t),
			color: new qn(t),
			dry: new Kn(),
			clean: new Kn(),
			amount: .15,
			bias: 0
		}));
	}
	enqueue(e) {
		this.events.push(e), this.events.sort((e, t) => e.time - t.time);
	}
	configure(e) {
		let t = !this.params;
		this.params = { ...e }, this.inputTarget = Pn(this.type === "talon" ? e.input : 0), this.outputTarget = Pn(e.output), this.wetTarget = +!e.active, this.driveTarget = e.drive ?? 0, t && (this.input = this.inputTarget, this.output = this.outputTarget, this.wet = this.wetTarget, this.drive = this.driveTarget), this.type !== "brit" && (this.curveTarget = zn(this.type, e), this.linkTarget = this.type === "cohere" ? 1 : e.link, this.attackTarget = this.type === "cohere" ? On[e.attack] : e.attack, this.releaseTarget = this.type === "cohere" ? kn[e.release] ?? .3 : e.release, t && (this.curve = this.curveTarget.slice(), this.link = this.linkTarget, this.attack = this.attackTarget, this.release = this.releaseTarget));
		for (let n of this.channels) {
			this.type === "brit" && Ln(e, this.rate).forEach((e, r) => n.filters[r].set(e, t));
			let r = this.type === "cohere" ? [
				0,
				30,
				60,
				106,
				125,
				185
			][e.scHpf] : e.detectorHp ? 80 : 0;
			n.hp.set(In("highpass", r, 0, Math.SQRT1_2, this.rate), t), n.emphasis.set(In("bell", 6e3, e.detectorBand ? 10 : 0, 1, this.rate), t), n.audioPole.set(In("pole", e.audioHp ? 49.01 : 0, 0, 1, this.rate), t), n.audioHp.set(In("highpass", e.audioHp ? 44.915 : 0, 0, .691, this.rate), t), t && this.type === "talon" && (n.amount = [
				.15,
				.8,
				1.5
			][e.color], n.bias = e.color === 1 ? .3 : 0);
		}
	}
	envelope(e, t) {
		let n = this.params, r = Bn(e, this.curve[0], this.curve[1], this.curve[2]), i = this.gain[t];
		this.memory[t] += (Math.max(0, -i) - this.memory[t]) * (1 - Math.exp(-1 / (this.rate * .6)));
		let a = this.release;
		this.type === "cohere" && n.release === 4 && (a = .1 + Math.min(1.1, this.memory[t] * .09)), this.type === "talon" && (n.ratio === 5 ? a = Math.min(20, this.release * (1 + this.memory[t] * .9)) : n.ratio === 7 ? a *= .45 + Math.min(1.5, Math.max(0, -i) / 15) : a *= [
			1,
			1.15,
			1.05,
			1,
			.9,
			1,
			.8,
			1
		][n.ratio], n.ratio !== 5 && (a = Math.min(3.5, a)), n.fierce && (a *= .65));
		let o = r < i ? this.attack : a;
		return this.gain[t] += (r - i) * (1 - Math.exp(-1 / (o * this.rate))), Pn(this.gain[t]);
	}
	render(e, t, n = 0) {
		if (this.disposed) {
			t.forEach((e) => e.fill(0));
			return;
		}
		let r = t[0].length;
		for (let i = 0; i < r; i++) {
			let r = (n + i) / this.rate;
			for (; this.events.length && this.events[0].time <= r;) this.configure(this.events.shift().params);
			if (!this.params) {
				t.forEach((e) => {
					e[i] = 0;
				});
				continue;
			}
			let a = this.params;
			this.input += (this.inputTarget - this.input) * this.smooth, this.output += (this.outputTarget - this.output) * this.smooth, this.wet += (this.wetTarget - this.wet) * this.smooth, this.drive += (this.driveTarget - this.drive) * this.smooth;
			let o = e[0]?.[i] ?? 0, s = e[1]?.[i] ?? o, c = o * this.input, l = s * this.input, u = 1, d = 1;
			if (this.type !== "brit") {
				for (let e = 0; e < 3; e++) this.curve[e] += (this.curveTarget[e] - this.curve[e]) * this.smooth;
				this.link += (this.linkTarget - this.link) * this.smooth, this.attack += (this.attackTarget - this.attack) * this.smooth, this.release += (this.releaseTarget - this.release) * this.smooth;
				let e = this.channels[0], t = this.channels[1], n = 20 * Math.log10(Math.max(1e-12, Math.abs(e.emphasis.run(e.hp.run(c))))), r = 20 * Math.log10(Math.max(1e-12, Math.abs(t.emphasis.run(t.hp.run(l))))), i = Math.max(n, r);
				this.envelope(n + this.link * (i - n), 0), this.envelope(r + this.link * (i - r), 1);
				let a = Math.min(this.gain[0], this.gain[1]), o = Math.max(this.memory[0], this.memory[1]), s = this.link * this.smooth;
				for (let e = 0; e < 2; e++) this.gain[e] += (a - this.gain[e]) * s, this.memory[e] += (o - this.memory[e]) * s;
				u = Pn(this.gain[0]), d = Pn(this.gain[1]), this.reduction = Math.min(this.gain[0], this.gain[1]) * this.wet;
			}
			for (let e = 0; e < t.length; e++) {
				let n = this.channels[e], r = e === 0 ? o : s, f = e === 0 ? c : l;
				if (this.type === "brit") {
					for (let e of n.filters) f = e.run(f);
					f = n.color.run(f, .22 * Pn(this.drive), .12);
				} else if (this.type === "talon") {
					f = n.audioHp.run(n.audioPole.run(f * (e === 0 ? u : d)));
					let t = [
						.15,
						.8,
						1.5
					][a.color] * (1 + Math.min(2, -this.gain[e] / 20));
					n.amount += (t - n.amount) * this.smooth, n.bias += ((a.color === 1 ? .3 : 0) - n.bias) * this.smooth, f = n.color.run(f, n.amount, n.bias);
				} else f = n.clean.run(f * (e === 0 ? u : d));
				let p = n.dry.run(r);
				t[e][i] = p + this.wet * (f * this.output - p);
			}
		}
	}
};
if (typeof registerProcessor < "u") {
	class e extends AudioWorkletProcessor {
		constructor(e) {
			super(), this.dsp = new Jn(e.processorOptions.type, sampleRate), this.meterFrames = 0, this.port.onmessage = ({ data: e }) => {
				e.type === "flush" ? this.port.postMessage({ id: e.id }) : e.type === "dispose" ? (this.dsp.disposed = !0, this.dsp.events = []) : this.dsp.enqueue(e);
			};
		}
		process(e, t) {
			return this.dsp.render(e[0] ?? [], t[0], currentFrame), this.meterFrames += t[0][0].length, this.meterFrames >= sampleRate / 25 && (this.meterFrames = 0, this.port.postMessage({ reduction: this.dsp.reduction })), !this.dsp.disposed;
		}
	}
	registerProcessor("rackloose-studio-v1", e);
}
//#endregion
//#region src/components/Glyphs.tsx
var Yn = (e) => e.map((t, n) => `${n ? "L" : "M"}${(2 + n * 44 / (e.length - 1)).toFixed(1)} ${(17 - t * 14).toFixed(1)}`).join(" ");
function Xn(e, t) {
	let n = t, r = .5, i = Array.from({ length: 25 }, () => (n = n * 16807 % 2147483647, r += (n / 2147483647 - r) * e, r)), a = Math.min(...i), o = Math.max(...i);
	return Yn(i.map((e) => .1 + (e - a) / (o - a) * .8));
}
var Zn = {
	Sine: Yn(Array.from({ length: 33 }, (e, t) => .5 + .5 * Math.sin(t / 32 * Math.PI * 4))),
	Triangle: Yn([
		0,
		1,
		0,
		1,
		0
	]),
	Saw: "M2 17L24 3V17L46 3V17",
	Square: "M2 17V3H13V17H24V3H35V17H46V3",
	Pulse: "M2 17V3H8V17H24V3H30V17H46",
	"Saw + Pulse": "M2 17L13 13.5V6.5L24 3V17L35 13.5V6.5L46 3V17",
	"Low-pass": "M2 7H24C30 7 31 3 33 6C35 10 38 17 46 18",
	"High-pass": "M2 18C10 17 13 10 15 6C17 3 18 7 24 7H46",
	"Band-pass": "M2 18C14 17 18 4 24 4C30 4 34 17 46 18",
	White: Xn(1, 7),
	Pink: Xn(.45, 11),
	Brown: Xn(.16, 23),
	Bell: "M2 14C14 14 18 4 24 4C30 4 34 14 46 14",
	"Low shelf": "M2 6H14C20 6 22 14 30 14H46",
	"High shelf": "M2 14H18C26 14 28 6 34 6H46"
};
function Qn({ param: e, value: t }) {
	let n = e.choices?.[t] ?? "", r = Zn[n === "Shelf" ? e.id === "hfBell" ? "High shelf" : "Low shelf" : n];
	return r ? /* @__PURE__ */ p("svg", {
		className: Q.choiceGlyph,
		viewBox: "0 0 48 20",
		"aria-hidden": "true",
		children: /* @__PURE__ */ p("path", { d: r })
	}) : null;
}
function $n({ params: e, brit: t = !1, rate: n = 48e3 }) {
	let r = ln(e, 24e3), i = (e) => 25 - Math.max(-18, Math.min(18, e)) * 22 / 18, a = Array.from({ length: 72 }, (a, o) => {
		let s = 20 * 1e3 ** (o / 71);
		return `${o ? "L" : "M"}${(3 + o * 114 / 71).toFixed(1)} ${i(t ? Rn(e, s, n) : r.reduce((e, t) => e + un(t, s, 48e3), 0)).toFixed(1)}`;
	}).join("");
	return /* @__PURE__ */ m("svg", {
		className: Q.eqGraphic,
		viewBox: "0 0 120 50",
		role: t ? "img" : void 0,
		"aria-label": t ? `BRIT filter response, 20 Hz to 20 kHz, at ${n / 1e3} kHz` : void 0,
		"aria-hidden": !t || void 0,
		"data-bypassed": e.active === 1,
		children: [
			[
				100,
				1e3,
				1e4
			].map((e) => /* @__PURE__ */ p("line", {
				x1: 3 + Math.log10(e / 20) / 3 * 114,
				x2: 3 + Math.log10(e / 20) / 3 * 114,
				y1: "3",
				y2: "47"
			}, e)),
			/* @__PURE__ */ p("line", {
				x1: "3",
				x2: "117",
				y1: "25",
				y2: "25"
			}),
			/* @__PURE__ */ p("path", { d: a })
		]
	});
}
function er({ reduction: e, label: t, max: n = 20 }) {
	let r = Math.min(n, Math.max(0, -e)), i = (e) => 45 - e / n * 90, a = (e, t) => {
		let n = (i(e) - 90) * Math.PI / 180;
		return [60 + Math.cos(n) * t, 60 + Math.sin(n) * t].map((e) => Number(e.toFixed(1)));
	};
	return /* @__PURE__ */ p("div", {
		className: Q.grMeter,
		role: "meter",
		"aria-label": t,
		"aria-valuemin": 0,
		"aria-valuemax": n,
		"aria-valuenow": r,
		"aria-valuetext": `${r} dB gain reduction`,
		children: /* @__PURE__ */ m("svg", {
			viewBox: "0 0 120 50",
			"aria-hidden": "true",
			children: [
				/* @__PURE__ */ p("path", { d: `M${a(0, 48).join(" ")}A48 48 0 0 0 ${a(n, 48).join(" ")}` }),
				[
					0,
					n / 4,
					n / 2,
					n * 3 / 4,
					n
				].map((e) => {
					let [t, n] = a(e, 48), [r, i] = a(e, 53), [o, s] = a(e, 40);
					return /* @__PURE__ */ m("g", { children: [/* @__PURE__ */ p("line", {
						x1: t,
						y1: n,
						x2: r,
						y2: i
					}), /* @__PURE__ */ p("text", {
						x: o,
						y: s,
						textAnchor: "middle",
						dominantBaseline: "middle",
						children: e
					})] }, e);
				}),
				/* @__PURE__ */ p("text", {
					className: Q.grUnit,
					x: "8",
					y: "45",
					children: "GR dB"
				}),
				/* @__PURE__ */ p("line", {
					className: Q.grNeedle,
					x1: "60",
					y1: "60",
					x2: "60",
					y2: "8",
					style: { transform: `rotate(${i(r)}deg)` }
				})
			]
		})
	});
}
var [tr, nr, , rr] = I.envelope.params;
function ir({ params: e }) {
	let t = (t) => 9 + H(t, e[t.id]) * 24, n = 3 + t(tr), r = n + t(nr), i = 117 - t(rr), a = 40 - e.sustain * 35, o = [
		["A", (3 + n) / 2],
		["D", (n + r) / 2],
		["S", (r + i) / 2],
		["R", (i + 117) / 2]
	];
	return /* @__PURE__ */ m("svg", {
		className: Q.envelopeGraphic,
		viewBox: "0 0 120 50",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ p("path", { d: `M3 40L${n.toFixed(1)} 5L${r.toFixed(1)} ${a.toFixed(1)}L${i.toFixed(1)} ${a.toFixed(1)}L117 40` }), o.map(([e, t]) => /* @__PURE__ */ p("text", {
			x: t.toFixed(1),
			y: "48",
			textAnchor: "middle",
			children: e
		}, e))]
	});
}
var ar = {
	play: /* @__PURE__ */ p("path", { d: "M3.5 2.2v9.6L11.6 7z" }),
	pause: /* @__PURE__ */ p("path", { d: "M3 2.2h2.9v9.6H3zM8.1 2.2H11v9.6H8.1z" }),
	stop: /* @__PURE__ */ p("path", { d: "M2.8 2.8h8.4v8.4H2.8z" }),
	reset: /* @__PURE__ */ p("path", { d: "M2.4 2.2h2v9.6h-2zM11.8 2.2v9.6L4.9 7z" }),
	undo: /* @__PURE__ */ p("path", {
		d: "M5.2 2.4 1.6 5.8l3.6 3.4V7.1h3.2a2.6 2.6 0 0 1 0 5.2H6.6v1.5h1.8a4.1 4.1 0 0 0 0-8.2H5.2z",
		transform: "translate(0 -1.2)"
	}),
	redo: /* @__PURE__ */ p("path", {
		d: "M8.8 2.4l3.6 3.4-3.6 3.4V7.1H5.6a2.6 2.6 0 0 0 0 5.2h1.8v1.5H5.6a4.1 4.1 0 0 1 0-8.2h3.2z",
		transform: "translate(0 -1.2)"
	})
};
function or({ name: e }) {
	return /* @__PURE__ */ p("svg", {
		className: Q.icon,
		viewBox: "0 0 14 14",
		"aria-hidden": "true",
		focusable: "false",
		children: ar[e]
	});
}
//#endregion
//#region src/components/MixButtons.tsx
function sr({ mixKey: e, label: t, mix: n, onToggle: r, solo: i = !0, onClear: a, clearable: o }) {
	return /* @__PURE__ */ m("span", {
		className: Q.mixButtons,
		children: [
			/* @__PURE__ */ p("button", {
				className: Q.muteToggle,
				"aria-label": `Mute ${t}`,
				"aria-pressed": n.muted.has(e),
				title: `Mute ${t}`,
				onClick: () => r(e, "muted"),
				children: "M"
			}),
			i && /* @__PURE__ */ p("button", {
				className: Q.soloToggle,
				"aria-label": `Solo ${t}`,
				"aria-pressed": n.soloed.has(e),
				title: `Solo ${t}`,
				onClick: () => r(e, "soloed"),
				children: "S"
			}),
			a && /* @__PURE__ */ p("button", {
				className: Q.clearToggle,
				"aria-label": `Clear ${t} mutes and solos`,
				title: `Clear ${t} mutes and solos`,
				disabled: !o,
				onClick: a,
				children: "CLR"
			})
		]
	});
}
//#endregion
//#region src/components/Drums.tsx
function cr({ module: e, mix: t, onMix: n, step: r, onParams: i, onAudition: a, disabled: o }) {
	let s = I[e.type];
	return /* @__PURE__ */ p("div", {
		className: Q.drumPads,
		children: s.drum.voices.map((c) => {
			let l = `${c.id}Pattern`, u = e.params[l];
			return /* @__PURE__ */ m("div", {
				className: Q.drumLane,
				"data-silent": !Ye(e, c.id, t),
				children: [
					/* @__PURE__ */ p("button", {
						className: Q.voiceButton,
						"aria-label": `Play ${s.name} ${c.label}`,
						disabled: o,
						onClick: () => a(c.id),
						children: c.label
					}),
					/* @__PURE__ */ p(sr, {
						mixKey: He(e.id, c.id),
						label: `${s.name} ${c.label}`,
						mix: t,
						onToggle: n
					}),
					/* @__PURE__ */ p("div", {
						className: Q.pads,
						children: [
							0,
							1,
							2,
							3
						].map((e) => /* @__PURE__ */ p("div", {
							className: Q.padGroup,
							"data-group": e,
							children: [
								0,
								1,
								2,
								3
							].map((t) => {
								let n = e * 4 + t;
								return /* @__PURE__ */ p("button", {
									className: Q.pad,
									"data-current": r === n,
									"aria-pressed": Me(u, n),
									"aria-label": `${s.name} ${c.label} step ${n + 1}`,
									onClick: () => i({ [l]: u ^ 1 << n }),
									children: /* @__PURE__ */ p("span", {})
								}, n);
							})
						}, e))
					})
				]
			}, c.id);
		})
	});
}
var lr = [
	"Steps",
	"Hits",
	"Shift"
];
function ur({ module: t, mix: n, onMix: r, onParams: i, onAudition: a, disabled: o, clock: s }) {
	let c = I[t.type], [l, d] = u(c.drum.voices[0].id), f = c.drum.voices.find((e) => e.id === l), h = z(t, l);
	return /* @__PURE__ */ m("div", {
		className: Q.orbitEditor,
		children: [/* @__PURE__ */ m("div", {
			className: Q.euclid,
			role: "group",
			"aria-label": `${c.name} rhythm`,
			children: [
				/* @__PURE__ */ p("span", { children: "VOICE / EDIT" }),
				/* @__PURE__ */ p("span", {}),
				lr.map((e) => /* @__PURE__ */ p("span", {
					className: Q.euclidHeading,
					children: e
				}, e)),
				c.drum.voices.map((s) => /* @__PURE__ */ m(e, { children: [
					/* @__PURE__ */ p("button", {
						className: Q.voiceButton,
						"aria-label": `Play ${c.name} ${s.label}`,
						"aria-pressed": l === s.id,
						disabled: o,
						"data-silent": !Ye(t, s.id, n),
						onClick: () => {
							d(s.id), a(s.id);
						},
						children: s.label
					}),
					/* @__PURE__ */ p(sr, {
						mixKey: He(t.id, s.id),
						label: `${c.name} ${s.label}`,
						mix: n,
						onToggle: r
					}),
					lr.map((e) => {
						let n = c.params.find((t) => t.id === `${s.id}${e}`);
						return /* @__PURE__ */ m("div", {
							className: Q.euclidCell,
							children: [/* @__PURE__ */ p(wn, {
								trim: !0,
								param: n,
								prefix: c.name,
								disabled: e !== "Steps" && !!t.params[`${s.id}Custom`],
								value: t.params[n.id],
								onChange: (e) => i({ [n.id]: e })
							}), /* @__PURE__ */ p("output", { children: t.params[n.id] })]
						}, e);
					})
				] }, s.id))
			]
		}), /* @__PURE__ */ m("div", {
			className: Q.orbitVoiceEditor,
			role: "group",
			"aria-label": `Edit ORBIT ${f.label}`,
			children: [
				/* @__PURE__ */ m("div", {
					className: Q.orbitEditorHeading,
					children: [
						/* @__PURE__ */ m("label", { children: ["EDIT VOICE ", /* @__PURE__ */ p("select", {
							"aria-label": "Orbit edit voice",
							value: l,
							onChange: (e) => d(e.target.value),
							children: c.drum.voices.map((e) => /* @__PURE__ */ p("option", {
								value: e.id,
								children: e.label
							}, e.id))
						})] }),
						/* @__PURE__ */ p("span", { children: t.params[`${l}Custom`] ? "CUSTOM" : "EUCLIDEAN" }),
						/* @__PURE__ */ p("button", {
							onClick: () => i({ [`${l}Custom`]: 0 }),
							"aria-label": `Generate ORBIT ${f.label} rhythm`,
							children: "Generate"
						})
					]
				}),
				/* @__PURE__ */ p("div", {
					className: Q.controls,
					children: [
						"Tune",
						"Decay",
						"Tone",
						"Level"
					].map((e) => {
						let n = c.params.find((t) => t.id === `${l}${e}`);
						return /* @__PURE__ */ p(wn, {
							param: {
								...n,
								label: e
							},
							prefix: `ORBIT ${f.label}`,
							value: t.params[n.id],
							onChange: (e) => i({ [n.id]: e })
						}, n.id);
					})
				}),
				/* @__PURE__ */ p("div", {
					className: Q.orbitSteps,
					children: h.map((e, n) => /* @__PURE__ */ m("button", {
						className: Q.pad,
						"aria-pressed": e,
						"data-current": s >= 0 && s % h.length === n,
						"aria-label": `ORBIT ${f.label} step ${n + 1}`,
						onClick: () => {
							let e = Fe(t, l, n);
							i({
								[`${l}Pattern`]: e[`${l}Pattern`],
								[`${l}Custom`]: 1
							});
						},
						children: [/* @__PURE__ */ p("span", {}), n + 1]
					}, n))
				}),
				/* @__PURE__ */ p("small", { children: "Tap a step to customize. Generate restores the Euclidean rhythm." })
			]
		})]
	});
}
var dr = [
	70,
	59,
	48,
	37,
	26,
	15
];
function fr({ module: e, clock: t }) {
	return /* @__PURE__ */ p("svg", {
		className: Q.orbitRings,
		viewBox: "0 0 160 160",
		"aria-hidden": "true",
		children: I[e.type].drum.voices.map(({ id: n }, r) => {
			let i = z(e, n), a = dr[r], o = t < 0 ? -1 : t % i.length;
			return /* @__PURE__ */ m("g", {
				"data-voice": n,
				children: [/* @__PURE__ */ p("circle", {
					className: Q.orbitPath,
					cx: "80",
					cy: "80",
					r: a
				}), i.map((e, t) => {
					let n = t / i.length * 2 * Math.PI - Math.PI / 2;
					return /* @__PURE__ */ p("circle", {
						cx: (80 + a * Math.cos(n)).toFixed(2),
						cy: (80 + a * Math.sin(n)).toFixed(2),
						r: t === o ? 3.8 : e ? 3 : 1.4,
						"data-hit": e,
						"data-current": t === o
					}, t);
				})]
			}, n);
		})
	});
}
//#endregion
//#region src/components/SoundEditors.tsx
function pr({ module: e, onParams: t, onAudition: n, disabled: r }) {
	let [i, a] = u("kick"), o = I.strike, s = o.drum.voices.find((e) => e.id === i);
	return /* @__PURE__ */ m("div", {
		className: Q.soundEditor,
		role: "group",
		"aria-label": "STRIKE voice editor",
		children: [/* @__PURE__ */ m("div", {
			className: Q.editorHeading,
			children: [
				/* @__PURE__ */ m("label", { children: ["EDIT VOICE ", /* @__PURE__ */ p("select", {
					"aria-label": "STRIKE edit voice",
					value: i,
					onChange: (e) => a(e.target.value),
					children: o.drum.voices.map((e) => /* @__PURE__ */ p("option", {
						value: e.id,
						children: e.label
					}, e.id))
				})] }),
				/* @__PURE__ */ m("button", {
					disabled: r,
					onClick: () => n(i),
					children: ["Audition ", s.label]
				}),
				/* @__PURE__ */ p("small", { children: "ORIGINAL DIGITAL KIT · 16 VOICES" })
			]
		}), /* @__PURE__ */ p("div", {
			className: Q.controls,
			children: o.params.filter((e) => e.voice === i && !e.pattern).map((n) => /* @__PURE__ */ p(wn, {
				param: {
					...n,
					label: n.label.slice(s.label.length + 1)
				},
				prefix: `STRIKE ${s.label}`,
				value: e.params[n.id],
				onChange: (e) => t({ [n.id]: e })
			}, n.id))
		})]
	});
}
var mr = [
	"2→1 + 4→3 + 6→5",
	"3→2→1 + 6→5→4",
	"6→5→4→3→2→1",
	"5+6→4→1+2+3",
	"4→2→1 + 6→5→3→1",
	"1 + 2 + 3 + 4 + 5 + 6"
];
function hr({ module: e, onParams: t }) {
	let [n, r] = u(1);
	return /* @__PURE__ */ m("div", {
		className: Q.soundEditor,
		role: "group",
		"aria-label": "PRISM operator editor",
		children: [
			/* @__PURE__ */ m("div", {
				className: Q.fmDisplay,
				children: [
					/* @__PURE__ */ p("span", { children: de[e.params.algorithm] }),
					/* @__PURE__ */ p("strong", { children: mr[e.params.algorithm] }),
					/* @__PURE__ */ p("small", { children: "16 VOICES · SIX OPERATORS · PHASE MODULATION" })
				]
			}),
			/* @__PURE__ */ p("div", {
				className: Q.operatorTabs,
				role: "group",
				"aria-label": "Select PRISM operator",
				children: [
					1,
					2,
					3,
					4,
					5,
					6
				].map((e) => /* @__PURE__ */ m("button", {
					"aria-pressed": n === e,
					"aria-label": `Edit PRISM operator ${e}`,
					onClick: () => r(e),
					children: ["OP ", e]
				}, e))
			}),
			/* @__PURE__ */ p("div", {
				className: Q.controls,
				children: I.prism.params.filter((e) => e.voice === `op${n}`).map((r) => /* @__PURE__ */ p(wn, {
					param: r,
					prefix: `PRISM Operator ${n}`,
					value: e.params[r.id],
					onChange: (e) => t({ [r.id]: e })
				}, r.id))
			})
		]
	});
}
//#endregion
//#region src/components/PanelLegend.tsx
function gr({ size: e, height: t, inner: n, marks: r }) {
	let i = (n, r) => [e / 2 + n * Math.sin(r * Math.PI / 180), t / 2 - n * Math.cos(r * Math.PI / 180)], a = (e, t) => n + 10 + (e.length - 1) * 2.2 * Math.abs(Math.sin(t * Math.PI / 180));
	return /* @__PURE__ */ p("svg", {
		className: Q.panelLegend,
		width: e,
		height: t,
		viewBox: `0 0 ${e} ${t}`,
		"aria-hidden": "true",
		children: r.map(({ angle: e, text: t, lit: r }, o) => {
			let [s, c] = i(n, e), [l, u] = i(n + (t ? 4 : 2.5), e), [d, f] = i(a(t ?? "", e), e);
			return /* @__PURE__ */ m("g", {
				"data-lit": r || void 0,
				children: [/* @__PURE__ */ p("line", {
					x1: s,
					y1: c,
					x2: l,
					y2: u
				}), t && /* @__PURE__ */ p("text", {
					x: d,
					y: f,
					textAnchor: "middle",
					dominantBaseline: "central",
					children: t
				})]
			}, o);
		})
	});
}
//#endregion
//#region src/components/Brit.tsx
var _r = (e) => I.brit.params.find((t) => t.id === e), vr = (e, t) => {
	let n = Math.min(270, (t - 1) * 45);
	return -n / 2 + e * n / (t - 1);
}, yr = (e, t) => e.choices ? vr(t, e.choices.length) : -135 + H(e, t) * 270, br = 104, xr = (e) => ({
	"--size": `${e}px`,
	"--height": `${br}px`
});
function Sr({ angle: e, skirt: t }) {
	return /* @__PURE__ */ m(f, { children: [
		t && /* @__PURE__ */ p("span", { className: Q.marconiSkirt }),
		/* @__PURE__ */ p("span", { className: Q.marconiFlutes }),
		/* @__PURE__ */ p("span", { className: Q.marconiDome }),
		/* @__PURE__ */ p("span", {
			className: Q.marconiPointer,
			style: { transform: `rotate(${e}deg)` }
		})
	] });
}
var Cr = (e, t) => [...Array.from({ length: 11 }, (e, t) => ({ angle: -135 + t * 27 })), ...t.map(([t, n]) => ({
	angle: yr(e, t),
	text: n
}))], wr = (e, t) => e.map((n, r) => ({
	angle: vr(r, e.length),
	text: n,
	lit: r === t
}));
function Tr({ module: e, prefix: t, onParams: n, id: r, color: i, size: a, knob: o, skirt: s, title: c, labels: l, marks: u }) {
	let d = _r(r), f = e.params[r], { props: h, display: g } = $({
		param: d,
		value: f,
		prefix: t,
		onChange: (e) => n({ [r]: e })
	});
	return /* @__PURE__ */ m("div", {
		className: Q.britSection,
		children: [
			/* @__PURE__ */ p("strong", { children: c }),
			/* @__PURE__ */ m("div", {
				className: Q.britWell,
				style: xr(a),
				children: [/* @__PURE__ */ p(gr, {
					size: a,
					height: br,
					inner: o / 2 + 3,
					marks: l ? wr(l, f) : Cr(d, u ?? [])
				}), /* @__PURE__ */ p("div", {
					className: Q.marconi,
					"data-color": i,
					"data-skirt": s || void 0,
					style: { "--knob": `${o}px` },
					...h,
					children: /* @__PURE__ */ p(Sr, {
						angle: yr(d, f),
						skirt: s
					})
				})]
			}),
			!l && /* @__PURE__ */ p("span", {
				className: Q.knobValue,
				children: g
			})
		]
	});
}
function Er({ module: e, prefix: t, onParams: n, frequency: r, gain: i, color: a, title: o, labels: s }) {
	let c = _r(r), l = _r(i), u = $({
		param: c,
		value: e.params[r],
		prefix: t,
		onChange: (e) => n({ [r]: e })
	}), d = $({
		param: l,
		value: e.params[i],
		prefix: t,
		onChange: (e) => n({ [i]: e })
	});
	return /* @__PURE__ */ m("div", {
		className: Q.britSection,
		children: [
			/* @__PURE__ */ p("strong", { children: o }),
			/* @__PURE__ */ m("div", {
				className: Q.britWell,
				style: xr(112),
				children: [
					/* @__PURE__ */ p(gr, {
						size: 112,
						height: br,
						inner: 36,
						marks: wr(s, e.params[r])
					}),
					/* @__PURE__ */ p("div", {
						className: Q.marconiRing,
						style: { "--ring": "66px" },
						...u.props,
						children: /* @__PURE__ */ p("span", {
							className: Q.ringPointer,
							style: { transform: `rotate(${yr(c, e.params[r])}deg)` }
						})
					}),
					/* @__PURE__ */ p("div", {
						className: Q.marconi,
						"data-color": a,
						style: { "--knob": "38px" },
						...d.props,
						children: /* @__PURE__ */ p(Sr, { angle: yr(l, e.params[i]) })
					})
				]
			}),
			/* @__PURE__ */ p("span", {
				className: Q.knobValue,
				children: d.display
			})
		]
	});
}
function Dr({ module: e, onParams: t, rate: n }) {
	let r = I.brit.name, i = e.params.active === 0, a = (n) => ({
		module: e,
		onParams: t,
		prefix: `${r} ${n}`
	});
	return /* @__PURE__ */ m("div", {
		className: Q.britPanel,
		"data-bypassed": !i,
		children: [
			/* @__PURE__ */ p(Tr, {
				...a("Signal"),
				id: "hpf",
				color: "blue",
				size: 96,
				knob: 46,
				title: "High pass",
				labels: [
					"OFF",
					"50",
					"80",
					"160",
					"300"
				]
			}),
			/* @__PURE__ */ p(Er, {
				...a("Low shelf"),
				frequency: "lfFreq",
				gain: "lfGain",
				color: "grey",
				title: "Low · Hz",
				labels: [
					"35",
					"60",
					"110",
					"220"
				]
			}),
			/* @__PURE__ */ p(Er, {
				...a("Mid bell"),
				frequency: "midFreq",
				gain: "midGain",
				color: "blue",
				title: "Mid · kHz",
				labels: [
					".36",
					".7",
					"1.6",
					"3.2",
					"4.8",
					"7.2"
				]
			}),
			/* @__PURE__ */ p(Tr, {
				...a("High shelf · 12 kHz"),
				id: "hfGain",
				color: "grey",
				size: 88,
				knob: 44,
				title: "High · 12k",
				marks: [
					[-16, "−16"],
					[0, "0"],
					[16, "+16"]
				]
			}),
			/* @__PURE__ */ p(Tr, {
				...a("Signal"),
				id: "drive",
				color: "red",
				size: 100,
				knob: 64,
				skirt: !0,
				title: "Drive",
				marks: [
					[0, "0"],
					[12, "12"],
					[24, "24"]
				]
			}),
			/* @__PURE__ */ p(Tr, {
				...a("Signal"),
				id: "output",
				color: "grey",
				size: 80,
				knob: 36,
				title: "Output",
				marks: [
					[-18, "−18"],
					[0, "0"],
					[18, "+18"]
				]
			}),
			/* @__PURE__ */ m("div", {
				className: Q.britSection,
				children: [/* @__PURE__ */ p("strong", { children: "EQ" }), /* @__PURE__ */ m("button", {
					className: Q.britSwitch,
					"aria-pressed": i,
					"aria-label": `${r} EQ in`,
					title: i ? "EQ in. Press to bypass." : "Bypassed. Press to switch the EQ in.",
					onClick: () => t({ active: +!!i }),
					children: [/* @__PURE__ */ p("span", { className: Q.britLamp }), "IN"]
				})]
			}),
			/* @__PURE__ */ m("div", {
				className: `${Q.britSection} ${Q.britCurve}`,
				children: [/* @__PURE__ */ p("strong", { children: "Response" }), /* @__PURE__ */ p($n, {
					params: e.params,
					brit: !0,
					rate: n
				})]
			})
		]
	});
}
//#endregion
//#region src/components/Talon.tsx
var Or = I.talon.name, kr = (e) => I.talon.params.find((t) => t.id === e), Ar = (e) => `${Or} ${e.group} ${e.label}`, jr = (e, t) => -135 + H(e, t) * 270, Mr = 108, Nr = [
	1,
	2,
	3,
	4,
	6,
	8,
	10,
	14,
	20,
	30
];
function Pr({ module: e, onParams: t, id: n, size: r, knob: i, title: a, marks: o }) {
	let s = kr(n), c = e.params[n], { props: l, display: u } = $({
		param: s,
		value: c,
		prefix: `${Or} ${s.group}`,
		onChange: (e) => t({ [n]: e })
	}), d = [...Array.from({ length: 11 }, (e, t) => ({ angle: -135 + t * 27 })), ...o.map(([e, t]) => ({
		angle: jr(s, e),
		text: t
	}))];
	return /* @__PURE__ */ m("div", {
		className: Q.talonSection,
		children: [
			/* @__PURE__ */ p("strong", { children: a }),
			/* @__PURE__ */ m("div", {
				className: Q.talonWell,
				style: {
					"--size": `${r}px`,
					"--height": `${Mr}px`
				},
				children: [/* @__PURE__ */ p(gr, {
					size: r,
					height: Mr,
					inner: i / 2 + 4,
					marks: d
				}), /* @__PURE__ */ m("div", {
					className: Q.talonKnob,
					style: { "--knob": `${i}px` },
					...l,
					children: [
						/* @__PURE__ */ p("span", { className: Q.talonGrip }),
						/* @__PURE__ */ p("span", { className: Q.talonCap }),
						/* @__PURE__ */ p("span", {
							className: Q.talonIndex,
							style: { transform: `rotate(${jr(s, c)}deg)` }
						})
					]
				})]
			}),
			/* @__PURE__ */ p("span", {
				className: Q.knobValue,
				children: u
			})
		]
	});
}
function Fr({ module: e, onParams: t, id: n, title: r, button: i, captions: a = [] }) {
	let o = kr(n), s = e.params[n], c = o.choices.length;
	function l(e) {
		let r = {
			ArrowDown: s + 1,
			ArrowRight: s + 1,
			ArrowUp: s - 1,
			ArrowLeft: s - 1,
			Home: 0,
			End: c - 1
		}[e.key];
		if (r === void 0) return;
		e.preventDefault();
		let i = Math.max(0, Math.min(c - 1, r));
		t({ [n]: i }), e.currentTarget.querySelectorAll("[role=\"radio\"]")[i].focus();
	}
	return /* @__PURE__ */ m("div", {
		className: Q.talonSection,
		children: [
			/* @__PURE__ */ p("strong", { children: r }),
			/* @__PURE__ */ p("div", {
				className: Q.talonLamps,
				role: "radiogroup",
				"aria-label": Ar(o),
				onKeyDown: l,
				children: o.choices.map((e, r) => /* @__PURE__ */ m("button", {
					type: "button",
					role: "radio",
					"aria-checked": r === s,
					tabIndex: r === s ? 0 : -1,
					onClick: () => t({ [n]: r }),
					children: [
						/* @__PURE__ */ p("span", { className: Q.talonLed }),
						e,
						a[r] && /* @__PURE__ */ p("small", {
							"aria-hidden": "true",
							children: a[r]
						})
					]
				}, e))
			}),
			/* @__PURE__ */ p("button", {
				type: "button",
				className: Q.talonPush,
				"aria-label": `${Ar(o)}: next`,
				title: `Step to the next ${o.label.toLowerCase()} mode`,
				onClick: () => t({ [n]: (s + 1) % c }),
				children: i
			})
		]
	});
}
function Ir({ module: e, onParams: t, id: n, text: r }) {
	let i = kr(n), a = e.params[n] === 1;
	return /* @__PURE__ */ m("button", {
		type: "button",
		className: Q.talonPush,
		"aria-pressed": a,
		"aria-label": Ar(i),
		title: `${i.label}: ${i.choices[e.params[n]]}`,
		onClick: () => t({ [n]: +!a }),
		children: [/* @__PURE__ */ p("span", { className: Q.talonLed }), r]
	});
}
function Lr({ reduction: e, label: t }) {
	let n = Math.min(40, Math.max(0, -e));
	return /* @__PURE__ */ m("div", {
		className: Q.talonSection,
		children: [/* @__PURE__ */ p("strong", { children: "GR" }), /* @__PURE__ */ p("div", {
			className: Q.talonMeter,
			role: "meter",
			"aria-label": t,
			"aria-valuemin": 0,
			"aria-valuemax": 40,
			"aria-valuenow": n,
			"aria-valuetext": `${n} dB gain reduction`,
			children: Nr.map((e) => /* @__PURE__ */ m("span", {
				"data-lit": n >= e,
				"data-hot": e > 10 || void 0,
				children: [/* @__PURE__ */ p("i", {}), e]
			}, e))
		})]
	});
}
function Rr({ module: e, onParams: t, reduction: n, label: r }) {
	let i = {
		module: e,
		onParams: t
	}, a = e.params.active === 0;
	return /* @__PURE__ */ m("div", {
		className: Q.talonPanel,
		"data-bypassed": !a,
		children: [
			/* @__PURE__ */ p(Pr, {
				...i,
				id: "input",
				size: 100,
				knob: 60,
				title: "Input",
				marks: [
					[-12, "−12"],
					[0, "0"],
					[12, "12"],
					[30, "30"]
				]
			}),
			/* @__PURE__ */ p(Pr, {
				...i,
				id: "attack",
				size: 84,
				knob: 46,
				title: "Attack · ms",
				marks: [
					[5e-5, ".05"],
					[.001, "1"],
					[.01, "10"],
					[.03, "30"]
				]
			}),
			/* @__PURE__ */ p(Pr, {
				...i,
				id: "release",
				size: 84,
				knob: 46,
				title: "Release · s",
				marks: [
					[.05, ".05"],
					[.3, ".3"],
					[1, "1"],
					[3.5, "3.5"]
				]
			}),
			/* @__PURE__ */ p(Fr, {
				...i,
				id: "ratio",
				title: "Ratio",
				button: "Ratio"
			}),
			/* @__PURE__ */ m("div", {
				className: Q.talonSection,
				children: [/* @__PURE__ */ p(Fr, {
					...i,
					id: "color",
					title: "Harmonics",
					button: "Dist",
					captions: [
						"",
						"2nd",
						"3rd"
					]
				}), /* @__PURE__ */ m("div", {
					className: Q.talonLatches,
					children: [/* @__PURE__ */ p(Ir, {
						...i,
						id: "audioHp",
						text: "HP 65"
					}), /* @__PURE__ */ p(Ir, {
						...i,
						id: "fierce",
						text: "Fierce"
					})]
				})]
			}),
			/* @__PURE__ */ m("div", {
				className: Q.talonSection,
				children: [/* @__PURE__ */ p("strong", { children: "Detector" }), /* @__PURE__ */ m("div", {
					className: Q.talonLatches,
					children: [
						/* @__PURE__ */ p(Ir, {
							...i,
							id: "detectorHp",
							text: "HP 80"
						}),
						/* @__PURE__ */ p(Ir, {
							...i,
							id: "detectorBand",
							text: "Band 6k"
						}),
						/* @__PURE__ */ p(Ir, {
							...i,
							id: "link",
							text: "Link"
						})
					]
				})]
			}),
			/* @__PURE__ */ m("div", {
				className: Q.talonOutput,
				children: [
					/* @__PURE__ */ p(Lr, {
						reduction: n,
						label: r
					}),
					/* @__PURE__ */ p(Pr, {
						...i,
						id: "output",
						size: 100,
						knob: 60,
						title: "Output",
						marks: [
							[-30, "−30"],
							[-12, "−12"],
							[0, "0"],
							[12, "+12"]
						]
					}),
					/* @__PURE__ */ m("div", {
						className: Q.talonSection,
						children: [/* @__PURE__ */ p("strong", { children: "Comp" }), /* @__PURE__ */ m("button", {
							type: "button",
							className: Q.talonSwitch,
							"aria-pressed": a,
							"aria-label": `${Or} in`,
							title: a ? "In. Press to bypass." : "Bypassed. Press to switch TALON in.",
							onClick: () => t({ active: +!!a }),
							children: [/* @__PURE__ */ p("span", { className: Q.talonLamp }), "IN"]
						})]
					})
				]
			}),
			e.params.ratio === 5 && /* @__PURE__ */ p("p", {
				className: Q.processorHint,
				children: "Opto recovery lengthens with sustained reduction, up to 20 s."
			})
		]
	});
}
//#endregion
//#region src/components/Mixer.tsx
var zr = 112, Br = [
	[1, "0"],
	[10 ** (-3 / 20), "3"],
	[.5, "6"],
	[10 ** (-10 / 20), "10"],
	[.1, "20"],
	[0, "∞"]
], Vr = [
	-48,
	-42,
	-36,
	-30,
	-24,
	-18,
	-12,
	-9,
	-6,
	-3,
	0
], Hr = (e) => I.mixer.params.find((t) => t.id === e), Ur = (e) => e <= 0 ? "−∞" : `${(20 * Math.log10(e)).toFixed(1).replace("-", "−")} dB`, Wr = (e) => Math.abs(e) < .005 ? "C" : `${e < 0 ? "L" : "R"}${Math.round(Math.abs(e) * 100)}`;
function Gr({ level: e, label: t }) {
	let n = Math.round(e);
	return /* @__PURE__ */ p("div", {
		className: Q.levelMeter,
		role: "meter",
		"aria-label": t,
		"aria-valuemin": Vr[0],
		"aria-valuemax": 0,
		"aria-valuenow": Math.max(Vr[0], Math.min(0, n)),
		"aria-valuetext": e < Vr[0] ? "Silent" : `${n} dB`,
		children: Vr.map((t) => /* @__PURE__ */ p("i", {
			"data-lit": e >= t,
			"data-zone": t >= -3 ? "hot" : t >= -9 ? "warm" : void 0
		}, t))
	});
}
function Kr({ param: e, value: t, prefix: n, onChange: r, children: i }) {
	let { props: a, fraction: o, display: s } = $({
		param: e,
		value: t,
		prefix: n,
		onChange: r,
		format: Ur,
		travel: zr
	});
	return /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ m("div", {
		className: Q.faderBay,
		style: { "--travel": `${zr}px` },
		children: [
			/* @__PURE__ */ p("span", {
				className: Q.faderScale,
				"aria-hidden": "true",
				children: Br.map(([e, t]) => /* @__PURE__ */ p("span", {
					style: { "--at": e },
					children: t
				}, t))
			}),
			/* @__PURE__ */ p("div", {
				className: Q.faderSlot,
				...a,
				children: /* @__PURE__ */ p("span", {
					className: Q.faderCap,
					style: { "--at": o }
				})
			}),
			i
		]
	}), /* @__PURE__ */ p("span", {
		className: Q.faderValue,
		children: s
	})] });
}
function qr({ module: e, patch: t, mix: n, levels: r, onParams: i, onToggle: a }) {
	let o = I[e.type].name;
	return /* @__PURE__ */ m("div", {
		className: Q.console,
		children: [fe.map((s, c) => {
			let { source: l, tooltip: u, connected: d } = $e(t, e.id, s), f = s.toUpperCase(), h = pe(s);
			return /* @__PURE__ */ m("div", {
				className: Q.channelStrip,
				role: "group",
				"aria-label": `${o} channel ${f}: ${l}`,
				"data-plugged": d,
				"data-silent": !Ye(e, s, n),
				children: [
					/* @__PURE__ */ m("div", {
						className: Q.scribble,
						title: u || void 0,
						children: [/* @__PURE__ */ p("span", {
							className: Q.channelSource,
							"data-source-name": !0,
							children: l
						}), /* @__PURE__ */ p("b", { children: f })]
					}),
					/* @__PURE__ */ p(wn, {
						param: Hr(h),
						prefix: o,
						value: e.params[h],
						format: Wr,
						caption: "PAN",
						onChange: (e) => i({ [h]: e })
					}),
					/* @__PURE__ */ p(sr, {
						mixKey: He(e.id, s),
						label: `${o} channel ${f}`,
						mix: n,
						onToggle: a
					}),
					/* @__PURE__ */ p(Kr, {
						param: Hr(s),
						prefix: o,
						value: e.params[s],
						onChange: (e) => i({ [s]: e }),
						children: /* @__PURE__ */ p(Gr, {
							level: r.channels[c],
							label: `${o} channel ${f} level`
						})
					})
				]
			}, s);
		}), /* @__PURE__ */ m("div", {
			className: Q.mixBus,
			role: "group",
			"aria-label": `${o} mix bus`,
			children: [/* @__PURE__ */ m("div", {
				className: Q.scribble,
				children: [/* @__PURE__ */ p("span", {
					className: Q.channelSource,
					children: "MIX BUS"
				}), /* @__PURE__ */ p("b", { children: "L · R" })]
			}), /* @__PURE__ */ m(Kr, {
				param: Hr("master"),
				prefix: o,
				value: e.params.master,
				onChange: (e) => i({ master: e }),
				children: [/* @__PURE__ */ p(Gr, {
					level: r.bus[0],
					label: `${o} mix bus left level`
				}), /* @__PURE__ */ p(Gr, {
					level: r.bus[1],
					label: `${o} mix bus right level`
				})]
			})]
		})]
	});
}
//#endregion
//#region src/components/TempoInput.tsx
var Jr = 40, Yr = 240;
function Xr({ bpm: e, onChange: t }) {
	let [n, r] = u(String(e)), o = a();
	return i(() => {
		r(String(e));
	}, [e]), /* @__PURE__ */ m("div", {
		className: Q.numberField,
		children: [
			/* @__PURE__ */ p("label", {
				htmlFor: o,
				children: "BPM"
			}),
			/* @__PURE__ */ p("input", {
				id: o,
				"aria-label": "Tempo",
				type: "number",
				min: Jr,
				max: Yr,
				step: 1,
				value: n,
				onChange: (e) => {
					r(e.target.value);
					let n = Number(e.target.value);
					n >= Jr && n <= Yr && t(n);
				},
				onBlur: () => {
					let i = n === "" ? e : Math.max(Jr, Math.min(Yr, Number(n)));
					r(String(i)), t(i);
				}
			}),
			/* @__PURE__ */ p("input", {
				className: Q.tempoSlider,
				type: "range",
				min: Jr,
				max: Yr,
				step: 1,
				value: e,
				"aria-label": "Tempo slider",
				"aria-valuetext": `${e} BPM`,
				onChange: (e) => t(Number(e.target.value))
			})
		]
	});
}
//#endregion
//#region src/components/Presets.tsx
var Zr = (e) => new Date(e).toLocaleString(void 0, {
	dateStyle: "medium",
	timeStyle: "short"
});
function Qr({ presets: e, openId: t, dirty: n, onLoad: r, onLoadFactory: a, onExport: o, onDelete: s, onSaveAs: c, onImport: d, onExportCurrent: h, onClose: g }) {
	let [_, v] = u(null), y = l(null), b = l(null);
	return i(() => {
		_ && y.current?.focus();
	}, [_]), /* @__PURE__ */ m("div", {
		ref: b,
		tabIndex: -1,
		className: `${Q.library} ${Q.presetBrowser}`,
		role: "region",
		"aria-label": "Presets",
		children: [
			/* @__PURE__ */ m("div", {
				className: Q.libraryHeading,
				children: [/* @__PURE__ */ p("strong", { children: "PRESETS" }), /* @__PURE__ */ m("span", {
					className: Q.presetActions,
					children: [
						/* @__PURE__ */ p("button", {
							onClick: (e) => c(e.currentTarget),
							title: "Save a copy under a new name (⇧⌘S / Ctrl+Shift+S)",
							children: "Save as…"
						}),
						/* @__PURE__ */ p("button", {
							onClick: d,
							title: "Add a .json patch file to My Presets",
							children: "↑ Import file…"
						}),
						/* @__PURE__ */ p("button", {
							onClick: h,
							title: "Download the rack as a .json patch file",
							children: "↓ Export file"
						}),
						/* @__PURE__ */ p("button", {
							"aria-label": "Close presets",
							onClick: g,
							children: "×"
						})
					]
				})]
			}),
			/* @__PURE__ */ p("strong", {
				className: Q.sectionLabel,
				children: "MY PRESETS · SAVED IN THIS BROWSER"
			}),
			e.length ? /* @__PURE__ */ p("ul", {
				className: Q.presetList,
				"aria-label": "My presets",
				children: e.map((e) => {
					let { id: i, patch: { name: a } } = e, c = i === t;
					return /* @__PURE__ */ p("li", {
						className: Q.presetRow,
						"data-open": c,
						children: _ === i ? /* @__PURE__ */ m(f, { children: [
							/* @__PURE__ */ m("span", {
								className: Q.presetConfirm,
								children: [
									"Delete “",
									a,
									"”? This can’t be undone."
								]
							}),
							/* @__PURE__ */ p("button", {
								className: Q.dangerButton,
								"aria-label": `Confirm delete ${a}`,
								onClick: () => {
									v(null), s(e), b.current?.focus();
								},
								children: "Delete"
							}),
							/* @__PURE__ */ p("button", {
								ref: y,
								"aria-label": `Keep ${a}`,
								onClick: () => v(null),
								children: "Keep"
							})
						] }) : /* @__PURE__ */ m(f, { children: [
							/* @__PURE__ */ m("button", {
								className: Q.presetLoad,
								"aria-label": `Load ${a}`,
								"aria-current": c || void 0,
								onClick: () => r(e),
								children: [/* @__PURE__ */ p("strong", { children: a }), /* @__PURE__ */ p("small", { children: c ? n ? "OPEN · UNSAVED CHANGES" : "OPEN" : `Saved ${Zr(e.savedAt)}` })]
							}),
							/* @__PURE__ */ p("button", {
								"aria-label": `Export ${a}`,
								title: `Download ${a} as a .json patch file`,
								onClick: () => o(e.patch),
								children: "↓ Export"
							}),
							/* @__PURE__ */ p("button", {
								"aria-label": `Delete ${a}`,
								title: `Delete ${a} from this browser`,
								onClick: () => v(i),
								children: "Delete"
							})
						] })
					}, i);
				})
			}) : /* @__PURE__ */ p("p", {
				className: Q.presetEmpty,
				children: "Nothing saved yet. Save keeps your rack here under its name; Import file adds a patch you exported."
			}),
			/* @__PURE__ */ p("strong", {
				className: Q.sectionLabel,
				children: "FACTORY"
			}),
			/* @__PURE__ */ p("div", {
				className: Q.factoryGrid,
				role: "group",
				"aria-label": "Factory presets",
				children: ot.map((e) => /* @__PURE__ */ p("button", {
					title: e,
					onClick: () => a(e),
					children: e
				}, e))
			})
		]
	});
}
function $r({ initialName: e, presets: t, onSave: n, onCancel: r }) {
	let [o, s] = u(e), c = l(null), d = a(), f = a(), h = kt(t, o), g = !o.trim();
	i(() => {
		c.current?.select();
	}, []);
	function _(e) {
		if (e.key === "Escape") {
			e.preventDefault(), r();
			return;
		}
		if (e.key !== "Tab") return;
		let t = [...e.currentTarget.querySelectorAll("input, button:not(:disabled)")], n = t[0], i = t.at(-1);
		e.shiftKey && document.activeElement === n ? (e.preventDefault(), i?.focus()) : !e.shiftKey && document.activeElement === i && (e.preventDefault(), n?.focus());
	}
	return /* @__PURE__ */ p("div", {
		className: Q.helpBackdrop,
		children: /* @__PURE__ */ p("div", {
			className: Q.saveDialog,
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": d,
			"aria-describedby": f,
			onKeyDown: _,
			children: /* @__PURE__ */ m("form", {
				onSubmit: (e) => {
					e.preventDefault(), g || n(o);
				},
				children: [
					/* @__PURE__ */ p("strong", {
						id: d,
						className: Q.saveTitle,
						children: "Save preset"
					}),
					/* @__PURE__ */ m("label", { children: ["Name", /* @__PURE__ */ p("input", {
						ref: c,
						autoFocus: !0,
						"aria-label": "Preset name",
						maxLength: 100,
						value: o,
						onChange: (e) => s(e.target.value)
					})] }),
					h && /* @__PURE__ */ m("p", {
						className: Q.saveWarning,
						role: "status",
						children: [
							"“",
							h.patch.name,
							"” is already in My Presets. Saving replaces it."
						]
					}),
					/* @__PURE__ */ p("p", {
						id: f,
						className: Q.saveNote,
						children: "Saved in this browser. Export a file to back it up or move it to another browser."
					}),
					/* @__PURE__ */ m("div", {
						className: Q.saveButtons,
						children: [/* @__PURE__ */ p("button", {
							type: "button",
							onClick: r,
							children: "Cancel"
						}), /* @__PURE__ */ p("button", {
							type: "submit",
							className: Q.saveButton,
							disabled: g,
							children: h ? "Replace" : "Save"
						})]
					})
				]
			})
		})
	});
}
//#endregion
//#region src/components/Live.tsx
function ei() {
	let e = {
		pulsing: /* @__PURE__ */ new Set(),
		meter: 0,
		reductions: {},
		mixerLevels: {}
	}, t = /* @__PURE__ */ new Set();
	return {
		get: () => e,
		set(n) {
			if (!Object.keys(n).every((t) => n[t] === e[t])) {
				e = {
					...e,
					...n
				};
				for (let e of t) e();
			}
		},
		subscribe(e) {
			return t.add(e), () => {
				t.delete(e);
			};
		}
	};
}
var ti = t(null);
function ni({ select: e, children: t }) {
	let n = r(ti), i = () => e(n.get());
	return /* @__PURE__ */ p(f, { children: t(d(n.subscribe, i, i)) });
}
//#endregion
//#region ../../../../../rackloose.svg?inline
var ri = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2064%2064'%3e%3crect%20x='5'%20y='6'%20width='54'%20height='52'%20rx='3'%20fill='%23303337'%20stroke='%23101214'%20stroke-width='2'/%3e%3cpath%20d='M10%2010v44M54%2010v44'%20stroke='%23777'%20stroke-width='3'/%3e%3crect%20x='14'%20y='12'%20width='36'%20height='17'%20fill='%23b9503a'%20stroke='%23111'/%3e%3crect%20x='14'%20y='31'%20width='36'%20height='20'%20fill='%23a0ac9b'%20stroke='%23111'/%3e%3cg%20fill='%23232626'%20stroke='%23dfdfca'%3e%3ccircle%20cx='23'%20cy='21'%20r='5'/%3e%3ccircle%20cx='41'%20cy='21'%20r='5'/%3e%3c/g%3e%3cpath%20d='M23%2021v-4m18%204%203-3'%20stroke='%23fff'%20stroke-width='2'/%3e%3cg%20fill='%231b2221'%20stroke='%23555'%3e%3ccircle%20cx='22'%20cy='39'%20r='3'/%3e%3ccircle%20cx='42'%20cy='44'%20r='3'/%3e%3c/g%3e%3cpath%20d='M22%2039c-6%2020%2027%2020%2020%205'%20fill='none'%20stroke='%23f4bb50'%20stroke-width='3'/%3e%3cpath%20d='M7%208h50'%20stroke='%23a9abad'/%3e%3c/svg%3e", ii = {
	channels: Array(8).fill(-60),
	bus: [-60, -60]
}, ai = [
	"a",
	"w",
	"s",
	"e",
	"d",
	"f",
	"t",
	"g",
	"y",
	"h",
	"u",
	"j",
	"k"
], oi = [
	"a",
	"s",
	"d",
	"f",
	"g",
	"h",
	"j",
	"k",
	"l",
	";",
	"'",
	"z",
	"x",
	"c",
	"v",
	"b"
], si = /* @__PURE__ */ new Set([
	1,
	3,
	6,
	8,
	10
]), ci = "input:not([type]), input[type=\"text\"], input[type=\"search\"], textarea, [contenteditable=\"true\"]", li = 30, ui = 40, di = {
	id: "depth",
	label: "Depth",
	min: -1,
	max: 1,
	step: .01,
	initial: 1
}, fi = (e) => `${Math.round(e * 100)}%`, pi = {
	oscillator: "1V / OCT",
	filter: "CV CONTROL",
	delay: "WARM REPEATS",
	boom: "LONG LOW END",
	punch: "FOUR ON THE FLOOR"
};
function mi(e, t, n) {
	let r = URL.createObjectURL(new Blob([e], { type: t })), i = document.createElement("a");
	i.href = r, i.download = n, i.click(), setTimeout(() => URL.revokeObjectURL(r), 1e3);
}
var hi = (e) => {
	let [t, n] = e.dataset.portKey.split(":");
	return {
		moduleId: t,
		portId: n
	};
}, gi = (e, t) => e === t || !!e && !!t && R(e, t), _i = (e, t) => e.error === t.error && e.inside === t.inside && e.cableId === t.cableId && R(e.anchor, t.anchor) && e.point.x === t.point.x && e.point.y === t.point.y && gi(e.target, t.target), vi = (e, t) => R(e.from, t) ? e.to : e.from, yi = (e, t) => ({
	...e,
	cables: e.cables.filter((e) => e.id !== t)
});
function bi(e) {
	try {
		return localStorage.getItem(e);
	} catch {
		return null;
	}
}
function xi({ key: e, patch: t, open: n }) {
	let r = pt(localStorage, e, t);
	return r || (n ? localStorage.setItem(`${e}:open`, n) : localStorage.removeItem(`${e}:open`)), r;
}
function Si({ keysEnabled: e = !0, suspended: t = !1, storageKey: r = "rackloose.patch.v1", linkBrand: o = !0 }) {
	let [d, h] = u(() => ct()), g = l(d), _ = l(null), v = l(null), y = l(null), b = l(null), x = l(null), S = l(null), [C, w] = u(!1), [T, E] = u(!1), [D, ee] = u(!1), [te, ne] = u(!1), [re, O] = u(null), [k, A] = u("Loading patch…"), [j, M] = c((e, t) => ({
		text: t,
		serial: e.serial + 1
	}), {
		text: "Ready when you are. Enable audio, then play a key or start the pattern.",
		serial: 0
	}), N = j.text, [P, ie] = u(!0), [ae, oe] = u(!1), [se, ce] = u(!1), [F, le] = u(!1), [ue, de] = u(-1), [fe, pe] = u([]), [me, ge] = u(48e3), [ve] = u(ei), [Te, Ee] = u(3), [De, ke] = u(null), [Me, Ne] = u(!0), [Pe, z] = u(null), [Fe, B] = u(null), [Re, He] = u(null), [We, Ke] = u(null), [Je, Ye] = u(null), [Ze, tt] = u(4), [it, at] = u(!1), [V, ot] = u(Ve), [st, pt] = u("performance"), H = l("performance"), [mt, gt] = u(/* @__PURE__ */ new Set()), _t = l(/* @__PURE__ */ new Map()), vt = l(/* @__PURE__ */ new Set()), [wt, Tt] = u({}), [U, W] = u(null), [Mt, Nt] = u(null), [Pt, G] = u({
		undo: 0,
		redo: 0
	}), Ft = l(Ve), It = l(!1), Lt = l(3), Rt = l(yt()), zt = l(null), [Bt, Vt] = u([]), [Ht, Ut] = u({}), [Wt, Gt] = u(""), Kt = l(""), [qt, Jt] = u(null), Yt = l(null), Xt = l(null), Zt = l(null), K = l(0), Qt = l(!1), $t = l(null), en = l(0), tn = a(), nn = a(), rn = a(), an = `${r}:baseline`, on = `${r}:presets`, sn = Bt.find((e) => e.id === Ht[Wt]) ?? null, cn = sn?.id ?? null, ln = s(() => ut(d), [d]), un = s(() => sn ? ut(sn.patch) : Mt, [sn, Mt]), dn = un !== null && ln !== un;
	i(() => {
		g.current = d, _.current?.update(d);
	}, [d]), i(() => {
		let e = new bn(g.current, (e) => M(e.message));
		_.current = e;
		let n = 0, r = 0;
		function i(t) {
			let a = ve.get(), o = g.current.modules.filter((t) => Ge(t.type) && e.pulsing(t.id)).map((e) => e.id);
			if (ve.set({ pulsing: o.length === a.pulsing.size && o.every((e) => a.pulsing.has(e)) ? a.pulsing : new Set(o) }), t - r > 40) {
				ge(e.sampleRate), de(e.clock), oe(e.playing), ce(e.ready), pe((t) => {
					let n = e.activeNotes;
					return n.length === t.length && n.every((e, n) => e === t[n]) ? t : n;
				}), Tt((t) => {
					let n = Object.fromEntries(g.current.modules.filter((e) => Le(e.type)).map((t) => [t.id, {
						playing: e.modulePlaying(t.id),
						clock: e.moduleClock(t.id)
					}]));
					return JSON.stringify(n) === JSON.stringify(t) ? t : n;
				});
				let n = Object.fromEntries(g.current.modules.filter((e) => [
					"compressor",
					"cohere",
					"talon"
				].includes(e.type)).map((t) => [t.id, Math.round(e.reduction(t.id) * 2) / 2])), i = Object.fromEntries(g.current.modules.filter((e) => e.type === "mixer").map((t) => {
					let { channels: n, bus: r } = e.mixerLevels(t.id), i = {
						channels: n.map(Math.round),
						bus: r.map(Math.round)
					}, o = a.mixerLevels[t.id];
					return [t.id, o && JSON.stringify(o) === JSON.stringify(i) ? o : i];
				}));
				ve.set({
					meter: e.meter,
					reductions: JSON.stringify(n) === JSON.stringify(a.reductions) ? a.reductions : n,
					mixerLevels: Object.keys(i).length === Object.keys(a.mixerLevels).length && Object.entries(i).every(([e, t]) => a.mixerLevels[e] === t) ? a.mixerLevels : i
				}), r = t;
			}
			n = requestAnimationFrame(i);
		}
		n = requestAnimationFrame(i);
		let a = () => {
			document.hidden ? e.setSuspended(!0) : e.setSuspended(t);
		};
		document.addEventListener("visibilitychange", a);
		let o = v.current, s = (t) => e.lifted(`pointer-${t.pointerId}`), c = () => e.lifted();
		return o?.addEventListener("pointerup", s, !0), o?.addEventListener("touchend", c, !0), () => {
			cancelAnimationFrame(n), document.removeEventListener("visibilitychange", a), o?.removeEventListener("pointerup", s, !0), o?.removeEventListener("touchend", c, !0), e.dispose(), _.current = null;
		};
	}, [t, ve]), i(() => {
		_.current?.setSuspended(t);
	}, [t]), i(() => {
		ie(!0);
		let e = setTimeout(() => ie(!1), Math.min(9e3, 3500 + j.text.length * 40));
		return () => clearTimeout(e);
	}, [j]), i(() => {
		_.current?.setMute(F);
	}, [F, t]), i(() => {
		_.current?.setMix(V);
	}, [V, t]);
	let fn = n((e) => {
		g.current = e.patch, Ft.current = e.mix, It.current = e.mainMuted, Lt.current = e.octave, Kt.current = e.session, h(e.patch), ot(e.mix), le(e.mainMuted), Ee(e.octave), Gt(e.session);
	}, []), pn = n(() => {
		Rt.current = yt(), G({
			undo: 0,
			redo: 0
		});
	}, []), mn = n((e, t = null) => {
		let n = {
			patch: g.current,
			mix: Ft.current,
			mainMuted: It.current,
			octave: Lt.current,
			session: Kt.current
		}, r = {
			...n,
			...typeof e == "function" ? e(n) : e
		};
		(r.patch !== n.patch || r.mix !== n.mix || r.mainMuted !== n.mainMuted || r.octave !== n.octave || r.session !== n.session) && (Rt.current = bt(Rt.current, n, t, Date.now()), G({
			undo: Rt.current.past.length,
			redo: 0
		}), fn(r));
	}, [fn]), q = n((e, t = null) => mn((t) => ({ patch: e(t.patch) }), t), [mn]), J = n((e, t) => {
		let n = g.current.modules.find((t) => t.id === e), r = Object.keys(t);
		if (!n || r.every((e) => n.params[e] === t[e])) return;
		let i = r.length === 1 ? I[n.type].params.find((e) => e.id === r[0]) : void 0;
		q((n) => ({
			...n,
			modules: n.modules.map((n) => n.id === e ? {
				...n,
				params: {
					...n.params,
					...t
				}
			} : n)
		}), i && !i.choices && !i.pattern ? `param:${e}:${i.id}` : null);
	}, [q]), hn = n((e, t) => mn((n) => ({ mix: et(n.mix, e, t) })), [mn]), gn = n((e) => {
		let t = ut(e);
		Nt(t);
		try {
			localStorage.setItem(an, t);
		} catch {}
	}, [an]);
	i(() => {
		let e, t = {
			presets: [],
			error: null
		}, n = null;
		try {
			zt.current && zt.current.key !== r && xi(zt.current), e = ft(localStorage, r), t = Et(localStorage, `${r}:presets`), n = localStorage.getItem(`${r}:open`);
		} catch {
			e = {
				patch: null,
				error: "Local save unavailable. Export a patch file to keep your work."
			};
		}
		(e.error ?? t.error) && M(e.error ?? t.error);
		let i = e.patch ?? ct(), a = e.patch ? bi(`${r}:baseline`) : null;
		_.current?.panic(), H.current = i.modules[0].id, pt(H.current);
		let o = _e("session");
		Vt(t.presets), Ut(n && t.presets.some((e) => e.id === n) ? { [o]: n } : {}), Jt(null), fn({
			patch: i,
			mix: Ve,
			mainMuted: !1,
			octave: Lt.current,
			session: o
		}), pn();
		let s = a ?? ut(i);
		if (a === null) try {
			localStorage.setItem(`${r}:baseline`, s);
		} catch {}
		Nt(s), A(e.error ?? (e.patch ? "Patch restored" : "Saved locally")), O(r);
	}, [
		r,
		fn,
		pn
	]), i(() => {
		if (re !== r) return;
		let e = zt.current = {
			key: r,
			patch: d,
			open: cn
		}, t = setTimeout(() => {
			try {
				A(xi(e) ?? "Saved locally");
			} catch {
				A("Local save unavailable. Export a patch file to keep your work.");
			}
		}, 400);
		return () => clearTimeout(t);
	}, [
		d,
		cn,
		re,
		r
	]), i(() => {
		let e = (e) => {
			if (e.key === on || e.key === null) try {
				Vt(Et(localStorage, on).presets);
			} catch {}
		};
		return window.addEventListener("storage", e), () => window.removeEventListener("storage", e);
	}, [on]), i(() => {
		let e = () => {
			if (zt.current) try {
				xi(zt.current);
			} catch {}
		};
		return window.addEventListener("pagehide", e), () => {
			window.removeEventListener("pagehide", e), e();
		};
	}, []), i(() => () => {
		cancelAnimationFrame(K.current), cancelAnimationFrame(en.current);
	}, []);
	let Y = n((e) => M(e instanceof Error ? e.message : "Audio could not start. Try enabling it again."), []), X = n((e, t = !1) => {
		(!t || vt.current.has(e)) && (vt.current.delete(e), t ? _.current?.cancel(e) : _.current?.release(e), _t.current.delete(e) && gt(new Set(_t.current.values())));
	}, []), Z = n(() => {
		_.current?.releaseManual(), vt.current.clear(), _t.current.clear(), gt(/* @__PURE__ */ new Set());
	}, []), _n = n((e, n, r = !1) => {
		if (t) return;
		let i = g.current, a = i.modules.find((e) => e.id === H.current) ?? i.modules[0], o = I[a.type];
		if (ze(i, a.id) || M(`${o.name} has no audio path to MAIN. Flip the rack to connect it.`), o.drum) {
			let t = o.drum.voices[n];
			if (!t || _t.current.has(e)) return;
			_t.current.set(e, t.id), gt(new Set(_t.current.values())), _.current?.hit(a.id, t.id, e, r).catch(Y);
		} else a.type === "noise" && (_t.current.set(e, "noise"), gt(new Set(_t.current.values()))), _.current?.press(e, a.type === "noise" ? 60 : (Te + 1) * 12 + n, a.id, r).catch(Y);
	}, [
		Y,
		t,
		Te
	]), vn = n((e, n) => {
		t || _.current?.hit(e, n).catch(Y);
	}, [Y, t]), yn = n(() => {
		_.current?.playing ? _.current.pause() : _.current?.play().catch(Y);
	}, [Y]), Cn = n((e) => {
		Ie(e.type) && H.current !== e.id && (Z(), H.current = e.id, pt(e.id));
	}, [Z]);
	i(() => {
		if (!e || t || D || qt !== null) {
			Z();
			return;
		}
		function n(e) {
			if (e.defaultPrevented || e.metaKey || e.ctrlKey || e.altKey || e.target instanceof Element && e.target.closest("input, select, textarea, [contenteditable=\"true\"]")) return;
			let t = g.current.modules.find((e) => e.id === H.current), n = t && (I[t.type].drum?.voices.length ?? +(t.type === "noise")), r = (n ? oi.slice(0, n) : ai).indexOf(e.key.toLowerCase());
			r >= 0 && (e.preventDefault(), e.repeat || _n(`key-${e.code}`, r));
		}
		let r = (e) => X(`key-${e.code}`);
		return window.addEventListener("keydown", n), window.addEventListener("keyup", r), window.addEventListener("blur", Z), () => {
			window.removeEventListener("keydown", n), window.removeEventListener("keyup", r), window.removeEventListener("blur", Z), Z();
		};
	}, [
		e,
		t,
		_n,
		X,
		yn,
		D,
		qt,
		Z
	]), i(() => {
		if (!e || t || D || qt !== null) return;
		let n = (e) => {
			if (e.code !== "Space" || e.metaKey || e.ctrlKey || e.altKey) return;
			let t = e.target instanceof Element ? e.target : null;
			t?.closest(ci) || (v.current?.contains(t) || !e.defaultPrevented && !t?.closest("button, [role=\"button\"], [role=\"slider\"], input, select, [contenteditable=\"true\"]")) && (e.preventDefault(), e.stopPropagation(), e.type === "keydown" && !e.repeat && yn());
		};
		return window.addEventListener("keydown", n, !0), window.addEventListener("keyup", n, !0), () => {
			window.removeEventListener("keydown", n, !0), window.removeEventListener("keyup", n, !0);
		};
	}, [
		e,
		t,
		D,
		qt,
		yn
	]), i(() => {
		if (!Je) return;
		let e = y.current, t = e?.querySelector(`[data-module-id="${Je}"]`);
		if (e && t) {
			let n = t.offsetTop - 6, r = t.offsetTop + t.offsetHeight + 6, i = matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth";
			n < e.scrollTop || r - n > e.clientHeight ? e.scrollTo({
				top: n,
				behavior: i
			}) : r > e.scrollTop + e.clientHeight && e.scrollTo({
				top: r - e.clientHeight,
				behavior: i
			});
		}
		let n = setTimeout(() => Ye(null), 1400);
		return () => clearTimeout(n);
	}, [Je]);
	let $ = n(() => {
		Zt.current = null, cancelAnimationFrame(K.current), K.current = 0, He(null);
	}, []), Tn = n(() => {
		let e = Zt.current;
		return !e?.moved || e.cancelled ? !1 : (e.cancelled = !0, cancelAnimationFrame(K.current), K.current = 0, He(null), !0);
	}, []), En = n((e) => {
		let t = (e === "undo" ? xt : St)(Rt.current, {
			patch: g.current,
			mix: Ft.current,
			mainMuted: It.current,
			octave: Lt.current,
			session: Kt.current
		});
		if (!t) return;
		Rt.current = t.history, G({
			undo: t.history.past.length,
			redo: t.history.future.length
		}), Zt.current && (Qt.current = !0), $(), B(null), W(null), z((e) => e && t.state.patch.cables.some((t) => t.id === e) ? e : null), t.state.patch.modules.some((e) => e.id === H.current) || (Z(), H.current = t.state.patch.modules[0].id, pt(H.current)), fn(t.state);
		let n = e === "undo" ? t.history.past.length : t.history.future.length;
		M(`${e === "undo" ? "Undone" : "Redone"}. ${n} more ${n === 1 ? "step" : "steps"} to ${e}.`);
	}, [
		fn,
		Z,
		$
	]);
	i(() => {
		let t = (t) => {
			if (!(t.key !== "Escape" || t.defaultPrevented)) {
				if (Tn()) {
					t.preventDefault(), M("Drag cancelled. Your cables are unchanged.");
					return;
				}
				(Fe || U || Pe) && (e || v.current?.contains(t.target)) && (t.preventDefault(), B(null), W(null), z(null), M(U ? "Plug back in its jack." : "Patching cancelled."));
			}
		}, n = () => Tn();
		return window.addEventListener("keydown", t, !0), window.addEventListener("blur", n), () => {
			window.removeEventListener("keydown", t, !0), window.removeEventListener("blur", n);
		};
	}, [
		Fe,
		U,
		Pe,
		e,
		Tn
	]), i(() => {
		if (!Pe) return;
		let t = (t) => {
			if (t.key !== "Delete" && t.key !== "Backspace" || t.defaultPrevented || t.metaKey || t.ctrlKey || t.altKey) return;
			let n = t.target instanceof Element ? t.target : null;
			n?.closest("input, select, textarea, [contenteditable=\"true\"]") || !e && !v.current?.contains(n) || (t.preventDefault(), q((e) => yi(e, Pe)), z(null), B(null), W(null), M("Cable removed. Undo puts it back."));
		};
		return window.addEventListener("keydown", t, !0), () => window.removeEventListener("keydown", t, !0);
	}, [
		Pe,
		e,
		q
	]), i(() => {
		let n = (n) => {
			if (n.defaultPrevented || n.altKey || !(n.metaKey || n.ctrlKey) || D || qt !== null) return;
			let r = n.key.toLowerCase(), i = r === "z" && !n.shiftKey, a = r === "z" && n.shiftKey || r === "y" && n.ctrlKey && !n.shiftKey;
			if (!i && !a) return;
			let o = n.target instanceof Element ? n.target : null;
			(v.current?.contains(o) || e && !t && !o?.closest("input, select, textarea, [contenteditable=\"true\"]")) && (n.preventDefault(), En(i ? "undo" : "redo"));
		};
		return window.addEventListener("keydown", n, !0), () => window.removeEventListener("keydown", n, !0);
	}, [
		e,
		t,
		D,
		qt,
		En
	]);
	let On = n((e) => {
		try {
			let t = e(Et(localStorage, on).presets);
			if (t.length > 200) return "My Presets holds up to 200 presets. Delete or export some first.";
			let n = Dt(localStorage, on, t);
			return n || Vt(t), n;
		} catch {
			return Ct;
		}
	}, [on]), kn = n((e, t) => {
		let n = On((n) => Ot(n, {
			id: e,
			savedAt: Date.now(),
			patch: t
		}));
		if (n) {
			M(n);
			return;
		}
		let r = Kt.current;
		Ut((t) => ({
			...t,
			[r]: e
		})), gn(t), M(`Saved “${t.name}” in this browser.`);
	}, [On, gn]), An = n((e) => {
		Xt.current = e ?? (document.activeElement instanceof HTMLElement ? document.activeElement : null), Jt(g.current.name);
	}, []), jn = n((e) => {
		let t = g.current;
		!sn || !t.name.trim() || kt(Bt, t.name, sn.id) ? An(e) : kn(sn.id, t);
	}, [
		sn,
		Bt,
		An,
		kn
	]);
	i(() => {
		let n = (n) => {
			if (n.defaultPrevented || n.altKey || !(n.metaKey || n.ctrlKey) || n.key.toLowerCase() !== "s") return;
			let r = n.target instanceof Element ? n.target : null, i = !!v.current?.contains(r);
			if (D || qt !== null) {
				i && n.preventDefault();
				return;
			}
			(i || e && !t && !r?.closest("input, select, textarea, [contenteditable=\"true\"]")) && (n.preventDefault(), n.shiftKey ? An() : jn());
		};
		return window.addEventListener("keydown", n, !0), () => window.removeEventListener("keydown", n, !0);
	}, [
		e,
		t,
		D,
		qt,
		jn,
		An
	]);
	function Mn(e, t, n, r = null) {
		q((r) => {
			let i = xe(r, e), a = i[t];
			return !a || Object.keys(n).every((e) => a[e] === n[e]) ? r : Se(r, e, i.map((e, r) => r === t ? {
				...e,
				...n
			} : e));
		}, r && `${r}:${e}`);
	}
	function Nn(e, t) {
		q((n) => n.sequencer[e] === t ? n : {
			...n,
			sequencer: {
				...n.sequencer,
				[e]: t
			}
		}, e);
	}
	function Pn(e, t) {
		q((n) => n.cables.some((n) => n.id === e && n.amount !== t) ? {
			...n,
			cables: n.cables.map((n) => n.id === e ? {
				...n,
				amount: t
			} : n)
		} : n, `depth:${e}`);
	}
	function Fn(e, t, n = null) {
		$(), W(null), _.current?.panic(), Z();
		let r = _e("session");
		n && Ut((e) => ({
			...e,
			[r]: n
		})), mn({
			patch: e,
			mix: Ve,
			mainMuted: !1,
			session: r
		}), gn(e), ne(!1), H.current = e.modules[0].id, pt(H.current), ke(null), z(null), B(null), M(dn ? `${t} Undo brings back your unsaved changes.` : t);
	}
	function In() {
		Jt(null);
		let e = Xt.current;
		Xt.current = null, e?.isConnected && e.focus();
	}
	function Ln(e) {
		e !== g.current.name && q((t) => ({
			...t,
			name: e
		})), kn(kt(Bt, e)?.id ?? _e("preset"), g.current), In();
	}
	function Rn(e) {
		let t = On((t) => t.filter((t) => t.id !== e.id));
		M(t ?? `Deleted “${e.patch.name}” from this browser.${e.id === cn ? " The rack still has it; Save adds it back." : ""}`);
	}
	function zn(e) {
		let t = `${jt(e.name)}.rackloose.json`;
		mi(lt(e), "application/json", t), M(`Exported ${t}. Import it in any browser to add it to My Presets.`);
	}
	function Bn(e) {
		let t = ye(e);
		q((e) => ({
			...e,
			modules: [
				...e.modules.slice(0, -1),
				t,
				e.modules.at(-1)
			]
		})), Cn(t), E(!1), Ye(t.id), M(`${I[e].name} added. Flip the rack to connect it.`);
	}
	function Vn(e) {
		let t = {
			...e,
			id: _e(),
			params: { ...e.params }
		};
		q((n) => {
			let r = [...n.modules];
			return r.splice(r.findIndex((t) => t.id === e.id) + 1, 0, t), {
				...n,
				modules: r
			};
		}), Cn(t), Ye(t.id), M(`${I[e.type].name} duplicated without its cables.`);
	}
	function Hn() {
		ee(!1), x.current?.focus();
	}
	function Un(e, t, n = null) {
		try {
			let r = Be(g.current, e, t, n);
			if (B(null), W(null), r === g.current) {
				M("Plug back in its jack.");
				return;
			}
			mn({ patch: r }), M(n ? "Cable moved." : "Connected. Flip to the front to hear your patch.");
		} catch (e) {
			Y(e);
		}
	}
	function Wn(e) {
		q((t) => yi(t, e)), z(null), W(null), M("Cable unplugged. Undo puts it back.");
	}
	function Gn(e) {
		if (Qt.current) {
			Qt.current = !1;
			return;
		}
		let t = we(g.current, e);
		if (U) {
			t?.id === U.cableId && !R(e, U.anchor) ? (W(null), M("Plug back in its jack.")) : Un(U.anchor, e, U.cableId);
			return;
		}
		if (Fe && R(Fe, e)) {
			B(null), M("Patching cancelled.");
			return;
		}
		if (Fe) {
			Un(Fe, e);
			return;
		}
		if (t) {
			W({
				cableId: t.id,
				anchor: vi(t, e)
			}), z(t.id), M("Plug lifted. Choose a free jack, or tap empty rack space to unplug. Tap the jack again or press Escape to put it back.");
			return;
		}
		let n = L(g.current, e);
		n && (B(e), z(null), M(`Choose a free ${n.kind.toUpperCase()} ${n.direction === "out" ? "input" : "output"}. Escape cancels.`));
	}
	function Kn(e) {
		C && !e.target.closest("button, [role=\"button\"], [role=\"slider\"], input, select, label, a") && (U ? Wn(U.cableId) : Fe ? (B(null), M("Patching cancelled.")) : z(null));
	}
	function qn(e) {
		let t = y.current;
		if (!t) return null;
		let n = t.getBoundingClientRect(), r = e.clientX >= n.left && e.clientX <= n.right && e.clientY >= n.top && e.clientY <= n.bottom, i = null, a = li;
		r && t.querySelectorAll("[data-port-key]").forEach((t) => {
			let r = t.getBoundingClientRect(), o = r.left + r.width / 2, s = r.top + r.height / 2, c = e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom ? -1 : Math.hypot(o - e.clientX, s - e.clientY);
			c >= a || s < n.top || s > n.bottom || (i = hi(t), a = c);
		});
		let o = !!i && R(i, e.anchor), s = i && !o ? Oe(g.current, e.anchor, i, e.cableId) : null;
		return {
			anchor: e.anchor,
			cableId: e.cableId,
			target: s || o ? null : i,
			candidate: i,
			error: s,
			inside: r,
			point: {
				x: e.clientX - n.left + t.scrollLeft,
				y: e.clientY - n.top + t.scrollTop
			}
		};
	}
	function Jn() {
		let e = Zt.current, t = y.current;
		if (!e?.moved || e.cancelled || !t) {
			K.current = 0;
			return;
		}
		let n = t.getBoundingClientRect(), r = n.top + ui - e.clientY, i = e.clientY - (n.bottom - ui);
		r > 0 ? t.scrollTop -= Math.ceil(Math.min(r, ui) / 3) : i > 0 && (t.scrollTop += Math.ceil(Math.min(i, ui) / 3));
		let a = qn(e);
		He((e) => e && a && _i(e, a) ? e : a), K.current = requestAnimationFrame(Jn);
	}
	function Yn(e, t) {
		if (!e.isPrimary || e.button !== 0) return;
		e.stopPropagation(), Qt.current = !1;
		let n = we(g.current, t);
		Zt.current = {
			pointerId: e.pointerId,
			anchor: n ? vi(n, t) : t,
			cableId: n?.id ?? null,
			x: e.clientX,
			y: e.clientY,
			clientX: e.clientX,
			clientY: e.clientY,
			moved: !1,
			cancelled: !1
		}, e.currentTarget.setPointerCapture(e.pointerId);
	}
	function Xn(e) {
		let t = Zt.current;
		if (t && t.pointerId === e.pointerId && !t.cancelled) {
			if (t.clientX = e.clientX, t.clientY = e.clientY, !t.moved) {
				if (Math.hypot(e.clientX - t.x, e.clientY - t.y) <= 5) return;
				t.moved = !0, B(null), W(null), z(t.cableId), M(t.cableId ? "Plug pulled out. Drop it on a free jack, or on empty rack space to unplug. Escape puts it back." : "Drop the plug on a free highlighted jack. Escape cancels.");
			}
			K.current ||= requestAnimationFrame(Jn);
		}
	}
	function Zn(e) {
		let t = Zt.current;
		if (!t || t.pointerId !== e.pointerId) return;
		t.clientX = e.clientX, t.clientY = e.clientY, t.moved ||= Math.hypot(t.clientX - t.x, t.clientY - t.y) > 5;
		let n = qn(t);
		$(), (t.moved || t.cancelled) && (Qt.current = !0), t.moved && !t.cancelled && (n?.error ? M(`${n.error}${t.cableId ? " The plug went back in its jack." : ""}`) : n?.target ? (Un(t.anchor, n.target, t.cableId), t.cableId && z(t.cableId)) : t.cableId && n?.inside && !n.candidate ? Wn(t.cableId) : M(t.cableId ? "Plug back in its jack." : "Connection cancelled. Your cables are unchanged."));
	}
	function tr() {
		Zt.current && (Qt.current = !0, $());
	}
	function nr(e) {
		let t = U?.anchor ?? Fe;
		t && !Zt.current && e.pointerType === "mouse" && ($t.current = {
			anchor: t,
			cableId: U?.cableId ?? null,
			clientX: e.clientX,
			clientY: e.clientY
		}, en.current ||= requestAnimationFrame(() => {
			en.current = 0;
			let e = $t.current && qn($t.current);
			Ke((t) => t && e && _i(t, e) ? t : e);
		}));
	}
	async function rr(e) {
		if (e) {
			try {
				if (e.size > 1e6) throw Error("Patch files must be smaller than 1 MB.");
				let t = await e.text(), n = dt(t), r = n.cables.length;
				try {
					let e = JSON.parse(t);
					Array.isArray(e.cables) && (r = e.cables.length);
				} catch {}
				let i = r - n.cables.length, a = i > 0 ? ` ${i} ${i === 1 ? "cable shared a jack" : "cables shared jacks"} with no spare left, so ${i === 1 ? "it was" : "they were"} left out.` : "", o = n.name.trim() ? n.name : "Imported patch", s = kt(Bt, o);
				if (s && ut(s.patch) === ut({
					...n,
					name: s.patch.name
				})) Fn(s.patch, `“${s.patch.name}” is already in My Presets, so it opened.${a}`, s.id);
				else {
					let e = {
						id: _e("preset"),
						savedAt: Date.now(),
						patch: {
							...n,
							name: s ? At(Bt, o) : o
						}
					}, t = On((t) => Ot(t, e));
					Fn(e.patch, t ? `Opened “${e.patch.name}”. ${t}${a}` : `Imported “${e.patch.name}” into My Presets.${s ? ` You already had a different “${s.patch.name}”.` : ""}${a}`, t ? null : e.id);
				}
			} catch (e) {
				Y(e);
			}
			b.current && (b.current.value = "");
		}
	}
	async function ar() {
		at(!0), M("Rendering your patch…");
		try {
			mi(Sn(await xn(d, Ze, V)), "audio/wav", `${jt(d.name)}.wav`), M("WAV exported. Your loop includes a two-second effects tail.");
		} catch (e) {
			Y(e);
		} finally {
			at(!1);
		}
	}
	let lr = d.cables.find((e) => e.id === Pe), dr = U?.anchor ?? Fe, mr = U?.cableId ?? null, gr = Re ?? (C && dr && We && R(We.anchor, dr) && We.cableId === mr ? We : null), _r = Re?.anchor ?? dr, vr = Re ? Re.cableId : mr, yr = gr?.cableId ?? null;
	function br(e, t, n) {
		let r = I[e.type], i = {
			moduleId: e.id,
			portId: t.id
		}, a = !!_r && R(_r, i), o = we(d, i), s = !!o && (o.id !== yr || a), c = t.direction === "in" ? "input" : "output", l = e.type === "mixer" && t.direction === "in" ? $e(d, e.id, t.id) : null, u = l ? `Channel ${t.id.toUpperCase()}: ${l.source}` : t.label;
		return /* @__PURE__ */ p("button", {
			className: Q.socket,
			"data-port-key": `${e.id}:${t.id}`,
			"data-kind": t.kind,
			"data-jack": n ?? void 0,
			"data-connected": s,
			"data-compatible": !!_r && !a && !Oe(d, _r, i, vr),
			"data-pending": a,
			"data-lifted": !!U && o?.id === U.cableId && !a,
			"data-target": !!gr?.target && R(gr.target, i),
			"data-selected-end": !!lr && lr.id !== yr && (R(lr.from, i) || R(lr.to, i)),
			"aria-label": `${r.name} ${u} ${c}${n && n > 1 ? ` ${n}` : ""}`,
			"aria-description": `${t.kind.toUpperCase()} ${c}${l?.tooltip ? ` · ${l.tooltip}` : ""}`,
			title: `${u}${l?.tooltip ? ` · ${l.tooltip}` : ""}${n ? ` · jack ${n}` : ""} · ${t.kind.toUpperCase()}${o ? " · plugged" : ""}`,
			onClick: () => Gn(i),
			onPointerDown: (e) => Yn(e, i),
			onPointerMove: Xn,
			onPointerUp: Zn,
			onPointerCancel: tr,
			onLostPointerCapture: tr,
			children: /* @__PURE__ */ p("span", {})
		}, t.id);
	}
	function xr(e) {
		let t = I[e.type];
		return /* @__PURE__ */ p("div", {
			className: Q.portGroups,
			children: ["in", "out"].filter((e) => t.ports.some((t) => t.direction === e)).map((n) => {
				let r = t.ports.filter((e) => e.direction === n);
				return /* @__PURE__ */ m("div", {
					className: Q.portGroup,
					"data-direction": n,
					children: [/* @__PURE__ */ p("span", {
						className: Q.portHeading,
						children: n === "in" ? "INPUTS" : "OUTPUTS"
					}), /* @__PURE__ */ p("div", {
						className: Q.portRow,
						children: r.filter((e) => !e.copyOf).map((i) => {
							let a = r.filter((e) => e === i || e.copyOf === i.id), o = n === "in" && i.kind === "cv", s = o ? d.cables.find((t) => R(t.to, {
								moduleId: e.id,
								portId: i.id
							})) : void 0, c = e.type === "mixer" && n === "in" ? $e(d, e.id, i.id) : null;
							return /* @__PURE__ */ m("div", {
								className: Q.socketControl,
								"data-source": !!c,
								"data-trim": o,
								"data-jacks": a.length,
								children: [
									a.length > 1 ? /* @__PURE__ */ p("div", {
										className: Q.jacks,
										children: a.map((n) => br(e, n, Ce(t.ports, n)))
									}) : br(e, i, null),
									o && /* @__PURE__ */ p(wn, {
										trim: !0,
										param: di,
										value: s?.amount ?? di.initial,
										format: fi,
										prefix: `${t.name} ${i.label}`,
										disabled: !s,
										onChange: (e) => {
											s && Pn(s.id, e);
										}
									}),
									/* @__PURE__ */ p("span", {
										title: c?.tooltip || void 0,
										children: c?.source ?? i.label
									}),
									(n !== "in" || i.kind !== "audio") && /* @__PURE__ */ m("small", { children: [i.kind.toUpperCase(), s && ` · ${fi(s.amount)}`] })
								]
							}, i.id);
						})
					})]
				}, n);
			})
		});
	}
	function Sr(e, t, n) {
		return t.choices ? /* @__PURE__ */ m("label", {
			className: Q.selectControl,
			children: [
				/* @__PURE__ */ p("span", {
					className: Q.controlLabel,
					children: t.label
				}),
				/* @__PURE__ */ p("select", {
					"aria-label": `${n} ${t.label}`,
					value: e.params[t.id],
					onChange: (n) => J(e.id, { [t.id]: Number(n.target.value) }),
					children: t.choices.map((e, t) => /* @__PURE__ */ p("option", {
						value: t,
						children: e
					}, e))
				}),
				/* @__PURE__ */ p(Qn, {
					param: t,
					value: e.params[t.id]
				})
			]
		}, t.id) : /* @__PURE__ */ p(wn, {
			param: t,
			prefix: n,
			value: e.params[t.id],
			onChange: (n) => J(e.id, { [t.id]: n })
		}, t.id);
	}
	function Cr(e) {
		let t = I[e.type], n = [...new Set(t.params.filter((e) => e.group && !e.voice).map((e) => e.group))];
		return n.length ? /* @__PURE__ */ p("div", {
			className: Q.groupControls,
			"data-type": e.type,
			children: n.map((n) => /* @__PURE__ */ m("fieldset", {
				"data-group": n,
				children: [/* @__PURE__ */ p("legend", { children: n }), /* @__PURE__ */ p("div", {
					className: Q.controls,
					children: t.params.filter((e) => e.group === n).map((r) => Sr(e, r, `${t.name} ${n}`))
				})]
			}, n))
		}) : null;
	}
	function wr(e) {
		return Qe(d, e);
	}
	function Tr(e) {
		let n = !!wt[e.id]?.playing;
		return /* @__PURE__ */ m("button", {
			className: Q.playButton,
			disabled: t,
			"aria-label": `${n ? "Stop" : "Play"} ${wr(e)} sequencer`,
			"data-playing": n,
			onClick: () => {
				_.current?.modulePlaying(e.id) ? _.current.stopModule(e.id) : _.current?.play(e.id).catch(Y);
			},
			children: [/* @__PURE__ */ p(or, { name: n ? "stop" : "play" }), /* @__PURE__ */ p("span", { children: n ? "STOP" : "PLAY" })]
		});
	}
	let Er = d.modules.find((e) => e.id === st) ?? d.modules[0], Or = I[Er.type], kr = Or.drum?.voices ?? (Er.type === "noise" ? [{
		id: "noise",
		label: "Noise"
	}] : null), Ar = kr && kr.length > 6 ? Math.ceil(kr.length / 2) : 6, jr = ze(d, Er.id) ? null : `${Or.name} needs an audio path to MAIN. Flip the rack to connect it.`;
	function Mr(e) {
		let t = xe(d, e.id), n = wt[e.id]?.clock ?? -1, r = n < 0 ? -1 : n % 16, i = wr(e), a = i !== I[e.type].name, o = De?.moduleId === e.id ? De.index : null, s = o === null ? null : t[o];
		return /* @__PURE__ */ m("div", {
			className: Q.sequenceBody,
			children: [
				/* @__PURE__ */ m("div", {
					className: Q.sequenceTop,
					children: [/* @__PURE__ */ m("div", {
						className: Q.lcd,
						children: [
							/* @__PURE__ */ p("small", { children: "SEQUENCER" }),
							/* @__PURE__ */ m("strong", { children: [r >= 0 ? String(r + 1).padStart(2, "0") : "16", /* @__PURE__ */ p("span", { children: "STEPS" })] }),
							/* @__PURE__ */ p("span", {
								className: Q.lcdDots,
								"aria-hidden": "true"
							})
						]
					}), /* @__PURE__ */ m("div", {
						className: Q.transport,
						children: [Tr(e), /* @__PURE__ */ p("span", {
							className: Q.transportCaption,
							children: "16TH NOTE / MONO"
						})]
					})]
				}),
				/* @__PURE__ */ p("div", {
					className: Q.steps,
					role: "group",
					"aria-label": `${i} steps`,
					children: t.map((t, n) => /* @__PURE__ */ m("div", {
						className: Q.stepCell,
						children: [/* @__PURE__ */ m("button", {
							className: Q.step,
							"data-enabled": t.enabled,
							"data-silent": !Xe(e.id, n, V),
							"data-current": r === n,
							"data-editing": o === n,
							"aria-label": `Step ${n + 1}: ${t.enabled ? ht(t.note) : "rest"}`,
							"aria-pressed": o === n,
							onClick: () => ke(o === n ? null : {
								moduleId: e.id,
								index: n
							}),
							children: [
								/* @__PURE__ */ p("span", { className: Q.stepLed }),
								/* @__PURE__ */ p("span", {
									className: Q.stepNumber,
									children: String(n + 1).padStart(2, "0")
								}),
								/* @__PURE__ */ p("strong", { children: t.enabled ? ht(t.note) : "—" })
							]
						}), /* @__PURE__ */ p(sr, {
							mixKey: Ue(e.id, n),
							label: a ? `${i} step ${n + 1}` : `step ${n + 1}`,
							mix: V,
							onToggle: hn
						})]
					}, n))
				}),
				o !== null && s && /* @__PURE__ */ m("div", {
					className: Q.stepEditor,
					children: [
						/* @__PURE__ */ m("strong", { children: ["STEP ", String(o + 1).padStart(2, "0")] }),
						/* @__PURE__ */ m("label", { children: [/* @__PURE__ */ p("input", {
							type: "checkbox",
							checked: s.enabled,
							onChange: (t) => Mn(e.id, o, { enabled: t.target.checked })
						}), "Note on"] }),
						/* @__PURE__ */ m("label", { children: ["Note", /* @__PURE__ */ p("select", {
							"aria-label": "Step note",
							value: s.note,
							onChange: (t) => Mn(e.id, o, { note: Number(t.target.value) }),
							children: Array.from({ length: 73 }, (e, t) => t + 24).map((e) => /* @__PURE__ */ p("option", {
								value: e,
								children: ht(e)
							}, e))
						})] }),
						/* @__PURE__ */ m("label", { children: [
							"Velocity",
							/* @__PURE__ */ p("input", {
								"aria-label": "Step velocity",
								type: "range",
								min: 0,
								max: 1,
								step: .01,
								value: s.velocity,
								onChange: (t) => Mn(e.id, o, { velocity: Number(t.target.value) }, `step:${o}:velocity`)
							}),
							/* @__PURE__ */ m("output", { children: [Math.round(s.velocity * 100), "%"] })
						] }),
						/* @__PURE__ */ m("label", { children: [
							"Gate",
							/* @__PURE__ */ p("input", {
								"aria-label": "Step gate",
								type: "range",
								min: .1,
								max: .95,
								step: .01,
								value: s.gate,
								onChange: (t) => Mn(e.id, o, { gate: Number(t.target.value) }, `step:${o}:gate`)
							}),
							/* @__PURE__ */ m("output", { children: [Math.round(s.gate * 100), "%"] })
						] }),
						/* @__PURE__ */ p("button", {
							onClick: () => ke(null),
							"aria-label": "Close step editor",
							children: "×"
						})
					]
				}),
				/* @__PURE__ */ m("div", {
					className: Q.sequenceHint,
					children: ["Click a step to edit its note, velocity & gate.", /* @__PURE__ */ p("span", { children: "PATCHABLE PITCH + GATE" })]
				})
			]
		});
	}
	let Nr = qe(d, V), Pr = ![
		"Saved locally",
		"Patch restored",
		"Loading patch…"
	].includes(k), Fr = /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("img", {
		className: Q.brandMark,
		src: ri,
		width: "48",
		height: "48",
		alt: ""
	}), /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("strong", { children: "Rackloose" }), /* @__PURE__ */ p("small", { children: "MODULAR SYNTHESIZER" })] })] }), Ir = gr || Fe || U ? vr ? "Drop the plug on a free highlighted jack, or on empty rack space to unplug. Escape puts it back." : "Choose a free highlighted jack. Escape cancels." : lr ? "Drag either plug to move it. Delete unplugs this cable." : "One cable per jack. Drag from a jack to patch; drag a plug to move or unplug it.";
	return /* @__PURE__ */ p(ti.Provider, {
		value: ve,
		children: /* @__PURE__ */ m("section", {
			ref: v,
			className: Q.app,
			"aria-label": "Rackloose modular synthesizer",
			onKeyDown: (e) => {
				e.key !== "Escape" || e.defaultPrevented || (D ? Hn() : qt === null ? te ? (ne(!1), Yt.current?.focus()) : T ? (E(!1), S.current?.focus()) : (Fe || Pe || U) && (B(null), z(null), W(null), M(U ? "Plug back in its jack." : "Patching cancelled.")) : In());
			},
			children: [
				/* @__PURE__ */ m("header", {
					className: Q.toolbar,
					children: [o ? /* @__PURE__ */ p("a", {
						className: Q.brand,
						href: "https://rackloose.michaelzick.com/",
						target: "_blank",
						rel: "noopener noreferrer",
						title: "Open Rackloose in a new tab",
						children: Fr
					}) : /* @__PURE__ */ p("div", {
						className: Q.brand,
						children: Fr
					}), /* @__PURE__ */ m("div", {
						className: Q.toolbarActions,
						children: [
							/* @__PURE__ */ m("button", {
								className: Q.audioButton,
								"data-ready": se,
								disabled: t,
								onClick: () => {
									se ? (_.current?.panic(), M("Audio stopped.")) : _.current?.unlock().then(() => M("Audio enabled. Play A–K, tap a key, or start the pattern.")).catch(Y);
								},
								children: [/* @__PURE__ */ p("span", { className: Q.statusLed }), se ? "Audio on" : "Enable audio"]
							}),
							/* @__PURE__ */ p("button", {
								onClick: () => {
									_.current?.panic(), M("Panic: all sound and pending notes cleared.");
								},
								title: "Immediately silence all sound",
								children: "Panic"
							}),
							/* @__PURE__ */ p("button", {
								ref: x,
								onClick: () => ee(!0),
								"aria-label": "Open user guide",
								title: "User guide",
								children: "?"
							})
						]
					})]
				}),
				/* @__PURE__ */ m("div", {
					className: Q.patchBar,
					children: [/* @__PURE__ */ m("div", {
						className: Q.patchFile,
						children: [
							/* @__PURE__ */ m("label", {
								className: Q.patchName,
								children: [/* @__PURE__ */ p("span", { children: "PATCH" }), /* @__PURE__ */ m("span", {
									className: Q.nameField,
									"data-value": d.name,
									children: [/* @__PURE__ */ p("input", {
										"aria-label": "Patch name",
										"aria-describedby": dn ? rn : void 0,
										maxLength: 100,
										size: 1,
										value: d.name,
										onChange: (e) => {
											let t = e.target.value;
											q((e) => e.name === t ? e : {
												...e,
												name: t
											}, "name");
										}
									}), dn && /* @__PURE__ */ m("span", {
										id: rn,
										className: Q.dirtyMark,
										title: "Unsaved changes",
										children: [/* @__PURE__ */ p("span", {
											"aria-hidden": "true",
											children: "*"
										}), /* @__PURE__ */ p("span", {
											className: Q.visuallyHidden,
											children: "Unsaved changes"
										})]
									})]
								})]
							}),
							/* @__PURE__ */ m("span", {
								className: Q.saveStatus,
								"data-save-status": !0,
								"data-error": Pr,
								"aria-live": "polite",
								title: k,
								children: [
									/* @__PURE__ */ p("span", {
										className: Q.saveLed,
										"aria-hidden": "true"
									}),
									/* @__PURE__ */ p("span", {
										className: Q.saveText,
										children: Pr ? "Not saved" : k
									}),
									Pr && /* @__PURE__ */ p("span", {
										className: Q.visuallyHidden,
										children: k
									})
								]
							}),
							/* @__PURE__ */ p("button", {
								"aria-label": "Save to My Presets",
								title: "Save to My Presets in this browser (⌘S / Ctrl+S)",
								onClick: (e) => jn(e.currentTarget),
								children: "Save"
							}),
							/* @__PURE__ */ p("button", {
								ref: Yt,
								"aria-expanded": te,
								onClick: () => {
									ne(!te), E(!1);
								},
								children: "Presets"
							}),
							/* @__PURE__ */ m("span", {
								className: Q.exportControls,
								children: [/* @__PURE__ */ p("select", {
									"aria-label": "Export loop count",
									title: "Loops to render",
									value: Ze,
									onChange: (e) => tt(Number(e.target.value)),
									children: [
										1,
										2,
										4,
										8
									].map((e) => /* @__PURE__ */ m("option", {
										value: e,
										children: [
											e,
											" ",
											e === 1 ? "loop" : "loops"
										]
									}, e))
								}), /* @__PURE__ */ p("button", {
									disabled: it,
									"aria-busy": it,
									title: "Render every sequencer to a WAV file",
									onClick: () => void ar(),
									children: it ? "Rendering…" : "↓ Export WAV"
								})]
							}),
							/* @__PURE__ */ p("input", {
								ref: b,
								type: "file",
								accept: ".json,application/json",
								hidden: !0,
								"aria-label": "Import patch file",
								onChange: (e) => void rr(e.target.files?.[0])
							})
						]
					}), /* @__PURE__ */ m("div", {
						className: Q.rackActions,
						children: [
							/* @__PURE__ */ m("span", {
								className: Q.historyActions,
								children: [/* @__PURE__ */ p("button", {
									"aria-label": "Undo",
									title: "Undo (⌘Z / Ctrl+Z)",
									disabled: !Pt.undo,
									onClick: () => En("undo"),
									children: /* @__PURE__ */ p(or, { name: "undo" })
								}), /* @__PURE__ */ p("button", {
									"aria-label": "Redo",
									title: "Redo (⇧⌘Z / Ctrl+Y)",
									disabled: !Pt.redo,
									onClick: () => En("redo"),
									children: /* @__PURE__ */ p(or, { name: "redo" })
								})]
							}),
							/* @__PURE__ */ p("button", {
								ref: S,
								className: Q.addButton,
								"aria-expanded": T,
								onClick: () => {
									E(!T), ne(!1);
								},
								children: "＋ Add device"
							}),
							/* @__PURE__ */ m("button", {
								className: Q.flipButton,
								"aria-label": C ? "Show front" : "Flip rack",
								"aria-pressed": C,
								onClick: () => {
									$(), w(!C), B(null), z(null), W(null), M(C ? "Front panel. Turn a knob and make it yours." : "Rear panel. Drag from one jack to another, or tap one then the other.");
								},
								children: ["⇄ ", C ? "Show front" : "Flip rack"]
							})
						]
					})]
				}),
				te && /* @__PURE__ */ p(Qr, {
					presets: Bt,
					openId: cn,
					dirty: dn,
					onSaveAs: An,
					onImport: () => b.current?.click(),
					onExportCurrent: () => zn(d),
					onExport: zn,
					onDelete: Rn,
					onLoad: (e) => Fn(e.patch, `Loaded “${e.patch.name}” from My Presets.`, e.id),
					onLoadFactory: (e) => Fn(ct(e), `${e} loaded. Your rack is patched and ready to play.`),
					onClose: () => {
						ne(!1), Yt.current?.focus();
					}
				}),
				T && /* @__PURE__ */ m("div", {
					className: Q.library,
					role: "region",
					"aria-label": "Device library",
					children: [/* @__PURE__ */ m("div", {
						className: Q.libraryHeading,
						children: [/* @__PURE__ */ p("strong", { children: "MAKE ROOM FOR SOMETHING NEW." }), /* @__PURE__ */ p("button", {
							"aria-label": "Close device library",
							onClick: () => E(!1),
							children: "×"
						})]
					}), /* @__PURE__ */ p("div", {
						className: Q.libraryGrid,
						children: he.map((e) => /* @__PURE__ */ m("button", {
							"data-device": I[e].color,
							disabled: d.modules.length >= 32,
							onClick: () => Bn(e),
							children: [
								/* @__PURE__ */ m("span", {
									className: Q.miniDevice,
									children: ["◉ ◉ ", /* @__PURE__ */ p("span", { children: "▰" })]
								}),
								/* @__PURE__ */ p("strong", { children: I[e].name }),
								/* @__PURE__ */ p("small", { children: I[e].subtitle })
							]
						}, e))
					})]
				}),
				/* @__PURE__ */ m("div", {
					className: Q.rackHeading,
					children: [/* @__PURE__ */ m("span", { children: [/* @__PURE__ */ p("span", { className: Q.rackLight }), C ? "REAR PANEL / SIGNAL ROUTING" : "YOUR RACK / FRONT PANEL"] }), /* @__PURE__ */ m("span", { children: [
						d.modules.length,
						" DEVICES · ",
						d.cables.length,
						" CONNECTIONS"
					] })]
				}),
				C && /* @__PURE__ */ m("div", {
					className: Q.routingBar,
					children: [/* @__PURE__ */ p("span", { children: Ir }), /* @__PURE__ */ m("span", {
						className: Q.legend,
						children: [
							/* @__PURE__ */ p("i", { "data-kind": "audio" }),
							" AUDIO ",
							/* @__PURE__ */ p("i", { "data-kind": "cv" }),
							" CV ",
							/* @__PURE__ */ p("i", { "data-kind": "gate" }),
							" GATE"
						]
					})]
				}),
				/* @__PURE__ */ m("div", {
					className: Q.rack,
					ref: y,
					"data-holding": !!gr,
					onClick: Kn,
					onPointerMove: nr,
					onPointerLeave: () => Ke(null),
					children: [
						C && /* @__PURE__ */ p(Dn, {
							patch: d,
							rackRef: y,
							selected: Pe,
							onSelect: (e) => {
								z(e), B(null), W(null);
							},
							drag: gr
						}),
						d.modules.map((e, n) => {
							let r = I[e.type];
							return /* @__PURE__ */ m("article", {
								className: Q.module,
								"data-module-id": e.id,
								"data-device": r.color,
								"data-rear": C,
								"data-revealed": Je === e.id,
								"data-silent": Nr[e.id] === !1,
								"data-keyboard-target": Er.id === e.id,
								onPointerDown: () => {
									C || Cn(e);
								},
								onFocus: () => {
									C || Cn(e);
								},
								"aria-label": `${r.name} ${r.subtitle}`,
								children: [
									/* @__PURE__ */ p("span", { className: `${Q.screw} ${Q.screwTL}` }),
									/* @__PURE__ */ p("span", { className: `${Q.screw} ${Q.screwTR}` }),
									/* @__PURE__ */ p("span", { className: `${Q.screw} ${Q.screwBL}` }),
									/* @__PURE__ */ p("span", { className: `${Q.screw} ${Q.screwBR}` }),
									/* @__PURE__ */ m("div", {
										className: Q.moduleHeader,
										children: [/* @__PURE__ */ m("div", {
											className: Q.moduleIdentity,
											children: [
												Ge(e.type) && /* @__PURE__ */ p(ni, {
													select: (t) => t.pulsing.has(e.id),
													children: (e) => /* @__PURE__ */ p("span", {
														className: Q.hitLed,
														"data-lit": e,
														title: "Flashes on each sequencer hit",
														"aria-hidden": "true"
													})
												}),
												Ie(e.type) ? /* @__PURE__ */ p("button", {
													className: Q.moduleNameButton,
													"aria-label": `Select ${r.name} ${n + 1} for keyboard`,
													"aria-pressed": Er.id === e.id,
													onClick: () => {
														C || Cn(e);
													},
													children: r.name
												}) : /* @__PURE__ */ p("span", {
													className: Q.moduleName,
													children: r.name
												}),
												/* @__PURE__ */ p("span", {
													className: Q.moduleSubtitle,
													children: r.subtitle
												})
											]
										}), /* @__PURE__ */ m("div", {
											className: Q.moduleTools,
											children: [
												e.type !== "output" && /* @__PURE__ */ p(sr, {
													mixKey: e.id,
													label: r.name,
													mix: V,
													onToggle: hn,
													clearable: nt(e, V),
													onClear: () => mn((t) => ({ mix: rt(t.mix, e) }))
												}),
												/* @__PURE__ */ p("span", {
													className: Q.moduleNumber,
													children: String(n + 1).padStart(2, "0")
												}),
												!be(d, e.id) && /* @__PURE__ */ m(f, { children: [
													/* @__PURE__ */ p("button", {
														"aria-label": `Move ${r.name} up`,
														disabled: n === 1,
														onClick: () => q((t) => je(t, e.id, -1)),
														children: "↑"
													}),
													/* @__PURE__ */ p("button", {
														"aria-label": `Move ${r.name} down`,
														disabled: n === d.modules.length - 2,
														onClick: () => q((t) => je(t, e.id, 1)),
														children: "↓"
													}),
													/* @__PURE__ */ p("button", {
														"aria-label": `Duplicate ${r.name}`,
														disabled: d.modules.length >= 32,
														onClick: () => Vn(e),
														children: "⧉"
													}),
													/* @__PURE__ */ p("button", {
														"aria-label": `Remove ${r.name}`,
														onClick: () => {
															$(), W(null), H.current === e.id && Cn(d.modules[0]), q((t) => Ae(t, e.id)), z(null), B(null), M(`${r.name} removed. Undo brings it back with its cables.`);
														},
														children: "×"
													})
												] })
											]
										})]
									}),
									C ? xr(e) : e.type === "performance" ? Mr(e) : /* @__PURE__ */ m(f, { children: [
										r.drum && /* @__PURE__ */ m("div", {
											className: Q.moduleTransport,
											children: [Tr(e), /* @__PURE__ */ m("span", { children: [
												"SHARED TEMPO · ",
												d.sequencer.bpm,
												" BPM"
											] })]
										}),
										/* @__PURE__ */ m("div", {
											className: Q.moduleBody,
											children: [e.type === "mixer" ? /* @__PURE__ */ p(ni, {
												select: (t) => t.mixerLevels[e.id] ?? ii,
												children: (t) => /* @__PURE__ */ p(qr, {
													module: e,
													patch: d,
													mix: V,
													levels: t,
													onParams: (t) => J(e.id, t),
													onToggle: hn
												})
											}) : /* @__PURE__ */ p("div", {
												className: Q.controls,
												children: r.params.filter((e) => !e.voice && !e.group).map((t) => Sr(e, t, r.name))
											}), e.type !== "mixer" && /* @__PURE__ */ p("div", {
												className: Q.moduleDecoration,
												children: e.type === "output" ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(ni, {
													select: (e) => e.meter,
													children: (e) => /* @__PURE__ */ p("div", {
														className: Q.meters,
														"aria-label": "Output level",
														role: "meter",
														"aria-valuemin": 0,
														"aria-valuemax": 1,
														"aria-valuenow": Number(e.toFixed(3)),
														children: [0, 1].map((t) => /* @__PURE__ */ m("div", {
															className: Q.meterRow,
															children: [/* @__PURE__ */ p("span", { children: t === 0 ? "L" : "R" }), Array.from({ length: 18 }, (t, n) => /* @__PURE__ */ p("i", {
																"data-lit": n / 18 < e,
																"data-hot": n > 14
															}, n))]
														}, t))
													})
												}), /* @__PURE__ */ p("button", {
													"aria-pressed": F,
													onClick: () => mn((e) => ({ mainMuted: !e.mainMuted })),
													className: Q.muteButton,
													children: F ? "UNMUTE" : "MUTE"
												})] }) : e.type === "envelope" ? /* @__PURE__ */ p(ir, { params: e.params }) : ["compressor", "cohere"].includes(e.type) ? /* @__PURE__ */ p(ni, {
													select: (t) => t.reductions[e.id] ?? 0,
													children: (e) => /* @__PURE__ */ p(er, {
														reduction: e,
														label: `${r.name} ${n + 1} gain reduction`
													})
												}) : e.type === "equalizer" ? /* @__PURE__ */ p($n, { params: e.params }) : r.drum?.mode === "euclid" ? /* @__PURE__ */ p(fr, {
													module: e,
													clock: wt[e.id]?.clock ?? -1
												}) : /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("span", { className: Q.deviceLed }), /* @__PURE__ */ m("span", {
													className: Q.deviceLabel,
													children: [
														pi[e.type] ?? "RACKLOOSE",
														/* @__PURE__ */ p("br", {}),
														/* @__PURE__ */ p("small", { children: "PATCH. PLAY. REPEAT." })
													]
												})] })
											})]
										}),
										e.type === "brit" ? /* @__PURE__ */ p(Dr, {
											module: e,
											rate: me,
											onParams: (t) => J(e.id, t)
										}) : e.type === "talon" ? /* @__PURE__ */ p(ni, {
											select: (t) => t.reductions[e.id] ?? 0,
											children: (t) => /* @__PURE__ */ p(Rr, {
												module: e,
												reduction: t,
												label: `${r.name} ${n + 1} gain reduction`,
												onParams: (t) => J(e.id, t)
											})
										}) : Cr(e),
										e.type === "prism" && /* @__PURE__ */ p(hr, {
											module: e,
											onParams: (t) => J(e.id, t)
										}),
										e.type === "strike" && /* @__PURE__ */ p(pr, {
											module: e,
											onParams: (t) => J(e.id, t),
											onAudition: (t) => vn(e.id, t),
											disabled: t
										}),
										r.drum?.mode === "euclid" && /* @__PURE__ */ p(ur, {
											module: e,
											clock: wt[e.id]?.clock ?? -1,
											mix: V,
											onMix: hn,
											disabled: t,
											onParams: (t) => J(e.id, t),
											onAudition: (t) => vn(e.id, t)
										}),
										r.drum?.mode === "steps" && /* @__PURE__ */ p(cr, {
											module: e,
											mix: V,
											onMix: hn,
											step: (wt[e.id]?.clock ?? -1) < 0 ? -1 : wt[e.id].clock % 16,
											disabled: t,
											onParams: (t) => J(e.id, t),
											onAudition: (t) => vn(e.id, t)
										})
									] })
								]
							}, e.id);
						}),
						/* @__PURE__ */ m("div", {
							className: Q.rackBottom,
							children: [/* @__PURE__ */ p("span", { children: "RACKLOOSE / BY MICHAEL ZICK © 2026" }), /* @__PURE__ */ p("span", { children: "NO RULES. JUST SIGNAL." })]
						})
					]
				}),
				/* @__PURE__ */ p("div", {
					className: Q.toastAnchor,
					children: /* @__PURE__ */ p("div", {
						className: Q.toast,
						role: "status",
						"data-shown": P,
						children: N
					})
				}),
				/* @__PURE__ */ m("div", {
					className: Q.keyboardPanel,
					children: [
						/* @__PURE__ */ m("div", {
							className: Q.globalControls,
							role: "group",
							"aria-label": "Global controls",
							children: [
								/* @__PURE__ */ m("div", {
									className: Q.globalTransport,
									children: [
										/* @__PURE__ */ m("button", {
											className: Q.playButton,
											disabled: t,
											onClick: yn,
											"data-playing": ae,
											"aria-label": ae ? "Pause all sequencers" : "Play all sequencers",
											children: [/* @__PURE__ */ p(or, { name: ae ? "pause" : "play" }), /* @__PURE__ */ p("span", { children: ae ? "PAUSE ALL" : "PLAY ALL" })]
										}),
										/* @__PURE__ */ m("button", {
											className: Q.resetButton,
											onClick: () => _.current?.reset(),
											"aria-label": "Reset all sequencers",
											children: [/* @__PURE__ */ p(or, { name: "reset" }), /* @__PURE__ */ p("span", { children: "RESET" })]
										}),
										/* @__PURE__ */ p("button", {
											className: Q.clearAllButton,
											disabled: !V.muted.size && !V.soloed.size && !F,
											onClick: () => {
												mn({
													mix: Ve,
													mainMuted: !1
												}), M("All mutes and solos cleared.");
											},
											"aria-label": "Clear all mutes and solos",
											children: /* @__PURE__ */ p("span", { children: "CLR ALL" })
										})
									]
								}),
								/* @__PURE__ */ p(Xr, {
									bpm: d.sequencer.bpm,
									onChange: (e) => Nn("bpm", e)
								}),
								/* @__PURE__ */ m("label", {
									className: Q.swingField,
									children: [
										"SWING",
										/* @__PURE__ */ p("input", {
											type: "range",
											min: 0,
											max: .6,
											step: .01,
											value: d.sequencer.swing,
											"aria-label": "Swing",
											onChange: (e) => Nn("swing", Number(e.target.value))
										}),
										/* @__PURE__ */ m("span", { children: [Math.round(d.sequencer.swing * 100), "%"] })
									]
								}),
								/* @__PURE__ */ m("span", {
									className: Q.globalPosition,
									"aria-label": "Global position",
									children: [ue < 0 ? "01" : String(ue % 16 + 1).padStart(2, "0"), " / 16"]
								})
							]
						}),
						/* @__PURE__ */ m("div", {
							className: Q.keyboardTop,
							children: [
								/* @__PURE__ */ m("strong", {
									className: Q.keyboardTarget,
									children: ["KEYBOARD → ", wr(Er)]
								}),
								jr ? /* @__PURE__ */ p("span", {
									className: Q.routingHint,
									title: jr,
									children: jr
								}) : e && /* @__PURE__ */ p("span", {
									className: Q.keyHint,
									children: kr ? kr.length > 11 ? "Home row + Z X C V B" : "Home row · pads" : "A–K · notes"
								}),
								!kr && /* @__PURE__ */ m("div", {
									className: Q.octaveControls,
									children: [
										/* @__PURE__ */ p("button", {
											"aria-label": "Lower keyboard octave",
											disabled: Te === 1,
											onClick: () => mn((e) => ({ octave: Math.max(1, e.octave - 1) }), "octave"),
											children: "−"
										}),
										/* @__PURE__ */ m("span", { children: ["OCT ", Te] }),
										/* @__PURE__ */ p("button", {
											"aria-label": "Raise keyboard octave",
											disabled: Te === 6,
											onClick: () => mn((e) => ({ octave: Math.min(6, e.octave + 1) }), "octave"),
											children: "＋"
										})
									]
								}),
								/* @__PURE__ */ p("button", {
									className: Q.keysToggle,
									"aria-expanded": Me,
									"aria-controls": tn,
									onClick: () => Ne(!Me),
									children: Me ? "Hide keys" : "Show keys"
								})
							]
						}),
						/* @__PURE__ */ p("div", {
							id: tn,
							hidden: !Me,
							children: kr ? /* @__PURE__ */ p("div", {
								className: Q.performancePads,
								"data-voices": kr.length,
								"data-rows": kr.length > 6 ? 2 : 1,
								style: { "--pad-columns": Ar },
								"aria-label": `${Or.name} performance pads`,
								children: kr.map((n, r) => /* @__PURE__ */ m("button", {
									"data-playing": mt.has(n.id),
									"aria-label": `Keyboard ${Or.name} ${n.label}`,
									disabled: t,
									onPointerDown: (e) => {
										e.button === 0 && (e.preventDefault(), e.currentTarget.setPointerCapture(e.pointerId), vt.current.add(`pointer-${e.pointerId}`), _n(`pointer-${e.pointerId}`, r, e.pointerType !== "mouse"));
									},
									onPointerUp: (e) => X(`pointer-${e.pointerId}`),
									onPointerCancel: (e) => X(`pointer-${e.pointerId}`, !0),
									onLostPointerCapture: (e) => X(`pointer-${e.pointerId}`, !0),
									onKeyDown: (e) => {
										(e.key === "Enter" || e.key === " ") && !e.repeat && (e.preventDefault(), e.stopPropagation(), _n(`pad-${n.id}`, r));
									},
									onKeyUp: (e) => {
										(e.key === "Enter" || e.key === " ") && (e.preventDefault(), X(`pad-${n.id}`));
									},
									onBlur: () => X(`pad-${n.id}`),
									children: [/* @__PURE__ */ p("span", { children: n.label }), e && /* @__PURE__ */ p("small", { children: oi[r].toUpperCase() })]
								}, n.id))
							}) : /* @__PURE__ */ p("div", {
								className: Q.piano,
								"aria-label": "Piano keyboard",
								children: Array.from({ length: 13 }, (e, n) => {
									let r = (Te + 1) * 12 + n, i = si.has(n % 12);
									return /* @__PURE__ */ m("button", {
										className: i ? Q.blackKey : Q.whiteKey,
										"data-note": r,
										"data-playing": fe.includes(r),
										"aria-label": `Play ${ht(r)}`,
										disabled: t,
										onPointerDown: (e) => {
											e.button === 0 && (e.preventDefault(), e.currentTarget.setPointerCapture(e.pointerId), vt.current.add(`pointer-${e.pointerId}`), _n(`pointer-${e.pointerId}`, n, e.pointerType !== "mouse"));
										},
										onPointerUp: (e) => X(`pointer-${e.pointerId}`),
										onPointerCancel: (e) => X(`pointer-${e.pointerId}`, !0),
										onLostPointerCapture: (e) => X(`pointer-${e.pointerId}`, !0),
										onKeyDown: (e) => {
											(e.key === "Enter" || e.key === " ") && !e.repeat && (e.preventDefault(), e.stopPropagation(), _n(`piano-${r}`, n));
										},
										onKeyUp: (e) => {
											(e.key === "Enter" || e.key === " ") && (e.preventDefault(), X(`piano-${r}`));
										},
										onBlur: () => X(`piano-${r}`),
										children: [/* @__PURE__ */ p("span", { children: ai[n].toUpperCase() }), !i && /* @__PURE__ */ p("small", { children: ht(r) })]
									}, n);
								})
							})
						})
					]
				}),
				D && /* @__PURE__ */ p("div", {
					className: Q.helpBackdrop,
					children: /* @__PURE__ */ m("div", {
						className: Q.help,
						role: "dialog",
						"aria-modal": "true",
						"aria-labelledby": nn,
						onKeyDown: (e) => {
							if (e.key === "Tab") {
								let t = e.currentTarget.querySelectorAll("button");
								t.length === 1 && (e.preventDefault(), t[0].focus());
							}
						},
						children: [
							/* @__PURE__ */ m("div", {
								className: Q.helpHeading,
								children: [
									/* @__PURE__ */ p("img", {
										src: "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2064%2064'%3e%3crect%20x='5'%20y='6'%20width='54'%20height='52'%20rx='3'%20fill='%23303337'%20stroke='%23101214'%20stroke-width='2'/%3e%3cpath%20d='M10%2010v44M54%2010v44'%20stroke='%23777'%20stroke-width='3'/%3e%3crect%20x='14'%20y='12'%20width='36'%20height='17'%20fill='%23b9503a'%20stroke='%23111'/%3e%3crect%20x='14'%20y='31'%20width='36'%20height='20'%20fill='%23a0ac9b'%20stroke='%23111'/%3e%3cg%20fill='%23232626'%20stroke='%23dfdfca'%3e%3ccircle%20cx='23'%20cy='21'%20r='5'/%3e%3ccircle%20cx='41'%20cy='21'%20r='5'/%3e%3c/g%3e%3cpath%20d='M23%2021v-4m18%204%203-3'%20stroke='%23fff'%20stroke-width='2'/%3e%3cg%20fill='%231b2221'%20stroke='%23555'%3e%3ccircle%20cx='22'%20cy='39'%20r='3'/%3e%3ccircle%20cx='42'%20cy='44'%20r='3'/%3e%3c/g%3e%3cpath%20d='M22%2039c-6%2020%2027%2020%2020%205'%20fill='none'%20stroke='%23f4bb50'%20stroke-width='3'/%3e%3cpath%20d='M7%208h50'%20stroke='%23a9abad'/%3e%3c/svg%3e",
										width: "34",
										height: "34",
										alt: ""
									}),
									/* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("small", { children: "RACKLOOSE · MODULAR SYNTHESIZER" }), /* @__PURE__ */ p("h2", {
										id: nn,
										children: "User Guide"
									})] }),
									/* @__PURE__ */ p("button", {
										autoFocus: !0,
										onClick: Hn,
										"aria-label": "Close user guide",
										children: "×"
									})
								]
							}),
							/* @__PURE__ */ p("h3", { children: "Transport" }),
							/* @__PURE__ */ p("p", { children: "Play All starts every sequencer and turns into Pause All while anything plays. Reset stops and rewinds. Type a tempo or drag the small slider under it; the change is heard right away. Space always plays and pauses, whichever control has focus, except while typing in a text field. Each STEP–16 and drum machine also has its own Play/Stop, locked to the shared tempo, swing and position." }),
							/* @__PURE__ */ p("h3", { children: "Playing" }),
							/* @__PURE__ */ m("p", { children: [
								"Click a device to aim the keyboard at it. MONARCH, ORACLE, AURORA, PRISM and SOLID play on ",
								/* @__PURE__ */ p("strong", { children: "A W S E D F T G Y H U J K" }),
								", and OCT shifts the range. MONARCH plays one note at a time; ORACLE plays up to five, AURORA eight and PRISM sixteen. Their Chord setting turns every note, from the keys or STEP–16, into a chord. Drum machines get pads on the home row, ",
								/* @__PURE__ */ p("strong", { children: "A S D F G H J K L ; '" }),
								", plus ",
								/* @__PURE__ */ p("strong", { children: "Z X C V B" }),
								" for STRIKE’s remaining five voices. STATIC holds noise on A. STEP–16 plays whatever its Pitch and Gate cables reach, and effects keep the last instrument. The light beside each instrument and drum machine flashes every time a sequencer plays it. Hide keys keeps every global control."
							] }),
							/* @__PURE__ */ p("h3", { children: "Knobs and steps" }),
							/* @__PURE__ */ p("p", { children: "Drag a knob up or down, or use the arrow keys; double-click restores its default. Click a STEP–16 step to set its note, velocity and gate. Add device adds more STEP–16s: each has its own 16 steps, Play/Stop and step mutes, and plays whatever its own Pitch and Gate cables reach, so separate parts can drive separate instruments. Typing in a field never plays notes." }),
							/* @__PURE__ */ p("h3", { children: "Patching cables" }),
							/* @__PURE__ */ p("p", { children: "Flip the rack to patch. Each jack holds one cable. Drag from an empty jack to a free one; jacks that can take it light up. Drag a plugged jack to pull its plug out: drop it on a free jack to move it, or on empty rack space to unplug it. You can also tap a plugged jack to lift its plug, then tap a free jack. Escape or a bad drop puts the plug back, and Delete unplugs a selected cable. Every output has a spare jack, and STEP–16 has three Pitch and three Gate jacks, so one signal can feed several places. Amber is audio, blue is CV and coral is gate; types must match. The trim beside a CV input sets its depth. SUM mixes eight channels and names each one after the instrument feeding it, through any effects; hover the name to see the chain." }),
							/* @__PURE__ */ p("h3", { children: "Mixing on SUM" }),
							/* @__PURE__ */ p("p", { children: "SUM is laid out like a console. Each channel strip has Pan, M and S, a fader and a level meter: green, amber from −9 dB and red from −3 dB. Drag a fader or pan knob, or use the arrow keys; double-click returns it to its default. The MIX BUS fader on the right sets the level of the whole mix, with its own left and right meters." }),
							/* @__PURE__ */ p("h3", { children: "Drums" }),
							/* @__PURE__ */ p("p", { children: "AURORA is an eight-voice Jupiter-8-inspired polysynth: blend two oscillators, shape them with high-pass and 12/24 dB low-pass filters, and animate pulse width with the LFO. PRISM is a focused DX7-inspired FM synth: choose one of six algorithms, then select an operator to edit its ratio, level and envelope. Brightness controls modulation depth; Velocity makes quieter sequenced notes softer in tone. Both use their own envelopes and work with STEP–16 Pitch and Gate, or directly from the keyboard." }),
							/* @__PURE__ */ p("p", { children: "STRIKE has sixteen vintage digital drum lanes. Select a voice to edit Tune, Decay, Tone, Level and Pan. Its sounds are original generated one-shots, inspired by LinnDrum. BOOM has eleven voices: kick, snare, rim, clap, closed and open hat, low and high tom, crash, ride and bell. A closed hat cuts off a ringing open hat. Click a voice name to hear it and click pads to program its steps. ORBIT voices each have Steps, Hits and Shift; tap its step pads for a custom rhythm, and Generate brings back the Euclidean pattern. A drum machine’s Chain in passes another instrument through." }),
							/* @__PURE__ */ p("h3", { children: "Dynamics and EQ" }),
							/* @__PURE__ */ p("p", { children: "VALVE is a tube limiter: Input drives the tube, Threshold sets where it starts to hold the level back, and Time constant picks how fast it lets go, from 1 (quick) to 6 (slow). The needle shows the gain reduction. CONSOLE is a channel EQ: high- and low-pass filters, LF and HF that switch between shelf and bell, and two sweepable mids with Q. The screen draws the curve you hear, and EQ Out bypasses it." }),
							/* @__PURE__ */ p("h3", { children: "Mute and solo" }),
							/* @__PURE__ */ p("p", { children: "M mutes and S solos a device, drum voice, SUM channel or step, and the two are exclusive. CLR clears one device, with its voices, channels or steps; CLR ALL clears everything, MAIN’s mute included. Silenced parts dim. These settings last for this session." }),
							/* @__PURE__ */ p("h3", { children: "Undo and unsaved changes" }),
							/* @__PURE__ */ m("p", { children: [
								"Undo and Redo, or ",
								/* @__PURE__ */ p("strong", { children: "⌘Z" }),
								" and ",
								/* @__PURE__ */ p("strong", { children: "⇧⌘Z" }),
								" (",
								/* @__PURE__ */ p("strong", { children: "Ctrl+Z" }),
								" and ",
								/* @__PURE__ */ p("strong", { children: "Ctrl+Y" }),
								"), step through your last 50 changes: knobs, steps, tempo, cables, devices, presets, mutes, solos and octave. A ",
								/* @__PURE__ */ p("strong", { children: "*" }),
								" after the patch name means it has changed since you last saved it to My Presets or loaded it."
							] }),
							/* @__PURE__ */ p("h3", { children: "Presets and files" }),
							/* @__PURE__ */ m("p", { children: [
								"Your rack keeps itself between visits. Save, or ",
								/* @__PURE__ */ p("strong", { children: "⌘S" }),
								" (",
								/* @__PURE__ */ p("strong", { children: "Ctrl+S" }),
								"), keeps it in My Presets in this browser: the first save asks for a name, and later saves update that preset. Type a new name in PATCH and save to rename it; Save as… (",
								/* @__PURE__ */ p("strong", { children: "⇧⌘S" }),
								") makes a copy. Presets lists My Presets above the factory presets. Export downloads a preset as a .json file, Import file adds one to My Presets, and Delete removes your own presets. Export WAV, beside Presets, renders the number of loops chosen next to it, every sequencer from the start, effects and mutes included, but not MAIN’s Mute. The light beside the patch name shows whether your rack is saved in this browser, and messages appear briefly over the bottom of the rack. Panic silences everything at once."
							] })
						]
					})
				}),
				qt !== null && /* @__PURE__ */ p($r, {
					initialName: qt,
					presets: Bt,
					onSave: Ln,
					onCancel: In
				})
			]
		})
	});
}
//#endregion
export { Si as RacklooseApp, dt as parsePatch, ct as preset, lt as serializePatch };
