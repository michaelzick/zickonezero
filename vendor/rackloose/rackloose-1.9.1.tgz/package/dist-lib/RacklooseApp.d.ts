export type RacklooseAppProps = {
    keysEnabled?: boolean;
    suspended?: boolean;
    storageKey?: string;
    linkBrand?: boolean;
};
export declare function RacklooseApp({ keysEnabled, suspended, storageKey, linkBrand }: RacklooseAppProps): import("react").JSX.Element;
