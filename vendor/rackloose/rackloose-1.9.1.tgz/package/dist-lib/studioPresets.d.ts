import type { Patch } from './model';
export { STUDIO_PRESETS } from './model';
type Name = typeof import('./model').STUDIO_PRESETS[number];
/**
 * Four originals in the French electro tradition. Each is its own arrangement, and each puts COHERE, TALON and BRIT
 * where an engineer would: TALON on drums, BRIT on the part that needs console colour, COHERE gluing the mix bus.
 */
export declare function studioPreset(name: Name): Patch;
