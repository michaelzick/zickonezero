import { type ModuleType, type Patch, type Step } from './model';
/**
 * A device in rack order. `lanes` program a step drum machine's voices, `euclid` sets ORBIT's rings as hits, steps
 * and rotation, and a STEP–16 plays `steps`. Voices a drum device isn't given stay silent.
 */
export type Device = {
    type: ModuleType;
    params?: Record<string, number>;
    lanes?: Record<string, string>;
    euclid?: Record<string, [hits: number, steps: number, shift?: number]>;
    steps?: Step[];
};
export type Route = [from: string, output: string, to: string, input: string, amount?: number];
export declare const bits: (pattern: string) => number;
/**
 * One bar of 16ths. `rhythm` marks an accent X, a note x, a ghost o or a rest, `notes` gives every step's pitch, and
 * `gate` is one length for every step or a length for each.
 */
export declare const bar: (rhythm: string, notes: number[], gate: number | number[]) => Step[];
/** The same pitch for a run of steps, so a part reads as its chord changes. */
export declare const hold: (...runs: [note: number, steps: number][]) => number[];
/** A dotted-eighth echo, the dance-floor default, in seconds. */
export declare const dotted: (bpm: number) => number;
type Operator = [ratio: number, detune: number, level: number, attack: number, decay: number, sustain: number, release: number];
/** PRISM's six operators in order. Any left out are silent. */
export declare const operators: (...ops: Operator[]) => any;
/**
 * PRISM voicings on the three-pairs algorithm, carrier then modulator in each pair. A tine e-piano, an inharmonic bell,
 * a reed that the 1:2 pair keeps to odd harmonics, a kalimba, a slap bass with a sub, a round FM bass and a pluck.
 */
export declare const FM: {
    epiano: any;
    bell: any;
    reed: any;
    kalimba: any;
    slap: any;
    bass: any;
    pluck: any;
};
export declare function rack(name: string, bpm: number, swing: number, devices: Record<string, Device>, routes: Route[]): Patch;
/** A STEP–16 playing an instrument, on spare jack `jack` (2 or 3) when the sequencer already plays another. */
export declare const play: (sequencer: string, instrument: string, jack?: "" | 2 | 3) => Route[];
/** Audio through each device in turn. */
export declare const chain: (...ids: string[]) => Route[];
/** Each source chain into its own SUM channel, from A, then SUM through the master devices to MAIN. */
export declare const mixdown: (chains: string[][], sum: string, ...master: string[]) => Route[];
export {};
