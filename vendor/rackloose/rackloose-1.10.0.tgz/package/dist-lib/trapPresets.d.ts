import type { Patch } from './model';
export { TRAP_PRESETS } from './model';
type Name = typeof import('./model').TRAP_PRESETS[number];
/**
 * Three slow trap starters that sit on 2 and 4 like a hip-hop beat: BOOM's kick and backbeat, an 808 under the
 * harmony, and SKITTER rolling BOOM's hats in 1/16s, 1/32s and rolls into the turnarounds.
 */
export declare function trapPreset(name: Name): Patch;
