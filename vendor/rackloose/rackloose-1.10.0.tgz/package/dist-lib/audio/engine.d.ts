import { type Mix, type Patch } from '../model';
export { prepareAudio } from './prism';
/** The quietest level a meter reports, in dBFS. */
export declare const METER_FLOOR = -60;
/** SUM's channel and mix bus levels, in dBFS. */
export type MixerLevels = {
    channels: number[];
    bus: number[];
};
/** A graph shared by the real-time player and offline exporter. No React or DOM dependencies. */
export declare class AudioGraph {
    readonly context: BaseAudioContext;
    private onError?;
    readonly master: GainNode;
    private nodes;
    private sources;
    private runtime;
    private outputs;
    private inputs;
    private cvAmounts;
    /** Each STEP–16's scheduled notes, so an instrument gated by one STEP–16 can play the Pitch of another. */
    private notes;
    private white;
    private mix;
    private open;
    private muted;
    private manualTarget;
    private manualOwned;
    /** The sound sources each STEP–16 plays, and when each source was last hit by a sequencer. */
    private targets;
    private pulses;
    patch: Patch;
    constructor(context: BaseAudioContext, patch: Patch, destination?: AudioNode, mix?: Mix, onError?: ((error: Error) => void) | undefined);
    private keep;
    /** A STEP–16 Pitch cable into a polyphonic instrument carries notes, not a voltage, so each voice keeps its own pitch through its release. */
    private isNoteCable;
    /**
     * The note a polyphonic instrument plays when STEP–16 `sequencer` opens its gate: the note on the STEP–16 its Pitch cable comes from,
     * scaled by that cable's depth like a voltage, or C4 unplugged like MONARCH.
     */
    private polyNote;
    /** A STEP–16's note at `time`, or C3, where its Pitch starts. */
    private noteAt;
    private get main();
    private gain;
    private source;
    private buildModule;
    applyPatch(patch: Patch, initial?: boolean): void;
    /** The envelopes and instruments STEP–16 `sequencer`'s Gate cables reach. Each gate input takes one cable, so one STEP–16 at most. */
    private gatedBy;
    /** Applies mute and solo, SUM's channels included. Gates follow the cables, so a rebuilt graph needs its mix again. */
    setMix(mix: Mix, initial?: boolean): void;
    private openEnvelope;
    private closeEnvelope;
    /** Moves a STEP–16's Pitch to `note` at `time`, and remembers it for `noteAt`. */
    private setNote;
    private gateOn;
    /** Plays a note on STEP–16 `sequencer`, the first one unless named. A STEP–16 played from the keyboard ignores its sequence. */
    noteOn(note: number, velocity?: number, time?: number, sequencer?: string): void;
    noteOff(time?: number, sequencer?: string): void;
    /**
     * Plays clock step `count` on the STEP–16s `ids`, honouring step mutes and solos. Every Pitch moves before any gate
     * opens, so an instrument gated by one STEP–16 and pitched by another hears that step's note.
     */
    sequence(ids: string[], count: number, time: number, duration: number): void;
    /** Records a sequencer hit on sound source `moduleId` at `time`, for its hit LED. */
    private pulse;
    /** When sound source `moduleId` was last hit by a sequencer, up to `time`, or -1. */
    lastPulse(moduleId: string, time: number): number;
    /** SUM `moduleId`'s channel and mix bus peak levels, in dBFS. */
    mixerLevels(moduleId: string): MixerLevels | null;
    /**
     * Plays a module from the keyboard. MONARCH and STEP–16 follow one note; polyphonic instruments give each `key` its own voice and,
     * like MONARCH, take over from the sequence while played.
     */
    manualOn(moduleId: string, note: number, key?: string): void;
    /** Lets go of one key played on polyphonic instruments; the others keep sounding. */
    manualRelease(key: string): void;
    manualOff(): void;
    /** Current compressor gain reduction in dB, zero or negative. */
    reduction(moduleId: string): number;
    drumStep(count: number, time: number, moduleId?: string): void;
    /** The devices SKITTER `moduleId`'s jacks copied from `port` reach. */
    private skitterTargets;
    /**
     * One SKITTER hit on lane `lane` at `time`: a drum lane plays the matching voice of every drum machine its Trig out
     * reaches, and the Synth lane opens every gate its Gate out reaches for Gate of the hit's `length`.
     */
    private skitterHit;
    /** The drum machines SKITTER `moduleId` plays, whose scheduled hits stopping it cancels. */
    skitterKits(moduleId: string): string[];
    hit(moduleId: string, voice: string, time?: number): void;
    cancelModule(moduleId: string, time?: number): void;
    cancelScheduled(time?: number): void;
    setMute(muted: boolean): void;
    flush(): Promise<void>;
    dispose(): void;
}
export declare class SynthEngine {
    private patch;
    private onError?;
    private context;
    private graph;
    private analyser;
    private timer;
    private notes;
    private target;
    private running;
    private nextTime;
    private count;
    private timeline;
    private frozen;
    private remaining;
    private muted;
    private mix;
    private suspended;
    private disposed;
    private revision;
    private manualRevision;
    private transportRevision;
    private moduleRevisions;
    private releaseSession;
    private inputs;
    /** Each SUM's meter readings as last shown, with when they were read, so meters fall back smoothly. */
    private held;
    playing: boolean;
    constructor(patch: Patch, onError?: ((error: Error) => void) | undefined);
    get activeNote(): number | null;
    /** Every key a polyphonic instrument is sounding, or the one note a mono target plays. */
    get activeNotes(): number[];
    private get poly();
    reduction(moduleId: string): number;
    get sampleRate(): number;
    get ready(): boolean;
    private get sounding();
    get clock(): number;
    get step(): number;
    modulePlaying(id: string): boolean;
    moduleClock(id: string): number;
    /** Whether sound source `moduleId` was hit by a sequencer in the last moment of what is being heard. */
    pulsing(moduleId: string): boolean;
    /** SUM `moduleId`'s channel and mix bus levels in dBFS, held at their peaks and falling back about 24 dB a second. */
    mixerLevels(moduleId: string): MixerLevels;
    get meter(): number;
    unlock(): Promise<boolean>;
    /**
     * Defer a phone's first touch until release, inside the user gesture. Keep each request cancellable until startup completes;
     * releasing normally should still sound a short tap, but a canceled touch must never play on a later gesture.
     */
    private unlockForInput;
    /** The app calls this as a finger lifts. It starts audio for the touches waiting on it, and does nothing otherwise. */
    lifted(key?: string): void;
    update(patch: Patch): void;
    press(key: string, note: number, moduleId?: string, touch?: boolean): Promise<void>;
    /** A key let go before audio finished starting (on a phone, a first tap always is) still plays, briefly. */
    private tap;
    release(key: string): void;
    hit(moduleId: string, voice: string, key?: string, touch?: boolean): Promise<void>;
    cancel(key: string): void;
    releaseManual(): void;
    /** Schedules one clock step on the sequencers `ids`: STEP–16s together, so their notes line up, then drum machines. */
    private schedule;
    private startClock;
    play(moduleId?: string): Promise<void>;
    stopModule(id: string): void;
    private tick;
    pause(): void;
    reset(): void;
    stop(): void;
    setMute(muted: boolean): void;
    setMix(mix: Mix): void;
    panic(): void;
    setSuspended(suspended: boolean): void;
    dispose(): void;
}
/** Renders the pattern as heard, honouring mute and solo; MAIN's temporary Mute is not applied. */
export declare function renderAudio(patch: Patch, loops?: number, mix?: Mix): Promise<AudioBuffer>;
export declare function encodeWav(buffer: Pick<AudioBuffer, 'numberOfChannels' | 'length' | 'sampleRate' | 'getChannelData'>): ArrayBuffer;
