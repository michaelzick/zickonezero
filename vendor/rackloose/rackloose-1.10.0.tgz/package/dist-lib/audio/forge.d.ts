/**
 * FORGE's kit, printed once per session from original physical-ish models. Cymbals sum dozens of inharmonic partials
 * with their own decays over a noise wash, so they shimmer rather than hiss; the kick and snare are driven hard.
 */
export declare function forgeSample(voice: string): Float32Array;
/**
 * FORGE's sampled kit into a bus with its own Drive, a parallel clipper connected only while Drive is up, and Room,
 * a gated room send connected only while Room is up.
 */
export declare function createForge(context: BaseAudioContext, bus: AudioNode, keep: <T extends AudioNode>(node: T) => T): {
    dispose(): void;
    apply(p: Record<string, number>): void;
    trigger: (voice: string, time: number, params: {
        [x: string]: number;
    }, velocity?: number) => void;
    cancelScheduled: (time: number) => void;
};
