/**
 * RUST's transfer curve over inputs from -1 to 1. Starve cuts everything under a threshold to silence before the drive,
 * so tails sputter and choke; Bias pushes one side harder for uneven, ugly clipping.
 */
export declare function rustCurve(mode: number, drive: number, bias: number, bits: number, starve: number): Float32Array<ArrayBuffer>;
/**
 * The distortion chain: input, a Body bell that chooses which band breaks up first, the curve, a DC blocker, a Tone
 * low-pass, then a dry/wet mix and Level. Crush runs without oversampling on purpose: its aliasing is the point.
 */
export declare function createRust(context: BaseAudioContext, keep: <T extends AudioNode>(node: T) => T): {
    input: GainNode;
    cv: AudioParam;
    output: GainNode;
    apply(p: Record<string, number>): void;
};
