import type { DrumKit } from './drums';
/** Original drum models printed to low-rate, companded 8-bit-style PCM. No recordings or external assets. */
export declare function strikeSample(voice: string): Float32Array;
/** How a sampled kit prints and plays its voices. `chokedBy` names the voices that cut each voice off, as a closed hat cuts an open one. */
export type SampleKit = {
    rate: number;
    sample: (voice: string) => Float32Array;
    chokedBy?: Record<string, string[]>;
    peak?: number;
    tone?: (amount: number) => number;
};
export declare const createStrike: (context: BaseAudioContext, bus: AudioNode) => DrumKit;
/**
 * Plays one-shots printed by `kit.sample` through each voice's own tone filter, level and pan. Every voice is monophonic:
 * a hit ends at the next hit of the same voice or of a voice that chokes it, so rolls and hat patterns never pile up.
 */
export declare function createSampleKit(context: BaseAudioContext, bus: AudioNode, { rate, sample, chokedBy, peak, tone }: SampleKit): DrumKit;
