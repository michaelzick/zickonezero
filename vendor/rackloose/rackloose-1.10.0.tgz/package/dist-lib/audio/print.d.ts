/** One sample's view of the noise a printed drum is built from: white, a darker low-passed copy, and the bright remainder. */
type Noise = {
    noise: number;
    low: number;
    high: number;
    sin: (frequency: number, time: number) => number;
};
/**
 * A mono one-shot `seconds` long at `rate`, filled sample by sample from seeded noise so every print is identical.
 * The first and last few samples fade in and out so a played buffer never clicks.
 */
export declare function printer(rate: number, seconds: number, seed: number): {
    data: Float32Array<ArrayBuffer>;
    each(sample: (time: number, noise: Noise) => number): void;
};
/** Scales `data` so its loudest sample reaches `peak`. */
export declare function normalize(data: Float32Array, peak: number): void;
export {};
