import type { ModuleType } from '../model';
type Params = Record<string, number>;
type Source = OscillatorNode | AudioBufferSourceNode;
/** `velocity` scales one hit, as a roll fades through its hits. */
export type DrumKit = {
    trigger: (voice: string, time: number, params: Params, velocity?: number) => void;
    cancelScheduled: (time: number) => void;
    dispose: () => void;
};
/** `keep` registers a node the graph disconnects on dispose; `start` also starts and stops a source with the graph. */
export type DrumHost = {
    keep: <T extends AudioNode>(node: T) => T;
    start: <T extends Source>(node: T) => T;
    noise: AudioBuffer;
};
/**
 * Synthesizes one drum device's voices into `bus`. Pitched voices start fresh oscillators on every hit so each attack
 * has the same phase; noisy and metallic voices share always-running sources behind their own VCA. Every voice is
 * monophonic like an analog circuit: a new hit fades out the last one.
 */
export declare function createDrumKit(context: BaseAudioContext, type: ModuleType, bus: AudioNode, { keep, start, noise }: DrumHost): DrumKit;
export {};
