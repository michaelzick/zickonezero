"use client";
import { Fragment as e, createContext as t, useCallback as n, useContext as r, useEffect as i, useId as a, useLayoutEffect as o, useMemo as s, useReducer as c, useRef as l, useState as u, useSyncExternalStore as d } from "react";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
//#region src/presetKit.ts
var h = (e) => [...e].reduce((e, t, n) => t === "x" ? e | 1 << n : e, 0), g = (e, t, n) => [...e].map((e, r) => ({
	note: t[r],
	enabled: e !== ".",
	velocity: e === "X" ? 1 : e === "o" ? .5 : .74,
	gate: typeof n == "number" ? n : n[r]
})), _ = (...e) => e.flatMap(([e, t]) => Array(t).fill(e)), v = (e) => Number((45 / e).toFixed(3)), y = (...e) => Object.fromEntries(Array.from({ length: 6 }, (t, n) => {
	let [r, i, a, o, s, c, l] = e[n] ?? [
		1,
		0,
		0,
		.005,
		.3,
		0,
		.2
	];
	return Object.entries({
		Ratio: r,
		Detune: i,
		Level: a,
		Attack: o,
		Decay: s,
		Sustain: c,
		Release: l
	}).map(([e, t]) => [`op${n + 1}${e}`, t]);
}).flat()), b = {
	epiano: y([
		1,
		0,
		.85,
		.002,
		1.8,
		.12,
		.7
	], [
		1,
		0,
		.45,
		.002,
		1,
		.05,
		.5
	], [
		1,
		4,
		.45,
		.002,
		1.4,
		.1,
		.6
	], [
		14,
		0,
		.2,
		.002,
		.12,
		0,
		.1
	], [
		1,
		-4,
		.35,
		.002,
		1.6,
		.1,
		.6
	], [
		1,
		0,
		.12,
		.002,
		.6,
		0,
		.3
	]),
	bell: y([
		1,
		0,
		.8,
		.002,
		2.2,
		0,
		1.4
	], [
		3.5,
		0,
		.5,
		.002,
		1.4,
		0,
		1
	], [
		2,
		3,
		.35,
		.002,
		1.5,
		0,
		1
	], [
		7,
		0,
		.3,
		.002,
		.6,
		0,
		.5
	], [
		4,
		0,
		.12,
		.002,
		.9,
		0,
		.6
	], [
		10.5,
		0,
		.15,
		.002,
		.3,
		0,
		.3
	]),
	reed: y([
		1,
		0,
		.8,
		.03,
		.4,
		.8,
		.25
	], [
		2,
		0,
		.5,
		.03,
		.5,
		.6,
		.3
	], [
		1,
		6,
		.3,
		.03,
		.4,
		.8,
		.25
	], [
		2,
		0,
		.3,
		.03,
		.5,
		.5,
		.3
	]),
	kalimba: y([
		1,
		0,
		.85,
		.002,
		.7,
		0,
		.4
	], [
		3,
		0,
		.35,
		.002,
		.08,
		0,
		.08
	], [
		1,
		5,
		.4,
		.002,
		.5,
		0,
		.3
	], [
		7,
		0,
		.18,
		.002,
		.04,
		0,
		.04
	]),
	slap: y([
		1,
		0,
		.9,
		.002,
		.35,
		.25,
		.08
	], [
		1,
		0,
		.65,
		.002,
		.15,
		.05,
		.06
	], [
		1,
		3,
		.5,
		.002,
		.3,
		.2,
		.08
	], [
		3,
		0,
		.35,
		.002,
		.05,
		0,
		.04
	], [
		.5,
		0,
		.35,
		.002,
		.4,
		.3,
		.08
	], [
		.5,
		0,
		.1,
		.002,
		.2,
		0,
		.06
	]),
	bass: y([
		1,
		0,
		.9,
		.002,
		.4,
		.3,
		.1
	], [
		1,
		0,
		.55,
		.002,
		.25,
		.1,
		.08
	], [
		.5,
		0,
		.5,
		.002,
		.5,
		.4,
		.1
	], [
		1,
		0,
		.2,
		.002,
		.15,
		0,
		.08
	]),
	pluck: y([
		1,
		0,
		.8,
		.002,
		.45,
		0,
		.3
	], [
		2,
		0,
		.4,
		.002,
		.15,
		0,
		.1
	], [
		2,
		3,
		.35,
		.002,
		.35,
		0,
		.25
	], [
		5,
		0,
		.2,
		.002,
		.06,
		0,
		.05
	])
};
function x(e, t, n, r, i) {
	let a = {
		version: 1,
		name: e,
		modules: Object.entries(r).map(([e, { type: t, params: n, lanes: r, euclid: i, steps: a }], o) => {
			let s = Ae(t, e), c = z[t].drum?.voices ?? [];
			if (r) for (let e of c) s.params[`${e.id}Pattern`] = h(r[e.id] ?? "");
			if (i) for (let e of c) {
				let [t, n, r = 0] = i[e.id] ?? [0, s.params[`${e.id}Steps`]];
				Object.assign(s.params, {
					[`${e.id}Hits`]: t,
					[`${e.id}Steps`]: n,
					[`${e.id}Shift`]: r
				});
			}
			return Object.assign(s.params, n), a && o > 0 ? {
				...s,
				steps: a
			} : s;
		}),
		cables: [],
		sequencer: {
			bpm: t,
			swing: n,
			steps: Object.values(r)[0].steps
		}
	};
	for (let [e, t, n, r, o] of i) a = Re(a, {
		moduleId: e,
		portId: t
	}, {
		moduleId: n,
		portId: r
	}, o);
	return a;
}
var S = (e, t, n = "") => [[
	e,
	`pitch${n}`,
	t,
	"pitch"
], [
	e,
	`gate${n}`,
	t,
	"gate"
]], C = (...e) => e.slice(1).map((t, n) => [
	e[n],
	"out",
	t,
	"in"
]), w = (e, t, ...n) => [...e.flatMap((e, n) => [...C(...e), [
	e.at(-1),
	"out",
	t,
	"abcdefgh"[n]
]]), ...C(t, ...n)], T = (e, ...t) => w(e, "mixer", ...t, "output");
function E(e) {
	return e === "Vintage Bass" ? x(e, 94, .1, {
		performance: {
			type: "performance",
			steps: g("X..o.xx.X..x.xx.", [
				43,
				43,
				43,
				43,
				43,
				46,
				48,
				48,
				36,
				36,
				36,
				48,
				48,
				46,
				41,
				41
			], [
				.9,
				.5,
				.5,
				.5,
				.5,
				.6,
				.9,
				.5,
				.9,
				.5,
				.5,
				.45,
				.5,
				.6,
				.9,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Wave: 3,
				osc2Detune: 4,
				osc2Level: .4,
				osc3Wave: 1,
				osc3Level: .55,
				cutoff: 480,
				resonance: .3,
				drive: .3,
				envAmount: .45,
				filterAttack: .004,
				filterDecay: .25,
				filterSustain: .25,
				filterRelease: .15,
				ampAttack: .004,
				ampDecay: .4,
				ampSustain: .8,
				ampRelease: .08,
				glide: .04,
				level: .75
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 2,
				midFreq: 1,
				midGain: 3,
				drive: 6
			}
		},
		melody: {
			type: "performance",
			steps: g("x".repeat(16), _([86, 6], [84, 1], [82, 1], [79, 6], [77, 1], [79, 1]), .95)
		},
		whistle: {
			type: "monarch",
			params: {
				osc1Wave: 0,
				osc1Level: .9,
				osc2Level: 0,
				osc3Level: 0,
				cutoff: 6e3,
				resonance: 0,
				drive: 0,
				envAmount: 0,
				tracking: 0,
				ampAttack: .03,
				ampDecay: .3,
				ampSustain: 1,
				ampRelease: .3,
				glide: .12,
				level: .5
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(94),
				feedback: .35,
				mix: .25
			}
		},
		chords: {
			type: "performance",
			steps: g("x.......x.......", _([55, 8], [60, 8]), .95)
		},
		keys: {
			type: "aurora",
			params: {
				osc1Wave: 2,
				osc2Wave: 1,
				osc2Detune: 8,
				blend: .45,
				cutoff: 1600,
				resonance: .1,
				envAmount: .2,
				filterAttack: .05,
				filterDecay: .8,
				filterSustain: .4,
				ampAttack: .04,
				ampDecay: .9,
				ampSustain: .7,
				ampRelease: 1.6,
				lfoWidth: .3,
				chord: 4,
				vintage: .4,
				level: .6
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 1.8,
				mix: .25
			}
		},
		drums: {
			type: "strike",
			params: {
				level: 1,
				kickDecay: .4,
				snareTune: -2,
				snareDecay: .3,
				clapLevel: .55,
				hatDecay: .06,
				hatLevel: .45,
				hatPan: .2,
				openLevel: .4,
				openPan: .2,
				tambourineLevel: .3,
				tambourinePan: -.3
			},
			lanes: {
				kick: "x......xx.x.....",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "x.xxx.x.x.xxx.x.",
				open: ".....x.......x..",
				tambourine: "....x.......x..."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .01,
				release: .15,
				color: 1,
				detectorHp: 1,
				output: 7
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: .6,
				c: .7,
				d: .7
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 0,
				attack: 4,
				release: 4,
				output: 2
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("performance", "monarch"),
		...S("melody", "whistle"),
		...S("chords", "keys"),
		...T([
			["drums", "talon"],
			["monarch", "brit"],
			["keys", "space"],
			["whistle", "echo"]
		], "cohere")
	]) : e === "Vintage Lead" ? x(e, 120, 0, {
		performance: {
			type: "performance",
			steps: g("X.xx.xx.X.xxX.xx", [
				76,
				76,
				76,
				74,
				74,
				72,
				74,
				74,
				72,
				72,
				69,
				72,
				71,
				71,
				67,
				71
			], .7)
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 3,
				osc1Level: .7,
				osc2Detune: 9,
				osc2Level: .5,
				osc3Wave: 3,
				osc3Octave: 1,
				osc3Level: .2,
				cutoff: 2600,
				resonance: .25,
				drive: .2,
				envAmount: .35,
				tracking: .6,
				filterDecay: .2,
				filterSustain: .4,
				ampAttack: .004,
				ampDecay: .25,
				ampSustain: .7,
				ampRelease: .15,
				glide: .025,
				level: .6
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(120),
				feedback: .3,
				mix: .22
			}
		},
		octaves: {
			type: "performance",
			steps: g("XxXxXxXxXxXxXxXx", [
				33,
				45,
				33,
				45,
				33,
				45,
				33,
				45,
				29,
				41,
				29,
				41,
				31,
				43,
				31,
				43
			], .5)
		},
		bass: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Detune: 6,
				osc2Level: .4,
				osc3Level: .3,
				cutoff: 600,
				resonance: .3,
				envAmount: .5,
				filterDecay: .12,
				filterSustain: .3,
				ampAttack: .002,
				ampDecay: .15,
				ampSustain: .5,
				ampRelease: .05,
				level: .7
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 1,
				lfGain: 2,
				midFreq: 3,
				midGain: 2,
				drive: 6
			}
		},
		chords: {
			type: "performance",
			steps: g("x.......x...x...", _([57, 8], [50, 4], [52, 4]), .95)
		},
		strings: {
			type: "aurora",
			params: {
				osc2Wave: 0,
				osc2Detune: 12,
				hpf: 200,
				cutoff: 3e3,
				envAmount: .15,
				filterAttack: .1,
				filterDecay: .8,
				filterSustain: .6,
				ampAttack: .08,
				ampDecay: .6,
				ampSustain: .8,
				ampRelease: 1.2,
				lfoRate: .5,
				lfoWidth: .2,
				chord: 2,
				vintage: .4,
				level: .7
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2,
				mix: .3
			}
		},
		drums: {
			type: "boom",
			params: {
				kickTune: 52,
				kickDecay: .5,
				snareTone: .55,
				snappy: .7,
				hatDecay: .04,
				openDecay: .25,
				level: .85
			},
			lanes: {
				kick: "x...x...x...x...",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "xx.xxx.xxx.xxx.x",
				open: "..x...x...x...x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .003,
				release: .1,
				color: 1,
				detectorHp: 1,
				output: 5
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: .75,
				c: 1,
				d: .45
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 1,
				attack: 4,
				release: 1,
				output: 2
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("performance", "monarch"),
		...S("octaves", "bass"),
		...S("chords", "strings"),
		...T([
			["drums", "talon"],
			["bass", "brit"],
			["strings", "space"],
			["monarch", "echo"]
		], "cohere")
	]) : e === "Boom Bap" ? x(e, 84, .18, {
		performance: {
			type: "performance",
			steps: g("X.....x.X..x..x.", _([50, 8], [55, 6], [50, 2]), [
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.4,
				.5,
				.95,
				.5,
				.5,
				.4,
				.5,
				.5,
				.6,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 1,
				osc1Octave: -1,
				osc1Level: .8,
				osc2Wave: 0,
				osc2Octave: -1,
				osc2Detune: 0,
				osc2Level: .3,
				osc3Wave: 0,
				osc3Octave: -2,
				osc3Level: .55,
				cutoff: 420,
				resonance: .1,
				drive: .3,
				envAmount: .25,
				tracking: .4,
				filterDecay: .3,
				filterSustain: .3,
				ampAttack: .006,
				ampDecay: .5,
				ampSustain: .75,
				ampRelease: .12,
				glide: .03,
				level: .8
			}
		},
		delay: {
			type: "delay",
			params: {
				time: v(84),
				feedback: .3,
				mix: .18
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 50,
				kickDecay: .55,
				snareTone: .4,
				snappy: .45,
				hatDecay: .05,
				level: .85
			},
			lanes: {
				kick: "x.....x...x..x..",
				snare: "....x.......x...",
				hat: "x.x.x.x.x.x.x.xx"
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .8,
				woodTune: 3,
				woodLevel: .4,
				shakerDecay: .08,
				shakerLevel: .5
			},
			euclid: {
				wood: [
					3,
					16,
					3
				],
				shaker: [
					8,
					16,
					1
				]
			}
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .1,
				brightness: .8,
				velocity: .75,
				lfoRate: 4.5,
				lfoDepth: .03,
				chord: 4,
				level: .7,
				...b.epiano
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 3,
				midFreq: 1,
				midGain: 2,
				hfGain: -6,
				drive: 10,
				output: 4
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .006,
				release: .15,
				color: 2,
				detectorHp: 1,
				output: 5
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: .5,
				c: .45,
				d: 1
			}
		},
		valve: {
			type: "compressor",
			params: {
				input: 1,
				threshold: -16,
				time: 1,
				output: 1
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("performance", "monarch"),
		...S("performance", "prism", 3),
		...T([
			["boom", "talon"],
			[
				"prism",
				"brit",
				"delay"
			],
			["monarch"],
			["orbit"]
		], "valve")
	]) : e === "Late Night Hip-Hop" ? x(e, 72, .24, {
		performance: {
			type: "performance",
			steps: g("X.....o.X....x..", _([41, 8], [39, 5], [46, 3]), [
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.95,
				.5,
				.5,
				.5,
				.5,
				.7,
				.5,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 1,
				osc1Level: .8,
				osc2Wave: 0,
				osc2Detune: 0,
				osc2Level: .3,
				osc3Wave: 0,
				osc3Level: .4,
				cutoff: 520,
				resonance: .1,
				drive: .12,
				envAmount: .3,
				filterDecay: .4,
				ampAttack: .008,
				ampDecay: .6,
				ampSustain: .8,
				ampRelease: .25,
				glide: .05,
				level: .8
			}
		},
		chords: {
			type: "performance",
			steps: g("x.......x.....o.", _([57, 8], [55, 8]), .95)
		},
		keys: {
			type: "aurora",
			params: {
				osc1Wave: 1,
				osc1Width: .3,
				osc2Wave: 2,
				osc2Octave: 1,
				blend: .4,
				cutoff: 1400,
				envAmount: .25,
				filterAttack: .01,
				filterDecay: 1.2,
				ampAttack: .06,
				ampDecay: 1.5,
				ampSustain: .6,
				ampRelease: 2,
				lfoWidth: .35,
				lfoFilter: .05,
				chord: 2,
				vintage: .5,
				level: .6
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 3,
				midFreq: 0,
				midGain: -3,
				hfGain: -5,
				drive: 8,
				output: 3
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2.4,
				mix: .3
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 47,
				kickDecay: .7,
				snareTone: .3,
				snappy: .35,
				hatDecay: .04,
				openDecay: .3,
				level: .85
			},
			lanes: {
				kick: "x......x..x.....",
				snare: "....x.......x...",
				rim: "..............x.",
				hat: "..x...x...x...x."
			}
		},
		orbit: {
			type: "orbit",
			params: {
				pitch: -4,
				level: .8,
				shakerLevel: .5
			},
			euclid: { shaker: [
				6,
				16,
				2
			] }
		},
		talon: {
			type: "talon",
			params: {
				input: 4,
				ratio: 5,
				attack: .01,
				release: .4,
				color: 1,
				output: 9
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: .6,
				c: .55,
				d: 1
			}
		},
		console: {
			type: "equalizer",
			params: {
				hpf: 25,
				lpf: 9e3,
				lfGain: 1.5,
				lfFreq: 120,
				lfBell: 1,
				hfGain: -2,
				hfFreq: 6e3
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -18,
				ratio: 0,
				attack: 4,
				release: 4,
				output: 3
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("performance", "monarch"),
		...S("chords", "keys"),
		...T([
			["boom", "talon"],
			["monarch"],
			[
				"keys",
				"brit",
				"space"
			],
			["orbit"]
		], "console", "cohere")
	]) : e === "Roots Reggae" ? x(e, 76, .2, {
		performance: {
			type: "performance",
			steps: g("..X...x.X..x.xx.", [
				33,
				33,
				33,
				33,
				33,
				33,
				36,
				36,
				38,
				38,
				38,
				38,
				38,
				41,
				40,
				40
			], [
				.65,
				.65,
				.85,
				.65,
				.65,
				.65,
				.5,
				.65,
				.85,
				.65,
				.65,
				.45,
				.65,
				.5,
				.85,
				.65
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 1,
				osc1Level: .7,
				osc2Wave: 0,
				osc2Octave: 1,
				osc2Detune: 0,
				osc2Level: .15,
				osc3Wave: 0,
				osc3Octave: 0,
				osc3Level: .5,
				cutoff: 520,
				resonance: .05,
				drive: .15,
				envAmount: .15,
				filterDecay: .3,
				ampAttack: .006,
				ampDecay: .35,
				ampSustain: .7,
				ampRelease: .12,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 3,
				midFreq: 0,
				midGain: -3,
				hfGain: -4,
				drive: 4
			}
		},
		bubble: {
			type: "performance",
			steps: g("..xx..xx..xx..xx", _([57, 8], [50, 8]), .6)
		},
		organ: {
			type: "aurora",
			params: {
				osc1Wave: 1,
				osc2Wave: 3,
				osc2Octave: 1,
				osc2Detune: 0,
				blend: .5,
				cutoff: 2600,
				resonance: 0,
				slope: 0,
				envAmount: 0,
				ampAttack: .003,
				ampDecay: .2,
				ampSustain: .85,
				ampRelease: .04,
				lfoRate: 6,
				lfoPitch: .01,
				lfoWidth: 0,
				chord: 2,
				vintage: .2,
				level: .45
			}
		},
		skank: {
			type: "performance",
			steps: g("....X.......X...", _([69, 8], [62, 8]), .35)
		},
		guitar: {
			type: "oracle",
			params: {
				bShape: 2,
				bFine: 5,
				cutoff: 2800,
				resonance: .2,
				envAmount: .3,
				filterDecay: .12,
				filterSustain: 0,
				ampAttack: .002,
				ampDecay: .14,
				ampSustain: 0,
				ampRelease: .08,
				chord: 2,
				level: 1
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(76),
				feedback: .4,
				mix: .3
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 1.6,
				mix: .22
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 46,
				kickDecay: .6,
				snareTone: .5,
				hatDecay: .05,
				openDecay: .35,
				level: .85
			},
			lanes: {
				kick: "........x.......",
				rim: "........x.......",
				hat: "x.x.x...x.x.x..x",
				open: "......x.......x."
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .8,
				metalDecay: .09,
				metalTone: .7,
				metalLevel: .5,
				sandDecay: .06,
				sandLevel: .55
			},
			euclid: {
				metal: [
					2,
					16,
					4
				],
				sand: [
					2,
					16,
					4
				]
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 1,
				ratio: 2,
				attack: .01,
				release: .25,
				color: 1,
				output: 6
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: 1,
				c: .8,
				d: .7,
				e: .9
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 0,
				attack: 4,
				release: 4,
				output: 2
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("performance", "monarch"),
		...S("bubble", "organ"),
		...S("skank", "guitar"),
		...T([
			["boom", "talon"],
			["orbit"],
			["monarch", "brit"],
			["organ"],
			[
				"guitar",
				"echo",
				"space"
			]
		], "cohere")
	]) : e === "Dub Session" ? x(e, 70, .18, {
		performance: {
			type: "performance",
			steps: g("X..x..x.X..x..x.", [
				28,
				28,
				28,
				28,
				28,
				28,
				31,
				31,
				33,
				33,
				33,
				31,
				31,
				31,
				26,
				26
			], [
				.85,
				.5,
				.5,
				.4,
				.5,
				.5,
				.6,
				.5,
				.85,
				.5,
				.5,
				.5,
				.5,
				.5,
				.7,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 0,
				osc1Level: .7,
				osc2Wave: 1,
				osc2Octave: 1,
				osc2Detune: 0,
				osc2Level: .12,
				osc3Wave: 0,
				osc3Octave: 0,
				osc3Level: .45,
				cutoff: 300,
				resonance: .1,
				drive: .25,
				envAmount: .1,
				ampAttack: .01,
				ampDecay: .4,
				ampSustain: .8,
				ampRelease: .2,
				glide: .02,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 3,
				midFreq: 0,
				midGain: -3,
				hfGain: -8,
				drive: 6
			}
		},
		skank: {
			type: "performance",
			steps: g("....x.......x...", _([64, 16]), .3)
		},
		guitar: {
			type: "oracle",
			params: {
				bShape: 2,
				bFine: 5,
				cutoff: 2400,
				resonance: .2,
				envAmount: .3,
				filterDecay: .12,
				filterSustain: 0,
				ampAttack: .002,
				ampDecay: .15,
				ampSustain: 0,
				ampRelease: .1,
				chord: 2,
				level: 1
			}
		},
		repeats: {
			type: "delay",
			params: {
				time: Number((60 / 70).toFixed(3)),
				feedback: .6,
				mix: .4
			}
		},
		melody: {
			type: "performance",
			steps: g("X.....X.X.X...X.", [
				71,
				71,
				71,
				71,
				71,
				71,
				74,
				74,
				71,
				71,
				69,
				69,
				69,
				69,
				67,
				67
			], .95)
		},
		melodica: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: 0,
				brightness: .9,
				velocity: .5,
				lfoRate: 5,
				lfoDepth: .12,
				level: 1,
				...b.reed
			}
		},
		hall: {
			type: "reverb",
			params: {
				decay: 2.2,
				mix: .3
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 45,
				kickDecay: 1.2,
				snareTone: .35,
				snappy: .5,
				hatDecay: .06,
				openDecay: .5,
				level: .8
			},
			lanes: {
				kick: "x..x......x.....",
				snare: "....x.......x...",
				rim: ".......x........",
				hat: "x.x.x.x.x.x.x...",
				open: "..............x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 3,
				ratio: 2,
				attack: .003,
				release: .2,
				color: 2,
				output: 8
			}
		},
		reverb: {
			type: "reverb",
			params: {
				decay: 1.4,
				mix: .2
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .9,
				skinTune: 5,
				skinDecay: .25,
				skinLevel: 1,
				woodLevel: .5
			},
			euclid: {
				skin: [
					1,
					16,
					12
				],
				wood: [
					2,
					16,
					6
				]
			}
		},
		delay: {
			type: "delay",
			params: {
				time: v(70),
				feedback: .55,
				mix: .45
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: 1,
				c: .7,
				d: 1,
				e: 1
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 0,
				attack: 4,
				release: 4,
				output: 2
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("performance", "monarch"),
		...S("skank", "guitar"),
		...S("melody", "melodica"),
		...T([
			[
				"boom",
				"talon",
				"reverb"
			],
			["orbit", "delay"],
			["monarch", "brit"],
			["guitar", "repeats"],
			["melodica", "hall"]
		], "cohere")
	]) : e === "Trap Soul" ? x(e, 68, .06, {
		performance: {
			type: "performance",
			steps: g("X.......X.....x.", _([53, 8], [58, 8]), [
				.95,
				.65,
				.65,
				.65,
				.65,
				.65,
				.65,
				.65,
				.95,
				.65,
				.65,
				.65,
				.65,
				.65,
				.6,
				.65
			])
		},
		oracle: {
			type: "oracle",
			params: {
				aLevel: .7,
				bLevel: .6,
				bFine: 6,
				noise: .03,
				cutoff: 1300,
				resonance: .12,
				envAmount: .3,
				tracking: .4,
				filterAttack: .005,
				filterDecay: .9,
				filterSustain: .25,
				filterRelease: 1.6,
				ampAttack: .01,
				ampDecay: 1.2,
				ampSustain: .6,
				ampRelease: 2.4,
				lfoRate: .35,
				lfoAmount: .12,
				lfoDest: 2,
				vintage: .45,
				chord: 4,
				level: 1
			}
		},
		equalizer: {
			type: "equalizer",
			params: {
				hpf: 140,
				lmfGain: -3,
				lmfFreq: 380,
				lmfQ: 1.2,
				hmfGain: 2,
				hmfFreq: 2800,
				hmfQ: .8,
				hfGain: 3,
				hfFreq: 9e3,
				lpf: 16e3,
				output: 4
			}
		},
		reverb: {
			type: "reverb",
			params: {
				decay: 2.6,
				mix: .3
			}
		},
		performance2: {
			type: "performance",
			steps: g("X.....x.X..x..x.", [
				53,
				53,
				53,
				53,
				53,
				53,
				53,
				53,
				58,
				58,
				58,
				56,
				56,
				56,
				60,
				60
			], [
				.95,
				.65,
				.65,
				.65,
				.65,
				.65,
				.6,
				.65,
				.95,
				.65,
				.65,
				.5,
				.65,
				.65,
				.5,
				.65
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 0,
				osc1Octave: -2,
				osc1Level: .8,
				osc2Wave: 1,
				osc2Octave: -1,
				osc2Detune: 0,
				osc2Level: .12,
				osc3Level: 0,
				cutoff: 700,
				resonance: 0,
				drive: .55,
				envAmount: .1,
				tracking: .3,
				ampAttack: .003,
				ampDecay: .8,
				ampSustain: .75,
				ampRelease: 1.1,
				glide: .07,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 2,
				midFreq: 1,
				midGain: 4,
				drive: 12,
				output: -2
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 52,
				kickDecay: .32,
				snareTone: .65,
				snappy: .8,
				hatDecay: .035,
				openDecay: .3,
				level: .8
			},
			lanes: {
				kick: "x.....x.x.....x.",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "x.x.x.xxx.x.x.xx",
				open: "...........x...."
			}
		},
		compressor: {
			type: "compressor",
			params: {
				input: 3,
				threshold: -26,
				time: 1,
				output: 8
			}
		},
		bells: {
			type: "performance",
			steps: g("..X...X...X..X..", [
				84,
				84,
				84,
				84,
				84,
				84,
				80,
				80,
				80,
				80,
				82,
				82,
				82,
				77,
				77,
				77
			], .5)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .05,
				brightness: 1,
				velocity: .6,
				level: 1,
				...b.bell
			}
		},
		delay: {
			type: "delay",
			params: {
				time: v(68),
				feedback: .4,
				mix: .3
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: .55,
				c: 1,
				d: 1
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -18,
				ratio: 0,
				attack: 4,
				release: 4,
				scHpf: 2,
				output: 2
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("performance", "oracle"),
		...S("performance2", "monarch"),
		...S("bells", "prism"),
		...T([
			[
				"oracle",
				"equalizer",
				"reverb"
			],
			["monarch", "brit"],
			["boom", "compressor"],
			["prism", "delay"]
		], "cohere")
	]) : e === "Broken Beat" ? x(e, 108, .1, {
		performance: {
			type: "performance",
			steps: g("X..x..x...x..x.x", [
				36,
				36,
				36,
				48,
				48,
				48,
				34,
				34,
				34,
				34,
				41,
				41,
				41,
				44,
				44,
				43
			], .4)
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Wave: 3,
				osc2Detune: 5,
				osc2Level: .35,
				osc3Wave: 0,
				osc3Level: .45,
				cutoff: 700,
				resonance: .35,
				drive: .3,
				envAmount: .55,
				filterDecay: .14,
				filterSustain: .15,
				ampAttack: .003,
				ampDecay: .2,
				ampSustain: .4,
				ampRelease: .06,
				level: .7
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 2,
				lfGain: 2,
				midFreq: 2,
				midGain: 3,
				drive: 8
			}
		},
		stabs: {
			type: "performance",
			steps: g("X..x...x..x..x..", _([48, 7], [53, 9]), .4)
		},
		keys: {
			type: "oracle",
			params: {
				aShape: 2,
				bFine: 8,
				cutoff: 1800,
				resonance: .15,
				envAmount: .45,
				filterDecay: .25,
				filterSustain: .2,
				ampAttack: .003,
				ampDecay: .35,
				ampSustain: .3,
				ampRelease: .25,
				chord: 4,
				vintage: .4,
				level: .9
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(108),
				feedback: .3,
				mix: .2
			}
		},
		punch: {
			type: "punch",
			params: {
				kickTune: 54,
				kickClick: .55,
				kickDecay: .4,
				snareTone: .55,
				snappy: .65,
				hatDecay: .04,
				openDecay: .2,
				level: .85
			},
			lanes: {
				kick: "x.....x..x...x..",
				snare: "....x.......x...",
				clap: "....x..........x",
				hat: "x.xxx.x.x.xxx.x.",
				open: ".....x.......x.."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .004,
				release: .12,
				color: 2,
				detectorHp: 1,
				output: 5
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .5,
				skinTune: 5,
				tomTune: 7,
				sandLevel: .6
			},
			euclid: {
				skin: [3, 8],
				tom: [
					2,
					16,
					3
				],
				sand: [5, 12]
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: .5,
				c: .85,
				d: .8
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 1,
				attack: 4,
				release: 1,
				output: 2
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("performance", "monarch"),
		...S("stabs", "keys"),
		...T([
			["punch", "talon"],
			["orbit"],
			["monarch", "brit"],
			["keys", "echo"]
		], "cohere")
	]) : x(e, 96, .08, {
		performance: {
			type: "performance",
			steps: g("X..X..X.X..X..X.", [
				62,
				62,
				62,
				65,
				65,
				65,
				69,
				69,
				67,
				67,
				67,
				72,
				72,
				72,
				69,
				69
			], .5)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: 0,
				brightness: .9,
				velocity: .6,
				level: 1,
				...b.kalimba
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(96),
				feedback: .35,
				mix: .25
			}
		},
		bass: {
			type: "performance",
			steps: g("X......o..x.....", _([38, 10], [36, 6]), [
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.6,
				.5,
				.5,
				.95,
				.5,
				.5,
				.5,
				.5,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 0,
				osc1Level: .8,
				osc2Wave: 1,
				osc2Detune: 0,
				osc2Level: .2,
				osc3Level: 0,
				cutoff: 300,
				resonance: 0,
				drive: .2,
				envAmount: .1,
				ampAttack: .006,
				ampDecay: .6,
				ampSustain: .8,
				ampRelease: .2,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 2,
				midFreq: 1,
				midGain: 4,
				drive: 10
			}
		},
		boom: {
			type: "boom",
			params: {
				kickTune: 44,
				kickDecay: .9,
				level: .85
			},
			lanes: { kick: "x.......x......." }
		},
		talon: {
			type: "talon",
			params: {
				input: 3,
				ratio: 4,
				attack: .002,
				release: .2,
				color: 2,
				output: 4
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .65,
				woodLevel: .5,
				metalLevel: .35,
				shakerLevel: .45
			},
			euclid: {
				skin: [
					5,
					16,
					2
				],
				wood: [
					3,
					8,
					2
				],
				sand: [7, 12],
				metal: [2, 15],
				shaker: [
					9,
					16,
					2
				],
				tom: [
					3,
					14,
					1
				]
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .75,
				b: .8,
				c: 1,
				d: .6
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -18,
				ratio: 0,
				attack: 4,
				release: 4,
				output: 2
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("performance", "prism"),
		...S("bass", "monarch"),
		...T([
			["boom", "talon"],
			["orbit"],
			["prism", "echo"],
			["monarch", "brit"]
		], "cohere")
	]);
}
//#endregion
//#region src/retroPresets.ts
var D = (...e) => w(e, "mixer", "cohere", "main"), ee = {
	cohere: {
		type: "cohere",
		params: {
			threshold: -16,
			ratio: 0,
			attack: 4,
			release: 4,
			scHpf: 2,
			output: 2
		}
	},
	main: {
		type: "output",
		params: { volume: .7 }
	}
};
function te(e) {
	return e === "Neon Skyline" ? x(e, 112, 0, {
		pads: {
			type: "performance",
			steps: g("X.......X.......", _([57, 8], [52, 8]), .95)
		},
		aurora: {
			type: "aurora",
			params: {
				osc2Wave: 0,
				osc2Detune: 12,
				hpf: 150,
				cutoff: 2400,
				envAmount: .2,
				filterAttack: .1,
				filterDecay: 1.5,
				filterSustain: .5,
				ampAttack: .08,
				ampDecay: 1,
				ampSustain: .8,
				ampRelease: 2.2,
				lfoRate: .4,
				lfoWidth: .3,
				chord: 2,
				vintage: .5,
				level: .8
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2.6,
				mix: .35
			}
		},
		bass: {
			type: "performance",
			steps: g("X.x.X.x.X.x.X.x.", _([41, 8], [36, 8]), .55)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .2,
				brightness: 1,
				velocity: .6,
				level: 1,
				...b.bass
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 2,
				midFreq: 2,
				midGain: 2,
				hfGain: 1,
				drive: 8,
				output: 8
			}
		},
		arp: {
			type: "performance",
			steps: g("XxxxXxxxXxxxXxxx", [
				69,
				72,
				76,
				79,
				81,
				79,
				76,
				72,
				67,
				72,
				76,
				79,
				84,
				79,
				76,
				72
			], .5)
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 3,
				osc1Level: .7,
				osc2Detune: 5,
				osc2Level: .4,
				osc3Level: 0,
				cutoff: 2200,
				resonance: .3,
				envAmount: .4,
				filterDecay: .12,
				filterSustain: .1,
				ampAttack: .002,
				ampDecay: .18,
				ampSustain: .2,
				ampRelease: .12,
				level: .55
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(112),
				feedback: .35,
				mix: .3
			}
		},
		strike: {
			type: "strike",
			params: {
				level: 1,
				kickDecay: .4,
				snareTune: -2,
				snareDecay: .3,
				clapLevel: .5,
				hatLevel: .4,
				hatPan: .2,
				tambourineLevel: .3,
				tambourinePan: -.3
			},
			lanes: {
				kick: "x...x...x...x...",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "x.x.x.x.x.x.x.x.",
				tambourine: "....x.......x..."
			}
		},
		room: {
			type: "reverb",
			params: {
				decay: 1.2,
				mix: .3
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 0,
				ratio: 7,
				attack: 2e-4,
				release: .08,
				color: 2,
				output: 12
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: .75,
				c: .6,
				d: .45
			}
		},
		...ee
	}, [
		...S("pads", "aurora"),
		...S("bass", "prism"),
		...S("arp", "monarch"),
		...D([
			"strike",
			"room",
			"talon"
		], ["prism", "brit"], ["aurora", "space"], ["monarch", "echo"])
	]) : e === "Digital Boogie" ? x(e, 116, .12, {
		bass: {
			type: "performance",
			steps: g("X..x..x.X.xx..x.", [
				40,
				40,
				40,
				52,
				52,
				52,
				40,
				40,
				45,
				45,
				45,
				57,
				57,
				57,
				43,
				43
			], [
				.6,
				.5,
				.5,
				.3,
				.5,
				.5,
				.6,
				.5,
				.6,
				.5,
				.5,
				.3,
				.5,
				.5,
				.6,
				.5
			])
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .3,
				brightness: 1.1,
				velocity: .8,
				level: 1,
				...b.slap
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 2,
				lfGain: 2,
				midFreq: 3,
				midGain: 3,
				drive: 6,
				output: 8
			}
		},
		stabs: {
			type: "performance",
			steps: g("..X..x....X..x..", _([52, 8], [57, 8]), .6)
		},
		aurora: {
			type: "aurora",
			params: {
				osc2Detune: 8,
				cutoff: 2600,
				envAmount: .4,
				filterDecay: .2,
				filterSustain: .2,
				ampAttack: .003,
				ampDecay: .3,
				ampSustain: .2,
				ampRelease: .2,
				lfoWidth: .2,
				chord: 4,
				vintage: .35,
				level: .6
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 1.2,
				mix: .2
			}
		},
		strike: {
			type: "strike",
			params: {
				level: 1,
				kickDecay: .35,
				snareDecay: .25,
				clapLevel: .6,
				hatDecay: .05,
				hatLevel: .35,
				hatPan: .2,
				bellLevel: .35,
				bellPan: -.25
			},
			lanes: {
				kick: "x.....x.x.....x.",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "x".repeat(16),
				bell: "......x.......x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .003,
				release: .1,
				color: 1,
				detectorHp: 1,
				output: 9
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: .75,
				c: .75
			}
		},
		...ee
	}, [
		...S("bass", "prism"),
		...S("stabs", "aurora"),
		...D(["strike", "talon"], ["prism", "brit"], ["aurora", "space"])
	]) : e === "Midnight Ballad" ? x(e, 76, .04, {
		keys: {
			type: "performance",
			steps: g("X.....x.X.....x.", _([58, 8], [51, 8]), .9)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .08,
				brightness: .75,
				velocity: .75,
				lfoRate: 4.5,
				lfoDepth: .04,
				chord: 3,
				level: .7,
				...b.epiano
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(76),
				feedback: .25,
				mix: .15
			}
		},
		strings: {
			type: "performance",
			steps: g("X.......X.......", _([58, 8], [63, 8]), .95)
		},
		aurora: {
			type: "aurora",
			params: {
				osc1Wave: 0,
				osc2Wave: 0,
				osc2Detune: 10,
				hpf: 250,
				cutoff: 2200,
				envAmount: .15,
				filterAttack: .15,
				filterDecay: 1.5,
				filterSustain: .6,
				ampAttack: .12,
				ampDecay: 1.2,
				ampSustain: .8,
				ampRelease: 2.8,
				lfoRate: .3,
				lfoWidth: .3,
				chord: 1,
				vintage: .45,
				level: .8
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2.8,
				mix: .4
			}
		},
		bass: {
			type: "performance",
			steps: g("X.....x.X.....x.", _([34, 6], [41, 2], [39, 6], [46, 2]), [
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.8,
				.5,
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.8,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 1,
				osc1Level: .8,
				osc2Wave: 0,
				osc2Detune: 0,
				osc2Level: .3,
				osc3Wave: 0,
				osc3Level: .3,
				cutoff: 700,
				resonance: .15,
				drive: .15,
				envAmount: .25,
				filterDecay: .5,
				filterSustain: .4,
				ampAttack: .01,
				ampDecay: .8,
				ampSustain: .7,
				ampRelease: .3,
				glide: .08,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				lfFreq: 1,
				lfGain: 2,
				midFreq: 1,
				midGain: 2,
				hfGain: -3,
				drive: 4
			}
		},
		strike: {
			type: "strike",
			params: {
				level: .9,
				kickDecay: .45,
				snareTune: -3,
				snareDecay: .5,
				hatLevel: .35,
				hatPan: .2,
				rideLevel: .3,
				ridePan: -.2
			},
			lanes: {
				kick: "x.......x..x....",
				snare: "....x.......x...",
				hat: "x...x...x...x...",
				ride: "..x...x...x...x."
			}
		},
		room: {
			type: "reverb",
			params: {
				decay: 1.6,
				mix: .35
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 0,
				ratio: 6,
				attack: 5e-4,
				release: .12,
				color: 1,
				output: 8
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .75,
				b: 1,
				c: .55,
				d: .4
			}
		},
		...ee
	}, [
		...S("keys", "prism"),
		...S("strings", "aurora"),
		...S("bass", "monarch"),
		...D([
			"strike",
			"room",
			"talon"
		], ["prism", "echo"], ["aurora", "space"], ["monarch", "brit"])
	]) : e === "New Wave Motion" ? x(e, 132, 0, {
		bass: {
			type: "performance",
			steps: g("X.x.x.x.X.x.x.x.", [
				38,
				38,
				38,
				38,
				38,
				38,
				50,
				50,
				34,
				34,
				34,
				34,
				34,
				34,
				46,
				46
			], .6)
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Detune: 7,
				osc2Level: .5,
				osc3Wave: 3,
				osc3Level: .35,
				cutoff: 900,
				resonance: .3,
				drive: .35,
				envAmount: .45,
				filterDecay: .15,
				filterSustain: .3,
				ampAttack: .002,
				ampDecay: .15,
				ampSustain: .6,
				ampRelease: .05,
				level: .7
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 2,
				lfGain: 2,
				midFreq: 2,
				midGain: 4,
				hfGain: 2,
				drive: 10
			}
		},
		pad: {
			type: "performance",
			steps: g("x.......x.......", _([50, 16]), .95)
		},
		aurora: {
			type: "aurora",
			params: {
				osc1Wave: 1,
				osc1Width: .35,
				osc2Wave: 0,
				osc2Detune: 9,
				hpf: 180,
				cutoff: 2600,
				envAmount: .2,
				filterAttack: .15,
				filterDecay: 1,
				filterSustain: .5,
				ampAttack: .06,
				ampDecay: .8,
				ampSustain: .75,
				ampRelease: 1.6,
				lfoRate: .7,
				lfoWidth: .45,
				chord: 2,
				vintage: .35,
				level: .7
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 1.8,
				mix: .25
			}
		},
		hook: {
			type: "performance",
			steps: g("X..X..X...X..X..", [
				81,
				81,
				81,
				77,
				77,
				77,
				74,
				74,
				74,
				74,
				76,
				76,
				76,
				77,
				77,
				77
			], .6)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .05,
				brightness: 1.1,
				velocity: .6,
				level: 1,
				...b.bell
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(132),
				feedback: .35,
				mix: .25
			}
		},
		strike: {
			type: "strike",
			params: {
				level: 1,
				kickDecay: .35,
				snareDecay: .3,
				hatDecay: .05,
				hatLevel: .4,
				hatPan: .2,
				midTomPan: .3,
				lowTomPan: -.3
			},
			lanes: {
				kick: "x.......x.x.....",
				snare: "....x.......x...",
				hat: "x.x.x.x.x.x.x...",
				midTom: "..............x.",
				lowTom: "...............x"
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 4,
				attack: .002,
				release: .1,
				color: 2,
				detectorHp: 1,
				output: 10
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: .65,
				c: .55,
				d: .7
			}
		},
		...ee
	}, [
		...S("bass", "monarch"),
		...S("pad", "aurora"),
		...S("hook", "prism"),
		...D(["strike", "talon"], ["monarch", "brit"], ["aurora", "space"], ["prism", "echo"])
	]) : e === "Glass Arcade" ? x(e, 108, 0, {
		arp: {
			type: "performance",
			steps: g("XxxxXxxxXxxxXxxx", [
				72,
				76,
				79,
				83,
				84,
				83,
				79,
				76,
				69,
				72,
				76,
				79,
				81,
				79,
				76,
				72
			], .5)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: 0,
				brightness: 1.2,
				velocity: .6,
				level: 1,
				...b.bell,
				op1Decay: .6,
				op1Release: .4,
				op3Decay: .5,
				op3Release: .3
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(108),
				feedback: .4,
				mix: .3
			}
		},
		melody: {
			type: "performance",
			steps: g("X.x.x...X.x.xx..", [
				76,
				76,
				79,
				79,
				81,
				81,
				79,
				79,
				76,
				76,
				74,
				74,
				72,
				74,
				74,
				74
			], .75)
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 3,
				osc1Level: .8,
				osc2Wave: 3,
				osc2Detune: 6,
				osc2Level: .35,
				osc3Level: 0,
				cutoff: 3200,
				resonance: .15,
				envAmount: .2,
				filterDecay: .2,
				filterSustain: .6,
				ampAttack: .003,
				ampDecay: .2,
				ampSustain: .75,
				ampRelease: .1,
				glide: .02,
				level: .55
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 2,
				midFreq: 3,
				midGain: 3,
				hfGain: 2,
				drive: 4,
				output: 4
			}
		},
		bass: {
			type: "performance",
			steps: g("X.x.X.x.X.x.X.x.", [
				36,
				36,
				48,
				48,
				36,
				36,
				48,
				48,
				33,
				33,
				45,
				45,
				33,
				33,
				45,
				45
			], .55)
		},
		aurora: {
			type: "aurora",
			params: {
				osc1Wave: 1,
				osc1Width: .25,
				osc2Wave: 1,
				osc2Octave: -1,
				osc2Detune: 0,
				osc2Width: .5,
				blend: .4,
				cutoff: 1400,
				resonance: .2,
				envAmount: .4,
				filterDecay: .15,
				filterSustain: .2,
				ampAttack: .002,
				ampDecay: .2,
				ampSustain: .5,
				ampRelease: .06,
				lfoWidth: 0,
				level: 1
			}
		},
		strike: {
			type: "strike",
			params: {
				level: 1,
				kickDecay: .3,
				snareDecay: .22,
				hatDecay: .04,
				hatLevel: .4,
				hatPan: .2,
				openLevel: .35,
				openPan: .2
			},
			lanes: {
				kick: "x.....x.x.......",
				snare: "....x.......x...",
				hat: "x.x.x.x.x.x.x...",
				open: "..............x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 3,
				ratio: 3,
				attack: 3e-4,
				release: .1,
				color: 0,
				detectorHp: 1,
				output: 10
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .8,
				b: 1,
				c: .3,
				d: .85
			}
		},
		...ee
	}, [
		...S("arp", "prism"),
		...S("melody", "monarch"),
		...S("bass", "aurora"),
		...D(["strike", "talon"], ["prism", "echo"], ["monarch", "brit"], ["aurora"])
	]) : x(e, 96, .06, {
		pads: {
			type: "performance",
			steps: g("X.......X.......", _([50, 8], [55, 8]), .95)
		},
		aurora: {
			type: "aurora",
			params: {
				osc1Wave: 0,
				osc2Wave: 2,
				osc2Octave: 1,
				osc2Detune: 6,
				blend: .4,
				hpf: 120,
				cutoff: 2e3,
				envAmount: .15,
				filterAttack: .12,
				filterDecay: 1.5,
				filterSustain: .6,
				ampAttack: .1,
				ampDecay: 1.2,
				ampSustain: .8,
				ampRelease: 2.4,
				lfoRate: .25,
				lfoWidth: .3,
				lfoFilter: .05,
				chord: 3,
				vintage: .4,
				level: .8
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 2,
				midFreq: 0,
				midGain: -2,
				hfGain: 5,
				drive: 3
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2.8,
				mix: .35
			}
		},
		pluck: {
			type: "performance",
			steps: g("X.XX.X.XX.X.XX.X", [
				74,
				74,
				78,
				81,
				81,
				85,
				85,
				81,
				79,
				79,
				83,
				86,
				86,
				83,
				83,
				79
			], .5)
		},
		prism: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: 0,
				brightness: .9,
				velocity: .6,
				level: 1,
				...b.pluck,
				op1Level: 1
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(96),
				feedback: .45,
				mix: .3
			}
		},
		bass: {
			type: "performance",
			steps: g("X.....x.X.....x.", _([38, 8], [43, 8]), [
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5,
				.5
			])
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Wave: 0,
				osc1Level: .8,
				osc2Wave: 1,
				osc2Detune: 0,
				osc2Level: .25,
				osc3Level: 0,
				cutoff: 400,
				resonance: 0,
				drive: .1,
				envAmount: .1,
				ampAttack: .01,
				ampDecay: .6,
				ampSustain: .8,
				ampRelease: .3,
				glide: .04,
				level: .8
			}
		},
		orbit: {
			type: "orbit",
			params: {
				level: .9,
				woodTune: 5,
				woodLevel: .45,
				sandLevel: .5,
				shakerDecay: .08,
				shakerLevel: .55
			},
			euclid: {
				wood: [3, 8],
				sand: [
					5,
					16,
					2
				],
				shaker: [
					8,
					16,
					1
				]
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: .7,
				b: 1,
				c: .53,
				d: 1
			}
		},
		...ee,
		cohere: {
			type: "cohere",
			params: {
				threshold: -14,
				ratio: 0,
				attack: 5,
				release: 4,
				output: 1
			}
		}
	}, [
		...S("pads", "aurora"),
		...S("pluck", "prism"),
		...S("bass", "monarch"),
		...D([
			"aurora",
			"brit",
			"space"
		], ["prism", "echo"], ["monarch"], ["orbit"])
	]);
}
//#endregion
//#region src/studioPresets.ts
var ne = (...e) => w(e, "sum", "cohere", "main");
function re(e) {
	return e === "French Touch" ? x(e, 123, .08, {
		seq: {
			type: "performance",
			steps: g("X.xx.x.xX.x.X.xx", [
				33,
				33,
				45,
				33,
				33,
				43,
				43,
				45,
				38,
				38,
				50,
				38,
				48,
				48,
				45,
				43
			], .5)
		},
		stabs: {
			type: "performance",
			steps: g("..X..x.x..X..x..", _([57, 8], [62, 8]), .55)
		},
		bass: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Wave: 3,
				osc2Detune: 5,
				osc2Level: .45,
				osc3Wave: 3,
				osc3Level: .5,
				cutoff: 520,
				resonance: .35,
				drive: .35,
				envAmount: .55,
				tracking: .6,
				filterAttack: .003,
				filterDecay: .16,
				filterSustain: .12,
				filterRelease: .08,
				ampAttack: .003,
				ampDecay: .3,
				ampSustain: .7,
				ampRelease: .06,
				glide: .015,
				level: .75
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 2,
				lfGain: 2.5,
				midFreq: 1,
				midGain: 3,
				drive: 8,
				output: -2
			}
		},
		keys: {
			type: "aurora",
			params: {
				osc2Wave: 0,
				osc2Detune: 9,
				hpf: 180,
				cutoff: 2200,
				envAmount: .35,
				filterAttack: .002,
				filterDecay: .22,
				filterSustain: .2,
				ampAttack: .004,
				ampDecay: .35,
				ampSustain: .5,
				ampRelease: .22,
				lfoWidth: 0,
				chord: 4,
				vintage: .35,
				level: .75
			}
		},
		sieve: {
			type: "filter",
			params: {
				cutoff: 1100,
				resonance: 4.5
			}
		},
		sweep: {
			type: "lfo",
			params: {
				wave: 1,
				rate: .12
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(123),
				feedback: .3,
				mix: .2
			}
		},
		drums: {
			type: "punch",
			params: {
				kickTune: 52,
				kickClick: .45,
				kickDecay: .5,
				snappy: .6,
				hatDecay: .04,
				openDecay: .28,
				level: .85
			},
			lanes: {
				kick: "x...x...x...x...",
				clap: "....x.......x...",
				hat: "...x...x...x...x",
				open: "..x...x...x...x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .008,
				release: .12,
				color: 1,
				detectorHp: 1,
				output: 5
			}
		},
		sum: {
			type: "mixer",
			params: {
				a: .8,
				b: .9,
				c: .55
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 1,
				attack: 4,
				release: 1,
				output: 3
			}
		},
		main: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("seq", "bass"),
		...S("stabs", "keys"),
		[
			"sweep",
			"out",
			"sieve",
			"cv",
			.8
		],
		...ne(["drums", "talon"], [
			"keys",
			"sieve",
			"echo"
		], ["bass", "brit"])
	]) : e === "Distortion Disco" ? x(e, 116, 0, {
		seq: {
			type: "performance",
			steps: g("Xx.xX.x.Xx.xX.xx", [
				28,
				40,
				40,
				28,
				38,
				38,
				40,
				40,
				31,
				43,
				43,
				31,
				33,
				33,
				35,
				38
			], .6)
		},
		stabs: {
			type: "performance",
			steps: g("..X....x..X..x..", _([64, 8], [57, 8]), .7)
		},
		bass: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Detune: 14,
				osc2Level: .6,
				osc3Wave: 3,
				osc3Octave: 1,
				osc3Level: .3,
				cutoff: 650,
				resonance: .25,
				drive: 1,
				envAmount: .5,
				tracking: .7,
				filterDecay: .2,
				filterSustain: .3,
				ampAttack: .002,
				ampDecay: .2,
				ampSustain: .8,
				ampRelease: .05,
				level: .7
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 1,
				lfFreq: 2,
				lfGain: 3,
				midFreq: 1,
				midGain: 6,
				hfGain: -4,
				drive: 20,
				output: -2
			}
		},
		prophet: {
			type: "oracle",
			params: {
				bFine: 10,
				aLevel: .8,
				bLevel: .7,
				cutoff: 1400,
				resonance: .2,
				envAmount: .5,
				filterAttack: .005,
				filterDecay: .3,
				filterSustain: .3,
				filterRelease: .2,
				ampAttack: .004,
				ampDecay: .5,
				ampSustain: .55,
				ampRelease: .25,
				chord: 2,
				vintage: .45,
				level: .9
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 1.4,
				mix: .18
			}
		},
		drums: {
			type: "strike",
			params: {
				level: .85,
				kickDecay: .35,
				kickLevel: 1,
				snareDecay: .25,
				snareLevel: .85,
				clapLevel: .6,
				hatDecay: .06,
				hatLevel: .5,
				hatPan: -.15,
				openLevel: .45,
				tambourineLevel: .4,
				tambourinePan: .25
			},
			lanes: {
				kick: "x...x...x...x...",
				snare: "....x.......x...",
				clap: "....x.......x...",
				hat: "x.x.x.x.x.x.x...",
				open: "..............x.",
				tambourine: "..x...x...x...x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 8,
				ratio: 6,
				attack: .001,
				release: .1,
				color: 2,
				fierce: 1,
				detectorHp: 1,
				output: 5
			}
		},
		sum: {
			type: "mixer",
			params: {
				a: 1,
				b: .9,
				c: .6
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -18,
				ratio: 2,
				attack: 3,
				release: 1,
				output: 4
			}
		},
		main: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("seq", "bass"),
		...S("stabs", "prophet"),
		...ne(["drums", "talon"], ["prophet", "space"], ["bass", "brit"])
	]) : e === "Electro Pogo" ? x(e, 128, 0, {
		seq: {
			type: "performance",
			steps: g(".xXx.xXx.xXx.xXx", [
				38,
				38,
				50,
				38,
				38,
				38,
				50,
				38,
				34,
				34,
				46,
				34,
				36,
				36,
				48,
				36
			], .6)
		},
		hook: {
			type: "performance",
			steps: g("X.x.xx.x.X.xX.x.", [
				69,
				69,
				74,
				74,
				77,
				76,
				76,
				74,
				74,
				77,
				77,
				74,
				76,
				76,
				79,
				79
			], .7)
		},
		bass: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Detune: 8,
				osc2Level: .5,
				osc3Wave: 3,
				osc3Level: .45,
				cutoff: 500,
				resonance: .4,
				drive: .55,
				envAmount: .6,
				filterDecay: .12,
				filterSustain: .15,
				ampDecay: .18,
				ampSustain: .6,
				ampRelease: .04,
				level: .7
			}
		},
		lead: {
			type: "oracle",
			params: {
				bOctave: 1,
				bFine: 6,
				bLevel: .5,
				cutoff: 2600,
				resonance: .3,
				envAmount: .35,
				filterDecay: .25,
				filterSustain: .4,
				ampAttack: .003,
				ampDecay: .3,
				ampSustain: .65,
				ampRelease: .15,
				glide: .035,
				level: 1
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 2,
				midFreq: 3,
				midGain: 4,
				hfGain: 4,
				drive: 6,
				output: 6
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(128),
				feedback: .32,
				mix: .22
			}
		},
		drums: {
			type: "punch",
			params: {
				kickTune: 50,
				kickClick: .7,
				kickDecay: .45,
				snareTone: .6,
				snappy: .8,
				hatDecay: .035,
				openDecay: .2,
				level: .85
			},
			lanes: {
				kick: "x...x...x...x...",
				snare: "....x.......x..x",
				clap: "....x.......x...",
				hat: "xx.xxx.xxx.xxx.x",
				open: "..x...x...x...x."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 3,
				attack: .006,
				release: .09,
				color: 1,
				detectorHp: 1,
				output: 5
			}
		},
		sum: {
			type: "mixer",
			params: {
				a: .8,
				b: .8,
				c: .5
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -14,
				ratio: 1,
				attack: 5,
				release: 4,
				scHpf: 2,
				output: 2
			}
		},
		main: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("seq", "bass"),
		...S("hook", "lead"),
		...ne(["drums", "talon"], [
			"lead",
			"brit",
			"echo"
		], ["bass"])
	]) : x(e, 126, 0, {
		seq: {
			type: "performance",
			steps: g("XxxxXxxxXxxxXxxx", [
				36,
				48,
				36,
				48,
				36,
				48,
				36,
				48,
				32,
				44,
				32,
				44,
				34,
				46,
				34,
				46
			], .45)
		},
		hook: {
			type: "performance",
			steps: g("..X..x.x..X..x..", [
				75,
				75,
				75,
				75,
				75,
				74,
				74,
				72,
				72,
				72,
				75,
				75,
				75,
				74,
				74,
				74
			], .8)
		},
		bass: {
			type: "monarch",
			params: {
				osc1Wave: 3,
				osc1Level: .8,
				osc2Detune: -7,
				osc2Level: .5,
				osc3Wave: 3,
				osc3Level: .35,
				cutoff: 420,
				resonance: .75,
				drive: .6,
				envAmount: .7,
				tracking: .6,
				filterAttack: .002,
				filterDecay: .11,
				filterSustain: 0,
				filterRelease: .05,
				ampAttack: .002,
				ampDecay: .15,
				ampSustain: .5,
				ampRelease: .04,
				level: .7
			}
		},
		fm: {
			type: "prism",
			params: {
				algorithm: 0,
				feedback: .35,
				brightness: 1,
				velocity: .7,
				lfoRate: 5.5,
				lfoDepth: .12,
				level: .55,
				...y([
					1,
					0,
					.9,
					.005,
					.8,
					.6,
					.25
				], [
					1,
					0,
					.55,
					.02,
					.4,
					.35,
					.2
				], [
					1,
					9,
					.8,
					.005,
					.8,
					.6,
					.25
				], [
					3,
					0,
					.25,
					.003,
					.25,
					.1,
					.15
				], [
					2,
					-6,
					.35,
					.005,
					.6,
					.4,
					.25
				], [
					1,
					0,
					.35,
					.003,
					.3,
					.15,
					.15
				])
			}
		},
		brit: {
			type: "brit",
			params: {
				hpf: 2,
				midFreq: 1,
				midGain: 3,
				hfGain: 2,
				drive: 10,
				output: 12
			}
		},
		echo: {
			type: "delay",
			params: {
				time: v(126),
				feedback: .38,
				mix: .28
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 2.2,
				mix: .22
			}
		},
		drums: {
			type: "boom",
			params: {
				kickTune: 48,
				kickDecay: .4,
				snareTone: .6,
				snappy: .75,
				hatDecay: .05,
				level: .85
			},
			lanes: {
				kick: "x...x...x...x...",
				snare: "....x.......x...",
				clap: "....x.......x...",
				rim: "...x.....x...x..",
				hat: "x.x.x.x.x.x.x.x.",
				bell: "..x..x....x..x.."
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 2,
				ratio: 4,
				attack: .003,
				release: .15,
				color: 2,
				fierce: 1,
				detectorHp: 1,
				output: 8
			}
		},
		sum: {
			type: "mixer",
			params: {
				a: .8,
				b: .8,
				c: .42
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -16,
				ratio: 1,
				attack: 4,
				release: 1,
				scHpf: 2,
				output: 3
			}
		},
		main: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("seq", "bass"),
		...S("hook", "fm"),
		...ne(["drums", "talon"], [
			"fm",
			"brit",
			"echo",
			"space"
		], ["bass"])
	]);
}
//#endregion
//#region src/trapPresets.ts
var ie = (e, t, n) => ({
	performance: {
		type: "performance",
		steps: e
	},
	oscillator: {
		type: "oscillator",
		params: {
			wave: n.wave,
			octave: n.octave,
			level: 1
		}
	},
	filter: {
		type: "filter",
		params: {
			cutoff: n.cutoff,
			resonance: n.resonance
		}
	},
	amplifier: {
		type: "amplifier",
		params: { level: .8 }
	},
	envelope: {
		type: "envelope",
		params: {
			attack: n.attack,
			decay: n.decay,
			sustain: n.sustain,
			release: n.release
		}
	},
	delay: {
		type: "delay",
		params: {
			time: v(t),
			feedback: .38,
			mix: n.echo
		}
	},
	space: {
		type: "reverb",
		params: {
			decay: 2.6,
			mix: n.space
		}
	}
}), ae = [
	[
		"oscillator",
		"out",
		"filter",
		"in"
	],
	[
		"filter",
		"out",
		"amplifier",
		"in"
	],
	[
		"amplifier",
		"out",
		"delay",
		"in"
	],
	[
		"delay",
		"out",
		"space",
		"in"
	],
	[
		"performance",
		"pitch",
		"oscillator",
		"pitch"
	],
	[
		"performance",
		"gate",
		"envelope",
		"gate"
	],
	[
		"envelope",
		"out",
		"amplifier",
		"cv",
		1
	]
], oe = (e) => ({
	type: "monarch",
	params: {
		osc1Wave: 0,
		osc1Octave: 0,
		osc1Level: .9,
		osc2Wave: 1,
		osc2Octave: 1,
		osc2Detune: 0,
		osc2Level: .08,
		osc3Level: 0,
		cutoff: 700,
		resonance: 0,
		drive: .45,
		envAmount: .1,
		tracking: .3,
		ampAttack: .003,
		ampDecay: 1.2,
		ampSustain: .7,
		ampRelease: .9,
		glide: .06,
		level: .4,
		...e
	}
}), se = (e, t, n = {}) => ({
	type: "skitter",
	lanes: e,
	params: {
		...n,
		...Object.fromEntries(Object.entries(t).flatMap(([e, t]) => Object.entries(t).map(([t, n]) => [`${e}Roll${t}`, h(n)])))
	}
}), O = (e, t) => ({
	type: "boom",
	lanes: e,
	params: {
		kickTune: 49,
		kickDecay: .55,
		snareTone: .35,
		snappy: .55,
		hatDecay: .045,
		openDecay: .35,
		level: .85,
		...t
	}
}), ce = {
	cohere: {
		type: "cohere",
		params: {
			threshold: -18,
			ratio: 1,
			attack: 4,
			release: 4,
			scHpf: 2,
			output: 4
		}
	},
	output: {
		type: "output",
		params: { volume: .7 }
	}
};
function le(e) {
	return e === "High Dive" ? x(e, 76, 0, {
		...ie(g("X.x.x..x..x.x...", [
			76,
			76,
			74,
			74,
			72,
			72,
			72,
			69,
			69,
			69,
			72,
			72,
			76,
			76,
			76,
			76
		], [
			.6,
			.6,
			.6,
			.6,
			.8,
			.8,
			.8,
			.9,
			.9,
			.9,
			.6,
			.6,
			.9,
			.9,
			.9,
			.9
		]), 76, {
			wave: 1,
			octave: 0,
			cutoff: 2600,
			resonance: 2,
			attack: .002,
			decay: .5,
			sustain: .15,
			release: .45,
			echo: .3,
			space: .35
		}),
		chords: {
			type: "performance",
			steps: g("X.......X.......", _([60, 8], [53, 8]), .95)
		},
		aurora: {
			type: "aurora",
			params: {
				osc1Wave: 0,
				osc2Wave: 2,
				osc2Detune: 4,
				blend: .45,
				hpf: 220,
				cutoff: 1800,
				resonance: .1,
				envAmount: .15,
				filterAttack: .2,
				filterDecay: 1.4,
				filterSustain: .5,
				ampAttack: .25,
				ampDecay: 1.2,
				ampSustain: .75,
				ampRelease: 1.8,
				lfoRate: .3,
				lfoPitch: 0,
				lfoWidth: .2,
				chord: 1,
				vintage: .3,
				level: .5
			}
		},
		bass: {
			type: "performance",
			steps: g("X.....x...X.....", _([33, 8], [29, 8]), [
				.95,
				.6,
				.6,
				.6,
				.6,
				.6,
				.7,
				.6,
				.6,
				.6,
				.95,
				.6,
				.6,
				.6,
				.6,
				.6
			])
		},
		monarch: oe({ level: .32 }),
		skitter: se({
			hat: "x.x.x.x.x.x.xx.x",
			open: "..............x."
		}, { hat: { 2: "............xx.x" } }),
		boom: O({
			kick: "x.....x...x.....",
			snare: "....x.......x...",
			clap: "....x.......x..."
		}, {
			kickDecay: .45,
			snareTone: .5,
			snappy: .7
		}),
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: .9,
				c: .95,
				d: .8
			}
		},
		valve: {
			type: "compressor",
			params: {
				input: 0,
				threshold: -20,
				time: 2,
				output: 3
			}
		},
		output: ce.output
	}, [
		...ae,
		...S("chords", "aurora"),
		...S("bass", "monarch"),
		[
			"skitter",
			"trig",
			"boom",
			"trig"
		],
		...w([
			["boom"],
			["monarch"],
			["space"],
			["aurora"]
		], "mixer", "valve", "output")
	]) : e === "Deep End" ? x(e, 64, .04, {
		performance: {
			type: "performance",
			steps: g("..X.......x.x...", _([74, 10], [75, 2], [74, 4]), [
				.9,
				.9,
				.95,
				.9,
				.9,
				.9,
				.9,
				.9,
				.9,
				.9,
				.9,
				.9,
				.95,
				.9,
				.9,
				.9
			])
		},
		lead: {
			type: "monarch",
			params: {
				osc1Wave: 0,
				osc1Octave: 0,
				osc1Level: .8,
				osc2Wave: 1,
				osc2Octave: 0,
				osc2Detune: 7,
				osc2Level: .25,
				osc3Level: 0,
				cutoff: 2800,
				resonance: 0,
				drive: 0,
				envAmount: 0,
				tracking: .5,
				ampAttack: .012,
				ampDecay: 1.2,
				ampSustain: .4,
				ampRelease: 1.4,
				glide: .18,
				level: .75
			}
		},
		delay: {
			type: "delay",
			params: {
				time: v(64),
				feedback: .45,
				mix: .32
			}
		},
		space: {
			type: "reverb",
			params: {
				decay: 3,
				mix: .42
			}
		},
		bass: {
			type: "performance",
			steps: g("X.........x...x.", _([31, 10], [27, 4], [30, 2]), [
				.95,
				.6,
				.6,
				.6,
				.6,
				.6,
				.6,
				.6,
				.6,
				.6,
				.95,
				.6,
				.6,
				.6,
				.7,
				.6
			])
		},
		monarch: oe({
			drive: .55,
			glide: .08,
			ampDecay: 1.6,
			ampRelease: 1.4,
			level: .3
		}),
		skitter: se({
			hat: "x.x.x.x.x.x.x.xx",
			perc: "...........x...."
		}, { hat: {
			2: "...............x",
			3: "......x.........",
			4: "..........x.....",
			6: "..............x."
		} }, { rollFade: .4 }),
		boom: O({
			kick: "x.........x.....",
			snare: "....x.......x...",
			clap: "....x.......x..."
		}, {
			kickDecay: .6,
			snareTone: .25,
			snappy: .45
		}),
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: .8,
				c: 1
			}
		},
		valve: {
			type: "compressor",
			params: {
				input: 0,
				threshold: -20,
				time: 2,
				output: 3
			}
		},
		output: ce.output
	}, [
		...S("performance", "lead"),
		...S("bass", "monarch"),
		[
			"skitter",
			"trig",
			"boom",
			"trig"
		],
		...w([
			["boom"],
			["monarch"],
			[
				"lead",
				"delay",
				"space"
			]
		], "mixer", "valve", "output")
	]) : x(e, 72, .05, {
		...ie(g("X...x.x.X...x...", _([71, 4], [67, 2], [69, 2], [71, 4], [74, 4]), .9), 72, {
			wave: 0,
			octave: 0,
			cutoff: 3200,
			resonance: 1,
			attack: .02,
			decay: .8,
			sustain: .5,
			release: .6,
			echo: .25,
			space: .4
		}),
		chords: {
			type: "performance",
			steps: g("X.....x.X.....x.", _([55, 8], [48, 8]), [
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.7,
				.5,
				.95,
				.5,
				.5,
				.5,
				.5,
				.5,
				.7,
				.5
			])
		},
		oracle: {
			type: "oracle",
			params: {
				aShape: 0,
				aLevel: .6,
				bShape: 1,
				bFine: 4,
				bLevel: .7,
				cutoff: 2600,
				resonance: .1,
				envAmount: .35,
				tracking: .5,
				filterAttack: .002,
				filterDecay: .35,
				filterSustain: .1,
				ampAttack: .003,
				ampDecay: .9,
				ampSustain: .15,
				ampRelease: .8,
				vintage: .35,
				chord: 3,
				level: .75
			}
		},
		bass: {
			type: "performance",
			steps: g("X.......X.......", _([31, 8], [36, 8]), .5)
		},
		monarch: oe({
			ampRelease: .6,
			level: .32
		}),
		skitter: se({
			hat: "x.xxx.x.x.xxx.x.",
			open: ".......x........",
			synth: "x......x..x...x."
		}, {
			hat: { 3: "...x.......x...." },
			synth: { 2: "..............x." }
		}, { gate: .7 }),
		boom: O({
			kick: "x......x..x.....",
			snare: "....x.......x..."
		}, {
			kickDecay: .5,
			snareTone: .3,
			snappy: .5
		}),
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: .9,
				c: .8,
				d: .9
			}
		},
		...ce
	}, [
		...ae,
		...S("chords", "oracle"),
		[
			"bass",
			"pitch",
			"monarch",
			"pitch"
		],
		[
			"skitter",
			"trig",
			"boom",
			"trig"
		],
		[
			"skitter",
			"gate",
			"monarch",
			"gate"
		],
		...w([
			["boom"],
			["monarch"],
			["space"],
			["oracle"]
		], "mixer", "cohere", "output")
	]);
}
//#endregion
//#region src/industrialPresets.ts
function ue(e) {
	return e === "Rust Machine" ? x(e, 96, 0, {
		seq: {
			type: "performance",
			steps: g("X.xX..x.X.xX..xx", [
				28,
				28,
				40,
				28,
				28,
				28,
				31,
				31,
				28,
				28,
				40,
				34,
				34,
				34,
				33,
				31
			], [
				.6,
				.5,
				.4,
				.7,
				.5,
				.5,
				.5,
				.5,
				.6,
				.5,
				.4,
				.8,
				.5,
				.5,
				.45,
				.45
			])
		},
		bass: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Wave: 3,
				osc2Detune: 9,
				osc2Level: .5,
				osc3Wave: 2,
				osc3Octave: -1,
				osc3Level: .45,
				cutoff: 1400,
				resonance: .35,
				drive: .7,
				envAmount: .4,
				filterAttack: .002,
				filterDecay: .2,
				filterSustain: .3,
				ampAttack: .002,
				ampDecay: .3,
				ampSustain: .7,
				ampRelease: .05,
				level: .75
			}
		},
		fuzz: {
			type: "rust",
			params: {
				mode: 0,
				drive: .75,
				bias: .25,
				starve: .4,
				body: 180,
				tone: .45,
				mix: 1,
				level: .55
			}
		},
		lead: {
			type: "performance",
			steps: g("x...x...X.....x.", _([64, 4], [63, 4], [64, 6], [59, 2]), .9)
		},
		oscillator: {
			type: "oscillator",
			params: {
				wave: 2,
				octave: 0,
				tune: 0,
				fine: 9,
				level: .6
			}
		},
		filter: {
			type: "filter",
			params: {
				mode: 2,
				cutoff: 1500,
				resonance: 3
			}
		},
		amplifier: {
			type: "amplifier",
			params: { level: .8 }
		},
		envelope: {
			type: "envelope",
			params: {
				attack: .01,
				decay: .4,
				sustain: .6,
				release: .3
			}
		},
		grind: {
			type: "rust",
			params: {
				mode: 1,
				drive: .55,
				bias: .1,
				body: 900,
				tone: .5,
				mix: .85,
				level: .5
			}
		},
		delay: {
			type: "delay",
			params: {
				time: .31,
				feedback: .35,
				mix: .2
			}
		},
		forge: {
			type: "forge",
			params: {
				level: .95,
				drive: .55,
				room: .35,
				kickLevel: 1,
				snareLevel: .95,
				hatLevel: .55,
				hatPan: .25,
				crashLevel: .6,
				crashPan: -.3,
				anvilLevel: .45,
				anvilPan: .4,
				lowTomLevel: .8
			},
			lanes: {
				kick: "x.....x.x.....x.",
				snare: "....x.......x...",
				hat: "x.x.x.x.x.x.x.x.",
				crash: "x...............",
				anvil: "..........x.....",
				lowTom: "..............xx"
			}
		},
		mixer: {
			type: "mixer",
			params: {
				a: 1,
				b: .65,
				c: .8
			}
		},
		valve: {
			type: "compressor",
			params: {
				input: 2,
				threshold: -20,
				time: 1,
				output: -1
			}
		},
		output: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("seq", "bass"),
		[
			"lead",
			"pitch",
			"oscillator",
			"pitch"
		],
		[
			"lead",
			"gate",
			"envelope",
			"gate"
		],
		[
			"envelope",
			"out",
			"amplifier",
			"cv",
			1
		],
		...w([
			["forge"],
			["bass", "fuzz"],
			[
				"oscillator",
				"filter",
				"amplifier",
				"grind",
				"delay"
			]
		], "mixer", "valve", "output")
	]) : x(e, 120, 0, {
		riff: {
			type: "performance",
			steps: g("X.x.X.xxX.x.X.x.", [
				26,
				26,
				38,
				26,
				26,
				26,
				29,
				31,
				26,
				26,
				38,
				26,
				36,
				36,
				33,
				29
			], .55)
		},
		monarch: {
			type: "monarch",
			params: {
				osc1Level: .8,
				osc2Detune: -11,
				osc2Level: .6,
				osc3Wave: 3,
				osc3Octave: -1,
				osc3Level: .5,
				cutoff: 2200,
				resonance: .25,
				drive: .8,
				envAmount: .3,
				filterDecay: .18,
				filterSustain: .5,
				ampAttack: .002,
				ampDecay: .2,
				ampSustain: .8,
				ampRelease: .04,
				level: .75
			}
		},
		broken: {
			type: "rust",
			params: {
				mode: 4,
				drive: .7,
				bias: .4,
				starve: .15,
				body: 320,
				tone: .6,
				mix: 1,
				level: .5
			}
		},
		talon: {
			type: "talon",
			params: {
				input: 4,
				ratio: 4,
				attack: .002,
				release: .15,
				color: 2,
				output: 3
			}
		},
		stabs: {
			type: "performance",
			steps: g("X.....X...X.....", _([50, 6], [53, 4], [48, 6]), .4)
		},
		oracle: {
			type: "oracle",
			params: {
				aShape: 2,
				aLevel: .8,
				bLevel: .7,
				bFine: 12,
				cutoff: 3e3,
				resonance: .2,
				envAmount: .3,
				filterDecay: .3,
				filterSustain: .4,
				ampAttack: .002,
				ampDecay: .3,
				ampSustain: .5,
				ampRelease: .2,
				chord: 0,
				level: .65
			}
		},
		crush: {
			type: "rust",
			params: {
				mode: 3,
				drive: .45,
				crush: 4,
				body: 700,
				tone: .65,
				mix: .8,
				level: .5
			}
		},
		forge: {
			type: "forge",
			params: {
				level: 1,
				drive: .45,
				room: .3,
				kickLevel: 1,
				snareLevel: .95,
				chinaLevel: .55,
				chinaPan: .35,
				crashLevel: .6,
				crashPan: -.35,
				rideLevel: .4,
				ridePan: .25,
				highTomLevel: .8,
				highTomPan: -.2,
				lowTomLevel: .85,
				lowTomPan: .2,
				pedalLevel: .4
			},
			lanes: {
				kick: "x...x...x...x...",
				snare: "....x.......x..x",
				ride: "x.x.x.x.x.x.x...",
				pedal: "..x...x...x.....",
				china: "......x.........",
				crash: "x...............",
				highTom: "............x.x.",
				lowTom: ".............x.x"
			}
		},
		sum: {
			type: "mixer",
			params: {
				a: 1,
				b: .75,
				c: .38
			}
		},
		cohere: {
			type: "cohere",
			params: {
				threshold: -18,
				ratio: 1,
				attack: 3,
				release: 4,
				output: 5.5
			}
		},
		main: {
			type: "output",
			params: { volume: .7 }
		}
	}, [
		...S("riff", "monarch"),
		...S("stabs", "oracle"),
		...w([
			["forge"],
			[
				"monarch",
				"broken",
				"talon"
			],
			["oracle", "crush"]
		], "sum", "cohere", "main")
	]);
}
//#endregion
//#region src/model.ts
var k = (e, t, n, r, i, a = .01, o, s = !1) => ({
	id: e,
	label: t,
	min: n,
	max: r,
	initial: i,
	step: a,
	unit: o,
	logarithmic: s
}), A = (e, t, n, r) => ({
	id: e,
	label: t,
	choices: n,
	initial: r,
	min: 0,
	max: n.length - 1,
	step: 1
}), j = (e, t, n = "audio", r) => ({
	id: e,
	label: t,
	kind: n,
	direction: "in",
	scale: r
}), M = (e, t, n = "audio") => ({
	id: e,
	label: t,
	kind: n,
	direction: "out"
}), N = (e, t = 2) => Array.from({ length: t }, (t, n) => n ? {
	...e,
	id: `${e.id}${n + 1}`,
	copyOf: e.id
} : e), de = (e) => ({
	...e,
	legacyDefault: e.initial
}), P = (e, t) => ({
	id: `${e}Pattern`,
	label: "Pattern",
	min: 0,
	max: 65535,
	step: 1,
	initial: [...t].reduce((e, t, n) => t === "x" ? e | 1 << n : e, 0),
	pattern: !0,
	voice: e
}), fe = (e, t, n, r, i) => [
	{
		...k(`${e}Steps`, `${t} steps`, 1, 16, n, 1),
		voice: e
	},
	{
		...k(`${e}Hits`, `${t} hits`, 0, 16, r, 1),
		voice: e
	},
	{
		...k(`${e}Shift`, `${t} shift`, 0, 15, i, 1),
		voice: e
	}
], pe = [
	"Skin",
	"Wood",
	"Sand",
	"Metal",
	"Shaker",
	"Tom"
].map((e) => ({
	id: e.toLowerCase(),
	label: e
})), me = ({ id: e, label: t }, n) => {
	let [r, i, a] = [
		[
			16,
			5,
			2
		],
		[
			8,
			3,
			0
		],
		[
			12,
			8,
			0
		],
		[
			16,
			0,
			0
		],
		[
			16,
			0,
			0
		],
		[
			16,
			0,
			0
		]
	][n], o = (t) => ({
		...de(t),
		voice: e
	});
	return [
		...fe(e, t, r, i, a).map((e) => n > 2 ? o(e) : e),
		o(k(`${e}Tune`, `${t} tune`, -24, 24, 0, 1, "st")),
		o(k(`${e}Decay`, `${t} decay`, .02, 2, [
			.32,
			.07,
			.07,
			.5,
			.12,
			.4
		][n], .01, "s", !0)),
		o(k(`${e}Tone`, `${t} tone`, 0, 1, .5)),
		o(k(`${e}Level`, `${t} level`, 0, 1, 1)),
		o(A(`${e}Custom`, `${t} rhythm`, ["Euclidean", "Custom"], 0)),
		o(P(e, "................"))
	];
}, he = (e, t) => [
	k(`${e}Attack`, "Attack", .002, 2, .008, .001, "s", !0),
	k(`${e}Decay`, "Decay", .01, 3, .25, .01, "s", !0),
	k(`${e}Sustain`, "Sustain", 0, 1, e === "amp" ? .65 : .2),
	k(`${e}Release`, "Release", .01, 4, .2, .01, "s", !0)
].map((e) => ({
	...e,
	group: t
})), ge = [
	j("chain", "Chain in"),
	j("trig", "Trig in", "gate"),
	...N(M("out", "Drums out"))
], F = (e, t) => t.map((t) => ({
	...t,
	group: e
})), _e = [
	["Off", [0]],
	["Maj 7", [
		0,
		4,
		7,
		11
	]],
	["Min 7", [
		0,
		3,
		7,
		10
	]],
	["Maj 9", [
		0,
		4,
		7,
		11,
		14
	]],
	["Min 9", [
		0,
		3,
		7,
		10,
		14
	]],
	["Min 11", [
		0,
		3,
		10,
		14,
		17
	]],
	["Dom 9", [
		0,
		4,
		7,
		10,
		14
	]]
], ve = [
	["kick", "Kick"],
	["snare", "Snare"],
	["rim", "Sidestick"],
	["clap", "Clap"],
	["hat", "Closed hat"],
	["open", "Open hat"],
	["lowTom", "Low tom"],
	["midTom", "Mid tom"],
	["highTom", "High tom"],
	["lowConga", "Low conga"],
	["highConga", "High conga"],
	["cabasa", "Cabasa"],
	["tambourine", "Tambourine"],
	["bell", "Cowbell"],
	["crash", "Crash"],
	["ride", "Ride"]
].map(([e, t]) => ({
	id: e,
	label: t
})), ye = [
	"Three pairs",
	"Twin stacks",
	"Serial stack",
	"Shared modulation",
	"Branched",
	"Additive"
], be = [
	"a",
	"b",
	"c",
	"d",
	"e",
	"f",
	"g",
	"h"
], xe = (e) => `${e}Pan`, Se = [
	["kick", "Kick"],
	["snare", "Snare"],
	["clap", "Clap"],
	["hat", "Hat"],
	["open", "Open hat"],
	["perc", "Perc"],
	["synth", "Synth"]
].map(([e, t]) => ({
	id: e,
	label: t
})), Ce = {
	boom: {
		kick: "kick",
		snare: "snare",
		clap: "clap",
		hat: "hat",
		open: "open",
		perc: "rim"
	},
	punch: {
		kick: "kick",
		snare: "snare",
		clap: "clap",
		hat: "hat",
		open: "open"
	},
	strike: {
		kick: "kick",
		snare: "snare",
		clap: "clap",
		hat: "hat",
		open: "open",
		perc: "rim"
	},
	forge: {
		kick: "kick",
		snare: "snare",
		hat: "hat",
		open: "open",
		perc: "anvil"
	},
	orbit: {
		kick: "skin",
		snare: "sand",
		clap: "sand",
		hat: "shaker",
		open: "metal",
		perc: "wood"
	}
}, I = [
	["kick", "Kick"],
	["snare", "Snare"],
	["hat", "Closed hat"],
	["pedal", "Pedal hat"],
	["open", "Open hat"],
	["lowTom", "Floor tom"],
	["highTom", "Rack tom"],
	["crash", "Crash"],
	["china", "China"],
	["ride", "Ride"],
	["anvil", "Anvil"]
].map(([e, t]) => ({
	id: e,
	label: t
})), L = [
	2,
	3,
	4,
	6
], R = (e, t) => `${e}Roll${t}`, we = [
	"Fuzz",
	"Rectify",
	"Fold",
	"Crush",
	"Broken"
], Te = (e, t) => e.flatMap(({ id: e, label: n }) => [
	k(`${e}Tune`, "Tune", -24, 24, 0, 1, "st"),
	k(`${e}Decay`, "Decay", .03, 4, t(e), .01, "s", !0),
	k(`${e}Tone`, "Tone", 0, 1, .7),
	k(`${e}Level`, "Level", 0, 1, .8),
	k(`${e}Pan`, "Pan", -1, 1, 0)
].map((t) => ({
	...t,
	voice: e,
	label: `${n} ${t.label}`
}))), Ee = [
	["kick", "Kick"],
	["snare", "Snare"],
	["rim", "Rim"],
	["clap", "Clap"],
	["hat", "Hat"],
	["open", "Open"],
	["lowTom", "Lo tom"],
	["highTom", "Hi tom"],
	["crash", "Crash"],
	["ride", "Ride"],
	["bell", "Bell"]
].map(([e, t]) => ({
	id: e,
	label: t
})), z = {
	performance: {
		name: "STEP–16",
		subtitle: "PATTERN & NOTE CONTROLLER",
		color: "performance",
		params: [],
		ports: [...N(M("pitch", "Pitch · 1V/oct", "cv"), 3), ...N(M("gate", "Note gate", "gate"), 3)]
	},
	oscillator: {
		name: "SOLID",
		subtitle: "ANALOG OSCILLATOR",
		color: "oscillator",
		params: [
			A("wave", "Waveform", [
				"Sine",
				"Triangle",
				"Saw",
				"Square"
			], 2),
			k("octave", "Octave", -3, 3, 0, 1),
			k("tune", "Tune", -12, 12, 0, 1, "st"),
			k("fine", "Fine", -50, 50, 0, 1, "ct"),
			k("level", "Level", 0, 1, .7)
		],
		ports: [
			j("pitch", "Pitch · 1V/oct", "cv", 1200),
			j("fm", "FM", "cv", 1200),
			...N(M("out", "Audio out"))
		]
	},
	noise: {
		name: "STATIC",
		subtitle: "NOISE GENERATOR",
		color: "noise",
		params: [A("color", "Color", [
			"White",
			"Pink",
			"Brown"
		], 0), k("level", "Level", 0, 1, .4)],
		ports: [...N(M("out", "Audio out"))]
	},
	mixer: {
		name: "SUM",
		subtitle: "EIGHT CHANNEL MIXER",
		color: "mixer",
		params: [
			...be.map((e, t) => {
				let n = k(e, `Channel ${e.toUpperCase()}`, 0, 1, .7);
				return t > 2 ? de(n) : n;
			}),
			...be.map((e) => de(k(xe(e), `Channel ${e.toUpperCase()} pan`, -1, 1, 0))),
			de(k("master", "Mix bus", 0, 1, 1))
		],
		ports: [...be.map((e) => j(e, `Channel ${e.toUpperCase()}`)), ...N(M("out", "Mix out"))]
	},
	filter: {
		name: "SIEVE",
		subtitle: "MULTIMODE FILTER",
		color: "filter",
		params: [
			A("mode", "Mode", [
				"Low-pass",
				"High-pass",
				"Band-pass"
			], 0),
			k("cutoff", "Cutoff", 40, 18e3, 1400, 1, "Hz", !0),
			k("resonance", "Resonance", .1, 12, 2.5, .1)
		],
		ports: [
			j("in", "Audio in"),
			j("cv", "Cutoff CV", "cv", 2400),
			...N(M("out", "Audio out"))
		]
	},
	amplifier: {
		name: "LEVEL",
		subtitle: "VOLTAGE CONTROLLED AMPLIFIER",
		color: "amplifier",
		params: [k("level", "Level", 0, 1, .8)],
		ports: [
			j("in", "Audio in"),
			j("cv", "Amplitude CV", "cv", 1),
			...N(M("out", "Audio out"))
		]
	},
	envelope: {
		name: "CONTOUR",
		subtitle: "ADSR ENVELOPE",
		color: "envelope",
		params: [
			k("attack", "Attack", .002, 2, .01, .001, "s", !0),
			k("decay", "Decay", .01, 3, .2, .01, "s", !0),
			k("sustain", "Sustain", 0, 1, .5),
			k("release", "Release", .01, 4, .18, .01, "s", !0)
		],
		ports: [j("gate", "Note gate", "gate"), ...N(M("out", "Envelope CV", "cv"))]
	},
	lfo: {
		name: "PULSE",
		subtitle: "LOW FREQUENCY OSCILLATOR",
		color: "lfo",
		params: [A("wave", "Waveform", [
			"Sine",
			"Triangle",
			"Saw",
			"Square"
		], 0), k("rate", "Rate", .05, 20, 2, .05, "Hz", !0)],
		ports: [j("cv", "Rate CV", "cv", 5), ...N(M("out", "Modulation CV", "cv"))]
	},
	delay: {
		name: "ECHO",
		subtitle: "FEEDBACK DELAY",
		color: "delay",
		params: [
			k("time", "Time", .02, 1, .28, .01, "s"),
			k("feedback", "Feedback", 0, .85, .32),
			k("mix", "Mix", 0, 1, .22)
		],
		ports: [j("in", "Audio in"), ...N(M("out", "Audio out"))]
	},
	reverb: {
		name: "SPACE",
		subtitle: "STEREO REVERBERATOR",
		color: "reverb",
		params: [k("decay", "Decay", .2, 3, 1.5, .1, "s"), k("mix", "Mix", 0, 1, .25)],
		ports: [j("in", "Audio in"), ...N(M("out", "Audio out"))]
	},
	boom: {
		name: "BOOM",
		subtitle: "ANALOG DRUM MACHINE",
		color: "boom",
		ports: ge,
		drum: {
			mode: "steps",
			voices: Ee
		},
		params: [
			...F("Kick", [k("kickTune", "Tune", 30, 90, 49, 1, "Hz"), k("kickDecay", "Decay", .1, 2.5, .8, .01, "s", !0)]),
			...F("Snare", [k("snareTone", "Tone", 0, 1, .5), k("snappy", "Snappy", 0, 1, .6)]),
			...F("Hat decay", [k("hatDecay", "Closed", .02, .6, .06, .01, "s", !0), de(k("openDecay", "Open", .1, 1.2, .4, .01, "s", !0))]),
			...F("Toms", [de(k("tomTune", "Tune", -12, 12, 0, 1, "st")), de(k("tomDecay", "Decay", .1, 1.5, .45, .01, "s", !0))]),
			...F("Cymbal decay", [de(k("crashDecay", "Crash", .3, 3, 1.6, .01, "s", !0)), de(k("rideDecay", "Ride", .2, 2.5, 1, .01, "s", !0))]),
			...F("Bell", [k("bellTune", "Tune", -12, 12, 0, 1, "st")]),
			k("level", "Level", 0, 1, .8),
			P("kick", "x......x..x....."),
			P("snare", "....x.......x..."),
			P("hat", "x.x.x.x.x.x.x.x."),
			P("bell", "...........x..x."),
			...[
				"rim",
				"clap",
				"open",
				"lowTom",
				"highTom",
				"crash",
				"ride"
			].map((e) => de(P(e, "................")))
		]
	},
	punch: {
		name: "PUNCH",
		subtitle: "DANCE FLOOR DRUM MACHINE",
		color: "punch",
		ports: ge,
		drum: {
			mode: "steps",
			voices: [
				{
					id: "kick",
					label: "Kick"
				},
				{
					id: "snare",
					label: "Snare"
				},
				{
					id: "clap",
					label: "Clap"
				},
				{
					id: "hat",
					label: "Hat"
				},
				{
					id: "open",
					label: "Open"
				}
			]
		},
		params: [
			k("kickTune", "Kick tune", 40, 90, 55, 1, "Hz"),
			k("kickClick", "Kick click", 0, 1, .5),
			k("kickDecay", "Kick decay", .1, 1.2, .45, .01, "s", !0),
			k("snareTone", "Snare tone", 0, 1, .5),
			k("snappy", "Snappy", 0, 1, .7),
			k("hatDecay", "Hat decay", .02, .3, .05, .01, "s", !0),
			k("openDecay", "Open decay", .1, 1, .35, .01, "s", !0),
			k("level", "Level", 0, 1, .8),
			P("kick", "x...x...x...x..."),
			P("snare", "............x..x"),
			P("clap", "....x.......x..."),
			P("hat", "xx..xx..xx..xx.."),
			P("open", "..x...x...x...x.")
		]
	},
	orbit: {
		name: "ORBIT",
		subtitle: "EUCLIDEAN PERCUSSION",
		color: "orbit",
		ports: ge,
		drum: {
			mode: "euclid",
			voices: pe
		},
		params: [
			k("pitch", "Pitch", -12, 12, 0, 1, "st"),
			k("level", "Level", 0, 1, .7),
			...pe.flatMap(me)
		]
	},
	monarch: {
		name: "MONARCH",
		subtitle: "VINTAGE MONOSYNTH",
		color: "monarch",
		ports: [
			j("pitch", "Pitch · 1V/oct", "cv", 1200),
			j("gate", "Note gate", "gate"),
			j("cv", "Cutoff CV", "cv", 2400),
			...N(M("out", "Audio out"))
		],
		params: [
			...[
				1,
				2,
				3
			].flatMap((e) => [
				A(`osc${e}Wave`, "Waveform", [
					"Sine",
					"Triangle",
					"Saw",
					"Square"
				], 2),
				k(`osc${e}Octave`, "Octave", -3, 3, e === 3 ? -1 : 0, 1),
				k(`osc${e}Detune`, "Detune", -50, 50, e === 2 ? 7 : 0, 1, "ct"),
				k(`osc${e}Level`, "Level", 0, 1, e === 1 ? .7 : .35)
			].map((t) => ({
				...t,
				group: `Oscillator ${e}`
			}))),
			...[
				k("cutoff", "Cutoff", 40, 18e3, 1100, 1, "Hz", !0),
				k("resonance", "Resonance", 0, 1, .2),
				k("drive", "Drive", 0, 1, .25),
				k("envAmount", "Env amount", -1, 1, .5),
				k("tracking", "Key track", 0, 1, .5)
			].map((e) => ({
				...e,
				group: "Filter"
			})),
			...he("filter", "Filter envelope"),
			...he("amp", "Amplifier envelope"),
			...[
				k("noise", "Noise", 0, 1, 0),
				k("glide", "Glide", 0, 1, 0, .01, "s"),
				k("level", "Level", 0, 1, .7)
			].map((e) => ({
				...e,
				group: "Performance"
			}))
		]
	},
	oracle: {
		name: "ORACLE",
		subtitle: "FIVE-VOICE POLYSYNTH",
		color: "oracle",
		ports: [
			j("pitch", "Pitch · 1V/oct", "cv", 1200),
			j("gate", "Note gate", "gate"),
			j("cv", "Cutoff CV", "cv", 2400),
			...N(M("out", "Audio out"))
		],
		params: [
			...F("Poly-Mod", [
				k("polyEnv", "Filt env", 0, 1, 0),
				k("polyOscB", "Osc B", 0, 1, 0),
				A("polyDest", "Dest", [
					"Freq A",
					"Filter",
					"Both"
				], 0)
			]),
			...F("Oscillator A", [
				k("aOctave", "Octave", -2, 2, 0, 1),
				A("aShape", "Shape", [
					"Saw",
					"Pulse",
					"Saw + Pulse"
				], 0),
				k("aWidth", "Width", .05, .95, .5)
			]),
			...F("Oscillator B", [
				k("bOctave", "Octave", -2, 2, 0, 1),
				k("bFine", "Fine", -50, 50, 7, 1, "ct"),
				A("bShape", "Shape", [
					"Saw",
					"Triangle",
					"Pulse"
				], 0),
				k("bWidth", "Width", .05, .95, .5)
			]),
			...F("LFO", [
				k("lfoRate", "Rate", .05, 20, 4, .05, "Hz", !0),
				A("lfoShape", "Shape", [
					"Triangle",
					"Saw",
					"Square"
				], 0),
				k("lfoAmount", "Amount", 0, 1, 0),
				A("lfoDest", "Dest", [
					"Pitch",
					"PW",
					"Filter"
				], 0)
			]),
			...F("Mixer", [
				k("aLevel", "Osc A", 0, 1, .8),
				k("bLevel", "Osc B", 0, 1, .6),
				k("noise", "Noise", 0, 1, 0)
			]),
			...F("Filter", [
				k("cutoff", "Cutoff", 40, 18e3, 1600, 1, "Hz", !0),
				k("resonance", "Resonance", 0, 1, .15),
				k("envAmount", "Env amount", 0, 1, .4),
				k("tracking", "Key track", 0, 1, .5)
			]),
			...he("filter", "Filter envelope"),
			...he("amp", "Amplifier envelope"),
			...F("Voices", [
				k("glide", "Glide", 0, 1, 0, .01, "s"),
				k("vintage", "Vintage", 0, 1, .3),
				A("chord", "Chord", _e.map(([e]) => e), 0),
				k("level", "Level", 0, 1, .7)
			])
		]
	},
	aurora: {
		name: "AURORA",
		subtitle: "EIGHT-VOICE ANALOG POLYSYNTH",
		color: "aurora",
		ports: [
			j("pitch", "Pitch · 1V/oct", "cv", 1200),
			j("gate", "Note gate", "gate"),
			j("cv", "Cutoff CV", "cv", 2400),
			...N(M("out", "Audio out"))
		],
		params: [
			...[1, 2].flatMap((e) => F(`Oscillator ${e}`, [
				A(`osc${e}Wave`, "Waveform", [
					"Saw",
					"Pulse",
					"Triangle",
					"Sine"
				], e === 1 ? 0 : 1),
				k(`osc${e}Octave`, "Octave", -2, 2, 0, 1),
				k(`osc${e}Detune`, "Detune", -50, 50, e === 2 ? 6 : 0, 1, "ct"),
				k(`osc${e}Width`, "Width", .05, .95, .5)
			])),
			...F("Source mix", [
				k("blend", "Osc 1 / 2", 0, 1, .5),
				k("crossMod", "Cross mod", 0, 1, 0),
				k("hpf", "High-pass", 20, 3e3, 20, 1, "Hz", !0)
			]),
			...F("Filter", [
				k("cutoff", "Cutoff", 40, 18e3, 2200, 1, "Hz", !0),
				k("resonance", "Resonance", 0, 1, .15),
				A("slope", "Slope", ["12 dB", "24 dB"], 1),
				k("envAmount", "Env amount", -1, 1, .35),
				k("tracking", "Key track", 0, 1, .5)
			]),
			...he("filter", "Filter envelope"),
			...he("amp", "Amplifier envelope"),
			...F("LFO", [
				k("lfoRate", "Rate", .05, 20, .6, .05, "Hz", !0),
				A("lfoShape", "Waveform", [
					"Triangle",
					"Sine",
					"Square"
				], 0),
				k("lfoPitch", "Pitch", 0, 1, 0),
				k("lfoWidth", "PWM", 0, 1, .15),
				k("lfoFilter", "Filter", 0, 1, 0)
			]),
			...F("Voices", [
				k("glide", "Glide", 0, 1, 0, .01, "s"),
				k("vintage", "Vintage", 0, 1, .25),
				A("chord", "Chord", _e.map(([e]) => e), 0),
				k("level", "Level", 0, 1, .65)
			])
		]
	},
	strike: {
		name: "STRIKE",
		subtitle: "VINTAGE DIGITAL DRUM MACHINE",
		color: "strike",
		ports: ge,
		drum: {
			mode: "steps",
			voices: ve
		},
		params: [k("level", "Level", 0, 1, .8), ...ve.flatMap(({ id: e, label: t }) => [P(e, e === "kick" ? "x.......x.x....." : e === "snare" ? "....x.......x..." : e === "hat" ? "x.x.x.x.x.x.x.x." : "................"), ...[
			k(`${e}Tune`, "Tune", -24, 24, 0, 1, "st"),
			k(`${e}Decay`, "Decay", .03, 3, ["crash", "ride"].includes(e) ? 1.8 : e === "open" ? .45 : e === "hat" ? .08 : .35, .01, "s", !0),
			k(`${e}Tone`, "Tone", 0, 1, .7),
			k(`${e}Level`, "Level", 0, 1, .8),
			k(`${e}Pan`, "Pan", -1, 1, 0)
		].map((n) => ({
			...n,
			voice: e,
			label: `${t} ${n.label}`
		}))])]
	},
	prism: {
		name: "PRISM",
		subtitle: "SIX-OPERATOR FM SYNTH",
		color: "prism",
		ports: [
			j("pitch", "Pitch · 1V/oct", "cv", 1200),
			j("gate", "Note gate", "gate"),
			j("cv", "Brightness CV", "cv", 1),
			...N(M("out", "Audio out"))
		],
		params: [
			...F("Sound", [
				A("algorithm", "Algorithm", ye, 0),
				k("feedback", "Feedback", 0, 1, .08),
				k("brightness", "Brightness", 0, 2, .8),
				k("velocity", "Velocity", 0, 1, .7)
			]),
			...F("Performance", [
				k("lfoRate", "LFO rate", .05, 20, 5, .05, "Hz", !0),
				k("lfoDepth", "Vibrato", 0, 1, 0),
				A("chord", "Chord", _e.map(([e]) => e), 0),
				k("level", "Level", 0, 1, .65)
			]),
			...Array.from({ length: 6 }, (e, t) => {
				let n = `op${t + 1}`;
				return [
					k(`${n}Ratio`, "Ratio", .5, 16, t % 2 ? 2 : 1, .5),
					k(`${n}Detune`, "Detune", -50, 50, 0, 1, "ct"),
					k(`${n}Level`, "Level", 0, 1, t < 2 ? .8 : .4),
					k(`${n}Attack`, "Attack", .002, 2, .005, .001, "s", !0),
					k(`${n}Decay`, "Decay", .01, 3, t % 2 ? .35 : 1.2, .01, "s", !0),
					k(`${n}Sustain`, "Sustain", 0, 1, t % 2 ? .05 : .25),
					k(`${n}Release`, "Release", .01, 4, .25, .01, "s", !0)
				].map((e) => ({
					...e,
					voice: n
				}));
			}).flat()
		]
	},
	compressor: {
		name: "VALVE",
		subtitle: "VARIABLE-MU LIMITER",
		color: "compressor",
		ports: [j("in", "Audio in"), ...N(M("out", "Audio out"))],
		params: [
			k("input", "Input", -12, 18, 0, .5, "dB"),
			k("threshold", "Threshold", -40, 0, -18, .5, "dB"),
			A("time", "Time constant", [
				"1",
				"2",
				"3",
				"4",
				"5",
				"6"
			], 1),
			k("output", "Output", -12, 12, 0, .5, "dB")
		]
	},
	equalizer: {
		name: "CONSOLE",
		subtitle: "FOUR-BAND CHANNEL EQ",
		color: "equalizer",
		ports: [j("in", "Audio in"), ...N(M("out", "Audio out"))],
		params: [
			A("active", "EQ", ["In", "Out"], 0),
			k("output", "Output", -12, 12, 0, .5, "dB"),
			...F("Filters", [k("hpf", "High-pass", 16, 350, 16, 1, "Hz", !0), k("lpf", "Low-pass", 3e3, 22e3, 22e3, 10, "Hz", !0)]),
			...F("LF", [
				k("lfGain", "Gain", -15, 15, 0, .5, "dB"),
				k("lfFreq", "Freq", 30, 450, 100, 1, "Hz", !0),
				A("lfBell", "Shape", ["Shelf", "Bell"], 0)
			]),
			...F("LMF", [
				k("lmfGain", "Gain", -15, 15, 0, .5, "dB"),
				k("lmfFreq", "Freq", 200, 2500, 600, 1, "Hz", !0),
				k("lmfQ", "Q", .5, 4, 1, .1)
			]),
			...F("HMF", [
				k("hmfGain", "Gain", -15, 15, 0, .5, "dB"),
				k("hmfFreq", "Freq", 600, 7e3, 2500, 10, "Hz", !0),
				k("hmfQ", "Q", .5, 4, 1, .1)
			]),
			...F("HF", [
				k("hfGain", "Gain", -15, 15, 0, .5, "dB"),
				k("hfFreq", "Freq", 1500, 16e3, 8e3, 10, "Hz", !0),
				A("hfBell", "Shape", ["Shelf", "Bell"], 0)
			])
		]
	},
	cohere: {
		name: "COHERE",
		subtitle: "STEREO BUS COMPRESSOR",
		color: "cohere",
		ports: [j("in", "Audio in"), ...N(M("out", "Audio out"))],
		params: [...F("Dynamics", [
			k("threshold", "Threshold", -40, 10, -18, .5, "dB"),
			A("ratio", "Ratio", [
				"2:1",
				"4:1",
				"10:1"
			], 1),
			A("attack", "Attack", [
				"0.1 ms",
				"0.3 ms",
				"1 ms",
				"3 ms",
				"10 ms",
				"30 ms"
			], 4),
			A("release", "Release", [
				"0.1 s",
				"0.3 s",
				"0.6 s",
				"1.2 s",
				"Auto"
			], 4)
		]), ...F("Bus", [
			A("scHpf", "Detector HP", [
				"Off",
				"30 Hz",
				"60 Hz",
				"106 Hz",
				"125 Hz",
				"185 Hz"
			], 0),
			k("output", "Makeup", -12, 20, 0, .5, "dB"),
			A("active", "Process", ["In", "Bypass"], 0)
		])]
	},
	talon: {
		name: "TALON",
		subtitle: "HARMONIC DYNAMICS PROCESSOR",
		color: "talon",
		ports: [j("in", "Audio in"), ...N(M("out", "Audio out"))],
		params: [
			...F("Dynamics", [
				k("input", "Input", -12, 30, 0, .5, "dB"),
				A("ratio", "Ratio", [
					"1:1",
					"2:1",
					"3:1",
					"4:1",
					"6:1",
					"10:1 Opto",
					"20:1",
					"Crush"
				], 4),
				k("attack", "Attack", 5e-5, .03, .003, 5e-5, "s", !0),
				k("release", "Release", .05, 3.5, .3, .01, "s", !0)
			]),
			...F("Character", [
				A("color", "Harmonics", [
					"Clean",
					"Even",
					"Odd"
				], 0),
				A("audioHp", "Audio HP", ["Off", "65 Hz"], 0),
				A("fierce", "Fierce", ["Off", "On"], 0)
			]),
			...F("Detector", [
				A("detectorHp", "High-pass", ["Off", "80 Hz"], 0),
				A("detectorBand", "Emphasis", ["Off", "6 kHz"], 0),
				A("link", "Stereo link", ["Off", "On"], 1)
			]),
			...F("Output", [k("output", "Output", -30, 12, 0, .5, "dB"), A("active", "Process", ["In", "Bypass"], 0)])
		]
	},
	brit: {
		name: "BRIT",
		subtitle: "THREE-BAND CLASS A EQUALIZER",
		color: "brit",
		ports: [j("in", "Audio in"), ...N(M("out", "Audio out"))],
		params: [
			...F("Low shelf", [A("lfFreq", "Freq", [
				"35 Hz",
				"60 Hz",
				"110 Hz",
				"220 Hz"
			], 2), k("lfGain", "Gain", -16, 16, 0, .5, "dB")]),
			...F("Mid bell", [A("midFreq", "Freq", [
				"360 Hz",
				"700 Hz",
				"1.6 kHz",
				"3.2 kHz",
				"4.8 kHz",
				"7.2 kHz"
			], 2), k("midGain", "Gain", -18, 18, 0, .5, "dB")]),
			...F("High shelf · 12 kHz", [k("hfGain", "Gain", -16, 16, 0, .5, "dB")]),
			...F("Signal", [
				A("hpf", "High-pass", [
					"Off",
					"50 Hz",
					"80 Hz",
					"160 Hz",
					"300 Hz"
				], 0),
				k("drive", "Drive", 0, 24, 0, .5, "dB"),
				k("output", "Output", -18, 18, 0, .5, "dB"),
				A("active", "Process", ["In", "Bypass"], 0)
			])
		]
	},
	skitter: {
		name: "SKITTER",
		subtitle: "TRAP STEP SEQUENCER · 1/16 · 1/32 · ROLLS",
		color: "skitter",
		ports: [...N(M("trig", "Trig out · drums", "gate")), ...N(M("gate", "Synth gate", "gate"))],
		drum: {
			mode: "steps",
			voices: Se
		},
		params: [
			k("rollFade", "Roll fade", 0, 1, .35),
			k("gate", "Gate", .1, 1, .5),
			...Se.flatMap(({ id: e }) => [P(e, {
				snare: "....x.......x...",
				hat: "x.x.x.x.x.x.x.x."
			}[e] ?? "................"), ...L.map((t) => ({
				...P(e, "................"),
				id: R(e, t),
				label: `Roll ×${t}`
			}))])
		]
	},
	forge: {
		name: "FORGE",
		subtitle: "INDUSTRIAL DRUM KIT",
		color: "forge",
		ports: ge,
		drum: {
			mode: "steps",
			voices: I
		},
		params: [
			k("level", "Level", 0, 1, .8),
			k("drive", "Drive", 0, 1, .35),
			k("room", "Room", 0, 1, .2),
			...I.map(({ id: e }) => P(e, {
				kick: "x.......x.x.....",
				snare: "....x.......x...",
				hat: "x.x.x.x.x.x.x.x."
			}[e] ?? "................")),
			...Te(I, (e) => ({
				crash: 2.4,
				china: 1.6,
				ride: 2.6,
				open: .7,
				hat: .09,
				pedal: .12,
				lowTom: .7,
				highTom: .55,
				anvil: 1,
				kick: .5,
				snare: .45
			})[e] ?? .4)
		]
	},
	rust: {
		name: "RUST",
		subtitle: "INDUSTRIAL DISTORTION",
		color: "rust",
		ports: [
			j("in", "Audio in"),
			j("cv", "Drive CV", "cv", 4),
			...N(M("out", "Audio out"))
		],
		params: [
			A("mode", "Mode", we, 0),
			k("drive", "Drive", 0, 1, .6),
			k("bias", "Bias", 0, 1, .15),
			k("crush", "Bits", 2, 12, 6, 1),
			k("starve", "Starve", 0, 1, 0),
			k("body", "Body", 60, 2e3, 220, 1, "Hz", !0),
			k("tone", "Tone", 0, 1, .55),
			k("mix", "Mix", 0, 1, 1),
			k("level", "Level", 0, 1, .6)
		]
	},
	output: {
		name: "MAIN",
		subtitle: "STEREO MASTER OUTPUT",
		color: "output",
		params: [k("volume", "Master", 0, 1, .65)],
		ports: [j("in", "Audio in")]
	}
}, De = Object.keys(z).filter((e) => e !== "output"), Oe = 0, ke = (e = "module") => `${e}-${Date.now().toString(36)}-${++Oe}`, Ae = (e, t = ke()) => ({
	id: t,
	type: e,
	params: Object.fromEntries(z[e].params.map((e) => [e.id, e.initial]))
}), je = (e) => e === "performance" ? {
	...Ae(e),
	steps: Array.from({ length: 16 }, (e, t) => ({
		enabled: t % 4 == 0,
		note: 48,
		velocity: .8,
		gate: .5
	}))
} : Ae(e), Me = (e, t) => {
	let n = e.modules.findIndex((e) => e.id === t);
	return n === 0 || e.modules[n]?.type === "output";
}, Ne = (e, t) => e.modules[0].id === t ? e.sequencer.steps : e.modules.find((e) => e.id === t)?.steps ?? e.sequencer.steps;
function Pe(e, t, n) {
	return e.modules[0].id === t ? {
		...e,
		sequencer: {
			...e.sequencer,
			steps: n
		}
	} : {
		...e,
		modules: e.modules.map((e) => e.id === t ? {
			...e,
			steps: n
		} : e)
	};
}
var B = (e, t) => {
	let n = e.modules.find((e) => e.id === t.moduleId);
	return n && z[n.type].ports.find((e) => e.id === t.portId);
}, V = (e, t) => e.moduleId === t.moduleId && e.portId === t.portId;
function Fe(e, t) {
	let n = e.filter((e) => (e.copyOf ?? e.id) === (t.copyOf ?? t.id));
	return n.length > 1 ? n.indexOf(t) + 1 : null;
}
var Ie = (e, t) => e.cables.find((e) => V(e.from, t) || V(e.to, t));
function Le(e, t, n) {
	let r = B(e, t), i = B(e, n);
	if (!r || !i) return "That socket no longer exists.";
	if (r.direction !== "out" || i.direction !== "in") return "Connect an output to an input.";
	if (r.kind !== i.kind) return `A ${r.kind.toUpperCase()} output needs a ${r.kind.toUpperCase()} input.`;
	if (e.cables.some((e) => V(e.to, n))) return "That input already has a cable. Pull its plug out first.";
	if (e.cables.some((e) => V(e.from, t))) return "That output jack already has a cable. Use its spare jack, or pull the plug out first.";
	let a = /* @__PURE__ */ new Set(), o = (n) => n === t.moduleId || !a.has(n) && (a.add(n), e.cables.filter((e) => e.from.moduleId === n).some((e) => o(e.to.moduleId)));
	return o(n.moduleId) ? "External feedback loops are not supported. Use ECHO’s feedback control." : null;
}
function Re(e, t, n, r = 1) {
	let i = Le(e, t, n);
	if (i) throw Error(i);
	return {
		...e,
		cables: [...e.cables, {
			id: ke("cable"),
			from: t,
			to: n,
			amount: r
		}]
	};
}
function ze(e, t, n) {
	let r = B(e, t), i = B(e, n);
	return !r || !i || r.direction === i.direction ? null : r.direction === "out" ? {
		from: t,
		to: n
	} : {
		from: n,
		to: t
	};
}
function Be(e, t, n, r = null) {
	if (!B(e, t) || !B(e, n)) return "That socket no longer exists.";
	let i = ze(e, t, n);
	return i ? Le(r ? {
		...e,
		cables: e.cables.filter((e) => e.id !== r)
	} : e, i.from, i.to) : "Connect an output to an input.";
}
function Ve(e, t, n, r) {
	if (!e.cables.find((e) => e.id === t)) throw Error("That cable no longer exists.");
	let i = Be(e, n, r, t);
	if (i) throw Error(i);
	let a = ze(e, n, r);
	return {
		...e,
		cables: e.cables.map((e) => e.id === t ? {
			...e,
			...a
		} : e)
	};
}
function He(e, t) {
	return Me(e, t) ? e : {
		...e,
		modules: e.modules.filter((e) => e.id !== t),
		cables: e.cables.filter((e) => e.from.moduleId !== t && e.to.moduleId !== t)
	};
}
function Ue(e, t, n) {
	let r = [...e.modules], i = r.findIndex((e) => e.id === t), a = i + n;
	return i < 1 || a < 1 || a >= r.length - 1 || Me(e, t) ? e : ([r[i], r[a]] = [r[a], r[i]], {
		...e,
		modules: r
	});
}
var We = (e, t) => (e >> t & 1) == 1;
function H(e, t, n = 0) {
	let r = Math.max(1, Math.min(16, Math.round(e))), i = Math.max(0, Math.min(r, Math.round(t))), a = Math.round(n);
	return Array.from({ length: r }, (e, t) => ((t - a) % r + r) % r * i % r < i);
}
function Ge(e, t, n) {
	let r = e.params;
	return [...L].reverse().find((e) => We(r[R(t, e)] ?? 0, n)) ?? 1;
}
var Ke = (e, t) => qe(e, t).map((n) => [n, Ge(e, n, t % 16)]);
function qe(e, t) {
	let n = z[e.type].drum, r = e.params;
	return n ? n.voices.filter(({ id: i }) => {
		if (n.mode === "steps") return We(r[`${i}Pattern`], t % 16);
		let a = U(e, i);
		return a[t % a.length];
	}).map((e) => e.id) : [];
}
function U(e, t) {
	let n = e.params, r = n[`${t}Steps`];
	return n[`${t}Custom`] ? Array.from({ length: r }, (e, r) => We(n[`${t}Pattern`], r)) : H(r, n[`${t}Hits`], n[`${t}Shift`]);
}
function Je(e, t, n) {
	let r = e.params[`${t}Custom`] ? e.params[`${t}Pattern`] : U(e, t).reduce((e, t, n) => e | (t ? 1 << n : 0), 0);
	return {
		...e.params,
		[`${t}Custom`]: 1,
		[`${t}Pattern`]: r ^ 1 << n
	};
}
var Ye = (e) => [
	"performance",
	"oscillator",
	"monarch",
	"oracle",
	"aurora",
	"prism",
	"strike",
	"noise",
	"boom",
	"punch",
	"orbit",
	"forge"
].includes(e), Xe = (e) => [
	"oracle",
	"aurora",
	"prism"
].includes(e), Ze = (e) => e === "performance" || !!z[e].drum;
function Qe(e, t) {
	let n = /* @__PURE__ */ new Set([t]);
	for (let t of n) for (let r of e.cables) r.from.moduleId === t && B(e, r.from)?.kind === "audio" && n.add(r.to.moduleId);
	return n;
}
function $e(e, t) {
	let n = e.modules.find((e) => e.id === t);
	if (n?.type === "performance" || n?.type === "skitter") {
		let n = /* @__PURE__ */ new Set([t]);
		for (let t of n) for (let r of e.cables) r.from.moduleId === t && B(e, r.from)?.kind !== "audio" && n.add(r.to.moduleId);
		return [...n].some((n) => n !== t && $e(e, n));
	}
	let r = Qe(e, t);
	return e.modules.some((e) => e.type === "output" && r.has(e.id));
}
function et(e, t, n, r = null) {
	let i = ze(e, t, n);
	if (!i) throw Error("Connect an output to an input.");
	if (!r) return Re(e, i.from, i.to);
	let a = e.cables.find((e) => e.id === r);
	return a && V(a.from, i.from) && V(a.to, i.to) ? e : Ve(e, r, i.from, i.to);
}
var tt = {
	muted: /* @__PURE__ */ new Set(),
	soloed: /* @__PURE__ */ new Set()
}, nt = (e, t) => `${e}:${t}`, rt = (e, t) => `${e}:step:${t}`, it = /* @__PURE__ */ new Set([
	"oscillator",
	"noise",
	"boom",
	"punch",
	"orbit",
	"monarch",
	"oracle",
	"aurora",
	"prism",
	"strike",
	"forge"
]), at = (e) => it.has(e);
function ot(e, t) {
	let n = /* @__PURE__ */ new Set([t]);
	for (let t of n) for (let r of e.cables) r.from.moduleId === t && B(e, r.from)?.kind !== "audio" && n.add(r.to.moduleId);
	return n.delete(t), e.modules.filter((t) => it.has(t.type) && [...Qe(e, t.id)].some((e) => n.has(e))).map((e) => e.id);
}
function st(e, t) {
	let n = new Set(e.modules.map((e) => e.id)), r = new Set([...t.soloed].filter((e) => n.has(e)));
	for (let t of r) for (let n of e.cables) n.from.moduleId === t && B(e, n.from)?.kind !== "audio" && r.add(n.to.moduleId);
	let i = (t, n = /* @__PURE__ */ new Set()) => r.has(t) ? !0 : !n.has(t) && (n.add(t), e.cables.some((e) => e.from.moduleId === t && e.to.portId !== "chain" && i(e.to.moduleId, n)));
	return Object.fromEntries(e.modules.filter((e) => e.type !== "output").map((e) => [e.id, !t.muted.has(e.id) && (!r.size || !it.has(e.type) || i(e.id))]));
}
var W = (e) => z[e].drum?.voices.map((e) => e.id) ?? (e === "mixer" ? be : []);
function G(e, t, n) {
	let r = W(e.type).some((t) => n.soloed.has(nt(e.id, t)));
	return !n.muted.has(nt(e.id, t)) && (!r || n.soloed.has(nt(e.id, t)));
}
function ct(e, t, n) {
	return !n.muted.has(rt(e, t)) && (!Array.from({ length: 16 }, (t, n) => rt(e, n)).some((e) => n.soloed.has(e)) || n.soloed.has(rt(e, t)));
}
function lt(e, t, n) {
	let r = [], i = Ie(e, {
		moduleId: t,
		portId: n
	});
	for (; i;) {
		let t = e.modules.find((e) => e.id === i.from.moduleId);
		if (!t || r.includes(t) || (r.unshift(t), it.has(t.type) || t.type === "mixer")) break;
		let n = z[t.type].ports.filter((e) => e.direction === "in" && e.kind === "audio");
		i = n.length === 1 ? Ie(e, {
			moduleId: t.id,
			portId: n[0].id
		}) : void 0;
	}
	return r;
}
function ut(e, t) {
	let n = z[t.type].name;
	return e.modules.filter((e) => e.type === t.type).length > 1 ? `${n} #${e.modules.findIndex((e) => e.id === t.id) + 1}` : n;
}
function dt(e, t, n) {
	let r = lt(e, t, n), i = n.toUpperCase();
	return {
		source: r.length ? ut(e, r[0]) : `Channel ${i}`,
		tooltip: r.map((t) => ut(e, t)).join(" → "),
		connected: r.length > 0
	};
}
function ft(e, t, n) {
	let r = new Set(e.muted), i = new Set(e.soloed), [a, o] = n === "muted" ? [r, i] : [i, r];
	return a.delete(t) || (a.add(t), o.delete(t)), {
		muted: r,
		soloed: i
	};
}
var pt = (e, t) => t === e.id || t.startsWith(`${e.id}:`), mt = (e, t) => [...t.muted, ...t.soloed].some((t) => pt(e, t));
function ht(e, t) {
	return mt(t, e) ? {
		muted: new Set([...e.muted].filter((e) => !pt(t, e))),
		soloed: new Set([...e.soloed].filter((e) => !pt(t, e)))
	} : e;
}
var gt = [
	"Vintage Bass",
	"Vintage Lead",
	"Boom Bap",
	"Late Night Hip-Hop",
	"Roots Reggae",
	"Dub Session",
	"Trap Soul",
	"Broken Beat",
	"Orbit Percussion"
], _t = [
	"Neon Skyline",
	"Digital Boogie",
	"Midnight Ballad",
	"New Wave Motion",
	"Glass Arcade",
	"Analog Sunrise"
], vt = [
	"French Touch",
	"Distortion Disco",
	"Electro Pogo",
	"Electroclash"
], yt = [
	"High Dive",
	"Undertow",
	"Deep End"
], bt = ["Rust Machine", "Dead Highway"], xt = [
	...yt,
	"Trap Soul",
	"Late Night Hip-Hop",
	"Boom Bap"
], St = gt.filter((e) => !xt.includes(e)), Ct = [
	...xt,
	"Groove",
	"House",
	...St,
	..._t,
	...vt,
	...bt
], wt = (e, t) => e.includes(t);
function Tt(e = "High Dive") {
	if (wt(yt, e)) return le(e);
	if (wt(bt, e)) return ue(e);
	if (wt(vt, e)) return re(e);
	if (wt(_t, e)) return te(e);
	if (wt(gt, e)) return E(e);
	let t = e === "Groove" ? ["boom", "orbit"] : ["punch"], n = [
		"performance",
		"oscillator",
		"filter",
		"amplifier",
		"envelope",
		"lfo",
		"delay",
		...t,
		"output"
	].map((e) => Ae(e, e)), r = (e) => n.find((t) => t.type === e);
	e === "Groove" ? (Object.assign(r("envelope").params, {
		decay: .16,
		sustain: .3
	}), r("delay").params.mix = .15) : (r("oscillator").params.wave = 3, Object.assign(r("filter").params, {
		cutoff: 900,
		resonance: 5
	}), Object.assign(r("envelope").params, {
		attack: .002,
		decay: .14,
		sustain: 0,
		release: .08
	}), r("delay").params.mix = .12);
	let i = [
		36,
		36,
		43,
		36,
		48,
		36,
		46,
		43,
		36,
		36,
		43,
		48,
		46,
		43,
		38,
		43
	], a = (t) => e === "House" ? t % 4 != 0 : t !== 1 && t !== 9, o = {
		version: 1,
		name: e,
		modules: n,
		cables: [],
		sequencer: {
			bpm: e === "Groove" ? 94 : 124,
			swing: e === "Groove" ? .12 : 0,
			steps: i.map((e, t) => ({
				enabled: a(t),
				note: e,
				velocity: t % 4 == 0 ? 1 : .75,
				gate: .65
			}))
		}
	}, s = ["delay", ...t];
	for (let [e, n, r, i, a] of [
		[
			"oscillator",
			"out",
			"filter",
			"in",
			1
		],
		[
			"filter",
			"out",
			"amplifier",
			"in",
			1
		],
		[
			"amplifier",
			"out",
			"delay",
			"in",
			1
		],
		...t.map((e, t) => [
			s[t],
			"out",
			e,
			"chain",
			1
		]),
		[
			s.at(-1),
			"out",
			"output",
			"in",
			1
		],
		[
			"performance",
			"pitch",
			"oscillator",
			"pitch",
			1
		],
		[
			"performance",
			"gate",
			"envelope",
			"gate",
			1
		],
		[
			"envelope",
			"out",
			"amplifier",
			"cv",
			1
		],
		[
			"lfo",
			"out",
			"filter",
			"cv",
			.12
		]
	]) o = Re(o, {
		moduleId: e,
		portId: n
	}, {
		moduleId: r,
		portId: i
	}, a);
	return o;
}
function Et(e) {
	return JSON.stringify(e, null, 2);
}
function Dt(e) {
	let t = e.cables.map((e) => JSON.stringify([
		e.from.moduleId,
		e.from.portId,
		e.to.moduleId,
		e.to.portId,
		e.amount
	])).sort();
	return JSON.stringify({
		name: e.name,
		modules: e.modules,
		sequencer: e.sequencer,
		cables: t
	});
}
function Ot(e) {
	if (e.length > 1e6) throw Error("Patch files must be smaller than 1 MB.");
	let t = JSON.parse(e), n = (e) => typeof e == "object" && !!e && !Array.isArray(e), r = () => {
		throw Error("This is not a valid Rackloose v1 patch.");
	}, i = (e) => !Array.isArray(e) || e.length !== 16 ? r() : e.map((e) => !n(e) || typeof e.enabled != "boolean" || typeof e.note != "number" || !Number.isInteger(e.note) || e.note < 24 || e.note > 96 || typeof e.velocity != "number" || !Number.isFinite(e.velocity) || e.velocity < 0 || e.velocity > 1 || typeof e.gate != "number" || !Number.isFinite(e.gate) || e.gate < .1 || e.gate > .95 ? r() : {
		enabled: e.enabled,
		note: e.note,
		velocity: e.velocity,
		gate: e.gate
	});
	if (!n(t) || t.version !== 1 || typeof t.name != "string" || t.name.length > 100 || !Array.isArray(t.modules) || !Array.isArray(t.cables) || !n(t.sequencer) || t.modules.length < 2 || t.modules.length > 32 || t.cables.length > 128) return r();
	let a = /* @__PURE__ */ new Set(), o = t.modules.map((e, t) => {
		if (!n(e) || typeof e.id != "string" || !/^[\w-]{1,80}$/.test(e.id) || a.has(e.id) || typeof e.type != "string" || !Object.hasOwn(z, e.type) || !n(e.params)) return r();
		a.add(e.id);
		let o = e.type, s = e.params, c = Object.fromEntries(z[o].params.map((e) => {
			let t = s[e.id] === void 0 && e.legacyDefault !== void 0 ? e.legacyDefault : s[e.id];
			return typeof t != "number" || !Number.isFinite(t) || t < e.min || t > e.max || (e.choices || e.pattern) && !Number.isInteger(t) ? r() : [e.id, t];
		}));
		return o === "performance" && t > 0 ? {
			id: e.id,
			type: o,
			params: c,
			steps: i(e.steps)
		} : {
			id: e.id,
			type: o,
			params: c
		};
	});
	if (o[0].type !== "performance" || o.filter((e) => e.type === "output").length !== 1 || o.at(-1)?.type !== "output") return r();
	let s = t.sequencer;
	if (typeof s.bpm != "number" || !Number.isFinite(s.bpm) || s.bpm < 40 || s.bpm > 240 || typeof s.swing != "number" || !Number.isFinite(s.swing) || s.swing < 0 || s.swing > .6) return r();
	let c = i(s.steps), l = {
		version: 1,
		name: t.name,
		modules: o,
		cables: [],
		sequencer: {
			bpm: s.bpm,
			swing: s.swing,
			steps: c
		}
	}, u = /* @__PURE__ */ new Set();
	for (let e of t.cables) {
		if (!n(e) || typeof e.id != "string" || !/^[\w-]{1,80}$/.test(e.id) || u.has(e.id) || !n(e.from) || !n(e.to) || typeof e.from.moduleId != "string" || typeof e.from.portId != "string" || typeof e.to.moduleId != "string" || typeof e.to.portId != "string" || typeof e.amount != "number" || !Number.isFinite(e.amount) || e.amount < -1 || e.amount > 1) return r();
		u.add(e.id);
		let t = {
			moduleId: e.from.moduleId,
			portId: e.from.portId
		}, i = {
			moduleId: e.to.moduleId,
			portId: e.to.portId
		}, a = B(l, t);
		if (a && l.cables.some((e) => V(e.from, t))) {
			let e = z[l.modules.find((e) => e.id === t.moduleId).type].ports.find((e) => (e.copyOf ?? e.id) === (a.copyOf ?? a.id) && !l.cables.some((n) => V(n.from, {
				moduleId: t.moduleId,
				portId: e.id
			})));
			if (!e) continue;
			t.portId = e.id;
		}
		if (Le(l, t, i) || B(l, t)?.kind !== "cv" && e.amount !== 1) return r();
		l = {
			...l,
			cables: [...l.cables, {
				id: e.id,
				from: t,
				to: i,
				amount: e.amount
			}]
		};
	}
	return l;
}
function kt(e, t) {
	try {
		let n = e.getItem(t);
		return {
			patch: n ? Ot(n) : null,
			error: null
		};
	} catch {
		return {
			patch: null,
			error: "Saved patch unavailable. You can still play and export patch files."
		};
	}
}
function At(e, t, n) {
	try {
		return e.setItem(t, Et(n)), null;
	} catch {
		return "Local save unavailable. Export a patch file to keep your work.";
	}
}
var jt = (e, t) => e.logarithmic ? Math.log(t / e.min) / Math.log(e.max / e.min) : (t - e.min) / (e.max - e.min), Mt = [
	"C",
	"C♯",
	"D",
	"D♯",
	"E",
	"F",
	"F♯",
	"G",
	"G♯",
	"A",
	"A♯",
	"B"
], Nt = (e) => `${Mt[e % 12]}${Math.floor(e / 12) - 1}`, Pt = class {
	notes = /* @__PURE__ */ new Map();
	press(e, t) {
		return this.notes.delete(e), this.notes.set(e, t), this.current;
	}
	release(e) {
		return this.notes.delete(e), this.current;
	}
	clear() {
		this.notes.clear();
	}
	has(e) {
		return this.notes.has(e);
	}
	get current() {
		return [...this.notes.values()].at(-1) ?? null;
	}
	get entries() {
		return [...this.notes];
	}
}, Ft = (e, t, n) => 60 / e / 4 * (n % 2 == 0 ? 1 + t : 1 - t);
function K(e, t, n = 0) {
	let r = [], i = n;
	for (let n = 0; n < t * 16; n++) {
		let t = n % 16, a = Ft(e.sequencer.bpm, e.sequencer.swing, t);
		r.push({
			step: e.sequencer.steps[t],
			index: t,
			time: i,
			duration: a
		}), i += a;
	}
	return {
		events: r,
		duration: i - n
	};
}
var It = () => ({
	past: [],
	future: [],
	key: null,
	at: 0
});
function Lt(e, t, n, r) {
	return n !== null && n === e.key && r - e.at < 1e3 && !e.future.length ? {
		...e,
		at: r
	} : {
		past: [...e.past, t].slice(-50),
		future: [],
		key: n,
		at: r
	};
}
function Rt(e, t) {
	let n = e.past.at(-1);
	return n === void 0 ? null : {
		state: n,
		history: {
			past: e.past.slice(0, -1),
			future: [t, ...e.future],
			key: null,
			at: 0
		}
	};
}
function zt(e, t) {
	let [n, ...r] = e.future;
	return n === void 0 ? null : {
		state: n,
		history: {
			past: [...e.past, t].slice(-50),
			future: r,
			key: null,
			at: 0
		}
	};
}
var Bt = "This browser could not save to My Presets. Export a file to keep your work.", Vt = 100, Ht = (e, t) => e.trim().toLocaleLowerCase() === t.trim().toLocaleLowerCase(), Ut = (e, t) => e.patch.name.localeCompare(t.patch.name, void 0, {
	sensitivity: "base",
	numeric: !0
}) || e.savedAt - t.savedAt;
function Wt(e, t) {
	try {
		let n = e.getItem(t);
		if (!n) return {
			presets: [],
			error: null
		};
		let r = JSON.parse(n);
		if (typeof r != "object" || !r || !("presets" in r) || !Array.isArray(r.presets)) throw Error("Not a preset list");
		let i = [], a = /* @__PURE__ */ new Set();
		for (let e of r.presets.slice(0, 200)) try {
			if (typeof e != "object" || !e) continue;
			let { id: t, savedAt: n, patch: r } = e;
			if (typeof t != "string" || !/^[\w-]{1,80}$/.test(t) || a.has(t) || typeof n != "number" || !Number.isFinite(n)) continue;
			let o = Ot(JSON.stringify(r));
			if (i.some((e) => Ht(e.patch.name, o.name))) continue;
			a.add(t), i.push({
				id: t,
				savedAt: n,
				patch: o
			});
		} catch {}
		return {
			presets: i.sort(Ut),
			error: null
		};
	} catch {
		return {
			presets: [],
			error: "My Presets could not be read. Export files to keep your presets."
		};
	}
}
function Gt(e, t, n) {
	try {
		return e.setItem(t, JSON.stringify({
			version: 1,
			presets: n
		})), null;
	} catch {
		return Bt;
	}
}
function Kt(e, t) {
	return [...e.filter((e) => e.id !== t.id && !Ht(e.patch.name, t.patch.name)), t].sort(Ut);
}
var qt = (e, t, n) => e.find((e) => e.id !== n && Ht(e.patch.name, t));
function Jt(e, t) {
	for (let n = 1;; n++) {
		let r = n === 1 ? "" : ` (${n})`, i = `${t.slice(0, Vt - r.length).trimEnd()}${r}`;
		if (!qt(e, i)) return i;
	}
}
function Yt(e) {
	return e.trim().toLowerCase().replace(/[^a-z0-9_-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80).replace(/-+$/, "") || "rackloose-patch";
}
//#endregion
//#region src/audio/hold.ts
var q = /* @__PURE__ */ new WeakMap(), Xt = 64;
function Zt(e, t, n) {
	let r = () => t, i = 0;
	for (let t of e) if (t.type === "ramp") {
		if (t.time > n) {
			let e = r(i);
			return e + (t.value - e) * (n - i) / (t.time - i);
		}
		r = () => t.value, i = t.time;
	} else {
		if (t.time > n) break;
		let e = r(t.time), a = t.time;
		r = t.type === "set" ? () => t.value : (n) => t.value + (e - t.value) * Math.exp(-(n - a) / t.constant), i = t.time;
	}
	return r(n);
}
function Qt(e, t) {
	if (typeof e.cancelAndHoldAtTime == "function" || q.has(e)) return e;
	let n = [], { setValueAtTime: r, linearRampToValueAtTime: i, setTargetAtTime: a, cancelScheduledValues: o } = e, s, c = (r) => {
		s ??= e.value;
		let i = n.length;
		for (; i && n[i - 1].time > r.time;) i--;
		if (n.splice(i, 0, r), t && n.length > Xt) {
			let e = -1;
			for (let r = 0; r < n.length && n[r].time <= t.currentTime - 1; r++) n[r].type !== "ramp" && (e = r);
			e > 0 && (s = Zt(n.slice(0, e), s, n[e].time), n.splice(0, e));
		}
	};
	return Object.assign(e, {
		setValueAtTime(t, n) {
			return c({
				type: "set",
				time: n,
				value: t,
				constant: 0
			}), r.call(e, t, n);
		},
		linearRampToValueAtTime(t, n) {
			return c({
				type: "ramp",
				time: n,
				value: t,
				constant: 0
			}), i.call(e, t, n);
		},
		setTargetAtTime(t, n, r) {
			return c({
				type: "target",
				time: n,
				value: t,
				constant: r
			}), a.call(e, t, n, r);
		},
		cancelScheduledValues(t) {
			return n.splice(0, n.length, ...n.filter((e) => e.time < t)), o.call(e, t);
		}
	}), q.set(e, {
		events: n,
		hold: (t) => {
			let r = Zt(n, s ?? e.value, t), i = n.find((e) => e.time >= t);
			e.cancelScheduledValues(t), i?.type === "ramp" ? e.linearRampToValueAtTime(r, t) : e.setValueAtTime(r, t);
		}
	}), e;
}
function J(e, t) {
	if (typeof e.cancelAndHoldAtTime == "function") {
		e.cancelAndHoldAtTime(t);
		return;
	}
	let n = q.get(e)?.hold;
	if (n) n(t);
	else {
		let n = e.value;
		e.cancelScheduledValues(t), e.setValueAtTime(n, t);
	}
}
//#endregion
//#region src/audio/drums.ts
var $t = [
	205.3,
	304.4,
	369.6,
	522.7,
	540,
	800
], en = (e) => 2 ** (e / 12);
function tn(e, t, n, { keep: r, start: i, noise: a }) {
	let o = /* @__PURE__ */ new Set(), s = /* @__PURE__ */ new Map(), c = (t = 0, i = n) => {
		let a = r(e.createGain());
		return a.gain.value = t, a.connect(i), a;
	}, l = (t, n, i = .7) => {
		let a = r(e.createBiquadFilter());
		return a.type = t, a.frequency.value = n, a.Q.value = i, a;
	}, u = (...e) => (e.reduce((e, t) => e.connect(t)), e.at(-1)), d = null, f = () => (d || (d = i(e.createBufferSource()), d.buffer = a, d.loop = !0), d), p = (t, n) => {
		let a = r(e.createGain());
		return a.gain.value = n, {
			sum: a,
			oscillators: t.map((t) => {
				let n = i(e.createOscillator());
				return n.type = "square", n.frequency.value = t, n.connect(a), n;
			})
		};
	}, m = /* @__PURE__ */ new Map(), h = (t, n, r, i, a = 5e-4) => {
		Qt(t, e);
		let o = m.get(t) ?? [], s = o.filter((t) => t.time < e.currentTime).at(-1);
		m.set(t, [
			...s ? [s] : [],
			...o.filter((t) => t.time >= e.currentTime),
			{
				time: n,
				peak: r,
				decay: i,
				rise: a
			}
		].sort((e, t) => e.time - t.time)), t.setTargetAtTime(r, n, a), t.setTargetAtTime(0, n + a * 5, i / 4.6);
	}, g = (e, t) => e.setTargetAtTime(0, t, .003);
	function _(e) {
		if (o.delete(e)) {
			for (let t of [
				...e.sources,
				...e.nodes,
				e.vca
			]) t.disconnect();
			s.get(e.voice) === e && s.delete(e.voice);
		}
	}
	function v(t, r, i, a, c, l = n) {
		let u = e.createGain(), d = [];
		u.gain.value = 0, Qt(u.gain, e), u.connect(l);
		let f = {
			voice: t,
			vca: u,
			nodes: d,
			sources: c(u, d),
			start: r,
			end: r + a * 1.25 + .05,
			naturalEnd: r + a * 1.25 + .05,
			decay: a
		};
		u.gain.setValueAtTime(0, r), u.gain.linearRampToValueAtTime(i, r + .0015), u.gain.setTargetAtTime(0, r + .0015, a / 4.6);
		for (let e of f.sources) e.start(r), e.stop(f.end);
		f.sources[0].onended = () => _(f), o.add(f);
		let p = s.get(t), [m, h] = p && p.start > r ? [f, p] : [p, f];
		if (s.set(t, h), m && o.has(m) && m.end > h.start) {
			m.vca.gain.setTargetAtTime(0, h.start, .002), m.end = h.start + .03, m.chokeAt = h.start;
			for (let e of m.sources) e.stop(m.end);
		}
	}
	let y = (t, n, r, i, a = 1) => {
		let o = e.createOscillator();
		if (o.type = r, o.frequency.value = i, a === 1) o.connect(t);
		else {
			let r = e.createGain();
			r.gain.value = a, o.connect(r).connect(t), n.push(r);
		}
		return o;
	}, b = (e, t, n, r, i) => {
		e.frequency.setValueAtTime(n * r, t), e.frequency.exponentialRampToValueAtTime(n, t + i);
	}, x = () => {};
	if (t === "boom") {
		let e = c(), t = c(), n = c(), r = c(), i = c(), a = c(), o = c(), s = c();
		u(f(), l("highpass", 1800), e), u(f(), l("highpass", 5e3), t), u(f(), l("bandpass", 1e3, 1.4), n);
		let d = p($t, .5).sum, m = u(d, l("bandpass", 1e4, 1), l("highpass", 7e3));
		m.connect(r), m.connect(i);
		let _ = l("highpass", 5e3);
		u(d, l("bandpass", 7e3, .5), _), u(f(), c(.35, _)), _.connect(a), u(p($t.map((e) => e * 1.13), .5).sum, l("bandpass", 4800, 2.5), l("highpass", 3e3), o);
		let S = p([540, 800], .5);
		u(S.sum, l("bandpass", 2640, 1.4), s);
		let C = (e, t, n, r) => v(e, t, .9, r, (e, r) => {
			let i = y(e, r, "sine", n), a = y(e, r, "triangle", n * 1.5, .15);
			return b(i, t, n, 1.6, .06), b(a, t, n * 1.5, 1.6, .06), [i, a];
		});
		x = (c, l, u) => {
			if (c === "kick") v("kick", l, 1, u.kickDecay, (e) => {
				let t = y(e, [], "sine", u.kickTune);
				return b(t, l, u.kickTune, 2, .025), [t];
			});
			else if (c === "snare") {
				let t = u.snareTone;
				v("snare", l, .55, .13, (e, n) => [y(e, n, "sine", 185, 1 - .6 * t), y(e, n, "sine", 330, .35 + .65 * t)]), h(e.gain, l, .6 * u.snappy, .2);
			} else if (c === "rim") v("rim", l, .7, .03, (e, t) => [y(e, t, "triangle", 455, .6), y(e, t, "triangle", 1667)]), h(t.gain, l, .5, .008);
			else if (c === "clap") {
				for (let e of [
					0,
					.01,
					.021
				]) h(n.gain, l + e, 1.4, .016, 4e-4);
				h(n.gain, l + .032, 1.4, .2);
			} else if (c === "hat") g(i.gain, l), h(r.gain, l, 1.25, u.hatDecay);
			else if (c === "open") h(i.gain, l, 1, u.openDecay);
			else if (c === "lowTom") C("lowTom", l, 95 * en(u.tomTune), u.tomDecay);
			else if (c === "highTom") C("highTom", l, 145 * en(u.tomTune), u.tomDecay * .85);
			else if (c === "crash") h(a.gain, l, .75, u.crashDecay, .002);
			else if (c === "ride") h(o.gain, l, .8, u.rideDecay, .001);
			else if (c === "bell") {
				let e = en(u.bellTune);
				S.oscillators.forEach((t, n) => t.frequency.setValueAtTime([540, 800][n] * e, l)), h(s.gain, l, .9, .32);
			}
		};
	} else if (t === "punch") {
		let t = r(e.createWaveShaper()), i = c(1, t), a = c(0, i), o = c(), s = c(), d = c(), m = c();
		t.curve = Float32Array.from({ length: 1025 }, (e, t) => Math.tanh(2.2 * (t / 512 - 1)) / Math.tanh(2.2)), t.oversample = "2x", t.connect(n), u(f(), l("lowpass", 4e3), a);
		let _ = l("lowpass", 6e3);
		u(f(), l("highpass", 1200), _, o), u(f(), l("bandpass", 1100, 1.6), s);
		let S = l("highpass", 7500);
		u(p($t.map((e) => e * 1.5), .5).sum, S), u(f(), c(.35, S)), S.connect(d), S.connect(m), x = (e, t, n) => {
			if (e === "kick") v("kick", t, 1, n.kickDecay, (e) => {
				let r = y(e, [], "sine", n.kickTune), i = r.frequency;
				return i.setValueAtTime(n.kickTune * 5, t), i.exponentialRampToValueAtTime(n.kickTune * 1.3, t + .03), i.exponentialRampToValueAtTime(n.kickTune, t + .16), [r];
			}, i), h(a.gain, t, .7 * n.kickClick, .012);
			else if (e === "snare") v("snare", t, .5, .11, (e, n) => [180, 330].map((r, i) => {
				let a = y(e, n, "triangle", r, i ? .6 : 1);
				return b(a, t, r, 1.15, .02), a;
			})), _.frequency.setValueAtTime(3e3 + 7e3 * n.snareTone, t), h(o.gain, t, .75 * n.snappy, .18);
			else if (e === "clap") {
				for (let e of [
					0,
					.011,
					.022
				]) h(s.gain, t + e, 1.5, .018, 4e-4);
				h(s.gain, t + .033, 1.5, .24);
			} else e === "hat" ? (g(m.gain, t), h(d.gain, t, .9, n.hatDecay)) : e === "open" && h(m.gain, t, .75, n.openDecay);
		};
	} else if (t === "orbit") {
		let e = l("bandpass", 6500, 1.2), t = c(), n = l("highpass", 4500), r = c();
		u(f(), e, l("highpass", 3e3), t), u(f(), n, r), x = (i, a, o) => {
			let s = en(o.pitch + o[`${i}Tune`]), c = o[`${i}Decay`], l = o[`${i}Level`], u = o[`${i}Tone`];
			i === "skin" || i === "tom" ? v(i, a, (i === "skin" ? .8 : .95) * l, c, (e, t) => {
				let n = (i === "skin" ? 196 : 98) * s, r = y(e, t, "sine", n), o = y(e, t, "sine", n * (i === "skin" ? 311 / 196 : 1.5), u * .5);
				return b(r, a, n, i === "skin" ? 1.4 : 2.2, .035), b(o, a, n * (i === "skin" ? 311 / 196 : 1.5), 1.4, .035), [r, o];
			}) : i === "wood" ? v("wood", a, .6 * l, c, (e, t) => {
				let n = y(e, t, "sine", 1450 * s), r = y(e, t, "sine", 3915 * s, u * .6);
				return b(n, a, 1450 * s, 1.05, .005), [n, r];
			}) : i === "sand" ? (e.frequency.setValueAtTime(Math.min(18e3, 6500 * s * (.5 + u)), a), h(t.gain, a, .9 * l, c, .004)) : i === "shaker" ? (n.frequency.setValueAtTime(Math.min(16e3, (1500 + u * 6e3) * s), a), h(r.gain, a, .65 * l, c, .008)) : i === "metal" && v("metal", a, .3 * l, c, (e, t) => [
				440,
				623,
				1067,
				1573
			].map((n, r) => y(e, t, r ? "sine" : "triangle", n * s, r ? .15 + u * .7 : 1)));
		};
	}
	return {
		trigger: x,
		cancelScheduled(e) {
			for (let t of [...o]) if (t.start >= e) {
				for (let n of t.sources) n.stop(e);
				_(t);
			}
			s.clear();
			for (let t of o) {
				if (t.chokeAt !== void 0 && t.chokeAt >= e) {
					J(t.vca.gain, e), t.vca.gain.setTargetAtTime(0, e, t.decay / 4.6), t.end = t.naturalEnd, t.chokeAt = void 0;
					for (let e of t.sources) e.stop(t.end);
				}
				(!s.has(t.voice) || s.get(t.voice).start < t.start) && s.set(t.voice, t);
			}
			for (let [t, n] of m) {
				let r = n.filter((t) => t.time < e).at(-1);
				J(t, e), r ? t.setTargetAtTime(0, Math.max(e, r.time + r.rise * 5), r.decay / 4.6) : t.setValueAtTime(0, e), m.set(t, r ? [r] : []);
			}
		},
		dispose() {
			for (let e of o) for (let t of e.sources) t.stop();
			for (let e of [...o]) _(e);
			s.clear();
		}
	};
}
//#endregion
//#region src/audio/envelope.ts
function nn(e) {
	let t = [], n = (e) => {
		let n = t.findIndex(([t]) => t > e);
		if (n === 0 || !t.length) return 0;
		if (n < 0) return t[t.length - 1][1];
		let [r, i] = t[n - 1], [a, o] = t[n];
		return i + (o - i) * (e - r) / (a - r);
	}, r = (r, ...i) => {
		let a = n(r);
		J(e, r), e.setValueAtTime(a, r);
		for (let [t, n] of i) e.linearRampToValueAtTime(n, t);
		t = [
			...t.filter(([e]) => e < r).slice(-16),
			[r, a],
			...i
		];
	};
	return {
		on(e, t, n, i, a) {
			r(e, [e + n, t], [e + n + i, t * a]);
		},
		off(e, t) {
			r(e, [e + t, 0]);
		}
	};
}
//#endregion
//#region src/audio/monarch.ts
var rn = [
	"sine",
	"triangle",
	"sawtooth",
	"square"
];
function an(e, t, { keep: n, source: r }) {
	let i = (t = 1) => {
		let r = n(e.createGain());
		return r.gain.value = t, r;
	}, a = i(), o = i(), s = i(), c = n(e.createWaveShaper()), l = n(e.createBiquadFilter());
	l.type = "lowpass", l.Q.value = .5, a.connect(l);
	let u = [n(e.createBiquadFilter()), n(e.createBiquadFilter())], d = i(0), f = i(), p = i(.5), m = i();
	s.connect(c).connect(u[0]).connect(u[1]).connect(d).connect(f);
	let h = r(e.createConstantSource()), g = r(e.createConstantSource());
	h.offset.value = 0, g.offset.value = 0, h.connect(d.gain), g.connect(m), l.connect(p);
	for (let e of u) e.type = "lowpass", o.connect(e.detune), m.connect(e.detune), p.connect(e.detune);
	let _ = [
		1,
		2,
		3
	].map(() => {
		let t = r(e.createOscillator()), n = i();
		return t.frequency.value = 261.625565, t.connect(n).connect(s), l.connect(t.detune), {
			osc: t,
			level: n
		};
	}), v = r(e.createBufferSource()), y = i(0);
	v.buffer = t, v.loop = !0, v.connect(y).connect(s);
	let b = {}, x = !1, S = -1, C = (t, n) => {
		x ? t.setTargetAtTime(n, e.currentTime, .008) : t.value = n;
	}, w = [[nn(h.offset), "amp"], [nn(g.offset), "filter"]];
	return {
		pitch: a,
		cv: o,
		output: f,
		apply(t) {
			if (b = t, _.forEach(({ osc: e, level: n }, r) => {
				let i = `osc${r + 1}`;
				e.type = rn[t[`${i}Wave`]], C(e.detune, t[`${i}Octave`] * 1200 + t[`${i}Detune`]), C(n.gain, t[`${i}Level`] * .23);
			}), C(y.gain, t.noise * .15), C(f.gain, t.level), C(l.frequency, t.glide ? Math.min(e.sampleRate * .45, 1 / (2 * Math.PI * t.glide)) : e.sampleRate * .45), C(p.gain, t.tracking), C(m.gain, t.envAmount * 4800), u.forEach((e, n) => {
				C(e.frequency, t.cutoff), C(e.Q, n === 0 ? .707 + t.resonance * 5 : .707);
			}), S !== t.drive) {
				S = t.drive;
				let e = 1 + t.drive * 5;
				c.curve = Float32Array.from({ length: 2049 }, (t, n) => Math.tanh(e * (n / 1024 - 1)) / Math.tanh(e)), c.oversample = "2x";
			}
			x = !0;
		},
		noteOn(e, t) {
			for (let [n, r] of w) n.on(t, e, b[`${r}Attack`], b[`${r}Decay`], b[`${r}Sustain`]);
		},
		noteOff(e) {
			for (let [t, n] of w) t.off(e, b[`${n}Release`]);
		}
	};
}
//#endregion
//#region src/audio/poly.ts
function on(e, t) {
	let n = !1, r;
	return (i, a) => {
		if (clearTimeout(r), r = void 0, i && !n) e.connect(t), n = !0;
		else if (!i && n) {
			let i = () => {
				r = void 0, n = !1;
				try {
					e.disconnect(t);
				} catch {}
			};
			a ? i() : r = setTimeout(i, 100);
		}
	};
}
var sn = class {
	voices;
	constructor(e = 5) {
		this.voices = Array.from({ length: e }, () => ({
			key: null,
			start: -Infinity,
			releaseAt: -Infinity,
			freeAt: -Infinity
		}));
	}
	allocate(e, t = /* @__PURE__ */ new Set()) {
		let n = this.voices.map((e, t) => ({
			voice: e,
			index: t
		})).filter(({ index: e }) => !t.has(e)), r = (e, t) => e.reduce((e, n) => t(n.voice) < t(e.voice) ? n : e).index, i = n.filter(({ voice: t }) => t.freeAt <= e), a = n.filter(({ voice: t }) => t.releaseAt <= e);
		return i.length ? r(i, (e) => e.freeAt) : a.length ? r(a, (e) => e.releaseAt) : r(n, (e) => e.start);
	}
	start(e, t, n) {
		Object.assign(this.voices[e], {
			key: t,
			start: n,
			releaseAt: Infinity,
			freeAt: Infinity
		});
	}
	release(e, t, n) {
		return this.voices.flatMap((r, i) => {
			if (n !== void 0 && r.key !== n || r.releaseAt <= e) return [];
			let a = r.start > e;
			return Object.assign(r, {
				start: Math.min(r.start, e),
				releaseAt: e,
				freeAt: e + t
			}), [{
				index: i,
				pending: a
			}];
		});
	}
}, cn = [
	[
		4,
		-3,
		70
	],
	[
		-5,
		2,
		-40
	],
	[
		1,
		6,
		110
	],
	[
		-2,
		-6,
		-90
	],
	[
		6,
		1,
		20
	]
], ln = 261.625565;
function un(e, t, { keep: n, source: r }) {
	let i = (t = 1) => {
		let r = n(e.createGain());
		return r.gain.value = t, r;
	}, a = (t = 0) => {
		let n = r(e.createConstantSource());
		return n.offset.value = t, n;
	}, o = (e) => Float32Array.from({ length: 1025 }, (t, n) => Math.tanh(e * (n / 512 - 1)) / Math.tanh(e)), s = (t, r, i) => {
		let a = n(e.createWaveShaper());
		return a.curve = o(24), a.oversample = "4x", t.connect(a), r.connect(a), on(a, i);
	}, c = i(), l = i(), u = i(.5), d = i(), f = n(e.createBiquadFilter());
	f.type = "highpass", f.frequency.value = 20, f.Q.value = -3.01, u.connect(f).connect(d);
	let p = r(e.createBufferSource()), m = i(0);
	p.buffer = t, p.loop = !0, p.connect(m);
	let h = r(e.createOscillator()), g = i(0), _ = i(0), v = i(0);
	h.connect(g), h.connect(_), h.connect(v);
	let y = cn.map((t) => {
		let o = a(), d = a(), f = a(), p = a(), h = a(), y = r(e.createOscillator()), b = r(e.createOscillator());
		y.type = "sawtooth", y.frequency.value = ln, b.frequency.value = ln;
		let x = i(), S = i(0), C = i(), w = i(), T = i(), E = i(0), D = i(), ee = i();
		y.connect(x).connect(C), S.connect(C);
		let te = s(y, p, S);
		b.connect(T).connect(D), E.connect(D);
		let ne = s(b, h, E), re = i(), ie = i(0), ae = [n(e.createBiquadFilter()), n(e.createBiquadFilter())];
		C.connect(w).connect(re), D.connect(ee).connect(re), m.connect(re), re.connect(ae[0]).connect(ae[1]).connect(ie).connect(u), d.connect(ie.gain);
		let oe = i(), se = i(), O = i(0), ce = i(0), le = i(), ue = i(0), k = i(0);
		f.connect(se), f.connect(O).connect(le), D.connect(ce).connect(le), le.connect(ue).connect(y.detune), le.connect(k);
		for (let e of [y.detune, b.detune]) o.connect(e), c.connect(e), g.connect(e);
		o.connect(oe), c.connect(oe), _.connect(p.offset), _.connect(h.offset);
		for (let e of ae) {
			e.type = "lowpass";
			for (let t of [
				oe,
				se,
				k,
				l,
				v
			]) t.connect(e.detune);
		}
		return {
			drift: t,
			note: o,
			amp: d,
			filterEnv: f,
			a: y,
			b,
			aWidth: p,
			bWidth: h,
			aComparator: te,
			bComparator: ne,
			aSaw: x,
			aPulse: S,
			aLevel: w,
			bWave: T,
			bPulse: E,
			bLevel: ee,
			filters: ae,
			tracking: oe,
			envDepth: se,
			polyEnv: O,
			polyB: ce,
			polyA: ue,
			polyFilter: k,
			pitched: !1
		};
	}), b = new sn(y.length), x = {}, S = !1, C = (t, n) => {
		S ? t.setTargetAtTime(n, e.currentTime, .008) : t.value = n;
	}, w = (e, t, n, r) => {
		let i = Math.max(.001, x[`${t}Attack`]);
		J(e, r), e.linearRampToValueAtTime(n, r + i), e.setTargetAtTime(n * x[`${t}Sustain`], r + i, Math.max(.001, x[`${t}Decay`]) / 3);
	}, T = (e, t, n) => {
		J(e, n), e.setTargetAtTime(0, n, Math.max(.001, x[`${t}Release`]) / 4);
	}, E = (e, t) => {
		for (let { index: n, pending: r } of b.release(e, x.ampRelease, t)) {
			let t = y[n];
			r && J(t.note.offset, e), T(t.amp.offset, "amp", e), T(t.filterEnv.offset, "filter", e);
		}
	};
	return {
		pitch: c,
		cv: l,
		output: d,
		apply(e) {
			x = e;
			let t = e.vintage, n = e.aShape, r = e.bShape, i = e.polyDest, a = e.lfoDest;
			for (let a of y) C(a.a.detune, e.aOctave * 1200 + a.drift[0] * t), C(a.b.detune, e.bOctave * 1200 + e.bFine + a.drift[1] * t), a.b.type = r === 1 ? "triangle" : "sawtooth", C(a.aSaw.gain, n === 1 ? 0 : n === 2 ? .7 : 1), C(a.aPulse.gain, n === 0 ? 0 : n === 2 ? .7 : 1), C(a.bWave.gain, r === 2 ? 0 : 1), C(a.bPulse.gain, +(r === 2)), a.aComparator(n !== 0, !S), a.bComparator(r === 2, !S), C(a.aWidth.offset, 2 * e.aWidth - 1), C(a.bWidth.offset, 2 * e.bWidth - 1), C(a.aLevel.gain, e.aLevel * .25), C(a.bLevel.gain, e.bLevel * .25), C(a.polyEnv.gain, e.polyEnv * 3600), C(a.polyB.gain, e.polyOscB * 2400), C(a.polyA.gain, i === 1 ? 0 : 1), C(a.polyFilter.gain, i === 0 ? 0 : 1), C(a.tracking.gain, e.tracking), C(a.envDepth.gain, e.envAmount * 6e3), a.filters.forEach((n, r) => {
				C(n.frequency, e.cutoff), C(n.detune, a.drift[2] * t), C(n.Q, r === 0 ? -3.01 + e.resonance * 20 : -3.01);
			});
			h.type = [
				"triangle",
				"sawtooth",
				"square"
			][e.lfoShape], C(h.frequency, e.lfoRate), C(g.gain, a === 0 ? e.lfoAmount * 300 : 0), C(_.gain, a === 1 ? e.lfoAmount * .9 : 0), C(v.gain, a === 2 ? e.lfoAmount * 2400 : 0), C(m.gain, e.noise * .2), C(d.gain, e.level), S = !0;
		},
		noteOn(e, t, n, r) {
			E(n, r);
			let i = /* @__PURE__ */ new Set();
			for (let a of (_e[x.chord]?.[1] ?? [0]).slice(0, y.length)) {
				let o = b.allocate(n, i), s = y[o], c = (e + a - 60) * 100;
				i.add(o), b.start(o, r, n), J(s.note.offset, n), x.glide > 0 && s.pitched ? s.note.offset.setTargetAtTime(c, n, x.glide / 3) : s.note.offset.setValueAtTime(c, n), s.pitched = !0, w(s.amp.offset, "amp", t, n), w(s.filterEnv.offset, "filter", t, n);
			}
		},
		noteOff: E
	};
}
//#endregion
//#region src/audio/aurora.ts
function dn(e, { keep: t, source: n }) {
	let r = (n = 1) => {
		let r = t(e.createGain());
		return r.gain.value = n, r;
	}, i = () => {
		let t = n(e.createConstantSource());
		return t.offset.value = 0, t;
	}, a = r(), o = r(), s = r(), c = r(.22);
	c.connect(s);
	let l = n(e.createOscillator()), u = r(0), d = r(0), f = r(0);
	l.connect(u), l.connect(d), l.connect(f);
	let p = Float32Array.from({ length: 2049 }, (e, t) => Math.tanh(24 * (t / 1024 - 1))), m = Array.from({ length: 8 }, (s, l) => {
		let m = i(), h = i(), g = i(), _ = r(), v = r(0), y = r(), b = r(), x = r(0), S = [0, 1].map(() => {
			let o = n(e.createOscillator()), s = i(), c = r(), l = r(0), f = r(), h = r();
			o.frequency.value = 261.625565;
			let g = t(e.createWaveShaper());
			return g.curve = p, g.oversample = "4x", o.connect(c).connect(h), o.connect(g), s.connect(g), l.connect(h), h.connect(f).connect(_), m.connect(o.detune), a.connect(o.detune), u.connect(o.detune), d.connect(s.offset), {
				osc: o,
				width: s,
				raw: c,
				pulse: l,
				level: f,
				out: h,
				pulsed: on(g, l)
			};
		});
		S[1].out.connect(x).connect(S[0].osc.detune);
		let C = t(e.createBiquadFilter()), w = [t(e.createBiquadFilter()), t(e.createBiquadFilter())];
		C.type = "highpass", C.Q.value = -3.01;
		let T = r(0), E = r(1);
		_.connect(C).connect(w[0]), w[0].connect(T).connect(v), w[0].connect(w[1]).connect(E).connect(v), h.connect(v.gain), v.connect(c), m.connect(y), a.connect(y), g.connect(b);
		for (let e of w) e.type = "lowpass", y.connect(e.detune), b.connect(e.detune), o.connect(e.detune), f.connect(e.detune);
		return {
			note: m,
			oscillators: S,
			hpf: C,
			filters: w,
			twoPole: T,
			fourPole: E,
			tracking: y,
			amount: b,
			cross: x,
			amp: nn(h.offset),
			env: nn(g.offset),
			pitched: !1,
			drift: [
				3,
				-4,
				1,
				5,
				-2,
				4,
				-5,
				2
			][l]
		};
	}), h = new sn(8), g = {}, _ = !1, v = (t, n) => {
		_ ? t.setTargetAtTime(n, e.currentTime, .008) : t.value = n;
	}, y = (e, t) => {
		for (let { index: n, pending: r } of h.release(e, g.ampRelease, t)) {
			let t = m[n];
			r && J(t.note.offset, e), t.amp.off(e, g.ampRelease), t.env.off(e, g.filterRelease);
		}
	};
	return {
		pitch: a,
		cv: o,
		output: s,
		apply(e) {
			g = e;
			for (let t of m) t.oscillators.forEach((n, r) => {
				let i = `osc${r + 1}`, a = e[`${i}Wave`];
				n.osc.type = [
					"sawtooth",
					"sawtooth",
					"triangle",
					"sine"
				][a], v(n.osc.detune, e[`${i}Octave`] * 1200 + e[`${i}Detune`] + t.drift * e.vintage * (r ? -.7 : 1)), v(n.width.offset, 2 * e[`${i}Width`] - 1), v(n.raw.gain, a === 1 ? 0 : 1), v(n.pulse.gain, +(a === 1)), n.pulsed(a === 1, !_), v(n.level.gain, r ? e.blend : 1 - e.blend);
			}), v(t.cross.gain, e.crossMod * 1800), v(t.hpf.frequency, e.hpf), v(t.twoPole.gain, +(e.slope === 0)), v(t.fourPole.gain, +(e.slope === 1)), t.filters.forEach((n, r) => {
				v(n.frequency, e.cutoff), v(n.Q, r ? -3.01 : -3.01 + e.resonance * 17), v(n.detune, t.drift * e.vintage * 9);
			}), v(t.tracking.gain, e.tracking), v(t.amount.gain, e.envAmount * 6e3);
			l.type = [
				"triangle",
				"sine",
				"square"
			][e.lfoShape], v(l.frequency, e.lfoRate), v(u.gain, e.lfoPitch * 100), v(d.gain, e.lfoWidth * .8), v(f.gain, e.lfoFilter * 2400), v(s.gain, e.level), _ = !0;
		},
		noteOn(e, t, n, r) {
			y(n, r);
			let i = /* @__PURE__ */ new Set();
			for (let a of _e[g.chord]?.[1] ?? [0]) {
				let o = h.allocate(n, i), s = m[o], c = (e + a - 60) * 100;
				i.add(o), h.start(o, r, n), J(s.note.offset, n), g.glide && s.pitched ? s.note.offset.setTargetAtTime(c, n, g.glide / 3) : s.note.offset.setValueAtTime(c, n), s.pitched = !0, s.amp.on(n, t, g.ampAttack, g.ampDecay, g.ampSustain), s.env.on(n, 1, g.filterAttack, g.filterDecay, g.filterSustain);
			}
		},
		noteOff: y
	};
}
//#endregion
//#region src/audio/worklets.ts
var fn = ["/** Self-contained phase-modulation DSP, imported directly by tests and as inline source by the worklet loader. */\nexport const ALGORITHMS = [\n  {inputs: [[1], [], [3], [], [5], []], carriers: [0, 2, 4]},\n  {inputs: [[1], [2], [], [4], [5], []], carriers: [0, 3]},\n  {inputs: [[1], [2], [3], [4], [5], []], carriers: [0]},\n  {inputs: [[3], [3], [3], [4, 5], [], []], carriers: [0, 1, 2]},\n  {inputs: [[1, 2], [3], [4], [], [5], []], carriers: [0]},\n  {inputs: [[], [], [], [], [], []], carriers: [0, 1, 2, 3, 4, 5]},\n];\nconst TAU = 2 * Math.PI;\nexport class PrismDSP {\n  constructor(rate) {\n    this.rate = rate; this.events = []; this.params = {}; this.level = 0; this.disposed = false;\n    this.voices = Array.from({length: 16}, () => ({key: null, start: -Infinity, released: -Infinity, free: -Infinity,\n      phase: new Float64Array(6), env: new Float64Array(6), stage: new Uint8Array(6), attackStep: new Float64Array(6), releaseStep: new Float64Array(6), values: new Float64Array(6), frequency: 0, velocity: 1, feedback: 0, lastFeedback: 0}));\n  }\n  enqueue(event) {\n    if (event.type === 'off') this.events = this.events.filter(e => !(e.time >= event.time && (event.key === undefined || e.key === event.key) && (e.type === 'on' || e.type === 'off')));\n    this.events.push(event); this.events.sort((a, b) => a.time - b.time);\n  }\n  release(time, key) {\n    for (const v of this.voices) if (v.key !== null && (key === undefined || v.key === key) && v.released === Infinity) {\n      v.released = time; v.free = time + Math.max(...this.ops.map(o => o.release));\n      for (let i = 0; i < 6; i++) {v.stage[i] = 3; v.releaseStep[i] = v.env[i] / (this.ops[i].release * this.rate);}\n    }\n  }\n  apply(event) {\n    if (event.type === 'params') {\n      this.params = event.params;\n      this.ops = Array.from({length: 6}, (_, i) => {const id = `op${i + 1}`, p = this.params; return {\n        ratio: p[`${id}Ratio`] * 2 ** (p[`${id}Detune`] / 1200), level: p[`${id}Level`], attack: p[`${id}Attack`],\n        decay: Math.exp(-1 / (p[`${id}Decay`] * this.rate / 4)), sustain: p[`${id}Sustain`], release: p[`${id}Release`],\n      };});\n    } else if (event.type === 'off') this.release(event.time, event.key);\n    else if (event.type === 'on' && this.ops) {\n      this.release(event.time, event.key);\n      const taken = new Set();\n      for (const note of event.notes) {\n        const available = this.voices.filter(v => !taken.has(v));\n        const silent = available.filter(v => v.free <= event.time), released = available.filter(v => v.released <= event.time);\n        const candidates = silent.length ? silent : released.length ? released : available;\n        const field = silent.length ? 'free' : released.length ? 'released' : 'start';\n        const v = candidates.reduce((a, b) => b[field] < a[field] ? b : a);\n        taken.add(v);\n        if (v.free <= event.time) {v.phase.fill(0); v.env.fill(0); v.feedback = 0; v.lastFeedback = 0;}\n        v.key = event.key; v.start = event.time; v.free = Infinity; v.released = Infinity;\n        v.frequency = 440 * 2 ** ((note - 69) / 12); v.velocity = event.velocity;\n        for (let i = 0; i < 6; i++) {v.stage[i] = 0; v.attackStep[i] = (1 - v.env[i]) / (this.ops[i].attack * this.rate);}\n      }\n    }\n  }\n  render(output, startFrame, pitch, brightness) {\n    if (this.disposed) {output.fill(0); return;}\n    for (let n = 0; n < output.length; n++) {\n      const time = (startFrame + n) / this.rate;\n      while (this.events.length && this.events[0].time <= time) this.apply(this.events.shift());\n      if (!this.ops) {output[n] = 0; continue;}\n      const p = this.params, algorithm = ALGORITHMS[p.algorithm];\n      const bend = (pitch?.[n] ?? 0) + Math.sin(TAU * p.lfoRate * time) * p.lfoDepth * 100;\n      const tune = 2 ** (Math.max(-9600, Math.min(9600, bend)) / 1200);\n      const color = Math.max(0, Math.min(4, p.brightness + (brightness?.[n] ?? 0)));\n      let sum = 0;\n      for (let index = 0; index < this.voices.length; index++) {\n        const v = this.voices[index];\n        if (v.free <= time) continue;\n        const touch = 1 - p.velocity + p.velocity * v.velocity;\n        for (let i = 5; i >= 0; i--) {\n          const op = this.ops[i];\n          if (v.stage[i] === 0) {v.env[i] = Math.min(1, v.env[i] + v.attackStep[i]); if (v.env[i] >= 1) v.stage[i] = 1;}\n          else if (v.stage[i] === 1) v.env[i] = op.sustain + (v.env[i] - op.sustain) * op.decay;\n          else v.env[i] = Math.max(0, v.env[i] - v.releaseStep[i]);\n          const frequency = Math.min(this.rate * 0.45, v.frequency * tune * op.ratio);\n          // The step is under half a turn, so subtracting a turn wraps exactly as the remainder would.\n          v.phase[i] += TAU * frequency / this.rate; if (v.phase[i] >= TAU) v.phase[i] -= TAU;\n          // A released operator at zero contributes nothing, so its sine is skipped.\n          if (v.env[i] === 0) {v.values[i] = 0; continue;}\n          let modulation = i === 5 ? (v.feedback + v.lastFeedback) * 0.5 * p.feedback * 3.5 : 0;\n          const inputs = algorithm.inputs[i];\n          for (let k = 0; k < inputs.length; k++) modulation += v.values[inputs[k]] * 5 * color * touch;\n          v.values[i] = Math.sin(v.phase[i] + modulation) * v.env[i] * op.level;\n        }\n        v.lastFeedback = v.feedback; v.feedback = v.values[5];\n        let voice = 0;\n        for (let k = 0; k < algorithm.carriers.length; k++) voice += v.values[algorithm.carriers[k]];\n        sum += voice / Math.sqrt(algorithm.carriers.length) * v.velocity;\n      }\n      this.level += (p.level - this.level) * 0.003;\n      output[n] = sum * this.level * 0.18;\n    }\n  }\n}\n// The guard lets unit tests import the exact processor DSP without an audio environment.\nif (typeof registerProcessor !== 'undefined') {\n  class PrismProcessor extends AudioWorkletProcessor {\n    constructor() {\n      super(); this.dsp = new PrismDSP(sampleRate);\n      this.port.onmessage = ({data}) => {\n        if (data.type === 'flush') this.port.postMessage({id: data.id});\n        else if (data.type === 'dispose') {this.dsp.disposed = true; this.dsp.events = [];}\n        else this.dsp.enqueue(data);\n      };\n    }\n    process(inputs, outputs) {\n      this.dsp.render(outputs[0][0], currentFrame, inputs[0]?.[0], inputs[1]?.[0]);\n      return !this.dsp.disposed;\n    }\n  }\n  registerProcessor('rackloose-prism-v1', PrismProcessor);\n}\n", "/** Original behavioral models, not measured circuit replicas. See docs/studio-processors.md for calibration and sources. */\nexport const COHERE_ATTACKS = [0.0001, 0.0003, 0.001, 0.003, 0.01, 0.03];\nexport const COHERE_RELEASES = [0.1, 0.3, 0.6, 1.2];\nexport const TALON_RATIOS = [1, 2, 3, 4, 6, 10, 20, 100];\nexport const BRIT_LOW = [35, 60, 110, 220];\nexport const BRIT_MID = [360, 700, 1600, 3200, 4800, 7200];\nexport const BRIT_HP = [0, 50, 80, 160, 300];\nconst db = x => 10 ** (x / 20);\nconst unity = [1, 0, 0, 0, 0];\n\n/** Normalized biquads and one pole filters. A third-order Butterworth HP is a first order plus a Q=1 biquad. */\nexport function coefficients(type, frequency, gain, Q, rate) {\n  if (!frequency) return unity.slice();\n  const w = 2 * Math.PI * Math.min(frequency, rate * 0.45) / rate, c = Math.cos(w), s = Math.sin(w);\n  const A = 10 ** (gain / 40), alpha = s / (2 * Q), shelf = s * Math.sqrt(2 * A);\n  let b0, b1, b2, a0, a1, a2;\n  if (type === 'pole') {\n    const k = Math.tan(w / 2); return [1 / (1 + k), -1 / (1 + k), 0, (k - 1) / (k + 1), 0];\n  } else if (type === 'highpass') {\n    [b0, b1, b2, a0, a1, a2] = [(1 + c) / 2, -(1 + c), (1 + c) / 2, 1 + alpha, -2 * c, 1 - alpha];\n  } else if (type === 'bell') {\n    [b0, b1, b2, a0, a1, a2] = [1 + alpha * A, -2 * c, 1 - alpha * A, 1 + alpha / A, -2 * c, 1 - alpha / A];\n  } else if (type === 'low') {\n    [b0, b1, b2, a0, a1, a2] = [A * (A + 1 - (A - 1) * c + shelf), 2 * A * (A - 1 - (A + 1) * c), A * (A + 1 - (A - 1) * c - shelf), A + 1 + (A - 1) * c + shelf, -2 * (A - 1 + (A + 1) * c), A + 1 + (A - 1) * c - shelf];\n  } else {\n    [b0, b1, b2, a0, a1, a2] = [A * (A + 1 + (A - 1) * c + shelf), -2 * A * (A - 1 + (A + 1) * c), A * (A + 1 + (A - 1) * c - shelf), A + 1 - (A - 1) * c + shelf, 2 * (A - 1 - (A + 1) * c), A + 1 - (A - 1) * c - shelf];\n  }\n  return [b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0];\n}\nexport function britFilters(p, rate) {\n  const hp = BRIT_HP[p.hpf] ?? 0;\n  return [coefficients('pole', hp, 0, 1, rate), coefficients('highpass', hp, 0, 1, rate),\n    coefficients('low', BRIT_LOW[p.lfFreq] ?? 110, p.lfGain, 0.7, rate),\n    coefficients('bell', BRIT_MID[p.midFreq] ?? 1600, p.midGain, 0.75, rate), coefficients('high', 12000, p.hfGain, 0.7, rate)];\n}\nexport function britResponse(p, frequency, rate = 48000) {\n  if (p.active) return 0;\n  const w = 2 * Math.PI * frequency / rate;\n  const magnitude = (a, b, c) => Math.hypot(a + b * Math.cos(w) + c * Math.cos(2 * w), b * Math.sin(w) + c * Math.sin(2 * w));\n  return britFilters(p, rate).reduce((sum, [b0, b1, b2, a1, a2]) => sum + 20 * Math.log10(magnitude(b0, b1, b2) / magnitude(1, a1, a2)), 0);\n}\n\n/** Each TALON mode has its own threshold and knee; Input drives a fixed characteristic instead of moving a threshold. */\nfunction curveSettings(type, p) {\n  let ratio, threshold, knee;\n  if (type === 'cohere') {\n    ratio = [2, 4, 10][p.ratio] ?? 4;\n    threshold = p.threshold + [-3, 0, 2][p.ratio]; knee = [9, 6, 3][p.ratio];\n  } else {\n    ratio = TALON_RATIOS[p.ratio] ?? 6;\n    threshold = [-18, -26, -24, -22, -20, -18, -16, -18][p.ratio];\n    knee = [0, 15, 12, 9, 6, 4, 2, 3][p.ratio];\n    if (p.fierce) {ratio = Math.max(12, ratio * 2); threshold -= 3; knee = 2;}\n  }\n  return [1 - 1 / ratio, threshold, knee];\n}\nfunction curveGain(level, slope, threshold, knee) {\n  if (!slope) return 0;\n  const over = level - threshold;\n  return over <= -knee / 2 ? 0 : over >= knee / 2 ? -over * slope : -slope * (over + knee / 2) ** 2 / (2 * knee);\n}\nexport function compressionCurve(type, level, p) {return curveGain(level, ...curveSettings(type, p));}\n\nclass Filter {\n  constructor(rate) {this.c = unity.slice(); this.target = unity.slice(); this.z1 = 0; this.z2 = 0; this.smooth = 1 - Math.exp(-1 / (rate * 0.008));}\n  set(c, initial) {this.target = c; if (initial) this.c = c.slice();}\n  run(x) {\n    const c = this.c;\n    for (let i = 0; i < 5; i++) c[i] += (this.target[i] - c[i]) * this.smooth;\n    const y = c[0] * x + this.z1;\n    this.z1 = c[1] * x - c[3] * y + this.z2; this.z2 = c[2] * x - c[4] * y;\n    return y;\n  }\n}\n\n// 4x interpolation/decimation of the nonlinear residual only: linear audio keeps its full bandwidth.\n// Two symmetric 49-tap Blackman-windowed sinc FIRs give exactly 12 base-rate samples of delay.\nexport const FIR = Float64Array.from({length: 49}, (_, i) => {\n  const n = i - 24, cutoff = 0.1125;\n  return (n ? Math.sin(2 * Math.PI * cutoff * n) / (Math.PI * n) : 2 * cutoff) * (0.42 - 0.5 * Math.cos(2 * Math.PI * i / 48) + 0.08 * Math.cos(4 * Math.PI * i / 48));\n});\nconst total = FIR.reduce((sum, x) => sum + x, 0); for (let i = 0; i < FIR.length; i++) FIR[i] /= total;\nclass Fir {\n  constructor() {this.buffer = new Float64Array(49); this.index = 0;}\n  /** Stores `x` without computing an output, for decimation steps whose output is discarded. */\n  push(x) {this.buffer[this.index] = x; this.index = (this.index + 1) % 49;}\n  run(x) {\n    this.buffer[this.index] = x; let sum = 0, at = this.index;\n    for (let i = 0; i < 49; i++) {sum += FIR[i] * this.buffer[at]; if (--at < 0) at = 48;}\n    this.index = (this.index + 1) % 49; return sum;\n  }\n}\n/**\n * The FIR over a 4x zero-stuffed signal, computed polyphase: phase `i` reads only the taps that meet a real sample,\n * in the same order, so it matches the full filter exactly at a quarter of the work.\n */\nclass Interpolator {\n  constructor() {this.buffer = new Float64Array(13); this.index = 0;}\n  push(x) {this.index = this.index ? this.index - 1 : 12; this.buffer[this.index] = x;}\n  run(phase) {\n    let sum = 0, at = this.index;\n    for (let k = phase; k < 49; k += 4) {sum += FIR[k] * this.buffer[at]; if (++at > 12) at = 0;}\n    return sum;\n  }\n}\nexport const STUDIO_LATENCY = 12;\nclass Delay {\n  constructor() {this.buffer = new Float64Array(STUDIO_LATENCY); this.index = 0;}\n  run(x) {const y = this.buffer[this.index]; this.buffer[this.index] = x; this.index = (this.index + 1) % this.buffer.length; return y;}\n}\nexport class Color {\n  constructor(rate) {this.up = new Interpolator(); this.down = new Fir(); this.clean = new Delay(); this.previous = 0; this.blocked = 0; this.dc = Math.exp(-2 * Math.PI * 5 / rate);}\n  run(x, amount, bias) {\n    let residual = 0;\n    const offset = Math.tanh(bias), slope = amount * (1 - offset * offset);\n    this.up.push(x * 4);\n    for (let i = 0; i < 4; i++) {\n      const up = this.up.run(i);\n      const shaped = (Math.tanh(amount * up + bias) - offset) / slope;\n      // Only every fourth decimated sample is kept, so the others are stored without being filtered.\n      if (i === 0) residual = this.down.run(shaped - up); else this.down.push(shaped - up);\n    }\n    // AC coupling of the nonlinear residual removes the DC generated by asymmetric coloration.\n    this.blocked = residual - this.previous + this.dc * this.blocked; this.previous = residual;\n    return this.clean.run(x) + this.blocked;\n  }\n}\n\nexport class StudioDSP {\n  constructor(type, rate) {\n    this.type = type; this.rate = rate; this.params = null; this.events = []; this.disposed = false; this.reduction = 0;\n    this.gain = [0, 0]; this.memory = [0, 0]; this.input = 1; this.output = 1; this.wet = 1; this.drive = 0;\n    this.smooth = 1 - Math.exp(-1 / (rate * 0.008));\n    this.channels = Array.from({length: 2}, () => ({filters: Array.from({length: 5}, () => new Filter(rate)),\n      hp: new Filter(rate), emphasis: new Filter(rate), audioPole: new Filter(rate), audioHp: new Filter(rate), color: new Color(rate), dry: new Delay(), clean: new Delay(), amount: 0.15, bias: 0}));\n  }\n  enqueue(event) {this.events.push(event); this.events.sort((a, b) => a.time - b.time);}\n  configure(p) {\n    const initial = !this.params; this.params = {...p};\n    this.inputTarget = db(this.type === 'talon' ? p.input : 0); this.outputTarget = db(p.output);\n    this.wetTarget = p.active ? 0 : 1; this.driveTarget = p.drive ?? 0;\n    if (initial) {this.input = this.inputTarget; this.output = this.outputTarget; this.wet = this.wetTarget; this.drive = this.driveTarget;}\n    if (this.type !== 'brit') {\n      this.curveTarget = curveSettings(this.type, p); this.linkTarget = this.type === 'cohere' ? 1 : p.link;\n      this.attackTarget = this.type === 'cohere' ? COHERE_ATTACKS[p.attack] : p.attack;\n      this.releaseTarget = this.type === 'cohere' ? COHERE_RELEASES[p.release] ?? 0.3 : p.release;\n      if (initial) {this.curve = this.curveTarget.slice(); this.link = this.linkTarget; this.attack = this.attackTarget; this.release = this.releaseTarget;}\n    }\n    for (const channel of this.channels) {\n      if (this.type === 'brit') britFilters(p, this.rate).forEach((c, i) => channel.filters[i].set(c, initial));\n      const hp = this.type === 'cohere' ? [0, 30, 60, 106, 125, 185][p.scHpf] : p.detectorHp ? 80 : 0;\n      channel.hp.set(coefficients('highpass', hp, 0, Math.SQRT1_2, this.rate), initial);\n      channel.emphasis.set(coefficients('bell', 6000, p.detectorBand ? 10 : 0, 1, this.rate), initial);\n      // Third-order Bessel HP, normalized to -3 dB at 65 Hz. Distinct from the detector filter.\n      channel.audioPole.set(coefficients('pole', p.audioHp ? 65 * 0.754 : 0, 0, 1, this.rate), initial);\n      channel.audioHp.set(coefficients('highpass', p.audioHp ? 65 * 0.691 : 0, 0, 0.691, this.rate), initial);\n      if (initial && this.type === 'talon') {channel.amount = [0.15, 0.8, 1.5][p.color]; channel.bias = p.color === 1 ? 0.3 : 0;}\n    }\n  }\n  envelope(level, channel) {\n    const p = this.params, target = curveGain(level, this.curve[0], this.curve[1], this.curve[2]), current = this.gain[channel];\n    // A slow reservoir makes Auto and Opto depend on both the depth and duration of preceding compression.\n    this.memory[channel] += (Math.max(0, -current) - this.memory[channel]) * (1 - Math.exp(-1 / (this.rate * 0.6)));\n    let release = this.release;\n    if (this.type === 'cohere' && p.release === 4) release = 0.1 + Math.min(1.1, this.memory[channel] * 0.09);\n    if (this.type === 'talon') {\n      if (p.ratio === 5) release = Math.min(20, this.release * (1 + this.memory[channel] * 0.9));\n      else if (p.ratio === 7) release *= 0.45 + Math.min(1.5, Math.max(0, -current) / 15);\n      else release *= [1, 1.15, 1.05, 1, 0.9, 1, 0.8, 1][p.ratio];\n      if (p.ratio !== 5) release = Math.min(3.5, release);\n      if (p.fierce) release *= 0.65;\n    }\n    const seconds = target < current ? this.attack : release;\n    this.gain[channel] += (target - current) * (1 - Math.exp(-1 / (seconds * this.rate)));\n    return db(this.gain[channel]);\n  }\n  render(inputs, outputs, startFrame = 0) {\n    if (this.disposed) {outputs.forEach(out => out.fill(0)); return;}\n    const frames = outputs[0].length;\n    for (let n = 0; n < frames; n++) {\n      const time = (startFrame + n) / this.rate;\n      while (this.events.length && this.events[0].time <= time) this.configure(this.events.shift().params);\n      if (!this.params) {outputs.forEach(out => {out[n] = 0;}); continue;}\n      const p = this.params;\n      this.input += (this.inputTarget - this.input) * this.smooth; this.output += (this.outputTarget - this.output) * this.smooth;\n      this.wet += (this.wetTarget - this.wet) * this.smooth; this.drive += (this.driveTarget - this.drive) * this.smooth;\n      const left = inputs[0]?.[n] ?? 0, right = inputs[1]?.[n] ?? left;\n      const l = left * this.input, r = right * this.input;\n      let gainL = 1, gainR = 1;\n      if (this.type !== 'brit') {\n        for (let i = 0; i < 3; i++) this.curve[i] += (this.curveTarget[i] - this.curve[i]) * this.smooth;\n        this.link += (this.linkTarget - this.link) * this.smooth;\n        this.attack += (this.attackTarget - this.attack) * this.smooth; this.release += (this.releaseTarget - this.release) * this.smooth;\n        const a = this.channels[0], b = this.channels[1];\n        const levelL = 20 * Math.log10(Math.max(1e-12, Math.abs(a.emphasis.run(a.hp.run(l)))));\n        const levelR = 20 * Math.log10(Math.max(1e-12, Math.abs(b.emphasis.run(b.hp.run(r)))));\n        const dominant = Math.max(levelL, levelR);\n        this.envelope(levelL + this.link * (dominant - levelL), 0); this.envelope(levelR + this.link * (dominant - levelR), 1);\n        // Converge existing independent histories continuously when linking, never copy one channel's gain instantly.\n        const commonGain = Math.min(this.gain[0], this.gain[1]), commonMemory = Math.max(this.memory[0], this.memory[1]), coupling = this.link * this.smooth;\n        for (let i = 0; i < 2; i++) {this.gain[i] += (commonGain - this.gain[i]) * coupling; this.memory[i] += (commonMemory - this.memory[i]) * coupling;}\n        gainL = db(this.gain[0]); gainR = db(this.gain[1]);\n        this.reduction = Math.min(this.gain[0], this.gain[1]) * this.wet;\n      }\n      for (let i = 0; i < outputs.length; i++) {\n        const channel = this.channels[i], raw = i === 0 ? left : right;\n        let wet = i === 0 ? l : r;\n        if (this.type === 'brit') {\n          for (const filter of channel.filters) wet = filter.run(wet);\n          wet = channel.color.run(wet, 0.22 * db(this.drive), 0.12);\n        } else if (this.type === 'talon') {\n          wet = channel.audioHp.run(channel.audioPole.run(wet * (i === 0 ? gainL : gainR)));\n          const amount = [0.15, 0.8, 1.5][p.color] * (1 + Math.min(2, -this.gain[i] / 20));\n          channel.amount += (amount - channel.amount) * this.smooth; channel.bias += ((p.color === 1 ? 0.3 : 0) - channel.bias) * this.smooth;\n          wet = channel.color.run(wet, channel.amount, channel.bias);\n        } else wet = channel.clean.run(wet * (i === 0 ? gainL : gainR));\n        const dry = channel.dry.run(raw);\n        outputs[i][n] = dry + this.wet * (wet * this.output - dry);\n      }\n    }\n  }\n}\n\nif (typeof registerProcessor !== 'undefined') {\n  class StudioProcessor extends AudioWorkletProcessor {\n    constructor(options) {\n      super(); this.dsp = new StudioDSP(options.processorOptions.type, sampleRate); this.meterFrames = 0;\n      this.port.onmessage = ({data}) => {\n        if (data.type === 'flush') this.port.postMessage({id: data.id});\n        else if (data.type === 'dispose') {this.dsp.disposed = true; this.dsp.events = [];}\n        else this.dsp.enqueue(data);\n      };\n    }\n    process(inputs, outputs) {\n      this.dsp.render(inputs[0] ?? [], outputs[0], currentFrame);\n      this.meterFrames += outputs[0][0].length;\n      if (this.meterFrames >= sampleRate / 25) {this.meterFrames = 0; this.port.postMessage({reduction: this.dsp.reduction});}\n      return !this.dsp.disposed;\n    }\n  }\n  registerProcessor('rackloose-studio-v1', StudioProcessor);\n}\n"].map((e) => ({
	source: e,
	contexts: /* @__PURE__ */ new WeakMap()
}));
async function Y(e) {
	await Promise.all(fn.map(({ source: t, contexts: n }) => {
		let r = n.get(e);
		if (!r) {
			let i = URL.createObjectURL(new Blob([t], { type: "text/javascript" }));
			r = e.audioWorklet.addModule(i).finally(() => URL.revokeObjectURL(i)), n.set(e, r), r.catch(() => n.delete(e));
		}
		return r;
	}));
}
function pn(e, t, n, r) {
	let i = 0, a = !1, o, s = /* @__PURE__ */ new Map(), c = (e) => {
		for (let t of s.values()) clearTimeout(t.timer), e ? t.reject(e) : t.resolve();
		s.clear();
	};
	return e.port.onmessage = ({ data: e }) => {
		if (a) return;
		typeof e.reduction == "number" && Number.isFinite(e.reduction) && n?.(e.reduction);
		let t = e.id === void 0 ? void 0 : s.get(e.id);
		t && (clearTimeout(t.timer), t.resolve(), s.delete(e.id));
	}, e.onprocessorerror = () => {
		a || (o = /* @__PURE__ */ Error(`${t} audio processor failed. Reload the patch to retry.`), c(o), r?.(o));
	}, {
		flush() {
			return o ? Promise.reject(o) : a ? Promise.resolve() : new Promise((n, r) => {
				let a = ++i, o = setTimeout(() => {
					s.delete(a), r(/* @__PURE__ */ Error(`${t} did not finish preparing audio. Try again.`));
				}, 5e3);
				s.set(a, {
					resolve: n,
					reject: r,
					timer: o
				}), e.port.postMessage({
					type: "flush",
					id: a
				});
			});
		},
		dispose() {
			a || (a = !0, e.port.postMessage({ type: "dispose" }), c(), e.port.onmessage = null, e.onprocessorerror = null, e.port.close());
		}
	};
}
//#endregion
//#region src/audio/prism.ts
function mn(e, { keep: t, onError: n }) {
	let r = t(new AudioWorkletNode(e, "rackloose-prism-v1", {
		numberOfInputs: 2,
		numberOfOutputs: 1,
		outputChannelCount: [1]
	})), i = t(e.createGain()), a = t(e.createGain());
	i.connect(r, 0, 0), a.connect(r, 0, 1);
	let o = {};
	return {
		pitch: i,
		cv: a,
		output: r,
		...pn(r, "PRISM", void 0, n),
		apply(t) {
			o = t, r.port.postMessage({
				type: "params",
				time: e.currentTime,
				params: t
			});
		},
		noteOn(e, t, n, i) {
			r.port.postMessage({
				type: "on",
				time: n,
				key: i,
				velocity: t,
				notes: (_e[o.chord]?.[1] ?? [0]).map((t) => e + t)
			});
		},
		noteOff(e, t) {
			r.port.postMessage({
				type: "off",
				time: e,
				key: t
			});
		}
	};
}
//#endregion
//#region src/audio/studio.ts
function hn(e, t, n, r) {
	let i = n(new AudioWorkletNode(e, "rackloose-studio-v1", {
		numberOfInputs: 1,
		numberOfOutputs: 1,
		outputChannelCount: [2],
		channelCount: 2,
		channelCountMode: "explicit",
		processorOptions: { type: t }
	})), a = 0;
	return {
		input: i,
		output: i,
		...pn(i, z[t].name, (e) => {
			a = e;
		}, r),
		get reduction() {
			return a;
		},
		apply(t) {
			i.port.postMessage({
				type: "params",
				time: e.currentTime,
				params: t
			});
		}
	};
}
//#endregion
//#region src/audio/strike.ts
var X = 28e3, Z = /* @__PURE__ */ new Map();
function gn(e) {
	let t = Z.get(e);
	if (t) return t;
	let n = ve.findIndex((t) => t.id === e);
	if (n < 0) throw Error(`Unknown STRIKE voice: ${e}`);
	let r = [
		"crash",
		"ride",
		"open"
	].includes(e), i = Math.ceil(X * (r ? 3 : 1.5)), a = new Float32Array(i), o = 7103 + n * 197, s = 0, c = 0, l = 0, u = (e, t) => Math.sin(2 * Math.PI * e * t), d = {
		lowTom: 100,
		midTom: 142,
		highTom: 195,
		lowConga: 210,
		highConga: 310
	};
	for (let t = 0; t < i; t++) {
		o ^= o << 13, o ^= o >>> 17, o ^= o << 5;
		let n = (o >>> 0) / 2 ** 31 - 1, r = t / X;
		s = .65 * s + .35 * n;
		let f = n - c;
		c = n;
		let p = 0;
		if (e === "kick") l += 2 * Math.PI * (54 + 120 * Math.exp(-r * 80)) / X, p = Math.sin(l) * Math.exp(-r * 9) + .28 * s * Math.exp(-r * 170) + .1 * u(105, r) * Math.exp(-r * 25);
		else if (e === "snare") p = (.55 * u(185, r) + .28 * u(331, r)) * Math.exp(-r * 25) + .75 * (n - s) * Math.exp(-r * 15);
		else if (e === "rim") p = (u(420, r) + .65 * u(1750, r) + .35 * u(3100, r)) * Math.exp(-r * 85) + n * .25 * Math.exp(-r * 300);
		else if (e === "clap") {
			let e = [
				0,
				.011,
				.024
			].reduce((e, t) => e + (r >= t ? Math.exp(-(r - t) * 230) : 0), 0);
			p = (n - s) * (e + (r > .035 ? .65 * Math.exp(-(r - .035) * 16) : 0));
		} else if (e in d) {
			let t = d[e], n = e.includes("Conga");
			l += 2 * Math.PI * t * (1 + .55 * Math.exp(-r * 55)) / X, p = (Math.sin(l) + .3 * u(t * (n ? 2.14 : 1.59), r)) * Math.exp(-r * (n ? 14 : 8)) + .22 * s * Math.exp(-r * 95);
		} else if (e === "bell") p = (u(540, r) + .65 * u(800, r) + .22 * u(1620, r)) * Math.exp(-r * 11);
		else {
			let t = [
				3421,
				4517,
				5683,
				7129,
				9181
			].reduce((t, n, i) => t + u(n * (e === "ride" ? .68 : 1), r) / (i + 2), 0), n = e === "hat" ? 34 : e === "open" ? 5 : e === "crash" ? 1.8 : e === "ride" ? 2.3 : e === "cabasa" ? 32 : 16;
			p = ((e === "cabasa" ? 0 : .4) * t + (e === "ride" ? .2 : .65) * f) * Math.exp(-r * n), e === "tambourine" && (p *= .65 + .35 * u(85, r)), e === "crash" && (p *= Math.min(1, r * 180));
		}
		let m = Math.tanh(p), h = Math.sign(m) * Math.log1p(255 * Math.abs(m)) / Math.log(256), g = Math.round(h * 127) / 127;
		a[t] = Math.sign(g) * Math.expm1(Math.abs(g) * Math.log(256)) / 255 * Math.min(1, t / 12) * Math.min(1, (i - 1 - t) / 128);
	}
	return Z.set(e, a), a;
}
var _n = (e, t) => vn(e, t, {
	rate: X,
	sample: gn,
	chokedBy: { open: ["hat"] }
});
function vn(e, t, { rate: n, sample: r, chokedBy: i = {}, peak: a = 1.6, tone: o = (e) => 700 * 20 ** e }) {
	let s = /* @__PURE__ */ new Map(), c = /* @__PURE__ */ new Set(), l = (e) => [e, ...i[e] ?? []], u = (e) => {
		if (c.delete(e)) for (let t of [
			e.source,
			e.gain,
			e.filter,
			e.pan
		]) t.disconnect();
	};
	function d(t) {
		let n = e.currentTime, r = /* @__PURE__ */ new Map();
		for (let e of c) {
			let t = r.get(e.voice) ?? [];
			t.push(e), r.set(e.voice, t);
		}
		for (let e of r.values()) e.sort((e, t) => e.start - t.start);
		for (let [e, i] of r) if (!t || l(e).includes(t)) for (let t of i) {
			let i = l(e).flatMap((e) => r.get(e) ?? []).filter((n) => n.start > t.start || n.voice !== e && n.start === t.start).reduce((e, t) => !e || t.start < e.start ? t : e, void 0)?.start ?? Infinity, a = t.gain.gain, o = (e) => t.peak * Math.min(1, Math.max(0, e - t.start) / .001) * Math.exp(-Math.max(0, e - t.start - .001) * 4.6 / t.decay);
			a.cancelScheduledValues(n), n < t.start + .001 ? (a.setValueAtTime(o(n), n), a.setValueAtTime(0, Math.max(n, t.start)), a.linearRampToValueAtTime(t.peak, t.start + .001)) : a.setValueAtTime(i < n ? o(i) * Math.max(0, 1 - (n - i) / .004) : o(n), n), a.setTargetAtTime(0, Math.max(n, t.start + .001), t.decay / 4.6), i >= n && i < t.end && (a.cancelScheduledValues(i), a.setValueAtTime(o(i), i), a.linearRampToValueAtTime(0, i + .004)), t.source.stop(Math.max(n, Math.min(t.end, i + .005)));
		}
	}
	return {
		trigger(i, l, f, p = 1) {
			let m = s.get(i);
			if (!m) {
				let t = r(i);
				m = e.createBuffer(1, t.length, n), m.copyToChannel(new Float32Array(t), 0), s.set(i, m);
			}
			let h = e.createBufferSource(), g = e.createGain(), _ = e.createBiquadFilter(), v = e.createStereoPanner();
			h.buffer = m, h.playbackRate.value = 2 ** (f[`${i}Tune`] / 12), _.type = "lowpass", _.frequency.value = Math.min(2e4, o(f[`${i}Tone`])), _.Q.value = -3.01, v.pan.value = f[`${i}Pan`], g.gain.value = 0, h.connect(_).connect(g).connect(v).connect(t);
			let y = {
				voice: i,
				start: l,
				end: l + Math.min(m.duration / h.playbackRate.value, f[`${i}Decay`] * 2) + .01,
				peak: f[`${i}Level`] * a * p,
				decay: f[`${i}Decay`],
				source: h,
				gain: g,
				filter: _,
				pan: v
			};
			h.onended = () => u(y), c.add(y), h.start(l), d(i);
		},
		cancelScheduled(e) {
			for (let t of [...c]) t.start >= e && (t.source.stop(e), u(t));
			d();
		},
		dispose() {
			for (let e of [...c]) e.source.stop(), u(e);
			s.clear();
		}
	};
}
//#endregion
//#region src/audio/print.ts
var yn = (e, t) => Math.sin(2 * Math.PI * e * t);
function bn(e, t, n) {
	let r = new Float32Array(Math.ceil(e * t));
	return {
		data: r,
		each(t) {
			let i = n, a = 0;
			for (let n = 0; n < r.length; n++) {
				i ^= i << 13, i ^= i >>> 17, i ^= i << 5;
				let o = (i >>> 0) / 2 ** 31 - 1;
				a = .7 * a + .3 * o, r[n] = t(n / e, {
					noise: o,
					low: a,
					high: o - a,
					sin: yn
				}) * Math.min(1, n / 8) * Math.min(1, (r.length - 1 - n) / 256);
			}
		}
	};
}
function xn(e, t) {
	let n = 0;
	for (let t of e) n = Math.max(n, Math.abs(t));
	if (n > 0) for (let r = 0; r < e.length; r++) e[r] *= t / n;
}
//#endregion
//#region src/audio/forge.ts
var Sn = 44100, Cn = /* @__PURE__ */ new Map();
function wn(e, t, n, r) {
	let i = r, a = () => (i = i * 16807 % 2147483647, i / 2147483647);
	return Array.from({ length: e }, () => ({
		frequency: t * (n / t) ** a(),
		level: .4 + a(),
		decay: .6 + a(),
		phase: a() * 2 * Math.PI
	}));
}
function Tn(e) {
	let t = Cn.get(e);
	if (t) return t;
	let n = I.findIndex((t) => t.id === e);
	if (n < 0) throw Error(`Unknown FORGE voice: ${e}`);
	let { data: r, each: i } = bn(Sn, {
		crash: 4,
		china: 3,
		ride: 4,
		open: 2,
		anvil: 2,
		lowTom: 1.6,
		highTom: 1.3,
		kick: 1.2,
		snare: 1
	}[e] ?? .5, 9241 + n * 173), a = {
		hat: [
			26,
			3e3,
			14e3
		],
		pedal: [
			26,
			3e3,
			14e3
		],
		open: [
			30,
			2600,
			13e3
		],
		crash: [
			44,
			1800,
			12500
		],
		china: [
			40,
			1100,
			9e3
		],
		ride: [
			28,
			2400,
			11e3
		]
	}[e], o = a ? wn(a[0], a[1], a[2], 77 + n * 31) : [], s = o.map((e) => Math.sin(e.phase)), c = o.map((e) => Math.cos(e.phase)), l, u = (e, t) => {
		l ??= o.map((e) => ({
			cos: Math.cos(2 * Math.PI * e.frequency / Sn),
			sin: Math.sin(2 * Math.PI * e.frequency / Sn),
			fall: Math.exp(-t * e.decay / Sn)
		}));
		let n = 0;
		for (let e = 0; e < o.length; e++) {
			let { cos: t, sin: r, fall: i } = l[e], a = s[e], u = c[e];
			n += o[e].level * a, s[e] = (a * t + u * r) * i, c[e] = (u * t - a * r) * i;
		}
		return n / o.length;
	}, d = 0, f = 0;
	return i((t, { noise: n, high: r, sin: i }) => {
		if (f = .55 * f + .45 * r, e === "kick") {
			d += 2 * Math.PI * (52 + 88 * Math.exp(-t * 35)) / Sn;
			let e = Math.sin(d) * Math.exp(-t * 6.5), n = r * Math.exp(-t * 600) + .5 * i(3200, t) * Math.exp(-t * 300);
			return Math.tanh(2.6 * (e + .55 * n));
		}
		if (e === "snare") {
			let e = i(190, t) * Math.exp(-t * 22) + .6 * i(287, t) * Math.exp(-t * 28) + .35 * i(412, t) * Math.exp(-t * 35), r = f * Math.exp(-t * 10), a = n * Math.exp(-t * 220);
			return Math.tanh(1.9 * (.7 * e + 1.1 * r + .6 * a));
		}
		return e === "lowTom" || e === "highTom" ? (d += 2 * Math.PI * (e === "lowTom" ? 82 : 132) * (1 + .3 * Math.exp(-t * 30)) / Sn, Math.tanh(1.5 * ((Math.sin(d) + .25 * Math.sin(1.52 * d)) * Math.exp(-t * (e === "lowTom" ? 4.5 : 5.5)) + .4 * r * Math.exp(-t * 300)))) : e === "anvil" ? [
			[1, 4],
			[2.76, 6],
			[5.4, 9],
			[8.93, 13]
		].reduce((e, [n, r], a) => e + i(520 * n, t) * Math.exp(-t * r) / (a + 1), 0) + .6 * r * Math.exp(-t * 500) : e === "hat" ? .7 * u(t, 40) + .55 * f * Math.exp(-t * 55) + .5 * r * Math.exp(-t * 900) : e === "pedal" ? (.6 * u(t, 30) + .4 * f * Math.exp(-t * 35)) * Math.min(1, t * 400) : e === "open" ? .7 * u(t, 3.2) + .45 * f * Math.exp(-t * 4.5) + .4 * r * Math.exp(-t * 700) : e === "crash" ? (.8 * u(t, 1.3) + .6 * f * Math.exp(-t * 2.2)) * Math.min(1, t * 250) : e === "china" ? (.8 * u(t, 2.2) * (1 + .6 * i(370, t)) + .6 * f * Math.exp(-t * 3)) * Math.min(1, t * 300) : .55 * u(t, 1.1) + (.5 * i(3150, t) + .35 * i(4270, t)) * Math.exp(-t * 4) + .15 * f * Math.exp(-t * 2) + .4 * r * Math.exp(-t * 800);
	}), xn(r, .9), Cn.set(e, r), r;
}
function En(e) {
	let t = e.createBuffer(2, Math.ceil(e.sampleRate * .34), e.sampleRate), n = 31337;
	for (let r = 0; r < 2; r++) {
		let i = t.getChannelData(r);
		for (let t = 0; t < i.length; t++) {
			n ^= n << 13, n ^= n >>> 17, n ^= n << 5;
			let r = t / e.sampleRate;
			i[t] = ((n >>> 0) / 2 ** 31 - 1) * Math.exp(-r * 3) * Math.min(1, (i.length - 1 - t) / 64) * .35;
		}
	}
	return t;
}
function Dn(e, t, n) {
	let r = n(e.createGain()), i = n(e.createGain()), a = n(e.createWaveShaper()), o = n(e.createGain()), s = n(e.createConvolver()), c = n(e.createGain());
	a.curve = Float32Array.from({ length: 2049 }, (e, t) => {
		let n = (t / 1024 - 1) * 6;
		return Math.max(-1, Math.min(1, n > 0 ? Math.tanh(n) : Math.tanh(1.4 * n) * .9));
	}), a.oversample = "2x", r.connect(i).connect(t), a.connect(o).connect(t), s.buffer = En(e), s.connect(c).connect(t);
	let l = on(r, a), u = on(i, s), d = vn(e, r, {
		rate: Sn,
		sample: Tn,
		chokedBy: { open: ["hat", "pedal"] },
		peak: 1.4,
		tone: (e) => 1200 * 16 ** e
	}), f = 0, p, m = () => {
		f < I.length && (Tn(I[f++].id), p = setTimeout(m, 0));
	};
	p = setTimeout(m, 0);
	let h = !1;
	return {
		...d,
		dispose() {
			clearTimeout(p), d.dispose();
		},
		apply(t) {
			let n = (t, n) => {
				h ? t.setTargetAtTime(n, e.currentTime, .01) : t.value = n;
			};
			l(t.drive > 0, !h), u(t.room > 0, !h), n(i.gain, 1 - .45 * t.drive), n(o.gain, .75 * t.drive), n(c.gain, t.room * .9), h = !0;
		}
	};
}
//#endregion
//#region src/audio/rust.ts
var On = 4097;
function kn(e, t, n, r, i) {
	let a = 1 + 60 * t ** 2, o = .6 * n, s = .25 * i;
	return Float32Array.from({ length: On }, (t, n) => {
		let i = n / 4096 * 2 - 1, c = Math.sign(i) * Math.max(0, Math.abs(i) - s) / (1 - s), l = a * c + o * Math.min(1, a * Math.abs(c) * 4);
		switch (we[e]) {
			case "Rectify": return Math.abs(Math.tanh(1.5 * l));
			case "Fold": return Math.sin(Math.PI / 2 * l);
			case "Crush": {
				let e = 2 ** (r - 1);
				return Math.round(Math.tanh(l) * e) / e;
			}
			case "Broken": return l > 0 ? Math.tanh(3 * l) : Math.max(-.3, l * 1.5);
			default: return Math.max(-1, Math.min(1, l));
		}
	});
}
function An(e, t) {
	let n = t(e.createGain()), r = t(e.createGain()), i = t(e.createBiquadFilter()), a = t(e.createWaveShaper()), o = t(e.createBiquadFilter()), s = t(e.createBiquadFilter()), c = t(e.createGain()), l = t(e.createGain()), u = t(e.createGain());
	i.type = "peaking", i.Q.value = 1.1, i.gain.value = 9, o.type = "highpass", o.frequency.value = 30, s.type = "lowpass", s.Q.value = .5, n.connect(c).connect(u), n.connect(r).connect(i).connect(a).connect(o).connect(s).connect(l).connect(u);
	let d = "", f = !1;
	return {
		input: n,
		cv: r.gain,
		output: u,
		apply(t) {
			let n = (t, n) => {
				f ? t.setTargetAtTime(n, e.currentTime, .01) : t.value = n;
			}, r = [
				t.mode,
				t.drive,
				t.bias,
				t.crush,
				t.starve
			].join();
			r !== d && (a.curve = kn(t.mode, t.drive, t.bias, t.crush, t.starve), a.oversample = we[t.mode] === "Crush" ? "none" : "2x", d = r), n(i.frequency, t.body), n(s.frequency, 1500 * 12 ** t.tone), n(c.gain, 1 - t.mix), n(l.gain, t.mix * (.7 - .25 * t.drive)), n(u.gain, t.level * 1.4), f = !0;
		}
	};
}
//#endregion
//#region src/audio/processors.ts
var jn = (e) => 10 ** (e / 20), Mn = (e, t, n, r) => {
	r ? e.value = t : e.setTargetAtTime(t, n, .008);
}, Nn = [
	[2e-4, .3],
	[2e-4, .45],
	[4e-4, .6],
	[4e-4, .75],
	[4e-4, .9],
	[2e-4, 1]
], Pn = 24, Fn = 6;
function In(e, t, n) {
	let r = jn(e), i = e + t, a = jn(i), o = (e) => 20 * Math.log10(e), s = (e, t) => e < r ? e : r + (1 - Math.exp(-t * (e - r))) / t, c = (e, t) => e < r ? 1 : (o(s(e * 1.001, t)) - o(s(e, t))) / (o(e * 1.001) - o(e)), l = .1, u = 1e4, d = 5;
	for (let e = 0; e < 15; e++) c(a, d) < 1 / n ? u = d : l = d, d = Math.sqrt(l * u);
	return (1 / (1 < a ? s(1, d) : jn(o(s(a, d)) + (0 - i) / n))) ** .6;
}
function Ln(e, { keep: t }) {
	let n = (n = 1) => {
		let r = t(e.createGain());
		return r.gain.value = n, r;
	}, r = (n, r, i = 0) => {
		let a = t(e.createBiquadFilter());
		return a.type = n, a.frequency.value = r, a.gain.value = i, a.Q.value = -3.01, a;
	}, i = n(), a = n(), o = t(e.createWaveShaper()), s = n(), c = .2, l = .5 * (1 - Math.tanh(c) ** 2);
	o.curve = Float32Array.from({ length: 2049 }, (e, t) => (Math.tanh(2 * (t / 1024 - 1) + c) - Math.tanh(c)) / l), o.oversample = "2x";
	let u = t(e.createDynamicsCompressor());
	u.knee.value = Pn, u.ratio.value = Fn, i.connect(a).connect(o).connect(r("highpass", 12)).connect(r("lowshelf", 90, 1)).connect(r("highshelf", 9e3, -1)).connect(u).connect(s);
	let d = !0, f = NaN, p = 1;
	return {
		input: i,
		output: s,
		compressor: u,
		apply(t) {
			let n = e.currentTime, [r, i] = Nn[t.time] ?? Nn[1];
			f !== t.threshold && (f = t.threshold, p = In(t.threshold, Pn, Fn)), Mn(a.gain, jn(t.input) / 4, n, d), Mn(u.threshold, t.threshold, n, d), u.attack.value = r, u.release.value = i, Mn(s.gain, jn(t.output) / p, n, d), d = !1;
		}
	};
}
function Rn(e, t) {
	return [
		{
			type: "highpass",
			frequency: e.hpf <= 16 ? 0 : e.hpf,
			Q: -3.01,
			gain: 0
		},
		{
			type: e.lfBell ? "peaking" : "lowshelf",
			frequency: e.lfFreq,
			Q: .7,
			gain: e.lfGain
		},
		{
			type: "peaking",
			frequency: e.lmfFreq,
			Q: e.lmfQ,
			gain: e.lmfGain
		},
		{
			type: "peaking",
			frequency: e.hmfFreq,
			Q: e.hmfQ,
			gain: e.hmfGain
		},
		{
			type: e.hfBell ? "peaking" : "highshelf",
			frequency: e.hfFreq,
			Q: .7,
			gain: e.hfGain
		},
		{
			type: "lowpass",
			frequency: e.lpf >= 22e3 ? t : Math.min(e.lpf, t),
			Q: -3.01,
			gain: 0
		}
	];
}
function zn({ type: e, frequency: t, Q: n, gain: r }, i, a) {
	let o = a / 2;
	if (e === "highpass" && t <= 0 || e === "lowpass" && t >= o) return 0;
	let s = 10 ** (r / 40), c = 2 * Math.PI * t / a, l = Math.cos(c), u = Math.sin(c), d = u / (2 * 10 ** (n / 20)), f = u / (2 * n), p = u / 2 * Math.SQRT2 * 2 * Math.sqrt(s), [m, h, g, _, v, y] = {
		lowpass: [
			(1 - l) / 2,
			1 - l,
			(1 - l) / 2,
			1 + d,
			-2 * l,
			1 - d
		],
		highpass: [
			(1 + l) / 2,
			-(1 + l),
			(1 + l) / 2,
			1 + d,
			-2 * l,
			1 - d
		],
		peaking: [
			1 + f * s,
			-2 * l,
			1 - f * s,
			1 + f / s,
			-2 * l,
			1 - f / s
		],
		lowshelf: [
			s * (s + 1 - (s - 1) * l + p),
			2 * s * (s - 1 - (s + 1) * l),
			s * (s + 1 - (s - 1) * l - p),
			s + 1 + (s - 1) * l + p,
			-2 * (s - 1 + (s + 1) * l),
			s + 1 + (s - 1) * l - p
		],
		highshelf: [
			s * (s + 1 + (s - 1) * l + p),
			-2 * s * (s - 1 + (s + 1) * l),
			s * (s + 1 + (s - 1) * l - p),
			s + 1 - (s - 1) * l + p,
			2 * (s - 1 - (s + 1) * l),
			s + 1 - (s - 1) * l - p
		]
	}[e] ?? [
		1,
		0,
		0,
		1,
		0,
		0
	], b = 2 * Math.PI * i / a, x = Math.cos(b), S = Math.sin(b), C = Math.cos(2 * b), w = Math.sin(2 * b), T = (e, t, n) => Math.hypot(e + t * x + n * C, t * S + n * w);
	return 20 * Math.log10(T(m, h, g) / T(_, v, y));
}
function Bn(e, { keep: t }) {
	let n = (n = 1) => {
		let r = t(e.createGain());
		return r.gain.value = n, r;
	}, r = n(), i = n(), a = n(0), o = n(), s = e.sampleRate / 2, c = Array.from({ length: 6 }, () => t(e.createBiquadFilter()));
	c.reduce((e, t) => e.connect(t), r).connect(i).connect(o), r.connect(a).connect(o);
	let l = !0;
	return {
		input: r,
		output: o,
		apply(t) {
			let n = e.currentTime;
			Rn(t, s).forEach((e, t) => {
				let r = c[t];
				r.type !== e.type && (r.type = e.type), e.frequency <= 0 || e.frequency >= s ? (r.frequency.cancelScheduledValues(n), r.frequency.setValueAtTime(e.frequency, n)) : Mn(r.frequency, e.frequency, n, l), Mn(r.Q, e.Q, n, l), Mn(r.gain, e.gain, n, l);
			}), Mn(i.gain, +!t.active, n, l), Mn(a.gain, +!!t.active, n, l), Mn(o.gain, jn(t.output), n, l), l = !1;
		}
	};
}
//#endregion
//#region src/audio/session.ts
function Vn() {
	let e = typeof navigator > "u" ? void 0 : navigator.audioSession;
	if (!e || e.type === "playback") return () => {};
	let t = e.type;
	return e.type = "playback", () => {
		e.type === "playback" && (e.type = t);
	};
}
//#endregion
//#region src/audio/engine.ts
var Hn = [
	"sine",
	"triangle",
	"sawtooth",
	"square"
], Un = [
	"lowpass",
	"highpass",
	"bandpass"
], Wn = (e, t) => `${e}:${t}`, Gn = (e, t, n) => {
	e.setTargetAtTime(t, n, .008);
}, Kn = .5, qn = .09;
function Jn({ analyser: e, data: t }) {
	e.getFloatTimeDomainData(t);
	let n = 0;
	for (let e of t) n = Math.max(n, Math.abs(e));
	return n > 0 ? Math.max(-60, 20 * Math.log10(n)) : -60;
}
function Yn(e, t = 0, n = 2, r = !1, i = 0) {
	let a = e.createBuffer(r ? 2 : 1, Math.ceil(e.sampleRate * n), e.sampleRate), o = 90210;
	for (let n = 0; n < a.numberOfChannels; n++) {
		let r = a.getChannelData(n), s = 0;
		for (let n = 0; n < r.length; n++) {
			o ^= o << 13, o ^= o >>> 17, o ^= o << 5;
			let a = (o >>> 0) / 2 ** 31 - 1;
			s = t === 1 ? .93 * s + .2 * a : t === 2 ? (s + .035 * a) / 1.035 : a, r[n] = s * (i ? Math.exp(-n / e.sampleRate / i * 5) : 1);
		}
	}
	return a;
}
var Xn = "seq", Zn = "manual", Qn = class {
	context;
	onError;
	master;
	nodes = [];
	sources = [];
	runtime = /* @__PURE__ */ new Map();
	outputs = /* @__PURE__ */ new Map();
	inputs = /* @__PURE__ */ new Map();
	cvAmounts = /* @__PURE__ */ new Map();
	notes = /* @__PURE__ */ new Map();
	white = null;
	mix = tt;
	open = {};
	muted = !1;
	manualTarget = null;
	manualOwned = /* @__PURE__ */ new Set();
	targets = /* @__PURE__ */ new Map();
	pulses = /* @__PURE__ */ new Map();
	patch;
	constructor(e, t, n = e.destination, r = tt, i) {
		this.context = e, this.onError = i, this.patch = t, this.master = this.keep(e.createGain());
		let a = this.keep(e.createDynamicsCompressor());
		a.threshold.value = -12, a.knee.value = 12, a.ratio.value = 8, a.attack.value = .003, a.release.value = .15, this.master.connect(a).connect(n);
		for (let e of t.modules) this.buildModule(e);
		for (let e of t.modules) e.type === "performance" && this.targets.set(e.id, ot(t, e.id));
		for (let n of t.cables) {
			let r = this.outputs.get(Wn(n.from.moduleId, n.from.portId)), i = this.inputs.get(Wn(n.to.moduleId, n.to.portId));
			if (!r || !i || this.isNoteCable(n)) continue;
			let a = z[t.modules.find((e) => e.id === n.to.moduleId).type].ports.find((e) => e.id === n.to.portId);
			if (a.kind === "cv") {
				let t = this.keep(e.createGain());
				t.gain.value = n.amount * (a.scale ?? 1), r.connect(t), "setValueAtTime" in i, t.connect(i), this.cvAmounts.set(n.id, t);
			} else "setValueAtTime" in i, r.connect(i);
		}
		this.applyPatch(t, !0), this.setMix(r, !0);
		for (let e of this.sources) e.start(0);
	}
	keep(e) {
		return this.nodes.push(e), e;
	}
	isNoteCable(e) {
		return e.to.portId === "pitch" && Xe(this.patch.modules.find((t) => t.id === e.to.moduleId).type) && this.patch.modules.find((t) => t.id === e.from.moduleId)?.type === "performance";
	}
	polyNote(e, t, n, r) {
		let i = this.patch.cables.find((t) => t.to.moduleId === e && this.isNoteCable(t));
		return i ? 60 + ((i.from.moduleId === t ? n : this.noteAt(i.from.moduleId, r)) - 60) * i.amount : 60;
	}
	noteAt(e, t) {
		let n = this.notes.get(e) ?? [];
		for (let e = n.length - 1; e >= 0; e--) if (n[e].time <= t) return n[e].note;
		return 48;
	}
	get main() {
		return this.patch.modules[0].id;
	}
	gain(e = 1) {
		let t = this.keep(this.context.createGain());
		return t.gain.value = e, t;
	}
	source(e) {
		return "offset" in e && Qt(e.offset, this.context), this.keep(e), this.sources.push(e), e;
	}
	buildModule(e) {
		let { context: t } = this, n = (t) => Wn(e.id, t), r = (e, t) => this.inputs.set(n(e), t), i = this.gain(), a = (e, t, r = !0) => this.outputs.set(n(e), r ? t.connect(i) : t), o = !1, s = (e, n) => {
			o ? Gn(e, n, t.currentTime) : e.value = n;
		}, c = () => {}, l, u, d, f, p, m, h, g, _, v, y = (e) => {
			p = this.source(t.createConstantSource()), p.offset.value = 0;
			let n = this.gain(1200);
			p.connect(n), "setValueAtTime" in e, n.connect(e);
		};
		switch (e.type) {
			case "performance":
				l = this.source(t.createConstantSource()), l.offset.value = -1, a("pitch", l, !1);
				break;
			case "oscillator": {
				let e = this.source(t.createOscillator()), n = this.gain();
				e.frequency.value = 261.625565, e.connect(n), r("pitch", e.detune), y(e.detune), r("fm", e.detune), a("out", n), c = (t) => {
					e.type = Hn[t.wave], s(e.detune, t.octave * 1200 + t.tune * 100 + t.fine), s(n.gain, t.level * .35);
				};
				break;
			}
			case "monarch":
				this.white ??= Yn(t, 0, 1), f = an(t, this.white, {
					keep: (e) => this.keep(e),
					source: (e) => this.source(e)
				}), r("pitch", f.pitch), y(f.pitch), r("cv", f.cv), a("out", f.output), c = f.apply;
				break;
			case "oracle":
			case "aurora":
			case "prism": {
				this.white ??= Yn(t, 0, 1);
				let n = {
					onError: this.onError,
					keep: (e) => this.keep(e),
					source: (e) => this.source(e)
				};
				h = e.type === "oracle" ? un(t, this.white, n) : e.type === "aurora" ? dn(t, n) : mn(t, n), r("pitch", h.pitch), r("cv", h.cv), a("out", h.output), c = h.apply;
				break;
			}
			case "compressor":
				g = Ln(t, { keep: (e) => this.keep(e) }), r("in", g.input), a("out", g.output), c = g.apply;
				break;
			case "cohere":
			case "talon":
			case "brit":
				m = hn(t, e.type, (e) => this.keep(e), this.onError), r("in", m.input), a("out", m.output), c = m.apply;
				break;
			case "equalizer": {
				let e = Bn(t, { keep: (e) => this.keep(e) });
				r("in", e.input), a("out", e.output), c = e.apply;
				break;
			}
			case "noise": {
				let n = this.source(t.createBufferSource()), r = this.gain();
				n.buffer = Yn(t, e.params.color), n.loop = !0, n.connect(r), a("out", r), c = (e) => s(r.gain, e.level * .3);
				break;
			}
			case "mixer": {
				let e = () => {
					let e = this.keep(t.createAnalyser());
					return e.fftSize = 512, {
						analyser: e,
						data: new Float32Array(e.fftSize)
					};
				}, n = this.gain(), i = this.gain(), o = this.keep(t.createChannelSplitter(2));
				v = {
					channels: [],
					bus: [e(), e()]
				}, n.connect(i).connect(o), v.bus.forEach(({ analyser: e }, t) => o.connect(e, t));
				let l = be.map((i, a) => {
					let o = this.gain(), s = this.gain(), c = e(), l = [this.gain(), this.gain()], u = this.gain(), d = this.keep(t.createChannelSplitter(2)), f = this.keep(t.createChannelMerger(2));
					return u.channelCount = 2, u.channelCountMode = "explicit", u.channelInterpretation = "speakers", o.connect(s).connect(u).connect(d), s.connect(c.analyser), l.forEach((e, t) => d.connect(e, t).connect(f, 0, t)), f.connect(n), r(i, o), v.channels.push(c), {
						id: be[a],
						level: o,
						gate: s,
						sides: l
					};
				});
				_ = Object.fromEntries(l.map(({ id: e, gate: t }) => [e, t])), a("out", i), c = (e) => {
					for (let { id: t, level: n, sides: [r, i] } of l) {
						let a = e[xe(t)];
						s(n.gain, e[t]), s(r.gain, a > 0 ? Math.cos(a * Math.PI / 2) : 1), s(i.gain, a < 0 ? Math.cos(-a * Math.PI / 2) : 1);
					}
					s(i.gain, e.master);
				};
				break;
			}
			case "filter": {
				let e = this.keep(t.createBiquadFilter());
				r("in", e), r("cv", e.detune), a("out", e), c = (t) => {
					e.type = Un[t.mode], s(e.frequency, t.cutoff), s(e.Q, t.resonance);
				};
				break;
			}
			case "amplifier": {
				let t = this.gain(), n = this.gain();
				t.connect(n), t.gain.value = +!this.patch.cables.some((t) => t.to.moduleId === e.id && t.to.portId === "cv"), r("in", t), r("cv", t.gain), a("out", n), c = (e) => s(n.gain, e.level);
				break;
			}
			case "envelope": {
				let e = this.source(t.createConstantSource());
				e.offset.value = 0, a("out", e), u = nn(e.offset);
				break;
			}
			case "lfo": {
				let e = this.source(t.createOscillator());
				r("cv", e.frequency), a("out", e), c = (t) => {
					e.type = Hn[t.wave], s(e.frequency, t.rate);
				};
				break;
			}
			case "delay": {
				let e = this.gain(), n = this.gain(), i = this.gain(), o = this.gain(), l = this.keep(t.createDelay(1)), u = this.gain();
				e.connect(i).connect(n), e.connect(l).connect(o).connect(n), l.connect(u).connect(l), r("in", e), a("out", n), c = (e) => {
					s(l.delayTime, e.time), s(u.gain, e.feedback), s(i.gain, 1 - e.mix), s(o.gain, e.mix);
				};
				break;
			}
			case "reverb": {
				let e = this.gain(), n = this.gain(), i = this.gain(), o = this.gain(), l = this.keep(t.createConvolver());
				e.connect(i).connect(n), e.connect(l).connect(o).connect(n), r("in", e), a("out", n);
				let u = -1;
				c = (e) => {
					u !== e.decay && (l.buffer = Yn(t, 0, e.decay, !0, e.decay), u = e.decay), s(i.gain, 1 - e.mix), s(o.gain, e.mix);
				};
				break;
			}
			case "boom":
			case "punch":
			case "orbit":
			case "strike":
			case "forge": {
				let n = this.gain(), o = this.gain(), l = this.gain(), u = this.gain();
				n.connect(o).connect(i).connect(u), l.connect(u), r("chain", l), a("out", u, !1), this.white ??= Yn(t, 0, 1);
				let f = e.type === "forge" ? Dn(t, n, (e) => this.keep(e)) : void 0;
				d = f ?? (e.type === "strike" ? _n(t, n) : tn(t, e.type, n, {
					keep: (e) => this.keep(e),
					start: (e) => this.source(e),
					noise: this.white
				})), c = (e) => {
					f?.apply(e), s(o.gain, e.level * Kn);
				};
				break;
			}
			case "rust": {
				let e = An(t, (e) => this.keep(e));
				r("in", e.input), r("cv", e.cv), a("out", e.output), c = e.apply;
				break;
			}
			case "output": r("in", this.master), c = (e) => s(this.master.gain, this.muted ? 0 : e.volume * .8);
		}
		for (let t of z[e.type].ports) {
			let e = t.copyOf && this.outputs.get(n(t.copyOf));
			e && this.outputs.set(n(t.id), e);
		}
		this.runtime.set(e.id, {
			module: e,
			apply: (e) => {
				c(e), o = !0;
			},
			gate: i,
			channels: _,
			meters: v,
			pitch: l,
			envelope: u,
			drums: d,
			monarch: f,
			poly: h,
			valve: g,
			studio: m,
			manualPitch: p
		});
	}
	applyPatch(e, t = !1) {
		for (let n of e.modules) {
			let e = this.runtime.get(n.id);
			e && (t || JSON.stringify(e.module.params) !== JSON.stringify(n.params)) && (e.apply(n.params), e.module = n);
		}
		for (let n of e.cables) {
			let r = this.cvAmounts.get(n.id);
			if (r && (t || this.patch.cables.find((e) => e.id === n.id)?.amount !== n.amount)) {
				let t = e.modules.find((e) => e.id === n.to.moduleId), i = z[t.type].ports.find((e) => e.id === n.to.portId)?.scale ?? 1;
				Gn(r.gain, this.manualTarget === n.to.moduleId && n.to.portId === "pitch" && !Xe(t.type) ? 0 : n.amount * i, this.context.currentTime);
			}
		}
		this.patch = e;
	}
	gatedBy(e) {
		let t = new Set(this.patch.cables.filter((t) => t.from.moduleId === e && B(this.patch, t.from)?.kind === "gate").map((e) => e.to.moduleId));
		return [...this.runtime.values()].filter((e) => (e.envelope || e.monarch || e.poly) && t.has(e.module.id));
	}
	setMix(e, t = !1) {
		this.mix = e, this.open = st(this.patch, e);
		let n = (e, n) => {
			t ? e.gain.value = +!!n : Gn(e.gain, +!!n, this.context.currentTime);
		};
		for (let { module: t, gate: r, channels: i } of this.runtime.values()) {
			n(r, this.open[t.id] !== !1);
			for (let [r, a] of Object.entries(i ?? {})) n(a, G(t, r, e));
		}
	}
	openEnvelope(e, t, n, r, i, a) {
		if (e.monarch) {
			e.monarch.noteOn(t, n);
			return;
		}
		if (e.poly) {
			e.poly.noteOn(this.polyNote(e.module.id, a, r, n), t, n, i);
			return;
		}
		let o = e.module.params;
		e.envelope?.on(n, t, o.attack, o.decay, o.sustain);
	}
	closeEnvelope(e, t, n) {
		e.monarch && e.monarch.noteOff(t), e.poly?.noteOff(t, n), e.envelope?.off(t, e.module.params.release);
	}
	setNote(e, t, n) {
		let r = this.runtime.get(e)?.pitch;
		r && (r.offset.cancelScheduledValues(n), r.offset.setValueAtTime((t - 60) / 12, n), this.notes.set(e, [...(this.notes.get(e) ?? []).filter((e) => e.time < n).slice(-63), {
			time: n,
			note: t
		}]));
	}
	gateOn(e, t, n, r) {
		if (this.open[e] !== !1) for (let i of this.gatedBy(e)) this.manualOwned.has(i.module.id) || this.openEnvelope(i, n, r, t, Xn, e);
	}
	noteOn(e, t = 1, n = this.context.currentTime, r = this.main) {
		this.manualTarget !== r && (this.setNote(r, e, n), this.gateOn(r, e, t, n));
	}
	noteOff(e = this.context.currentTime, t = this.main) {
		for (let n of this.gatedBy(t)) this.manualOwned.has(n.module.id) || this.closeEnvelope(n, e, Xn);
	}
	sequence(e, t, n, r) {
		let i = t % 16, a = e.filter((e) => e !== this.manualTarget).flatMap((e) => {
			let t = Ne(this.patch, e)[i];
			return t?.enabled && ct(e, i, this.mix) ? [{
				id: e,
				step: t
			}] : [];
		});
		for (let { id: e, step: t } of a) this.setNote(e, t.note, n);
		for (let { id: e, step: t } of a) if (this.gateOn(e, t.note, t.velocity, n), this.noteOff(n + r * t.gate, e), this.open[e] !== !1) for (let t of this.targets.get(e) ?? []) this.pulse(t, n, e);
	}
	pulse(e, t, n) {
		this.pulses.set(e, [...(this.pulses.get(e) ?? []).slice(-63), {
			time: t,
			sequencer: n
		}]);
	}
	lastPulse(e, t) {
		let n = this.pulses.get(e);
		if (!n) return -1;
		let r = n.length - 1;
		for (; r >= 0 && n[r].time > t;) r--;
		return r > 0 && n.splice(0, r), r < 0 ? -1 : n[0].time;
	}
	mixerLevels(e) {
		let t = this.runtime.get(e)?.meters;
		return t ? {
			channels: t.channels.map(Jn),
			bus: t.bus.map(Jn)
		} : null;
	}
	manualOn(e, t, n = Zn) {
		this.manualTarget !== e && this.manualOff();
		let r = this.runtime.get(e), i = this.context.currentTime;
		if (r) {
			if (this.manualTarget = e, r.poly) {
				this.manualOwned = /* @__PURE__ */ new Set([e]), r.poly.noteOff(i, Xn), r.poly.noteOn(t, 1, i, n);
				return;
			}
			if (r.module.type === "performance") {
				if (this.manualOwned = new Set(this.gatedBy(e).map((e) => e.module.id)), this.setNote(e, t, i), this.open[e] === !1) return;
			} else {
				let n = Qe(this.patch, e);
				this.manualOwned = new Set(r.monarch ? [e] : this.patch.cables.filter((e) => n.has(e.to.moduleId) && this.runtime.get(e.from.moduleId)?.envelope).map((e) => e.from.moduleId));
				for (let t of this.patch.cables) t.to.moduleId === e && t.to.portId === "pitch" && this.cvAmounts.get(t.id)?.gain.setValueAtTime(0, i);
				r.manualPitch?.offset.setValueAtTime((t - 60) / 12, i);
			}
			for (let n of this.manualOwned) {
				let r = this.runtime.get(n);
				r.poly?.noteOff(i, Xn), this.openEnvelope(r, 1, i, t, Zn, e);
			}
		}
	}
	manualRelease(e) {
		this.runtime.get(this.manualTarget ?? "")?.poly?.noteOff(this.context.currentTime, e);
	}
	manualOff() {
		let e = this.context.currentTime, t = this.manualTarget;
		for (let t of this.manualOwned) {
			let n = this.runtime.get(t);
			n && this.closeEnvelope(n, e);
		}
		this.runtime.get(t ?? "")?.manualPitch?.offset.setValueAtTime(0, e);
		for (let n of this.patch.cables) n.to.moduleId === t && n.to.portId === "pitch" && this.cvAmounts.get(n.id)?.gain.setValueAtTime(n.amount * 1200, e);
		this.manualOwned.clear(), this.manualTarget = null;
	}
	reduction(e) {
		return this.runtime.get(e)?.studio?.reduction ?? this.runtime.get(e)?.valve?.compressor.reduction ?? 0;
	}
	drumStep(e, t, n) {
		for (let { module: r, drums: i } of this.runtime.values()) {
			let a = r.type === "skitter";
			if (!(i || a) || n && r.id !== n || a && this.open[r.id] === !1) continue;
			let o = Ke(r, e).filter(([e]) => G(r, e, this.mix)), s = Ft(this.patch.sequencer.bpm, this.patch.sequencer.swing, e % 16), c = (e) => e > 2 ? r.params.rollFade ?? 0 : 0;
			for (let [e, n] of o) for (let o = 0; o < n; o++) {
				let l = t + o * s / n, u = 1 - c(n) * o / n;
				a ? this.skitterHit(r, e, l, u, s / n) : i.trigger(e, l, r.params, u);
			}
			o.length && this.pulse(r.id, t, r.id);
		}
	}
	skitterTargets(e, t) {
		return this.patch.cables.filter((n) => n.from.moduleId === e && (B(this.patch, n.from)?.copyOf ?? n.from.portId) === t).map((e) => this.runtime.get(e.to.moduleId)).filter((e) => !!e);
	}
	skitterHit(e, t, n, r, i) {
		if (t === "synth") for (let t of this.skitterTargets(e.id, "gate")) !this.manualOwned.has(t.module.id) && (t.envelope || t.monarch || t.poly) && (this.openEnvelope(t, r, n, 60, Xn, e.id), this.closeEnvelope(t, n + i * (e.params.gate ?? .5), Xn), this.pulse(t.module.id, n, e.id));
		else for (let i of this.skitterTargets(e.id, "trig")) {
			let a = Ce[i.module.type]?.[t];
			a && i.drums && G(i.module, a, this.mix) && (i.drums.trigger(a, n, i.module.params, r), this.pulse(i.module.id, n, e.id));
		}
	}
	skitterKits(e) {
		return this.patch.modules.some((t) => t.id === e && t.type === "skitter") ? this.skitterTargets(e, "trig").filter((e) => e.drums).map((e) => e.module.id) : [];
	}
	hit(e, t, n = this.context.currentTime) {
		let r = this.runtime.get(e);
		r && G(r.module, t, this.mix) && (r.module.type === "skitter" ? this.open[e] !== !1 && this.skitterHit(r.module, t, n, 1, .12) : r.drums?.trigger(t, n, r.module.params));
	}
	cancelModule(e, t = this.context.currentTime) {
		let n = this.runtime.get(e);
		for (let [n, r] of this.pulses) this.pulses.set(n, r.filter((n) => n.sequencer !== e || n.time <= t));
		if (n?.drums && n.drums.cancelScheduled(t), n?.module.type === "skitter") {
			for (let n of this.skitterKits(e)) this.runtime.get(n).drums.cancelScheduled(t);
			for (let n of this.gatedBy(e)) this.manualOwned.has(n.module.id) || this.closeEnvelope(n, t, Xn);
		}
		n?.pitch && (this.noteOff(t, e), this.manualTarget !== e && (J(n.pitch.offset, t), this.notes.set(e, (this.notes.get(e) ?? []).filter((e) => e.time <= t))));
	}
	cancelScheduled(e = this.context.currentTime) {
		for (let t of this.patch.modules) Ze(t.type) && this.cancelModule(t.id, e);
	}
	setMute(e) {
		this.muted = e, Gn(this.master.gain, e ? 0 : this.patch.modules.find((e) => e.type === "output").params.volume * .8, this.context.currentTime);
	}
	async flush() {
		await Promise.all([...this.runtime.values()].map((e) => Promise.all([e.poly?.flush?.(), e.studio?.flush()])));
	}
	dispose() {
		for (let { poly: e, studio: t } of this.runtime.values()) e?.dispose?.(), t?.dispose();
		this.master.gain.cancelScheduledValues(this.context.currentTime), this.master.gain.value = 0;
		for (let { drums: e } of this.runtime.values()) e?.dispose();
		for (let e of this.sources) e.stop();
		for (let e of this.nodes) e.disconnect();
		this.sources = [], this.nodes = [];
	}
}, $n = (e) => JSON.stringify({
	modules: e.modules.map((e) => [
		e.id,
		e.type,
		e.type === "noise" ? e.params.color : null
	]).sort(),
	cables: e.cables.map((e) => [
		e.id,
		e.from,
		e.to
	]).sort()
}), er = class {
	patch;
	onError;
	context = null;
	graph = null;
	analyser = null;
	timer = null;
	notes = new Pt();
	target = null;
	running = /* @__PURE__ */ new Map();
	nextTime = 0;
	count = 0;
	timeline = [];
	frozen = -1;
	remaining = .04;
	muted = !1;
	mix = tt;
	suspended = !1;
	disposed = !1;
	revision = 0;
	manualRevision = 0;
	transportRevision = 0;
	moduleRevisions = /* @__PURE__ */ new Map();
	releaseSession = null;
	inputs = /* @__PURE__ */ new Map();
	held = /* @__PURE__ */ new Map();
	playing = !1;
	constructor(e, t) {
		this.patch = e, this.onError = t;
	}
	get activeNote() {
		return this.notes.current;
	}
	get activeNotes() {
		return this.poly ? this.notes.entries.map(([, e]) => e) : this.notes.current === null ? [] : [this.notes.current];
	}
	get poly() {
		let e = this.patch.modules.find((e) => e.id === this.target)?.type;
		return !!e && Xe(e);
	}
	reduction(e) {
		return this.ready ? this.graph.reduction(e) : 0;
	}
	get sampleRate() {
		return this.context?.sampleRate ?? 48e3;
	}
	get ready() {
		return !!this.graph && this.context?.state === "running";
	}
	get sounding() {
		let e = this.context?.currentTime ?? 0;
		for (; this.timeline.length > 1 && this.timeline[1].time <= e;) this.timeline.shift();
		return this.playing && this.timeline[0]?.time <= e ? this.timeline[0] : null;
	}
	get clock() {
		return this.sounding?.count ?? this.frozen;
	}
	get step() {
		return this.clock < 0 ? -1 : this.clock % 16;
	}
	modulePlaying(e) {
		return this.playing && this.running.has(e);
	}
	moduleClock(e) {
		let t = this.clock;
		return this.running.has(e) && t >= this.running.get(e) ? t : -1;
	}
	pulsing(e) {
		if (!this.graph || !this.context || !this.ready) return !1;
		let t = this.context.currentTime - (this.context.outputLatency || 0), n = this.graph.lastPulse(e, t);
		return n >= 0 && t - n < qn;
	}
	mixerLevels(e) {
		let t = {
			channels: be.map(() => -60),
			bus: [-60, -60]
		}, n = this.graph && this.ready ? this.graph.mixerLevels(e) : null;
		if (!n || !this.context) return this.held.delete(e), t;
		let r = this.context.currentTime, i = this.held.get(e), a = i ? (r - i.time) * 24 : 0, o = (e, t, n) => Math.max(e, n ? n[t] - a : -60), s = {
			channels: n.channels.map((e, t) => o(e, t, i?.levels.channels)),
			bus: n.bus.map((e, t) => o(e, t, i?.levels.bus))
		};
		return this.held.set(e, {
			time: r,
			levels: s
		}), s;
	}
	get meter() {
		if (!this.analyser || !this.ready) return 0;
		let e = new Float32Array(this.analyser.fftSize);
		return this.analyser.getFloatTimeDomainData(e), Math.min(1, Math.sqrt(e.reduce((e, t) => e + t * t, 0) / e.length) * 6);
	}
	async unlock() {
		if (this.suspended || this.disposed) return !1;
		let e = this.revision;
		if (!this.context) {
			if (typeof AudioContext > "u") throw Error("Web Audio is unavailable in this browser. Try a current Chrome or Safari.");
			this.releaseSession = Vn(), this.context = new AudioContext({ latencyHint: "interactive" }), this.analyser = this.context.createAnalyser(), this.analyser.fftSize = 256, this.analyser.connect(this.context.destination);
		}
		let t = this.context;
		if (await t.resume(), this.disposed || this.suspended || e !== this.revision) return !1;
		try {
			await Y(t);
		} catch (t) {
			if (this.disposed || this.suspended || e !== this.revision) return !1;
			throw t;
		}
		return this.disposed || this.suspended || e !== this.revision ? !1 : (this.graph || (this.graph = new Qn(this.context, this.patch, this.analyser, this.mix, (e) => {
			this.panic(), this.onError?.(e);
		}), this.graph.setMute(this.muted)), !0);
	}
	unlockForInput(e, t = !1) {
		return e === void 0 ? this.unlock() : (this.inputs.get(e)?.cancel(), new Promise((n, r) => {
			let i = () => {
				this.inputs.get(e) === a && this.inputs.delete(e);
			}, a = {
				started: !1,
				cancel: () => {
					i(), n(!1);
				},
				start: (e) => {
					a.started = !0, e.then((e) => {
						i(), n(e);
					}, (e) => {
						i(), r(e);
					});
				}
			};
			this.inputs.set(e, a), (!t || this.ready) && a.start(this.unlock());
		}));
	}
	lifted(e) {
		if (e !== void 0 && !this.inputs.has(e)) return;
		let t = [...this.inputs.values()].filter((e) => !e.started);
		if (!t.length) return;
		let n = this.unlock();
		for (let e of t) e.start(n);
	}
	update(e) {
		let t = $n(e) !== $n(this.patch);
		this.patch = e;
		for (let t of this.running.keys()) e.modules.some((e) => e.id === t && Ze(e.type)) || this.running.delete(t);
		if (this.target && !e.modules.some((e) => e.id === this.target) && this.releaseManual(), this.playing && !this.running.size && this.pause(), this.graph && this.context) {
			if (t) {
				if (this.graph.dispose(), this.graph = new Qn(this.context, e, this.analyser, this.mix, (e) => {
					this.panic(), this.onError?.(e);
				}), this.graph.setMute(this.muted), this.target && this.poly) for (let [e, t] of this.notes.entries) this.graph.manualOn(this.target, t, e);
				else this.notes.current !== null && this.target && this.graph.manualOn(this.target, this.notes.current);
				for (let e of this.timeline) e.time >= this.context.currentTime && this.schedule([...this.running.keys()], e);
			} else this.graph.applyPatch(e);
		}
	}
	async press(e, t, n = this.patch.modules[0].id, r = !1) {
		if (this.suspended || this.disposed) return;
		n !== this.target && this.releaseManual(), this.target = n, this.notes.press(e, t);
		let i = this.manualRevision, a = !this.ready;
		await this.unlockForInput(e, r) && i === this.manualRevision && this.target === n && (this.poly ? this.notes.has(e) ? this.graph.manualOn(n, t, e) : a && this.tap(n, t, e) : this.notes.current === null ? a && this.tap(n, t) : this.graph.manualOn(n, this.notes.current));
	}
	tap(e, t, n) {
		let r = this.manualRevision;
		this.graph.manualOn(e, t, n), setTimeout(() => {
			r === this.manualRevision && this.target === e && this.graph && (n === void 0 ? this.notes.current === null && this.graph.manualOff() : this.notes.has(n) || this.graph.manualRelease(n));
		}, 150);
	}
	release(e) {
		if (this.poly) {
			if (!this.notes.has(e)) return;
			this.notes.release(e) === null ? this.graph?.manualOff() : this.graph?.manualRelease(e);
			return;
		}
		let t = this.notes.current, n = this.notes.release(e);
		t !== n && (n !== null && this.target ? this.graph?.manualOn(this.target, n) : this.graph?.manualOff());
	}
	async hit(e, t, n, r = !1) {
		if (this.suspended || this.disposed) return;
		let i = this.manualRevision;
		await this.unlockForInput(n, r) && i === this.manualRevision && this.graph.hit(e, t);
	}
	cancel(e) {
		this.inputs.get(e)?.cancel(), this.release(e);
	}
	releaseManual() {
		this.manualRevision++, this.notes.clear(), this.graph?.manualOff(), this.target = null;
		for (let e of this.inputs.values()) e.cancel();
	}
	schedule(e, t) {
		if (!this.graph) return;
		let n = e.filter((e) => this.patch.modules.some((t) => t.id === e && t.type === "performance"));
		this.graph.sequence(n, t.count, t.time, t.duration);
		for (let r of e) n.includes(r) || this.graph.drumStep(t.count, t.time, r);
	}
	startClock() {
		this.playing = !0, this.nextTime = this.context.currentTime + Math.max(.01, this.remaining), this.timeline = [], this.tick(), this.timer = setInterval(() => this.tick(), 25);
	}
	async play(e) {
		let t = this.transportRevision, n = this.patch.modules.filter((t) => Ze(t.type) && (!e || t.id === e)).map((e) => ({
			id: e.id,
			revision: this.moduleRevisions.get(e.id)
		}));
		if (!await this.unlock() || t !== this.transportRevision) return;
		let r = n.filter((e) => e.revision === this.moduleRevisions.get(e.id) && this.patch.modules.some((t) => t.id === e.id)).map((e) => e.id);
		if (r.length) {
			if (this.playing) {
				let e = this.timeline.filter((e) => e.time > this.context.currentTime);
				for (let t of r) if (!this.running.has(t)) {
					this.running.set(t, e[0]?.count ?? this.count);
					for (let n of e) this.schedule([t], n);
				}
			} else {
				this.running.clear();
				for (let e of r) this.running.set(e, this.count);
				this.startClock();
			}
		}
	}
	stopModule(e) {
		let t = this.graph?.skitterKits(e) ?? [];
		if (this.moduleRevisions.set(e, (this.moduleRevisions.get(e) ?? 0) + 1), this.running.delete(e), this.graph?.cancelModule(e), t.length && this.graph && this.context) {
			let e = [...this.running.keys()].filter((e) => t.includes(e) || this.graph.skitterKits(e).some((e) => t.includes(e)));
			for (let t of this.timeline) t.time >= this.context.currentTime && this.schedule(e, t);
		}
		this.running.size || this.pause();
	}
	tick() {
		if (this.context && this.graph && this.playing) for (; this.nextTime < this.context.currentTime + .1;) {
			let e = Ft(this.patch.sequencer.bpm, this.patch.sequencer.swing, this.count % 16), t = {
				count: this.count,
				time: this.nextTime,
				duration: e
			};
			this.timeline.push(t), this.schedule([...this.running.keys()], t), this.nextTime += e, this.count++;
		}
	}
	pause() {
		if (this.transportRevision++, !this.playing) return;
		let e = this.context.currentTime;
		this.frozen = this.sounding?.count ?? this.frozen;
		let t = this.timeline.find((t) => t.time > e);
		this.count = t?.count ?? this.count, this.remaining = Math.max(0, (t?.time ?? this.nextTime) - e), this.playing = !1, this.timer && clearInterval(this.timer), this.timer = null, this.timeline = [], this.graph?.cancelScheduled();
	}
	reset() {
		this.pause(), this.running.clear(), this.frozen = -1, this.count = 0, this.remaining = .04;
	}
	stop() {
		this.reset();
	}
	setMute(e) {
		this.muted = e, this.graph?.setMute(e);
	}
	setMix(e) {
		this.mix = e, this.graph?.setMix(e);
	}
	panic() {
		this.revision++, this.reset(), this.releaseManual(), this.graph?.dispose(), this.graph = null;
	}
	setSuspended(e) {
		this.suspended = e, e && this.panic();
	}
	dispose() {
		this.disposed = !0, this.panic(), this.analyser?.disconnect(), this.context && this.context.close().catch(() => {}), this.context = null, this.releaseSession?.(), this.releaseSession = null;
	}
};
async function tr(e, t = 4, n = tt) {
	let r = 44100, i = K(e, t, .04), a = new OfflineAudioContext(2, Math.ceil((i.duration + 2.04) * r), r);
	e.modules.some((e) => [
		"prism",
		"cohere",
		"talon",
		"brit"
	].includes(e.type)) && await Y(a);
	let o = new Qn(a, e, a.destination, n), s = e.modules.filter((e) => e.type === "performance").map((e) => e.id);
	i.events.forEach(({ time: e, duration: t }, n) => {
		o.sequence(s, n, e, t), o.drumStep(n, e);
	});
	try {
		return await o.flush(), await a.startRendering();
	} finally {
		o.dispose();
	}
}
function nr(e) {
	let t = e.numberOfChannels, n = e.length * t * 2, r = new ArrayBuffer(44 + n), i = new DataView(r), a = (e, t) => {
		for (let n = 0; n < t.length; n++) i.setUint8(e + n, t.charCodeAt(n));
	};
	a(0, "RIFF"), i.setUint32(4, 36 + n, !0), a(8, "WAVE"), a(12, "fmt "), i.setUint32(16, 16, !0), i.setUint16(20, 1, !0), i.setUint16(22, t, !0), i.setUint32(24, e.sampleRate, !0), i.setUint32(28, e.sampleRate * t * 2, !0), i.setUint16(32, t * 2, !0), i.setUint16(34, 16, !0), a(36, "data"), i.setUint32(40, n, !0);
	let o = Array.from({ length: t }, (t, n) => e.getChannelData(n));
	for (let n = 0; n < e.length; n++) for (let e = 0; e < t; e++) {
		let r = Math.max(-1, Math.min(1, o[e][n]));
		i.setInt16(44 + (n * t + e) * 2, Math.round(r * (r < 0 ? 32768 : 32767)), !0);
	}
	return r;
}
var Q = {
	app: "_app_ju1b3_1",
	toolbar: "_toolbar_ju1b3_21",
	brand: "_brand_ju1b3_22",
	brandMark: "_brandMark_ju1b3_26",
	toolbarActions: "_toolbarActions_ju1b3_27",
	audioButton: "_audioButton_ju1b3_29",
	statusLed: "_statusLed_ju1b3_30",
	rackLight: "_rackLight_ju1b3_30",
	deviceLed: "_deviceLed_ju1b3_30",
	patchBar: "_patchBar_ju1b3_32",
	patchName: "_patchName_ju1b3_33",
	nameField: "_nameField_ju1b3_36",
	dirtyMark: "_dirtyMark_ju1b3_39",
	saveStatus: "_saveStatus_ju1b3_40",
	saveText: "_saveText_ju1b3_41",
	saveLed: "_saveLed_ju1b3_42",
	exportControls: "_exportControls_ju1b3_44",
	visuallyHidden: "_visuallyHidden_ju1b3_45",
	historyActions: "_historyActions_ju1b3_46",
	icon: "_icon_ju1b3_48",
	patchFile: "_patchFile_ju1b3_50",
	rackActions: "_rackActions_ju1b3_50",
	addButton: "_addButton_ju1b3_52",
	flipButton: "_flipButton_ju1b3_53",
	rackHeading: "_rackHeading_ju1b3_54",
	rack: "_rack_ju1b3_30",
	module: "_module_ju1b3_57",
	revealFlash: "_revealFlash_ju1b3_1",
	moduleHeader: "_moduleHeader_ju1b3_73",
	moduleIdentity: "_moduleIdentity_ju1b3_74",
	moduleName: "_moduleName_ju1b3_75",
	moduleSubtitle: "_moduleSubtitle_ju1b3_76",
	moduleTools: "_moduleTools_ju1b3_77",
	moduleNumber: "_moduleNumber_ju1b3_78",
	screw: "_screw_ju1b3_80",
	screwTL: "_screwTL_ju1b3_82",
	screwTR: "_screwTR_ju1b3_82",
	screwBL: "_screwBL_ju1b3_82",
	screwBR: "_screwBR_ju1b3_82",
	moduleBody: "_moduleBody_ju1b3_83",
	controls: "_controls_ju1b3_84",
	knobControl: "_knobControl_ju1b3_85",
	controlLabel: "_controlLabel_ju1b3_86",
	dial: "_dial_ju1b3_87",
	dialTicks: "_dialTicks_ju1b3_88",
	dialCap: "_dialCap_ju1b3_89",
	knobValue: "_knobValue_ju1b3_92",
	selectControl: "_selectControl_ju1b3_93",
	choiceGlyph: "_choiceGlyph_ju1b3_95",
	moduleDecoration: "_moduleDecoration_ju1b3_96",
	deviceLabel: "_deviceLabel_ju1b3_98",
	envelopeGraphic: "_envelopeGraphic_ju1b3_100",
	drumPads: "_drumPads_ju1b3_102",
	drumLane: "_drumLane_ju1b3_103",
	voiceButton: "_voiceButton_ju1b3_104",
	pads: "_pads_ju1b3_105",
	padGroup: "_padGroup_ju1b3_106",
	pad: "_pad_ju1b3_105",
	euclid: "_euclid_ju1b3_112",
	euclidHeading: "_euclidHeading_ju1b3_114",
	euclidCell: "_euclidCell_ju1b3_115",
	orbitRings: "_orbitRings_ju1b3_116",
	orbitPath: "_orbitPath_ju1b3_118",
	mixButtons: "_mixButtons_ju1b3_120",
	muteToggle: "_muteToggle_ju1b3_122",
	soloToggle: "_soloToggle_ju1b3_123",
	clearToggle: "_clearToggle_ju1b3_124",
	sequenceBody: "_sequenceBody_ju1b3_126",
	step: "_step_ju1b3_126",
	stepCell: "_stepCell_ju1b3_128",
	sequenceTop: "_sequenceTop_ju1b3_130",
	lcd: "_lcd_ju1b3_131",
	lcdDots: "_lcdDots_ju1b3_134",
	numberField: "_numberField_ju1b3_135",
	tempoSlider: "_tempoSlider_ju1b3_138",
	swingField: "_swingField_ju1b3_143",
	transport: "_transport_ju1b3_145",
	playButton: "_playButton_ju1b3_146",
	transportCaption: "_transportCaption_ju1b3_148",
	steps: "_steps_ju1b3_149",
	stepLed: "_stepLed_ju1b3_151",
	stepNumber: "_stepNumber_ju1b3_155",
	sequenceHint: "_sequenceHint_ju1b3_156",
	stepEditor: "_stepEditor_ju1b3_157",
	meters: "_meters_ju1b3_159",
	meterRow: "_meterRow_ju1b3_160",
	muteButton: "_muteButton_ju1b3_161",
	rackBottom: "_rackBottom_ju1b3_162",
	keyboardPanel: "_keyboardPanel_ju1b3_163",
	keyboardTop: "_keyboardTop_ju1b3_164",
	keyHint: "_keyHint_ju1b3_164",
	octaveControls: "_octaveControls_ju1b3_165",
	keysToggle: "_keysToggle_ju1b3_165",
	piano: "_piano_ju1b3_166",
	whiteKey: "_whiteKey_ju1b3_168",
	blackKey: "_blackKey_ju1b3_170",
	toastAnchor: "_toastAnchor_ju1b3_173",
	toast: "_toast_ju1b3_173",
	library: "_library_ju1b3_176",
	libraryHeading: "_libraryHeading_ju1b3_177",
	libraryGrid: "_libraryGrid_ju1b3_178",
	presetBrowser: "_presetBrowser_ju1b3_180",
	presetActions: "_presetActions_ju1b3_181",
	sectionLabel: "_sectionLabel_ju1b3_182",
	presetList: "_presetList_ju1b3_183",
	presetRow: "_presetRow_ju1b3_184",
	presetLoad: "_presetLoad_ju1b3_186",
	presetConfirm: "_presetConfirm_ju1b3_189",
	dangerButton: "_dangerButton_ju1b3_190",
	presetEmpty: "_presetEmpty_ju1b3_191",
	factoryGrid: "_factoryGrid_ju1b3_193",
	saveDialog: "_saveDialog_ju1b3_194",
	saveTitle: "_saveTitle_ju1b3_195",
	saveWarning: "_saveWarning_ju1b3_197",
	saveNote: "_saveNote_ju1b3_198",
	saveButtons: "_saveButtons_ju1b3_199",
	saveButton: "_saveButton_ju1b3_199",
	miniDevice: "_miniDevice_ju1b3_200",
	routingBar: "_routingBar_ju1b3_201",
	legend: "_legend_ju1b3_202",
	portGroups: "_portGroups_ju1b3_204",
	portGroup: "_portGroup_ju1b3_204",
	portHeading: "_portHeading_ju1b3_204",
	portRow: "_portRow_ju1b3_204",
	socketControl: "_socketControl_ju1b3_204",
	jacks: "_jacks_ju1b3_206",
	socket: "_socket_ju1b3_204",
	trim: "_trim_ju1b3_209",
	cables: "_cables_ju1b3_212",
	cableHits: "_cableHits_ju1b3_212",
	cable: "_cable_ju1b3_212",
	cableLine: "_cableLine_ju1b3_216",
	cableShadow: "_cableShadow_ju1b3_216",
	cableHit: "_cableHit_ju1b3_212",
	loosePlug: "_loosePlug_ju1b3_218",
	helpBackdrop: "_helpBackdrop_ju1b3_220",
	help: "_help_ju1b3_220",
	helpHeading: "_helpHeading_ju1b3_220",
	hitLed: "_hitLed_ju1b3_228",
	globalControls: "_globalControls_ju1b3_243",
	globalTransport: "_globalTransport_ju1b3_244",
	resetButton: "_resetButton_ju1b3_248",
	clearAllButton: "_clearAllButton_ju1b3_249",
	globalPosition: "_globalPosition_ju1b3_253",
	keyboardTarget: "_keyboardTarget_ju1b3_254",
	routingHint: "_routingHint_ju1b3_255",
	moduleNameButton: "_moduleNameButton_ju1b3_257",
	moduleTransport: "_moduleTransport_ju1b3_258",
	performancePads: "_performancePads_ju1b3_261",
	orbitEditor: "_orbitEditor_ju1b3_267",
	orbitVoiceEditor: "_orbitVoiceEditor_ju1b3_268",
	orbitEditorHeading: "_orbitEditorHeading_ju1b3_269",
	orbitSteps: "_orbitSteps_ju1b3_273",
	groupControls: "_groupControls_ju1b3_280",
	grMeter: "_grMeter_ju1b3_297",
	grUnit: "_grUnit_ju1b3_300",
	grNeedle: "_grNeedle_ju1b3_301",
	eqGraphic: "_eqGraphic_ju1b3_316",
	soundEditor: "_soundEditor_ju1b3_359",
	editorHeading: "_editorHeading_ju1b3_360",
	fmDisplay: "_fmDisplay_ju1b3_363",
	operatorTabs: "_operatorTabs_ju1b3_365",
	console: "_console_ju1b3_403",
	channelStrip: "_channelStrip_ju1b3_404",
	mixBus: "_mixBus_ju1b3_404",
	scribble: "_scribble_ju1b3_406",
	channelSource: "_channelSource_ju1b3_408",
	faderValue: "_faderValue_ju1b3_411",
	faderBay: "_faderBay_ju1b3_414",
	faderScale: "_faderScale_ju1b3_415",
	faderSlot: "_faderSlot_ju1b3_417",
	faderCap: "_faderCap_ju1b3_419",
	levelMeter: "_levelMeter_ju1b3_422",
	processorHint: "_processorHint_ju1b3_440",
	britPanel: "_britPanel_ju1b3_457",
	britSection: "_britSection_ju1b3_458",
	britWell: "_britWell_ju1b3_460",
	panelLegend: "_panelLegend_ju1b3_461",
	marconi: "_marconi_ju1b3_465",
	marconiRing: "_marconiRing_ju1b3_465",
	marconiSkirt: "_marconiSkirt_ju1b3_470",
	marconiFlutes: "_marconiFlutes_ju1b3_471",
	marconiDome: "_marconiDome_ju1b3_473",
	marconiPointer: "_marconiPointer_ju1b3_475",
	ringPointer: "_ringPointer_ju1b3_480",
	britCurve: "_britCurve_ju1b3_483",
	britSwitch: "_britSwitch_ju1b3_485",
	britLamp: "_britLamp_ju1b3_487",
	talonPanel: "_talonPanel_ju1b3_491",
	talonSection: "_talonSection_ju1b3_492",
	talonWell: "_talonWell_ju1b3_494",
	talonKnob: "_talonKnob_ju1b3_495",
	talonGrip: "_talonGrip_ju1b3_498",
	talonCap: "_talonCap_ju1b3_499",
	talonIndex: "_talonIndex_ju1b3_500",
	talonLamps: "_talonLamps_ju1b3_503",
	talonLed: "_talonLed_ju1b3_508",
	talonLatches: "_talonLatches_ju1b3_510",
	talonPush: "_talonPush_ju1b3_511",
	talonMeter: "_talonMeter_ju1b3_513",
	talonSwitch: "_talonSwitch_ju1b3_520",
	talonLamp: "_talonLamp_ju1b3_503",
	talonOutput: "_talonOutput_ju1b3_524",
	rollBrush: "_rollBrush_ju1b3_539"
};
//#endregion
//#region src/components/Knob.tsx
function rr(e, t) {
	return e.choices ? e.choices[t] ?? "" : e.unit === "Hz" && t >= 1e3 ? `${(t / 1e3).toFixed(1)}k` : e.unit === "s" && t < .001 ? `${Math.round(t * 1e6)}μs` : e.unit === "s" && t < 1 ? `${e.step < .001 ? Number((t * 1e3).toFixed(2)) : Math.round(t * 1e3)}ms` : `${Number(t.toFixed(2))}${e.unit ?? ""}`;
}
function ir({ param: e, value: t, onChange: n, prefix: r = "", format: i, disabled: a = !1, travel: o = 130 }) {
	let s = l(null), c = jt(e, t), u = Math.max(4, Math.ceil(-Math.log10(e.step)));
	function d(t) {
		let r = Math.max(0, Math.min(1, t)), i = e.logarithmic ? e.min * (e.max / e.min) ** r : e.min + r * (e.max - e.min);
		n(Math.max(e.min, Math.min(e.max, Number((Math.round(i / e.step) * e.step).toFixed(u)))));
	}
	function f(e) {
		e.isPrimary && e.button === 0 && (s.current = {
			y: e.clientY,
			fraction: c
		}, e.currentTarget.setPointerCapture(e.pointerId), e.preventDefault());
	}
	let p = i ? i(t) : rr(e, t);
	return {
		props: {
			role: "slider",
			tabIndex: a ? -1 : 0,
			"aria-disabled": a || void 0,
			"aria-label": `${r} ${e.label}`.trim(),
			"aria-valuemin": e.min,
			"aria-valuemax": e.max,
			"aria-valuenow": t,
			"aria-valuetext": p,
			onPointerDown: a ? void 0 : f,
			onPointerMove: (e) => {
				s.current && d(s.current.fraction + (s.current.y - e.clientY) / o);
			},
			onPointerUp: () => {
				s.current = null;
			},
			onPointerCancel: () => {
				s.current = null;
			},
			onDoubleClick: a ? void 0 : () => n(e.initial),
			onKeyDown: (r) => {
				!a && [
					"ArrowUp",
					"ArrowRight",
					"ArrowDown",
					"ArrowLeft",
					"Home",
					"End"
				].includes(r.key) && (r.preventDefault(), r.key === "Home" ? n(e.min) : r.key === "End" ? n(e.max) : e.logarithmic ? d(c + (["ArrowUp", "ArrowRight"].includes(r.key) ? .025 : -.025)) : n(Math.max(e.min, Math.min(e.max, Number((t + (["ArrowUp", "ArrowRight"].includes(r.key) ? e.step : -e.step)).toFixed(u))))));
			}
		},
		fraction: c,
		display: p
	};
}
function ar({ param: e, value: t, onChange: n, prefix: r = "", format: i, trim: a = !1, disabled: o = !1, caption: s }) {
	let { props: c, fraction: l, display: u } = ir({
		param: e,
		value: t,
		onChange: n,
		prefix: r,
		format: i,
		disabled: o
	}), d = /* @__PURE__ */ m("div", {
		className: a ? `${Q.dial} ${Q.trim}` : Q.dial,
		...c,
		title: a ? `${e.label} ${u}` : void 0,
		children: [/* @__PURE__ */ p("span", { className: Q.dialTicks }), /* @__PURE__ */ p("span", {
			className: Q.dialCap,
			style: { transform: `rotate(${-135 + l * 270}deg)` },
			children: /* @__PURE__ */ p("span", {})
		})]
	});
	return a ? d : /* @__PURE__ */ m("div", {
		className: Q.knobControl,
		children: [
			/* @__PURE__ */ p("span", {
				className: Q.controlLabel,
				children: s ?? e.label
			}),
			d,
			/* @__PURE__ */ p("span", {
				className: Q.knobValue,
				children: u
			})
		]
	});
}
//#endregion
//#region src/components/CableLayer.tsx
var or = (e) => `${e.moduleId}:${e.portId}`, sr = (e, t) => {
	let n = Math.min(140, Math.abs(e.y - t.y) * .2 + Math.abs(e.x - t.x) * .25 + 40);
	return `M${e.x},${e.y} C${e.x + 12},${e.y + n} ${t.x - 12},${t.y + n} ${t.x},${t.y}`;
};
function cr({ patch: e, rackRef: t, selected: n, onSelect: r, drag: i }) {
	let [a, s] = u({}), [c, l] = u(null);
	o(() => {
		let e = t.current;
		if (!e) return;
		function n() {
			let t = e.getBoundingClientRect(), n = {};
			e.querySelectorAll("[data-port-key]").forEach((r) => {
				let i = r.getBoundingClientRect();
				n[r.dataset.portKey] = {
					x: i.x - t.x + i.width / 2 + e.scrollLeft,
					y: i.y - t.y + i.height / 2 + e.scrollTop
				};
			}), s(n);
		}
		n();
		let r = new ResizeObserver(n);
		return r.observe(e), e.querySelectorAll("article").forEach((e) => r.observe(e)), window.addEventListener("resize", n), () => {
			r.disconnect(), window.removeEventListener("resize", n);
		};
	}, [e.modules, t]);
	let d = (t) => {
		let n = e.modules.find((e) => e.id === t.moduleId), r = z[n.type].ports, i = B(e, t), a = Fe(r, i), o = n.type === "mixer" && i.direction === "in" ? `Channel ${i.id.toUpperCase()}: ${dt(e, n.id, i.id).source}` : i.label;
		return `${z[n.type].name} ${o}${a && a > 1 ? ` ${a}` : ""}`;
	}, h = i && B(e, i.anchor), g = i && a[or(i.anchor)], _ = i && (i.target ? a[or(i.target)] : i.point), v = h && g && _ ? h.direction === "out" ? sr(g, _) : sr(_, g) : null, y = e.cables.flatMap((t) => {
		let n = a[or(t.from)], r = a[or(t.to)];
		return n && r && t.id !== i?.cableId ? [{
			cable: t,
			path: sr(n, r),
			kind: B(e, t.from).kind
		}] : [];
	});
	return /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("svg", {
		className: Q.cableHits,
		"aria-label": "Patch cables",
		children: y.map(({ cable: e, path: t }) => /* @__PURE__ */ p("path", {
			className: Q.cableHit,
			d: t,
			role: "button",
			tabIndex: 0,
			"aria-label": `Cable from ${d(e.from)} to ${d(e.to)}`,
			onClick: () => r(e.id),
			onPointerEnter: () => l(e.id),
			onPointerLeave: () => l((t) => t === e.id ? null : t),
			onKeyDown: (t) => {
				(t.key === "Enter" || t.key === " ") && (t.preventDefault(), r(e.id));
			}
		}, e.id))
	}), /* @__PURE__ */ m("svg", {
		className: Q.cables,
		"aria-hidden": "true",
		children: [y.map(({ cable: e, path: t, kind: r }) => /* @__PURE__ */ m("g", {
			className: Q.cable,
			"data-kind": r,
			"data-selected": n === e.id,
			"data-hovered": c === e.id,
			children: [/* @__PURE__ */ p("path", {
				className: Q.cableShadow,
				d: t
			}), /* @__PURE__ */ p("path", {
				className: Q.cableLine,
				d: t
			})]
		}, e.id)), v && /* @__PURE__ */ m("g", {
			className: Q.cable,
			"data-kind": h.kind,
			"data-held": "true",
			"data-snapped": !!i.target,
			"data-invalid": !!i.error,
			children: [
				/* @__PURE__ */ p("path", {
					className: Q.cableShadow,
					d: v
				}),
				/* @__PURE__ */ p("path", {
					className: Q.cableLine,
					d: v
				}),
				!i.target && /* @__PURE__ */ p("circle", {
					className: Q.loosePlug,
					cx: _.x,
					cy: _.y,
					r: 8
				})
			]
		})]
	})] });
}
//#endregion
//#region src/audio/studio-processor.js
var lr = [
	1e-4,
	3e-4,
	.001,
	.003,
	.01,
	.03
], ur = [
	.1,
	.3,
	.6,
	1.2
], dr = [
	1,
	2,
	3,
	4,
	6,
	10,
	20,
	100
], fr = [
	35,
	60,
	110,
	220
], pr = [
	360,
	700,
	1600,
	3200,
	4800,
	7200
], mr = [
	0,
	50,
	80,
	160,
	300
], hr = (e) => 10 ** (e / 20), gr = [
	1,
	0,
	0,
	0,
	0
];
function $(e, t, n, r, i) {
	if (!t) return gr.slice();
	let a = 2 * Math.PI * Math.min(t, i * .45) / i, o = Math.cos(a), s = Math.sin(a), c = 10 ** (n / 40), l = s / (2 * r), u = s * Math.sqrt(2 * c), d, f, p, m, h, g;
	if (e === "pole") {
		let e = Math.tan(a / 2);
		return [
			1 / (1 + e),
			-1 / (1 + e),
			0,
			(e - 1) / (e + 1),
			0
		];
	}
	return e === "highpass" ? [d, f, p, m, h, g] = [
		(1 + o) / 2,
		-(1 + o),
		(1 + o) / 2,
		1 + l,
		-2 * o,
		1 - l
	] : e === "bell" ? [d, f, p, m, h, g] = [
		1 + l * c,
		-2 * o,
		1 - l * c,
		1 + l / c,
		-2 * o,
		1 - l / c
	] : e === "low" ? [d, f, p, m, h, g] = [
		c * (c + 1 - (c - 1) * o + u),
		2 * c * (c - 1 - (c + 1) * o),
		c * (c + 1 - (c - 1) * o - u),
		c + 1 + (c - 1) * o + u,
		-2 * (c - 1 + (c + 1) * o),
		c + 1 + (c - 1) * o - u
	] : [d, f, p, m, h, g] = [
		c * (c + 1 + (c - 1) * o + u),
		-2 * c * (c - 1 + (c + 1) * o),
		c * (c + 1 + (c - 1) * o - u),
		c + 1 - (c - 1) * o + u,
		2 * (c - 1 - (c + 1) * o),
		c + 1 - (c - 1) * o - u
	], [
		d / m,
		f / m,
		p / m,
		h / m,
		g / m
	];
}
function _r(e, t) {
	let n = mr[e.hpf] ?? 0;
	return [
		$("pole", n, 0, 1, t),
		$("highpass", n, 0, 1, t),
		$("low", fr[e.lfFreq] ?? 110, e.lfGain, .7, t),
		$("bell", pr[e.midFreq] ?? 1600, e.midGain, .75, t),
		$("high", 12e3, e.hfGain, .7, t)
	];
}
function vr(e, t, n = 48e3) {
	if (e.active) return 0;
	let r = 2 * Math.PI * t / n, i = (e, t, n) => Math.hypot(e + t * Math.cos(r) + n * Math.cos(2 * r), t * Math.sin(r) + n * Math.sin(2 * r));
	return _r(e, n).reduce((e, [t, n, r, a, o]) => e + 20 * Math.log10(i(t, n, r) / i(1, a, o)), 0);
}
function yr(e, t) {
	let n, r, i;
	return e === "cohere" ? (n = [
		2,
		4,
		10
	][t.ratio] ?? 4, r = t.threshold + [
		-3,
		0,
		2
	][t.ratio], i = [
		9,
		6,
		3
	][t.ratio]) : (n = dr[t.ratio] ?? 6, r = [
		-18,
		-26,
		-24,
		-22,
		-20,
		-18,
		-16,
		-18
	][t.ratio], i = [
		0,
		15,
		12,
		9,
		6,
		4,
		2,
		3
	][t.ratio], t.fierce && (n = Math.max(12, n * 2), r -= 3, i = 2)), [
		1 - 1 / n,
		r,
		i
	];
}
function br(e, t, n, r) {
	if (!t) return 0;
	let i = e - n;
	return i <= -r / 2 ? 0 : i >= r / 2 ? -i * t : -t * (i + r / 2) ** 2 / (2 * r);
}
var xr = class {
	constructor(e) {
		this.c = gr.slice(), this.target = gr.slice(), this.z1 = 0, this.z2 = 0, this.smooth = 1 - Math.exp(-1 / (e * .008));
	}
	set(e, t) {
		this.target = e, t && (this.c = e.slice());
	}
	run(e) {
		let t = this.c;
		for (let e = 0; e < 5; e++) t[e] += (this.target[e] - t[e]) * this.smooth;
		let n = t[0] * e + this.z1;
		return this.z1 = t[1] * e - t[3] * n + this.z2, this.z2 = t[2] * e - t[4] * n, n;
	}
}, Sr = Float64Array.from({ length: 49 }, (e, t) => {
	let n = t - 24, r = .1125;
	return (n ? Math.sin(2 * Math.PI * r * n) / (Math.PI * n) : 2 * r) * (.42 - .5 * Math.cos(2 * Math.PI * t / 48) + .08 * Math.cos(4 * Math.PI * t / 48));
}), Cr = Sr.reduce((e, t) => e + t, 0);
for (let e = 0; e < Sr.length; e++) Sr[e] /= Cr;
var wr = class {
	constructor() {
		this.buffer = /* @__PURE__ */ new Float64Array(49), this.index = 0;
	}
	push(e) {
		this.buffer[this.index] = e, this.index = (this.index + 1) % 49;
	}
	run(e) {
		this.buffer[this.index] = e;
		let t = 0, n = this.index;
		for (let e = 0; e < 49; e++) t += Sr[e] * this.buffer[n], --n < 0 && (n = 48);
		return this.index = (this.index + 1) % 49, t;
	}
}, Tr = class {
	constructor() {
		this.buffer = /* @__PURE__ */ new Float64Array(13), this.index = 0;
	}
	push(e) {
		this.index = this.index ? this.index - 1 : 12, this.buffer[this.index] = e;
	}
	run(e) {
		let t = 0, n = this.index;
		for (let r = e; r < 49; r += 4) t += Sr[r] * this.buffer[n], ++n > 12 && (n = 0);
		return t;
	}
}, Er = class {
	constructor() {
		this.buffer = /* @__PURE__ */ new Float64Array(12), this.index = 0;
	}
	run(e) {
		let t = this.buffer[this.index];
		return this.buffer[this.index] = e, this.index = (this.index + 1) % this.buffer.length, t;
	}
}, Dr = class {
	constructor(e) {
		this.up = new Tr(), this.down = new wr(), this.clean = new Er(), this.previous = 0, this.blocked = 0, this.dc = Math.exp(-2 * Math.PI * 5 / e);
	}
	run(e, t, n) {
		let r = 0, i = Math.tanh(n), a = t * (1 - i * i);
		this.up.push(e * 4);
		for (let e = 0; e < 4; e++) {
			let o = this.up.run(e), s = (Math.tanh(t * o + n) - i) / a;
			e === 0 ? r = this.down.run(s - o) : this.down.push(s - o);
		}
		return this.blocked = r - this.previous + this.dc * this.blocked, this.previous = r, this.clean.run(e) + this.blocked;
	}
}, Or = class {
	constructor(e, t) {
		this.type = e, this.rate = t, this.params = null, this.events = [], this.disposed = !1, this.reduction = 0, this.gain = [0, 0], this.memory = [0, 0], this.input = 1, this.output = 1, this.wet = 1, this.drive = 0, this.smooth = 1 - Math.exp(-1 / (t * .008)), this.channels = Array.from({ length: 2 }, () => ({
			filters: Array.from({ length: 5 }, () => new xr(t)),
			hp: new xr(t),
			emphasis: new xr(t),
			audioPole: new xr(t),
			audioHp: new xr(t),
			color: new Dr(t),
			dry: new Er(),
			clean: new Er(),
			amount: .15,
			bias: 0
		}));
	}
	enqueue(e) {
		this.events.push(e), this.events.sort((e, t) => e.time - t.time);
	}
	configure(e) {
		let t = !this.params;
		this.params = { ...e }, this.inputTarget = hr(this.type === "talon" ? e.input : 0), this.outputTarget = hr(e.output), this.wetTarget = +!e.active, this.driveTarget = e.drive ?? 0, t && (this.input = this.inputTarget, this.output = this.outputTarget, this.wet = this.wetTarget, this.drive = this.driveTarget), this.type !== "brit" && (this.curveTarget = yr(this.type, e), this.linkTarget = this.type === "cohere" ? 1 : e.link, this.attackTarget = this.type === "cohere" ? lr[e.attack] : e.attack, this.releaseTarget = this.type === "cohere" ? ur[e.release] ?? .3 : e.release, t && (this.curve = this.curveTarget.slice(), this.link = this.linkTarget, this.attack = this.attackTarget, this.release = this.releaseTarget));
		for (let n of this.channels) {
			this.type === "brit" && _r(e, this.rate).forEach((e, r) => n.filters[r].set(e, t));
			let r = this.type === "cohere" ? [
				0,
				30,
				60,
				106,
				125,
				185
			][e.scHpf] : e.detectorHp ? 80 : 0;
			n.hp.set($("highpass", r, 0, Math.SQRT1_2, this.rate), t), n.emphasis.set($("bell", 6e3, e.detectorBand ? 10 : 0, 1, this.rate), t), n.audioPole.set($("pole", e.audioHp ? 49.01 : 0, 0, 1, this.rate), t), n.audioHp.set($("highpass", e.audioHp ? 44.915 : 0, 0, .691, this.rate), t), t && this.type === "talon" && (n.amount = [
				.15,
				.8,
				1.5
			][e.color], n.bias = e.color === 1 ? .3 : 0);
		}
	}
	envelope(e, t) {
		let n = this.params, r = br(e, this.curve[0], this.curve[1], this.curve[2]), i = this.gain[t];
		this.memory[t] += (Math.max(0, -i) - this.memory[t]) * (1 - Math.exp(-1 / (this.rate * .6)));
		let a = this.release;
		this.type === "cohere" && n.release === 4 && (a = .1 + Math.min(1.1, this.memory[t] * .09)), this.type === "talon" && (n.ratio === 5 ? a = Math.min(20, this.release * (1 + this.memory[t] * .9)) : n.ratio === 7 ? a *= .45 + Math.min(1.5, Math.max(0, -i) / 15) : a *= [
			1,
			1.15,
			1.05,
			1,
			.9,
			1,
			.8,
			1
		][n.ratio], n.ratio !== 5 && (a = Math.min(3.5, a)), n.fierce && (a *= .65));
		let o = r < i ? this.attack : a;
		return this.gain[t] += (r - i) * (1 - Math.exp(-1 / (o * this.rate))), hr(this.gain[t]);
	}
	render(e, t, n = 0) {
		if (this.disposed) {
			t.forEach((e) => e.fill(0));
			return;
		}
		let r = t[0].length;
		for (let i = 0; i < r; i++) {
			let r = (n + i) / this.rate;
			for (; this.events.length && this.events[0].time <= r;) this.configure(this.events.shift().params);
			if (!this.params) {
				t.forEach((e) => {
					e[i] = 0;
				});
				continue;
			}
			let a = this.params;
			this.input += (this.inputTarget - this.input) * this.smooth, this.output += (this.outputTarget - this.output) * this.smooth, this.wet += (this.wetTarget - this.wet) * this.smooth, this.drive += (this.driveTarget - this.drive) * this.smooth;
			let o = e[0]?.[i] ?? 0, s = e[1]?.[i] ?? o, c = o * this.input, l = s * this.input, u = 1, d = 1;
			if (this.type !== "brit") {
				for (let e = 0; e < 3; e++) this.curve[e] += (this.curveTarget[e] - this.curve[e]) * this.smooth;
				this.link += (this.linkTarget - this.link) * this.smooth, this.attack += (this.attackTarget - this.attack) * this.smooth, this.release += (this.releaseTarget - this.release) * this.smooth;
				let e = this.channels[0], t = this.channels[1], n = 20 * Math.log10(Math.max(1e-12, Math.abs(e.emphasis.run(e.hp.run(c))))), r = 20 * Math.log10(Math.max(1e-12, Math.abs(t.emphasis.run(t.hp.run(l))))), i = Math.max(n, r);
				this.envelope(n + this.link * (i - n), 0), this.envelope(r + this.link * (i - r), 1);
				let a = Math.min(this.gain[0], this.gain[1]), o = Math.max(this.memory[0], this.memory[1]), s = this.link * this.smooth;
				for (let e = 0; e < 2; e++) this.gain[e] += (a - this.gain[e]) * s, this.memory[e] += (o - this.memory[e]) * s;
				u = hr(this.gain[0]), d = hr(this.gain[1]), this.reduction = Math.min(this.gain[0], this.gain[1]) * this.wet;
			}
			for (let e = 0; e < t.length; e++) {
				let n = this.channels[e], r = e === 0 ? o : s, f = e === 0 ? c : l;
				if (this.type === "brit") {
					for (let e of n.filters) f = e.run(f);
					f = n.color.run(f, .22 * hr(this.drive), .12);
				} else if (this.type === "talon") {
					f = n.audioHp.run(n.audioPole.run(f * (e === 0 ? u : d)));
					let t = [
						.15,
						.8,
						1.5
					][a.color] * (1 + Math.min(2, -this.gain[e] / 20));
					n.amount += (t - n.amount) * this.smooth, n.bias += ((a.color === 1 ? .3 : 0) - n.bias) * this.smooth, f = n.color.run(f, n.amount, n.bias);
				} else f = n.clean.run(f * (e === 0 ? u : d));
				let p = n.dry.run(r);
				t[e][i] = p + this.wet * (f * this.output - p);
			}
		}
	}
};
if (typeof registerProcessor < "u") {
	class e extends AudioWorkletProcessor {
		constructor(e) {
			super(), this.dsp = new Or(e.processorOptions.type, sampleRate), this.meterFrames = 0, this.port.onmessage = ({ data: e }) => {
				e.type === "flush" ? this.port.postMessage({ id: e.id }) : e.type === "dispose" ? (this.dsp.disposed = !0, this.dsp.events = []) : this.dsp.enqueue(e);
			};
		}
		process(e, t) {
			return this.dsp.render(e[0] ?? [], t[0], currentFrame), this.meterFrames += t[0][0].length, this.meterFrames >= sampleRate / 25 && (this.meterFrames = 0, this.port.postMessage({ reduction: this.dsp.reduction })), !this.dsp.disposed;
		}
	}
	registerProcessor("rackloose-studio-v1", e);
}
//#endregion
//#region src/components/Glyphs.tsx
var kr = (e) => e.map((t, n) => `${n ? "L" : "M"}${(2 + n * 44 / (e.length - 1)).toFixed(1)} ${(17 - t * 14).toFixed(1)}`).join(" ");
function Ar(e, t) {
	let n = t, r = .5, i = Array.from({ length: 25 }, () => (n = n * 16807 % 2147483647, r += (n / 2147483647 - r) * e, r)), a = Math.min(...i), o = Math.max(...i);
	return kr(i.map((e) => .1 + (e - a) / (o - a) * .8));
}
var jr = {
	Sine: kr(Array.from({ length: 33 }, (e, t) => .5 + .5 * Math.sin(t / 32 * Math.PI * 4))),
	Triangle: kr([
		0,
		1,
		0,
		1,
		0
	]),
	Saw: "M2 17L24 3V17L46 3V17",
	Square: "M2 17V3H13V17H24V3H35V17H46V3",
	Pulse: "M2 17V3H8V17H24V3H30V17H46",
	"Saw + Pulse": "M2 17L13 13.5V6.5L24 3V17L35 13.5V6.5L46 3V17",
	"Low-pass": "M2 7H24C30 7 31 3 33 6C35 10 38 17 46 18",
	"High-pass": "M2 18C10 17 13 10 15 6C17 3 18 7 24 7H46",
	"Band-pass": "M2 18C14 17 18 4 24 4C30 4 34 17 46 18",
	White: Ar(1, 7),
	Pink: Ar(.45, 11),
	Brown: Ar(.16, 23),
	Bell: "M2 14C14 14 18 4 24 4C30 4 34 14 46 14",
	"Low shelf": "M2 6H14C20 6 22 14 30 14H46",
	"High shelf": "M2 14H18C26 14 28 6 34 6H46"
};
function Mr({ param: e, value: t }) {
	let n = e.choices?.[t] ?? "", r = jr[n === "Shelf" ? e.id === "hfBell" ? "High shelf" : "Low shelf" : n];
	return r ? /* @__PURE__ */ p("svg", {
		className: Q.choiceGlyph,
		viewBox: "0 0 48 20",
		"aria-hidden": "true",
		children: /* @__PURE__ */ p("path", { d: r })
	}) : null;
}
function Nr({ params: e, brit: t = !1, rate: n = 48e3 }) {
	let r = Rn(e, 24e3), i = (e) => 25 - Math.max(-18, Math.min(18, e)) * 22 / 18, a = Array.from({ length: 72 }, (a, o) => {
		let s = 20 * 1e3 ** (o / 71);
		return `${o ? "L" : "M"}${(3 + o * 114 / 71).toFixed(1)} ${i(t ? vr(e, s, n) : r.reduce((e, t) => e + zn(t, s, 48e3), 0)).toFixed(1)}`;
	}).join("");
	return /* @__PURE__ */ m("svg", {
		className: Q.eqGraphic,
		viewBox: "0 0 120 50",
		role: t ? "img" : void 0,
		"aria-label": t ? `BRIT filter response, 20 Hz to 20 kHz, at ${n / 1e3} kHz` : void 0,
		"aria-hidden": !t || void 0,
		"data-bypassed": e.active === 1,
		children: [
			[
				100,
				1e3,
				1e4
			].map((e) => /* @__PURE__ */ p("line", {
				x1: 3 + Math.log10(e / 20) / 3 * 114,
				x2: 3 + Math.log10(e / 20) / 3 * 114,
				y1: "3",
				y2: "47"
			}, e)),
			/* @__PURE__ */ p("line", {
				x1: "3",
				x2: "117",
				y1: "25",
				y2: "25"
			}),
			/* @__PURE__ */ p("path", { d: a })
		]
	});
}
function Pr({ reduction: e, label: t, max: n = 20 }) {
	let r = Math.min(n, Math.max(0, -e)), i = (e) => 45 - e / n * 90, a = (e, t) => {
		let n = (i(e) - 90) * Math.PI / 180;
		return [60 + Math.cos(n) * t, 60 + Math.sin(n) * t].map((e) => Number(e.toFixed(1)));
	};
	return /* @__PURE__ */ p("div", {
		className: Q.grMeter,
		role: "meter",
		"aria-label": t,
		"aria-valuemin": 0,
		"aria-valuemax": n,
		"aria-valuenow": r,
		"aria-valuetext": `${r} dB gain reduction`,
		children: /* @__PURE__ */ m("svg", {
			viewBox: "0 0 120 50",
			"aria-hidden": "true",
			children: [
				/* @__PURE__ */ p("path", { d: `M${a(0, 48).join(" ")}A48 48 0 0 0 ${a(n, 48).join(" ")}` }),
				[
					0,
					n / 4,
					n / 2,
					n * 3 / 4,
					n
				].map((e) => {
					let [t, n] = a(e, 48), [r, i] = a(e, 53), [o, s] = a(e, 40);
					return /* @__PURE__ */ m("g", { children: [/* @__PURE__ */ p("line", {
						x1: t,
						y1: n,
						x2: r,
						y2: i
					}), /* @__PURE__ */ p("text", {
						x: o,
						y: s,
						textAnchor: "middle",
						dominantBaseline: "middle",
						children: e
					})] }, e);
				}),
				/* @__PURE__ */ p("text", {
					className: Q.grUnit,
					x: "8",
					y: "45",
					children: "GR dB"
				}),
				/* @__PURE__ */ p("line", {
					className: Q.grNeedle,
					x1: "60",
					y1: "60",
					x2: "60",
					y2: "8",
					style: { transform: `rotate(${i(r)}deg)` }
				})
			]
		})
	});
}
var [Fr, Ir, , Lr] = z.envelope.params;
function Rr({ params: e }) {
	let t = (t) => 9 + jt(t, e[t.id]) * 24, n = 3 + t(Fr), r = n + t(Ir), i = 117 - t(Lr), a = 40 - e.sustain * 35, o = [
		["A", (3 + n) / 2],
		["D", (n + r) / 2],
		["S", (r + i) / 2],
		["R", (i + 117) / 2]
	];
	return /* @__PURE__ */ m("svg", {
		className: Q.envelopeGraphic,
		viewBox: "0 0 120 50",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ p("path", { d: `M3 40L${n.toFixed(1)} 5L${r.toFixed(1)} ${a.toFixed(1)}L${i.toFixed(1)} ${a.toFixed(1)}L117 40` }), o.map(([e, t]) => /* @__PURE__ */ p("text", {
			x: t.toFixed(1),
			y: "48",
			textAnchor: "middle",
			children: e
		}, e))]
	});
}
var zr = {
	play: /* @__PURE__ */ p("path", { d: "M3.5 2.2v9.6L11.6 7z" }),
	pause: /* @__PURE__ */ p("path", { d: "M3 2.2h2.9v9.6H3zM8.1 2.2H11v9.6H8.1z" }),
	stop: /* @__PURE__ */ p("path", { d: "M2.8 2.8h8.4v8.4H2.8z" }),
	reset: /* @__PURE__ */ p("path", { d: "M2.4 2.2h2v9.6h-2zM11.8 2.2v9.6L4.9 7z" }),
	undo: /* @__PURE__ */ p("path", {
		d: "M5.2 2.4 1.6 5.8l3.6 3.4V7.1h3.2a2.6 2.6 0 0 1 0 5.2H6.6v1.5h1.8a4.1 4.1 0 0 0 0-8.2H5.2z",
		transform: "translate(0 -1.2)"
	}),
	redo: /* @__PURE__ */ p("path", {
		d: "M8.8 2.4l3.6 3.4-3.6 3.4V7.1H5.6a2.6 2.6 0 0 0 0 5.2h1.8v1.5H5.6a4.1 4.1 0 0 1 0-8.2h3.2z",
		transform: "translate(0 -1.2)"
	})
};
function Br({ name: e }) {
	return /* @__PURE__ */ p("svg", {
		className: Q.icon,
		viewBox: "0 0 14 14",
		"aria-hidden": "true",
		focusable: "false",
		children: zr[e]
	});
}
//#endregion
//#region src/components/MixButtons.tsx
function Vr({ mixKey: e, label: t, mix: n, onToggle: r, solo: i = !0, onClear: a, clearable: o }) {
	return /* @__PURE__ */ m("span", {
		className: Q.mixButtons,
		children: [
			/* @__PURE__ */ p("button", {
				className: Q.muteToggle,
				"aria-label": `Mute ${t}`,
				"aria-pressed": n.muted.has(e),
				title: `Mute ${t}`,
				onClick: () => r(e, "muted"),
				children: "M"
			}),
			i && /* @__PURE__ */ p("button", {
				className: Q.soloToggle,
				"aria-label": `Solo ${t}`,
				"aria-pressed": n.soloed.has(e),
				title: `Solo ${t}`,
				onClick: () => r(e, "soloed"),
				children: "S"
			}),
			a && /* @__PURE__ */ p("button", {
				className: Q.clearToggle,
				"aria-label": `Clear ${t} mutes and solos`,
				title: `Clear ${t} mutes and solos`,
				disabled: !o,
				onClick: a,
				children: "CLR"
			})
		]
	});
}
//#endregion
//#region src/components/Drums.tsx
var Hr = [
	[1, "1/16"],
	[2, "1/32"],
	[3, "×3 · 1/32T"],
	[4, "×4 · 1/64"],
	[6, "×6 · 1/64T"]
], Ur = {
	2: "1/32",
	3: "1/32 triplet",
	4: "1/64",
	6: "1/64 triplet"
};
function Wr(e, t, n, r) {
	let i = e.params, a = 1 << n, o = We(i[`${t}Pattern`], n), s = Ge(e, t, n), c = (e) => Object.fromEntries(L.map((n) => [R(t, n), n === e ? i[R(t, n)] | a : i[R(t, n)] & ~a]));
	return r === 1 ? {
		[`${t}Pattern`]: i[`${t}Pattern`] ^ a,
		...o ? c(0) : {}
	} : {
		[`${t}Pattern`]: i[`${t}Pattern`] | a,
		...c(o && s === r ? 0 : r)
	};
}
function Gr({ module: e, mix: t, onMix: n, step: r, onParams: i, onAudition: a, disabled: o }) {
	let s = z[e.type], c = s.params.some((e) => e.id === R(s.drum.voices[0].id, 2)), [l, d] = u(1);
	return /* @__PURE__ */ m("div", {
		className: Q.drumPads,
		children: [c && /* @__PURE__ */ m("div", {
			className: Q.rollBrush,
			role: "group",
			"aria-label": `${s.name} pad mode`,
			children: [/* @__PURE__ */ p("span", { children: "NOTE" }), Hr.map(([e, t]) => /* @__PURE__ */ p("button", {
				"aria-pressed": l === e,
				onClick: () => d(e),
				children: t
			}, e))]
		}), s.drum.voices.map((u) => {
			let d = `${u.id}Pattern`, f = e.params[d];
			return /* @__PURE__ */ m("div", {
				className: Q.drumLane,
				"data-silent": !G(e, u.id, t),
				children: [
					/* @__PURE__ */ p("button", {
						className: Q.voiceButton,
						"aria-label": `Play ${s.name} ${u.label}`,
						disabled: o,
						onClick: () => a(u.id),
						children: u.label
					}),
					/* @__PURE__ */ p(Vr, {
						mixKey: nt(e.id, u.id),
						label: `${s.name} ${u.label}`,
						mix: t,
						onToggle: n
					}),
					/* @__PURE__ */ p("div", {
						className: Q.pads,
						children: [
							0,
							1,
							2,
							3
						].map((t) => /* @__PURE__ */ p("div", {
							className: Q.padGroup,
							"data-group": t,
							children: [
								0,
								1,
								2,
								3
							].map((n) => {
								let a = t * 4 + n, o = We(f, a), h = o && c ? Ge(e, u.id, a) : 1;
								return /* @__PURE__ */ m("button", {
									className: Q.pad,
									"data-current": r === a,
									"data-roll": h > 1 ? h : void 0,
									"aria-pressed": o,
									"aria-label": `${s.name} ${u.label} step ${a + 1}${h > 1 ? `, ${Ur[h]}` : ""}`,
									onClick: () => i(c ? Wr(e, u.id, a, l) : { [d]: f ^ 1 << a }),
									children: [/* @__PURE__ */ p("span", {}), h > 1 && /* @__PURE__ */ p("small", { children: h })]
								}, a);
							})
						}, t))
					})
				]
			}, u.id);
		})]
	});
}
var Kr = [
	"Steps",
	"Hits",
	"Shift"
];
function qr({ module: t, mix: n, onMix: r, onParams: i, onAudition: a, disabled: o, clock: s }) {
	let c = z[t.type], [l, d] = u(c.drum.voices[0].id), f = c.drum.voices.find((e) => e.id === l), h = U(t, l);
	return /* @__PURE__ */ m("div", {
		className: Q.orbitEditor,
		children: [/* @__PURE__ */ m("div", {
			className: Q.euclid,
			role: "group",
			"aria-label": `${c.name} rhythm`,
			children: [
				/* @__PURE__ */ p("span", { children: "VOICE / EDIT" }),
				/* @__PURE__ */ p("span", {}),
				Kr.map((e) => /* @__PURE__ */ p("span", {
					className: Q.euclidHeading,
					children: e
				}, e)),
				c.drum.voices.map((s) => /* @__PURE__ */ m(e, { children: [
					/* @__PURE__ */ p("button", {
						className: Q.voiceButton,
						"aria-label": `Play ${c.name} ${s.label}`,
						"aria-pressed": l === s.id,
						disabled: o,
						"data-silent": !G(t, s.id, n),
						onClick: () => {
							d(s.id), a(s.id);
						},
						children: s.label
					}),
					/* @__PURE__ */ p(Vr, {
						mixKey: nt(t.id, s.id),
						label: `${c.name} ${s.label}`,
						mix: n,
						onToggle: r
					}),
					Kr.map((e) => {
						let n = c.params.find((t) => t.id === `${s.id}${e}`);
						return /* @__PURE__ */ m("div", {
							className: Q.euclidCell,
							children: [/* @__PURE__ */ p(ar, {
								trim: !0,
								param: n,
								prefix: c.name,
								disabled: e !== "Steps" && !!t.params[`${s.id}Custom`],
								value: t.params[n.id],
								onChange: (e) => i({ [n.id]: e })
							}), /* @__PURE__ */ p("output", { children: t.params[n.id] })]
						}, e);
					})
				] }, s.id))
			]
		}), /* @__PURE__ */ m("div", {
			className: Q.orbitVoiceEditor,
			role: "group",
			"aria-label": `Edit ORBIT ${f.label}`,
			children: [
				/* @__PURE__ */ m("div", {
					className: Q.orbitEditorHeading,
					children: [
						/* @__PURE__ */ m("label", { children: ["EDIT VOICE ", /* @__PURE__ */ p("select", {
							"aria-label": "Orbit edit voice",
							value: l,
							onChange: (e) => d(e.target.value),
							children: c.drum.voices.map((e) => /* @__PURE__ */ p("option", {
								value: e.id,
								children: e.label
							}, e.id))
						})] }),
						/* @__PURE__ */ p("span", { children: t.params[`${l}Custom`] ? "CUSTOM" : "EUCLIDEAN" }),
						/* @__PURE__ */ p("button", {
							onClick: () => i({ [`${l}Custom`]: 0 }),
							"aria-label": `Generate ORBIT ${f.label} rhythm`,
							children: "Generate"
						})
					]
				}),
				/* @__PURE__ */ p("div", {
					className: Q.controls,
					children: [
						"Tune",
						"Decay",
						"Tone",
						"Level"
					].map((e) => {
						let n = c.params.find((t) => t.id === `${l}${e}`);
						return /* @__PURE__ */ p(ar, {
							param: {
								...n,
								label: e
							},
							prefix: `ORBIT ${f.label}`,
							value: t.params[n.id],
							onChange: (e) => i({ [n.id]: e })
						}, n.id);
					})
				}),
				/* @__PURE__ */ p("div", {
					className: Q.orbitSteps,
					children: h.map((e, n) => /* @__PURE__ */ m("button", {
						className: Q.pad,
						"aria-pressed": e,
						"data-current": s >= 0 && s % h.length === n,
						"aria-label": `ORBIT ${f.label} step ${n + 1}`,
						onClick: () => {
							let e = Je(t, l, n);
							i({
								[`${l}Pattern`]: e[`${l}Pattern`],
								[`${l}Custom`]: 1
							});
						},
						children: [/* @__PURE__ */ p("span", {}), n + 1]
					}, n))
				}),
				/* @__PURE__ */ p("small", { children: "Tap a step to customize. Generate restores the Euclidean rhythm." })
			]
		})]
	});
}
var Jr = [
	70,
	59,
	48,
	37,
	26,
	15
];
function Yr({ module: e, clock: t }) {
	return /* @__PURE__ */ p("svg", {
		className: Q.orbitRings,
		viewBox: "0 0 160 160",
		"aria-hidden": "true",
		children: z[e.type].drum.voices.map(({ id: n }, r) => {
			let i = U(e, n), a = Jr[r], o = t < 0 ? -1 : t % i.length;
			return /* @__PURE__ */ m("g", {
				"data-voice": n,
				children: [/* @__PURE__ */ p("circle", {
					className: Q.orbitPath,
					cx: "80",
					cy: "80",
					r: a
				}), i.map((e, t) => {
					let n = t / i.length * 2 * Math.PI - Math.PI / 2;
					return /* @__PURE__ */ p("circle", {
						cx: (80 + a * Math.cos(n)).toFixed(2),
						cy: (80 + a * Math.sin(n)).toFixed(2),
						r: t === o ? 3.8 : e ? 3 : 1.4,
						"data-hit": e,
						"data-current": t === o
					}, t);
				})]
			}, n);
		})
	});
}
//#endregion
//#region src/components/SoundEditors.tsx
var Xr = {
	strike: "ORIGINAL DIGITAL KIT · 16 VOICES",
	forge: "INDUSTRIAL KIT · 11 VOICES"
};
function Zr({ module: e, onParams: t, onAudition: n, disabled: r }) {
	let i = z[e.type], [a, o] = u(i.drum.voices[0].id), s = i.drum.voices.find((e) => e.id === a);
	return /* @__PURE__ */ m("div", {
		className: Q.soundEditor,
		role: "group",
		"aria-label": `${i.name} voice editor`,
		children: [/* @__PURE__ */ m("div", {
			className: Q.editorHeading,
			children: [
				/* @__PURE__ */ m("label", { children: ["EDIT VOICE ", /* @__PURE__ */ p("select", {
					"aria-label": `${i.name} edit voice`,
					value: a,
					onChange: (e) => o(e.target.value),
					children: i.drum.voices.map((e) => /* @__PURE__ */ p("option", {
						value: e.id,
						children: e.label
					}, e.id))
				})] }),
				/* @__PURE__ */ m("button", {
					disabled: r,
					onClick: () => n(a),
					children: ["Audition ", s.label]
				}),
				/* @__PURE__ */ p("small", { children: Xr[e.type] })
			]
		}), /* @__PURE__ */ p("div", {
			className: Q.controls,
			children: i.params.filter((e) => e.voice === a && !e.pattern).map((n) => /* @__PURE__ */ p(ar, {
				param: {
					...n,
					label: n.label.slice(s.label.length + 1)
				},
				prefix: `${i.name} ${s.label}`,
				value: e.params[n.id],
				onChange: (e) => t({ [n.id]: e })
			}, n.id))
		})]
	});
}
var Qr = [
	"2→1 + 4→3 + 6→5",
	"3→2→1 + 6→5→4",
	"6→5→4→3→2→1",
	"5+6→4→1+2+3",
	"4→2→1 + 6→5→3→1",
	"1 + 2 + 3 + 4 + 5 + 6"
];
function $r({ module: e, onParams: t }) {
	let [n, r] = u(1);
	return /* @__PURE__ */ m("div", {
		className: Q.soundEditor,
		role: "group",
		"aria-label": "PRISM operator editor",
		children: [
			/* @__PURE__ */ m("div", {
				className: Q.fmDisplay,
				children: [
					/* @__PURE__ */ p("span", { children: ye[e.params.algorithm] }),
					/* @__PURE__ */ p("strong", { children: Qr[e.params.algorithm] }),
					/* @__PURE__ */ p("small", { children: "16 VOICES · SIX OPERATORS · PHASE MODULATION" })
				]
			}),
			/* @__PURE__ */ p("div", {
				className: Q.operatorTabs,
				role: "group",
				"aria-label": "Select PRISM operator",
				children: [
					1,
					2,
					3,
					4,
					5,
					6
				].map((e) => /* @__PURE__ */ m("button", {
					"aria-pressed": n === e,
					"aria-label": `Edit PRISM operator ${e}`,
					onClick: () => r(e),
					children: ["OP ", e]
				}, e))
			}),
			/* @__PURE__ */ p("div", {
				className: Q.controls,
				children: z.prism.params.filter((e) => e.voice === `op${n}`).map((r) => /* @__PURE__ */ p(ar, {
					param: r,
					prefix: `PRISM Operator ${n}`,
					value: e.params[r.id],
					onChange: (e) => t({ [r.id]: e })
				}, r.id))
			})
		]
	});
}
//#endregion
//#region src/components/PanelLegend.tsx
function ei({ size: e, height: t, inner: n, marks: r }) {
	let i = (n, r) => [e / 2 + n * Math.sin(r * Math.PI / 180), t / 2 - n * Math.cos(r * Math.PI / 180)], a = (e, t) => n + 10 + (e.length - 1) * 2.2 * Math.abs(Math.sin(t * Math.PI / 180));
	return /* @__PURE__ */ p("svg", {
		className: Q.panelLegend,
		width: e,
		height: t,
		viewBox: `0 0 ${e} ${t}`,
		"aria-hidden": "true",
		children: r.map(({ angle: e, text: t, lit: r }, o) => {
			let [s, c] = i(n, e), [l, u] = i(n + (t ? 4 : 2.5), e), [d, f] = i(a(t ?? "", e), e);
			return /* @__PURE__ */ m("g", {
				"data-lit": r || void 0,
				children: [/* @__PURE__ */ p("line", {
					x1: s,
					y1: c,
					x2: l,
					y2: u
				}), t && /* @__PURE__ */ p("text", {
					x: d,
					y: f,
					textAnchor: "middle",
					dominantBaseline: "central",
					children: t
				})]
			}, o);
		})
	});
}
//#endregion
//#region src/components/Brit.tsx
var ti = (e) => z.brit.params.find((t) => t.id === e), ni = (e, t) => {
	let n = Math.min(270, (t - 1) * 45);
	return -n / 2 + e * n / (t - 1);
}, ri = (e, t) => e.choices ? ni(t, e.choices.length) : -135 + jt(e, t) * 270, ii = 104, ai = (e) => ({
	"--size": `${e}px`,
	"--height": `${ii}px`
});
function oi({ angle: e, skirt: t }) {
	return /* @__PURE__ */ m(f, { children: [
		t && /* @__PURE__ */ p("span", { className: Q.marconiSkirt }),
		/* @__PURE__ */ p("span", { className: Q.marconiFlutes }),
		/* @__PURE__ */ p("span", { className: Q.marconiDome }),
		/* @__PURE__ */ p("span", {
			className: Q.marconiPointer,
			style: { transform: `rotate(${e}deg)` }
		})
	] });
}
var si = (e, t) => [...Array.from({ length: 11 }, (e, t) => ({ angle: -135 + t * 27 })), ...t.map(([t, n]) => ({
	angle: ri(e, t),
	text: n
}))], ci = (e, t) => e.map((n, r) => ({
	angle: ni(r, e.length),
	text: n,
	lit: r === t
}));
function li({ module: e, prefix: t, onParams: n, id: r, color: i, size: a, knob: o, skirt: s, title: c, labels: l, marks: u }) {
	let d = ti(r), f = e.params[r], { props: h, display: g } = ir({
		param: d,
		value: f,
		prefix: t,
		onChange: (e) => n({ [r]: e })
	});
	return /* @__PURE__ */ m("div", {
		className: Q.britSection,
		children: [
			/* @__PURE__ */ p("strong", { children: c }),
			/* @__PURE__ */ m("div", {
				className: Q.britWell,
				style: ai(a),
				children: [/* @__PURE__ */ p(ei, {
					size: a,
					height: ii,
					inner: o / 2 + 3,
					marks: l ? ci(l, f) : si(d, u ?? [])
				}), /* @__PURE__ */ p("div", {
					className: Q.marconi,
					"data-color": i,
					"data-skirt": s || void 0,
					style: { "--knob": `${o}px` },
					...h,
					children: /* @__PURE__ */ p(oi, {
						angle: ri(d, f),
						skirt: s
					})
				})]
			}),
			!l && /* @__PURE__ */ p("span", {
				className: Q.knobValue,
				children: g
			})
		]
	});
}
function ui({ module: e, prefix: t, onParams: n, frequency: r, gain: i, color: a, title: o, labels: s }) {
	let c = ti(r), l = ti(i), u = ir({
		param: c,
		value: e.params[r],
		prefix: t,
		onChange: (e) => n({ [r]: e })
	}), d = ir({
		param: l,
		value: e.params[i],
		prefix: t,
		onChange: (e) => n({ [i]: e })
	});
	return /* @__PURE__ */ m("div", {
		className: Q.britSection,
		children: [
			/* @__PURE__ */ p("strong", { children: o }),
			/* @__PURE__ */ m("div", {
				className: Q.britWell,
				style: ai(112),
				children: [
					/* @__PURE__ */ p(ei, {
						size: 112,
						height: ii,
						inner: 36,
						marks: ci(s, e.params[r])
					}),
					/* @__PURE__ */ p("div", {
						className: Q.marconiRing,
						style: { "--ring": "66px" },
						...u.props,
						children: /* @__PURE__ */ p("span", {
							className: Q.ringPointer,
							style: { transform: `rotate(${ri(c, e.params[r])}deg)` }
						})
					}),
					/* @__PURE__ */ p("div", {
						className: Q.marconi,
						"data-color": a,
						style: { "--knob": "38px" },
						...d.props,
						children: /* @__PURE__ */ p(oi, { angle: ri(l, e.params[i]) })
					})
				]
			}),
			/* @__PURE__ */ p("span", {
				className: Q.knobValue,
				children: d.display
			})
		]
	});
}
function di({ module: e, onParams: t, rate: n }) {
	let r = z.brit.name, i = e.params.active === 0, a = (n) => ({
		module: e,
		onParams: t,
		prefix: `${r} ${n}`
	});
	return /* @__PURE__ */ m("div", {
		className: Q.britPanel,
		"data-bypassed": !i,
		children: [
			/* @__PURE__ */ p(li, {
				...a("Signal"),
				id: "hpf",
				color: "blue",
				size: 96,
				knob: 46,
				title: "High pass",
				labels: [
					"OFF",
					"50",
					"80",
					"160",
					"300"
				]
			}),
			/* @__PURE__ */ p(ui, {
				...a("Low shelf"),
				frequency: "lfFreq",
				gain: "lfGain",
				color: "grey",
				title: "Low · Hz",
				labels: [
					"35",
					"60",
					"110",
					"220"
				]
			}),
			/* @__PURE__ */ p(ui, {
				...a("Mid bell"),
				frequency: "midFreq",
				gain: "midGain",
				color: "blue",
				title: "Mid · kHz",
				labels: [
					".36",
					".7",
					"1.6",
					"3.2",
					"4.8",
					"7.2"
				]
			}),
			/* @__PURE__ */ p(li, {
				...a("High shelf · 12 kHz"),
				id: "hfGain",
				color: "grey",
				size: 88,
				knob: 44,
				title: "High · 12k",
				marks: [
					[-16, "−16"],
					[0, "0"],
					[16, "+16"]
				]
			}),
			/* @__PURE__ */ p(li, {
				...a("Signal"),
				id: "drive",
				color: "red",
				size: 100,
				knob: 64,
				skirt: !0,
				title: "Drive",
				marks: [
					[0, "0"],
					[12, "12"],
					[24, "24"]
				]
			}),
			/* @__PURE__ */ p(li, {
				...a("Signal"),
				id: "output",
				color: "grey",
				size: 80,
				knob: 36,
				title: "Output",
				marks: [
					[-18, "−18"],
					[0, "0"],
					[18, "+18"]
				]
			}),
			/* @__PURE__ */ m("div", {
				className: Q.britSection,
				children: [/* @__PURE__ */ p("strong", { children: "EQ" }), /* @__PURE__ */ m("button", {
					className: Q.britSwitch,
					"aria-pressed": i,
					"aria-label": `${r} EQ in`,
					title: i ? "EQ in. Press to bypass." : "Bypassed. Press to switch the EQ in.",
					onClick: () => t({ active: +!!i }),
					children: [/* @__PURE__ */ p("span", { className: Q.britLamp }), "IN"]
				})]
			}),
			/* @__PURE__ */ m("div", {
				className: `${Q.britSection} ${Q.britCurve}`,
				children: [/* @__PURE__ */ p("strong", { children: "Response" }), /* @__PURE__ */ p(Nr, {
					params: e.params,
					brit: !0,
					rate: n
				})]
			})
		]
	});
}
//#endregion
//#region src/components/Talon.tsx
var fi = z.talon.name, pi = (e) => z.talon.params.find((t) => t.id === e), mi = (e) => `${fi} ${e.group} ${e.label}`, hi = (e, t) => -135 + jt(e, t) * 270, gi = 108, _i = [
	1,
	2,
	3,
	4,
	6,
	8,
	10,
	14,
	20,
	30
];
function vi({ module: e, onParams: t, id: n, size: r, knob: i, title: a, marks: o }) {
	let s = pi(n), c = e.params[n], { props: l, display: u } = ir({
		param: s,
		value: c,
		prefix: `${fi} ${s.group}`,
		onChange: (e) => t({ [n]: e })
	}), d = [...Array.from({ length: 11 }, (e, t) => ({ angle: -135 + t * 27 })), ...o.map(([e, t]) => ({
		angle: hi(s, e),
		text: t
	}))];
	return /* @__PURE__ */ m("div", {
		className: Q.talonSection,
		children: [
			/* @__PURE__ */ p("strong", { children: a }),
			/* @__PURE__ */ m("div", {
				className: Q.talonWell,
				style: {
					"--size": `${r}px`,
					"--height": `${gi}px`
				},
				children: [/* @__PURE__ */ p(ei, {
					size: r,
					height: gi,
					inner: i / 2 + 4,
					marks: d
				}), /* @__PURE__ */ m("div", {
					className: Q.talonKnob,
					style: { "--knob": `${i}px` },
					...l,
					children: [
						/* @__PURE__ */ p("span", { className: Q.talonGrip }),
						/* @__PURE__ */ p("span", { className: Q.talonCap }),
						/* @__PURE__ */ p("span", {
							className: Q.talonIndex,
							style: { transform: `rotate(${hi(s, c)}deg)` }
						})
					]
				})]
			}),
			/* @__PURE__ */ p("span", {
				className: Q.knobValue,
				children: u
			})
		]
	});
}
function yi({ module: e, onParams: t, id: n, title: r, button: i, captions: a = [] }) {
	let o = pi(n), s = e.params[n], c = o.choices.length;
	function l(e) {
		let r = {
			ArrowDown: s + 1,
			ArrowRight: s + 1,
			ArrowUp: s - 1,
			ArrowLeft: s - 1,
			Home: 0,
			End: c - 1
		}[e.key];
		if (r === void 0) return;
		e.preventDefault();
		let i = Math.max(0, Math.min(c - 1, r));
		t({ [n]: i }), e.currentTarget.querySelectorAll("[role=\"radio\"]")[i].focus();
	}
	return /* @__PURE__ */ m("div", {
		className: Q.talonSection,
		children: [
			/* @__PURE__ */ p("strong", { children: r }),
			/* @__PURE__ */ p("div", {
				className: Q.talonLamps,
				role: "radiogroup",
				"aria-label": mi(o),
				onKeyDown: l,
				children: o.choices.map((e, r) => /* @__PURE__ */ m("button", {
					type: "button",
					role: "radio",
					"aria-checked": r === s,
					tabIndex: r === s ? 0 : -1,
					onClick: () => t({ [n]: r }),
					children: [
						/* @__PURE__ */ p("span", { className: Q.talonLed }),
						e,
						a[r] && /* @__PURE__ */ p("small", {
							"aria-hidden": "true",
							children: a[r]
						})
					]
				}, e))
			}),
			/* @__PURE__ */ p("button", {
				type: "button",
				className: Q.talonPush,
				"aria-label": `${mi(o)}: next`,
				title: `Step to the next ${o.label.toLowerCase()} mode`,
				onClick: () => t({ [n]: (s + 1) % c }),
				children: i
			})
		]
	});
}
function bi({ module: e, onParams: t, id: n, text: r }) {
	let i = pi(n), a = e.params[n] === 1;
	return /* @__PURE__ */ m("button", {
		type: "button",
		className: Q.talonPush,
		"aria-pressed": a,
		"aria-label": mi(i),
		title: `${i.label}: ${i.choices[e.params[n]]}`,
		onClick: () => t({ [n]: +!a }),
		children: [/* @__PURE__ */ p("span", { className: Q.talonLed }), r]
	});
}
function xi({ reduction: e, label: t }) {
	let n = Math.min(40, Math.max(0, -e));
	return /* @__PURE__ */ m("div", {
		className: Q.talonSection,
		children: [/* @__PURE__ */ p("strong", { children: "GR" }), /* @__PURE__ */ p("div", {
			className: Q.talonMeter,
			role: "meter",
			"aria-label": t,
			"aria-valuemin": 0,
			"aria-valuemax": 40,
			"aria-valuenow": n,
			"aria-valuetext": `${n} dB gain reduction`,
			children: _i.map((e) => /* @__PURE__ */ m("span", {
				"data-lit": n >= e,
				"data-hot": e > 10 || void 0,
				children: [/* @__PURE__ */ p("i", {}), e]
			}, e))
		})]
	});
}
function Si({ module: e, onParams: t, reduction: n, label: r }) {
	let i = {
		module: e,
		onParams: t
	}, a = e.params.active === 0;
	return /* @__PURE__ */ m("div", {
		className: Q.talonPanel,
		"data-bypassed": !a,
		children: [
			/* @__PURE__ */ p(vi, {
				...i,
				id: "input",
				size: 100,
				knob: 60,
				title: "Input",
				marks: [
					[-12, "−12"],
					[0, "0"],
					[12, "12"],
					[30, "30"]
				]
			}),
			/* @__PURE__ */ p(vi, {
				...i,
				id: "attack",
				size: 84,
				knob: 46,
				title: "Attack · ms",
				marks: [
					[5e-5, ".05"],
					[.001, "1"],
					[.01, "10"],
					[.03, "30"]
				]
			}),
			/* @__PURE__ */ p(vi, {
				...i,
				id: "release",
				size: 84,
				knob: 46,
				title: "Release · s",
				marks: [
					[.05, ".05"],
					[.3, ".3"],
					[1, "1"],
					[3.5, "3.5"]
				]
			}),
			/* @__PURE__ */ p(yi, {
				...i,
				id: "ratio",
				title: "Ratio",
				button: "Ratio"
			}),
			/* @__PURE__ */ m("div", {
				className: Q.talonSection,
				children: [/* @__PURE__ */ p(yi, {
					...i,
					id: "color",
					title: "Harmonics",
					button: "Dist",
					captions: [
						"",
						"2nd",
						"3rd"
					]
				}), /* @__PURE__ */ m("div", {
					className: Q.talonLatches,
					children: [/* @__PURE__ */ p(bi, {
						...i,
						id: "audioHp",
						text: "HP 65"
					}), /* @__PURE__ */ p(bi, {
						...i,
						id: "fierce",
						text: "Fierce"
					})]
				})]
			}),
			/* @__PURE__ */ m("div", {
				className: Q.talonSection,
				children: [/* @__PURE__ */ p("strong", { children: "Detector" }), /* @__PURE__ */ m("div", {
					className: Q.talonLatches,
					children: [
						/* @__PURE__ */ p(bi, {
							...i,
							id: "detectorHp",
							text: "HP 80"
						}),
						/* @__PURE__ */ p(bi, {
							...i,
							id: "detectorBand",
							text: "Band 6k"
						}),
						/* @__PURE__ */ p(bi, {
							...i,
							id: "link",
							text: "Link"
						})
					]
				})]
			}),
			/* @__PURE__ */ m("div", {
				className: Q.talonOutput,
				children: [
					/* @__PURE__ */ p(xi, {
						reduction: n,
						label: r
					}),
					/* @__PURE__ */ p(vi, {
						...i,
						id: "output",
						size: 100,
						knob: 60,
						title: "Output",
						marks: [
							[-30, "−30"],
							[-12, "−12"],
							[0, "0"],
							[12, "+12"]
						]
					}),
					/* @__PURE__ */ m("div", {
						className: Q.talonSection,
						children: [/* @__PURE__ */ p("strong", { children: "Comp" }), /* @__PURE__ */ m("button", {
							type: "button",
							className: Q.talonSwitch,
							"aria-pressed": a,
							"aria-label": `${fi} in`,
							title: a ? "In. Press to bypass." : "Bypassed. Press to switch TALON in.",
							onClick: () => t({ active: +!!a }),
							children: [/* @__PURE__ */ p("span", { className: Q.talonLamp }), "IN"]
						})]
					})
				]
			}),
			e.params.ratio === 5 && /* @__PURE__ */ p("p", {
				className: Q.processorHint,
				children: "Opto recovery lengthens with sustained reduction, up to 20 s."
			})
		]
	});
}
//#endregion
//#region src/components/Mixer.tsx
var Ci = 112, wi = [
	[1, "0"],
	[10 ** (-3 / 20), "3"],
	[.5, "6"],
	[10 ** (-10 / 20), "10"],
	[.1, "20"],
	[0, "∞"]
], Ti = [
	-48,
	-42,
	-36,
	-30,
	-24,
	-18,
	-12,
	-9,
	-6,
	-3,
	0
], Ei = (e) => z.mixer.params.find((t) => t.id === e), Di = (e) => e <= 0 ? "−∞" : `${(20 * Math.log10(e)).toFixed(1).replace("-", "−")} dB`, Oi = (e) => Math.abs(e) < .005 ? "C" : `${e < 0 ? "L" : "R"}${Math.round(Math.abs(e) * 100)}`;
function ki({ level: e, label: t }) {
	let n = Math.round(e);
	return /* @__PURE__ */ p("div", {
		className: Q.levelMeter,
		role: "meter",
		"aria-label": t,
		"aria-valuemin": Ti[0],
		"aria-valuemax": 0,
		"aria-valuenow": Math.max(Ti[0], Math.min(0, n)),
		"aria-valuetext": e < Ti[0] ? "Silent" : `${n} dB`,
		children: Ti.map((t) => /* @__PURE__ */ p("i", {
			"data-lit": e >= t,
			"data-zone": t >= -3 ? "hot" : t >= -9 ? "warm" : void 0
		}, t))
	});
}
function Ai({ param: e, value: t, prefix: n, onChange: r, children: i }) {
	let { props: a, fraction: o, display: s } = ir({
		param: e,
		value: t,
		prefix: n,
		onChange: r,
		format: Di,
		travel: Ci
	});
	return /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ m("div", {
		className: Q.faderBay,
		style: { "--travel": `${Ci}px` },
		children: [
			/* @__PURE__ */ p("span", {
				className: Q.faderScale,
				"aria-hidden": "true",
				children: wi.map(([e, t]) => /* @__PURE__ */ p("span", {
					style: { "--at": e },
					children: t
				}, t))
			}),
			/* @__PURE__ */ p("div", {
				className: Q.faderSlot,
				...a,
				children: /* @__PURE__ */ p("span", {
					className: Q.faderCap,
					style: { "--at": o }
				})
			}),
			i
		]
	}), /* @__PURE__ */ p("span", {
		className: Q.faderValue,
		children: s
	})] });
}
function ji({ module: e, patch: t, mix: n, levels: r, onParams: i, onToggle: a }) {
	let o = z[e.type].name;
	return /* @__PURE__ */ m("div", {
		className: Q.console,
		children: [be.map((s, c) => {
			let { source: l, tooltip: u, connected: d } = dt(t, e.id, s), f = s.toUpperCase(), h = xe(s);
			return /* @__PURE__ */ m("div", {
				className: Q.channelStrip,
				role: "group",
				"aria-label": `${o} channel ${f}: ${l}`,
				"data-plugged": d,
				"data-silent": !G(e, s, n),
				children: [
					/* @__PURE__ */ m("div", {
						className: Q.scribble,
						title: u || void 0,
						children: [/* @__PURE__ */ p("span", {
							className: Q.channelSource,
							"data-source-name": !0,
							children: l
						}), /* @__PURE__ */ p("b", { children: f })]
					}),
					/* @__PURE__ */ p(ar, {
						param: Ei(h),
						prefix: o,
						value: e.params[h],
						format: Oi,
						caption: "PAN",
						onChange: (e) => i({ [h]: e })
					}),
					/* @__PURE__ */ p(Vr, {
						mixKey: nt(e.id, s),
						label: `${o} channel ${f}`,
						mix: n,
						onToggle: a
					}),
					/* @__PURE__ */ p(Ai, {
						param: Ei(s),
						prefix: o,
						value: e.params[s],
						onChange: (e) => i({ [s]: e }),
						children: /* @__PURE__ */ p(ki, {
							level: r.channels[c],
							label: `${o} channel ${f} level`
						})
					})
				]
			}, s);
		}), /* @__PURE__ */ m("div", {
			className: Q.mixBus,
			role: "group",
			"aria-label": `${o} mix bus`,
			children: [/* @__PURE__ */ m("div", {
				className: Q.scribble,
				children: [/* @__PURE__ */ p("span", {
					className: Q.channelSource,
					children: "MIX BUS"
				}), /* @__PURE__ */ p("b", { children: "L · R" })]
			}), /* @__PURE__ */ m(Ai, {
				param: Ei("master"),
				prefix: o,
				value: e.params.master,
				onChange: (e) => i({ master: e }),
				children: [/* @__PURE__ */ p(ki, {
					level: r.bus[0],
					label: `${o} mix bus left level`
				}), /* @__PURE__ */ p(ki, {
					level: r.bus[1],
					label: `${o} mix bus right level`
				})]
			})]
		})]
	});
}
//#endregion
//#region src/components/TempoInput.tsx
var Mi = 40, Ni = 240;
function Pi({ bpm: e, onChange: t }) {
	let [n, r] = u(String(e)), o = a();
	return i(() => {
		r(String(e));
	}, [e]), /* @__PURE__ */ m("div", {
		className: Q.numberField,
		children: [
			/* @__PURE__ */ p("label", {
				htmlFor: o,
				children: "BPM"
			}),
			/* @__PURE__ */ p("input", {
				id: o,
				"aria-label": "Tempo",
				type: "number",
				min: Mi,
				max: Ni,
				step: 1,
				value: n,
				onChange: (e) => {
					r(e.target.value);
					let n = Number(e.target.value);
					n >= Mi && n <= Ni && t(n);
				},
				onBlur: () => {
					let i = n === "" ? e : Math.max(Mi, Math.min(Ni, Number(n)));
					r(String(i)), t(i);
				}
			}),
			/* @__PURE__ */ p("input", {
				className: Q.tempoSlider,
				type: "range",
				min: Mi,
				max: Ni,
				step: 1,
				value: e,
				"aria-label": "Tempo slider",
				"aria-valuetext": `${e} BPM`,
				onChange: (e) => t(Number(e.target.value))
			})
		]
	});
}
//#endregion
//#region src/components/Presets.tsx
var Fi = (e) => new Date(e).toLocaleString(void 0, {
	dateStyle: "medium",
	timeStyle: "short"
});
function Ii({ presets: e, openId: t, dirty: n, onLoad: r, onLoadFactory: a, onExport: o, onDelete: s, onSaveAs: c, onImport: d, onExportCurrent: h, onClose: g }) {
	let [_, v] = u(null), y = l(null), b = l(null);
	return i(() => {
		_ && y.current?.focus();
	}, [_]), /* @__PURE__ */ m("div", {
		ref: b,
		tabIndex: -1,
		className: `${Q.library} ${Q.presetBrowser}`,
		role: "region",
		"aria-label": "Presets",
		children: [
			/* @__PURE__ */ m("div", {
				className: Q.libraryHeading,
				children: [/* @__PURE__ */ p("strong", { children: "PRESETS" }), /* @__PURE__ */ m("span", {
					className: Q.presetActions,
					children: [
						/* @__PURE__ */ p("button", {
							onClick: (e) => c(e.currentTarget),
							title: "Save a copy under a new name (⇧⌘S / Ctrl+Shift+S)",
							children: "Save as…"
						}),
						/* @__PURE__ */ p("button", {
							onClick: d,
							title: "Add a .json patch file to My Presets",
							children: "↑ Import file…"
						}),
						/* @__PURE__ */ p("button", {
							onClick: h,
							title: "Download the rack as a .json patch file",
							children: "↓ Export file"
						}),
						/* @__PURE__ */ p("button", {
							"aria-label": "Close presets",
							onClick: g,
							children: "×"
						})
					]
				})]
			}),
			/* @__PURE__ */ p("strong", {
				className: Q.sectionLabel,
				children: "MY PRESETS · SAVED IN THIS BROWSER"
			}),
			e.length ? /* @__PURE__ */ p("ul", {
				className: Q.presetList,
				"aria-label": "My presets",
				children: e.map((e) => {
					let { id: i, patch: { name: a } } = e, c = i === t;
					return /* @__PURE__ */ p("li", {
						className: Q.presetRow,
						"data-open": c,
						children: _ === i ? /* @__PURE__ */ m(f, { children: [
							/* @__PURE__ */ m("span", {
								className: Q.presetConfirm,
								children: [
									"Delete “",
									a,
									"”? This can’t be undone."
								]
							}),
							/* @__PURE__ */ p("button", {
								className: Q.dangerButton,
								"aria-label": `Confirm delete ${a}`,
								onClick: () => {
									v(null), s(e), b.current?.focus();
								},
								children: "Delete"
							}),
							/* @__PURE__ */ p("button", {
								ref: y,
								"aria-label": `Keep ${a}`,
								onClick: () => v(null),
								children: "Keep"
							})
						] }) : /* @__PURE__ */ m(f, { children: [
							/* @__PURE__ */ m("button", {
								className: Q.presetLoad,
								"aria-label": `Load ${a}`,
								"aria-current": c || void 0,
								onClick: () => r(e),
								children: [/* @__PURE__ */ p("strong", { children: a }), /* @__PURE__ */ p("small", { children: c ? n ? "OPEN · UNSAVED CHANGES" : "OPEN" : `Saved ${Fi(e.savedAt)}` })]
							}),
							/* @__PURE__ */ p("button", {
								"aria-label": `Export ${a}`,
								title: `Download ${a} as a .json patch file`,
								onClick: () => o(e.patch),
								children: "↓ Export"
							}),
							/* @__PURE__ */ p("button", {
								"aria-label": `Delete ${a}`,
								title: `Delete ${a} from this browser`,
								onClick: () => v(i),
								children: "Delete"
							})
						] })
					}, i);
				})
			}) : /* @__PURE__ */ p("p", {
				className: Q.presetEmpty,
				children: "Nothing saved yet. Save keeps your rack here under its name; Import file adds a patch you exported."
			}),
			/* @__PURE__ */ p("strong", {
				className: Q.sectionLabel,
				children: "FACTORY"
			}),
			/* @__PURE__ */ p("div", {
				className: Q.factoryGrid,
				role: "group",
				"aria-label": "Factory presets",
				children: Ct.map((e) => /* @__PURE__ */ p("button", {
					title: e,
					onClick: () => a(e),
					children: e
				}, e))
			})
		]
	});
}
function Li({ initialName: e, presets: t, onSave: n, onCancel: r }) {
	let [o, s] = u(e), c = l(null), d = a(), f = a(), h = qt(t, o), g = !o.trim();
	i(() => {
		c.current?.select();
	}, []);
	function _(e) {
		if (e.key === "Escape") {
			e.preventDefault(), r();
			return;
		}
		if (e.key !== "Tab") return;
		let t = [...e.currentTarget.querySelectorAll("input, button:not(:disabled)")], n = t[0], i = t.at(-1);
		e.shiftKey && document.activeElement === n ? (e.preventDefault(), i?.focus()) : !e.shiftKey && document.activeElement === i && (e.preventDefault(), n?.focus());
	}
	return /* @__PURE__ */ p("div", {
		className: Q.helpBackdrop,
		children: /* @__PURE__ */ p("div", {
			className: Q.saveDialog,
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": d,
			"aria-describedby": f,
			onKeyDown: _,
			children: /* @__PURE__ */ m("form", {
				onSubmit: (e) => {
					e.preventDefault(), g || n(o);
				},
				children: [
					/* @__PURE__ */ p("strong", {
						id: d,
						className: Q.saveTitle,
						children: "Save preset"
					}),
					/* @__PURE__ */ m("label", { children: ["Name", /* @__PURE__ */ p("input", {
						ref: c,
						autoFocus: !0,
						"aria-label": "Preset name",
						maxLength: 100,
						value: o,
						onChange: (e) => s(e.target.value)
					})] }),
					h && /* @__PURE__ */ m("p", {
						className: Q.saveWarning,
						role: "status",
						children: [
							"“",
							h.patch.name,
							"” is already in My Presets. Saving replaces it."
						]
					}),
					/* @__PURE__ */ p("p", {
						id: f,
						className: Q.saveNote,
						children: "Saved in this browser. Export a file to back it up or move it to another browser."
					}),
					/* @__PURE__ */ m("div", {
						className: Q.saveButtons,
						children: [/* @__PURE__ */ p("button", {
							type: "button",
							onClick: r,
							children: "Cancel"
						}), /* @__PURE__ */ p("button", {
							type: "submit",
							className: Q.saveButton,
							disabled: g,
							children: h ? "Replace" : "Save"
						})]
					})
				]
			})
		})
	});
}
//#endregion
//#region src/components/Live.tsx
function Ri() {
	let e = {
		pulsing: /* @__PURE__ */ new Set(),
		meter: 0,
		reductions: {},
		mixerLevels: {}
	}, t = /* @__PURE__ */ new Set();
	return {
		get: () => e,
		set(n) {
			if (!Object.keys(n).every((t) => n[t] === e[t])) {
				e = {
					...e,
					...n
				};
				for (let e of t) e();
			}
		},
		subscribe(e) {
			return t.add(e), () => {
				t.delete(e);
			};
		}
	};
}
var zi = t(null);
function Bi({ select: e, children: t }) {
	let n = r(zi), i = () => e(n.get());
	return /* @__PURE__ */ p(f, { children: t(d(n.subscribe, i, i)) });
}
//#endregion
//#region ../../../../../rackloose.svg?inline
var Vi = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2064%2064'%3e%3crect%20x='5'%20y='6'%20width='54'%20height='52'%20rx='3'%20fill='%23303337'%20stroke='%23101214'%20stroke-width='2'/%3e%3cpath%20d='M10%2010v44M54%2010v44'%20stroke='%23777'%20stroke-width='3'/%3e%3crect%20x='14'%20y='12'%20width='36'%20height='17'%20fill='%23b9503a'%20stroke='%23111'/%3e%3crect%20x='14'%20y='31'%20width='36'%20height='20'%20fill='%23a0ac9b'%20stroke='%23111'/%3e%3cg%20fill='%23232626'%20stroke='%23dfdfca'%3e%3ccircle%20cx='23'%20cy='21'%20r='5'/%3e%3ccircle%20cx='41'%20cy='21'%20r='5'/%3e%3c/g%3e%3cpath%20d='M23%2021v-4m18%204%203-3'%20stroke='%23fff'%20stroke-width='2'/%3e%3cg%20fill='%231b2221'%20stroke='%23555'%3e%3ccircle%20cx='22'%20cy='39'%20r='3'/%3e%3ccircle%20cx='42'%20cy='44'%20r='3'/%3e%3c/g%3e%3cpath%20d='M22%2039c-6%2020%2027%2020%2020%205'%20fill='none'%20stroke='%23f4bb50'%20stroke-width='3'/%3e%3cpath%20d='M7%208h50'%20stroke='%23a9abad'/%3e%3c/svg%3e", Hi = {
	channels: Array(8).fill(-60),
	bus: [-60, -60]
}, Ui = [
	"a",
	"w",
	"s",
	"e",
	"d",
	"f",
	"t",
	"g",
	"y",
	"h",
	"u",
	"j",
	"k"
], Wi = [
	"a",
	"s",
	"d",
	"f",
	"g",
	"h",
	"j",
	"k",
	"l",
	";",
	"'",
	"z",
	"x",
	"c",
	"v",
	"b"
], Gi = /* @__PURE__ */ new Set([
	1,
	3,
	6,
	8,
	10
]), Ki = "input:not([type]), input[type=\"text\"], input[type=\"search\"], textarea, [contenteditable=\"true\"]", qi = 30, Ji = 40, Yi = {
	id: "depth",
	label: "Depth",
	min: -1,
	max: 1,
	step: .01,
	initial: 1
}, Xi = (e) => `${Math.round(e * 100)}%`, Zi = {
	oscillator: "1V / OCT",
	filter: "CV CONTROL",
	delay: "WARM REPEATS",
	boom: "LONG LOW END",
	punch: "FOUR ON THE FLOOR",
	skitter: "NO SOUND · ALL BOUNCE",
	forge: "HIT IT HARDER",
	rust: "NOTHING CLEAN"
};
function Qi(e, t, n) {
	let r = URL.createObjectURL(new Blob([e], { type: t })), i = document.createElement("a");
	i.href = r, i.download = n, i.click(), setTimeout(() => URL.revokeObjectURL(r), 1e3);
}
var $i = (e) => {
	let [t, n] = e.dataset.portKey.split(":");
	return {
		moduleId: t,
		portId: n
	};
}, ea = (e, t) => e === t || !!e && !!t && V(e, t), ta = (e, t) => e.error === t.error && e.inside === t.inside && e.cableId === t.cableId && V(e.anchor, t.anchor) && e.point.x === t.point.x && e.point.y === t.point.y && ea(e.target, t.target), na = (e, t) => V(e.from, t) ? e.to : e.from, ra = (e, t) => ({
	...e,
	cables: e.cables.filter((e) => e.id !== t)
});
function ia(e) {
	try {
		return localStorage.getItem(e);
	} catch {
		return null;
	}
}
function aa({ key: e, patch: t, open: n }) {
	let r = At(localStorage, e, t);
	return r || (n ? localStorage.setItem(`${e}:open`, n) : localStorage.removeItem(`${e}:open`)), r;
}
function oa({ keysEnabled: e = !0, suspended: t = !1, storageKey: r = "rackloose.patch.v1", linkBrand: o = !0 }) {
	let [d, h] = u(() => Tt()), g = l(d), _ = l(null), v = l(null), y = l(null), b = l(null), x = l(null), S = l(null), [C, w] = u(!1), [T, E] = u(!1), [D, ee] = u(!1), [te, ne] = u(!1), [re, ie] = u(null), [ae, oe] = u("Loading patch…"), [se, O] = c((e, t) => ({
		text: t,
		serial: e.serial + 1
	}), {
		text: "Ready when you are. Enable audio, then play a key or start the pattern.",
		serial: 0
	}), ce = se.text, [le, ue] = u(!0), [k, A] = u(!1), [j, M] = u(!1), [N, de] = u(!1), [P, fe] = u(-1), [pe, me] = u([]), [he, ge] = u(48e3), [F] = u(Ri), [_e, ve] = u(3), [ye, be] = u(null), [xe, Se] = u(!0), [Ce, I] = u(null), [L, R] = u(null), [we, Te] = u(null), [Ee, Oe] = u(null), [Ae, Le] = u(null), [Re, ze] = u(4), [Ve, We] = u(!1), [H, Ge] = u(tt), [Ke, qe] = u("performance"), U = l("performance"), [Je, Xe] = u(/* @__PURE__ */ new Set()), Qe = l(/* @__PURE__ */ new Map()), nt = l(/* @__PURE__ */ new Set()), [it, ot] = u({}), [W, G] = u(null), [lt, pt] = u(null), [gt, _t] = u({
		undo: 0,
		redo: 0
	}), vt = l(tt), yt = l(!1), bt = l(3), xt = l(It()), St = l(null), [Ct, wt] = u([]), [At, jt] = u({}), [Mt, Pt] = u(""), Ft = l(""), [K, Vt] = u(null), Ht = l(null), Ut = l(null), q = l(null), Xt = l(0), Zt = l(!1), Qt = l(null), J = l(0), $t = a(), en = a(), tn = a(), nn = `${r}:baseline`, rn = `${r}:presets`, an = Ct.find((e) => e.id === At[Mt]) ?? null, on = an?.id ?? null, sn = s(() => Dt(d), [d]), cn = s(() => an ? Dt(an.patch) : lt, [an, lt]), ln = cn !== null && sn !== cn;
	i(() => {
		g.current = d, _.current?.update(d);
	}, [d]), i(() => {
		let e = new er(g.current, (e) => O(e.message));
		_.current = e;
		let n = 0, r = 0;
		function i(t) {
			let a = F.get(), o = g.current.modules.filter((t) => at(t.type) && e.pulsing(t.id)).map((e) => e.id);
			if (F.set({ pulsing: o.length === a.pulsing.size && o.every((e) => a.pulsing.has(e)) ? a.pulsing : new Set(o) }), t - r > 40) {
				ge(e.sampleRate), fe(e.clock), A(e.playing), M(e.ready), me((t) => {
					let n = e.activeNotes;
					return n.length === t.length && n.every((e, n) => e === t[n]) ? t : n;
				}), ot((t) => {
					let n = Object.fromEntries(g.current.modules.filter((e) => Ze(e.type)).map((t) => [t.id, {
						playing: e.modulePlaying(t.id),
						clock: e.moduleClock(t.id)
					}]));
					return JSON.stringify(n) === JSON.stringify(t) ? t : n;
				});
				let n = Object.fromEntries(g.current.modules.filter((e) => [
					"compressor",
					"cohere",
					"talon"
				].includes(e.type)).map((t) => [t.id, Math.round(e.reduction(t.id) * 2) / 2])), i = Object.fromEntries(g.current.modules.filter((e) => e.type === "mixer").map((t) => {
					let { channels: n, bus: r } = e.mixerLevels(t.id), i = {
						channels: n.map(Math.round),
						bus: r.map(Math.round)
					}, o = a.mixerLevels[t.id];
					return [t.id, o && JSON.stringify(o) === JSON.stringify(i) ? o : i];
				}));
				F.set({
					meter: e.meter,
					reductions: JSON.stringify(n) === JSON.stringify(a.reductions) ? a.reductions : n,
					mixerLevels: Object.keys(i).length === Object.keys(a.mixerLevels).length && Object.entries(i).every(([e, t]) => a.mixerLevels[e] === t) ? a.mixerLevels : i
				}), r = t;
			}
			n = requestAnimationFrame(i);
		}
		n = requestAnimationFrame(i);
		let a = () => {
			document.hidden ? e.setSuspended(!0) : e.setSuspended(t);
		};
		document.addEventListener("visibilitychange", a);
		let o = v.current, s = (t) => e.lifted(`pointer-${t.pointerId}`), c = () => e.lifted();
		return o?.addEventListener("pointerup", s, !0), o?.addEventListener("touchend", c, !0), () => {
			cancelAnimationFrame(n), document.removeEventListener("visibilitychange", a), o?.removeEventListener("pointerup", s, !0), o?.removeEventListener("touchend", c, !0), e.dispose(), _.current = null;
		};
	}, [t, F]), i(() => {
		_.current?.setSuspended(t);
	}, [t]), i(() => {
		ue(!0);
		let e = setTimeout(() => ue(!1), Math.min(9e3, 3500 + se.text.length * 40));
		return () => clearTimeout(e);
	}, [se]), i(() => {
		_.current?.setMute(N);
	}, [N, t]), i(() => {
		_.current?.setMix(H);
	}, [H, t]);
	let un = n((e) => {
		g.current = e.patch, vt.current = e.mix, yt.current = e.mainMuted, bt.current = e.octave, Ft.current = e.session, h(e.patch), Ge(e.mix), de(e.mainMuted), ve(e.octave), Pt(e.session);
	}, []), dn = n(() => {
		xt.current = It(), _t({
			undo: 0,
			redo: 0
		});
	}, []), fn = n((e, t = null) => {
		let n = {
			patch: g.current,
			mix: vt.current,
			mainMuted: yt.current,
			octave: bt.current,
			session: Ft.current
		}, r = {
			...n,
			...typeof e == "function" ? e(n) : e
		};
		(r.patch !== n.patch || r.mix !== n.mix || r.mainMuted !== n.mainMuted || r.octave !== n.octave || r.session !== n.session) && (xt.current = Lt(xt.current, n, t, Date.now()), _t({
			undo: xt.current.past.length,
			redo: 0
		}), un(r));
	}, [un]), Y = n((e, t = null) => fn((t) => ({ patch: e(t.patch) }), t), [fn]), pn = n((e, t) => {
		let n = g.current.modules.find((t) => t.id === e), r = Object.keys(t);
		if (!n || r.every((e) => n.params[e] === t[e])) return;
		let i = r.length === 1 ? z[n.type].params.find((e) => e.id === r[0]) : void 0;
		Y((n) => ({
			...n,
			modules: n.modules.map((n) => n.id === e ? {
				...n,
				params: {
					...n.params,
					...t
				}
			} : n)
		}), i && !i.choices && !i.pattern ? `param:${e}:${i.id}` : null);
	}, [Y]), mn = n((e, t) => fn((n) => ({ mix: ft(n.mix, e, t) })), [fn]), hn = n((e) => {
		let t = Dt(e);
		pt(t);
		try {
			localStorage.setItem(nn, t);
		} catch {}
	}, [nn]);
	i(() => {
		let e, t = {
			presets: [],
			error: null
		}, n = null;
		try {
			St.current && St.current.key !== r && aa(St.current), e = kt(localStorage, r), t = Wt(localStorage, `${r}:presets`), n = localStorage.getItem(`${r}:open`);
		} catch {
			e = {
				patch: null,
				error: "Local save unavailable. Export a patch file to keep your work."
			};
		}
		(e.error ?? t.error) && O(e.error ?? t.error);
		let i = e.patch ?? Tt(), a = e.patch ? ia(`${r}:baseline`) : null;
		_.current?.panic(), U.current = i.modules[0].id, qe(U.current);
		let o = ke("session");
		wt(t.presets), jt(n && t.presets.some((e) => e.id === n) ? { [o]: n } : {}), Vt(null), un({
			patch: i,
			mix: tt,
			mainMuted: !1,
			octave: bt.current,
			session: o
		}), dn();
		let s = a ?? Dt(i);
		if (a === null) try {
			localStorage.setItem(`${r}:baseline`, s);
		} catch {}
		pt(s), oe(e.error ?? (e.patch ? "Patch restored" : "Saved locally")), ie(r);
	}, [
		r,
		un,
		dn
	]), i(() => {
		if (re !== r) return;
		let e = St.current = {
			key: r,
			patch: d,
			open: on
		}, t = setTimeout(() => {
			try {
				oe(aa(e) ?? "Saved locally");
			} catch {
				oe("Local save unavailable. Export a patch file to keep your work.");
			}
		}, 400);
		return () => clearTimeout(t);
	}, [
		d,
		on,
		re,
		r
	]), i(() => {
		let e = (e) => {
			if (e.key === rn || e.key === null) try {
				wt(Wt(localStorage, rn).presets);
			} catch {}
		};
		return window.addEventListener("storage", e), () => window.removeEventListener("storage", e);
	}, [rn]), i(() => {
		let e = () => {
			if (St.current) try {
				aa(St.current);
			} catch {}
		};
		return window.addEventListener("pagehide", e), () => {
			window.removeEventListener("pagehide", e), e();
		};
	}, []), i(() => () => {
		cancelAnimationFrame(Xt.current), cancelAnimationFrame(J.current);
	}, []);
	let X = n((e) => O(e instanceof Error ? e.message : "Audio could not start. Try enabling it again."), []), Z = n((e, t = !1) => {
		(!t || nt.current.has(e)) && (nt.current.delete(e), t ? _.current?.cancel(e) : _.current?.release(e), Qe.current.delete(e) && Xe(new Set(Qe.current.values())));
	}, []), gn = n(() => {
		_.current?.releaseManual(), nt.current.clear(), Qe.current.clear(), Xe(/* @__PURE__ */ new Set());
	}, []), _n = n((e, n, r = !1) => {
		if (t) return;
		let i = g.current, a = i.modules.find((e) => e.id === U.current) ?? i.modules[0], o = z[a.type];
		if ($e(i, a.id) || O(`${o.name} has no audio path to MAIN. Flip the rack to connect it.`), o.drum) {
			let t = o.drum.voices[n];
			if (!t || Qe.current.has(e)) return;
			Qe.current.set(e, t.id), Xe(new Set(Qe.current.values())), _.current?.hit(a.id, t.id, e, r).catch(X);
		} else a.type === "noise" && (Qe.current.set(e, "noise"), Xe(new Set(Qe.current.values()))), _.current?.press(e, a.type === "noise" ? 60 : (_e + 1) * 12 + n, a.id, r).catch(X);
	}, [
		X,
		t,
		_e
	]), vn = n((e, n) => {
		t || _.current?.hit(e, n).catch(X);
	}, [X, t]), yn = n(() => {
		_.current?.playing ? _.current.pause() : _.current?.play().catch(X);
	}, [X]), bn = n((e) => {
		Ye(e.type) && U.current !== e.id && (gn(), U.current = e.id, qe(e.id));
	}, [gn]);
	i(() => {
		if (!e || t || D || K !== null) {
			gn();
			return;
		}
		function n(e) {
			if (e.defaultPrevented || e.metaKey || e.ctrlKey || e.altKey || e.target instanceof Element && e.target.closest("input, select, textarea, [contenteditable=\"true\"]")) return;
			let t = g.current.modules.find((e) => e.id === U.current), n = t && (z[t.type].drum?.voices.length ?? +(t.type === "noise")), r = (n ? Wi.slice(0, n) : Ui).indexOf(e.key.toLowerCase());
			r >= 0 && (e.preventDefault(), e.repeat || _n(`key-${e.code}`, r));
		}
		let r = (e) => Z(`key-${e.code}`);
		return window.addEventListener("keydown", n), window.addEventListener("keyup", r), window.addEventListener("blur", gn), () => {
			window.removeEventListener("keydown", n), window.removeEventListener("keyup", r), window.removeEventListener("blur", gn), gn();
		};
	}, [
		e,
		t,
		_n,
		Z,
		yn,
		D,
		K,
		gn
	]), i(() => {
		if (!e || t || D || K !== null) return;
		let n = (e) => {
			if (e.code !== "Space" || e.metaKey || e.ctrlKey || e.altKey) return;
			let t = e.target instanceof Element ? e.target : null;
			t?.closest(Ki) || (v.current?.contains(t) || !e.defaultPrevented && !t?.closest("button, [role=\"button\"], [role=\"slider\"], input, select, [contenteditable=\"true\"]")) && (e.preventDefault(), e.stopPropagation(), e.type === "keydown" && !e.repeat && yn());
		};
		return window.addEventListener("keydown", n, !0), window.addEventListener("keyup", n, !0), () => {
			window.removeEventListener("keydown", n, !0), window.removeEventListener("keyup", n, !0);
		};
	}, [
		e,
		t,
		D,
		K,
		yn
	]), i(() => {
		if (!Ae) return;
		let e = y.current, t = e?.querySelector(`[data-module-id="${Ae}"]`);
		if (e && t) {
			let n = t.offsetTop - 6, r = t.offsetTop + t.offsetHeight + 6, i = matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth";
			n < e.scrollTop || r - n > e.clientHeight ? e.scrollTo({
				top: n,
				behavior: i
			}) : r > e.scrollTop + e.clientHeight && e.scrollTo({
				top: r - e.clientHeight,
				behavior: i
			});
		}
		let n = setTimeout(() => Le(null), 1400);
		return () => clearTimeout(n);
	}, [Ae]);
	let xn = n(() => {
		q.current = null, cancelAnimationFrame(Xt.current), Xt.current = 0, Te(null);
	}, []), Sn = n(() => {
		let e = q.current;
		return !e?.moved || e.cancelled ? !1 : (e.cancelled = !0, cancelAnimationFrame(Xt.current), Xt.current = 0, Te(null), !0);
	}, []), Cn = n((e) => {
		let t = (e === "undo" ? Rt : zt)(xt.current, {
			patch: g.current,
			mix: vt.current,
			mainMuted: yt.current,
			octave: bt.current,
			session: Ft.current
		});
		if (!t) return;
		xt.current = t.history, _t({
			undo: t.history.past.length,
			redo: t.history.future.length
		}), q.current && (Zt.current = !0), xn(), R(null), G(null), I((e) => e && t.state.patch.cables.some((t) => t.id === e) ? e : null), t.state.patch.modules.some((e) => e.id === U.current) || (gn(), U.current = t.state.patch.modules[0].id, qe(U.current)), un(t.state);
		let n = e === "undo" ? t.history.past.length : t.history.future.length;
		O(`${e === "undo" ? "Undone" : "Redone"}. ${n} more ${n === 1 ? "step" : "steps"} to ${e}.`);
	}, [
		un,
		gn,
		xn
	]);
	i(() => {
		let t = (t) => {
			if (!(t.key !== "Escape" || t.defaultPrevented)) {
				if (Sn()) {
					t.preventDefault(), O("Drag cancelled. Your cables are unchanged.");
					return;
				}
				(L || W || Ce) && (e || v.current?.contains(t.target)) && (t.preventDefault(), R(null), G(null), I(null), O(W ? "Plug back in its jack." : "Patching cancelled."));
			}
		}, n = () => Sn();
		return window.addEventListener("keydown", t, !0), window.addEventListener("blur", n), () => {
			window.removeEventListener("keydown", t, !0), window.removeEventListener("blur", n);
		};
	}, [
		L,
		W,
		Ce,
		e,
		Sn
	]), i(() => {
		if (!Ce) return;
		let t = (t) => {
			if (t.key !== "Delete" && t.key !== "Backspace" || t.defaultPrevented || t.metaKey || t.ctrlKey || t.altKey) return;
			let n = t.target instanceof Element ? t.target : null;
			n?.closest("input, select, textarea, [contenteditable=\"true\"]") || !e && !v.current?.contains(n) || (t.preventDefault(), Y((e) => ra(e, Ce)), I(null), R(null), G(null), O("Cable removed. Undo puts it back."));
		};
		return window.addEventListener("keydown", t, !0), () => window.removeEventListener("keydown", t, !0);
	}, [
		Ce,
		e,
		Y
	]), i(() => {
		let n = (n) => {
			if (n.defaultPrevented || n.altKey || !(n.metaKey || n.ctrlKey) || D || K !== null) return;
			let r = n.key.toLowerCase(), i = r === "z" && !n.shiftKey, a = r === "z" && n.shiftKey || r === "y" && n.ctrlKey && !n.shiftKey;
			if (!i && !a) return;
			let o = n.target instanceof Element ? n.target : null;
			(v.current?.contains(o) || e && !t && !o?.closest("input, select, textarea, [contenteditable=\"true\"]")) && (n.preventDefault(), Cn(i ? "undo" : "redo"));
		};
		return window.addEventListener("keydown", n, !0), () => window.removeEventListener("keydown", n, !0);
	}, [
		e,
		t,
		D,
		K,
		Cn
	]);
	let wn = n((e) => {
		try {
			let t = e(Wt(localStorage, rn).presets);
			if (t.length > 200) return "My Presets holds up to 200 presets. Delete or export some first.";
			let n = Gt(localStorage, rn, t);
			return n || wt(t), n;
		} catch {
			return Bt;
		}
	}, [rn]), Tn = n((e, t) => {
		let n = wn((n) => Kt(n, {
			id: e,
			savedAt: Date.now(),
			patch: t
		}));
		if (n) {
			O(n);
			return;
		}
		let r = Ft.current;
		jt((t) => ({
			...t,
			[r]: e
		})), hn(t), O(`Saved “${t.name}” in this browser.`);
	}, [wn, hn]), En = n((e) => {
		Ut.current = e ?? (document.activeElement instanceof HTMLElement ? document.activeElement : null), Vt(g.current.name);
	}, []), Dn = n((e) => {
		let t = g.current;
		!an || !t.name.trim() || qt(Ct, t.name, an.id) ? En(e) : Tn(an.id, t);
	}, [
		an,
		Ct,
		En,
		Tn
	]);
	i(() => {
		let n = (n) => {
			if (n.defaultPrevented || n.altKey || !(n.metaKey || n.ctrlKey) || n.key.toLowerCase() !== "s") return;
			let r = n.target instanceof Element ? n.target : null, i = !!v.current?.contains(r);
			if (D || K !== null) {
				i && n.preventDefault();
				return;
			}
			(i || e && !t && !r?.closest("input, select, textarea, [contenteditable=\"true\"]")) && (n.preventDefault(), n.shiftKey ? En() : Dn());
		};
		return window.addEventListener("keydown", n, !0), () => window.removeEventListener("keydown", n, !0);
	}, [
		e,
		t,
		D,
		K,
		Dn,
		En
	]);
	function On(e, t, n, r = null) {
		Y((r) => {
			let i = Ne(r, e), a = i[t];
			return !a || Object.keys(n).every((e) => a[e] === n[e]) ? r : Pe(r, e, i.map((e, r) => r === t ? {
				...e,
				...n
			} : e));
		}, r && `${r}:${e}`);
	}
	function kn(e, t) {
		Y((n) => n.sequencer[e] === t ? n : {
			...n,
			sequencer: {
				...n.sequencer,
				[e]: t
			}
		}, e);
	}
	function An(e, t) {
		Y((n) => n.cables.some((n) => n.id === e && n.amount !== t) ? {
			...n,
			cables: n.cables.map((n) => n.id === e ? {
				...n,
				amount: t
			} : n)
		} : n, `depth:${e}`);
	}
	function jn(e, t, n = null) {
		xn(), G(null), _.current?.panic(), gn();
		let r = ke("session");
		n && jt((e) => ({
			...e,
			[r]: n
		})), fn({
			patch: e,
			mix: tt,
			mainMuted: !1,
			session: r
		}), hn(e), ne(!1), U.current = e.modules[0].id, qe(U.current), be(null), I(null), R(null), O(ln ? `${t} Undo brings back your unsaved changes.` : t);
	}
	function Mn() {
		Vt(null);
		let e = Ut.current;
		Ut.current = null, e?.isConnected && e.focus();
	}
	function Nn(e) {
		e !== g.current.name && Y((t) => ({
			...t,
			name: e
		})), Tn(qt(Ct, e)?.id ?? ke("preset"), g.current), Mn();
	}
	function Pn(e) {
		let t = wn((t) => t.filter((t) => t.id !== e.id));
		O(t ?? `Deleted “${e.patch.name}” from this browser.${e.id === on ? " The rack still has it; Save adds it back." : ""}`);
	}
	function Fn(e) {
		let t = `${Yt(e.name)}.rackloose.json`;
		Qi(Et(e), "application/json", t), O(`Exported ${t}. Import it in any browser to add it to My Presets.`);
	}
	function In(e) {
		let t = je(e);
		Y((e) => ({
			...e,
			modules: [
				...e.modules.slice(0, -1),
				t,
				e.modules.at(-1)
			]
		})), bn(t), E(!1), Le(t.id), O(`${z[e].name} added. Flip the rack to connect it.`);
	}
	function Ln(e) {
		let t = {
			...e,
			id: ke(),
			params: { ...e.params }
		};
		Y((n) => {
			let r = [...n.modules];
			return r.splice(r.findIndex((t) => t.id === e.id) + 1, 0, t), {
				...n,
				modules: r
			};
		}), bn(t), Le(t.id), O(`${z[e.type].name} duplicated without its cables.`);
	}
	function Rn() {
		ee(!1), x.current?.focus();
	}
	function zn(e, t, n = null) {
		try {
			let r = et(g.current, e, t, n);
			if (R(null), G(null), r === g.current) {
				O("Plug back in its jack.");
				return;
			}
			fn({ patch: r }), O(n ? "Cable moved." : "Connected. Flip to the front to hear your patch.");
		} catch (e) {
			X(e);
		}
	}
	function Bn(e) {
		Y((t) => ra(t, e)), I(null), G(null), O("Cable unplugged. Undo puts it back.");
	}
	function Vn(e) {
		if (Zt.current) {
			Zt.current = !1;
			return;
		}
		let t = Ie(g.current, e);
		if (W) {
			t?.id === W.cableId && !V(e, W.anchor) ? (G(null), O("Plug back in its jack.")) : zn(W.anchor, e, W.cableId);
			return;
		}
		if (L && V(L, e)) {
			R(null), O("Patching cancelled.");
			return;
		}
		if (L) {
			zn(L, e);
			return;
		}
		if (t) {
			G({
				cableId: t.id,
				anchor: na(t, e)
			}), I(t.id), O("Plug lifted. Choose a free jack, or tap empty rack space to unplug. Tap the jack again or press Escape to put it back.");
			return;
		}
		let n = B(g.current, e);
		n && (R(e), I(null), O(`Choose a free ${n.kind.toUpperCase()} ${n.direction === "out" ? "input" : "output"}. Escape cancels.`));
	}
	function Hn(e) {
		C && !e.target.closest("button, [role=\"button\"], [role=\"slider\"], input, select, label, a") && (W ? Bn(W.cableId) : L ? (R(null), O("Patching cancelled.")) : I(null));
	}
	function Un(e) {
		let t = y.current;
		if (!t) return null;
		let n = t.getBoundingClientRect(), r = e.clientX >= n.left && e.clientX <= n.right && e.clientY >= n.top && e.clientY <= n.bottom, i = null, a = qi;
		r && t.querySelectorAll("[data-port-key]").forEach((t) => {
			let r = t.getBoundingClientRect(), o = r.left + r.width / 2, s = r.top + r.height / 2, c = e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom ? -1 : Math.hypot(o - e.clientX, s - e.clientY);
			c >= a || s < n.top || s > n.bottom || (i = $i(t), a = c);
		});
		let o = !!i && V(i, e.anchor), s = i && !o ? Be(g.current, e.anchor, i, e.cableId) : null;
		return {
			anchor: e.anchor,
			cableId: e.cableId,
			target: s || o ? null : i,
			candidate: i,
			error: s,
			inside: r,
			point: {
				x: e.clientX - n.left + t.scrollLeft,
				y: e.clientY - n.top + t.scrollTop
			}
		};
	}
	function Wn() {
		let e = q.current, t = y.current;
		if (!e?.moved || e.cancelled || !t) {
			Xt.current = 0;
			return;
		}
		let n = t.getBoundingClientRect(), r = n.top + Ji - e.clientY, i = e.clientY - (n.bottom - Ji);
		r > 0 ? t.scrollTop -= Math.ceil(Math.min(r, Ji) / 3) : i > 0 && (t.scrollTop += Math.ceil(Math.min(i, Ji) / 3));
		let a = Un(e);
		Te((e) => e && a && ta(e, a) ? e : a), Xt.current = requestAnimationFrame(Wn);
	}
	function Gn(e, t) {
		if (!e.isPrimary || e.button !== 0) return;
		e.stopPropagation(), Zt.current = !1;
		let n = Ie(g.current, t);
		q.current = {
			pointerId: e.pointerId,
			anchor: n ? na(n, t) : t,
			cableId: n?.id ?? null,
			x: e.clientX,
			y: e.clientY,
			clientX: e.clientX,
			clientY: e.clientY,
			moved: !1,
			cancelled: !1
		}, e.currentTarget.setPointerCapture(e.pointerId);
	}
	function Kn(e) {
		let t = q.current;
		if (t && t.pointerId === e.pointerId && !t.cancelled) {
			if (t.clientX = e.clientX, t.clientY = e.clientY, !t.moved) {
				if (Math.hypot(e.clientX - t.x, e.clientY - t.y) <= 5) return;
				t.moved = !0, R(null), G(null), I(t.cableId), O(t.cableId ? "Plug pulled out. Drop it on a free jack, or on empty rack space to unplug. Escape puts it back." : "Drop the plug on a free highlighted jack. Escape cancels.");
			}
			Xt.current ||= requestAnimationFrame(Wn);
		}
	}
	function qn(e) {
		let t = q.current;
		if (!t || t.pointerId !== e.pointerId) return;
		t.clientX = e.clientX, t.clientY = e.clientY, t.moved ||= Math.hypot(t.clientX - t.x, t.clientY - t.y) > 5;
		let n = Un(t);
		xn(), (t.moved || t.cancelled) && (Zt.current = !0), t.moved && !t.cancelled && (n?.error ? O(`${n.error}${t.cableId ? " The plug went back in its jack." : ""}`) : n?.target ? (zn(t.anchor, n.target, t.cableId), t.cableId && I(t.cableId)) : t.cableId && n?.inside && !n.candidate ? Bn(t.cableId) : O(t.cableId ? "Plug back in its jack." : "Connection cancelled. Your cables are unchanged."));
	}
	function Jn() {
		q.current && (Zt.current = !0, xn());
	}
	function Yn(e) {
		let t = W?.anchor ?? L;
		t && !q.current && e.pointerType === "mouse" && (Qt.current = {
			anchor: t,
			cableId: W?.cableId ?? null,
			clientX: e.clientX,
			clientY: e.clientY
		}, J.current ||= requestAnimationFrame(() => {
			J.current = 0;
			let e = Qt.current && Un(Qt.current);
			Oe((t) => t && e && ta(t, e) ? t : e);
		}));
	}
	async function Xn(e) {
		if (e) {
			try {
				if (e.size > 1e6) throw Error("Patch files must be smaller than 1 MB.");
				let t = await e.text(), n = Ot(t), r = n.cables.length;
				try {
					let e = JSON.parse(t);
					Array.isArray(e.cables) && (r = e.cables.length);
				} catch {}
				let i = r - n.cables.length, a = i > 0 ? ` ${i} ${i === 1 ? "cable shared a jack" : "cables shared jacks"} with no spare left, so ${i === 1 ? "it was" : "they were"} left out.` : "", o = n.name.trim() ? n.name : "Imported patch", s = qt(Ct, o);
				if (s && Dt(s.patch) === Dt({
					...n,
					name: s.patch.name
				})) jn(s.patch, `“${s.patch.name}” is already in My Presets, so it opened.${a}`, s.id);
				else {
					let e = {
						id: ke("preset"),
						savedAt: Date.now(),
						patch: {
							...n,
							name: s ? Jt(Ct, o) : o
						}
					}, t = wn((t) => Kt(t, e));
					jn(e.patch, t ? `Opened “${e.patch.name}”. ${t}${a}` : `Imported “${e.patch.name}” into My Presets.${s ? ` You already had a different “${s.patch.name}”.` : ""}${a}`, t ? null : e.id);
				}
			} catch (e) {
				X(e);
			}
			b.current && (b.current.value = "");
		}
	}
	async function Zn() {
		We(!0), O("Rendering your patch…");
		try {
			Qi(nr(await tr(d, Re, H)), "audio/wav", `${Yt(d.name)}.wav`), O("WAV exported. Your loop includes a two-second effects tail.");
		} catch (e) {
			X(e);
		} finally {
			We(!1);
		}
	}
	let Qn = d.cables.find((e) => e.id === Ce), $n = W?.anchor ?? L, rr = W?.cableId ?? null, ir = we ?? (C && $n && Ee && V(Ee.anchor, $n) && Ee.cableId === rr ? Ee : null), or = we?.anchor ?? $n, sr = we ? we.cableId : rr, lr = ir?.cableId ?? null;
	function ur(e, t, n) {
		let r = z[e.type], i = {
			moduleId: e.id,
			portId: t.id
		}, a = !!or && V(or, i), o = Ie(d, i), s = !!o && (o.id !== lr || a), c = t.direction === "in" ? "input" : "output", l = e.type === "mixer" && t.direction === "in" ? dt(d, e.id, t.id) : null, u = l ? `Channel ${t.id.toUpperCase()}: ${l.source}` : t.label;
		return /* @__PURE__ */ p("button", {
			className: Q.socket,
			"data-port-key": `${e.id}:${t.id}`,
			"data-kind": t.kind,
			"data-jack": n ?? void 0,
			"data-connected": s,
			"data-compatible": !!or && !a && !Be(d, or, i, sr),
			"data-pending": a,
			"data-lifted": !!W && o?.id === W.cableId && !a,
			"data-target": !!ir?.target && V(ir.target, i),
			"data-selected-end": !!Qn && Qn.id !== lr && (V(Qn.from, i) || V(Qn.to, i)),
			"aria-label": `${r.name} ${u} ${c}${n && n > 1 ? ` ${n}` : ""}`,
			"aria-description": `${t.kind.toUpperCase()} ${c}${l?.tooltip ? ` · ${l.tooltip}` : ""}`,
			title: `${u}${l?.tooltip ? ` · ${l.tooltip}` : ""}${n ? ` · jack ${n}` : ""} · ${t.kind.toUpperCase()}${o ? " · plugged" : ""}`,
			onClick: () => Vn(i),
			onPointerDown: (e) => Gn(e, i),
			onPointerMove: Kn,
			onPointerUp: qn,
			onPointerCancel: Jn,
			onLostPointerCapture: Jn,
			children: /* @__PURE__ */ p("span", {})
		}, t.id);
	}
	function dr(e) {
		let t = z[e.type];
		return /* @__PURE__ */ p("div", {
			className: Q.portGroups,
			children: ["in", "out"].filter((e) => t.ports.some((t) => t.direction === e)).map((n) => {
				let r = t.ports.filter((e) => e.direction === n);
				return /* @__PURE__ */ m("div", {
					className: Q.portGroup,
					"data-direction": n,
					children: [/* @__PURE__ */ p("span", {
						className: Q.portHeading,
						children: n === "in" ? "INPUTS" : "OUTPUTS"
					}), /* @__PURE__ */ p("div", {
						className: Q.portRow,
						children: r.filter((e) => !e.copyOf).map((i) => {
							let a = r.filter((e) => e === i || e.copyOf === i.id), o = n === "in" && i.kind === "cv", s = o ? d.cables.find((t) => V(t.to, {
								moduleId: e.id,
								portId: i.id
							})) : void 0, c = e.type === "mixer" && n === "in" ? dt(d, e.id, i.id) : null;
							return /* @__PURE__ */ m("div", {
								className: Q.socketControl,
								"data-source": !!c,
								"data-trim": o,
								"data-jacks": a.length,
								children: [
									a.length > 1 ? /* @__PURE__ */ p("div", {
										className: Q.jacks,
										children: a.map((n) => ur(e, n, Fe(t.ports, n)))
									}) : ur(e, i, null),
									o && /* @__PURE__ */ p(ar, {
										trim: !0,
										param: Yi,
										value: s?.amount ?? Yi.initial,
										format: Xi,
										prefix: `${t.name} ${i.label}`,
										disabled: !s,
										onChange: (e) => {
											s && An(s.id, e);
										}
									}),
									/* @__PURE__ */ p("span", {
										title: c?.tooltip || void 0,
										children: c?.source ?? i.label
									}),
									(n !== "in" || i.kind !== "audio") && /* @__PURE__ */ m("small", { children: [i.kind.toUpperCase(), s && ` · ${Xi(s.amount)}`] })
								]
							}, i.id);
						})
					})]
				}, n);
			})
		});
	}
	function fr(e, t, n) {
		return t.choices ? /* @__PURE__ */ m("label", {
			className: Q.selectControl,
			children: [
				/* @__PURE__ */ p("span", {
					className: Q.controlLabel,
					children: t.label
				}),
				/* @__PURE__ */ p("select", {
					"aria-label": `${n} ${t.label}`,
					value: e.params[t.id],
					onChange: (n) => pn(e.id, { [t.id]: Number(n.target.value) }),
					children: t.choices.map((e, t) => /* @__PURE__ */ p("option", {
						value: t,
						children: e
					}, e))
				}),
				/* @__PURE__ */ p(Mr, {
					param: t,
					value: e.params[t.id]
				})
			]
		}, t.id) : /* @__PURE__ */ p(ar, {
			param: t,
			prefix: n,
			value: e.params[t.id],
			onChange: (n) => pn(e.id, { [t.id]: n })
		}, t.id);
	}
	function pr(e) {
		let t = z[e.type], n = [...new Set(t.params.filter((e) => e.group && !e.voice).map((e) => e.group))];
		return n.length ? /* @__PURE__ */ p("div", {
			className: Q.groupControls,
			"data-type": e.type,
			children: n.map((n) => /* @__PURE__ */ m("fieldset", {
				"data-group": n,
				children: [/* @__PURE__ */ p("legend", { children: n }), /* @__PURE__ */ p("div", {
					className: Q.controls,
					children: t.params.filter((e) => e.group === n).map((r) => fr(e, r, `${t.name} ${n}`))
				})]
			}, n))
		}) : null;
	}
	function mr(e) {
		return ut(d, e);
	}
	function hr(e) {
		let n = !!it[e.id]?.playing;
		return /* @__PURE__ */ m("button", {
			className: Q.playButton,
			disabled: t,
			"aria-label": `${n ? "Stop" : "Play"} ${mr(e)} sequencer`,
			"data-playing": n,
			onClick: () => {
				_.current?.modulePlaying(e.id) ? _.current.stopModule(e.id) : _.current?.play(e.id).catch(X);
			},
			children: [/* @__PURE__ */ p(Br, { name: n ? "stop" : "play" }), /* @__PURE__ */ p("span", { children: n ? "STOP" : "PLAY" })]
		});
	}
	let gr = d.modules.find((e) => e.id === Ke) ?? d.modules[0], $ = z[gr.type], _r = $.drum?.voices ?? (gr.type === "noise" ? [{
		id: "noise",
		label: "Noise"
	}] : null), vr = _r && _r.length > 6 ? Math.ceil(_r.length / 2) : 6, yr = $e(d, gr.id) ? null : `${$.name} needs an audio path to MAIN. Flip the rack to connect it.`;
	function br(e) {
		let t = Ne(d, e.id), n = it[e.id]?.clock ?? -1, r = n < 0 ? -1 : n % 16, i = mr(e), a = i !== z[e.type].name, o = ye?.moduleId === e.id ? ye.index : null, s = o === null ? null : t[o];
		return /* @__PURE__ */ m("div", {
			className: Q.sequenceBody,
			children: [
				/* @__PURE__ */ m("div", {
					className: Q.sequenceTop,
					children: [/* @__PURE__ */ m("div", {
						className: Q.lcd,
						children: [
							/* @__PURE__ */ p("small", { children: "SEQUENCER" }),
							/* @__PURE__ */ m("strong", { children: [r >= 0 ? String(r + 1).padStart(2, "0") : "16", /* @__PURE__ */ p("span", { children: "STEPS" })] }),
							/* @__PURE__ */ p("span", {
								className: Q.lcdDots,
								"aria-hidden": "true"
							})
						]
					}), /* @__PURE__ */ m("div", {
						className: Q.transport,
						children: [hr(e), /* @__PURE__ */ p("span", {
							className: Q.transportCaption,
							children: "16TH NOTE / MONO"
						})]
					})]
				}),
				/* @__PURE__ */ p("div", {
					className: Q.steps,
					role: "group",
					"aria-label": `${i} steps`,
					children: t.map((t, n) => /* @__PURE__ */ m("div", {
						className: Q.stepCell,
						children: [/* @__PURE__ */ m("button", {
							className: Q.step,
							"data-enabled": t.enabled,
							"data-silent": !ct(e.id, n, H),
							"data-current": r === n,
							"data-editing": o === n,
							"aria-label": `Step ${n + 1}: ${t.enabled ? Nt(t.note) : "rest"}`,
							"aria-pressed": o === n,
							onClick: () => be(o === n ? null : {
								moduleId: e.id,
								index: n
							}),
							children: [
								/* @__PURE__ */ p("span", { className: Q.stepLed }),
								/* @__PURE__ */ p("span", {
									className: Q.stepNumber,
									children: String(n + 1).padStart(2, "0")
								}),
								/* @__PURE__ */ p("strong", { children: t.enabled ? Nt(t.note) : "—" })
							]
						}), /* @__PURE__ */ p(Vr, {
							mixKey: rt(e.id, n),
							label: a ? `${i} step ${n + 1}` : `step ${n + 1}`,
							mix: H,
							onToggle: mn
						})]
					}, n))
				}),
				o !== null && s && /* @__PURE__ */ m("div", {
					className: Q.stepEditor,
					children: [
						/* @__PURE__ */ m("strong", { children: ["STEP ", String(o + 1).padStart(2, "0")] }),
						/* @__PURE__ */ m("label", { children: [/* @__PURE__ */ p("input", {
							type: "checkbox",
							checked: s.enabled,
							onChange: (t) => On(e.id, o, { enabled: t.target.checked })
						}), "Note on"] }),
						/* @__PURE__ */ m("label", { children: ["Note", /* @__PURE__ */ p("select", {
							"aria-label": "Step note",
							value: s.note,
							onChange: (t) => On(e.id, o, { note: Number(t.target.value) }),
							children: Array.from({ length: 73 }, (e, t) => t + 24).map((e) => /* @__PURE__ */ p("option", {
								value: e,
								children: Nt(e)
							}, e))
						})] }),
						/* @__PURE__ */ m("label", { children: [
							"Velocity",
							/* @__PURE__ */ p("input", {
								"aria-label": "Step velocity",
								type: "range",
								min: 0,
								max: 1,
								step: .01,
								value: s.velocity,
								onChange: (t) => On(e.id, o, { velocity: Number(t.target.value) }, `step:${o}:velocity`)
							}),
							/* @__PURE__ */ m("output", { children: [Math.round(s.velocity * 100), "%"] })
						] }),
						/* @__PURE__ */ m("label", { children: [
							"Gate",
							/* @__PURE__ */ p("input", {
								"aria-label": "Step gate",
								type: "range",
								min: .1,
								max: .95,
								step: .01,
								value: s.gate,
								onChange: (t) => On(e.id, o, { gate: Number(t.target.value) }, `step:${o}:gate`)
							}),
							/* @__PURE__ */ m("output", { children: [Math.round(s.gate * 100), "%"] })
						] }),
						/* @__PURE__ */ p("button", {
							onClick: () => be(null),
							"aria-label": "Close step editor",
							children: "×"
						})
					]
				}),
				/* @__PURE__ */ m("div", {
					className: Q.sequenceHint,
					children: ["Click a step to edit its note, velocity & gate.", /* @__PURE__ */ p("span", { children: "PATCHABLE PITCH + GATE" })]
				})
			]
		});
	}
	let xr = st(d, H), Sr = ![
		"Saved locally",
		"Patch restored",
		"Loading patch…"
	].includes(ae), Cr = /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("img", {
		className: Q.brandMark,
		src: Vi,
		width: "48",
		height: "48",
		alt: ""
	}), /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("strong", { children: "Rackloose" }), /* @__PURE__ */ p("small", { children: "MODULAR SYNTHESIZER" })] })] }), wr = ir || L || W ? sr ? "Drop the plug on a free highlighted jack, or on empty rack space to unplug. Escape puts it back." : "Choose a free highlighted jack. Escape cancels." : Qn ? "Drag either plug to move it. Delete unplugs this cable." : "One cable per jack. Drag from a jack to patch; drag a plug to move or unplug it.";
	return /* @__PURE__ */ p(zi.Provider, {
		value: F,
		children: /* @__PURE__ */ m("section", {
			ref: v,
			className: Q.app,
			"aria-label": "Rackloose modular synthesizer",
			onKeyDown: (e) => {
				e.key !== "Escape" || e.defaultPrevented || (D ? Rn() : K === null ? te ? (ne(!1), Ht.current?.focus()) : T ? (E(!1), S.current?.focus()) : (L || Ce || W) && (R(null), I(null), G(null), O(W ? "Plug back in its jack." : "Patching cancelled.")) : Mn());
			},
			children: [
				/* @__PURE__ */ m("header", {
					className: Q.toolbar,
					children: [o ? /* @__PURE__ */ p("a", {
						className: Q.brand,
						href: "https://rackloose.michaelzick.com/",
						target: "_blank",
						rel: "noopener noreferrer",
						title: "Open Rackloose in a new tab",
						children: Cr
					}) : /* @__PURE__ */ p("div", {
						className: Q.brand,
						children: Cr
					}), /* @__PURE__ */ m("div", {
						className: Q.toolbarActions,
						children: [
							/* @__PURE__ */ m("button", {
								className: Q.audioButton,
								"data-ready": j,
								disabled: t,
								onClick: () => {
									j ? (_.current?.panic(), O("Audio stopped.")) : _.current?.unlock().then(() => O("Audio enabled. Play A–K, tap a key, or start the pattern.")).catch(X);
								},
								children: [/* @__PURE__ */ p("span", { className: Q.statusLed }), j ? "Audio on" : "Enable audio"]
							}),
							/* @__PURE__ */ p("button", {
								onClick: () => {
									_.current?.panic(), O("Panic: all sound and pending notes cleared.");
								},
								title: "Immediately silence all sound",
								children: "Panic"
							}),
							/* @__PURE__ */ p("button", {
								ref: x,
								onClick: () => ee(!0),
								"aria-label": "Open user guide",
								title: "User guide",
								children: "?"
							})
						]
					})]
				}),
				/* @__PURE__ */ m("div", {
					className: Q.patchBar,
					children: [/* @__PURE__ */ m("div", {
						className: Q.patchFile,
						children: [
							/* @__PURE__ */ m("label", {
								className: Q.patchName,
								children: [/* @__PURE__ */ p("span", { children: "PATCH" }), /* @__PURE__ */ m("span", {
									className: Q.nameField,
									"data-value": d.name,
									children: [/* @__PURE__ */ p("input", {
										"aria-label": "Patch name",
										"aria-describedby": ln ? tn : void 0,
										maxLength: 100,
										size: 1,
										value: d.name,
										onChange: (e) => {
											let t = e.target.value;
											Y((e) => e.name === t ? e : {
												...e,
												name: t
											}, "name");
										}
									}), ln && /* @__PURE__ */ m("span", {
										id: tn,
										className: Q.dirtyMark,
										title: "Unsaved changes",
										children: [/* @__PURE__ */ p("span", {
											"aria-hidden": "true",
											children: "*"
										}), /* @__PURE__ */ p("span", {
											className: Q.visuallyHidden,
											children: "Unsaved changes"
										})]
									})]
								})]
							}),
							/* @__PURE__ */ m("span", {
								className: Q.saveStatus,
								"data-save-status": !0,
								"data-error": Sr,
								"aria-live": "polite",
								title: ae,
								children: [
									/* @__PURE__ */ p("span", {
										className: Q.saveLed,
										"aria-hidden": "true"
									}),
									/* @__PURE__ */ p("span", {
										className: Q.saveText,
										children: Sr ? "Not saved" : ae
									}),
									Sr && /* @__PURE__ */ p("span", {
										className: Q.visuallyHidden,
										children: ae
									})
								]
							}),
							/* @__PURE__ */ p("button", {
								"aria-label": "Save to My Presets",
								title: "Save to My Presets in this browser (⌘S / Ctrl+S)",
								onClick: (e) => Dn(e.currentTarget),
								children: "Save"
							}),
							/* @__PURE__ */ p("button", {
								ref: Ht,
								"aria-expanded": te,
								onClick: () => {
									ne(!te), E(!1);
								},
								children: "Presets"
							}),
							/* @__PURE__ */ m("span", {
								className: Q.exportControls,
								children: [/* @__PURE__ */ p("select", {
									"aria-label": "Export loop count",
									title: "Loops to render",
									value: Re,
									onChange: (e) => ze(Number(e.target.value)),
									children: [
										1,
										2,
										4,
										8
									].map((e) => /* @__PURE__ */ m("option", {
										value: e,
										children: [
											e,
											" ",
											e === 1 ? "loop" : "loops"
										]
									}, e))
								}), /* @__PURE__ */ p("button", {
									disabled: Ve,
									"aria-busy": Ve,
									title: "Render every sequencer to a WAV file",
									onClick: () => void Zn(),
									children: Ve ? "Rendering…" : "↓ Export WAV"
								})]
							}),
							/* @__PURE__ */ p("input", {
								ref: b,
								type: "file",
								accept: ".json,application/json",
								hidden: !0,
								"aria-label": "Import patch file",
								onChange: (e) => void Xn(e.target.files?.[0])
							})
						]
					}), /* @__PURE__ */ m("div", {
						className: Q.rackActions,
						children: [
							/* @__PURE__ */ m("span", {
								className: Q.historyActions,
								children: [/* @__PURE__ */ p("button", {
									"aria-label": "Undo",
									title: "Undo (⌘Z / Ctrl+Z)",
									disabled: !gt.undo,
									onClick: () => Cn("undo"),
									children: /* @__PURE__ */ p(Br, { name: "undo" })
								}), /* @__PURE__ */ p("button", {
									"aria-label": "Redo",
									title: "Redo (⇧⌘Z / Ctrl+Y)",
									disabled: !gt.redo,
									onClick: () => Cn("redo"),
									children: /* @__PURE__ */ p(Br, { name: "redo" })
								})]
							}),
							/* @__PURE__ */ p("button", {
								ref: S,
								className: Q.addButton,
								"aria-expanded": T,
								onClick: () => {
									E(!T), ne(!1);
								},
								children: "＋ Add device"
							}),
							/* @__PURE__ */ m("button", {
								className: Q.flipButton,
								"aria-label": C ? "Show front" : "Flip rack",
								"aria-pressed": C,
								onClick: () => {
									xn(), w(!C), R(null), I(null), G(null), O(C ? "Front panel. Turn a knob and make it yours." : "Rear panel. Drag from one jack to another, or tap one then the other.");
								},
								children: ["⇄ ", C ? "Show front" : "Flip rack"]
							})
						]
					})]
				}),
				te && /* @__PURE__ */ p(Ii, {
					presets: Ct,
					openId: on,
					dirty: ln,
					onSaveAs: En,
					onImport: () => b.current?.click(),
					onExportCurrent: () => Fn(d),
					onExport: Fn,
					onDelete: Pn,
					onLoad: (e) => jn(e.patch, `Loaded “${e.patch.name}” from My Presets.`, e.id),
					onLoadFactory: (e) => jn(Tt(e), `${e} loaded. Your rack is patched and ready to play.`),
					onClose: () => {
						ne(!1), Ht.current?.focus();
					}
				}),
				T && /* @__PURE__ */ m("div", {
					className: Q.library,
					role: "region",
					"aria-label": "Device library",
					children: [/* @__PURE__ */ m("div", {
						className: Q.libraryHeading,
						children: [/* @__PURE__ */ p("strong", { children: "MAKE ROOM FOR SOMETHING NEW." }), /* @__PURE__ */ p("button", {
							"aria-label": "Close device library",
							onClick: () => E(!1),
							children: "×"
						})]
					}), /* @__PURE__ */ p("div", {
						className: Q.libraryGrid,
						children: De.map((e) => /* @__PURE__ */ m("button", {
							"data-device": z[e].color,
							disabled: d.modules.length >= 32,
							onClick: () => In(e),
							children: [
								/* @__PURE__ */ m("span", {
									className: Q.miniDevice,
									children: ["◉ ◉ ", /* @__PURE__ */ p("span", { children: "▰" })]
								}),
								/* @__PURE__ */ p("strong", { children: z[e].name }),
								/* @__PURE__ */ p("small", { children: z[e].subtitle })
							]
						}, e))
					})]
				}),
				/* @__PURE__ */ m("div", {
					className: Q.rackHeading,
					children: [/* @__PURE__ */ m("span", { children: [/* @__PURE__ */ p("span", { className: Q.rackLight }), C ? "REAR PANEL / SIGNAL ROUTING" : "YOUR RACK / FRONT PANEL"] }), /* @__PURE__ */ m("span", { children: [
						d.modules.length,
						" DEVICES · ",
						d.cables.length,
						" CONNECTIONS"
					] })]
				}),
				C && /* @__PURE__ */ m("div", {
					className: Q.routingBar,
					children: [/* @__PURE__ */ p("span", { children: wr }), /* @__PURE__ */ m("span", {
						className: Q.legend,
						children: [
							/* @__PURE__ */ p("i", { "data-kind": "audio" }),
							" AUDIO ",
							/* @__PURE__ */ p("i", { "data-kind": "cv" }),
							" CV ",
							/* @__PURE__ */ p("i", { "data-kind": "gate" }),
							" GATE"
						]
					})]
				}),
				/* @__PURE__ */ m("div", {
					className: Q.rack,
					ref: y,
					"data-holding": !!ir,
					onClick: Hn,
					onPointerMove: Yn,
					onPointerLeave: () => Oe(null),
					children: [
						C && /* @__PURE__ */ p(cr, {
							patch: d,
							rackRef: y,
							selected: Ce,
							onSelect: (e) => {
								I(e), R(null), G(null);
							},
							drag: ir
						}),
						d.modules.map((e, n) => {
							let r = z[e.type];
							return /* @__PURE__ */ m("article", {
								className: Q.module,
								"data-module-id": e.id,
								"data-device": r.color,
								"data-rear": C,
								"data-revealed": Ae === e.id,
								"data-silent": xr[e.id] === !1,
								"data-keyboard-target": gr.id === e.id,
								onPointerDown: () => {
									C || bn(e);
								},
								onFocus: () => {
									C || bn(e);
								},
								"aria-label": `${r.name} ${r.subtitle}`,
								children: [
									/* @__PURE__ */ p("span", { className: `${Q.screw} ${Q.screwTL}` }),
									/* @__PURE__ */ p("span", { className: `${Q.screw} ${Q.screwTR}` }),
									/* @__PURE__ */ p("span", { className: `${Q.screw} ${Q.screwBL}` }),
									/* @__PURE__ */ p("span", { className: `${Q.screw} ${Q.screwBR}` }),
									/* @__PURE__ */ m("div", {
										className: Q.moduleHeader,
										children: [/* @__PURE__ */ m("div", {
											className: Q.moduleIdentity,
											children: [
												at(e.type) && /* @__PURE__ */ p(Bi, {
													select: (t) => t.pulsing.has(e.id),
													children: (e) => /* @__PURE__ */ p("span", {
														className: Q.hitLed,
														"data-lit": e,
														title: "Flashes on each sequencer hit",
														"aria-hidden": "true"
													})
												}),
												Ye(e.type) ? /* @__PURE__ */ p("button", {
													className: Q.moduleNameButton,
													"aria-label": `Select ${r.name} ${n + 1} for keyboard`,
													"aria-pressed": gr.id === e.id,
													onClick: () => {
														C || bn(e);
													},
													children: r.name
												}) : /* @__PURE__ */ p("span", {
													className: Q.moduleName,
													children: r.name
												}),
												/* @__PURE__ */ p("span", {
													className: Q.moduleSubtitle,
													children: r.subtitle
												})
											]
										}), /* @__PURE__ */ m("div", {
											className: Q.moduleTools,
											children: [
												e.type !== "output" && /* @__PURE__ */ p(Vr, {
													mixKey: e.id,
													label: r.name,
													mix: H,
													onToggle: mn,
													clearable: mt(e, H),
													onClear: () => fn((t) => ({ mix: ht(t.mix, e) }))
												}),
												/* @__PURE__ */ p("span", {
													className: Q.moduleNumber,
													children: String(n + 1).padStart(2, "0")
												}),
												!Me(d, e.id) && /* @__PURE__ */ m(f, { children: [
													/* @__PURE__ */ p("button", {
														"aria-label": `Move ${r.name} up`,
														disabled: n === 1,
														onClick: () => Y((t) => Ue(t, e.id, -1)),
														children: "↑"
													}),
													/* @__PURE__ */ p("button", {
														"aria-label": `Move ${r.name} down`,
														disabled: n === d.modules.length - 2,
														onClick: () => Y((t) => Ue(t, e.id, 1)),
														children: "↓"
													}),
													/* @__PURE__ */ p("button", {
														"aria-label": `Duplicate ${r.name}`,
														disabled: d.modules.length >= 32,
														onClick: () => Ln(e),
														children: "⧉"
													}),
													/* @__PURE__ */ p("button", {
														"aria-label": `Remove ${r.name}`,
														onClick: () => {
															xn(), G(null), U.current === e.id && bn(d.modules[0]), Y((t) => He(t, e.id)), I(null), R(null), O(`${r.name} removed. Undo brings it back with its cables.`);
														},
														children: "×"
													})
												] })
											]
										})]
									}),
									C ? dr(e) : e.type === "performance" ? br(e) : /* @__PURE__ */ m(f, { children: [
										r.drum && /* @__PURE__ */ m("div", {
											className: Q.moduleTransport,
											children: [hr(e), /* @__PURE__ */ m("span", { children: [
												"SHARED TEMPO · ",
												d.sequencer.bpm,
												" BPM"
											] })]
										}),
										/* @__PURE__ */ m("div", {
											className: Q.moduleBody,
											children: [e.type === "mixer" ? /* @__PURE__ */ p(Bi, {
												select: (t) => t.mixerLevels[e.id] ?? Hi,
												children: (t) => /* @__PURE__ */ p(ji, {
													module: e,
													patch: d,
													mix: H,
													levels: t,
													onParams: (t) => pn(e.id, t),
													onToggle: mn
												})
											}) : /* @__PURE__ */ p("div", {
												className: Q.controls,
												children: r.params.filter((e) => !e.voice && !e.group).map((t) => fr(e, t, r.name))
											}), e.type !== "mixer" && /* @__PURE__ */ p("div", {
												className: Q.moduleDecoration,
												children: e.type === "output" ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(Bi, {
													select: (e) => e.meter,
													children: (e) => /* @__PURE__ */ p("div", {
														className: Q.meters,
														"aria-label": "Output level",
														role: "meter",
														"aria-valuemin": 0,
														"aria-valuemax": 1,
														"aria-valuenow": Number(e.toFixed(3)),
														children: [0, 1].map((t) => /* @__PURE__ */ m("div", {
															className: Q.meterRow,
															children: [/* @__PURE__ */ p("span", { children: t === 0 ? "L" : "R" }), Array.from({ length: 18 }, (t, n) => /* @__PURE__ */ p("i", {
																"data-lit": n / 18 < e,
																"data-hot": n > 14
															}, n))]
														}, t))
													})
												}), /* @__PURE__ */ p("button", {
													"aria-pressed": N,
													onClick: () => fn((e) => ({ mainMuted: !e.mainMuted })),
													className: Q.muteButton,
													children: N ? "UNMUTE" : "MUTE"
												})] }) : e.type === "envelope" ? /* @__PURE__ */ p(Rr, { params: e.params }) : ["compressor", "cohere"].includes(e.type) ? /* @__PURE__ */ p(Bi, {
													select: (t) => t.reductions[e.id] ?? 0,
													children: (e) => /* @__PURE__ */ p(Pr, {
														reduction: e,
														label: `${r.name} ${n + 1} gain reduction`
													})
												}) : e.type === "equalizer" ? /* @__PURE__ */ p(Nr, { params: e.params }) : r.drum?.mode === "euclid" ? /* @__PURE__ */ p(Yr, {
													module: e,
													clock: it[e.id]?.clock ?? -1
												}) : /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("span", { className: Q.deviceLed }), /* @__PURE__ */ m("span", {
													className: Q.deviceLabel,
													children: [
														Zi[e.type] ?? "RACKLOOSE",
														/* @__PURE__ */ p("br", {}),
														/* @__PURE__ */ p("small", { children: "PATCH. PLAY. REPEAT." })
													]
												})] })
											})]
										}),
										e.type === "brit" ? /* @__PURE__ */ p(di, {
											module: e,
											rate: he,
											onParams: (t) => pn(e.id, t)
										}) : e.type === "talon" ? /* @__PURE__ */ p(Bi, {
											select: (t) => t.reductions[e.id] ?? 0,
											children: (t) => /* @__PURE__ */ p(Si, {
												module: e,
												reduction: t,
												label: `${r.name} ${n + 1} gain reduction`,
												onParams: (t) => pn(e.id, t)
											})
										}) : pr(e),
										e.type === "prism" && /* @__PURE__ */ p($r, {
											module: e,
											onParams: (t) => pn(e.id, t)
										}),
										["strike", "forge"].includes(e.type) && /* @__PURE__ */ p(Zr, {
											module: e,
											onParams: (t) => pn(e.id, t),
											onAudition: (t) => vn(e.id, t),
											disabled: t
										}),
										r.drum?.mode === "euclid" && /* @__PURE__ */ p(qr, {
											module: e,
											clock: it[e.id]?.clock ?? -1,
											mix: H,
											onMix: mn,
											disabled: t,
											onParams: (t) => pn(e.id, t),
											onAudition: (t) => vn(e.id, t)
										}),
										r.drum?.mode === "steps" && /* @__PURE__ */ p(Gr, {
											module: e,
											mix: H,
											onMix: mn,
											step: (it[e.id]?.clock ?? -1) < 0 ? -1 : it[e.id].clock % 16,
											disabled: t,
											onParams: (t) => pn(e.id, t),
											onAudition: (t) => vn(e.id, t)
										})
									] })
								]
							}, e.id);
						}),
						/* @__PURE__ */ m("div", {
							className: Q.rackBottom,
							children: [/* @__PURE__ */ p("span", { children: "RACKLOOSE / BY MICHAEL ZICK © 2026" }), /* @__PURE__ */ p("span", { children: "NO RULES. JUST SIGNAL." })]
						})
					]
				}),
				/* @__PURE__ */ p("div", {
					className: Q.toastAnchor,
					children: /* @__PURE__ */ p("div", {
						className: Q.toast,
						role: "status",
						"data-shown": le,
						children: ce
					})
				}),
				/* @__PURE__ */ m("div", {
					className: Q.keyboardPanel,
					children: [
						/* @__PURE__ */ m("div", {
							className: Q.globalControls,
							role: "group",
							"aria-label": "Global controls",
							children: [
								/* @__PURE__ */ m("div", {
									className: Q.globalTransport,
									children: [
										/* @__PURE__ */ m("button", {
											className: Q.playButton,
											disabled: t,
											onClick: yn,
											"data-playing": k,
											"aria-label": k ? "Pause all sequencers" : "Play all sequencers",
											children: [/* @__PURE__ */ p(Br, { name: k ? "pause" : "play" }), /* @__PURE__ */ p("span", { children: k ? "PAUSE ALL" : "PLAY ALL" })]
										}),
										/* @__PURE__ */ m("button", {
											className: Q.resetButton,
											onClick: () => _.current?.reset(),
											"aria-label": "Reset all sequencers",
											children: [/* @__PURE__ */ p(Br, { name: "reset" }), /* @__PURE__ */ p("span", { children: "RESET" })]
										}),
										/* @__PURE__ */ p("button", {
											className: Q.clearAllButton,
											disabled: !H.muted.size && !H.soloed.size && !N,
											onClick: () => {
												fn({
													mix: tt,
													mainMuted: !1
												}), O("All mutes and solos cleared.");
											},
											"aria-label": "Clear all mutes and solos",
											children: /* @__PURE__ */ p("span", { children: "CLR ALL" })
										})
									]
								}),
								/* @__PURE__ */ p(Pi, {
									bpm: d.sequencer.bpm,
									onChange: (e) => kn("bpm", e)
								}),
								/* @__PURE__ */ m("label", {
									className: Q.swingField,
									children: [
										"SWING",
										/* @__PURE__ */ p("input", {
											type: "range",
											min: 0,
											max: .6,
											step: .01,
											value: d.sequencer.swing,
											"aria-label": "Swing",
											onChange: (e) => kn("swing", Number(e.target.value))
										}),
										/* @__PURE__ */ m("span", { children: [Math.round(d.sequencer.swing * 100), "%"] })
									]
								}),
								/* @__PURE__ */ m("span", {
									className: Q.globalPosition,
									"aria-label": "Global position",
									children: [P < 0 ? "01" : String(P % 16 + 1).padStart(2, "0"), " / 16"]
								})
							]
						}),
						/* @__PURE__ */ m("div", {
							className: Q.keyboardTop,
							children: [
								/* @__PURE__ */ m("strong", {
									className: Q.keyboardTarget,
									children: ["KEYBOARD → ", mr(gr)]
								}),
								yr ? /* @__PURE__ */ p("span", {
									className: Q.routingHint,
									title: yr,
									children: yr
								}) : e && /* @__PURE__ */ p("span", {
									className: Q.keyHint,
									children: _r ? _r.length > 11 ? "Home row + Z X C V B" : "Home row · pads" : "A–K · notes"
								}),
								!_r && /* @__PURE__ */ m("div", {
									className: Q.octaveControls,
									children: [
										/* @__PURE__ */ p("button", {
											"aria-label": "Lower keyboard octave",
											disabled: _e === 1,
											onClick: () => fn((e) => ({ octave: Math.max(1, e.octave - 1) }), "octave"),
											children: "−"
										}),
										/* @__PURE__ */ m("span", { children: ["OCT ", _e] }),
										/* @__PURE__ */ p("button", {
											"aria-label": "Raise keyboard octave",
											disabled: _e === 6,
											onClick: () => fn((e) => ({ octave: Math.min(6, e.octave + 1) }), "octave"),
											children: "＋"
										})
									]
								}),
								/* @__PURE__ */ p("button", {
									className: Q.keysToggle,
									"aria-expanded": xe,
									"aria-controls": $t,
									onClick: () => Se(!xe),
									children: xe ? "Hide keys" : "Show keys"
								})
							]
						}),
						/* @__PURE__ */ p("div", {
							id: $t,
							hidden: !xe,
							children: _r ? /* @__PURE__ */ p("div", {
								className: Q.performancePads,
								"data-voices": _r.length,
								"data-rows": _r.length > 6 ? 2 : 1,
								style: { "--pad-columns": vr },
								"aria-label": `${$.name} performance pads`,
								children: _r.map((n, r) => /* @__PURE__ */ m("button", {
									"data-playing": Je.has(n.id),
									"aria-label": `Keyboard ${$.name} ${n.label}`,
									disabled: t,
									onPointerDown: (e) => {
										e.button === 0 && (e.preventDefault(), e.currentTarget.setPointerCapture(e.pointerId), nt.current.add(`pointer-${e.pointerId}`), _n(`pointer-${e.pointerId}`, r, e.pointerType !== "mouse"));
									},
									onPointerUp: (e) => Z(`pointer-${e.pointerId}`),
									onPointerCancel: (e) => Z(`pointer-${e.pointerId}`, !0),
									onLostPointerCapture: (e) => Z(`pointer-${e.pointerId}`, !0),
									onKeyDown: (e) => {
										(e.key === "Enter" || e.key === " ") && !e.repeat && (e.preventDefault(), e.stopPropagation(), _n(`pad-${n.id}`, r));
									},
									onKeyUp: (e) => {
										(e.key === "Enter" || e.key === " ") && (e.preventDefault(), Z(`pad-${n.id}`));
									},
									onBlur: () => Z(`pad-${n.id}`),
									children: [/* @__PURE__ */ p("span", { children: n.label }), e && /* @__PURE__ */ p("small", { children: Wi[r].toUpperCase() })]
								}, n.id))
							}) : /* @__PURE__ */ p("div", {
								className: Q.piano,
								"aria-label": "Piano keyboard",
								children: Array.from({ length: 13 }, (e, n) => {
									let r = (_e + 1) * 12 + n, i = Gi.has(n % 12);
									return /* @__PURE__ */ m("button", {
										className: i ? Q.blackKey : Q.whiteKey,
										"data-note": r,
										"data-playing": pe.includes(r),
										"aria-label": `Play ${Nt(r)}`,
										disabled: t,
										onPointerDown: (e) => {
											e.button === 0 && (e.preventDefault(), e.currentTarget.setPointerCapture(e.pointerId), nt.current.add(`pointer-${e.pointerId}`), _n(`pointer-${e.pointerId}`, n, e.pointerType !== "mouse"));
										},
										onPointerUp: (e) => Z(`pointer-${e.pointerId}`),
										onPointerCancel: (e) => Z(`pointer-${e.pointerId}`, !0),
										onLostPointerCapture: (e) => Z(`pointer-${e.pointerId}`, !0),
										onKeyDown: (e) => {
											(e.key === "Enter" || e.key === " ") && !e.repeat && (e.preventDefault(), e.stopPropagation(), _n(`piano-${r}`, n));
										},
										onKeyUp: (e) => {
											(e.key === "Enter" || e.key === " ") && (e.preventDefault(), Z(`piano-${r}`));
										},
										onBlur: () => Z(`piano-${r}`),
										children: [/* @__PURE__ */ p("span", { children: Ui[n].toUpperCase() }), !i && /* @__PURE__ */ p("small", { children: Nt(r) })]
									}, n);
								})
							})
						})
					]
				}),
				D && /* @__PURE__ */ p("div", {
					className: Q.helpBackdrop,
					children: /* @__PURE__ */ m("div", {
						className: Q.help,
						role: "dialog",
						"aria-modal": "true",
						"aria-labelledby": en,
						onKeyDown: (e) => {
							if (e.key === "Tab") {
								let t = e.currentTarget.querySelectorAll("button");
								t.length === 1 && (e.preventDefault(), t[0].focus());
							}
						},
						children: [
							/* @__PURE__ */ m("div", {
								className: Q.helpHeading,
								children: [
									/* @__PURE__ */ p("img", {
										src: "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2064%2064'%3e%3crect%20x='5'%20y='6'%20width='54'%20height='52'%20rx='3'%20fill='%23303337'%20stroke='%23101214'%20stroke-width='2'/%3e%3cpath%20d='M10%2010v44M54%2010v44'%20stroke='%23777'%20stroke-width='3'/%3e%3crect%20x='14'%20y='12'%20width='36'%20height='17'%20fill='%23b9503a'%20stroke='%23111'/%3e%3crect%20x='14'%20y='31'%20width='36'%20height='20'%20fill='%23a0ac9b'%20stroke='%23111'/%3e%3cg%20fill='%23232626'%20stroke='%23dfdfca'%3e%3ccircle%20cx='23'%20cy='21'%20r='5'/%3e%3ccircle%20cx='41'%20cy='21'%20r='5'/%3e%3c/g%3e%3cpath%20d='M23%2021v-4m18%204%203-3'%20stroke='%23fff'%20stroke-width='2'/%3e%3cg%20fill='%231b2221'%20stroke='%23555'%3e%3ccircle%20cx='22'%20cy='39'%20r='3'/%3e%3ccircle%20cx='42'%20cy='44'%20r='3'/%3e%3c/g%3e%3cpath%20d='M22%2039c-6%2020%2027%2020%2020%205'%20fill='none'%20stroke='%23f4bb50'%20stroke-width='3'/%3e%3cpath%20d='M7%208h50'%20stroke='%23a9abad'/%3e%3c/svg%3e",
										width: "34",
										height: "34",
										alt: ""
									}),
									/* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("small", { children: "RACKLOOSE · MODULAR SYNTHESIZER" }), /* @__PURE__ */ p("h2", {
										id: en,
										children: "User Guide"
									})] }),
									/* @__PURE__ */ p("button", {
										autoFocus: !0,
										onClick: Rn,
										"aria-label": "Close user guide",
										children: "×"
									})
								]
							}),
							/* @__PURE__ */ p("h3", { children: "Transport" }),
							/* @__PURE__ */ p("p", { children: "Play All starts every sequencer and turns into Pause All while anything plays. Reset stops and rewinds. Type a tempo or drag the small slider under it; the change is heard right away. Space always plays and pauses, whichever control has focus, except while typing in a text field. Each STEP–16 and drum machine also has its own Play/Stop, locked to the shared tempo, swing and position." }),
							/* @__PURE__ */ p("h3", { children: "Playing" }),
							/* @__PURE__ */ m("p", { children: [
								"Click a device to aim the keyboard at it. MONARCH, ORACLE, AURORA, PRISM and SOLID play on ",
								/* @__PURE__ */ p("strong", { children: "A W S E D F T G Y H U J K" }),
								", and OCT shifts the range. MONARCH plays one note at a time; ORACLE plays up to five, AURORA eight and PRISM sixteen. Their Chord setting turns every note, from the keys or STEP–16, into a chord. Drum machines get pads on the home row, ",
								/* @__PURE__ */ p("strong", { children: "A S D F G H J K L ; '" }),
								", plus ",
								/* @__PURE__ */ p("strong", { children: "Z X C V B" }),
								" for STRIKE’s remaining five voices. STATIC holds noise on A. STEP–16 plays whatever its Pitch and Gate cables reach, and effects keep the last instrument. The light beside each instrument and drum machine flashes every time a sequencer plays it. Hide keys keeps every global control."
							] }),
							/* @__PURE__ */ p("h3", { children: "Knobs and steps" }),
							/* @__PURE__ */ p("p", { children: "Drag a knob up or down, or use the arrow keys; double-click restores its default. Click a STEP–16 step to set its note, velocity and gate. Add device adds more STEP–16s: each has its own 16 steps, Play/Stop and step mutes, and plays whatever its own Pitch and Gate cables reach, so separate parts can drive separate instruments. Typing in a field never plays notes." }),
							/* @__PURE__ */ p("h3", { children: "Patching cables" }),
							/* @__PURE__ */ p("p", { children: "Flip the rack to patch. Each jack holds one cable. Drag from an empty jack to a free one; jacks that can take it light up. Drag a plugged jack to pull its plug out: drop it on a free jack to move it, or on empty rack space to unplug it. You can also tap a plugged jack to lift its plug, then tap a free jack. Escape or a bad drop puts the plug back, and Delete unplugs a selected cable. Every output has a spare jack, and STEP–16 has three Pitch and three Gate jacks, so one signal can feed several places. Amber is audio, blue is CV and coral is gate; types must match. The trim beside a CV input sets its depth. SUM mixes eight channels and names each one after the instrument feeding it, through any effects; hover the name to see the chain." }),
							/* @__PURE__ */ p("h3", { children: "Mixing on SUM" }),
							/* @__PURE__ */ p("p", { children: "SUM is laid out like a console. Each channel strip has Pan, M and S, a fader and a level meter: green, amber from −9 dB and red from −3 dB. Drag a fader or pan knob, or use the arrow keys; double-click returns it to its default. The MIX BUS fader on the right sets the level of the whole mix, with its own left and right meters." }),
							/* @__PURE__ */ p("h3", { children: "Drums" }),
							/* @__PURE__ */ p("p", { children: "AURORA is an eight-voice Jupiter-8-inspired polysynth: blend two oscillators, shape them with high-pass and 12/24 dB low-pass filters, and animate pulse width with the LFO. PRISM is a focused DX7-inspired FM synth: choose one of six algorithms, then select an operator to edit its ratio, level and envelope. Brightness controls modulation depth; Velocity makes quieter sequenced notes softer in tone. Both use their own envelopes and work with STEP–16 Pitch and Gate, or directly from the keyboard." }),
							/* @__PURE__ */ p("p", { children: "STRIKE has sixteen vintage digital drum lanes. Select a voice to edit Tune, Decay, Tone, Level and Pan. Its sounds are original generated one-shots, inspired by LinnDrum. BOOM has eleven voices: kick, snare, rim, clap, closed and open hat, low and high tom, crash, ride and bell. A closed hat cuts off a ringing open hat. Click a voice name to hear it and click pads to program its steps. ORBIT voices each have Steps, Hits and Shift; tap its step pads for a custom rhythm, and Generate brings back the Euclidean pattern. A drum machine’s Chain in passes another instrument through. SKITTER is a trap step sequencer that makes no sound: patch Trig out into a drum machine’s Trig in and its lanes play that kit’s kick, snare, clap, hats and perc, or patch Synth gate into MONARCH, CONTOUR or a polysynth. Pick a note under Note, then tap a step to play it as a 1/16, a pair of 1/32s, or a roll of 1/32 triplets, 1/64s or 1/64 triplets. FORGE is an industrial rock kit with its own Drive and gated Room, and RUST distorts anything patched into it, from fuzz to crushed bits." }),
							/* @__PURE__ */ p("h3", { children: "Dynamics and EQ" }),
							/* @__PURE__ */ p("p", { children: "VALVE is a tube limiter: Input drives the tube, Threshold sets where it starts to hold the level back, and Time constant picks how fast it lets go, from 1 (quick) to 6 (slow). The needle shows the gain reduction. CONSOLE is a channel EQ: high- and low-pass filters, LF and HF that switch between shelf and bell, and two sweepable mids with Q. The screen draws the curve you hear, and EQ Out bypasses it." }),
							/* @__PURE__ */ p("h3", { children: "Mute and solo" }),
							/* @__PURE__ */ p("p", { children: "M mutes and S solos a device, drum voice, SUM channel or step, and the two are exclusive. CLR clears one device, with its voices, channels or steps; CLR ALL clears everything, MAIN’s mute included. Silenced parts dim. These settings last for this session." }),
							/* @__PURE__ */ p("h3", { children: "Undo and unsaved changes" }),
							/* @__PURE__ */ m("p", { children: [
								"Undo and Redo, or ",
								/* @__PURE__ */ p("strong", { children: "⌘Z" }),
								" and ",
								/* @__PURE__ */ p("strong", { children: "⇧⌘Z" }),
								" (",
								/* @__PURE__ */ p("strong", { children: "Ctrl+Z" }),
								" and ",
								/* @__PURE__ */ p("strong", { children: "Ctrl+Y" }),
								"), step through your last 50 changes: knobs, steps, tempo, cables, devices, presets, mutes, solos and octave. A ",
								/* @__PURE__ */ p("strong", { children: "*" }),
								" after the patch name means it has changed since you last saved it to My Presets or loaded it."
							] }),
							/* @__PURE__ */ p("h3", { children: "Presets and files" }),
							/* @__PURE__ */ m("p", { children: [
								"Your rack keeps itself between visits. Save, or ",
								/* @__PURE__ */ p("strong", { children: "⌘S" }),
								" (",
								/* @__PURE__ */ p("strong", { children: "Ctrl+S" }),
								"), keeps it in My Presets in this browser: the first save asks for a name, and later saves update that preset. Type a new name in PATCH and save to rename it; Save as… (",
								/* @__PURE__ */ p("strong", { children: "⇧⌘S" }),
								") makes a copy. Presets lists My Presets above the factory presets. Export downloads a preset as a .json file, Import file adds one to My Presets, and Delete removes your own presets. Export WAV, beside Presets, renders the number of loops chosen next to it, every sequencer from the start, effects and mutes included, but not MAIN’s Mute. The light beside the patch name shows whether your rack is saved in this browser, and messages appear briefly over the bottom of the rack. Panic silences everything at once."
							] })
						]
					})
				}),
				K !== null && /* @__PURE__ */ p(Li, {
					initialName: K,
					presets: Ct,
					onSave: Nn,
					onCancel: Mn
				})
			]
		})
	});
}
//#endregion
export { oa as RacklooseApp, Ot as parsePatch, Tt as preset, Et as serializePatch };
