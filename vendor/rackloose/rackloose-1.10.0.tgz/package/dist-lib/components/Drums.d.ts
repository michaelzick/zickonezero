import { type Mix, type RackModule } from '../model';
import { type MixToggle } from './MixButtons';
/** `onParams` changes one or more of the module's params as a single edit. */
type DrumProps = {
    module: RackModule;
    mix: Mix;
    onMix: MixToggle;
    onParams: (values: Record<string, number>) => void;
    onAudition: (voice: string) => void;
    disabled?: boolean;
};
/**
 * The params a tap on step `index` changes. With the 1/16 brush it toggles the step, clearing any 1/32s or roll it had;
 * another brush sets that note value on the step, turning it on, and tapping a step already set that way takes it back to 1/16.
 */
export declare function editRoll(module: RackModule, voice: string, index: number, brush: number): Record<string, number>;
/** One lane of 16 pads per voice, in groups of four. The voice name auditions it; `step` lights the playhead. */
export declare function DrumPads({ module, mix, onMix, step, onParams, onAudition, disabled }: DrumProps & {
    step: number;
}): import("react").JSX.Element;
/** Six rhythm lanes plus the sound and step editor for the selected lane. */
export declare function EuclidMatrix({ module, mix, onMix, onParams, onAudition, disabled, clock }: DrumProps & {
    clock: number;
}): import("react").JSX.Element;
/** Concentric rings, outermost first: one dot per step, large dots for hits, and the playhead glowing at `clock`. */
export declare function OrbitRings({ module, clock }: {
    module: RackModule;
    clock: number;
}): import("react").JSX.Element;
export {};
