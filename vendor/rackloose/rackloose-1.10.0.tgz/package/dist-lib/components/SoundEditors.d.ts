import { type RackModule } from '../model';
type EditorProps = {
    module: RackModule;
    onParams: (values: Record<string, number>) => void;
};
/** Tune, Decay, Tone, Level and Pan for one voice of a sampled drum machine: STRIKE or FORGE. */
export declare function VoiceEditor({ module, onParams, onAudition, disabled }: EditorProps & {
    onAudition: (voice: string) => void;
    disabled?: boolean;
}): import("react").JSX.Element;
export declare function PrismEditor({ module, onParams }: EditorProps): import("react").JSX.Element;
export {};
