import type { Patch } from './model';
export { INDUSTRIAL_PRESETS } from './model';
type Name = typeof import('./model').INDUSTRIAL_PRESETS[number];
/**
 * Two industrial rock originals. FORGE's kit hits through its own drive and gated room, and every synth part goes
 * through RUST before it reaches the mix: fuzz and rectified grind on the slow one, broken clipping and crushed
 * stabs on the fast one.
 */
export declare function industrialPreset(name: Name): Patch;
